# Instalación asistida con Claude Code

**Para el equipo (3 pasos):**

1. Copia el zip (y su `.sha256` si te lo pasaron) a una carpeta temporal de tu máquina, p. ej. `/tmp/talent-issue-craft-2026-07-21.zip`.
2. Abre Claude Code **en la raíz del repositorio** donde quieres instalar el skill.
3. Pega el prompt de abajo sustituyendo `<RUTA-DEL-ZIP>` por la ruta real. Claude Code hace el resto y te pregunta solo lo imprescindible.

---

## Prompt (copiar desde aquí)

```text
Instala el skill `talent-issue-craft` en este repositorio desde un paquete zip.

Zip: <RUTA-DEL-ZIP>

Ejecuta estos pasos EN ORDEN, verificando cada uno; si algo falla, DETENTE y repórtamelo en lugar de improvisar:

1. Integridad: si junto al zip existe un archivo `.sha256`, verifícalo con `sha256sum -c`. Si no coincide, PARA.
2. Descomprime el zip en un directorio temporal y confirma que contiene la carpeta `talent-issue-craft/` con `SKILL.md`, `references/`, `templates/`, `scripts/` y `examples/`.
3. Si ya existe `.claude/skills/talent-issue-craft/` en este repo, DETENTE y pregúntame antes de tocar nada. Si no existe, copia la carpeta completa a `.claude/skills/talent-issue-craft/`.
4. Verifica la instalación (ninguna necesita credenciales), desde `.claude/skills/talent-issue-craft/`:
   a. `npx tsx scripts/issue_craft_helper.ts --action list-types` → debe imprimir la matriz de 14 combinaciones.
   b. `bash scripts/check_nucleo_parity.sh` → debe terminar con código 0.
   c. `npx tsx scripts/issue_craft_helper.ts --action audit-issue --file examples/gold-fix.md` → debe terminar con `verdict=PRE-CHECK-OK`.
5. Parametriza el skill para ESTE repo: lee `templates/perfil-de-repo.md` y rellénalo derivando del propio repositorio todo lo que puedas (checks y gates reales del package.json o del CI, idiomas del contenido, convención de ramas y PRs, superficies sensibles del producto). Pregúntame ÚNICAMENTE lo que no puedas derivar con evidencia (por ejemplo: destinatario de escalada, régimen de cierre si no es evidente, umbral del score si hay historial propio).
6. Si el repo tiene archivo de instrucciones de agente (CLAUDE.md o equivalente), añade el registro: cargar este skill SIEMPRE antes de crear, redactar, optimizar o auditar cualquier issue.
7. Si vamos a usar las acciones remotas del auditor (auditar issues del tracker por id), recuérdame declarar `LINEAR_API_KEY` en un `.env.local` ignorado por git — nunca pasarla por argumentos de línea de comandos.
8. Dame un reporte final: cada verificación con su salida literal, qué campos del perfil quedaron rellenos con qué evidencia, y qué quedó pendiente de mi respuesta.

No modifiques NADA del contenido interno del skill (plantillas, references, scripts): solo instalarlo, parametrizar `perfil-de-repo.md` y registrarlo.
```

---

**Notas:**

- El aprovisionamiento de plantillas nativas en el tracker (`provision-templates`) NO es parte de la instalación: es una operación de escritura al workspace y va aparte, con el visto bueno del responsable (ver `INSTRUCCIONES.md`, sección "Plantillas nativas").
- Windows: usar WSL o Git Bash para los comandos de verificación (`sha256sum`, `bash`).
