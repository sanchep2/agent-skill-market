# talent-issue-craft — instalación y uso

Sistema de creación y optimización de issues con calidad estado-del-arte para ejecución agéntica: 9 tipos de tarea × variantes = 14 combinaciones, plantillas gold, régimen de decisiones en 3 estados, rúbricas de verificación para ejecutor y revisores, y un auditor con exit-code (`audit-issue`) como gate de despachabilidad. Derivado del análisis forense de un corpus real de ~2000 issues. Tracker objetivo: Linear (API GraphQL). Contenido en español neutro, independiente de stack y de repositorio.

> **Versión del paquete**: 2026-07-21.

## Primeros pasos recomendados (en orden)

1. **Instala** el skill en tu repositorio (vía asistida con `PROMPT-INSTALACION.md`, o los pasos manuales de abajo).
2. **Parametriza** `templates/perfil-de-repo.md` con los datos de TU repositorio (gates, idiomas, convenciones).
3. **Aprovisiona TUS plantillas nativas en TU workspace de Linear** (una sola vez por workspace): primero el dry-run para revisar, luego el apply — ver la sección "Plantillas nativas en Linear" más abajo. A partir de ahí, el selector de plantillas de Linear te ofrece los 9 tipos y toda issue nueva nace clasificada.
4. **Úsalo a diario**: crea issues desde las plantillas, pre-checkea borradores con `audit-issue --file` y gatea con `audit-issue --issue` antes de ponerte (o poner a un agente) a ejecutar.

## Requisitos

- Un agente que soporte skills (carpeta `.claude/skills/`) o cualquier flujo donde puedas leer los archivos del skill como guía.
- Node.js ≥ 22 y `npx` (el helper usa solo builtins de Node; `tsx` se resuelve solo con `npx tsx`).
- Una API key personal de Linear SOLO para las acciones remotas (`audit-issue --issue`, `provision-templates --apply`). Las acciones locales (`list-types`, `audit-issue --file`, `provision-templates --dry-run`) funcionan sin credenciales.

## Instalación

> **Vía recomendada — instalación asistida**: pon el zip en una carpeta temporal y pega en tu sesión de agente el prompt de `PROMPT-INSTALACION.md` (incluido en este paquete): verifica integridad, instala, corre las comprobaciones y te guía para parametrizar el perfil del repo. Los pasos manuales de abajo son el equivalente.

1. Descomprimir este zip. Copiar la carpeta `talent-issue-craft/` a los skills del repositorio destino:

   ```bash
   unzip talent-issue-craft-<fecha>.zip
   cp -r talent-issue-craft <repo>/.claude/skills/
   ```

   Para uso personal en todos tus proyectos: `~/.claude/skills/talent-issue-craft/`.

2. Verificar la instalación (sin credenciales):

   ```bash
   cd <repo>/.claude/skills/talent-issue-craft
   npx tsx scripts/issue_craft_helper.ts --action list-types
   # Esperado: la matriz sellada de 14 combinaciones type × variant
   ```

3. Credenciales (solo para acciones remotas): declarar `LINEAR_API_KEY` en el entorno o en un `.env.local` (NUNCA committearlo; añadirlo a `.gitignore`). La key jamás se pasa por argumentos de línea de comandos.

4. **Parametrizar el repo** (paso clave): rellenar `templates/perfil-de-repo.md` con los datos del repositorio — gates/checks requeridos, idiomas, superficies sensibles, régimen de cierre, destinatario de escalada, escalera de enforcement y umbral del score. El skill es genérico; el perfil es lo que lo aterriza a tu equipo.

5. Calibrar el umbral del score con historial propio cuando exista (método en `references/02-verificaciones.md` §10). Sin historial: usar el default documentado y recalibrar a las 10+ issues cerradas.

## Uso diario

- **Crear una issue**: elegir tipo/variante con la tabla de routing de `SKILL.md` → copiar `templates/NN-<tipo>.md` → rellenar y sellar decisiones → pre-check local:

  ```bash
  npx tsx scripts/issue_craft_helper.ts --action audit-issue --file mi-borrador.md
  ```

- **Gate de despachabilidad** (con la issue ya creada en Linear, con estimate/prioridad/etiquetas/proyecto):

  ```bash
  npx tsx scripts/issue_craft_helper.ts --action audit-issue --issue ABC-123
  # Despachable = classification_source=marker + operational_gate_eligible=true + exit 0
  ```

- **Optimizar una issue existente**: auditar → reescribir con la plantilla del tipo → re-auditar y comparar score.

- Doctrina completa: `references/01` (núcleo y despachabilidad) · `references/02` (rúbricas y baterías de verificación) · `references/03` (patrones GraphQL de Linear) · `references/04` (12 anti-patrones con evidencia). Ejemplos rellenos en `examples/`.

## Plantillas nativas en Linear (opcional, recomendado)

Aprovisiona las 9 plantillas como Templates nativos del tracker — así toda issue creada desde el selector de Linear nace con el marcador de clasificación y la estructura completa:

```bash
# 1. Previsualizar (default; sin red, sin credenciales, cero escrituras):
npx tsx scripts/issue_craft_helper.ts --action provision-templates --global
#    (o por equipo: --team <KEY>)

# 2. Aplicar (única vía de escritura; requiere LINEAR_API_KEY y el GO del responsable):
npx tsx scripts/issue_craft_helper.ts --action provision-templates --global --apply
```

- `--global`: Templates de workspace, visibles en TODOS los equipos (recomendado en workspaces multi-equipo).
- `--team <KEY>`: Templates solo de ese equipo.
- El apply nunca pisa templates existentes con el mismo nombre y nunca reintenta una creación fallida (ante un fallo de red, re-ejecutar: el censo omite lo ya creado).

## Estructura del paquete

```text
talent-issue-craft/
├── SKILL.md                  ← punto de entrada: routing de 14 combinaciones + quick starts
├── references/01..04         ← doctrina (núcleo, verificaciones, Linear nativo, anti-patrones)
├── templates/00..09          ← núcleo canónico + 9 plantillas por tipo + perfil-de-repo.md (rellenar)
├── scripts/                  ← issue_craft_helper.ts (auditor/aprovisionador) + check_nucleo_parity.sh
└── examples/                 ← 3 issues gold rellenas (feat-db, fix, spike)
```

## Reglas de oro

1. El marcador `<!-- issue-craft:v1 type=… variant=… madurez=… -->` es la PRIMERA línea del body y la única autoridad de clasificación; las etiquetas del tracker son cross-check.
2. Cero decisiones abiertas sin régimen (sellada / diferida con dueño y default / no-se-decidirá): es el gate de despacho.
3. Un score alto no salva checks duros rotos: cualquier duro aplicable incumplido → exit ≠ 0.
4. Si se modifica el núcleo: canon + manifest + 9 plantillas en el MISMO cambio, y `bash scripts/check_nucleo_parity.sh` en verde.
