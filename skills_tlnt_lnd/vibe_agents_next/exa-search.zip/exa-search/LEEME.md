# exa-search 1.0.0

Skill para buscar con Exa, leer páginas, obtener extractos y respuestas con fuentes y ejecutar
Agent con presupuesto. Entrega Markdown y JSON con cobertura, coste y errores por URL.
Distingue texto literal de una fuente y respuestas generadas por modelos.

Requiere Python 3.9 o superior, internet al usar la API y una clave `EXA_API_KEY`.
No requiere paquetes adicionales. Durante su construcción no se ha llamado al proveedor:
Se incorporó el smoke real del 2026-10-15: smoke_real_20261015.json contiene capturas públicas normalizadas y saneadas. Los fixtures de contrato siguen siendo construidos.

Instala la carpeta completa en el directorio de skills de tu agente; por ejemplo
`~/.claude/skills/exa-search` o `~/.codex/skills/exa-search`. No basta con copiar `SKILL.md`.

```bash
python3 scripts/exa_helper.py salud
python3 scripts/exa_helper.py conectar exa
python3 scripts/exa_helper.py buscar "Publicaciones sobre recuperación de información híbrida" \
  --categoria publication --salida estudio --investigacion ejemplo --tope-total-usd 0.20 --json
python3 scripts/exa_helper.py citas --salida estudio --investigacion ejemplo
```

Para conectar, copia antes la clave al portapapeles. También se admite `--desde-fichero`.
No pegues claves en el chat ni en argumentos. `salud` no comprueba su validez por red:
no hay una sonda gratuita verificada. `salud --en-vivo` hace una búsqueda mínima de pago.

Una búsqueda `auto` con diez resultados y highlights tiene tarifa publicada de 0,007 USD;
reserva local de 0,0155 USD. Topes por defecto: 0,50 USD por llamada y 1,50 por investigación.
El gasto se liquida con `costDollars` cuando viene (estimación del proveedor, no factura).
Sin dato se usa tarifa o cota; una respuesta perdida se declara DESCONOCIDO, nunca gratis.
Usa el mismo directorio/ID al continuar. `saldo` muestra gasto local, no saldo remoto.

Agent es experimental y requiere `--permitir-contrato-sin-verificar`: falta confirmar el
campo de tarea. Monitors está deshabilitado porque no se confirmó un límite de recurrencia.
Los costes, parámetros, recetas y limitaciones están en las seis referencias enlazadas desde `SKILL.md`.
Windows está sin probar. Smoke real (15-oct-2026) y evals con y sin el skill (16-oct-2026) en `evals/resultados.md`; no se han validado en vivo todos los parámetros.

Las pruebas sin red se ejecutan en el entorno de verificación:
`cd scripts && python3 -m unittest -v test_exa_helper`.
