#!/usr/bin/env bash
# paridad.sh: comprueba que cada copia de buscadores_comun.py de los skills es idéntica al canónico y que su
# COMUN.sha256 declara el SHA-256 correcto. Sale con código distinto de 0 si algo no cuadra (falla cerrado).
#
#   bash paridad.sh [--esperar N] DIR_SKILLS [CANONICO]
#       Recorre DIR_SKILLS/*/scripts/buscadores_comun.py. Con --esperar N exige encontrar exactamente N copias.
#   bash paridad.sh --sha [CANONICO]
#       Imprime la línea que va en scripts/COMUN.sha256 de cada skill: «<sha256>  buscadores_comun.py».
#
# CANONICO es, por defecto, el buscadores_comun.py que está junto a este script.
# Códigos de salida: 0 todo cuadra · 1 hay diferencias, copias que faltan o declaraciones erróneas · 2 uso incorrecto.
set -u

uso() {
    sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//' >&2
    exit 2
}

sha_de() {
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$1" | awk '{print $1}'
    elif command -v shasum >/dev/null 2>&1; then
        shasum -a 256 "$1" | awk '{print $1}'
    else
        echo "No hay sha256sum ni shasum en esta máquina." >&2
        exit 2
    fi
}

esperar=""
modo="paridad"
while [ $# -gt 0 ]; do
    case "$1" in
        --esperar)
            [ $# -ge 2 ] || uso
            esperar="$2"
            shift 2
            ;;
        --sha)
            modo="sha"
            shift
            ;;
        -h | --help) uso ;;
        --)
            shift
            break
            ;;
        -*) uso ;;
        *) break ;;
    esac
done

aqui="$(cd "$(dirname "$0")" && pwd)"

if [ "$modo" = "sha" ]; then
    canon="${1:-$aqui/buscadores_comun.py}"
    [ -f "$canon" ] || { echo "No existe el canónico: $canon" >&2; exit 1; }
    echo "$(sha_de "$canon")  buscadores_comun.py"
    exit 0
fi

[ $# -ge 1 ] || uso
dir="$1"
canon="${2:-$aqui/buscadores_comun.py}"
[ -d "$dir" ] || { echo "No existe el directorio de skills: $dir" >&2; exit 2; }
[ -f "$canon" ] || { echo "No existe el canónico: $canon" >&2; exit 1; }
case "$esperar" in
    "" | *[!0-9]*) [ -z "$esperar" ] || uso ;;
esac

sha_canon="$(sha_de "$canon")"
fallos=0
total=0

# Enumerar cada nivel de forma explícita: find sin -L omite skills enlazados.
# Rechazamos enlaces, incluso en los antecesores del directorio raíz.
antecesor="$dir"
while [ "$antecesor" != "." ] && [ "$antecesor" != "/" ]; do
    if [ -L "$antecesor" ]; then
        echo "FALLA: enlace simbólico en $antecesor"
        exit 1
    fi
    antecesor="$(dirname "$antecesor")"
done
[ -r "$dir" ] && [ -x "$dir" ] || { echo "FALLA: no se puede enumerar $dir"; exit 1; }
copias=()
for carpeta in "$dir"/* "$dir"/.[!.]* "$dir"/..?*; do
    if [ -L "$carpeta" ] || [ -L "$carpeta/scripts" ]; then
        echo "FALLA: enlace simbólico en directorio de skill/scripts: $carpeta"
        fallos=$((fallos + 1))
        continue
    fi
    [ -d "$carpeta/scripts" ] || continue
    if [ ! -r "$carpeta/scripts" ] || [ ! -x "$carpeta/scripts" ]; then
        echo "FALLA: no se puede enumerar $carpeta/scripts"
        fallos=$((fallos + 1))
        continue
    fi
    copia="$carpeta/scripts/buscadores_comun.py"
    if [ -f "$copia" ] || [ -L "$copia" ]; then
        copias+=("$copia")
    fi
done
for copia in "${copias[@]}"; do

    [ -n "$copia" ] || continue
    total=$((total + 1))
    scripts="$(dirname "$copia")"
    skill="$(basename "$(dirname "$scripts")")"
    if [ -L "$copia" ]; then
        echo "FALLA $skill: la copia es un enlace simbólico, no una copia byte a byte"
        fallos=$((fallos + 1))
        continue
    fi
    if ! cmp -s "$canon" "$copia"; then
        echo "FALLA $skill: scripts/buscadores_comun.py difiere del canónico"
        fallos=$((fallos + 1))
        continue
    fi
    declarado_fichero="$scripts/COMUN.sha256"
    if [ ! -f "$declarado_fichero" ]; then
        echo "FALLA $skill: falta scripts/COMUN.sha256"
        fallos=$((fallos + 1))
        continue
    fi
    declarado="$(grep -Eo '[0-9A-Fa-f]{64}' "$declarado_fichero" | head -n 1 | tr 'A-F' 'a-f')"
    if [ -z "$declarado" ]; then
        echo "FALLA $skill: scripts/COMUN.sha256 no contiene un SHA-256"
        fallos=$((fallos + 1))
    elif [ "$declarado" != "$sha_canon" ]; then
        echo "FALLA $skill: scripts/COMUN.sha256 declara $declarado y el canónico es $sha_canon"
        fallos=$((fallos + 1))
    else
        echo "OK $skill $declarado"
    fi
done

if [ "$total" -eq 0 ]; then
    echo "FALLA: no hay ninguna copia scripts/buscadores_comun.py bajo $dir"
    exit 1
fi
if [ -n "$esperar" ] && [ "$total" -ne "$esperar" ]; then
    echo "FALLA: se esperaban $esperar copias y hay $total"
    fallos=$((fallos + 1))
fi
if [ "$fallos" -ne 0 ]; then
    echo "Paridad rota: $fallos problema(s) en $total copia(s)."
    exit 1
fi
echo "Paridad correcta: $total copia(s) idénticas al canónico ($sha_canon)."
exit 0
