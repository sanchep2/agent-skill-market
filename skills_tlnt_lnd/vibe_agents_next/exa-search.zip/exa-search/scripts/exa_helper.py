#!/usr/bin/env python3
"""exa-search: Exa completo (búsqueda, lectura, respuesta con fuentes y Agent) con coste informado, citas y modos acotados.

Python >= 3.9, solo biblioteca estándar. Usa el cliente común `buscadores_comun.py` (copia exacta, SHA-256 en
`COMUN.sha256`): libro de gasto único con reserva previa, trabajos asíncronos acotados, registro de salida que separa
texto literal de respuesta generada y salud sin gasto.

Subcomandos: salud · conectar · saldo · buscar · leer · responder · agente · vigilar (deshabilitado) · libro ·
pendientes · reanudar · citas. Cada uno que escribe exige --salida DIR (nunca escribe en el directorio actual).

Invariantes (cada una tiene su prueba en test_exa_helper.py):
  BUS-C1  se RESERVA la cota de cada llamada antes de lanzarla y se LIQUIDA con `costDollars` (estimación del proveedor), con la tarifa
          publicada (calculado) o con la cota (sin dato); una respuesta perdida es DESCONOCIDO, nunca 0.
  BUS-C2  el Agent solo se lanza con una cota que el proveedor cumple (precio fijo por petición o `budget.maxCostDollars`);
          el POST de creación sale UNA vez; un trabajo sin estado final queda `pendiente` con su reserva.
  BUS-C3  `texto_literal` solo lleva texto de una fuente (texto de página, highlights); `responder`, Agent, `summary` y
          `outputSchema` van en `respuesta_generada` con sus referencias aparte. Los fallos por URL salen visibles.
  BUS-C4  cada modo habilitado tiene su cota con fuente y fecha; sin sonda gratuita verificada, `salud` dice «clave
          presente, validez no comprobada» y termina sin error.
"""
from __future__ import annotations

import argparse
import contextlib
import io
import datetime as dt
import json
import re
import sys
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent))
import buscadores_comun as C  # noqa: E402

VERSION = "1.0.0"
NOMBRE = "exa-search"
API = "https://api.exa.ai"
IDENTIFICADOR = "exa-search"          # userIdentifier: atribuye el gasto a este skill (1-64 caracteres [A-Za-z0-9_-])

URL_PRECIOS = "https://exa.ai/docs/admin/pricing"
URL_ERRORES = "https://exa.ai/docs/admin/error-codes"
FECHA_FUENTES = "2026-10-15"          # fecha de lectura de la documentación oficial (Fase 0)

# ---------------------------------------------------------------------------------------------
# Tarifas publicadas (USD por petición, a partir de «USD por 1.000»). Fuente: URL_PRECIOS, leída el 2026-10-15.
# ---------------------------------------------------------------------------------------------
PRECIO_BUSQUEDA = {"instant": 0.004, "fast": 0.007, "auto": 0.007, "deep-lite": 0.012, "deep": 0.012,
                   "deep-reasoning": 0.015}
PRECIO_RESULTADO_EXTRA = 0.001        # cada resultado por encima de 10
PRECIO_RESUMEN = 0.001                # resúmenes de IA, por resultado
PRECIO_CONTENIDO = 0.001              # /contents: por página y por tipo de contenido
PRECIO_ANSWER = 0.005
PRECIO_AGENT_FIJO = {"minimal": 0.012, "low": 0.025, "medium": 0.10, "high": 0.50, "xhigh": 1.00}
AGENT_PRESUPUESTO_MIN, AGENT_PRESUPUESTO_MAX = 1.0, 100.0     # budget.maxCostDollars, solo en auto y ultra
AGENT_CAROS = ("high", "xhigh", "auto", "ultra")              # exigen --permitir-caro; sin prueba en vivo en v1

TIPOS = ("instant", "fast", "auto", "deep-lite", "deep", "deep-reasoning")
TIPOS_DEEP = ("deep-lite", "deep", "deep-reasoning")
CATEGORIAS = ("company", "publication", "news", "personal site", "financial report", "people")
CATEGORIAS_ES = {"empresa": "company", "empresas": "company", "publicacion": "publication", "publicación": "publication",
                 "noticias": "news", "noticia": "news", "sitio personal": "personal site",
                 "informe financiero": "financial report", "personas": "people", "persona": "people"}
CATEGORIAS_RETIRADAS = {"pdf": "deprecada el 23-jul-2026", "github": "deprecada el 23-jul-2026",
                        "tweet": "deprecada el 23-jul-2026",
                        "research paper": "sustituida por «publication»"}
SIN_FECHAS = ("company", "people")
MODELOS_ANSWER = ("exa", "exa-pro", "exa-research", "exa-fast")
ESFUERZOS = ("minimal", "low", "medium", "high", "xhigh", "auto", "ultra")
EXTRAS = {"enlaces": "links", "imagenes": "imageLinks", "codigo": "codeBlocks"}

MAX_DOMINIOS = 1200
MAX_CONSULTAS_EXTRA = 10

# Parámetros y rutas que NUNCA se envían (obsoletos, retirados o fuera de alcance). Fuente: Fase 0 §2, changelog de Exa.
PARAMETROS_PROHIBIDOS = frozenset((
    "livecrawl", "livecrawlTimeout", "numSentences", "highlightsPerUrl", "useAutoprompt", "startCrawlDate",
    "endCrawlDate", "crawledBeforeDate", "context", "includeText", "excludeText", "resolvedSearchType",
    "highlightScores", "includeUrls", "excludeUrls", "stream", "compliance", "snapshotAsOf"))
TIPOS_PROHIBIDOS = frozenset(("neural", "keyword"))
RUTAS_PERMITIDAS = ("/search", "/contents", "/answer", "/agent/runs")

# Campo de la tarea en POST /agent/runs: la Fase 0 NO lo documenta (NO VERIFICADO). Un único punto de cambio.
AGENT_CAMPO_TAREA = "query"

# Etiquetas de error de Exa (admin/error-codes) y qué hacer con cada una.
_TAGS = re.compile(r"\b(NO_MORE_CREDITS|API_KEY_BUDGET_EXCEEDED|TEAM_BUDGET_EXCEEDED|FEATURE_DISABLED|PROHIBITED_CONTENT|"
                   r"TEAM_BLOCKED|RATE_LIMIT_EXCEEDED|CONCURRENCY_LIMIT_REACHED|INVALID_REQUEST|INVALID_NUM_RESULTS|"
                   r"NUM_RESULTS_EXCEEDED|SUBPAGES_LIMIT_EXCEEDED)\b")
_EXPLICACION_402 = {
    "NO_MORE_CREDITS": "la cuenta de Exa se quedó sin créditos. El skill no compra créditos ni cambia de plan.",
    "API_KEY_BUDGET_EXCEEDED": "esta clave alcanzó su propio presupuesto (el límite que se le puso a la clave). "
                               "Súbelo en el panel de Exa o usa otra clave, si quien paga lo autoriza.",
    "TEAM_BUDGET_EXCEEDED": "el equipo alcanzó su presupuesto en Exa. Súbelo en el panel solo si quien paga lo autoriza."}
_EXPLICACION_403 = {
    "FEATURE_DISABLED": "esa función no está habilitada para esta cuenta o plan.",
    "PROHIBITED_CONTENT": "Exa bloqueó la consulta por contenido prohibido.",
    "TEAM_BLOCKED": "el equipo está bloqueado en Exa."}
_EXPLICACION_400 = {
    "INVALID_REQUEST": "opciones en conflicto o falta una cabecera beta; revisa las opciones que pasaste.",
    "INVALID_NUM_RESULTS": "numResults no es válido; usa un valor entre 1 y 100.",
    "NUM_RESULTS_EXCEEDED": "numResults supera el máximo de tu plan o del tipo de búsqueda; baja --n.",
    "SUBPAGES_LIMIT_EXCEEDED": "subpages supera el máximo permitido; baja --subpaginas."}

PROVEEDORES = {
    "exa": {
        "var": "EXA_API_KEY", "nombre": "Exa",
        "sin": "sin Exa no hay búsqueda, lectura de páginas, respuestas con fuentes ni Agent",
        "url_alta": "https://exa.ai/docs/", "unidad": "usd",
        "alternativa": "Mira el saldo en el panel de Exa y no repitas hasta resolverlo; el skill no compra créditos.",
        "pausa_min_s": 0.2,      # 10 QPS en /search y /answer, 5 QPS en deep* y /agent/runs (admin/billing, 2026-10-15)
        "sonda": "ninguna",      # sin sonda gratuita verificada en la Fase 0 (BUS-C4)
        "en_vivo": {"descripcion": "1 búsqueda `instant` con 1 resultado y sin contenidos (≈0,004 USD)",
                    "llamar": lambda ses: _en_vivo(ses)}}}
C.configurar(NOMBRE, PROVEEDORES)


# ---------------------------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------------------------
def _num(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and v == v and abs(v) != float("inf")


def _texto(v: Any) -> Optional[str]:
    return v if isinstance(v, str) and v.strip() else None


def _fecha(v: Any) -> Optional[str]:
    s = _texto(v)
    if s is None:
        return None
    s = s.strip()
    m = re.fullmatch(r"(\d{4}-\d{2}-\d{2})T00:00:00(?:\.0+)?(?:Z|\+00:00)?", s)
    return m.group(1) if m else s


def _dia_a_iso(texto: str, fin: bool = False) -> str:
    try:
        d = dt.datetime.strptime(texto.strip(), "%Y-%m-%d")
    except ValueError:
        raise C.ErrorDeConfiguracion(f"La fecha {texto!r} debe ser AAAA-MM-DD.") from None
    return d.strftime("%Y-%m-%d") + ("T23:59:59.999Z" if fin else "T00:00:00.000Z")


def _lista(valores: Optional[List[str]]) -> List[str]:
    """Acepta valores repetidos y separados por comas; sin duplicados, en orden."""
    out: List[str] = []
    for v in valores or []:
        for x in str(v).split(","):
            x = x.strip()
            if x and x not in out:
                out.append(x)
    return out


def _etiqueta(datos: Any) -> Optional[str]:
    try:
        txt = datos if isinstance(datos, str) else json.dumps(datos, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        return None
    m = _TAGS.search(txt or "")
    return m.group(1) if m else None


def verificar_cuerpo(ruta: str, cuerpo: Any) -> None:
    """Defensa en profundidad: ningún cuerpo sale con un parámetro obsoleto o retirado, ni a una ruta fuera de alcance."""
    if not any(ruta == r or ruta.startswith(r + "/") for r in RUTAS_PERMITIDAS):
        raise C.ErrorDeConfiguracion(f"Ruta fuera de alcance: {ruta} (v1 solo usa {', '.join(RUTAS_PERMITIDAS)}).")

    opacos = ("outputSchema", "schema", "properties", "items", "systemPrompt", "query")      # contenido del usuario

    def recorre(x: Any, camino: str) -> None:
        if isinstance(x, dict):
            for k, v in x.items():
                if k in PARAMETROS_PROHIBIDOS:
                    raise C.ErrorDeConfiguracion(f"Parámetro prohibido (obsoleto o retirado): {camino}{k}.")
                if k == "type" and isinstance(v, str) and v in TIPOS_PROHIBIDOS and camino == "":
                    raise C.ErrorDeConfiguracion(f"Tipo de búsqueda retirado: {v}.")
                if k not in opacos:
                    recorre(v, f"{camino}{k}.")
        elif isinstance(x, list):
            for v in x:
                recorre(v, camino)
    recorre(cuerpo, "")


# ---------------------------------------------------------------------------------------------
# Cuerpos de petición (exactos) y validación de lo que la documentación declara incompatible
# ---------------------------------------------------------------------------------------------
def _validar_dominios(valores: List[str], nombre: str) -> List[str]:
    if len(valores) > MAX_DOMINIOS:
        raise C.ErrorDeConfiguracion(f"{nombre}: hasta {MAX_DOMINIOS} entradas (hay {len(valores)}).")
    for d in valores:
        if d.lower().startswith("site:"):
            raise C.ErrorDeConfiguracion(f"{nombre}: «{d}» usa site:; Exa pide el dominio sin ese prefijo "
                                         "(host, host/ruta o *.host).")
        if "://" in d or " " in d:
            raise C.ErrorDeConfiguracion(f"{nombre}: «{d}» no es un host, un host con ruta ni un comodín *.host.")
    return valores


def validar_esquema(esquema: Any, estricto: bool = True) -> Dict[str, Any]:
    """outputSchema: raíz `text` u `object`; con `object`, como mucho 10 propiedades por objeto, 2 niveles de objetos y
    `items` en cada array (Fase 0 §1, lectura de `reference/search`). `estricto=False` solo comprueba la raíz."""
    if not isinstance(esquema, dict) or esquema.get("type") not in ("text", "object"):
        raise C.ErrorDeConfiguracion("outputSchema: la raíz debe ser un objeto con \"type\" «text» u «object».")
    if not estricto or esquema["type"] == "text":
        return esquema

    def recorre(nodo: Any, nivel: int) -> None:
        if not isinstance(nodo, dict):
            return
        if nodo.get("type") == "object":
            if nivel > 2:
                raise C.ErrorDeConfiguracion("outputSchema: más de 2 niveles de objetos.")
            props = nodo.get("properties") or {}
            if not isinstance(props, dict) or len(props) > 10:
                raise C.ErrorDeConfiguracion("outputSchema: como mucho 10 propiedades por objeto.")
            for sub in props.values():
                recorre(sub, nivel + 1)
        if nodo.get("type") == "array":
            if "items" not in nodo:
                raise C.ErrorDeConfiguracion("outputSchema: cada array necesita «items».")
            recorre(nodo["items"], nivel)
    recorre(esquema, 1)
    return esquema


def _contenidos(texto: Optional[int], highlights: Any, max_car: Optional[int], resumen: bool,
                resumen_consulta: Optional[str], edad: Optional[int], consulta_base: Optional[str],
                sin_contenidos: bool, por_defecto: bool) -> Dict[str, Any]:
    """El objeto de contenidos. `highlights`: None = no pedido, True = sin consulta propia, str = consulta propia."""
    if texto is not None and not 1 <= texto <= 1_000_000:
        raise C.ErrorDeConfiguracion("--texto: entre 1 y 1.000.000 caracteres.")
    if max_car is not None and not 1 <= max_car <= 1_000_000:
        raise C.ErrorDeConfiguracion("--max-car: entre 1 y 1.000.000 caracteres.")
    if edad is not None and not -1 <= edad <= 720:
        raise C.ErrorDeConfiguracion("--edad-max-horas: entre -1 y 720 (0 fuerza descarga nueva, -1 solo caché).")
    c: Dict[str, Any] = {}
    if sin_contenidos:
        if texto is not None or highlights is not None or resumen or edad is not None:
            raise C.ErrorDeConfiguracion("--sin-contenidos no se combina con --texto, --highlights, --resumen ni "
                                         "--edad-max-horas (esta última solo vale para contenidos).")
        return c
    if texto is not None:
        c["text"] = {"maxCharacters": texto}
    if highlights is not None or max_car is not None:
        h: Dict[str, Any] = {}
        if isinstance(highlights, str):
            h["query"] = highlights
        if max_car is not None:
            h["maxCharacters"] = max_car
        c["highlights"] = h if h else True
    if resumen:
        q = resumen_consulta or consulta_base
        if not q:
            raise C.ErrorDeConfiguracion("--resumen necesita una consulta (--resumen-consulta).")
        c["summary"] = {"query": q}
    if not c and por_defecto:
        c["highlights"] = True                     # recomendación de la documentación: empezar con highlights
    if edad is not None:
        c["maxAgeHours"] = edad
    return c


def cuerpo_busqueda(consulta: str, tipo: str = "auto", n: int = 10, categoria: Optional[str] = None,
                    dominios: Optional[List[str]] = None, excluir: Optional[List[str]] = None,
                    desde: Optional[str] = None, hasta: Optional[str] = None, texto: Optional[int] = None,
                    highlights: Any = None, max_car: Optional[int] = None, resumen: bool = False,
                    resumen_consulta: Optional[str] = None, edad_max_horas: Optional[int] = None,
                    consultas_extra: Optional[List[str]] = None, esquema: Optional[Dict[str, Any]] = None,
                    pais: Optional[str] = None, moderacion: bool = False, sin_contenidos: bool = False,
                    validar_el_esquema: bool = True) -> Dict[str, Any]:
    """El cuerpo EXACTO de POST /search. Valida lo que la documentación declara incompatible ANTES de gastar."""
    if not _texto(consulta):
        raise C.ErrorDeConfiguracion("Falta la consulta.")
    if tipo not in TIPOS:
        raise C.ErrorDeConfiguracion(f"--tipo: {', '.join(TIPOS)}.")
    if not isinstance(n, int) or isinstance(n, bool) or not 1 <= n <= 100:
        raise C.ErrorDeConfiguracion("--n: de 1 a 100 (el límite real depende del tipo y del plan).")
    cat = None
    if categoria:
        cat = CATEGORIAS_ES.get(categoria.strip().lower(), categoria.strip().lower())
        if cat in CATEGORIAS_RETIRADAS:
            raise C.ErrorDeConfiguracion(f"La categoría «{cat}» está {CATEGORIAS_RETIRADAS[cat]}: no se envía. "
                                         f"Categorías vigentes: {', '.join(CATEGORIAS)}.")
        if cat not in CATEGORIAS:
            raise C.ErrorDeConfiguracion(f"--categoria: {', '.join(CATEGORIAS)}.")
    inc = _validar_dominios(_lista(dominios), "--dominios")
    exc = _validar_dominios(_lista(excluir), "--excluir")
    if cat in SIN_FECHAS and (desde or hasta):
        raise C.ErrorDeConfiguracion(f"La categoría «{cat}» no admite fechas de publicación (Exa responde 400): "
                                     "quita --desde y --hasta o cambia de categoría.")
    if cat == "people" and exc:
        raise C.ErrorDeConfiguracion("La categoría «people» no admite --excluir (Exa responde 400).")
    extra = [e.strip() for e in (consultas_extra or []) if isinstance(e, str) and e.strip()]
    if extra:
        if tipo not in TIPOS_DEEP:
            raise C.ErrorDeConfiguracion(f"--consultas-extra solo vale con los tipos {', '.join(TIPOS_DEEP)} "
                                         f"(has pedido «{tipo}»).")
        if len(extra) > MAX_CONSULTAS_EXTRA:
            raise C.ErrorDeConfiguracion(f"--consultas-extra: de 1 a {MAX_CONSULTAS_EXTRA}.")
    if pais is not None and not re.fullmatch(r"[A-Za-z]{2}", pais.strip()):
        raise C.ErrorDeConfiguracion("--pais: código ISO de 2 letras (por ejemplo MX, ES, US).")
    cont = _contenidos(texto, highlights, max_car, resumen, resumen_consulta, edad_max_horas, consulta, sin_contenidos,
                       por_defecto=True)
    cuerpo: Dict[str, Any] = {"query": consulta, "type": tipo, "numResults": n, "userIdentifier": IDENTIFICADOR}
    if cat:
        cuerpo["category"] = cat
    if inc:
        cuerpo["includeDomains"] = inc
    if exc:
        cuerpo["excludeDomains"] = exc
    if desde:
        cuerpo["startPublishedDate"] = _dia_a_iso(desde)
    if hasta:
        cuerpo["endPublishedDate"] = _dia_a_iso(hasta, fin=True)
    if desde and hasta and cuerpo["startPublishedDate"][:10] > cuerpo["endPublishedDate"][:10]:
        raise C.ErrorDeConfiguracion("--desde es posterior a --hasta.")
    if extra:
        cuerpo["additionalQueries"] = extra
    if esquema is not None:
        cuerpo["outputSchema"] = validar_esquema(esquema, validar_el_esquema)
    if pais:
        cuerpo["userLocation"] = pais.strip().upper()
    if moderacion:
        cuerpo["moderation"] = True
    if cont:
        cuerpo["contents"] = cont
    verificar_cuerpo("/search", cuerpo)
    return cuerpo


def cuerpo_contenidos(urls: List[str], texto: Optional[int] = None, highlights: Any = None,
                      max_car: Optional[int] = None, resumen: bool = False, resumen_consulta: Optional[str] = None,
                      edad_max_horas: Optional[int] = None, subpaginas: Optional[int] = None,
                      objetivo_subpaginas: Optional[List[str]] = None, extras: Optional[List[str]] = None,
                      extras_n: int = 20) -> Dict[str, Any]:
    """El cuerpo EXACTO de POST /contents (1-100 URL)."""
    urls = [u.strip() for u in urls or [] if isinstance(u, str) and u.strip()]
    if not 1 <= len(urls) <= 100:
        raise C.ErrorDeConfiguracion("leer: de 1 a 100 URL por llamada.")
    for u in urls:
        if not re.match(r"https?://[^\s/]+", u, re.I):
            raise C.ErrorDeConfiguracion(f"No es una URL http(s): {u[:80]!r}.")
    if subpaginas is not None and not 0 <= subpaginas <= 100:
        raise C.ErrorDeConfiguracion("--subpaginas: de 0 a 100.")
    if objetivo_subpaginas and not subpaginas:
        raise C.ErrorDeConfiguracion("--objetivo-subpaginas necesita --subpaginas N (N >= 1).")
    cont = _contenidos(texto, highlights, max_car, resumen, resumen_consulta, edad_max_horas, None, False,
                       por_defecto=False)
    if resumen and not resumen_consulta:
        raise C.ErrorDeConfiguracion("--resumen necesita --resumen-consulta (qué quieres saber de cada página).")
    if not any(k in cont for k in ("text", "highlights", "summary")):
        cont["text"] = {"maxCharacters": 20000}
    cuerpo: Dict[str, Any] = {"urls": urls, "userIdentifier": IDENTIFICADOR}
    cuerpo.update(cont)
    if subpaginas:
        cuerpo["subpages"] = subpaginas
    sub_obj = _lista(objetivo_subpaginas)
    if sub_obj:
        cuerpo["subpageTarget"] = sub_obj[0] if len(sub_obj) == 1 else sub_obj
    ex = _lista(extras)
    if ex:
        malos = [e for e in ex if e not in EXTRAS]
        if malos:
            raise C.ErrorDeConfiguracion(f"--extras: {', '.join(EXTRAS)}.")
        if not 0 <= extras_n <= 1000:
            raise C.ErrorDeConfiguracion("--extras-n: de 0 a 1.000.")
        cuerpo["extras"] = {EXTRAS[e]: extras_n for e in ex}
    verificar_cuerpo("/contents", cuerpo)
    return cuerpo


def cuerpo_answer(consulta: str, modelo: Optional[str] = None, texto_citas: bool = False,
                  esquema: Optional[Dict[str, Any]] = None, pais: Optional[str] = None,
                  instrucciones: Optional[str] = None, validar_el_esquema: bool = True) -> Dict[str, Any]:
    """El cuerpo EXACTO de POST /answer (sin stream)."""
    if not _texto(consulta):
        raise C.ErrorDeConfiguracion("Falta la consulta.")
    if modelo is not None and modelo not in MODELOS_ANSWER:
        raise C.ErrorDeConfiguracion(f"--modelo: {', '.join(MODELOS_ANSWER)}.")
    if pais is not None and not re.fullmatch(r"[A-Za-z]{2}", pais.strip()):
        raise C.ErrorDeConfiguracion("--pais: código ISO de 2 letras (por ejemplo MX, ES, US).")
    cuerpo: Dict[str, Any] = {"query": consulta, "userIdentifier": IDENTIFICADOR}
    if modelo:
        cuerpo["model"] = modelo
    if texto_citas:
        cuerpo["text"] = True
    if instrucciones:
        cuerpo["systemPrompt"] = instrucciones
    if pais:
        cuerpo["userLocation"] = pais.strip().upper()
    if esquema is not None:
        cuerpo["outputSchema"] = validar_esquema(esquema, validar_el_esquema)
    verificar_cuerpo("/answer", cuerpo)
    return cuerpo


def cuerpo_agente(consulta: str, esfuerzo: str, presupuesto_usd: Optional[float] = None,
                  esquema: Optional[Dict[str, Any]] = None, instrucciones: Optional[str] = None,
                  validar_el_esquema: bool = True) -> Dict[str, Any]:
    """El cuerpo EXACTO de POST /agent/runs. `budget.maxCostDollars` solo existe en `auto` y `ultra` (1-100 USD)."""
    if not _texto(consulta):
        raise C.ErrorDeConfiguracion("Falta la tarea del agente.")
    if esfuerzo not in ESFUERZOS:
        raise C.ErrorDeConfiguracion(f"--esfuerzo: {', '.join(ESFUERZOS)}.")
    cuerpo: Dict[str, Any] = {AGENT_CAMPO_TAREA: consulta, "effort": esfuerzo}
    if esfuerzo in ("auto", "ultra"):
        if presupuesto_usd is None or not _num(presupuesto_usd) \
                or not AGENT_PRESUPUESTO_MIN <= presupuesto_usd <= AGENT_PRESUPUESTO_MAX:
            raise C.ModoDeshabilitado(f"El esfuerzo «{esfuerzo}» solo se lanza con --presupuesto-usd de "
                                      f"{AGENT_PRESUPUESTO_MIN:g} a {AGENT_PRESUPUESTO_MAX:g} USD "
                                      "(budget.maxCostDollars, la cota que Exa hace cumplir). Sin ella no se lanza.")
        cuerpo["budget"] = {"maxCostDollars": float(presupuesto_usd)}
    elif presupuesto_usd is not None:
        raise C.ErrorDeConfiguracion("--presupuesto-usd solo existe en auto y ultra; los demás esfuerzos tienen precio fijo.")
    if instrucciones:
        cuerpo["systemPrompt"] = instrucciones
    if esquema is not None:
        cuerpo["outputSchema"] = validar_esquema(esquema, validar_el_esquema)
    verificar_cuerpo("/agent/runs", cuerpo)
    return cuerpo


# ---------------------------------------------------------------------------------------------
# Coste: estimación (cota y tarifa calculada) y lectura de `costDollars`
# ---------------------------------------------------------------------------------------------
def _cota(precio: float, completo: bool) -> float:
    """Cota de reserva: un margen sobre el precio publicado (no es un precio; el coste liquidado prioriza el informado por Exa)."""
    return round(precio * 1.5 + 0.005, 6) if completo else round(precio * 3 + 0.02, 6)


def estimar_busqueda(cuerpo: Dict[str, Any]) -> Tuple[float, bool]:
    """(precio calculado con la tarifa publicada, ¿completo?). Incompleto = algún recargo NO VERIFICADO en la Fase 0
    (maxAgeHours=0, outputSchema, additionalQueries): sin `costDollars` se liquida la cota, no la tarifa."""
    n = cuerpo["numResults"]
    cont = cuerpo.get("contents") or {}
    tipos = sum(1 for k in ("text", "highlights", "summary") if k in cont)
    extra = max(0, n - 10)
    precio = PRECIO_BUSQUEDA[cuerpo["type"]] + extra * PRECIO_RESULTADO_EXTRA * (1 + tipos)
    if "summary" in cont:
        precio += n * PRECIO_RESUMEN
    completo = not (cont.get("maxAgeHours") == 0 or "outputSchema" in cuerpo or "additionalQueries" in cuerpo
                    or (extra > 0 and tipos > 0))
    return round(precio, 6), completo


def estimar_contenidos(cuerpo: Dict[str, Any]) -> Tuple[float, bool]:
    paginas = len(cuerpo["urls"]) * (1 + int(cuerpo.get("subpages") or 0))
    tipos = sum(1 for k in ("text", "highlights", "summary") if k in cuerpo)
    completo = not (cuerpo.get("maxAgeHours") == 0 or cuerpo.get("subpages") or cuerpo.get("extras"))
    return round(paginas * max(1, tipos) * PRECIO_CONTENIDO, 6), completo


def estimar_answer(cuerpo: Dict[str, Any]) -> Tuple[float, bool]:
    completo = "model" not in cuerpo and "outputSchema" not in cuerpo
    return PRECIO_ANSWER, completo


def tarifa(usd: float, descripcion: str) -> "C.Tarifa":
    return C.Tarifa(usd, URL_PRECIOS, FECHA_FUENTES, descripcion)


def coste_dollars(datos: Any) -> Optional[float]:
    """`costDollars.total` si el proveedor lo informa (es una estimación del proveedor, no una factura); si no, None."""
    if not isinstance(datos, dict):
        return None
    cd = datos.get("costDollars")
    if isinstance(cd, dict):
        t = cd.get("total")
        return float(t) if _num(t) and t >= 0 else None
    if _num(cd) and cd >= 0:
        return float(cd)
    return None


def coste_de_respuesta(datos: Any, calculado: Optional[float], completo: bool, descripcion: str) -> Optional["C.Coste"]:
    """Real (costDollars) > calculado (tarifa publicada, solo si no hay recargos sin verificar) > None (se liquida la cota)."""
    real = coste_dollars(datos)
    if real is not None:
        return C.Coste(usd=real, fuente="proveedor")
    if completo and calculado is not None:
        return tarifa(calculado, descripcion).coste()
    return None


# ---------------------------------------------------------------------------------------------
# Llamadas
# ---------------------------------------------------------------------------------------------
def _explicar(e: Exception, ultimo: Dict[str, Any], agente: bool = False) -> Exception:
    """Mensaje claro por etiqueta (402, 403 y 400 de Exa). Conserva la clase y el cortacircuitos de la sesión."""
    tag = _etiqueta(ultimo.get("datos"))
    if isinstance(e, C.LimiteAlcanzado) and getattr(e, "proveedor", None) == "exa" and ultimo.get("estado") == 402:
        expl = _EXPLICACION_402.get(tag or "", "sin crédito o presupuesto agotado (HTTP 402).")
        return C.LimiteAlcanzado("exa", f"Exa respondió 402{' ' + tag if tag else ''}: {expl} No se reintenta.",
                                 e.alternativa)
    if isinstance(e, C.LimiteAlcanzado) and ultimo.get("estado") == 429:
        t = tag or "RATE_LIMIT_EXCEEDED"
        return C.LimiteAlcanzado("exa", f"Exa respondió 429 {t}: demasiadas peticiones o ejecuciones a la vez (10 QPS en "
                                 "búsqueda y respuesta, 5 en deep* y Agent, por equipo). Se respetó Retry-After y no se "
                                 "reintenta más.", e.alternativa)
    if isinstance(e, C.ClaveRechazada) and ultimo.get("estado") == 403:
        expl = _EXPLICACION_403.get(tag or "", "acceso denegado (HTTP 403).")
        return C.ClaveRechazada("exa", f"Exa respondió 403{' ' + tag if tag else ''}: {expl} No se reintenta.")
    if isinstance(e, C.ErrorHttp) and not isinstance(e, C.ErrorDeUrl):
        expl = _EXPLICACION_400.get(tag or "")
        extra = f" {expl}" if expl else ""
        if agente and e.estado in (400, 404, 422):
            extra += (f" NOTA: el nombre del campo de la tarea del Agent ({AGENT_CAMPO_TAREA!r}) y las rutas de "
                      "sondeo/cancelación no están verificados en la Fase 0; compruébalos con la documentación del Agent.")
        return C.ErrorHttp("exa", e.estado, str(e) + extra, e.datos) if extra else e
    return e


def _llamar(ses: "C.Sesion", concepto: str, ruta: str, cuerpo: Dict[str, Any], cota: float,
            calculado: Optional[float], completo: bool, descripcion: str,
            reintentar: bool = True) -> "C.Respuesta":
    """Una llamada SÍNCRONA de pago (búsqueda, lectura, respuesta): reserva → llamar → liquidar."""
    verificar_cuerpo(ruta, cuerpo)
    ultimo: Dict[str, Any] = {}

    def hacer() -> Tuple[Any, ...]:
        est, dat, cab = C.http_con_cabeceras("POST", API + ruta, cuerpo, {"x-api-key": C.clave("exa")})
        ultimo["estado"], ultimo["datos"] = est, dat
        coste = coste_de_respuesta(dat, calculado, completo, descripcion) if 200 <= est < 300 else None
        ses.uso({"proveedor": "exa", "concepto": concepto, "ruta": ruta, "http": est,
                 "request_id": dat.get("requestId") if isinstance(dat, dict) else None,
                 "search_time": dat.get("searchTime") if isinstance(dat, dict) else None,
                 "costDollars": dat.get("costDollars") if isinstance(dat, dict) else None,
                 "limites": C.cabeceras_de_limite(cab),
                 "coste_usd": coste.usd if coste is not None and coste.usd is not None else None})
        return est, dat, coste, "ok", cab

    try:
        return ses.pagada("exa", concepto, cota, hacer, reintentar=reintentar and ruta in ("/search", "/contents"))
    except (C.LimiteAlcanzado, C.ClaveRechazada, C.ErrorHttp) as e:
        nuevo = _explicar(e, ultimo)
        if nuevo is not e and isinstance(nuevo, (C.LimiteAlcanzado, C.ClaveRechazada)):
            ses.parados["exa"] = (type(nuevo), str(nuevo), getattr(nuevo, "alternativa", "") or "")
        if nuevo is e:
            raise
        raise nuevo from None


def _coste_registro(ses: "C.Sesion", r: Optional["C.Respuesta"], datos: Any, n: int) -> Dict[str, Any]:
    if r is None:
        return {"usd": 0.0, "fuente": "cache", "request_id": (datos or {}).get("requestId") if isinstance(datos, dict) else None,
                "compartido_por_resultados": n}
    d = ses.coste_de_llamada("exa", r)
    d["request_id"] = datos.get("requestId") if isinstance(datos, dict) else None
    d["compartido_por_resultados"] = n
    return d


# ---------------------------------------------------------------------------------------------
# Normalización al registro común (BUS-C3)
# ---------------------------------------------------------------------------------------------
_ESQ_RES = {"id": True, "title": True, "url": True, "publishedDate": True, "author": True, "text": True,
            "highlights": [True], "summary": True}
ESQ_BUSQUEDA = {"requestId": True, "costDollars": {"total": True}, "results": [dict(_ESQ_RES, subpages=[dict(_ESQ_RES)])]}
ESQ_CONTENIDOS = {"requestId": True, "costDollars": {"total": True},
                  "results": [dict(_ESQ_RES, subpages=[dict(_ESQ_RES)])],
                  "statuses": [{"id": True, "url": True, "status": True, "source": True,
                                "error": {"tag": True, "httpStatusCode": True}}]}
ESQ_ANSWER = {"requestId": True, "costDollars": {"total": True}, "answer": True,
              "citations": [{"id": True, "url": True, "title": True, "publishedDate": True, "author": True,
                             "text": True}]}


def _cacheable(datos: Any) -> bool:
    """Solo se guarda en caché lo que `proyectar` conserva sin pérdida: nada de outputSchema ni highlights no textuales."""
    if not isinstance(datos, dict) or "output" in datos or (datos.get("answer") is not None and not isinstance(datos["answer"], str)):
        return False
    pendientes = list(datos.get("results") or [])
    while pendientes:
        r = pendientes.pop()
        if isinstance(r, dict):
            hl = r.get("highlights")
            if hl is not None and not (isinstance(hl, list) and all(isinstance(x, str) for x in hl)):
                return False
            if r.get("summary") is not None and not isinstance(r["summary"], str):
                return False
            if r.get("extras"):
                return False
            pendientes.extend(r.get("subpages") or [])
    return True


def _highlights(v: Any) -> List[str]:
    out = []
    for x in v if isinstance(v, list) else []:
        t = x if isinstance(x, str) else (x.get("text") if isinstance(x, dict) else None)
        if _texto(t):
            out.append(t)
    return out


def _texto_de_resultado(r: Dict[str, Any]) -> Tuple[Optional[str], List[str]]:
    """Texto atribuido a la fuente: el texto de la página si se pidió; si no, los highlights unidos por una línea en blanco."""
    t = r.get("text")
    if isinstance(t, str) and t.strip():
        return t, []
    hl = _highlights(r.get("highlights"))
    if hl:
        return "\n\n".join(hl), [f"extracto_de_highlights:{len(hl)}"]
    return None, []


def _refs_de(citas: Any) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for c in citas if isinstance(citas, list) else []:
        if isinstance(c, str) and c.strip():
            out.append({"url": c})
        elif isinstance(c, dict):
            u = c.get("url") or c.get("id")
            d = {k: v for k, v in (("url", u), ("titulo", c.get("title")), ("fecha", _fecha(c.get("publishedDate"))),
                                    ("autor", c.get("author"))) if v}
            if d:
                out.append(d)
    return out


def _contenido_generado(v: Any) -> Optional[str]:
    if v is None:
        return None
    if isinstance(v, str):
        return v if v.strip() else None
    return json.dumps(v, ensure_ascii=False, indent=1, default=str)


def _grounding(g: Any) -> Tuple[List[Dict[str, Any]], List[str]]:
    """(referencias, avisos de confianza) de output.grounding: campo, citas y confianza low/medium/high por campo."""
    refs: List[Dict[str, Any]] = []
    avisos: List[str] = []
    for item in g if isinstance(g, list) else []:
        if not isinstance(item, dict):
            continue
        campo = item.get("field") or item.get("path") or item.get("name")
        conf = item.get("confidence")
        citas = _refs_de(item.get("citations") or item.get("sources") or [])
        for c in citas:
            if campo:
                c["campo"] = str(campo)
            if conf:
                c["confianza"] = str(conf)
            refs.append(c)
        if conf:
            avisos.append(f"confianza:{campo or 'salida'}={conf}")
    return refs, avisos


def normalizar_busqueda(datos: Any, consulta: str, tipo: str, categoria: Optional[str], coste: Dict[str, Any],
                        consultado: Optional[str] = None) -> List[Dict[str, Any]]:
    """Una ficha por resultado (texto literal de la fuente; summary en respuesta_generada) y, si hubo outputSchema,
    una ficha aparte con la salida generada y su grounding."""
    modo = f"search:{tipo}" + (f":{categoria}" if categoria else "")
    out: List[Dict[str, Any]] = []
    res = datos.get("results") if isinstance(datos, dict) else None
    for r in res if isinstance(res, list) else []:
        if not isinstance(r, dict):
            continue
        out.extend(_ficha(r, consulta, modo, coste, consultado))
        for sp in r.get("subpages") if isinstance(r.get("subpages"), list) else []:
            if isinstance(sp, dict):
                out.extend(_ficha(sp, consulta, modo, coste, consultado, subpagina_de=r.get("url")))
    salida = datos.get("output") if isinstance(datos, dict) else None
    if isinstance(salida, dict) and salida.get("content") is not None:
        refs, av = _grounding(salida.get("grounding"))
        out.append(C.registro_respuesta(
            titulo="Salida estructurada (outputSchema)", respuesta_generada=_contenido_generado(salida["content"]),
            referencias=refs or None, motor="exa", modo=modo + ":outputSchema", consulta=consulta, coste=coste,
            consultado=consultado, avisos=av))
    return out


def _ficha(r: Dict[str, Any], consulta: Optional[str], modo: str, coste: Dict[str, Any], consultado: Optional[str],
           subpagina_de: Optional[str] = None) -> List[Dict[str, Any]]:
    tl, avisos = _texto_de_resultado(r)
    resumen = r.get("summary")
    url = _texto(r.get("url"))
    if subpagina_de:
        avisos = avisos + [f"subpagina_de:{subpagina_de}"]
    refs = [{"url": url, **({"titulo": r["title"]} if _texto(r.get("title")) else {})}] if url else None
    if isinstance(r.get("extras"), dict):
        avisos.append("extras:" + json.dumps(r["extras"], ensure_ascii=False, sort_keys=True))
    fecha = _fecha(r.get("publishedDate"))
    ficha = C.nuevo_registro(
        url=url, titulo=r.get("title"), texto_literal=tl,
        respuesta_generada=resumen if isinstance(resumen, str) else _contenido_generado(resumen),
        referencias=refs if resumen else None, fecha=fecha, fecha_fuente="proveedor" if fecha else None,
        autor=r.get("author"), motor="exa", modo=modo, consulta=consulta, coste=coste, consultado=consultado,
        avisos=avisos + (["resumen_generado_por_el_proveedor"] if resumen else []))
    return [ficha]


def _clave_url(u: Any) -> str:
    s = (u or "").strip() if isinstance(u, str) else ""
    return re.sub(r"#.*$", "", s)


def normalizar_contenidos(datos: Any, urls: List[str], coste: Dict[str, Any],
                          consultado: Optional[str] = None) -> List[Dict[str, Any]]:
    """Una ficha por URL pedida: texto literal si hay resultado; si no, un registro de error VISIBLE con el motivo de
    `statuses` (nunca se pierde en silencio). Las subpáginas van aparte."""
    estados: Dict[str, Dict[str, Any]] = {}
    for s in (datos.get("statuses") if isinstance(datos, dict) else None) or []:
        if isinstance(s, dict):
            estados[_clave_url(s.get("id") or s.get("url"))] = s
    resultados: Dict[str, Dict[str, Any]] = {}
    for r in (datos.get("results") if isinstance(datos, dict) else None) or []:
        if isinstance(r, dict):
            resultados.setdefault(_clave_url(r.get("url") or r.get("id")), r)
    out: List[Dict[str, Any]] = []
    vistas = set()
    for u in urls:
        k = _clave_url(u)
        vistas.add(k)
        st, r = estados.get(k), resultados.get(k)
        fuente = (st or {}).get("source")
        modo = "contents" + (f":{fuente}" if _texto(fuente) else "")
        if st and str(st.get("status", "")).lower() == "error" or (st and not r and str(st.get("status", "")).lower() != "success"):
            e = st.get("error") if isinstance(st.get("error"), dict) else {}
            motivo = str(e.get("tag") or st.get("status") or "error")
            if e.get("httpStatusCode") is not None:
                motivo += f" (HTTP {e['httpStatusCode']})"
            out.append(C.registro_error(url=u, error=motivo, motor="exa", modo=modo, coste=coste, consultado=consultado))
            continue
        if r is None:
            out.append(C.registro_error(url=u, error="Exa no devolvió ni contenido ni estado para esta URL",
                                        motor="exa", modo=modo, coste=coste, consultado=consultado))
            continue
        out.extend(_ficha(r, None, modo, coste, consultado))
        for sp in r.get("subpages") if isinstance(r.get("subpages"), list) else []:
            if isinstance(sp, dict):
                out.extend(_ficha(sp, None, modo + ":subpagina", coste, consultado, subpagina_de=r.get("url") or u))
    for k, r in resultados.items():            # resultados que no se pidieron por URL (redirecciones, subpáginas)
        if k not in vistas and not any(a.get("url") and _clave_url(a["url"]) == k for a in out):
            out.extend(_ficha(r, None, "contents", coste, consultado))
    # Conservar TODOS los errores recibidos, también URL adicionales y motivos
    # distintos para la misma URL; deduplicar únicamente URL + motivo.
    vistos_error = {(_clave_url(r.get('url')), r.get('error')) for r in out if r.get('error')}
    for st in (datos.get('statuses') if isinstance(datos, dict) else None) or []:
        if not isinstance(st, dict) or str(st.get('status', '')).lower() != 'error':
            continue
        u = st.get('id') or st.get('url')
        e = st.get('error') if isinstance(st.get('error'), dict) else {}
        motivo = str(e.get('tag') or st.get('status') or 'error')
        if e.get('httpStatusCode') is not None:
            motivo += f" (HTTP {e['httpStatusCode']})"
        clave = (_clave_url(u), motivo)
        if clave not in vistos_error:
            vistos_error.add(clave)
            out.append(C.registro_error(url=u, error=motivo, motor='exa', modo='contents',
                                        coste=coste, consultado=consultado))
    return out


def normalizar_answer(datos: Any, consulta: str, modelo: Optional[str], coste: Dict[str, Any],
                      consultado: Optional[str] = None) -> List[Dict[str, Any]]:
    """La respuesta generada va en `respuesta_generada` y sus citas en `referencias` (nunca como cita literal). Si viene
    texto atribuido en las citas, cada una es además una ficha de extracto con su texto literal."""
    d = datos if isinstance(datos, dict) else {}
    citas = d.get("citations") if isinstance(d.get("citations"), list) else []
    out = [C.registro_respuesta(
        titulo="Respuesta de Exa", respuesta_generada=_contenido_generado(d.get("answer")),
        referencias=_refs_de(citas) or None, motor="exa", modo=f"answer:{modelo or 'predeterminado'}",
        consulta=consulta, coste=coste, consultado=consultado, avisos=["respuesta_generada_por_el_proveedor"])]
    for c in citas:
        if isinstance(c, dict) and _texto(c.get("text")):
            out.append(C.registro_extracto(
                url=_texto(c.get("url")), titulo=c.get("title"), texto_literal=c["text"],
                fecha=_fecha(c.get("publishedDate")), fecha_fuente="proveedor" if _fecha(c.get("publishedDate")) else None,
                autor=c.get("author"), motor="exa", modo="answer:cita", consulta=consulta, coste=coste,
                consultado=consultado))
    return out


def normalizar_agente(datos: Any, consulta: str, esfuerzo: str, coste: Dict[str, Any],
                      consultado: Optional[str] = None) -> List[Dict[str, Any]]:
    d = datos if isinstance(datos, dict) else {}
    estado = str(d.get("status") or "").lower()
    modo = f"agent:{esfuerzo}"
    if estado != "completed":
        detalle = d.get("error")
        det = (" — " + (detalle if isinstance(detalle, str) else json.dumps(detalle, ensure_ascii=False, default=str)[:200])) \
            if detalle else ""
        return [C.registro_error(url=None, error=f"El run del Agent terminó en estado «{estado or 'desconocido'}»{det}",
                                 motor="exa", modo=modo, consulta=consulta, coste=coste, consultado=consultado)]
    sal = d.get("output") if isinstance(d.get("output"), dict) else {}
    refs, av = _grounding(sal.get("grounding"))
    out = []
    if _texto(sal.get("text")):
        out.append(C.registro_respuesta(titulo="Resultado del Agent", respuesta_generada=sal["text"],
                                        referencias=refs or None, motor="exa", modo=modo, consulta=consulta,
                                        coste=coste, consultado=consultado, avisos=av))
    if sal.get("structured") is not None:
        out.append(C.registro_respuesta(titulo="Resultado estructurado del Agent",
                                        respuesta_generada=_contenido_generado(sal["structured"]),
                                        referencias=refs or None, motor="exa", modo=modo + ":estructurado",
                                        consulta=consulta, coste=coste, consultado=consultado, avisos=av))
    if not out:
        out.append(C.registro_error(url=None, error="El run del Agent terminó sin salida (output vacío)", motor="exa",
                                    modo=modo, consulta=consulta, coste=coste, consultado=consultado))
    return out


# ---------------------------------------------------------------------------------------------
# Operaciones (con caché del día para buscar, leer y responder)
# ---------------------------------------------------------------------------------------------
def _con_cache(ses: "C.Sesion", cuerpo: Dict[str, Any], esquema: Any, edad: Any) -> Optional[Any]:
    if edad is not None or "outputSchema" in cuerpo or "extras" in cuerpo:           # el usuario pidió frescura, o la salida no se proyecta
        return None
    return ses.cache_leer("exa", cuerpo)


def _comprobar_recargos(ses: "C.Sesion", contenidos: Dict[str, Any], permitir: bool) -> None:
    if contenidos.get("maxAgeHours") == 0:
        if not permitir:
            raise C.ModoDeshabilitado("maxAgeHours=0: recargo NO VERIFICADO en la Fase 0. "
                                      "Solo con --permitir-recargos; sin probar en vivo.")
        ses.cobertura["avisos"].append("maxAgeHours=0: recargo NO VERIFICADO; sin probar en vivo; "
                                       "la reserva local es una estimación, no un límite impuesto por Exa")


def buscar(ses: "C.Sesion", consulta: str, permitir_recargos: bool = False, **opciones: Any) -> List[Dict[str, Any]]:
    cuerpo = cuerpo_busqueda(consulta, **opciones)
    _comprobar_recargos(ses, cuerpo.get("contents") or {}, permitir_recargos)
    precio, completo = estimar_busqueda(cuerpo)
    cota = _cota(precio, completo)
    edad = (cuerpo.get("contents") or {}).get("maxAgeHours")
    hit = _con_cache(ses, cuerpo, ESQ_BUSQUEDA, edad)
    if isinstance(hit, dict):
        ses.cobertura["avisos"].append("resultado de la caché del día: sin gasto nuevo")
        return normalizar_busqueda(hit, consulta, cuerpo["type"], cuerpo.get("category"),
                                   _coste_registro(ses, None, hit, len(hit.get("results") or [])))
    r = _llamar(ses, f"search:{cuerpo['type']}:{consulta[:60]}", "/search", cuerpo, cota, precio, completo,
                f"búsqueda {cuerpo['type']} con {cuerpo['numResults']} resultados")
    if edad is None and _cacheable(r.datos):
        ses.cache_guardar("exa", cuerpo, r.datos, ESQ_BUSQUEDA)
    n = len((r.datos or {}).get("results") or []) if isinstance(r.datos, dict) else 0
    return normalizar_busqueda(r.datos, consulta, cuerpo["type"], cuerpo.get("category"),
                               _coste_registro(ses, r, r.datos, n))


def leer(ses: "C.Sesion", urls: List[str], permitir_recargos: bool = False, **opciones: Any) -> List[Dict[str, Any]]:
    cuerpo = cuerpo_contenidos(urls, **opciones)
    _comprobar_recargos(ses, cuerpo, permitir_recargos)
    precio, completo = estimar_contenidos(cuerpo)
    cota = _cota(precio, completo)
    hit = _con_cache(ses, cuerpo, ESQ_CONTENIDOS, cuerpo.get("maxAgeHours"))
    if isinstance(hit, dict):
        ses.cobertura["avisos"].append("resultado de la caché del día: sin gasto nuevo")
        return normalizar_contenidos(hit, cuerpo["urls"], _coste_registro(ses, None, hit, len(cuerpo["urls"])))
    r = _llamar(ses, f"contents:{len(cuerpo['urls'])}", "/contents", cuerpo, cota, precio, completo,
                f"/contents de {len(cuerpo['urls'])} URL")
    if cuerpo.get("maxAgeHours") is None and "extras" not in cuerpo and _cacheable(r.datos):
        ses.cache_guardar("exa", cuerpo, r.datos, ESQ_CONTENIDOS)
    return normalizar_contenidos(r.datos, cuerpo["urls"], _coste_registro(ses, r, r.datos, len(cuerpo["urls"])))


def responder(ses: "C.Sesion", consulta: str, **opciones: Any) -> List[Dict[str, Any]]:
    cuerpo = cuerpo_answer(consulta, **opciones)
    precio, completo = estimar_answer(cuerpo)
    cota = _cota(precio, completo)
    hit = _con_cache(ses, cuerpo, ESQ_ANSWER, None)
    if isinstance(hit, dict):
        ses.cobertura["avisos"].append("resultado de la caché del día: sin gasto nuevo")
        return normalizar_answer(hit, consulta, cuerpo.get("model"), _coste_registro(ses, None, hit, 1))
    r = _llamar(ses, f"answer:{consulta[:60]}", "/answer", cuerpo, cota, precio, completo, "/answer")
    if _cacheable(r.datos):
        ses.cache_guardar("exa", cuerpo, r.datos, ESQ_ANSWER)
    return normalizar_answer(r.datos, consulta, cuerpo.get("model"), _coste_registro(ses, r, r.datos, 1))


# -- Agent (BUS-C2) ---------------------------------------------------------------------------
def _ruta_run(tid: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", tid):
        raise C.ErrorBuscadores("El id del run del Agent tiene caracteres no válidos.")
    return f"{API}/agent/runs/{tid}"


def _consultar_run(tid: str) -> Tuple[Any, ...]:
    estado, datos, cab = C.http_tras_envio_con_cabeceras("GET", _ruta_run(tid), None, {"x-api-key": C.clave("exa")})
    # consultar usa el contrato de cinco valores de Sesion, no el triple HTTP crudo.
    return estado, datos, None, "ok", cab


def _cancelar_run(tid: str) -> Any:
    return C.http_tras_envio_con_cabeceras("POST", _ruta_run(tid) + "/cancel", None, {"x-api-key": C.clave("exa")})


def _terminal_run(datos: Any) -> Any:
    estado = str(datos.get("status") or "").lower() if isinstance(datos, dict) else ""
    return estado if estado in ("completed", "failed", "cancelled", "canceled") else None


def _coste_final_run(datos: Any) -> Optional["C.Coste"]:
    real = coste_dollars(datos)
    return C.Coste(usd=real, fuente="proveedor") if real is not None else None


C.registrar_manejador("exa", _consultar_run, _terminal_run, _coste_final_run, _cancelar_run)


def cota_agente(esfuerzo: str, presupuesto_usd: Optional[float]) -> Tuple[float, str]:
    """(cota en USD, de dónde sale): el precio fijo por petición o budget.maxCostDollars. Ambos los hace cumplir Exa."""
    if esfuerzo in ("auto", "ultra"):
        return float(presupuesto_usd), "budget.maxCostDollars del Agent (1-100 USD, solo auto y ultra)"
    return PRECIO_AGENT_FIJO[esfuerzo], f"precio fijo por petición de effort={esfuerzo} ({URL_PRECIOS}, {FECHA_FUENTES})"


def agente(ses: "C.Sesion", consulta: str, esfuerzo: str, presupuesto_usd: Optional[float] = None,
           esquema: Optional[Dict[str, Any]] = None, instrucciones: Optional[str] = None, espera_s: float = 300.0,
           cancelar_al_agotar: bool = False, permitir_caro: bool = False,
           validar_el_esquema: bool = True, permitir_contrato_sin_verificar: bool = False) -> Tuple["C.ResultadoTrabajo", List[Dict[str, Any]]]:
    if esfuerzo in AGENT_CAROS and not permitir_caro:
        raise C.ModoDeshabilitado(f"El esfuerzo «{esfuerzo}» es caro y no está probado en vivo en esta versión: solo con "
                                  "--permitir-caro y un --tope-usd que cubra su cota.")
    if not permitir_contrato_sin_verificar:
        raise C.ModoDeshabilitado("Agent: el campo de tarea no se confirma en la Fase 0; hipótesis query, "
                                  "sin probar en vivo. Solo con --permitir-contrato-sin-verificar.")
    if not _num(espera_s) or espera_s < 0:
        raise C.ErrorDeConfiguracion("--espera-s debe ser finito y mayor o igual a 0.")
    ses.cobertura["avisos"].append("Agent: contrato de tarea query NO VERIFICADO; sin probar en vivo en todos los esfuerzos")
    cuerpo = cuerpo_agente(consulta, esfuerzo, presupuesto_usd, esquema, instrucciones, validar_el_esquema)
    cota, fuente = cota_agente(esfuerzo, presupuesto_usd)
    ultimo: Dict[str, Any] = {}

    def crear() -> Tuple[Any, ...]:
        est, dat, cab = C.http_con_cabeceras("POST", API + "/agent/runs", cuerpo, {"x-api-key": C.clave("exa")})
        ultimo["estado"], ultimo["datos"] = est, dat
        return est, dat, None, "ok", cab

    def coste_final(datos: Any) -> Optional["C.Coste"]:
        real = coste_dollars(datos)
        if real is not None:
            return C.Coste(usd=real, fuente="proveedor")
        if esfuerzo in PRECIO_AGENT_FIJO and _terminal_run(datos) == "completed":
            return tarifa(PRECIO_AGENT_FIJO[esfuerzo], f"Agent effort={esfuerzo}, precio fijo por petición").coste()
        return None

    try:
        res = ses.trabajo("exa", f"agent:{esfuerzo}:{consulta[:60]}", cota, 0.0, crear, _consultar_run, _cancelar_run,
                          _terminal_run, coste_final, espera_s, fuente_cota=fuente, pausa_s=3.0,
                          cancelar_al_agotar=cancelar_al_agotar)
    except (C.LimiteAlcanzado, C.ClaveRechazada, C.ErrorHttp) as e:
        nuevo = _explicar(e, ultimo, agente=True)
        if nuevo is e:
            raise
        if isinstance(nuevo, (C.LimiteAlcanzado, C.ClaveRechazada)):
            ses.parados["exa"] = (type(nuevo), str(nuevo), getattr(nuevo, "alternativa", "") or "")
        raise nuevo from None
    return res, registros_de_trabajo(ses, res, consulta, esfuerzo)


def registros_de_trabajo(ses: "C.Sesion", res: "C.ResultadoTrabajo", consulta: str, esfuerzo: str) -> List[Dict[str, Any]]:
    if res.pendiente:
        return []
    coste = {"usd": res.coste_usd, "fuente": res.fuente_coste, "compartido_por_resultados": 1,
             "request_id": res.datos.get("id") if isinstance(res.datos, dict) else None}
    return normalizar_agente(res.datos, consulta, esfuerzo, coste)


# ---------------------------------------------------------------------------------------------
# Salida para personas
# ---------------------------------------------------------------------------------------------
def _una_linea(s: Any, n: int = 240) -> str:
    t = re.sub(r"\s+", " ", C.limpiar_control(C.redactar(str(s if s is not None else "")))).strip()
    return t if len(t) <= n else t[: n - 1] + "…"


def imprimir_registros(regs: List[Dict[str, Any]]) -> None:
    """Resumen legible. El contenido de las fuentes es DATO, no instrucciones."""
    for i, r in enumerate(regs, 1):
        if r.get("error"):
            print(f"{i}. FALLO · {_una_linea(r.get('url') or 'sin URL')} · {_una_linea(r['error'])}")
            continue
        cab = " · ".join(x for x in (_una_linea(r.get("titulo") or r.get("url") or "sin título", 100),
                                     _una_linea(r.get("autor")), _una_linea(r.get("fecha")), _una_linea(r.get("url"))) if x)
        print(f"{i}. {cab}")
        if r.get("texto_literal"):
            print("   texto literal de la fuente: " + _una_linea(r["texto_literal"]))
        if r.get("respuesta_generada"):
            print("   RESPUESTA GENERADA (no es texto de una fuente): " + _una_linea(r["respuesta_generada"], 400))
            for ref in (r.get("referencias") or [])[:5]:
                print("   referencia: " + _una_linea(ref.get("url") or ref.get("titulo"), 160))
        if r.get("avisos"):
            print("   avisos: " + _una_linea(", ".join(r["avisos"])))


def _cierre(ses: "C.Sesion", regs: List[Dict[str, Any]], titulo: str, consulta: Optional[str], a: argparse.Namespace) -> int:
    regs = C.redactar_datos(regs)
    e = C.entrega_de_sesion(ses, regs, titulo, consulta)
    if ses.salida is not None:
        for r in regs:
            ses.registrar(r)
        pm, pj = C.guardar_entrega(ses.exigir_salida(), e)
    if getattr(a, "json", False):
        print(json.dumps(e, ensure_ascii=False, indent=1, default=str))
        return C.SALIDA_DESCONOCIDO if e["coste"]["desconocido"] else C.SALIDA_OK
    imprimir_registros(regs)
    utiles = sum(1 for r in regs if not r.get("error"))
    this = ses.cobertura["coste_usd"]
    por = f" ({this / utiles:.4f} USD por resultado útil)" if utiles and this else ""
    print(f"\n{utiles} resultado(s) útil(es), {len(regs) - utiles} fallo(s) por URL.")
    print(f"Coste de esta ejecución: {this:.4f} USD{por}. Coste de la investigación: {e['coste']['texto']}.")
    for p in C.redactar_datos(ses.cobertura["paradas"]):
        print(f"PARADA {p['proveedor']}: {p['motivo']}")
    for av in C.redactar_datos(ses.cobertura["avisos"]):
        print("AVISO: " + av)
    lim = C.redactar_datos(ses.limites.get("exa"))
    if lim:
        print("Límites de Exa: " + ", ".join(f"{k}={v}" for k, v in sorted(lim.items())))
    if ses.salida is not None:
        print(f"Guardado: {C.mostrar_ruta(pm)} y {C.mostrar_ruta(pj)}")
    else:
        print("(sin --salida: no se ha escrito ningún fichero de resultados)")
    return C.SALIDA_DESCONOCIDO if e["coste"]["desconocido"] else C.SALIDA_OK


# ---------------------------------------------------------------------------------------------
# Salud en vivo, saldo y subcomandos
# ---------------------------------------------------------------------------------------------
def _en_vivo(ses: "C.Sesion") -> str:
    cuerpo = cuerpo_busqueda("exa", tipo="instant", n=1, sin_contenidos=True)
    precio, completo = estimar_busqueda(cuerpo)
    r = _llamar(ses, "salud:en-vivo", "/search", cuerpo, _cota(precio, completo), precio, completo, "búsqueda instant", reintentar=False)
    n = len((r.datos or {}).get("results") or []) if isinstance(r.datos, dict) else 0
    return f"{n} resultado(s); coste {r.coste_usd:.4f} USD ({r.fuente_coste})"


def _sesion(a: argparse.Namespace) -> "C.Sesion":
    if getattr(a, "salida", None) is None and not getattr(a, "investigacion", None):
        a.investigacion = "sueltas-" + dt.datetime.now().strftime("%Y%m%d")      # sin --salida: un tope por día
    return C.sesion_de_args(a)


def _leer_esquema(ruta: Optional[Path]) -> Optional[Dict[str, Any]]:
    if ruta is None:
        return None
    try:
        return json.loads(Path(ruta).read_text(encoding="utf-8"))
    except OSError as e:
        raise C.ErrorDeConfiguracion(f"No se pudo leer el esquema: {e.strerror or e}") from None
    except ValueError:
        raise C.ErrorDeConfiguracion("El fichero del esquema no es un JSON válido.") from None


def _leer_urls(a: argparse.Namespace) -> List[str]:
    urls = list(a.urls or [])
    if a.urls_fichero:
        try:
            for linea in Path(a.urls_fichero).read_text(encoding="utf-8").splitlines():
                linea = linea.strip()
                if linea and not linea.startswith("#"):
                    urls.append(linea)
        except OSError as e:
            raise C.ErrorDeConfiguracion(f"No se pudo leer el fichero de URL: {e.strerror or e}") from None
    return urls


def cmd_saldo(a: argparse.Namespace) -> int:
    mes = dt.datetime.now().strftime("%Y-%m")
    gasto = C.Libro().total_mes(mes).get("exa", {"usd": 0.0, "creditos": 0.0})
    info = {"consulta_de_saldo_en_la_api": False,
            "motivo": "la Fase 0 no verificó ningún endpoint gratuito de saldo en Exa; mira el panel del proveedor",
            "plan_gratis": "10 USD al mes (se reponen el día 1, no se acumulan) + 10 USD únicos al completar el onboarding "
                           f"(fuente {URL_PRECIOS}, {FECHA_FUENTES})",
            "gasto_liquidado_este_mes_en_el_libro_usd": round(gasto["usd"], 6), "mes": mes}
    if getattr(a, "json", False):
        print(json.dumps(info, ensure_ascii=False, indent=1))
    else:
        print("Exa no ofrece (verificado) una consulta de saldo por API sin gasto: mira el saldo en el panel del proveedor.")
        print(f"Plan gratis según su documentación: {info['plan_gratis']}.")
        print(f"Gasto liquidado en el libro de este skill en {mes}: {gasto['usd']:.4f} USD "
              "(solo lo que pasó por este skill; el saldo real es el del panel).")
    return C.SALIDA_OK


def cmd_buscar(a: argparse.Namespace) -> int:
    ses = _sesion(a)
    hl = a.highlights if a.highlights is not None else None
    regs = buscar(ses, a.consulta, tipo=a.tipo, n=a.n, categoria=a.categoria, dominios=a.dominios, excluir=a.excluir,
                  desde=a.desde, hasta=a.hasta, texto=a.texto, highlights=(True if hl is True else hl), max_car=a.max_car,
                  resumen=a.resumen, resumen_consulta=a.resumen_consulta, edad_max_horas=a.edad_max_horas,
                  consultas_extra=a.consultas_extra, esquema=_leer_esquema(a.esquema), pais=a.pais,
                  moderacion=a.moderacion, sin_contenidos=a.sin_contenidos, permitir_recargos=a.permitir_recargos,
                  validar_el_esquema=not a.sin_validar_esquema)
    return _cierre(ses, regs, "Búsqueda en Exa", a.consulta, a)


def cmd_leer(a: argparse.Namespace) -> int:
    ses = _sesion(a)
    hl = a.highlights if a.highlights is not None else None
    regs = leer(ses, _leer_urls(a), texto=a.texto, highlights=hl, max_car=a.max_car, resumen=a.resumen,
                resumen_consulta=a.resumen_consulta, edad_max_horas=a.edad_max_horas, subpaginas=a.subpaginas,
                objetivo_subpaginas=a.objetivo_subpaginas, extras=a.extras, extras_n=a.extras_n, permitir_recargos=a.permitir_recargos)
    return _cierre(ses, regs, "Lectura de páginas con Exa", None, a)


def cmd_responder(a: argparse.Namespace) -> int:
    ses = _sesion(a)
    regs = responder(ses, a.consulta, modelo=a.modelo, texto_citas=a.texto_citas, esquema=_leer_esquema(a.esquema),
                     pais=a.pais, instrucciones=a.instrucciones, validar_el_esquema=not a.sin_validar_esquema)
    return _cierre(ses, regs, "Respuesta de Exa", a.consulta, a)


def cmd_agente(a: argparse.Namespace) -> int:
    ses = _sesion(a)
    ses.cobertura["avisos"].append("Agent: todos los esfuerzos sin probar en vivo; contrato experimental")
    res, regs = agente(ses, a.consulta, a.esfuerzo, a.presupuesto_usd, _leer_esquema(a.esquema), a.instrucciones,
                       a.espera_s, a.cancelar_al_agotar, a.permitir_caro, not a.sin_validar_esquema, a.permitir_contrato_sin_verificar)
    if res.pendiente:
        if not getattr(a, "json", False):
            print(f"El run {C.redactar(str(res.trabajo_id))} sigue vivo (estado {C.redactar(str(res.estado))}); su reserva se conserva en el libro y NO se "
                  f"repite el POST. Míralo con `pendientes` y ciérralo con `reanudar {res.id_reserva}`.")
        else:
            print(json.dumps(C.redactar_datos({"pendiente": True, "trabajo_id": res.trabajo_id, "id_reserva": res.id_reserva,
                              "estado": C.redactar(str(res.estado))}), ensure_ascii=False))
        return res.codigo_salida
    codigo = _cierre(ses, regs, "Agent de Exa", a.consulta, a)
    return C.SALIDA_ERROR if regs and all(r.get("error") for r in regs) else codigo


def cmd_reanudar(a: argparse.Namespace) -> int:
    """Como el `reanudar` común, pero además NORMALIZA y guarda el resultado del Agent si ya terminó."""
    ses = _sesion(a)
    r = C.Libro().reserva(a.id)
    if r is None:
        raise C.ErrorBuscadores(f"No existe la reserva {a.id}. Míralas con `pendientes`.")
    ses.investigacion = r["investigacion"]
    if r.get("proveedor") != "exa" or not str(r.get("concepto", "")).startswith("agent:"):
        raise C.ErrorDeConfiguracion("La reserva no corresponde a un trabajo Agent de Exa.")
    if getattr(a, "cancelar", False):
        res = ses.cancelar_pendiente(a.id, _consultar_run, _cancelar_run, _terminal_run, _coste_final_run)
    else:
        res = ses.reanudar(a.id, _consultar_run, _terminal_run, _coste_final_run, _cancelar_run)
    if res.pendiente:
        if getattr(a, "json", False):
            print(json.dumps(C.redactar_datos({"pendiente": True, "trabajo_id": res.trabajo_id,
                              "id_reserva": res.id_reserva, "estado": C.redactar(str(res.estado))})))
        else:
            print(f"El run {C.redactar(str(res.trabajo_id))} sigue vivo (estado {C.redactar(str(res.estado))}); su reserva se conserva.")
        return res.codigo_salida
    if not getattr(a, "json", False):
        print(f"El run {C.redactar(str(res.trabajo_id))} terminó ({C.redactar(str(res.estado))}); liquidado: {res.coste_usd:.4f} USD (fuente {res.fuente_coste}).")
    concepto = str(r.get("concepto") or "")
    m = re.match(r"agent:([a-z]+):(.*)", concepto)
    regs = registros_de_trabajo(ses, res, m.group(2) if m else concepto, m.group(1) if m else "desconocido")
    codigo = _cierre(ses, regs, "Agent de Exa (reanudado)", None, a)
    return C.SALIDA_ERROR if regs and all(r.get("error") for r in regs) else codigo


def cmd_vigilar(a: argparse.Namespace) -> int:
    raise C.ModoDeshabilitado(
        "`vigilar` (Monitors) está deshabilitado en esta versión: la Fase 0 no confirma que un monitor se pueda consultar "
        "sin webhook ni que tenga un límite de ejecuciones recurrentes (intervalo mínimo de 1 hora, 15 USD por 1.000 "
        "ejecuciones, sin tope por monitor documentado), y sin esa cota BUS-C2 impide lanzarlo. Mira "
        "references/costes-y-limites.md.")


def _rango(minimo: int, maximo: int) -> Callable[[str], int]:
    def f(texto: str) -> int:
        try:
            v = int(texto)
        except ValueError:
            raise argparse.ArgumentTypeError(f"{texto!r} no es un entero") from None
        if not minimo <= v <= maximo:
            raise argparse.ArgumentTypeError(f"{texto!r}: debe estar entre {minimo} y {maximo}")
        return v
    return f


def _opciones_contenido(p: argparse.ArgumentParser) -> None:
    p.add_argument("--permitir-recargos", action="store_true", help="permite maxAgeHours=0, recargo sin verificar en vivo")
    p.add_argument("--highlights", nargs="?", const=True, default=None, metavar="CONSULTA",
                   help="extractos relevantes de cada página (con una consulta propia si se da)")
    p.add_argument("--max-car", type=_rango(1, 1_000_000), default=None, help="máximo de caracteres por highlight")
    p.add_argument("--resumen", action="store_true", help="resumen generado por Exa de cada página (va a respuesta_generada)")
    p.add_argument("--resumen-consulta", default=None, help="qué resumir (por defecto, la consulta de la búsqueda)")
    p.add_argument("--edad-max-horas", type=_rango(-1, 720), default=None,
                   help="frescura del contenido: 0 fuerza descarga nueva (recargo sin verificar), -1 solo caché")


def construir_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="exa_helper.py", description="Exa completo: búsqueda, lectura, respuesta y Agent "
                                 "con coste informado, citas y modos acotados.")
    C.anadir_opciones_comunes(ap)
    sub = ap.add_subparsers(dest="cmd", required=True)
    C.anadir_subcomandos_comunes(sub)
    C.anadir_opciones_comunes(sub.choices["conectar"], True)
    sub.choices["reanudar"].add_argument("--cancelar", action="store_true", help="solicita cancelar y confirma mediante consulta")

    s = sub.add_parser("saldo", help="saldo y plan gratis (Exa no ofrece consulta de saldo verificada)")
    C.anadir_opciones_comunes(s, True)

    b = sub.add_parser("buscar", help="POST /search")
    b.add_argument("consulta")
    b.add_argument("--tipo", choices=TIPOS, default="auto")
    b.add_argument("--categoria", default=None,
                   help=f"{', '.join(CATEGORIAS)} (company y people no admiten fechas; people no admite --excluir)")
    b.add_argument("--dominios", action="append", default=None, help="includeDomains: host, host/ruta o *.host (coma o repetido)")
    b.add_argument("--excluir", action="append", default=None, help="excludeDomains")
    b.add_argument("--desde", default=None, help="AAAA-MM-DD (fecha de publicación)")
    b.add_argument("--hasta", default=None, help="AAAA-MM-DD (fecha de publicación)")
    b.add_argument("--n", type=_rango(1, 100), default=10)
    b.add_argument("--texto", type=_rango(1, 1_000_000), default=None, help="texto de la página (maxCharacters)")
    _opciones_contenido(b)
    b.add_argument("--sin-contenidos", action="store_true", help="solo títulos y URL (sin highlights)")
    b.add_argument("--consultas-extra", action="append", default=None,
                   help="additionalQueries (1-10), solo con deep-lite, deep o deep-reasoning")
    b.add_argument("--esquema", type=Path, default=None, help="fichero JSON con el outputSchema (va a respuesta_generada)")
    b.add_argument("--sin-validar-esquema", action="store_true", help="solo comprueba la raíz del esquema")
    b.add_argument("--pais", default=None, help="userLocation: código ISO de 2 letras")
    b.add_argument("--moderacion", action="store_true")
    C.anadir_opciones_comunes(b, True)

    le = sub.add_parser("leer", help="POST /contents (1-100 URL)")
    le.add_argument("urls", nargs="*")
    le.add_argument("--urls-fichero", type=Path, default=None, help="una URL por línea; # comenta")
    le.add_argument("--texto", type=_rango(1, 1_000_000), default=None, help="maxCharacters (por defecto 20.000)")
    _opciones_contenido(le)
    le.add_argument("--subpaginas", type=_rango(0, 100), default=None)
    le.add_argument("--objetivo-subpaginas", action="append", default=None)
    le.add_argument("--extras", action="append", default=None, help=f"{', '.join(EXTRAS)} (coma o repetido)")
    le.add_argument("--extras-n", type=_rango(0, 1000), default=20)
    C.anadir_opciones_comunes(le, True)

    r = sub.add_parser("responder", help="POST /answer: respuesta generada con sus citas")
    r.add_argument("consulta")
    r.add_argument("--modelo", choices=MODELOS_ANSWER, default=None)
    r.add_argument("--texto-citas", action="store_true", help="pide el texto de cada cita (va a texto_literal)")
    r.add_argument("--instrucciones", default=None, help="systemPrompt")
    r.add_argument("--esquema", type=Path, default=None)
    r.add_argument("--sin-validar-esquema", action="store_true")
    r.add_argument("--pais", default=None)
    C.anadir_opciones_comunes(r, True)

    g = sub.add_parser("agente", help="POST /agent/runs acotado (precio fijo o budget.maxCostDollars)")
    g.add_argument("consulta", help="la tarea del agente")
    g.add_argument("--esfuerzo", required=True, choices=ESFUERZOS)
    g.add_argument("--presupuesto-usd", type=C.usd_positivo, default=None,
                   help="budget.maxCostDollars (1-100 USD), obligatorio con auto y ultra")
    g.add_argument("--instrucciones", default=None, help="systemPrompt")
    g.add_argument("--esquema", type=Path, default=None)
    g.add_argument("--sin-validar-esquema", action="store_true")
    g.add_argument("--espera-s", type=float, default=300.0, help="cuánto sondear antes de dejarlo pendiente")
    g.add_argument("--cancelar-al-agotar", action="store_true")
    g.add_argument("--permitir-contrato-sin-verificar", action="store_true", help="habilita la hipótesis query del Agent; sin probar en vivo")
    g.add_argument("--permitir-caro", action="store_true", help="habilita high, xhigh, auto y ultra (sin prueba en vivo)")
    C.anadir_opciones_comunes(g, True)

    v = sub.add_parser("vigilar", help="Monitors: deshabilitado (ver references/costes-y-limites.md)")
    v.add_argument("resto", nargs="*")
    C.anadir_opciones_comunes(v, True)
    return ap


def _ejecutar(a: argparse.Namespace) -> int:
    if a.cmd == "salud":
        a.tope_usd = min(a.tope_usd, a.tope_total_usd, 0.05)
    if a.cmd == "reanudar":
        return cmd_reanudar(a)
    capturar = getattr(a, "json", False) and (a.cmd in ("salud", "conectar") or
                 (a.cmd == "libro" and getattr(a, "liberar_colgadas", False)))
    if capturar:
        if a.cmd == "salud" and a.en_vivo:
            print("--en-vivo: UNA llamada de pago mínima instant/1; máximo 0,05 USD; sin reintento.", file=sys.stderr)
        salida = io.StringIO()
        with contextlib.redirect_stdout(salida):
            r = C.ejecutar_comun(a)
        print(json.dumps({"skill": NOMBRE, "version": VERSION, "comando": a.cmd,
                          "codigo": r, "diagnostico": salida.getvalue(), "sonda_gratuita": "ninguna"},
                         ensure_ascii=False))
    else:
        r = C.ejecutar_comun(a)
        if a.cmd == "salud":
            print("Conexión de Exa: `conectar exa` (portapapeles o --desde-fichero; nunca una clave en argv).")
    if r is not None:
        return r
    return {"saldo": cmd_saldo, "buscar": cmd_buscar, "leer": cmd_leer, "responder": cmd_responder,
            "agente": cmd_agente, "vigilar": cmd_vigilar}[a.cmd](a)


def main(argv: Optional[List[str]] = None) -> int:
    a = construir_parser().parse_args(argv)
    return C.correr(lambda: _ejecutar(a))


if __name__ == "__main__":
    sys.exit(main())
