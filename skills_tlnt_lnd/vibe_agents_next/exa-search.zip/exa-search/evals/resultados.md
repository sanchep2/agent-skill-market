# Resultados — exa-search 1.0.0

Fecha: 16-oct-2026. Lo que sigue es lo medido, tal cual; donde el skill no gana o no se pudo comprobar algo, se dice.

## Pruebas automáticas

- `cd scripts && python3 -m unittest discover -p "test_*.py"`: **452 pruebas, OK** (275 del helper y 177 del cliente
  común), sin red, con HOME vacío y Python 3.14. La sintaxis de los módulos se comprueba también con la gramática de
  Python 3.9; no se ha ejecutado en un intérprete 3.9 real.
- La copia de `buscadores_comun.py` coincide con el SHA-256 declarado en `scripts/COMUN.sha256`
  (`c2520164bfe171b7812420fad0ed39b8bad287ba3349b945fd946488e39f65bb`) y con las copias de los otros tres skills de
  buscadores.
- Auditoría adversarial en seis rondas, con todos los hallazgos corregidos; la sexta da APTO. Intentó que el skill pasara
  el tope, repitiera un POST de pago, apuntara 0 cuando el coste es desconocido, usara funciones retiradas, siguiera
  instrucciones de una página o imprimiera una clave.

## Smoke real (15-oct-2026)

Revisión manual, ficha a ficha, de títulos, URL y extractos guardados. «Útil» significa que la ficha responde a la
pregunta del tema con contenido propio y en un idioma útil para la consulta. T1: «AI automation agency clients» (inglés,
negocio); T2: «lanzamiento de curso online» (español, marketing); T3: «vibe coding» (técnico).

| Modo | T1 | T2 | T3 | Nota |
|---|---|---|---|---|
| buscar auto + highlights | 10/10 | 10/10 | 10/10 | Mezcla español e inglés en T1 (la consulta iba en español) |
| deep-lite + consultas extra | 10/10 | — | — | Cubre outreach y casos, como pedían las consultas extra |
| news (desde 15-sep) | — | — | 5/10 | El resto, agentes de código y herramientas cercanas; 4 idiomas (Exa no tiene filtro de idioma) |
| leer / responder / agente | 2 de 3 URL (la 3.ª, inválida a propósito, sale como fallo) · respuesta generada con 4 referencias · Agent `minimal` con 3 webs | | | |

Coste del smoke: **0,059 USD**, según `costDollars` del proveedor (no es una factura).

Todos los modos pasan la puerta de ≥ 50 % útil; news queda justo en 5/10. Para noticias, escribe el idioma o el país en
la frase y revisa los resultados.

## Evals con y sin el skill (16-oct-2026)

**Método.** Dos escenarios de `evals.json`. El mismo agente de código hace cada escenario dos veces: con el skill y sin él
(su búsqueda web normal, sin navegador ni APIs de pago). Las entregas se copian como X e Y al azar y la clave se guarda
aparte. Juzgan:

- **Un juez que solo ve las dos respuestas.**
- **Tres jueces de tres proveedores distintos que ven además la evidencia de cada lado** (traza del agente y ficheros
  generados: registros, libro de gasto). Los criterios de proceso (coste, lecturas, separación entre texto de la fuente
  y texto generado) solo se pueden comprobar con ella. Cada juez comprueba a mano al menos 3 URL por entrega.

**Escenarios.**

- **e1:** cinco fuentes originales en español sobre lanzamientos de cursos online publicadas entre el 1 y el 14 de
  octubre de 2026, con pasajes literales y un tope de 0,20 USD.
- **e2:** publicaciones originales sobre evaluación de sistemas RAG con recuperación híbrida, con salida estructurada
  (método, limitaciones y citas).

| Escenario | Juez | Criterios con skill | Criterios sin skill | Calidad con skill (0-10) | Calidad sin skill | Mejor |
|---|---|---|---|---|---|---|
| e1 | Solo respuestas | 1/6 | 0/6 | 7 | 4 | con el skill |
| e1 | Juez A (con evidencia) | 6/6 | 3/6 | 8 | 4 | con el skill |
| e1 | Juez B (con evidencia) | 6/6 | 3/6 | 9 | 4 | con el skill |
| e1 | Juez C (con evidencia) | 6/6 | 3/6 | 9 | 5 | con el skill |
| e2 | Solo respuestas | 1/6 | 1/6 | 8 | 7 | con el skill |
| e2 | Juez A (con evidencia) | 5/5 | 3/5 | 9 | 7 | con el skill |
| e2 | Juez B (con evidencia) | 5/5 | 3/5 | 9 | 7 | con el skill |
| e2 | Juez C (con evidencia) | 3/6 | 2/6 | 8,5 | 8 | con el skill |

Los cuatro jueces eligen el skill en los dos escenarios.

**Lo que decide la diferencia, según los jueces:**

- **Con el skill:** en e1, cinco anuncios en español dentro de la ventana, con los pasajes presentes en el texto guardado,
  filtros de fecha en las llamadas reales, siete lecturas guardadas y el coste identificado. En e2, `type auto` y
  `category publication`, texto literal separado de la síntesis, cada afirmación citada y ninguna función retirada.
- **Sin el skill:** honesto sobre sus huecos, pero no guarda las respuestas originales ni acredita lecturas ni
  presupuesto; en e1 acaba con 0 fuentes plenamente confirmadas. En e2 su síntesis es útil y contrastada, aunque más
  breve.

**Invenciones.**

- **Con el skill: ninguna.** Una nota de «dato del proveedor no verificable»: un autor que viene de los metadatos de Exa
  y no aparece en la página; la propia entrega ya lo avisaba.
- **Sin el skill:** una fecha que no está en la página citada y un recuento de aperturas que la traza no respalda.

**Lo que los jueces no pudieron comprobar en el skill.** El juez C señala en e2 que la evidencia no muestra el mapeo de
`output.content` y su grounding, ni una prueba con instrucciones ocultas en una página, ni los eventos de reserva previos
a cada intento. Esas rutas las cubren las pruebas automáticas, no esta eval. Según ese juez, en e2 la ventaja de
utilidad es moderada.

**Coste real de las evals con el skill** (según `costDollars` del proveedor):

| Escenario | Llamadas | Coste |
|---|---|---|
| e1 | 4 | 0,021 USD |
| e2 | 4 | 0,027 USD |

## Límites conocidos

- Exa no tiene filtro de idioma: escribe el idioma o el país en la frase.
- `vigilar` (Monitors) está deshabilitado. `findSimilar` y `/research` no se implementan: uno está deprecado y el otro,
  retirado.
- Agent es experimental: necesita `--permitir-contrato-sin-verificar`. Solo se ha probado en vivo el esfuerzo `minimal`;
  los modos caros se documentan con su tope, sin probarlos en vivo.
- Pruebas automáticas en Linux; smoke y evals en macOS. En Windows no se ha probado.
