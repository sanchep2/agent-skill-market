# Parámetros y cuerpos vigentes

Fuente de verdad: Fase 0, lectura 2026-10-15 de
[/search](https://exa.ai/docs/reference/search),
[/contents](https://exa.ai/docs/reference/get-contents),
[/answer](https://exa.ai/docs/reference/answer),
[Agent](https://exa.ai/docs/agent/quickstart),
[OpenAPI](https://exa.ai/docs/exa-spec.yaml) y
[changelog](https://exa.ai/docs/changelog).
Todo acceso es HTTPS con cabecera `x-api-key`; la clave nunca va en URL ni cuerpo.

## buscar

`buscar CONSULTA` construye exclusivamente campos conocidos; no admite cuerpos arbitrarios.

| Opción | Campo JSON / límite |
|---|---|
| `--tipo` | `type`: instant, fast, auto (defecto), deep-lite, deep, deep-reasoning |
| `--n` | `numResults`: 1–100; defecto 10; el proveedor puede limitar por plan/tipo |
| `--categoria` | `category`: company, publication, news, personal site, financial report, people |
| `--dominios`, `--excluir` | includeDomains / excludeDomains; repetibles o con comas; hasta 1.200 cada lista |
| `--desde`, `--hasta` | startPublishedDate / endPublishedDate, AAAA-MM-DD convertido a inicio/fin UTC |
| `--texto N` | contents.text.maxCharacters: 1–1.000.000 |
| `--highlights [CONSULTA]` | contents.highlights: true u objeto query |
| `--max-car N` | highlights.maxCharacters; helper admite 1–1.000.000 como política local |
| `--resumen` | contents.summary.query; usa consulta principal o --resumen-consulta |
| `--edad-max-horas` | contents.maxAgeHours: -1 a 720; 0 requiere --permitir-recargos |
| `--consultas-extra` | additionalQueries; repetible; 1–10; solo deep-lite/deep/deep-reasoning |
| `--esquema FICHERO` | outputSchema, fichero JSON; resultado generado y grounding aparte |
| `--pais` | userLocation: cadena de dos letras, normalizada a mayúsculas |
| `--moderacion` | moderation: true |
| `--sin-contenidos` | omite contents; incompatible con opciones de contenido |

`userIdentifier` siempre es `exa-search`. Si no se pide texto/resumen, se añaden highlights por defecto.
`company` y `people` con fechas se rechazan antes de llamar; `people` con excluir también.
`--hasta` anterior a `--desde`, fechas inválidas, site: y categorías retiradas se rechazan sin gasto.
Alias de categoría en español: empresa(s), publicación/publicacion, noticia(s), sitio personal,
informe financiero y persona(s). El cuerpo siempre usa el nombre oficial en inglés.

Ejemplo exacto mínimo:

```json
{"query":"Guías de evaluación de recuperación","type":"auto","numResults":10,"userIdentifier":"exa-search","contents":{"highlights":true}}
```

`outputSchema`: raíz text u object, hasta diez propiedades por objeto, dos niveles de objetos,
arrays con items. `--sin-validar-esquema` conserva solo la comprobación de raíz; no garantiza aceptación
por Exa. No uses esta opción para evitar un error de esquema sin revisar antes su documentación.

## leer

`leer URL… [--urls-fichero RUTA]`: 1–100 URL HTTP(S), fichero opcional con una por línea.
Cuerpo: `urls`, `userIdentifier`, y opciones de contenido en la raíz, **sin** objeto `contents`.
Por defecto pide `text:{maxCharacters:20000}` si no se elige otro tipo.

Admite texto/highlights/max-car/resumen/edad como buscar. El resumen exige `--resumen-consulta`.
`--subpaginas 0..100` → subpages; `--objetivo-subpaginas` → subpageTarget, cadena o lista;
requiere al menos una subpágina. `--extras enlaces|imagenes|codigo` → extras.links/imageLinks/codeBlocks;
`--extras-n 0..1000` (defecto 20). Los extras devueltos se conservan en avisos `extras:<JSON>`.
Los estados por URL se unen por su id o URL exactos: un error conserva tag y httpStatusCode.
Subpáginas se normalizan por separado. Una URL omitida por el proveedor da un error visible.

## responder

`responder CONSULTA [--modelo exa|exa-pro|exa-research|exa-fast] [--texto-citas] [--pais XX]`
con `--instrucciones` → systemPrompt y `--esquema` → outputSchema.
Envía query y userIdentifier. Omite stream, por lo que no procesa SSE.
`answer` es generado; `citations` son referencias. Texto atribuido en citas se entrega en extractos aparte.
Precio base 0,005 USD: variantes y esquema tienen estimación incompleta si no viene costDollars.

## agente (experimental; captura real de minimal, demás esfuerzos sin probar)

`agente TAREA --esfuerzo minimal|low|medium|high|xhigh|auto|ultra`
requiere `--permitir-contrato-sin-verificar`. La Fase 0 enumera input.data y otros campos,
pero no especifica el nombre del campo de tarea: este helper **supone query**.
No se declara un contrato oficial exacto para esa hipótesis; los tests prueban la construcción local.
El smoke del 15-oct-2026 lo confirmó en vivo con `minimal`; si la API cambia, se ajusta en AGENT_CAMPO_TAREA.

Esfuerzos fijos: minimal/low/medium/high/xhigh. auto/ultra requieren `--presupuesto-usd 1..100`
y envían `budget:{maxCostDollars:N}`. Nunca se envía budget en esfuerzo fijo.
`high/xhigh/auto/ultra` requieren además `--permitir-caro`.
Opciones: `--esquema`, `--instrucciones`, `--espera-s` finito no negativo (defecto 300),
`--cancelar-al-agotar`. Hipótesis de flujo: POST /agent/runs, GET /agent/runs/{id},
POST /agent/runs/{id}/cancel; las rutas existen en Fase 0, sus detalles no se probaron en vivo.
Estados terminales: completed, failed, cancelled (también se tolera canceled).

`pendientes`: lista reservas retenidas. `reanudar ID_RESERVA [--cancelar]`: consulta o solicita
cancelación y exige confirmación terminal; nunca crea otro trabajo.

## Exclusiones y elementos retirados

- No se envían livecrawl (obsoleto 2026-02-02), numSentences, highlightsPerUrl,
  startCrawlDate/endCrawlDate (ignorados globalmente desde 2026-07-23), crawledBeforeDate,
  context, includeText/excludeText, resolvedSearchType ni highlightScores.
- useAutoprompt, includeUrls y excludeUrls no figuran en los esquemas leídos;
  su deprecación formal es **NO VERIFICADA**. Se excluyen por ausencia del esquema vigente.
- Categorías pdf/github/tweet deprecadas 2026-07-23; research paper sustituida por publication.
  Tipos neural/keyword no figuran como tipos vigentes, aunque la respuesta pueda traer search.neural.
- /findSimilar figura deprecated:true; /research retirado 2026-04-01.
- Dynamic highlights requiere beta; fuera de v1. Tampoco se exponen stream, compliance,
  snapshotAsOf ni opciones avanzadas de contenido que este helper no normaliza.
- Websets, Batches, Monitors, /chat/completions, /responses y MCP: ver costes y límites.
