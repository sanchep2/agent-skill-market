# Método y recetas

Fuentes leídas en la Fase 0 el 2026-10-15:
[mejores prácticas](https://exa.ai/docs/search/best-practices),
[guías por datos](https://exa.ai/docs/search/data/),
[búsqueda](https://exa.ai/docs/reference/search),
[precios](https://exa.ai/docs/admin/pricing).
Estas recetas trasladan recomendaciones de documentación; no son resultados medidos por este skill.

## Elegir una ruta

Describe la página que quieres encontrar: qué explica, qué método utiliza o qué problema resuelve.
Empieza con highlights. Cambiar de tipo es el último recurso según mejores prácticas.
Pide contenidos dentro de `/search`: hasta diez resultados tienen contenido incluido según el
[changelog](https://exa.ai/docs/changelog), entrada 2026-03-03, leído 2026-10-15.
Solo lee por URL cuando ya tengas fuentes elegidas o necesites más texto.

| Caso | Opciones | Precio esperado, antes de recargos |
|---|---|---|
| General | `buscar "Descripción de la página" --tipo auto --n 10` | 0,007 USD |
| Noticias | `--tipo auto --n 10`, ventana en la frase; fechas solo si son requisito duro | 0,007 USD |
| Papers y hallazgos | `--categoria publication`, describe método o hallazgo | auto: 0,007 USD |
| Empresas | `--tipo auto --categoria company`, describe actividad | 0,007 USD |
| Personas | `--tipo auto --categoria people`, describe rol y perfil | 0,007 USD |
| Código | `--tipo fast`, versión y artefacto concreto, sin categoría | 0,007 USD |
| Latencia mínima | `--tipo instant --highlights --edad-max-horas -1` | 0,004 USD |
| Varios pasos | `--tipo deep --esquema esquema.json` | base 0,012 USD; síntesis sin precio separado confirmado |
| Alternativa de investigación | `--tipo deep-lite` o `--tipo deep-reasoning` | base 0,012 / 0,015 USD |
| Lista y enriquecimiento | `agente … --esfuerzo minimal --permitir-contrato-sin-verificar` | 0,012 USD fijo; contrato experimental |
| Leer fuentes elegidas | `leer URL… --texto 20000` | 0,001 USD por página y tipo |
| Síntesis con fuentes | `responder …` | base 0,005 USD; valorar frente a deep pendiente |

No atribuyas garantías de latencia: las cifras publicadas varían incluso entre páginas oficiales.
`publication` incluye patentes, ensayos clínicos y aprobaciones regulatorias, además de papers.
La guía de noticias aconseja describir el tipo de fuente en la frase y no depender de `category:news`;
el índice incluye blogs y transcripciones. `news` sigue siendo una categoría válida.

## Ventana, idioma y dominios

La ventana en la consulta es una preferencia; `--desde/--hasta` son filtros de publicación.
Si hay requisito estricto, usa filtros y revisa `fecha`: Exa no garantiza su precisión.
Sin filtro de idioma los resultados mezclan idiomas: Exa news devolvió 4 idiomas en el smoke real del 15-oct-2026. Escribe el idioma o el país explícitamente en la frase (por ejemplo, «noticias en español sobre vibe coding en México»); comprueba cada resultado, pues la frase no es un filtro estricto. La Fase 0 no documenta un filtro de idioma; `--pais` orienta ubicación, no idioma. Véase [evaluación](../evals/resultados.md#smoke-real-15-oct-2026).

Receta: `buscar "Noticias en español sobre vibe coding en México" --categoria news --n 10`. Mantén `--salida` y `--investigacion` al continuar.
`--edad-max-horas` regula contenido almacenado, no demuestra cuándo se publicó una fuente.
No bases una decisión crítica de actualidad solo en ese parámetro.

`--dominios docs.example.org/ruta --dominios '*.example.org'` permite rutas y comodines
según esquema oficial. No uses `site:`. Cada lista admite hasta 1.200 entradas.
El límite de resultados es 1–100; cada plan y tipo puede aplicar un máximo menor.
`company` y `people` no admiten fechas; `people` tampoco exclusiones.

Reddit: el inventario de la Fase 0 encontró cero URL en más de quince consultas previas.
No es evidencia de cobertura universal ni de imposibilidad. El índice no lo documenta y los
prefijos de ruta sobre ese dominio siguen sin probar en vivo; no prometas cobertura social.

## Continuar sin duplicar gasto

Conserva `--salida` y `--investigacion`. Revisa `libro --ver` antes de continuar si hubo interrupción.
La caché dura el día local, se proyecta a campos usados y se declara como reutilización sin gasto nuevo.
`--sin-cache` evita lectura/escritura; pedir `--edad-max-horas` evita reutilizar contenidos locales.
`outputSchema` no se guarda en caché. Los extras tampoco se guardan porque su proyección no está definida.
No vuelvas a crear un Agent porque tarde: usa `pendientes` y `reanudar ID_DE_RESERVA`.
