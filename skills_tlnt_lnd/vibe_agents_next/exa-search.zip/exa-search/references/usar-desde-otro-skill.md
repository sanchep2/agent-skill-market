# Usar desde otro skill

Ejecuta `scripts/exa_helper.py` por ruta absoluta resuelta desde la instalación. No copies funciones
ni leas claves de otro skill. La copia de buscadores_comun.py es local y funciona sin otra carpeta.
Python >=3.9, solo biblioteca estándar. Versión del helper y metadata.version: 1.0.0.

## Invocación

```bash
python3 "$SKILL_DIR/scripts/exa_helper.py" buscar "Métodos de evaluación de RAG" \
  --tipo auto --categoria publication --n 10 --salida "$SALIDA" \
  --investigacion estudio-01 --tope-usd 0.10 --tope-total-usd 0.20 --json
python3 "$SKILL_DIR/scripts/exa_helper.py" leer "https://example.org/paper" \
  --salida "$SALIDA" --investigacion estudio-01 --json
python3 "$SKILL_DIR/scripts/exa_helper.py" citas --salida "$SALIDA" \
  --investigacion estudio-01 --json
```

Las opciones comunes se aceptan antes o después del subcomando. Usa argv como lista si lanzas
un subprocess, sin shell=True. No pases claves en argv. --salida es obligatorio para escribir
resultados; sin él se imprime salida y el libro/caché siguen en EXA_SEARCH_HOME o ~/.exa-search.
Conectar y libro son operaciones explícitas de configuración/contabilidad fuera de --salida.
Sin --salida/--investigacion, las consultas sueltas usan ID sueltas-AAAAMMDD para compartir el tope diario.

--json devuelve una entrega JSON en stdout en buscar/leer/responder, Agent terminal y citas.
Agent pendiente devuelve un objeto con pendiente, trabajo_id, id_reserva, estado.
`reanudar ID --json` devuelve ese objeto si sigue vivo o una entrega si terminó.
`pendientes --json` devuelve lista; libro --json devuelve el resumen; saldo --json explica
que consulta_de_saldo_en_la_api=false. salud, conectar y libro --liberar-colgadas con --json devuelven un objeto con
skill, version, comando, codigo, diagnostico y sonda_gratuita. El helper adapta su salida
humana común sin modificar el cliente. En salud --en-vivo --json el anuncio previo va
a stderr antes de llamar. Errores van a stderr redactado; comprueba el código antes de analizar stdout.

El JSON de entrega se construye con CAMPOS_REGISTRO del cliente común; ver
[entrega y credibilidad](entrega-y-credibilidad.md). No confundir registro.texto_literal con
respuesta_generada. Nunca transformar una síntesis en cita_literal para adaptar datos.

## Salidas del proceso

| Código | Significado |
|---:|---|
| 0 | Operación completada; revisar fallos por URL y diagnósticos de salud |
| 1 | Error general, HTTP no clasificado o fallo terminal del Agent |
| 2 | Uso incorrecto, parámetros incompatibles o modo deshabilitado |
| 3 | Clave ausente, mal formada o rechazada |
| 4 | Tope por llamada o presupuesto total insuficiente |
| 5 | Límite del proveedor: 402/429/cuota |
| 6 | Resultado desconocido o trabajo pendiente; no repetir la creación |
| 130 | Interrupción por teclado |

Un 0 puede incluir errores parciales por URL: se encuentran en fallos.
Un estado failed/cancelled de Agent se presenta como error, con coste si lo hubo.
Salud común devuelve 0 aunque falten claves o falle su llamada pagada; examina FALTA/MAL/SIN VALIDAR.
Las señales pueden producir los códigos convencionales del sistema y retener/liquidar reservas según su tipo.

## Trabajos e integración

`pendientes` lista ID **de reserva**; `reanudar <id>` recibe ese ID, no el run ID de Exa.
`reanudar <id> --cancelar` solicita cancelación y consulta; la reserva sigue hasta terminal.
No relances agente ante código 6, timeout o respuesta perdida. Sin run ID, no hay reanudación
segura: consulta el panel. Liberar una reserva local por cota no cancela un run remoto.

`conector-investigacion.toml` es una ficha declarativa de instalación aparte. Propone
buscar/leer con --json y un mapeo directo `registros` → fichas. Adaptador del consumidor:
por cada registro con texto_literal y URL, cita_literal=texto_literal; naturaleza=declarado;
fecha_publicacion=fecha; notas con fecha_fuente, motor, modo, avisos y coste compartido.
Los registros con solo respuesta_generada y los fallos se conservan como cobertura/contexto,
nunca se convierten en citas literales. El consumidor debe enlazar el JSON de evidencia.
No se instala un adaptador ni se modifica el skill consumidor en esta tarea.

No sumes coste de cada registro: usa entrega.coste. Mismo ID durante toda la investigación.
No hay modo gratuito de API garantizado; plan gratis no equivale a llamadas sin coste contable.
