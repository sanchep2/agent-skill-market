# Costes y límites

Documentación leída el **2026-10-15** en la Fase 0:
[precios](https://exa.ai/docs/admin/pricing),
[facturación y tasas](https://exa.ai/docs/admin/billing),
[errores](https://exa.ai/docs/admin/error-codes),
[Agent](https://exa.ai/docs/agent/quickstart),
[Monitors](https://exa.ai/docs/monitors/quickstart).
El smoke real del 2026-10-15 costó 0,059 USD según `costDollars` (ver `evals/resultados.md`). Los precios siguientes son tarifas documentadas, no facturas.

## Síncronos: BUS-C1

| Modo | Base USD por solicitud | Fuente de reserva |
|---|---:|---|
| `instant` | 0,004 | tarifa de /search |
| `fast` | 0,007 | tarifa de /search |
| `auto` | 0,007 | tarifa de /search |
| `deep-lite` | 0,012 | tarifa de /search |
| `deep` | 0,012 | tarifa de /search |
| `deep-reasoning` | 0,015 | tarifa de /search |
| /contents | 0,001 por página y tipo | precio por contenido |
| /answer | 0,005 base | tarifa de /answer |

Constantes: URL_PRECIOS = https://exa.ai/docs/admin/pricing; FECHA_FUENTES = 2026-10-15.
Cada resultado de búsqueda por encima de diez: 0,001 USD; resumen IA: 0,001 USD.
Los primeros diez resultados tienen contenidos incluidos, según
[changelog](https://exa.ai/docs/changelog) del 2026-03-03, leído 2026-10-15.

Fórmulas **locales** de planificación (no son una garantía contractual de máximo de factura):

- Búsqueda: base + max(0,n−10) × 0,001 × (1+tipos) + n × 0,001 si hay resumen.
  tipos cuenta text/highlights/summary. El factor de contenidos extra es una estimación conservadora
  del helper a partir del precio por página/tipo; no fue medido en vivo; con más de diez resultados y contenidos la estimación es incompleta.
- Lectura: URL × (1+subpages) × tipos × 0,001. Extras, subpáginas y descarga forzada
  hacen incompleta la estimación: no se liquida como tarifa exacta si falta coste del proveedor.
- Responder: base 0,005; con modelo explícito o esquema, la estimación se marca incompleta.
- Reserva con tarifa considerada completa: `precio*1.5 + 0.005` USD.
  Incompleta: `precio*3 + 0.02` USD. Redondeo a seis decimales.
  Estos márgenes son decisiones locales de protección, **no precios publicados ni límites de Exa**.
  Ejemplo auto/10/highlights: precio 0,007 y reserva 0,0155 USD.

`maxAgeHours:0` tiene recargo **NO VERIFICADO** (Fase 0 §3: «El recargo por
maxAgeHours:0 (descarga en directo): NO VERIFICADO»). Se permite solo con
`--permitir-recargos`, se avisa «sin probar en vivo», y sin costDollars se liquida la cota.
outputSchema y additionalQueries están documentados, pero no se verificó un desglose de recargos:
se usa estimación incompleta. Tampoco hay precio independiente confirmado de extras/subpáginas.

Orden de liquidación: costDollars.total (o número si llega así) → tarifa cuando es calculable
→ cota. `costDollars` es una **estimación informada por el proveedor, no factura** (Fase 0 §1).
El libro la etiqueta fuente_coste=proveedor; tarifa lleva URL y fecha; cota no se presenta como medición.
Sin respuesta o 5xx: DESCONOCIDO (cota liquidada), también si un reintento acaba bien.
No se apunta cero por respuesta perdida. Un 503 se trata conservadoramente como desconocido,
aunque la documentación diga no facturado. Respuesta correcta sin coste: «por cota» si falta tarifa completa.

Libro común con un único bloqueo para USD y créditos. Exa reserva cota_creditos=0;
no convierte USD en créditos de Websets. Antes de cada intento comprueba gastado+pendiente+reserva
contra ambos topes. Por defecto: 0,50 USD por llamada y 1,50 USD por investigación.
No es un límite mensual de cuenta: otros clientes pueden gastar fuera de este libro.
`libro --ver` muestra ambas unidades. `libro --liberar-colgadas` liquida cota completa,
solo cuando ningún proceso la tiene en vuelo. Trabajos requieren `--incluir-pendientes` explícito;
forzar su cierre local no demuestra que el proveedor haya dejado de facturar.

## Agent: BUS-C2

| Esfuerzo | Cota USD impuesta por tarifa o presupuesto del proveedor |
|---|---:|
| `minimal` | 0,012 fijo por petición |
| `low` | 0,025 fijo por petición |
| `medium` | 0,10 fijo por petición |
| `high` | 0,50 fijo por petición |
| `xhigh` | 1,00 fijo por petición |
| `auto` | budget.maxCostDollars explícito, entre 1 y 100 |
| `ultra` | budget.maxCostDollars explícito, entre 1 y 100 |

Fuente de cada cota: precios y Agent enlazados arriba, 2026-10-15.
Esfuerzos fijos NO envían budget; auto/ultra NO usan sus topes implícitos de 5/20 USD.
El campo de tarea no se especificó en Fase 0; la hipótesis query está detrás de
`--permitir-contrato-sin-verificar`. El smoke real del 2026-10-15 aporta una captura de minimal; los demás esfuerzos no están probados en vivo.
High/xhigh/auto/ultra necesitan --permitir-caro y topes que cubran su reserva.
En vivo solo se ha probado minimal; no se atribuyen pruebas inexistentes a los demás esfuerzos.

Reservar → POST una vez → consultar hasta terminal. Timeout deja pendiente; respuesta perdida
al crear deja pendiente_desconocido y detiene el proveedor en la sesión. Cancelar no libera nada
hasta GET terminal. `pendientes` y `reanudar ID_RESERVA [--cancelar]` permiten recuperar el estado.
Al terminal: coste del proveedor o cota. El flujo inicial puede usar tarifa fija si completó;
reanudar sin coste usa cota, por lo que no afirma factura en ninguno de los dos casos.
No hay POST repetido ante 5xx. Sondeo/consulta no añade reservas según el contrato común;
la Fase 0 no verifica una tarifa separada de consulta/cancelación. No se promete que sean gratuitas.

## Red y salud

Hasta dos reintentos en /search y /contents por red/5xx/429. Cada intento reserva y liquida.
Retry-After hasta 30 s; si pide más, se para. /answer y creación Agent no se reintentan.
402 distingue NO_MORE_CREDITS, API_KEY_BUDGET_EXCEEDED, TEAM_BUDGET_EXCEEDED.
403 explica FEATURE_DISABLED, PROHIBITED_CONTENT, TEAM_BLOCKED; corta la sesión como acceso rechazado.
429 incluye RATE_LIMIT_EXCEEDED/CONCURRENCY_LIMIT_REACHED. Se conservan X-RateLimit-*,
Retry-After y x-exa-queued; uso.jsonl añade requestId, searchTime y costDollars.
Tasas publicadas por equipo: /search y /answer 10 QPS, deep* 5, /contents 100,
Agent 5 QPS y 50 activos. Pausa local mínima 0,2 s; no coordina QPS entre procesos/equipos.

BUS-C4: sonda gratuita ninguna. salud sin red devuelve 0 y dice qué falta o
«clave presente, validez no comprobada». --en-vivo anuncia UNA búsqueda pagada instant/1
sin contenidos ni reintento; máximo 0,05 USD local. El diagnóstico común devuelve 0 también
si la sonda pagada falla y lo indica con MAL; no interpretes el código como validación de clave.

## Documentado y deshabilitado

- Monitors: Fase 0 §1 enumera search, trigger, outputSchema, webhook, metadata, intervalo mínimo
  una hora y retraso de hasta treinta minutos. No confirma límite de ejecuciones ni consulta sin
  webhook. Por BUS-C2, `vigilar` falla antes de reservar o llamar. Tarifa informativa: 0,015 USD/ejecución.
- /findSimilar: deprecated:true en [OpenAPI](https://exa.ai/docs/exa-spec.yaml), leído 2026-10-15.
- /research: retirado 2026-04-01 en [changelog](https://exa.ai/docs/changelog); usar deep-reasoning.
- Websets: precios NO VERIFICADOS; además exige plan API propio, fuera de alcance.
- Batches: beta Enterprise; dynamic highlights: beta con cabecera especial; fuera de v1.
- /chat/completions y /responses: Fase 0 §1 «Esquema NO VERIFICADO»; no se implementan.
- MCP web_search_exa: parámetros NO VERIFICADOS en Fase 0 §7; no se invoca MCP.
  Sin CLI oficial documentada; el helper es una herramienta local de este skill.
- highlightScores: contradicción changelog/esquema; no se lee ni se envía.
- saldo: sin endpoint gratuito verificado; solo panel y gasto local. Plan documentado:
  10 USD/mes no acumulables más 10 USD de onboarding; no se mide disponibilidad en esta versión.

## Coste después del smoke del 2026-10-15

La entrega y `coste_entrega()` desglosan el coste por origen, en texto y JSON.
El total liquidado es contable: no implica que todo sea una factura o una estimación.
En `desglose`:

- `usd_real_proveedor`: USD informados por el proveedor (Exa `costDollars`, Perplexity Agent `usage.cost`).
- `usd_estimado_tarifa`: USD calculados con tarifa, sin medición monetaria de esa llamada.
- `usd_valoracion_creditos`: conversión estimada a USD de créditos de Firecrawl; nunca USD reales informados.
- `creditos_informados_proveedor`: créditos medidos por el proveedor, separados de su valoración monetaria.
- `usd_cota_sin_coste_real`: cota liquidada cuyo coste real es DESCONOCIDO, incluso con HTTP exitoso sin uso.
- `reservado_sin_liquidar_usd` y `reservado_sin_liquidar_creditos`: reservas pendientes, fuera del total liquidado.

`valoracion_estimada: true` indica que hay componentes estimados; no etiqueta los USD
reales del proveedor como estimados. `coste_real_desconocido: true` cubre cotas sin coste real y pendientes. El flag preexistente `desconocido` conserva su significado de respuesta incierta (pérdida o pendiente), para mantener los códigos de salida de respuestas válidas sin uso informado. No sumar una llamada por cada resultado ni sumar créditos a USD.
