# Instalación y alta

Instala la carpeta completa en el directorio de skills que utilice tu agente. Ejemplos:
`~/.claude/skills/exa-search` y `~/.codex/skills/exa-search`. No requiere SDK ni paquetes pip.
Python >=3.9 y biblioteca estándar. La API necesita acceso HTTPS; las pruebas usan transporte falso.

## Clave

Obtén una clave en el panel de Exa siguiendo su [documentación](https://exa.ai/docs/).
La Fase 0 (2026-10-15) documenta x-api-key o Authorization: Bearer; este helper usa x-api-key.
No se describen rutas de menú que no se hayan verificado.

Copia la clave al portapapeles y ejecuta:

```bash
python3 scripts/exa_helper.py conectar exa
```

Alternativa: `conectar exa --desde-fichero RUTA` con un fichero elegido por la persona.
No se acepta el valor de una clave por argv. No pegar claves en chats, logs ni ejemplos.
También se admite EXA_API_KEY en el entorno, configurada por un mecanismo privado del sistema.
El entorno tiene prioridad sobre el fichero. No se importan claves de otras instalaciones.

Datos locales en `~/.exa-search/`; EXA_SEARCH_HOME cambia esa raíz. El fichero claves.env
se guarda 0600, el directorio privado 0700. Se rechazan espacios, controles, caracteres invisibles
o comillas tipográficas en una clave. Los errores nombran el problema sin mostrar su valor.
El diagnóstico nunca necesita imprimir credenciales.

## Comprobar

`python3 scripts/exa_helper.py salud` devuelve 0 y describe Python, directorio, capacidades y
claves ausentes. Sin sonda gratuita verificada, una clave presente aparece como
«clave presente, validez no comprobada». Esto no certifica que funcione.

Solo si se quiere una llamada pagada: `salud --en-vivo --tope-usd 0.02`.
Anuncia UNA búsqueda instant, n=1, sin contenidos, sin reintento. Reserva 0,011 USD;
tarifa base 0,004 USD, informada por precios leídos 2026-10-15. No se ha ejecutado en esta construcción.
Un tope inferior a la reserva impide lanzar; el diagnóstico lo muestra con MAL.
`saldo` no consulta API: muestra gasto local y remite al panel para saldo real.

## Portabilidad y verificación

Windows: sin probar. El libro usa flock en POSIX y msvcrt en Windows; el portapapeles depende
de utilidades del sistema. --desde-fichero y el entorno evitan necesitar portapapeles.
No se instalan automáticamente herramientas ni enlaces a otros agentes.

`cd scripts && python3 -m unittest -v test_exa_helper` prueba con fixtures construidos,
red falsa y directorios temporales. Incluye carreras de procesos, HTTP seguro, redacción de claves,
Unicode, reservas, asíncronos y SHA. No valida un contrato real con Exa.
La copia canónica de buscadores_comun.py no se modifica: COMUN.sha256 declara su hash.
Para actualizarla, sustituye por una versión canónica aprobada, declara su nuevo SHA y verifica paridad.
La política de revisión de este paquete puede exigir conservar los ficheros existentes.

Smoke real (15-oct-2026), evals con juez ciego (16-oct-2026) y auditoría adversarial: ver
`evals/resultados.md`. La revisión de licencia y redistribución según tu uso corre de tu cuenta.
