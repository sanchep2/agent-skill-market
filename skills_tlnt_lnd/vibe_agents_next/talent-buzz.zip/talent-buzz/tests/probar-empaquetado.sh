#!/usr/bin/env bash
# Fixtures del empaquetador del ZIP publico (scripts/empaquetar.sh):
# (a) el ZIP del arbol real sale limpio: 0 entradas fuera de [A-Za-z0-9._/-],
#     0 __pycache__, 0 .pyc, raiz talent-buzz/;
# (b) un __pycache__/ o un .pyc o un temporal plantado NO entra (con y sin git),
#     ni uno ya versionado;
# (c) una ruta con «@», con espacio o no ASCII hace fallar al empaquetador con
#     rc 1, nombrando la ruta y sin dejar ZIP;
# (d) es determinista: mismo sha256 en dos corridas y aunque cambien fechas y
#     permisos de los ficheros; con git y sin git sale el mismo ZIP;
# (e) la plantilla de la unidad viaja con el nombre sin «@» y la guia la instala
#     como buzz-hermes@.service (el nombre de la unidad no cambia).
# Solo usa copias en un temporal propio; no toca el arbol.
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL="$(cd "$DIR/.." && pwd)"
EMP="$SKILL/scripts/empaquetar.sh"
TMP="$(mktemp -d)"
: "${TMP:?}"
trap 'rm -rf -- "$TMP"' EXIT
export PYTHONDONTWRITEBYTECODE=1
fallos=0
casos=0

ok()  { casos=$((casos+1)); echo "OK  $1"; }
mal() { casos=$((casos+1)); echo "FALLO $1"; fallos=$((fallos+1)); }
chk() { # $1 descripcion; resto: comando de test
  local desc="$1"; shift
  if "$@"; then ok "$desc"; else mal "$desc"; fi
}

nombres_zip() { python3 -I -c 'import sys, zipfile
print("\n".join(zipfile.ZipFile(sys.argv[1]).namelist()))' "$1"; }
sha_de() { python3 -I -c 'import hashlib, sys
print(hashlib.sha256(open(sys.argv[1], "rb").read()).hexdigest())' "$1"; }
miembro_zip() { python3 -I -c 'import sys, zipfile
sys.stdout.write(zipfile.ZipFile(sys.argv[1]).read(sys.argv[2]).decode())' "$1" "$2"; }
valor() { grep "^$2=" "$1.out" | cut -d= -f2; }   # $1 zip, $2 clave de la salida

# Copia de la skill en $1/talent-buzz (sin bytecode que pudiera traer el arbol).
copia_skill() {
  mkdir -p "$1"
  cp -a "$SKILL" "$1/talent-buzz"
  find "$1/talent-buzz" -name __pycache__ -prune -exec rm -rf -- {} +
}
# Construye con el empaquetador de la copia $1 hacia el zip $2; devuelve su rc.
construir() {
  local rc=0
  bash "$1/scripts/empaquetar.sh" "$2" >"$2.out" 2>"$2.err" || rc=$?
  return "$rc"
}
sin_entradas_malas() { # $1 zip: ninguna entrada fuera del juego, __pycache__ ni .pyc
  [ "$(nombres_zip "$1" | grep -cE '[^A-Za-z0-9._/-]|__pycache__|\.pyc$')" = 0 ]
}

# ── (a) el ZIP del arbol real ───────────────────────────────────────────────
REAL="$TMP/real.zip"
rc=0; construir "$SKILL" "$REAL" || rc=$?
chk "(a) el arbol real empaqueta con rc 0" test "$rc" = 0
chk "(a) imprime sha256 y entradas que coinciden con el ZIP" \
  test "$(valor "$REAL" sha256)" = "$(sha_de "$REAL")" -a "$(valor "$REAL" entradas)" = "$(nombres_zip "$REAL" | wc -l)"
chk "(a) 0 entradas fuera de [A-Za-z0-9._/-], 0 __pycache__, 0 .pyc" sin_entradas_malas "$REAL"
chk "(a) todas las entradas cuelgan de talent-buzz/ y esta SKILL.md" \
  test "$(nombres_zip "$REAL" | grep -vc '^talent-buzz/')" = 0 -a "$(nombres_zip "$REAL" | grep -c '^talent-buzz/SKILL\.md$')" = 1

# ── (b) bytecode y temporales plantados no entran (copia SIN git) ───────────
C2="$TMP/c2"; copia_skill "$C2"
S2="$C2/talent-buzz"
limpio2="$TMP/limpio2.zip"
rc=0; construir "$S2" "$limpio2" || rc=$?
chk "(b) la copia limpia empaqueta (fuente arbol)" test "$rc" = 0 -a "$(valor "$limpio2" fuente)" = arbol
chk "(b) la copia da el MISMO ZIP que el arbol real (con o sin git)" test "$(sha_de "$limpio2")" = "$(sha_de "$REAL")"
mkdir -p "$S2/scripts/__pycache__" "$S2/tests/__pycache__"
printf 'bytecode' > "$S2/scripts/__pycache__/genkeys.cpython-314.pyc"
printf 'texto'    > "$S2/scripts/__pycache__/leeme.txt"
printf 'bytecode' > "$S2/tests/__pycache__/x.pyc"
printf 'bytecode' > "$S2/scripts/suelto.pyc"
printf 'swap'     > "$S2/scripts/.roto.swp"
printf 'copia'    > "$S2/SKILL.md~"
plantado2="$TMP/plantado2.zip"
rc=0; construir "$S2" "$plantado2" || rc=$?
chk "(b) con bytecode y temporales plantados el empaquetador sigue en rc 0" test "$rc" = 0
chk "(b) ninguno de los plantados entra" sin_entradas_malas "$plantado2"
chk "(b) los temporales (.swp, ~) tampoco entran" \
  test "$(nombres_zip "$plantado2" | grep -cE '\.swp$|~$')" = 0
chk "(b) el ZIP con plantados es idéntico al limpio" test "$(sha_de "$plantado2")" = "$(sha_de "$limpio2")"

# ── (b2) con git: solo lo versionado; lo versionado con bytecode tampoco entra ─
C3="$TMP/c3"; copia_skill "$C3"
S3="$C3/talent-buzz"
git -C "$S3" init -q
git -C "$S3" add -A
limpio3="$TMP/limpio3.zip"
rc=0; construir "$S3" "$limpio3" || rc=$?
chk "(b) con git la fuente es git y empaqueta" test "$rc" = 0 -a "$(valor "$limpio3" fuente)" = git
chk "(b) git y arbol dan el mismo ZIP" test "$(sha_de "$limpio3")" = "$(sha_de "$limpio2")"
mkdir -p "$S3/scripts/__pycache__"
printf 'bytecode' > "$S3/scripts/__pycache__/q.cpython-314.pyc"
printf 'sin versionar' > "$S3/assets/sin-versionar@.txt"
plantado3="$TMP/plantado3.zip"
rc=0; construir "$S3" "$plantado3" || rc=$?
chk "(b) con git lo SIN versionar (incluso con «@») no entra ni molesta" \
  test "$rc" = 0 -a "$(sha_de "$plantado3")" = "$(sha_de "$limpio3")"
git -C "$S3" add -f scripts/__pycache__/q.cpython-314.pyc
versionado3="$TMP/versionado3.zip"
rc=0; construir "$S3" "$versionado3" || rc=$?
chk "(b) con git un .pyc ya VERSIONADO tampoco entra" \
  test "$rc" = 0 -a "$(sha_de "$versionado3")" = "$(sha_de "$limpio3")"

# ── (c) rutas con caracteres fuera del juego ────────────────────────────────
mala() { # $1 etiqueta, $2 ruta relativa a plantar; el nombre sale por printf para no depender del locale
  local c="$TMP/mala-$1"; copia_skill "$c"
  printf 'x' > "$c/talent-buzz/$2"
  local z="$TMP/mala-$1.zip" r=0
  construir "$c/talent-buzz" "$z" || r=$?
  chk "(c) $1: rc 1" test "$r" = 1
  chk "(c) $1: nombra la ruta" grep -qF "$2" "$z.err"
  chk "(c) $1: no deja ZIP" test ! -e "$z"
}
mala arroba    'assets/zz@x.txt'
mala espacio   'assets/zz y.txt'
mala noascii   "assets/caf$(printf '\303\251').txt"
C4="$TMP/c4"; copia_skill "$C4"
printf 'x' > "$C4/talent-buzz/assets/zz@git.txt"
git -C "$C4/talent-buzz" init -q
git -C "$C4/talent-buzz" add -A
rc=0; construir "$C4/talent-buzz" "$TMP/c4.zip" || rc=$?
chk "(c) con git una ruta versionada con «@» falla (rc 1) y se nombra" \
  test "$rc" = 1 -a "$(grep -cF 'assets/zz@git.txt' "$TMP/c4.zip.err")" -ge 1 -a ! -e "$TMP/c4.zip"

# ── (d) determinismo ────────────────────────────────────────────────────────
otra="$TMP/otra.zip"
rc=0; construir "$S2" "$otra" || rc=$?
chk "(d) dos corridas del mismo arbol: mismo sha256" test "$rc" = 0 -a "$(sha_de "$otra")" = "$(sha_de "$limpio2")"
chk "(d) dos corridas: ZIP identico byte a byte" cmp -s "$otra" "$limpio2"
C5="$TMP/c5"; copia_skill "$C5"
find "$C5/talent-buzz" -exec touch -d '2031-05-05 10:11:12' {} +
chmod 664 "$C5/talent-buzz/SKILL.md"
chmod 700 "$C5/talent-buzz/scripts/sonda.sh"
fechas5="$TMP/fechas5.zip"
rc=0; construir "$C5/talent-buzz" "$fechas5" || rc=$?
chk "(d) otras fechas y permisos de lectura/propietario: mismo sha256" \
  test "$rc" = 0 -a "$(sha_de "$fechas5")" = "$(sha_de "$limpio2")"

# ── (e) la plantilla de la unidad: nombre nuevo, destino intacto ────────────
TPL='talent-buzz/assets/buzz-hermes-at.service.tmpl'
chk "(e) la plantilla esta en el ZIP con el nombre sin «@»" \
  test "$(nombres_zip "$REAL" | grep -cFx "$TPL")" = 1
chk "(e) el nombre viejo con «@» no esta en el ZIP" \
  test "$(nombres_zip "$REAL" | grep -c 'buzz-hermes@')" = 0
plantilla_ok() {
  local c; c="$(miembro_zip "$REAL" "$TPL")"
  printf '%s\n' "$c" | grep -qF 'User=hermesbot%i' && ! printf '%s\n' "$c" | grep -q 'User=hermesbot$'
}
chk "(e) la plantilla del ZIP conserva User=hermesbot%i y no User=hermesbot a secas" plantilla_ok
GUIA="$SKILL/references/extension-hermes.md"
chk "(e) la guia instala desde assets/buzz-hermes-at.service.tmpl" \
  grep -qF 'assets/buzz-hermes-at.service.tmpl' "$GUIA"
chk "(e) la guia deja la unidad como /etc/systemd/system/buzz-hermes@.service" \
  grep -qF 'sudo tee /etc/systemd/system/buzz-hermes@.service >/dev/null' "$GUIA"
VIEJO='buzz-hermes@.service'; VIEJO="$VIEJO.tmpl"   # partido para que el propio fichero no lo contenga
chk "(e) la guia ya no nombra la plantilla con «@»" \
  test "$(grep -cF "$VIEJO" "$GUIA")" = 0
chk "(e) INV-TB-055/056 apuntan a la plantilla nueva" \
  test "$(grep -cE $'^INV-TB-05[56]\tassets/buzz-hermes-at\\.service\\.tmpl\t' "$SKILL/invariants.tsv")" = 2
chk "(e) desmontar.sh sigue usando la unidad buzz-hermes@.service" \
  grep -qF 'buzz-hermes@.service' "$SKILL/scripts/desmontar.sh"

# ── uso ─────────────────────────────────────────────────────────────────────
rc=0; bash "$EMP" >/dev/null 2>&1 || rc=$?
chk "sin argumentos: rc 2" test "$rc" = 2
rc=0; bash "$S2/scripts/empaquetar.sh" "$S2/dentro.zip" >/dev/null 2>&1 || rc=$?
chk "una salida dentro de la skill se rechaza (rc 2) y no escribe" test "$rc" = 2 -a ! -e "$S2/dentro.zip"

# El TOTAL es un GATE, no un adorno: universo FIJO (comprobaciones literales en este fichero).
TOTAL=$casos
TOTAL_ESPERADO=37
echo "---- TOTAL=$TOTAL (esperados=$TOTAL_ESPERADO) ----"
if [ "$TOTAL" -ne "$TOTAL_ESPERADO" ]; then
  echo "ERROR: TOTAL=$TOTAL != TOTAL_ESPERADO=$TOTAL_ESPERADO — cobertura perdida o test fantasma" >&2
  exit 1
fi
if [ "$fallos" -eq 0 ]; then echo "probar-empaquetado: TODO OK"; else echo "probar-empaquetado: $fallos fallos"; exit 1; fi
