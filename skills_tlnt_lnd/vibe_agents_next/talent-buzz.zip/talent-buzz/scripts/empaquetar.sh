#!/usr/bin/env bash
# empaquetar.sh <salida.zip> — arma el ZIP PUBLICO de la skill (raiz `talent-buzz/`).
#
# Por que existe: el ZIP se armaba a mano y Claude lo rechazaba con «Zip file contains
# path with invalid characters» (una «@» en el nombre de una plantilla y un .pyc colado).
#
#  - FUENTE: los ficheros VERSIONADOS de la skill (`git ls-files`). Sin git (el ZIP ya
#    descomprimido del alumno), el arbol menos lo excluido.
#  - EXCLUYE siempre `__pycache__/`, `*.pyc`/`*.pyo`, `.git/` y temporales (`*.swp`,
#    `*~`, `*.tmp`, `*.bak`, `*.orig`, `*.rej`, `.DS_Store`, `Thumbs.db`).
#  - COMPRUEBA las rutas: rc 1, nombrando la ruta, si alguna entrada lleva un caracter
#    fuera de [A-Za-z0-9._/-] (o es un enlace simbolico, o tiene componentes `.`/`..`).
#    No se escribe ZIP si alguna ruta falla.
#  - DETERMINISTA: orden fijo (bytes), fecha fija, permisos normalizados (755 si el
#    fichero es ejecutable, 644 si no) y compresion fija: mismo arbol, mismo sha256.
#  - Imprime `sha256=<hex>` y `entradas=<n>`. Solo usa bash + python3 (biblioteca
#    estandar) y, si esta, git.
# rc: 0 ok · 1 ruta/entrada no valida · 2 uso o precondicion.
set -euo pipefail
export LC_ALL=C PYTHONDONTWRITEBYTECODE=1
umask 022

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
SKILL="$(cd "$DIR/.." && pwd -P)"
RAIZ="talent-buzz"

die() { echo "empaquetar: $*" >&2; exit 2; }

[ $# -eq 1 ] && [ -n "$1" ] || die "uso: empaquetar.sh <salida.zip>"
SALIDA="$(realpath -m -- "$1")"
case "$SALIDA" in
  "$SKILL"/*) die "la salida no puede estar dentro de la skill: $SALIDA" ;;
esac
[ -d "$(dirname "$SALIDA")" ] || die "no existe el directorio de salida: $(dirname "$SALIDA")"
[ ! -d "$SALIDA" ] || die "la salida es un directorio: $SALIDA"

TMPD="$(mktemp -d)"
: "${TMPD:?}"
trap 'rm -rf -- "$TMPD"' EXIT

# Exclusion: __pycache__/, bytecode, .git/ y temporales (aplica con git y sin git).
excluido() { # $1 ruta relativa a la skill
  local p="$1" b="${1##*/}"
  case "/$p/" in
    */__pycache__/*|*/.git/*|*/.pytest_cache/*|*/.mypy_cache/*) return 0 ;;
  esac
  case "$b" in
    *.pyc|*.pyo|*.swp|*.swo|*~|*.tmp|*.bak|*.orig|*.rej|.DS_Store|Thumbs.db) return 0 ;;
  esac
  return 1
}

# Fuente de la lista (NUL-separada): git si SKILL.md esta versionado; si no, el arbol.
if git -C "$SKILL" ls-files --error-unmatch SKILL.md >/dev/null 2>&1; then
  FUENTE=git
  git -C "$SKILL" ls-files -z -- . > "$TMPD/crudo"
else
  FUENTE=arbol
  ( cd "$SKILL" && find . \( -type f -o -type l \) -print0 ) > "$TMPD/crudo"
fi

: > "$TMPD/lista"
malas=0
total=0
while IFS= read -r -d '' p; do
  p="${p#./}"
  if excluido "$p"; then continue; fi
  total=$((total+1))
  entrada="$RAIZ/$p"
  if [[ "$entrada" =~ [^A-Za-z0-9._/-] ]]; then
    echo "empaquetar: ruta con caracter no valido (permitido [A-Za-z0-9._/-]): '$entrada'" >&2
    malas=$((malas+1)); continue
  fi
  case "/$p/" in
    */./*|*/../*|*//*) echo "empaquetar: ruta con componente vacio, '.' o '..': '$entrada'" >&2
                       malas=$((malas+1)); continue ;;
  esac
  if [ -L "$SKILL/$p" ]; then
    echo "empaquetar: enlace simbolico no permitido: '$entrada'" >&2
    malas=$((malas+1)); continue
  fi
  if [ ! -f "$SKILL/$p" ]; then
    echo "empaquetar: el fichero no existe: '$entrada'" >&2
    malas=$((malas+1)); continue
  fi
  printf '%s\0' "$p" >> "$TMPD/lista"
done < "$TMPD/crudo"

[ "$malas" -eq 0 ] || { echo "empaquetar: $malas entrada(s) no valida(s); no se escribe el ZIP" >&2; exit 1; }
[ "$total" -gt 0 ] || die "la skill no tiene ficheros que empaquetar (fuente: $FUENTE)"
grep -qz '^SKILL\.md$' "$TMPD/lista" || die "falta SKILL.md entre los ficheros a empaquetar (fuente: $FUENTE)"

RES="$(python3 -I - "$SKILL" "$TMPD/lista" "$TMPD/salida.zip" "$RAIZ" <<'PYEOF'
import hashlib, os, re, sys, zipfile

skill, lista, salida, raiz = sys.argv[1:5]
with open(lista, "rb") as f:
    nombres = sorted(n.decode("ascii") for n in f.read().split(b"\0") if n)

FECHA = (1980, 1, 1, 0, 0, 0)  # fecha fija: el ZIP no depende de cuando se construye
with zipfile.ZipFile(salida, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n in nombres:
        ruta = os.path.join(skill, n)
        modo = 0o755 if os.stat(ruta).st_mode & 0o111 else 0o644  # permisos normalizados
        zi = zipfile.ZipInfo(raiz + "/" + n, FECHA)
        zi.create_system = 3
        zi.external_attr = (0o100000 | modo) << 16
        with open(ruta, "rb") as f:
            z.writestr(zi, f.read(), zipfile.ZIP_DEFLATED, 9)

# Comprobacion final sobre el ZIP ya escrito (cinturon y tirantes).
with zipfile.ZipFile(salida) as z:
    entradas = z.namelist()
malas = [e for e in entradas
         if re.search(r"[^A-Za-z0-9._/-]", e) or "__pycache__" in e or e.endswith(".pyc")]
if malas:
    sys.exit("empaquetar: el ZIP final lleva entradas no validas: " + repr(malas))
with open(salida, "rb") as f:
    print("sha256=" + hashlib.sha256(f.read()).hexdigest())
print("entradas=%d" % len(entradas))
PYEOF
)"

mv -f -- "$TMPD/salida.zip" "$SALIDA"
echo "fuente=$FUENTE"
echo "$RES"
