# Changelog — talent-buzz

## 1.2.2 — 2026-10-21 (ZIP publico que Claude acepta, issue 9445)

Claude rechazaba el ZIP publico de la skill con «Zip file contains path with
invalid characters». Dos causas: la plantilla de la unidad systemd llevaba una
«@» en el NOMBRE del fichero (la «@» que systemd usa en las unidades de
plantilla) y el ZIP se armaba a mano, sin filtro de rutas, y arrastraba
`scripts/__pycache__/*.pyc`.

- **Plantilla renombrada**: `assets/buzz-hermes@.service.tmpl` pasa a
  `assets/buzz-hermes-at.service.tmpl` (`git mv`, contenido identico, incluidos
  `User=hermesbot%i` y la ausencia de `User=hermesbot` a secas, INV-TB-055/056,
  que ahora apuntan a la ruta nueva). La unidad INSTALADA no cambia: la guia
  `references/extension-hermes.md` la deja en
  `/etc/systemd/system/buzz-hermes@.service` (instancias `buzz-hermes@N`) y
  `scripts/desmontar.sh` sigue intacto.
- **Empaquetador nuevo `scripts/empaquetar.sh <salida.zip>`**: arma el ZIP
  publico (raiz `talent-buzz/`) desde los ficheros versionados (`git ls-files`;
  sin git, el arbol), excluye `__pycache__/`, `*.pyc` y temporales, FALLA (rc 1,
  nombrando la ruta, sin escribir el ZIP) si alguna entrada lleva un caracter
  fuera de `[A-Za-z0-9._/-]`, es determinista (orden, fechas y permisos
  normalizados: mismo sha256 en cada corrida y con o sin git) e imprime el
  sha256 y el numero de entradas. Cierra la clase para toda la skill, no solo
  para esta plantilla. Solo bash + python3 de la biblioteca estandar (+ git si
  esta).
- **Prueba nueva `tests/probar-empaquetado.sh`** (37 casos): ZIP limpio y
  entradas validas, bytecode y temporales plantados (con y sin git, tambien
  versionados) fuera, rutas con «@», espacio o no ASCII rechazadas, determinismo
  ante cambios de fechas y permisos, plantilla con el nombre nuevo y destino
  `buzz-hermes@.service` intacto en la guia.

## 1.2.1 — 2026-07-31 (ronda corta del auditor: 1 bug funcional + 2 verificaciones + no-divulgacion del gate)

Correcciones sobre la Entrega A tras revision corta del auditor. El bug 1 vive
en el binario buzz-acp; se corrige en el patch fuente y se redespliega por la
via de la Entrega B (sub-accion de binario del Paso 2 + re-verificacion). No es
regresion de seguridad: el binario desplegado sigue siendo estrictamente mejor
que el baseline; el fallo es una perdida de mensaje del salvavidas best-effort,
solo en turnos de LECTURA de notes.

- **Bug funcional (fallback-publisher, patch 01)**: `is_publishing_command`
  hacia `contains("buzz notes")` (substring pelado), con lo que las LECTURAS
  `buzz notes get`/`buzz notes ls` contaban como publicacion → en un turno de
  lectura el salvavidas creia que ya se habia publicado y NO posteaba la
  respuesta (mensaje perdido), contradiciendo lo declarado (get/ls no suprimen
  el salvavidas). Corregido a `buzz notes set` + `buzz notes rm` — las dos
  subordenes de ESCRITURA que existen en el CLI del pin `4a1ebf25`: `NotesCmd`
  expone `Set`/`Get`/`Ls`/`Rm` (`buzz/crates/buzz-cli/src/lib.rs:1029,:1094`).
  `buzz notes create` NO existe en el pin (era una suborden inventada en el fix
  de la primera vuelta; el auditor lo cazo en M1); `rm` publica una eliminacion
  NIP-09 (kind:5) y por tanto SI es publicacion. Consistente con los hermanos ya
  especificos (`messages send`, `canvas set`, `reactions add`). Un solo cambio
  cubre los DOS sitios de llamada: el stream y el tool-call handler comparten la
  funcion. Tests rojo/verde: positivos `buzz notes set …` y `buzz notes rm …`
  (deben suprimir el doble-post); negativos `buzz notes get`/`ls` (lecturas) y
  `buzz notes create` (no existe) — todos false. El caso `get` FALLA con el bug
  (`assertion failed: !is_publishing_command("buzz notes get")`) y PASA con el
  fix (verificado compilando la funcion extraida del export parcheado).
- **No-divulgacion del gate (tests/probar-antifugas.sh, M2)**: un gate
  anti-fugas que echa el secreto al log ES una fuga. Dos frentes:
  (a) `escanea_texto` imprimia la linea casada completa —el secreto— al log;
  ahora reporta solo etiqueta + nº de linea + tipo (NSEC/SK/HEX64), clasificado
  por prefijo, nunca el contenido. (b) El secreto tambien puede vivir en el
  NOMBRE de un fichero, y varios sitios imprimian RUTAS/etiquetas no confiables
  en claro: la etiqueta de `escanea_texto` (`untracked <nombre>`), las rutas de
  `veta_binarios` (numstat) y el echo de binario untracked. Se anade el filtro
  `redacta()` (sustituye NSEC/SK/HEX64 por marcadores con su tipo, NSEC/SK antes
  que HEX64) y se aplica a los tres sitios. DETECCION y REDACCION son patrones
  SEPARADOS: el detector `RE_SK` dispara por prefijo (`sk-lead`/`sk-hermes`),
  pero el redactor `RED_SK` consume el TOKEN COMPLETO (`sk-(lead|hermes)[A-Za-z0-9._-]*`)
  hasta un delimitador seguro — borrar solo el prefijo dejaba el sufijo visible y
  el prefijo reconstruible desde el marcador (fuga parcial cazada por el auditor
  en la 2a vuelta de M2). NSEC y HEX64 ya casaban el token entero. Fixture nuevo
  de no-divulgacion (`probar-antifugas-fixtures.sh` caso 4g): CAPTURA la salida
  del gate (el resto de casos la descarta) con secretos sinteticos en nombres de
  fichero staged y untracked (texto y binario), y verifica, en frentes
  INDEPENDIENTES del detector, que (i) sigue detectando (rc=1), (ii) la salida no
  matchea el regex detector, (iii) no aparece el valor sintetico completo y
  (iv) no aparece el sufijo distintivo de la credencial SK.
- **Verificacion 4 — hardening en maquina real (CORREGIDO)**: `montar.sh` no
  instala la flota hermes (es una extension documentada). La guia
  `references/extension-hermes.md` nombraba `buzz-hermes@.service.tmpl` +
  `hardening.conf` en prosa pero su bloque reproducible solo creaba usuario y
  workdir: NO renderizaba la plantilla ni instalaba el drop-in → el hardening
  declarado no se aplicaba siguiendo la guia al pie de la letra (en el servidor
  vivo se instalo a mano). Anadidos los comandos concretos: render de la
  plantilla a `/etc/systemd/system/buzz-hermes@.service`, `install` del drop-in
  a `…/buzz-hermes@.service.d/hardening.conf`, `daemon-reload` y verificacion
  (`systemctl cat`).
- **Verificacion 3 — ProtectHome (CONFIRMADO, sin cambio)**: `hardening.conf`
  `ProtectHome=read-only` es el endurecimiento pretendido, no un defecto: hermes
  debe LEER de /home (env/helpers/config) y nunca ESCRIBIR; `read-only` es el
  punto correcto — `yes` dejaria /home vacio para el proceso y romperia lecturas
  en runtime.

## 1.2.0 — 2026-07-31 (ronda de seguridad: 11 hallazgos, Entrega A)

Revision de seguridad externa (2 criticos + 9 mayores) + 4 rondas del
auditor sobre el plan (B1/B2, M1-M7) + reapertura de M4 (TOCTOU real) +
pasada CodeRabbit pre-push. Todos aceptados (el 5 parcial, justificado). La
aplicacion al servidor vivo es la Entrega B (separada).

- **Critico 1 (injection al publicar, B1/M4/M6/M7)**: la respuesta del
  modelo JAMAS viaja dentro de un comando. Nuevo `buzz-publicar`
  (scripts/publicar.sh): publica ./respuesta.txt por STDIN (--content -),
  consumo exclusivo por mv atomico (serializa turnos concurrentes — el
  segundo str_replace falla ruidoso, sin mezclas), trap EXIT que SIEMPRE
  resiembra el centinela, payload fallido preservado con nombre exclusivo
  0600 como evidencia autoritativa, rc!=0 para el rescate. Protocolo
  ejecutable con las herramientas REALES de buzz-dev-mcp (str_replace:
  fichero existente + old_str presente; sin escritura arbitraria). Patch 01:
  is_publishing_command reconoce buzz-publicar SOLO en posicion de comando
  (una mencion en texto no silencia el fallback); el fallback queda
  documentado como REARMADO y BEST-EFFORT. roles.py y
  extension-app-agents.md reescritos (app: archivo nuevo por turno con
  sufijo aleatorio + stdin; heredoc PROHIBIDO — terminacion anticipada).
  M4 (reapertura): el protocolo centinela NO tiene exclusion mutua propia
  (str_replace hace lectura->validacion->persistencia; dos turnos
  GENUINAMENTE paralelos sobre el mismo respuesta.txt se pisan). Demostrado
  con un fixture paralelo real (barrera: ambos leen antes de que ninguno
  persista, uno pisa al otro). Mitigacion ratcheteada: `BUZZ_ACP_AGENTS=1`
  fijado en hermes.env.tmpl (antes solo el default upstream, sin ratchet) —
  un subproceso por instancia serializa los turnos; subir el valor exige un
  CAS real (INV-TB-068). Endurecimiento (CodeRabbit pre-push): el payload de
  un envio fallido se preserva por RENOMBRADO atomico (mv, no cp — un cp a
  medias con set -e podia perder la evidencia), el `mv` de consumo verifica su
  estado antes de que el trap se arme, y se rechaza contenido compuesto solo
  de espacios en blanco (tabs/saltos, no solo espacio ASCII).
  probar-publicacion.sh: 21 casos (adversarial byte a byte, semantica real de
  la herramienta, concurrencia real con barrera, fallo transitorio, permisos,
  solo-espacios + autoridad del ratchet).
- **Critico 2 (merges invisibles)**: `git show` sin -m omite en el diff
  combinado denso lo que iguala a un padre — un merge que incorpora un
  secreto igualando al padre lateral pasaba LIMPIO (rojo demostrado contra
  el gate de main). Ahora `show -m` en contenido y numstat; fixture 4b.
- **H3 (usuario compartido)**: buzz-hermes@.service.tmpl con
  User/Group=hermesbot%i; layout padre 0711 root:root (travesia) + /N 0700
  por instancia con preflight cruzado (extension-hermes.md); pair-relay ya
  tenia DynamicUser. desmontar.sh con ciclo de vida M5: --purge trata los
  datos ANTES de borrar usuarios (--cuarentena archiva primero FUERA del
  arbol, tar 0600 root) y verifica cero restos del UID en las rutas
  gestionadas; sin --purge, usuarios y datos se conservan juntos. La
  creacion de usuarios/layout y la siembra del centinela por instancia es
  PROCEDIMIENTO DOCUMENTADO en extension-hermes.md (paso 4 del alta), no
  automatizacion de montar.sh — montar.sh solo instala el helper; la
  Entrega B lo ejecuta en el server.
- **H4 (default abierto)**: BUZZ_BIND_IP pasa a OBLIGATORIA en el patch 04
  (`:?`): sin la variable, compose falla explicito (el default abierto ya
  mordio en produccion). Verificado: 'BUZZ_BIND_IP is missing a value'.
- **H5 (SSRF, parcial justificado)**: guard upstream restaurado — RFC1918 +
  link-local rechazados para TODOS los esquemas en RelayUrlPolicy (rojo
  directo: wss://10.0.0.1 pasaba). La autoridad cleartext (MagicDNS +
  100.64/10) se mantiene: es la razon de ser del skill. IPv6
  privado/link-local, loopback extendido, resolucion DNS a redes privadas y
  DNS rebinding: follow-up declarado y aceptado por el auditor.
- **H6-7 (reconciliacion del .env)**: reconciliar_env + exigir_0600 en
  scripts/lib-seguridad.sh (compartido con movil.sh): el .env heredado se
  verifica 0600+dueño ANTES de tocarlo y se reconcilia el CONJUNTO de claves
  invariantes (BUZZ_IMAGE — cierra el bypass del pin M3 —, frontera,
  membership=true, URLs) por reescritura atomica conservando secretos byte a
  byte; HMAC con criterio 'exactamente una ocurrencia' (correccion del
  auditor: no habia duplicado). Falla cerrado ante claves DUPLICADAS en el
  heredado (dos HMAC = identidad ambigua; no se normaliza en silencio,
  INV-TB-069). Endurecimiento (CodeRabbit pre-push): los valores con salto
  de linea se rechazan (romperian el formato .env), los metacaracteres de
  sed (&, \, |) se escapan y el valor queda LITERAL, y cada comando critico
  (cp/sed/printf/chmod/mv) verifica su estado y aborta limpiando el temporal —
  la funcion se invoca a la izquierda de || y un fallo a medias no puede
  pasar por exito (todos los caminos de fallo, incluido el mv final, limpian
  el tmp). probar-reconcilia-env.sh: 18 casos (incluye inmutabilidad por
  huella completa — cmp byte a byte + modo/inode/dueño/mtime — en los caminos
  de rechazo, metacaracteres &/\/| literales, salto de linea, idempotencia por
  cmp sobre baseline anclada).
- **H8 (sonda no determinista)**: df fake determinista con TRES estados
  (suficiente/insuficiente/fallo de medicion), TB_TEST_DF=ok literal en los
  casos positivos y TMPDIR fijado; 3 corridas consecutivas identicas. El
  estado 'fallo' cazo un bug real: set -e + pipefail hacian INALCANZABLE la
  rama "no medible" de sonda.sh con un df roto — corregido.
- **H9 (cobertura del escaner)**: 4 casos nuevos (clave API en commit,
  hex64 staged, binario STAGED, secreto en NOMBRE de fichero) + el
  evil-merge, con literales compuestos en runtime.
- **H10 (interpolacion python3 -c, cierre del descarte de 1.0.5)**: ruta Y
  nombres por sys.argv en montar.sh y verificar.sh — una comilla en la ruta
  o el nombre ya no ejecuta codigo.
- **H11 (pin por prefijo)**: TB_BUZZ_COMMIT al SHA completo;
  probar-patches resuelve con rev-parse y compara el HEAD del arbol.
- Ratchet D6: INV-TB-047..069 (23 invariantes nuevas).

## 1.1.5 — 2026-07-30 (minors de CodeRabbit + decision de entrega)

- Decision del dueño registrada en movil.md: la Entrega 2 se publica SIN el
  ensayo interactivo de pairing; el estado NO RODADO queda declarado y la
  primera instalacion real que complete QR→SAS→conexion→DM debe actualizar
  la seccion con su resultado.
- movil.sh (minors CR): `strings` entra en los prerequisitos (V3/V3b lo
  usan de fallback); las opciones con valor (--host/--ip/--build-number/
  --fuente/--puerto) fallan explicito si el valor falta; ip_tailnet_valida
  exige 4 octetos por regex y compara en base 10 forzada (10#) — ceros
  iniciales ya no revientan ni se leen como octal.

## 1.1.4 — 2026-07-30 (cierre de los 2 findings de CodeRabbit sobre movil.sh)

- V1 separaba mal extraccion y conteo: si unzip fallaba DENTRO del pipe, el
  grep contaba 0 sobre un flujo truncado y el `|| true` lo tapaba — V1
  decia OK sin haber leido el APK. Ahora la extraccion va a fichero con rc
  verificado (fatal si unzip falla) y el conteo se hace sobre el fichero.
  INV-TB-045.
- inyectar_autoridad insertaba las IPs extra con un sed que, si no matchea,
  NO falla: una IP podia caerse del network security config en silencio y
  la plataforma rechazaria el cleartext hacia ella en runtime. Ahora cada
  insercion se verifica en el fichero (fail-closed, con fixture de ancla
  rota) y V3b confirma ademas cada IP declarada en los recursos del APK
  FINAL. INV-TB-046.

## 1.1.3 — 2026-07-30 (cierre M10 definitivo: el guard valida el conjunto FINAL)

- Revision 2: un roster compuesto SOLO por el autor superaba el guard de
  roster vacio (el self se excluye despues, en la normalizacion) y el DM
  salia con cero p-tags. El guard se MUEVE a despues de normalizar: si el
  conjunto final de p-tags de un DM queda vacio (lookup fallido, roster
  vacio o self-only), StateError y nada se publica. Test nuevo con roster
  self-only (cero publicacion, cero mensaje local). Patch 03 regenerado.

## 1.1.2 — 2026-07-30 (endurecimiento M10: roster vacio)

- El DM tambien falla cerrado cuando la consulta de miembros DEVUELVE VACIO
  (no solo cuando lanza): un roster vacio es tan inutilizable como un fallo
  de red — publicar produciria igualmente un DM sin p-tags. StateError
  explicito + test negativo (roster vacio => nada se publica ni se añade en
  local). Patch 03 regenerado.

## 1.1.1 — 2026-07-30 (cierre M9-M12, revision 1 de la Entrega 2)

- M9: retiradas las afirmaciones de pairing "rodado" de SKILL.md y
  movil.md. Nueva seccion obligatoria "Estado del ensayo de pairing" en
  movil.md (INV-TB-040): declara RODADO (build fresco V1-V4, portal con
  negativa real, Desktop 0.5.1 con sha256) y **NO RODADO** (QR → SAS →
  conexion → DM) — la compatibilidad del pairing se trata como NO
  VERIFICADA hasta registrar ahi la evidencia del ensayo. SKILL.md remite a
  esa seccion como unica fuente del estado.
- M10: un DM cuyos participantes no pueden determinarse ya NO se envia
  (fail-closed): el catch silencioso publicaba el DM sin p-tags y
  reproducia el defecto que el patch corrige. Test negativo: fetchMembers
  falla => el mensaje no se publica ni se añade en local. INV-TB-041.
- M11: --host ahora se ACREDITA como MagicDNS del tailnet
  (`host_acreditado`): *.ts.net y TODAS sus IPv4 resueltas dentro de
  100.64.0.0/10; sin resolucion no hay acreditacion. Fixtures: dominio
  publico rechazado, MagicDNS inexistente rechazado, positivo oportunista
  con el nombre propio del tailnet. INV-TB-042.
- M12: los secretos reutilizados se verifican antes de usarse
  (`exigir_0600`: propietario actual + modo 600, fail-closed) — tanto
  android-signing.env antes del source como el keystore que referencia.
  Fixtures 0600/0644/inexistente. INV-TB-043.
- Alta r9: el portal verifica que la IP de tailscale este en 100.64.0.0/10
  antes de abrir (INV-TB-044).
- Medias r9: --build-number pasa a OBLIGATORIO (un default repetiria
  versionCode sin que nadie lo note); eliminado el ultimo `echo | head` de
  V3 (coherencia con la doctrina anti-lectores-tempranos bajo pipefail).

## 1.1.0 — 2026-07-30 (Entrega 2: fase movil)

La fase movil deja de ser "PENDIENTE": APK Android propio, construido del
export limpio de pin+patches y verificado sobre el artefacto final.

- **Patch 02 (esquemas + autoridad de cleartext)**: normalizacion explicita
  `{http→ws, https→wss, ws→ws, wss→wss}` en la validacion de credenciales
  (el ternario upstream `https ? wss : ws` degradaba wss a ws — M1, con test
  de regresion) y autoridad UNICA de trafico en claro (`RelayUrlPolicy`):
  ws/http SOLO hacia el host MagicDNS exacto inyectado en build o IPs
  100.64.0.0/10; el resto en claro se rechaza (publicos, RFC1918,
  link-local); wss/https valen para cualquier host. La misma decision en dos
  capas desde UNA fuente: constante Dart + network_security_config.xml
  (cleartext OFF por defecto), ambas con placeholder que movil.sh rellena.
  Un placeholder sin sustituir no autoriza nada (contiene `_`, imposible en
  MagicDNS: fail-closed con test). Matriz de tests esquema×host (31 casos
  con los upstream adaptados a la politica).
- **Patch 03 (paridad de DMs)**: los DMs del movil p-taggean a todos los
  participantes (menos el autor), como el escritorio — sin eso los harnesses
  de agentes (filtrados por mencion) no ven DMs del movil. Tests de p-tags
  (DM si, no-DM no, sin duplicados, sin self).
- **movil.sh**: build desde `exportar_contexto_exacto` (M3), keystore propio
  0600 de nacimiento y REUTILIZADO (Android exige misma firma para
  actualizar), inyeccion validada (placeholder exactamente 1 vez por capa,
  host sin `_`, IPs solo 100.64/10) y verificacion fail-closed del APK
  final: V1 placeholder ausente, V2 manifest de la APP con network security
  config y sin cleartext global, V3 host presente en los recursos, V4
  huella del certificado == keystore. `portal` sirve el APK SOLO en la IP
  del tailnet. Guard de source (leccion INV-TB-002).
- Hallazgos del build real, corregidos y fijados en el script: (a) `find |
  head` y `grep -q` sobre pipes bajo pipefail convierten SIGPIPE en falso
  limpio/falso rojo — las verificaciones cuentan hasta EOF o leen de
  fichero (misma familia que el subshell M5 r4); (b) el primer manifest que
  devuelve un find global es el de una LIBRERIA Flutter, no el de la app;
  (c) la optimizacion de recursos de AGP RENOMBRA
  res/xml/network_security_config.xml (aparecio como 8G.xml) — V3 busca el
  host en res/ entero, no una ruta fija.
- **references/movil.md**: guia completa con Buzz Desktop **0.5.1** como
  dependencia VERSIONADA del pairing (el payload es un contrato
  escritorio-movil; "ultima release" no vale) y errores reales destilados.
- Suite movil upstream: 904 en verde, 1 fallo PRE-EXISTENTE en
  4a1ebf2 puro (channel_detail_page "keeps follow mode off...", tambien
  falla sin nuestros patches — dependiente del entorno de fuentes), 1 skip.
- Ratchet D6: INV-TB-030..039; INV-TB-009 pasa de "movil PENDIENTE" a
  "movil entregado con procedimiento" (SKILL.md actualizado en el mismo
  commit, como pactado en el GO de la Entrega 1).

## 1.0.7 — 2026-07-30 (cierre M8 + Alta, revision ronda 8)

- M8: buzz-agent representa el error de una herramienta como status
  "completed" + rawOutput.isError=true (emit_completed SIEMPRE reporta
  completed) — el rearme del fallback solo miraba failed/error y un
  `buzz messages send` fallido seguia perdiendo la respuesta. Helper puro
  `tool_update_is_failure` cubriendo AMBAS formas reales, con tests de
  transicion sobre el JSON literal (completed+isError:true => rearma;
  completed+isError:false => no). INV-TB-029.
- Alta r8: el bloqueo de aislamiento de Fenix se evalua AL INICIO de
  montar.sh (antes de checkout, identidades o relay): sin consentimiento no
  queda ni despliegue parcial.

## 1.0.6 — 2026-07-30 (re-revision de CodeRabbit: 3 hallazgos, 3 cerrados)

- Patch 01: la INVOCACION del comando publicador ya no basta — si su
  tool_call_update reporta failed/error, la pretension de publicacion se
  retira y el fallback rescata el turno; sin noticia del resultado se asume
  exito (default seguro contra duplicados). Rodado en produccion.
- Aislamiento de Fenix convertido en BLOQUEO explicito de instalacion:
  montar.sh se niega salvo TB_FENIX_AISLAMIENTO=acepto-home-compartido
  (consentimiento informado que SKILL.md obliga a preguntar, fase 3;
  INV-TB-028). El aislamiento con cuenta dedicada sigue como follow-up.
- probar-sonda: el caso sin-cc restaura docker antes, aislando de verdad la
  ausencia de cc del orden de comprobaciones de la sonda.

## 1.0.5 — 2026-07-30 (cierre de los hallazgos de CodeRabbit, PR #22)

Accionables (10/10 tratados):
- Patch 01 endurecido: deteccion de comandos publicadores normalizada por
  espacios y continuaciones de linea (helper puro `is_publishing_command` con
  tests); el fallback SOLO dispara en turnos EndTurn (nunca con narracion
  parcial de turnos cancelados/limitados); eliminado el bufer muerto de
  thought; `fallback_publish_enabled` recolocada fuera del doc-comment de
  `publish_agent_turn_metric` (recupera su doc).
- montar.sh: pin comparado por SHA RESUELTO (admite corto/largo/tag);
  BUZZ_BIND_IP reconciliado siempre que se conserve un .env preexistente
  (la frontera M2 es invariante); .env con escritura atomica; reversa de
  patches en orden inverso.
- desmontar.sh: `systemctl disable` no expande globs — instancias hermes
  enumeradas; --purge elimina tambien plantilla hermes y buzz-panic (mensaje
  honesto).
- make-conexion.py: fchmod(0600) explicito (O_TRUNC no reaplica modo).
- sonda.sh: espacio en disco medido sobre el ancestro existente, distinguiendo
  "sin espacio" de "ruta no medible".
- verificar.sh: V3a/V3c con IP escapada y anclada; V5 fail-closed (claves y
  fenix.env obligatorios); linea no-op eliminada.
- buzz-claude.service.tmpl + seguridad.md: CLAUDE.md/settings.json declarados
  como POLITICA, no aislamiento; el aislamiento real (cuenta dedicada,
  ProtectHome, ReadWritePaths) queda como follow-up explicito.
- Tests: caso negativo de cc en la sonda; probar-genkeys ya no aborta al fallar
  la coherencia (acumula); probar-patches falla explicito si el worktree no se
  crea. README: el contador del manifiesto decia 12.

Descartados con motivo: interpolacion python3 -c (rutas internas controladas,
sin input externo) · buzz-panic start sobre unidades cargadas (las unidades
van enabled; irrelevante para un freno) · comillas en .env (el formato .env de
compose no las lleva; los valores generados son hex/URL sin espacios) · linea
informativa del fixture .gitignore (por diseno).

## 1.0.4 — 2026-07-30 (hallazgos del ensayo e2e en VM fresca)

Ensayo end-to-end RODADO en VM KVM fresca (Ubuntu 24.04 cloud, sin nada
preinstalado): sonda -> montar -> verificar (10 evidencias, prueba negativa de
frontera REAL entre interfaz NAT y tailnet) -> mencion a Fenix respondida en
11s -> desmontaje con claves intactas (sha256 identico). Dos hallazgos, ambos
corregidos y convertidos en doctrina:

- La sonda no exigia el toolchain C: cargo moria a mitad de montaje en una
  maquina fresca ("could not compile ... build script"). Ahora `need_cmd cc`
  (INV-TB-027) + fake en probar-sonda.
- verificar.sh solo aceptaba `host_ip` con comillas en el render de compose;
  las versiones actuales lo emiten sin comillas. Grep tolerante a ambas.

## 1.0.3 — 2026-07-30 (revision ronda 6: fixture determinista, pre-merge)

- M5: el fixture binario usaba /dev/urandom (256 bytes sin NUL con ~37% de
  probabilidad -> falso limpio aleatorio). Ahora es determinista con bytes NUL
  explicitos (la senal exacta de la heuristica binaria de Git). Evidencia: 20
  repeticiones consecutivas TODO OK.
- Alta r6: la sonda exige `tar` (lo necesita lib-contexto para extraer el
  archive del contexto de imagen).
- Baja r6: exportar_contexto_exacto emite mensaje propio si archive|tar falla.
- Ratchet D6: INV-TB-025..026.

## 1.0.2 — 2026-07-30 (cierre M3 definitivo, revision ronda 5, pre-merge)

- M3: la imagen se construye desde un EXPORT LIMPIO de commit+patches
  (`git archive` a tmpdir, `scripts/lib-contexto.sh`), nunca desde el checkout
  de trabajo. Los IGNORADOS (.hermit/, que `git status --porcelain` ni muestra
  y .dockerignore no excluye) y los untracked quedan fuera del contexto POR
  CONSTRUCCION, no por inspeccion. La puerta de reversa exacta se mantiene
  para los binarios host. Fixture `tests/probar-contexto-imagen.sh`: prueba el
  MISMO mecanismo con un repo contaminado (ignorado .hermit, ignorado extra,
  untracked, drift rastreado) y las guardas (destino no vacio, patch que no
  aplica).
- Alta r5: el gate M5 falla explicito (rc=2) si la base no existe — antes un
  error de base se convertia en "sin commits" y el gate quedaba vacio en
  silencio. Fixture nuevo.
- Ratchet D6: INV-TB-022..024.

## 1.0.1 — 2026-07-30 (cierres de la revision ronda 4, pre-merge)

- M2: modo dominio arranca Caddy de verdad (BUZZ_COMPOSE_TLS=true literal, lo
  que run.sh compara) y verificar.sh verifica POR MODO: caddy activo, relay sin
  puertos host, mismo conjunto compose que el arranque, readiness https real.
- M3: fail-closed de arbol exacto — reversa total de los patches sobre el
  checkout: si no queda identico al commit (drift o untracked no tolerado), no
  se construye imagen. Untracked tolerado: solo target/ y solo si .dockerignore
  lo excluye del contexto.
- M5: el gate anti-fugas alimentaba sus funciones por pipeline (subshell →
  contador perdido → LIMPIO con hallazgos). Ahora process substitution +
  fixtures negativos obligatorios (secreto staged, secreto en commit intermedio
  tapado, binario, untracked con espacios) que exigen rc=1.
- M6: la ruta de claude-agent-acp se resuelve tras instalarla y se inyecta en
  fenix.env (@CLAUDE_ACP@); tambien se corrige en re-ejecuciones.
- M7: add-member sin || true; verificar.sh exige owner y fenix en el roster
  (list-members) y BUZZ_AUTH_TAG presente y no-pendiente antes del OK.
- Medias: contenedores por `docker compose ps -q` (labels, no nombre),
  coherencia criptografica real en probar-genkeys (bech32 decodificado ==
  hex, pubkey derivada de la privada), .gitattributes para el falso trailing
  whitespace de los .patch, flag de exito en el loop de readiness.
- Ratchet D6: 7 invariantes nuevas (INV-TB-015..021), una por hallazgo.

## 1.0.0 — 2026-07-30

Alta como 14.º miembro del paquete (Entrega 1: nucleo).

- Nucleo: relay block/buzz pinneado a 4a1ebf2 con imagen construida en local
  (M3), Fenix (Claude) como servicio systemd con workdir gobernado, pair-relay
  confinado, identidades frescas por instalacion (genkeys 0600, se niega a
  sobrescribir), frenos (buzz-panic + kill switches).
- Frontera de red (M2): BUZZ_BIND_IP (patch 04) + verificacion por 4 vias con
  prueba negativa desde otra interfaz.
- Patch 01: salvavidas de publicacion para harnesses de modelo local
  (buzz-agent/hermes), con tests Rust del contrato; el razonamiento nunca se
  publica.
- Gate anti-fugas M5: escaneo de staged+untracked antes de cada commit y de
  TODOS los commits de la rama antes del push, con veto de binarios.
- Extensiones documentadas: hermes (cerebro via talent-llm-local o endpoint
  OpenAI-compatible) y agentes de la app de escritorio.
- Fase movil: DIFERIDA a Entrega 2 (patches Android/Dart, keystore, Desktop
  0.5.1, ensayo de pairing fresco).

## Fix de estación (2026-07-31) — 5 findings reales de CR en el gate del vehículo #1429

Aplicados por la estación (CEO de fábrica) citando el ledger del Mergeador
(`M2-1429R8-GATE1-RED-9-FINDINGS…`, 22:48Z 30-jul) para desbloquear la propagación;
la línea autora los ratifica o refina en su próxima entrega:

- `buzz-panic`: el freno MIDE el rc del stop y verifica por `is-active` — jamás reporta
  «PARADOS» con agentes vivos; fallo ⇒ lista de vivos + exit 1.
- `roles.py` `set_key`: escritura ATÓMICA del `.env` (temporal en el mismo dir + fsync +
  `os.replace`), permisos/dueño del original preservados.
- `make-conexion.py`: `O_NOFOLLOW` al abrir el runbook de claves (anti-symlink).
- `montar.sh`: `TB_FENIX_USER` validado con `getent` ANTES de renderizar el unit
  (un usuario inexistente fallaba tarde con un unit inválido).
- `01-fallback-publisher.patch`: `is_publishing_command` distingue verbos de escritura
  (`buzz notes set|rm`, las dos escrituras del pin `4a1ebf25`; `create` NO existe en el
  CLI) de lecturas (`get`/`ls` ya no suprimen el salvavidas); asserts nuevos de la clase;
  line-counts de los hunks recalculados (`git apply --stat` verde). Ver 1.2.1 para el
  detalle del bug y su rojo/verde.

PENDIENTE DEL AUTOR (no tocado): el finding de `genkeys.py` (secp256k1 hand-rolled vs
libsecp256k1) es best-practice debatible — `probar-genkeys.sh` PASA con outputs BIP340
correctos; la adjudicación (accept-fix o reject-con-razón) es de la línea buzz.
