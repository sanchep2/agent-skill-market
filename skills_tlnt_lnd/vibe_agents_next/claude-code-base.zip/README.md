# Plantilla base — CLAUDE.md + AGENTS.md

Plantilla lista para arrancar Claude Code en tu proyecto con disciplina profesional desde el
día uno. Contiene las reglas de trabajo que marcan la diferencia entre "la IA me escribió algo"
y un proyecto mantenible: modo plan, verificación real, flujo por ramas, memoria de errores y
seguridad de datos.

## Qué incluye

| Archivo | Qué es | Quién lo lee |
|---------|--------|--------------|
| `CLAUDE.md` | Fuente de verdad del proyecto: reglas, stack, comandos, errores | Claude Code |
| `AGENTS.md` | Resumen operativo espejo, sincronizado con `CLAUDE.md` | Codex, Cursor y otros agentes |

## Instalación (3 pasos)

1. **Copia** `CLAUDE.md` y `AGENTS.md` a la RAÍZ de tu repositorio.
2. **Rellena** los marcadores `<ASÍ>` con los datos de tu proyecto (nombre, stack, comandos,
   tracker) y borra las notas de plantilla (las citas que explican cómo llenar cada sección).
3. **Crea la memoria**: carpeta `.claude/memory/` con dos archivos vacíos, `MEMORY.md` y
   `gotchas.md`. Haz commit de todo.

Desde ese momento, Claude Code leerá `CLAUDE.md` automáticamente al abrir el proyecto.

## Cómo sacarle el máximo

- **Mantenlo vivo**: cada vez que cambies de stack, comandos o reglas, actualiza `CLAUDE.md`
  en el mismo PR que el cambio. Un archivo desactualizado hace que el agente confíe en
  información falsa.
- **Alimenta `gotchas.md`**: cada error de sesión se registra con fecha, causa raíz y regla
  preventiva. Cuando un patrón se repite 3+ veces, promuévelo a la sección «Errores Críticos»
  de `CLAUDE.md`. Así el agente deja de repetir los mismos tropiezos.
- **Sincroniza los dos archivos**: toda regla nueva nace en `CLAUDE.md` y se refleja después
  en `AGENTS.md`. Si divergen, gana `CLAUDE.md`.
- **Complementa con skills**: instala en `.claude/skills/` los skills de tu stack (los tienes
  disponibles en la sección de Recursos) y lista cuándo cargarlos en la tabla «Skills por
  Dominio».
