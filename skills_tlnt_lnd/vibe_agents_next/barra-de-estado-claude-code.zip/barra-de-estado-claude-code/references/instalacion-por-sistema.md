# Instalación por sistema

## Table of Contents

- [1. Antes de empezar](#1-antes-de-empezar)
- [2. macOS](#2-macos)
- [3. Linux](#3-linux)
- [4. Windows](#4-windows)
- [5. Qué escribe el instalador](#5-qué-escribe-el-instalador)
- [6. Probar sin abrir Claude Code](#6-probar-sin-abrir-claude-code)
- [7. Desinstalar](#7-desinstalar)
- [8. Problemas frecuentes](#8-problemas-frecuentes)

## 1. Antes de empezar

```text
¿Tienes Claude Code instalado y has entrado con /login al menos una vez?
   │ no → instala Claude Code, abre `claude`, inicia sesión, cierra. Luego vuelve aquí.
   │ sí
¿`node --version` responde 18 o superior?
   │ no → Claude Code ya lo exige; si no está en el PATH de esa terminal, abre una nueva.
   │ sí
node scripts/instalar.js  →  reinicia Claude Code  →  la barra aparece tras la primera respuesta
```

Lo único que necesita el instalador es la carpeta de configuración de Claude Code: `~/.claude`
o, si la has movido, la que indique `CLAUDE_CONFIG_DIR`. Si esa carpeta no existe, se detiene
y te lo dice.

## 2. macOS

```bash
cd barra-de-estado-claude-code
node scripts/instalar.js
```

El script lee el token de la sesión desde el Llavero (`security find-generic-password -s
"Claude Code-credentials" -w`). Es la misma entrada que crea Claude Code al iniciar sesión.
No hace falta permitir nada: `security` la lee con tu usuario, sin diálogo, en el mismo Mac
donde iniciaste sesión.

Si el Llavero está bloqueado (sesión por SSH, por ejemplo), Claude Code guarda la credencial en
`~/.claude/.credentials.json` y el script la lee de ahí.

## 3. Linux

```bash
cd barra-de-estado-claude-code
node scripts/instalar.js
```

El token vive en `~/.claude/.credentials.json` (modo `0600`, solo tu usuario). Si usas
`CLAUDE_CONFIG_DIR`, el script mira dentro de esa carpeta. En WSL es igual que en Linux.

## 4. Windows

```powershell
cd barra-de-estado-claude-code
node scripts\instalar.js
```

Detalles que importan en Windows:

- Claude Code ejecuta la barra por **Git Bash** si está instalado y por **PowerShell** si no. En
  los dos casos el comando `node "C:/Users/<tú>/.claude/statusline.js"` funciona.
- La ruta va **con barras normales** y entre comillas. Git Bash trata las barras invertidas como
  escapes y la barra desaparece sin error; por eso el instalador nunca escribe `C:\...`.
- El token vive en `%USERPROFILE%\.claude\.credentials.json`, protegido por los permisos de tu
  carpeta de usuario. El script lo lee de ahí (no usa el Administrador de credenciales).
- Windows Terminal muestra los colores ANSI; la consola clásica `cmd.exe` puede no hacerlo.

## 5. Qué escribe el instalador

```text
~/.claude/statusline.js                 ← copia del script (se sobrescribe al reinstalar)
~/.claude/settings.json                 ← se añade o sustituye la clave statusLine
~/.claude/settings.json.bak-<fecha>     ← copia de seguridad del settings anterior
```

Contenido exacto de la clave (ruta de ejemplo en macOS):

```json
{
  "statusLine": {
    "type": "command",
    "command": "node \"/Users/tu-usuario/.claude/statusline.js\"",
    "refreshInterval": 60
  }
}
```

`refreshInterval: 60` hace que la barra se vuelva a dibujar cada minuto aunque Claude esté en
reposo, para que la cuenta atrás de los límites no se congele. El resto de claves de tu
`settings.json` no se tocan. Con `--dry-run` ves todo esto sin escribir nada.

## 6. Probar sin abrir Claude Code

Cualquier sistema, misma orden (en PowerShell usa comillas dobles fuera y simples dentro o guarda el JSON en un archivo):

```bash
echo '{"cwd":"/tmp","model":{"display_name":"Fable 5.1"},"effort":{"level":"high"},"context_window":{"used_percentage":31,"total_input_tokens":310000},"rate_limits":{"five_hour":{"used_percentage":39,"resets_at":1788316800},"seven_day":{"used_percentage":8,"resets_at":1788476400}}}' | node ~/.claude/statusline.js
```

Debe imprimir una línea con colores. Si el último tramo (`Fable7d:…`) no aparece, mira
`references/uso-por-modelo.md`: lo normal es que no haya sesión iniciada en esa máquina o que el
plan no tenga ventanas por modelo.

Para ver el JSON de uso crudo:

```bash
node ~/.claude/statusline.js --usage
```

## 7. Desinstalar

```bash
node scripts/instalar.js --uninstall
```

Quita la clave `statusLine` (con copia de seguridad) y deja el script en `~/.claude` por si lo
quieres volver a activar. Reinicia Claude Code.

## 8. Problemas frecuentes

| Síntoma | Causa | Arreglo |
|---|---|---|
| No aparece ninguna barra | `settings.json` no tiene la clave, o Claude Code no se reinició | `node scripts/instalar.js` y reiniciar `claude` en esa terminal |
| No aparece y estás en Windows | Ruta con `\` en `settings.json` | Sustituir por `/` o volver a correr el instalador |
| Solo sale carpeta, rama y modelo | Aún no hay primera respuesta en la sesión | Escribe algo a Claude; `ctx`, `effort` y límites llegan después |
| No sale `5h`/`7d` nunca | Cuenta que no es Pro/Max (equipo, Console, clave de API) | Es esperado; `/usage` sigue funcionando |
| No sale `Fable7d` | Sin sesión iniciada, token viejo, plan sin ventanas por modelo, o cortacircuitos abierto | `node ~/.claude/statusline.js --usage` te dice qué pasa; `--clear-cache` tras `/login` |
| Sale `·stale` | La caché tiene más de 15 min y la red o el endpoint fallan | Se arregla solo al recuperarse; si persiste, mira el 429 en `uso-por-modelo.md` |
| La barra va a tirones | `gh pr view` tarda | `export CLAUDE_STATUSLINE_NO_PR=1` |
| El instalador dice que `settings.json` no es JSON | Archivo editado a mano con errores | Corregirlo (una coma de más es lo habitual) y reinstalar |
