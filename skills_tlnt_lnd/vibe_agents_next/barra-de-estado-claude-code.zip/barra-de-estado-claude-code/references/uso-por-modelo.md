# Uso por modelo: el endpoint, el token y la caché

## Table of Contents

- [1. Por qué hace falta un endpoint aparte](#1-por-qué-hace-falta-un-endpoint-aparte)
- [2. El endpoint](#2-el-endpoint)
- [3. El token, por sistema](#3-el-token-por-sistema)
- [4. Caché y cortacircuitos](#4-caché-y-cortacircuitos)
- [5. Errores y qué hacer](#5-errores-y-qué-hacer)
- [6. Seguridad](#6-seguridad)

## 1. Por qué hace falta un endpoint aparte

El JSON que Claude Code pasa a la barra trae dos ventanas de la cuenta: `five_hour` y
`seven_day`. No trae el consumo **por modelo** (la ventana semanal específica de Fable, de Opus
o de Sonnet). Ese dato existe en la cuenta y es el que muestra `/usage`; para tenerlo en la
barra hay que pedírselo al mismo servicio que consulta `/usage`.

```text
JSON de la barra ──▶ 5h y 7d de la cuenta            (lo manda Claude Code)
endpoint de uso  ──▶ ventanas por modelo + las mismas 5h/7d   (lo pide este script, con caché)
```

## 2. El endpoint

```text
GET https://api.anthropic.com/api/oauth/usage
Authorization: Bearer <accessToken OAuth de la sesión>
anthropic-beta: oauth-2025-04-20
Accept: application/json
```

Respuesta (resumen de lo que el script usa; verificado 2026-09-01 en una cuenta Max):

```json
{
  "five_hour": { "utilization": 39, "resets_at": "2026-09-02T02:39:59Z" },
  "seven_day": { "utilization": 8,  "resets_at": "2026-09-03T22:59:59Z" },
  "limits": [
    { "kind": "session",       "percent": 39, "resets_at": "2026-09-02T02:39:59Z" },
    { "kind": "weekly_all",    "percent": 8,  "resets_at": "2026-09-03T22:59:59Z" },
    { "kind": "weekly_scoped", "percent": 13, "resets_at": "2026-09-03T22:59:59Z",
      "scope": { "model": { "display_name": "Fable" } } }
  ]
}
```

El script recorre `limits[]` y muestra **todas** las entradas con `kind = "weekly_scoped"`, con
el nombre del modelo sin espacios seguido de `7d`: `Fable7d:13%(rst 1d23h)`. Si el plan tiene
varias ventanas por modelo, salen todas seguidas. Si no tiene ninguna, el tramo no aparece.
`resets_at` llega en ISO 8601 (UTC) y se convierte a cuenta atrás.

Otras claves del JSON (`seven_day_opus`, `seven_day_sonnet`, `extra_usage`, `spend`…) existen
y cambian entre planes; el script no depende de ellas. `node ~/.claude/statusline.js --usage`
imprime el JSON completo por si quieres mostrar otra.

## 3. El token, por sistema

| Sistema | Dónde guarda Claude Code la credencial | Cómo la lee el script |
|---|---|---|
| macOS | Llavero, entrada `Claude Code-credentials`; si el Llavero rechaza la escritura (SSH), `~/.claude/.credentials.json` | `security find-generic-password -s "Claude Code-credentials" -w` → JSON con `claudeAiOauth.accessToken`; si falla, el archivo |
| Linux / WSL | `~/.claude/.credentials.json` (modo 0600) | Lee el archivo |
| Windows | `%USERPROFILE%\.claude\.credentials.json` (permisos de tu carpeta de usuario) | Lee el archivo |
| Cualquiera con `CLAUDE_CONFIG_DIR` | La misma estructura dentro de esa carpeta | Mira primero `CLAUDE_CONFIG_DIR` |

Fuente: doc oficial de autenticación de Claude Code, sección *Credential management* (2026-09-01).

Claude Code renueva ese token solo; el script siempre lee el valor actual, nunca lo copia a
ningún sitio.

## 4. Caché y cortacircuitos

```text
archivo de caché:        <tmp del sistema>/claude-statusline-usage.json   (modo 0600)
archivo de cortacircuitos: <tmp del sistema>/claude-statusline-usage.breaker

cada refresco de la barra:
  caché con < 5 min   → se usa tal cual (cero red)
  cortacircuitos < 10 min desde el último fallo → se usa la caché vieja
  si no → GET al endpoint (máx. 8 s)
      200 → caché nueva, cortacircuitos cerrado
      error, timeout o 429 → cortacircuitos abierto 10 min, caché vieja
  caché > 15 min → el tramo lleva «·stale» para que sepas que es viejo
```

`<tmp del sistema>` es `os.tmpdir()` de Node: `/tmp` o `/var/folders/...` en macOS, `/tmp` en
Linux, `%TEMP%` en Windows. La caché contiene solo el JSON de uso, nunca el token.

## 5. Errores y qué hacer

| Situación | Qué ves | Qué hacer |
|---|---|---|
| Sin sesión iniciada en esa máquina | No sale el tramo por modelo; `--usage` dice «sin datos de uso» | `claude` → `/login` |
| Token de `claude setup-token` | `--usage` sin datos, cortacircuitos abierto por 429 | Ese tipo de token no puede consultar el endpoint; usa la sesión normal |
| Cambiaste de cuenta con `/login` | La barra muestra la cuenta anterior hasta 5 min | `node ~/.claude/statusline.js --clear-cache` |
| Red caída | `·stale` tras 15 min | Se recupera solo; el cortacircuitos reintenta cada 10 min |
| 429 del endpoint | `·stale` | Estás llamando demasiado (¿otra barra o script en paralelo?); no bajes los tiempos de caché |
| Plan sin ventanas por modelo | Nunca sale el tramo; `--usage` muestra `limits[]` sin `weekly_scoped` | Es esperado; 5h/7d siguen saliendo |

## 6. Seguridad

- El token de acceso **nunca** se imprime, ni en la barra ni en `--usage` (que solo muestra la respuesta del endpoint).
- El token viaja solo al dominio oficial de Anthropic, por HTTPS, con la cabecera que Claude Code usa para el mismo fin.
- La caché lleva modo `0600` en macOS y Linux; en Windows hereda los permisos de tu `%TEMP%`.
- El script no escribe en ningún sitio más que la caché y, durante la instalación, en `~/.claude`.
- Si compartes la máquina, recuerda que quien pueda leer tu `~/.claude/.credentials.json` ya tiene tu sesión de Claude Code: este script no añade ni quita riesgo ahí.
