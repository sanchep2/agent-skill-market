# Formato y campos

## Table of Contents

- [1. Los tramos de la barra](#1-los-tramos-de-la-barra)
- [2. Colores](#2-colores)
- [3. El JSON que manda Claude Code](#3-el-json-que-manda-claude-code)
- [4. Personalizar](#4-personalizar)
- [5. Cuándo se vuelve a dibujar](#5-cuándo-se-vuelve-a-dibujar)

## 1. Los tramos de la barra

```text
Talent Academy 2026 | ⎇main | PR #12 | Fable 5.1 | effort:high | ctx:31%(310000) | 5h:39%(rst 2h57m) 7d:8%(rst 1d23h) | Fable7d:13%(rst 1d23h)
└──── carpeta ─────┘ └rama─┘ └─ PR ─┘ └─modelo─┘ └─ effort ──┘ └─ contexto ────┘ └──── límites de la cuenta ────────┘ └── por modelo ──────┘
```

| Tramo | De dónde sale | Cuándo aparece |
|---|---|---|
| Carpeta | `cwd` del JSON (solo el nombre, no la ruta) | Siempre |
| `⎇rama` | `git rev-parse --abbrev-ref HEAD` en esa carpeta | Si es un repositorio git |
| `PR #n` | `pr.number` del JSON si Claude Code lo manda; si no, `gh pr view` | Si hay PR abierto para la rama |
| Modelo | `model.display_name` | Siempre |
| `effort:x` | `effort.level` | Si el modelo admite effort (tras la primera respuesta) |
| `ctx:31%(310000)` | `context_window.used_percentage` y `total_input_tokens` | Tras la primera respuesta |
| `5h:39%(rst 2h57m) 7d:8%(rst 1d23h)` | `rate_limits.five_hour` y `seven_day` | Cuentas Pro/Max, tras la primera respuesta |
| `Fable7d:13%(rst 1d23h)` | Endpoint de uso de la cuenta (ver `uso-por-modelo.md`) | Si el plan tiene ventanas por modelo |

`rst` = tiempo hasta que se reinicia esa ventana: `2h57m` si falta menos de un día, `1d23h` si falta más.

## 2. Colores

| Tramo | Color ANSI | Motivo |
|---|---|---|
| Carpeta | azul (`34`) | Ubicación |
| Rama | cian (`36`) | Git |
| PR | magenta (`35`) | Revisión |
| Modelo y effort | amarillo (`33`) | Lo que decide el coste por respuesta |
| Contexto | verde (`32`) | Va creciendo dentro de la sesión |
| Límites 5h/7d | rojo (`31`); **rojo intenso** (`1;31`) si cualquiera pasa del 80 % | Lo que te puede parar |
| Por modelo | magenta (`35`) | Dato externo a la sesión |
| Separador ` \| ` | atenuado (`2`) | Ruido mínimo |

Los códigos viven en la constante `C` al principio de `statusline.js`.

## 3. El JSON que manda Claude Code

Campos que usa este script (los demás se ignoran). Todos pueden faltar: el script no falla si no están.

```json
{
  "cwd": "/ruta/actual",
  "model": { "id": "claude-fable-5-1", "display_name": "Fable 5.1" },
  "effort": { "level": "high" },
  "context_window": { "used_percentage": 31, "total_input_tokens": 310000 },
  "rate_limits": {
    "five_hour": { "used_percentage": 39, "resets_at": 1788316800 },
    "seven_day": { "used_percentage": 8, "resets_at": 1788476400 }
  },
  "pr": { "number": 12 }
}
```

- `resets_at` viene en segundos desde la época Unix (UTC).
- `rate_limits` solo llega en cuentas Pro/Max de claude.ai y después de la primera respuesta de la sesión; cada ventana puede faltar por separado, y Claude Code retira una ventana cuando pasa su `resets_at`.
- `context_window.used_percentage` cuenta solo tokens de entrada (incluida la caché); `total_input_tokens` es el tamaño de lo que hay en la ventana ahora mismo.
- Tabla completa de campos en la doc oficial: `https://code.claude.com/docs/en/statusline`, sección *Available data*.

## 4. Personalizar

Sin tocar código, con variables de entorno en tu shell (`export VAR=valor` en bash/zsh, `$env:VAR="valor"` en PowerShell):

| Variable | Efecto |
|---|---|
| `CLAUDE_STATUSLINE_BRANCH_ICON=""` | Sin icono antes de la rama (o pon el glifo que prefieras, por ejemplo uno de Nerd Font) |
| `CLAUDE_STATUSLINE_NO_PR=1` | No consulta `gh`; desaparece el tramo PR |
| `CLAUDE_STATUSLINE_NO_USAGE=1` | No consulta el endpoint de uso; desaparece el tramo por modelo |

Cambios en el código (es un solo archivo, `~/.claude/statusline.js`):

- **Orden de los tramos**: función `render()`; cada `parts.push(...)` es un tramo, en el orden en que aparecen.
- **Umbral del rojo intenso**: `if (pct >= 80) alert = true;`.
- **Separador**: última línea de `render()`, `color(C.dim, ' | ')`.
- **Segunda línea**: la barra admite varias líneas; devuelve `linea1 + '\n' + linea2` desde `render()`.

Después de editar, prueba con el JSON simulado (`instalacion-por-sistema.md` §6). Claude Code recarga el script solo en el siguiente refresco.

## 5. Cuándo se vuelve a dibujar

Claude Code vuelve a ejecutar el script:

- al empezar o reanudar la sesión;
- con cada respuesta nueva, al terminar `/compact`, al cambiar el modo de permisos o el modo vim;
- cuando una ventana de límites llega a su `resets_at`;
- cada `refreshInterval` segundos (el instalador pone 60).

Los cambios se agrupan en 300 ms y, si llega otro refresco mientras el script corre, el anterior se cancela. Por eso el script nunca espera a la red más de 8 segundos y usa caché para el endpoint de uso.
