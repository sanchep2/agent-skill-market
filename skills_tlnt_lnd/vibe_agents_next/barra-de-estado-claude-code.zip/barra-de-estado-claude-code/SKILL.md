---
name: barra-de-estado-claude-code
description: Instala y configura la barra de estado de Claude Code (statusline, status line, status bar) en macOS, Linux y Windows con un solo script en Node.js — carpeta, rama git, PR abierto, modelo, effort, contexto usado con tokens, límites de 5 horas y 7 días con cuenta atrás, y el consumo semanal por modelo (Fable, Opus, Sonnet) leído del endpoint de uso de la cuenta con el token OAuth de la sesión. Úsalo cuando el usuario pida «barra de estado», «statusline», «status line», «ver el uso de mi plan en la terminal», «cuánto llevo gastado de Fable», «rate limits en la barra», «context window en la barra», «configurar /statusline», «instalar la barra de la academia», «status bar Claude Code», «usage limits statusline», «weekly usage per model», «settings.json statusLine», o quiera personalizar, desinstalar o arreglar la barra («no sale», «no aparece», «stale», «429»).
---

# Barra de estado de Claude Code — con consumo por modelo

## Quick Orientation

Este skill deja la barra de estado de Claude Code así, en cualquier sistema:

```text
Talent Academy 2026 | ⎇main | PR #12 | Fable 5.1 | effort:high | ctx:31%(310000) | 5h:39%(rst 2h57m) 7d:8%(rst 1d23h) | Fable7d:13%(rst 1d23h)
```

Todo lo que hay a la izquierda del último tramo lo manda Claude Code por sí mismo. El último
tramo —el **consumo semanal por modelo**— no está en el JSON de la barra: el script lo lee del
endpoint de uso de la cuenta con el token de la sesión iniciada, lo cachea y lo muestra.

| Componente | Valor | Verificado |
|---|---|---|
| Runtime | Node.js >= 18 (el mismo que exige Claude Code; sin jq, sin Python) | 2026-09-01 |
| Claude Code | >= 2.1.251 para todos los campos usados (`rate_limits`, `effort`); probado en 2.1.257 | 2026-09-01 |
| Sistemas | macOS (Llavero), Linux y Windows (`~/.claude/.credentials.json`); respeta `CLAUDE_CONFIG_DIR` | 2026-09-01 |
| Fuente del consumo por modelo | `GET https://api.anthropic.com/api/oauth/usage` con `Authorization: Bearer <token OAuth>` y `anthropic-beta: oauth-2025-04-20` | 2026-09-01 |
| Caché | 5 min en el directorio temporal del sistema · `·stale` pasados 15 min · cortacircuitos de 10 min tras un fallo | — |
| Cuentas | El tramo de 5h/7d solo lo manda Claude Code en cuentas Pro/Max de claude.ai; el tramo por modelo solo existe si el plan tiene ventanas por modelo | 2026-09-01 |

**Fuentes oficiales (2026-09-01):** barra de estado y campos del JSON
`https://code.claude.com/docs/en/statusline` · dónde vive la credencial por sistema
`https://code.claude.com/docs/en/authentication` (sección *Credential management*).

## Reference Files

| Tema | Archivo | Cuándo leerlo |
|---|---|---|
| Instalación paso a paso por sistema, `settings.json`, prueba sin abrir Claude, desinstalar, problemas frecuentes | `references/instalacion-por-sistema.md` | Al instalar o cuando «no sale» |
| Qué significa cada tramo, colores, campos del JSON de Claude Code, cómo personalizar el orden y los iconos | `references/formato-y-campos.md` | Al personalizar la barra |
| De dónde sale el consumo por modelo: endpoint, token por sistema, caché, cortacircuitos, límites, seguridad | `references/uso-por-modelo.md` | Cuando falte el tramo por modelo, salga `·stale` o haya un 429 |

## Quick Start

Un solo script, tres sistemas. Elige tu shell.

**macOS / Linux (bash o zsh):**

```bash
# 1) Descomprime el skill donde quieras y entra
cd barra-de-estado-claude-code
# 2) Instala (copia el script a ~/.claude y escribe statusLine en ~/.claude/settings.json)
node scripts/instalar.js
# 3) Reinicia Claude Code en esa terminal. La barra aparece tras la primera respuesta.
```

**Windows (PowerShell o Git Bash):**

```powershell
cd barra-de-estado-claude-code
node scripts\instalar.js
# Reinicia Claude Code. El instalador escribe la ruta con barras normales (C:/Users/...),
# que es lo que Claude Code necesita en Windows.
```

**Probar sin abrir Claude Code (cualquier sistema):**

```bash
echo '{"cwd":"/tmp","model":{"display_name":"Fable 5.1"},"context_window":{"used_percentage":31,"total_input_tokens":310000}}' | node scripts/statusline.js
node scripts/statusline.js --usage        # JSON crudo del endpoint de uso (para diagnóstico)
node scripts/statusline.js --clear-cache  # tras cambiar de cuenta con /login
```

El Quick Start es mono-lenguaje a propósito: la barra la ejecuta Claude Code, que ya trae
Node.js, así que un script en Node es lo único que funciona igual en los tres sistemas sin
instalar nada más. Los shells cambian; el script no.

## Essential Patterns

**Flujo de datos de la barra:**

```text
Claude Code ──JSON por stdin──▶ node statusline.js ──una línea con colores──▶ barra
   (modelo, ctx, 5h/7d,               │
    effort, cwd, pr…)                 ├─ git rev-parse  → rama
                                      ├─ gh pr view     → PR abierto (opcional)
                                      └─ caché de uso   → Fable7d / Opus7d / Sonnet7d
```

**De dónde sale el token, según el sistema:**

```text
                 ┌── macOS ───▶ Llavero: security find-generic-password -s "Claude Code-credentials" -w
readAccessToken ─┤             (si falla: ~/.claude/.credentials.json, el respaldo que usa Claude Code)
                 └── Linux/Windows ───▶ ~/.claude/.credentials.json   (o $CLAUDE_CONFIG_DIR/.credentials.json)
El token NUNCA se imprime ni se guarda en la caché: la caché solo contiene el JSON de uso.
```

**Caché y cortacircuitos del endpoint de uso:**

```text
¿caché < 5 min? ──sí──▶ usar caché
      │ no
¿cortacircuitos abierto (< 10 min desde el último fallo)? ──sí──▶ usar caché vieja (·stale si > 15 min)
      │ no
GET /api/oauth/usage ──200──▶ escribir caché, cerrar cortacircuitos
                     ──error/429──▶ abrir cortacircuitos, usar caché vieja
```

**Qué tramo aparece y cuándo:**

```text
carpeta · rama · modelo        → siempre
PR #n                          → si `gh` está instalado y la rama tiene PR abierto (o Claude Code lo manda)
effort · ctx                   → tras la primera respuesta de la sesión
5h · 7d                        → solo cuentas Pro/Max, tras la primera respuesta
<Modelo>7d                     → solo si el plan tiene ventanas semanales por modelo y hay sesión iniciada
```

## Critical Gotchas

1. **El consumo por modelo no viene en el JSON de la barra** → Claude Code solo manda `five_hour` y `seven_day`. Cualquier barra que muestre «Fable7d» lo saca del endpoint de uso con el token de la sesión; no lo busques en `rate_limits`.
2. **Windows: barras invertidas en `settings.json` = barra que no aparece y sin error** → Git Bash se come los `\` de `C:\Users\...`. El instalador escribe siempre `node "C:/Users/.../statusline.js"`. Si lo editas a mano, usa barras normales.
3. **`~` no se expande en PowerShell para comandos externos** → por eso el instalador escribe la ruta absoluta, no `~/.claude/statusline.js`.
4. **Tras cambiar de cuenta con `/login`, la caché muestra la cuenta anterior** → `node ~/.claude/statusline.js --clear-cache` (o espera 5 minutos).
5. **Los tokens de `claude setup-token` no sirven** → el endpoint de uso devuelve 429 con esos tokens largos; hace falta la sesión normal iniciada con `/login`.
6. **El endpoint de uso tiene límite de peticiones** → nunca lo llames en cada refresco: el script cachea 5 minutos y, si falla, no reintenta durante 10. Bajar esos tiempos te lleva al 429.
7. **En macOS por SSH el Llavero está bloqueado** → `security` falla en silencio y el script cae a `~/.claude/.credentials.json`, que Claude Code escribe en ese caso. Si tampoco existe, el tramo por modelo simplemente no sale.
8. **La barra solo se refresca con eventos** → sin `refreshInterval`, los minutos de la cuenta atrás se quedan congelados mientras Claude está en reposo. El instalador pone 60 s.
9. **`rate_limits` aparece después de la primera respuesta** → al abrir la sesión la barra muestra solo carpeta, rama y modelo. Es normal; no es un fallo.
10. **Cuentas de equipo, Console o clave de API no reciben `rate_limits`** → el tramo 5h/7d y el de modelo no aparecen porque el JSON no los trae. Solo `/usage` los muestra.
11. **`gh pr view` sale a la red en cada refresco** → si notas lag, exporta `CLAUDE_STATUSLINE_NO_PR=1` en tu shell y el tramo PR desaparece.
12. **Un `settings.json` roto bloquea la instalación** → el instalador se niega a seguir si el archivo no es JSON válido: arréglalo a mano (o borra la clave conflictiva) antes de reinstalar.
13. **El icono `⎇` puede salir como un cuadrado en fuentes muy viejas** → `CLAUDE_STATUSLINE_BRANCH_ICON=""` lo quita; si usas una Nerd Font puedes poner el glifo que prefieras.
14. **El texto de la barra se corta en terminales estrechas** → Claude Code no ajusta el ancho; si trabajas a menos de 120 columnas, quita el tramo PR o el icono.

## Cross-Skill Integration

Este skill es **autosuficiente**: no depende de ningún otro skill, repositorio ni servicio propio. Se apoya solo en Claude Code y en Node.js. Integraciones de contexto:

### Comandos nativos de Claude Code

- `/statusline` genera barras a partir de una descripción en lenguaje natural; este skill lo sustituye con un script fijo y probado. Si ya usabas `/statusline`, el instalador guarda tu configuración anterior en `settings.json.bak-<fecha>`.
- `/usage` muestra en Claude Code el desglose completo de la cuenta (incluida la caché de prompts); la barra es el resumen permanente de lo mismo.
- `/login` y `/logout` cambian la credencial que el script lee; tras cambiar de cuenta, borra la caché (gotcha 4).

### `settings.json` de Claude Code

La única clave que toca es `statusLine` (alcance de usuario, `~/.claude/settings.json`):

```json
{
  "statusLine": {
    "type": "command",
    "command": "node \"/Users/tu-usuario/.claude/statusline.js\"",
    "refreshInterval": 60
  }
}
```

En un proyecto compartido puedes ponerla en `.claude/settings.json` del repositorio, pero la ruta absoluta es de cada máquina: para equipos, que cada persona corra el instalador.

## Next Steps

- **¿Instalando o «no sale la barra»?** → `references/instalacion-por-sistema.md`
- **¿Quieres cambiar el orden, los colores o los iconos?** → `references/formato-y-campos.md`
- **¿No aparece el tramo por modelo, sale `·stale` o hay un 429?** → `references/uso-por-modelo.md`
