#!/usr/bin/env node
/**
 * statusline.js — Barra de estado de Claude Code con consumo por modelo.
 *
 * Funciona igual en macOS, Linux y Windows. Claude Code le pasa por stdin un JSON con la
 * sesión (modelo, contexto, límites de 5 h y 7 días…) y este script imprime UNA línea:
 *
 *   carpeta | ⎇rama | PR #12 | Fable 5.1 | effort:high | ctx:31%(310000) | 5h:39%(rst 2h57m) 7d:8%(rst 1d23h) | Fable7d:13%(rst 1d23h)
 *
 * El último tramo (consumo semanal por modelo) NO viene en el JSON de la barra: se lee del
 * endpoint de uso de la cuenta con el token OAuth de la sesión iniciada en Claude Code.
 *   - macOS: Llavero (`security find-generic-password -s "Claude Code-credentials" -w`),
 *            con ~/.claude/.credentials.json como respaldo.
 *   - Linux y Windows: ~/.claude/.credentials.json (o CLAUDE_CONFIG_DIR/.credentials.json).
 * Se cachea 5 minutos en el directorio temporal del sistema y se marca «·stale» pasados 15.
 * Tras un fallo de red o un 429, un cortacircuitos evita reintentar durante 10 minutos.
 *
 * Uso como barra (lo configura scripts/instalar.js):
 *   "statusLine": { "type": "command", "command": "node \"/ruta/absoluta/statusline.js\"", "refreshInterval": 60 }
 *
 * Uso manual (prueba sin abrir Claude):
 *   echo '{"cwd":"/tmp","model":{"display_name":"Fable 5.1"}}' | node statusline.js
 *   node statusline.js --usage          # imprime el JSON de uso (caché o red) para diagnóstico
 *   node statusline.js --clear-cache    # borra la caché (p. ej. tras cambiar de cuenta)
 *
 * Uso como módulo: const { render, fetchUsage } = require('./statusline.js')
 *
 * Variables de entorno opcionales:
 *   CLAUDE_STATUSLINE_BRANCH_ICON   icono antes de la rama (por defecto "⎇"; pon "" para ninguno)
 *   CLAUDE_STATUSLINE_NO_PR=1       no consultar el PR abierto (evita llamar a `gh`)
 *   CLAUDE_STATUSLINE_NO_USAGE=1    no consultar el endpoint de uso (solo lo que trae el JSON)
 *   CLAUDE_CONFIG_DIR               dónde vive la configuración de Claude Code (lo respeta Claude Code)
 *
 * Sin dependencias: solo Node.js (>= 18), el mismo que exige Claude Code.
 */
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');
const { execFileSync } = require('child_process');

// ---------- tipos (JSDoc) ----------
/** @typedef {{ used_percentage?: number, resets_at?: number }} Window */
/** @typedef {{ five_hour?: Window, seven_day?: Window, spend_limit?: Window }} RateLimits */
/** @typedef {{ kind?: string, percent?: number, resets_at?: string, scope?: { model?: { display_name?: string } | string } }} UsageLimit */
/** @typedef {{ limits?: UsageLimit[] }} UsageResponse */

// ---------- constantes ----------
const USAGE_URL = 'https://api.anthropic.com/api/oauth/usage';
const USAGE_BETA = 'oauth-2025-04-20';
const CACHE_FILE = path.join(os.tmpdir(), 'claude-statusline-usage.json');
const BREAKER_FILE = path.join(os.tmpdir(), 'claude-statusline-usage.breaker');
const CACHE_TTL_S = 300;      // reutilizar la caché 5 min
const STALE_AFTER_S = 900;    // marcar ·stale pasados 15 min
const BREAKER_OPEN_S = 600;   // tras un fallo, no reintentar durante 10 min
const NET_TIMEOUT_MS = 8000;

const C = { blue: '34', cyan: '36', magenta: '35', yellow: '33', green: '32', red: '31', boldred: '1;31', dim: '2' };
const color = (code, s) => `[${code}m${s}[0m`;

// ---------- utilidades ----------
function claudeDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}

function readJsonSafe(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
}

function fileAgeSeconds(file) {
  try { return (Date.now() - fs.statSync(file).mtimeMs) / 1000; } catch { return Infinity; }
}

/** Tiempo restante compacto: "2h57m" · "1d23h". */
function remaining(epochSeconds) {
  const s = Math.max(0, Math.floor(epochSeconds) - Math.floor(Date.now() / 1000));
  if (!Number.isFinite(s)) return '';
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
  return d ? `${d}d${String(h).padStart(2, '0')}h` : `${h}h${String(m).padStart(2, '0')}m`;
}

// ---------- token OAuth de la sesión ----------
/** Lee el token de acceso de la sesión iniciada en Claude Code, sin imprimirlo nunca. */
function readAccessToken() {
  // macOS: Llavero (Keychain). Si falla (SSH, Llavero bloqueado), cae al archivo.
  if (process.platform === 'darwin') {
    try {
      const raw = execFileSync('security', ['find-generic-password', '-s', 'Claude Code-credentials', '-w'],
        { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 3000 });
      const tk = JSON.parse(raw).claudeAiOauth?.accessToken;
      if (tk) return tk;
    } catch { /* sigue al archivo */ }
  }
  // Linux, Windows y respaldo de macOS: ~/.claude/.credentials.json (o CLAUDE_CONFIG_DIR)
  const creds = readJsonSafe(path.join(claudeDir(), '.credentials.json'));
  return creds?.claudeAiOauth?.accessToken || '';
}

// ---------- endpoint de uso, con caché y cortacircuitos ----------
function httpGetJson(url, headers) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers, timeout: NET_TIMEOUT_MS }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => {
        if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
        try { resolve(JSON.parse(body)); } catch (e) { reject(e); }
      });
    });
    req.on('timeout', () => { req.destroy(new Error('timeout')); });
    req.on('error', reject);
  });
}

/**
 * Devuelve el JSON de uso: de la caché si es reciente; si no, de la red (y lo cachea).
 * Nunca lanza: ante cualquier fallo devuelve la caché vieja (o null) y abre el cortacircuitos.
 * @returns {Promise<UsageResponse|null>}
 */
async function fetchUsage({ force = false } = {}) {
  const cached = readJsonSafe(CACHE_FILE);
  if (!force && cached && fileAgeSeconds(CACHE_FILE) < CACHE_TTL_S) return cached;
  if (!force && fileAgeSeconds(BREAKER_FILE) < BREAKER_OPEN_S) return cached; // circuito abierto
  const token = readAccessToken();
  if (!token) return cached;
  try {
    const data = await httpGetJson(USAGE_URL, {
      Authorization: `Bearer ${token}`, Accept: 'application/json', 'anthropic-beta': USAGE_BETA,
    });
    fs.writeFileSync(CACHE_FILE, JSON.stringify(data), { mode: 0o600 });
    try { fs.unlinkSync(BREAKER_FILE); } catch { /* no había */ }
    return data;
  } catch {
    try { fs.writeFileSync(BREAKER_FILE, String(Date.now())); } catch { /* sin permisos: da igual */ }
    return cached;
  }
}

/** Ventanas semanales por modelo → ["Fable7d:13%(rst 1d23h)", …]. */
function modelWindows(usage) {
  const out = [];
  for (const l of (usage && usage.limits) || []) {
    if (l.kind !== 'weekly_scoped') continue;
    const m = l.scope && l.scope.model;
    const name = (m && typeof m === 'object' ? m.display_name : m) || 'modelo';
    let s = `${String(name).replace(/\s+/g, '')}7d:${Math.round(Number(l.percent) || 0)}%`;
    if (l.resets_at) {
      const ts = Date.parse(l.resets_at) / 1000;
      if (Number.isFinite(ts)) s += `(rst ${remaining(ts)})`;
    }
    out.push(s);
  }
  return out;
}

// ---------- segmentos de la barra ----------
function gitBranch(cwd) {
  try {
    const br = execFileSync('git', ['-C', cwd, '--no-optional-locks', 'rev-parse', '--abbrev-ref', 'HEAD'],
      { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 2000 }).trim();
    return br && br !== 'HEAD' ? br : '';
  } catch { return ''; }
}

function openPr(cwd) {
  if (process.env.CLAUDE_STATUSLINE_NO_PR) return '';
  try {
    return execFileSync('gh', ['pr', 'view', '--json', 'number', '-q', '.number'],
      { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 3000 }).trim();
  } catch { return ''; }
}

/**
 * Construye la línea de la barra a partir del JSON de Claude Code y del JSON de uso.
 * @param {object} inp  JSON de stdin
 * @param {UsageResponse|null} usage  JSON del endpoint de uso (o null)
 */
function render(inp, usage) {
  const parts = [];
  const cwd = inp.cwd || (inp.workspace && inp.workspace.current_dir) || '';
  if (cwd) parts.push(color(C.blue, path.basename(cwd)));
  const br = cwd ? gitBranch(cwd) : '';
  if (br) {
    const icon = process.env.CLAUDE_STATUSLINE_BRANCH_ICON !== undefined ? process.env.CLAUDE_STATUSLINE_BRANCH_ICON : '⎇';
    parts.push(color(C.cyan, `${icon}${br}`));
  }
  const pr = inp.pr && inp.pr.number ? String(inp.pr.number) : (cwd ? openPr(cwd) : '');
  if (pr) parts.push(color(C.magenta, `PR #${pr}`));
  const model = inp.model && inp.model.display_name;
  if (model) parts.push(color(C.yellow, model));
  const effort = inp.effort && inp.effort.level;
  if (effort) parts.push(color(C.yellow, `effort:${effort}`));
  const cw = inp.context_window || {};
  if (cw.used_percentage !== undefined && cw.used_percentage !== null) {
    const tot = cw.total_input_tokens;
    parts.push(color(C.green, `ctx:${Math.round(cw.used_percentage)}%` + (tot ? `(${tot})` : '')));
  }
  /** @type {RateLimits} */
  const rl = inp.rate_limits || {};
  const rs = []; let alert = false;
  for (const [key, label] of [['five_hour', '5h'], ['seven_day', '7d']]) {
    const w = rl[key];
    if (w && w.used_percentage !== undefined && w.used_percentage !== null) {
      const pct = Math.round(w.used_percentage);
      if (pct >= 80) alert = true;
      rs.push(`${label}:${pct}%` + (w.resets_at ? `(rst ${remaining(w.resets_at)})` : ''));
    }
  }
  if (rs.length) parts.push(color(alert ? C.boldred : C.red, rs.join(' ')));
  const mw = modelWindows(usage);
  if (mw.length) {
    const stale = fileAgeSeconds(CACHE_FILE) > STALE_AFTER_S ? '·stale' : '';
    parts.push(color(C.magenta, mw.join(' ') + stale));
  }
  return parts.join(color(C.dim, ' | '));
}

// ---------- CLI ----------
async function main() {
  const args = process.argv.slice(2);
  if (args.includes('--help') || args.includes('-h')) {
    process.stdout.write(`statusline.js — barra de estado de Claude Code con consumo por modelo
  (stdin JSON) | node statusline.js      imprime la barra
  node statusline.js --usage             imprime el JSON de uso (caché o red)
  node statusline.js --clear-cache       borra caché y cortacircuitos
  node statusline.js --version           versión
`);
    return;
  }
  if (args.includes('--version')) { process.stdout.write('statusline.js 1.0.0\n'); return; }
  if (args.includes('--clear-cache')) {
    for (const f of [CACHE_FILE, BREAKER_FILE]) { try { fs.unlinkSync(f); } catch { /* no había */ } }
    process.stdout.write('caché borrada\n'); return;
  }
  if (args.includes('--usage')) {
    const u = await fetchUsage({ force: true });
    process.stdout.write(u ? JSON.stringify(u, null, 2) + '\n' : 'sin datos de uso (¿sesión iniciada en Claude Code?)\n');
    return;
  }
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch { raw = ''; }
  let inp = {};
  try { inp = raw.trim() ? JSON.parse(raw) : {}; } catch { inp = {}; }
  const usage = process.env.CLAUDE_STATUSLINE_NO_USAGE ? null : await fetchUsage();
  process.stdout.write(render(inp, usage) + '\n');
}

module.exports = { render, fetchUsage, readAccessToken, modelWindows, remaining, CACHE_FILE };

if (require.main === module) {
  main().catch(() => { process.stdout.write('\n'); });
}
