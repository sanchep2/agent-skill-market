#!/usr/bin/env node
/**
 * instalar.js — Instala la barra de estado en Claude Code (macOS, Linux y Windows).
 *
 * Qué hace:
 *   1. Copia statusline.js a la carpeta de configuración de Claude Code (~/.claude o CLAUDE_CONFIG_DIR).
 *   2. Guarda una copia de seguridad de settings.json (settings.json.bak-AAAAMMDD-HHMMSS) si existe.
 *   3. Escribe (o sustituye) la clave "statusLine" con la ruta ABSOLUTA en barras normales
 *      (en Windows, Git Bash se come las barras invertidas) y un refresco de 60 s.
 *   4. Prueba la barra con un JSON simulado y muestra el resultado.
 *
 * Uso:
 *   node scripts/instalar.js            instala
 *   node scripts/instalar.js --dry-run  muestra lo que haría sin tocar nada
 *   node scripts/instalar.js --uninstall  quita la clave statusLine (deja el script y la copia de seguridad)
 *
 * Sin dependencias: solo Node.js (>= 18).
 */
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const args = process.argv.slice(2);
const DRY = args.includes('--dry-run');
const UNINSTALL = args.includes('--uninstall');

const claudeDir = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
const settingsFile = path.join(claudeDir, 'settings.json');
const src = path.join(__dirname, 'statusline.js');
const dst = path.join(claudeDir, 'statusline.js');
const dstForward = dst.replace(/\\/g, '/');          // Windows: barras normales, siempre
const command = `node "${dstForward}"`;

function stamp() {
  const d = new Date(), p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function log(s) { process.stdout.write(s + '\n'); }

function main() {
  const major = Number(process.versions.node.split('.')[0]);
  if (major < 18) { log(`Node ${process.versions.node} es demasiado viejo: hace falta 18 o superior.`); process.exit(1); }

  let settings = {};
  if (fs.existsSync(settingsFile)) {
    try { settings = JSON.parse(fs.readFileSync(settingsFile, 'utf8')); }
    catch { log(`No pude leer ${settingsFile} como JSON. Arréglalo a mano antes de seguir.`); process.exit(1); }
  }

  if (UNINSTALL) {
    if (!settings.statusLine) { log('No había statusLine configurada. Nada que quitar.'); return; }
    log(`Quitando statusLine de ${settingsFile} (copia de seguridad antes).`);
    if (!DRY) {
      fs.copyFileSync(settingsFile, `${settingsFile}.bak-${stamp()}`);
      delete settings.statusLine;
      fs.writeFileSync(settingsFile, JSON.stringify(settings, null, 2) + '\n');
    }
    log('Listo. Reinicia Claude Code para que desaparezca la barra.');
    return;
  }

  log(`Carpeta de Claude Code: ${claudeDir}`);
  if (!fs.existsSync(claudeDir)) {
    log('Esa carpeta no existe: abre Claude Code una vez e inicia sesión antes de instalar.');
    process.exit(1);
  }
  if (settings.statusLine) log(`Ya había una statusLine: ${JSON.stringify(settings.statusLine)} → se sustituye (queda copia de seguridad).`);

  log(`1) Copiar ${src} → ${dst}`);
  log(`2) Escribir en ${settingsFile}: "statusLine": { "type": "command", "command": ${JSON.stringify(command)}, "refreshInterval": 60 }`);
  if (DRY) { log('(--dry-run: no se ha tocado nada)'); return; }

  fs.copyFileSync(src, dst);
  if (process.platform !== 'win32') fs.chmodSync(dst, 0o755);
  if (fs.existsSync(settingsFile)) fs.copyFileSync(settingsFile, `${settingsFile}.bak-${stamp()}`);
  settings.statusLine = { type: 'command', command, refreshInterval: 60 };
  fs.writeFileSync(settingsFile, JSON.stringify(settings, null, 2) + '\n');

  log('3) Prueba con un JSON simulado:');
  const mock = JSON.stringify({
    cwd: process.cwd(), model: { display_name: 'Fable 5.1' }, effort: { level: 'high' },
    context_window: { used_percentage: 31, total_input_tokens: 310000 },
    rate_limits: { five_hour: { used_percentage: 39, resets_at: Math.floor(Date.now() / 1000) + 10620 },
      seven_day: { used_percentage: 8, resets_at: Math.floor(Date.now() / 1000) + 169200 } },
  });
  const r = spawnSync(process.execPath, [dst], { input: mock, encoding: 'utf8', timeout: 20000 });
  log('   ' + (r.stdout || '').trim());
  if (!(r.stdout || '').includes('7d:')) log('   (la barra funciona; si no ves el tramo por modelo, revisa references/uso-por-modelo.md)');
  log('Listo. Reinicia Claude Code en esa terminal: la barra aparece tras la primera respuesta.');
}

main();
