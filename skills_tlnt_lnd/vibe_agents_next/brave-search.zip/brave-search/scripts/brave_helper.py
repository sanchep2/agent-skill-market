#!/usr/bin/env python3
"""brave_helper: búsqueda web, noticias, vídeos, imágenes, sugerencias y contexto para modelos con la API de Brave Search.

Python >= 3.9, solo biblioteca estándar. Usa el cliente común `buscadores_comun.py` (copia exacta en esta carpeta):
libro de gasto único con reserva previa (BUS-C1), registro de salida que separa texto literal de respuesta generada
(BUS-C3) y salud sin gasto (BUS-C4). Brave no tiene trabajos asíncronos en lo que este skill habilita (BUS-C2): Answers
y Place Search están documentados y DESHABILITADOS.

Entrega data original: el texto de cada resultado es el que devuelve Brave (`texto_literal`), con URL, título y fecha
solo si el proveedor la da (`page_age`); autor y fecha ausentes siguen ausentes. Nada se resume ni se reconstruye.

    python3 brave_helper.py salud
    python3 brave_helper.py web "consulta" --n 20 --paginas 3 --json
    python3 brave_helper.py --permitir-almacenamiento --salida salida contexto "consulta" --metadatos
"""
from __future__ import annotations

import argparse
import contextlib
import io
import datetime as dt
import html
import json
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent))
import buscadores_comun as C  # noqa: E402  (la copia de ESTA carpeta, no otra instalada)

SKILL = "brave-search"
VERSION = "1.0.0"
PROVEEDOR = "brave"
BASE = "https://api.search.brave.com"
URL_DOC = "https://api-dashboard.search.brave.com/documentation"
FECHA_FUENTES = "2026-10-15"          # día en que se leyó la documentación oficial (Fase 0)
URL_TERMINOS = "https://api-dashboard.search.brave.com/terms-of-service"
ALMACENAMIENTO_RESTRINGIDO = (
    'El apartado b (i) de los términos de Brave prohíbe "store, cache, or create a database of Search Results" '
    'salvo almacenamiento transitorio necesario para operar la aplicación '
    f'({URL_TERMINOS}, lectura 2026-10-17). '
    'Usa --permitir-almacenamiento solo si la cuenta tiene un plan con derecho de almacenamiento; '
    'la responsabilidad de tener ese derecho es de quien activa el flag.'
)


def _comprobar_almacenamiento(permitir: bool, salida: Optional[Path] = None, citas: bool = False) -> None:
    if not permitir and (salida is not None or citas):
        raise C.ErrorDeConfiguracion(ALMACENAMIENTO_RESTRINGIDO)

# --- Tarifa y cotas --------------------------------------------------------------------------------------------------
# Brave no devuelve el coste de cada llamada. Plan Search: 5 USD por 1.000 solicitudes (página de precios). Esa tarifa
# se aplica a web, noticias, vídeos, imágenes y contexto: medición BUS-C4 del plan Search,
# 2026-10-15 23:03 CDMX (medicion-br0), misma política 50;w=1, 0;w=2678400.
FUENTE_MEDICION = "medición 2026-10-15 (medicion-br0) + tarifa Fase 0"
TARIFA = C.Tarifa(0.005, "https://brave.com/search/api/", FECHA_FUENTES,
                  "plan Search: 5 USD por 1.000 solicitudes; las solicitudes fallidas no cuentan")
COTA_NO_VERIFICADA_USD = 0.01
CREDITO_GRATIS_MENSUAL_USD = 5.0      # según la misma página de precios (la guía antigua habla de 2.000 consultas: manda la página)
API_VERSION_ANTIGUA = "2026-02-06"    # pipeline anterior de llm/context; solo con --pipeline-antiguo

PAGINA_MAX = 9                        # offset 0..9: diez páginas como máximo (web, noticias y vídeos)
MAX_Q_CARACTERES = 600
MAX_Q_PALABRAS = 75
MAX_GOGGLES = 3
RESULT_FILTERS = ("web", "discussions", "faq", "news", "videos", "query")
RESULT_FILTERS_NO = {"summarizer": "obsoleto: lo sustituye Answers, que está deshabilitado en este skill",
                     "infobox": "su bloque de respuesta no está verificado",
                     "locations": "sus identificadores caducan a las ~8 h y exigen otro endpoint sin verificar"}
BLOQUES_IGNORADOS = ("infobox", "summarizer", "locations", "rich", "mixed")

# endpoint -> ruta, si su tarifa está comprobada, rango de count (mín, máx, valor por defecto del proveedor) y offset máx.
ENDPOINTS: Dict[str, Dict[str, Any]] = {
    "web": {"ruta": "/res/v1/web/search", "tarifa": True, "count": (1, 20, 20), "offset": PAGINA_MAX,
            "seguro": ("off", "moderate", "strict"), "no_verificados": ()},
    "noticias": {"ruta": "/res/v1/news/search", "tarifa": True, "count": (1, 50, 20), "offset": PAGINA_MAX,
                 "seguro": ("off", "moderate", "strict"),
                 "no_verificados": ("country", "search_lang", "ui_lang", "spellcheck", "extra_snippets", "goggles")},
    "videos": {"ruta": "/res/v1/videos/search", "tarifa": True, "count": (1, 50, 20), "offset": PAGINA_MAX,
               "seguro": (), "no_verificados": ("country", "search_lang", "ui_lang", "spellcheck", "safesearch")},
    "imagenes": {"ruta": "/res/v1/images/search", "tarifa": True, "count": (1, 200, 50), "offset": None,
                 "seguro": ("off", "strict"), "no_verificados": ("country", "search_lang", "spellcheck")},
    "sugerir": {"ruta": "/res/v1/suggest/search", "tarifa": False, "count": None, "offset": None,
                "seguro": (), "no_verificados": ("country", "lang", "count")},
    "contexto": {"ruta": "/res/v1/llm/context", "tarifa": True, "count": (1, 50, 20), "offset": None,
                 "seguro": ("off", "moderate", "strict"), "no_verificados": ()},
}
# opciones verificadas en la Fase 0 para cada endpoint (cualquier otra se rechaza antes de llamar)
OPCIONES: Dict[str, frozenset] = {
    "web": frozenset(("n", "pagina", "frescura", "pais", "idioma", "ui", "seguro", "correccion", "filtro",
                      "snippets_extra", "goggles", "sin_operadores", "unidades")),
    "noticias": frozenset(("n", "pagina", "frescura", "seguro")),
    "videos": frozenset(("n", "pagina", "frescura")),
    "imagenes": frozenset(("n", "seguro")),
    "sugerir": frozenset(),
    "contexto": frozenset(("n", "frescura", "pais", "idioma", "seguro", "goggles", "umbral", "metadatos", "local",
                           "max_urls", "max_tokens", "max_snippets", "max_tokens_url", "max_snippets_url")),
}
# nombres de parámetro que pueden salir en la URL de cada endpoint (los verificados + los no verificados permitidos)
PARAMETROS_PERMITIDOS: Dict[str, frozenset] = {
    "web": frozenset(("q", "count", "offset", "freshness", "country", "search_lang", "ui_lang", "safesearch", "spellcheck",
                      "text_decorations", "result_filter", "goggles", "extra_snippets", "operators", "units")),
    "noticias": frozenset(("q", "count", "offset", "freshness", "safesearch")),
    "videos": frozenset(("q", "count", "offset", "freshness")),
    "imagenes": frozenset(("q", "count", "safesearch")),
    "sugerir": frozenset(("q",)),
    "contexto": frozenset(("q", "count", "maximum_number_of_urls", "maximum_number_of_tokens",
                           "maximum_number_of_snippets", "maximum_number_of_tokens_per_url",
                           "maximum_number_of_snippets_per_url", "context_threshold_mode", "enable_local",
                           "enable_source_metadata", "goggles", "freshness", "country", "search_lang", "safesearch")),
}
# parámetros que la documentación marca como obsoletos o que se dejan fuera a propósito: NUNCA salen
PARAMETROS_PROHIBIDOS = frozenset(("summary", "enable_rich_callback", "include_fetch_metadata"))
UMBRALES = ("strict", "balanced", "lenient", "disabled")
ENDPOINTS_DESHABILITADOS = {
    "respuestas": ("Brave Answers (/res/v1/chat/completions) es otro plan (4 USD por 1.000 solicitudes más 5 USD por millón "
                   "de tokens) y cobra por tokens: no hay un límite de gasto por llamada que Brave haga cumplir, y el modo "
                   "de investigación con citas exige streaming. Sin cota que el proveedor cumpla no se lanza (BUS-C2). "
                   "Documentado y sin probar. Para grounding usa `contexto`."),
    "lugares": ("Place Search está documentado (latitud y longitud juntas o `location`, `radius`, `q`, `count` de 1 a 100) "
                "pero la Fase 0 no verificó su ruta ni su respuesta. Sin ruta verificada no se implementa. Documentado y "
                "sin probar."),
}

SUGERIR_NO_INCLUIDO = "tu plan no lo incluye (OPTION_NOT_IN_PLAN, medido); requiere el plan Autosuggest"


class ErrorDePlan(C.ErrorHttp):
    """Error de plan de este endpoint; no rechaza la clave ni para otros endpoints."""
    codigo_salida = C.SALIDA_LIMITE


def _opcion_fuera_del_plan(datos: Any) -> bool:
    if not isinstance(datos, dict):
        return False
    error = datos.get("error")
    return (datos.get("code") == "OPTION_NOT_IN_PLAN"
            or (isinstance(error, dict) and error.get("code") == "OPTION_NOT_IN_PLAN"))


def _comprobar_endpoint(endpoint: str, permitir_sugerir: bool) -> None:
    if endpoint == "sugerir" and not permitir_sugerir:
        raise C.ModoDeshabilitado(SUGERIR_NO_INCLUIDO + "; usa --permitir-sugerir para intentar UNA llamada con cota local de 0,01 USD.")


# ---------------------------------------------------------------------------------------------
# Salud en vivo y registro del skill en el cliente común
# ---------------------------------------------------------------------------------------------
def _en_vivo(ses: "C.Sesion") -> str:
    print("--en-vivo: UNA llamada de pago mínima (0,005 USD por tarifa), sin reintentos.", file=sys.stderr, flush=True)
    regs, meta = ejecutar_busqueda(ses, "web", "brave search api", n=1, reintentar=False)
    cab = ses.limites.get(PROVEEDOR) or {}
    resto = cab.get("x-ratelimit-remaining")
    return (f"{len(regs)} resultado(s) de la búsqueda web; coste estimado {TARIFA.usd:.4f} USD por tarifa"
            + (f"; X-RateLimit-Remaining: {resto}" if resto else ""))


C.configurar(SKILL, {PROVEEDOR: {
    "var": "BRAVE_SEARCH_API_KEY", "nombre": "Brave Search", "unidad": "usd",
    "sin": "sin esta clave no hay búsqueda; alta en el panel de la API de Brave Search (plan Search, crédito gratis mensual)",
    "url_alta": URL_DOC,
    "alternativa": "Espera a que se reinicie la ventana (por segundo o mensual) o usa otro buscador; este skill no compra "
                   "créditos ni cambia de plan.",
    "pausa_min_s": 1.0,                               # la ventana por segundo es deslizante de 1 s
    "sonda": "ninguna",                               # no hay sonda gratuita verificada (BUS-C4)
    "en_vivo": {"descripcion": "UNA búsqueda web de 1 resultado (≈0,005 USD por tarifa)", "llamar": _en_vivo},
}})


# ---------------------------------------------------------------------------------------------
# Validación de parámetros y construcción de la URL
# ---------------------------------------------------------------------------------------------
_RANGO_FRESCURA = re.compile(r"^(\d{4}-\d{2}-\d{2})to(\d{4}-\d{2}-\d{2})$")
_LANG = re.compile(r"^[a-z]{2}(-[a-z]{2,4})?$")
_UI = re.compile(r"^[a-z]{2}-[a-z]{2,4}$")
_NOMBRE_NV = re.compile(r"^[a-z_]{2,40}$")


def _uso(msg: str) -> "C.ErrorDeConfiguracion":
    return C.ErrorDeConfiguracion(msg)


def validar_consulta(q: Any) -> str:
    if not isinstance(q, str):
        raise _uso("La consulta debe ser un texto.")
    t = C.limpiar_control(q).strip()
    if not t:
        raise _uso("La consulta está vacía.")
    if len(t) > MAX_Q_CARACTERES:
        raise _uso(f"La consulta tiene {len(t)} caracteres; Brave admite hasta {MAX_Q_CARACTERES}.")
    if len(t.split()) > MAX_Q_PALABRAS:
        raise _uso(f"La consulta tiene {len(t.split())} palabras; Brave admite hasta {MAX_Q_PALABRAS}.")
    return t


def validar_frescura(v: Any) -> str:
    t = str(v).strip()
    if t.lower() in ("pd", "pw", "pm", "py"):
        return t.lower()
    m = _RANGO_FRESCURA.match(t)
    if not m:
        raise _uso("Frescura inválida: usa pd (24 h), pw (7 días), pm (31 días), py (365 días) o un rango "
                   "AAAA-MM-DDtoAAAA-MM-DD.")
    desde, hasta = C.parse_dia(m.group(1)), C.parse_dia(m.group(2))
    if desde is None or hasta is None or desde > hasta:
        raise _uso("Frescura inválida: el rango debe tener dos fechas reales y la primera no puede ser posterior a la segunda.")
    return t


def frescura_de_rango(desde: Optional[str], hasta: Optional[str]) -> Optional[str]:
    if desde is None and hasta is None:
        return None
    if desde is None or hasta is None:
        raise _uso("--desde y --hasta van juntos (rango AAAA-MM-DDtoAAAA-MM-DD).")
    return validar_frescura(f"{desde}to{hasta}")


def _entero(nombre: str, v: Any, minimo: int, maximo: int) -> str:
    if isinstance(v, bool) or not isinstance(v, int):
        raise _uso(f"{nombre} debe ser un entero.")
    if not minimo <= v <= maximo:
        raise _uso(f"{nombre} debe estar entre {minimo} y {maximo} (valor recibido: {v}).")
    return str(v)


def _pais(endpoint: str, v: Any) -> str:
    t = str(v).strip()
    if t.upper() == "ALL":
        if endpoint != "web":
            raise _uso("country=ALL solo está documentado para la búsqueda web.")
        return "ALL"
    if not re.fullmatch(r"[A-Za-z]{2}", t):
        raise _uso("País inválido: dos letras (ES, MX, US…)" + (" o ALL." if endpoint == "web" else "."))
    # la web documenta mayúsculas (US) y LLM Context minúsculas (us); se respeta lo documentado en cada una
    return t.upper() if endpoint == "web" else t.lower()


def _idioma(v: Any) -> str:
    t = str(v).strip().lower()
    if not _LANG.fullmatch(t):
        raise _uso("Idioma inválido: código como es, en, pt-br o zh-hans.")
    return t


def _ui(v: Any) -> str:
    t = str(v).strip()
    if not _UI.fullmatch(t.lower()):
        raise _uso("Idioma de la interfaz inválido: código como es-ES o en-US.")
    base, _, region = t.partition("-")
    return base.lower() + "-" + (region.upper() if len(region) == 2 else region)


def _goggles(valores: Any) -> List[str]:
    lista = [str(g).strip() for g in (valores or []) if str(g).strip()]
    if len(lista) > MAX_GOGGLES:
        raise _uso(f"Brave admite hasta {MAX_GOGGLES} goggles por solicitud.")
    for g in lista:
        if len(g) > 3000 or C.limpiar_control(g) != g:
            raise _uso("Goggle inválido: demasiado largo o con caracteres de control.")
        if re.match(r"^[a-z][a-z0-9+.-]*://", g, re.I) and not g.lower().startswith("https://"):
            raise _uso("Un goggle por URL debe usar https.")
    return lista


def _filtro(v: Any) -> Optional[str]:
    if v is None:
        return None
    partes = [p.strip().lower() for p in (v.split(",") if isinstance(v, str) else v) if str(p).strip()]
    if not partes or partes == ["todo"]:
        return None
    vistos: List[str] = []
    for p in partes:
        if p in RESULT_FILTERS_NO:
            raise _uso(f"result_filter={p} no se envía: {RESULT_FILTERS_NO[p]}.")
        if p not in RESULT_FILTERS:
            raise _uso(f"Filtro desconocido {p!r}. Opciones: {', '.join(RESULT_FILTERS)} (o «todo»).")
        if p not in vistos:
            vistos.append(p)
    return ",".join(vistos)


def _booleano(v: Any) -> str:
    return "true" if v else "false"


def _no_verificados(endpoint: str, pares: Sequence[str]) -> List[Tuple[str, str]]:
    """«NOMBRE=VALOR» de la lista de parámetros NO verificados en la Fase 0 que se permiten para ese endpoint."""
    out: List[Tuple[str, str]] = []
    permitidos = ENDPOINTS[endpoint]["no_verificados"]
    for texto in pares or []:
        nombre, sep, valor = str(texto).partition("=")
        nombre = nombre.strip().lower()
        valor = valor.strip()
        if not sep or not _NOMBRE_NV.fullmatch(nombre) or not valor or len(valor) > 200 or C.limpiar_control(valor) != valor:
            raise _uso("Usa --no-verificado NOMBRE=VALOR (valor corto y sin caracteres de control).")
        if nombre not in permitidos:
            raise _uso(f"El parámetro {nombre!r} no está permitido para {endpoint}. Permitidos sin verificar: "
                       f"{', '.join(permitidos) if permitidos else 'ninguno'}.")
        out.append((nombre, valor))
    return out


def construir_parametros(endpoint: str, q: str, *, n: Optional[int] = None, pagina: Optional[int] = None,
                         frescura: Optional[str] = None, pais: Optional[str] = None, idioma: Optional[str] = None,
                         ui: Optional[str] = None, seguro: Optional[str] = None, correccion: Optional[bool] = None,
                         filtro: Any = None, snippets_extra: bool = False, goggles: Any = (), sin_operadores: bool = False,
                         unidades: Optional[str] = None, umbral: Optional[str] = None, metadatos: bool = False,
                         local: Optional[bool] = None, max_urls: Optional[int] = None, max_tokens: Optional[int] = None,
                         max_snippets: Optional[int] = None, max_tokens_url: Optional[int] = None,
                         max_snippets_url: Optional[int] = None,
                         no_verificados: Sequence[str] = ()) -> List[Tuple[str, str]]:
    """Pares (parámetro, valor) de la URL, en orden estable. Valida todo ANTES de que haya red."""
    if endpoint not in ENDPOINTS:
        raise _uso(f"Endpoint desconocido {endpoint!r}.")
    spec = ENDPOINTS[endpoint]
    dadas = {"n": n, "pagina": pagina, "frescura": frescura, "pais": pais, "idioma": idioma, "ui": ui, "seguro": seguro,
             "correccion": correccion, "filtro": filtro, "snippets_extra": snippets_extra or None,
             "goggles": list(goggles or []) or None, "sin_operadores": sin_operadores or None, "unidades": unidades,
             "umbral": umbral, "metadatos": metadatos or None, "local": local, "max_urls": max_urls,
             "max_tokens": max_tokens, "max_snippets": max_snippets, "max_tokens_url": max_tokens_url,
             "max_snippets_url": max_snippets_url}
    for nombre, valor in dadas.items():
        if valor is not None and nombre not in OPCIONES[endpoint]:
            raise _uso(f"La opción {nombre!r} no está verificada para {endpoint}. Si el proveedor la admite, pásala con "
                       "--no-verificado NOMBRE=VALOR (sin probar en vivo).")
    q = validar_consulta(q)
    p: List[Tuple[str, str]] = [("q", q)]
    if spec["count"] is not None:
        minimo, maximo, defecto = spec["count"]
        p.append(("count", _entero("--n", n if n is not None else defecto, minimo, maximo)))
    elif n is not None:
        raise _uso(f"{endpoint} no admite --n.")
    if endpoint in ("web", "noticias", "videos"):
        if pagina is not None:
            p.append(("offset", _entero("--pagina", pagina, 0, spec["offset"])))
    if endpoint == "contexto":
        for nombre, valor, minimo, maximo in (("maximum_number_of_urls", max_urls, 1, 50),
                                              ("maximum_number_of_tokens", max_tokens, 1024, 32768),
                                              ("maximum_number_of_snippets", max_snippets, 1, 256),
                                              ("maximum_number_of_tokens_per_url", max_tokens_url, 512, 8192),
                                              ("maximum_number_of_snippets_per_url", max_snippets_url, 1, 100)):
            if valor is not None:
                p.append((nombre, _entero(nombre, valor, minimo, maximo)))
        if umbral is not None:
            if umbral not in UMBRALES:
                raise _uso(f"--umbral debe ser uno de {', '.join(UMBRALES)}.")
            p.append(("context_threshold_mode", umbral))
        if local is not None:
            p.append(("enable_local", _booleano(local)))
        if metadatos:
            p.append(("enable_source_metadata", "true"))
    if endpoint in ("web", "contexto"):
        for g in _goggles(goggles):
            p.append(("goggles", g))
    if frescura is not None:
        p.append(("freshness", validar_frescura(frescura)))
    if endpoint in ("web", "contexto"):
        if pais is not None:
            p.append(("country", _pais(endpoint, pais)))
        if idioma is not None:
            p.append(("search_lang", _idioma(idioma)))
    if endpoint == "web":
        if ui is not None:
            p.append(("ui_lang", _ui(ui)))
    if seguro is not None:
        if seguro not in spec["seguro"]:
            raise _uso(f"--seguro para {endpoint} admite: {', '.join(spec['seguro']) or 'ninguno'}.")
        p.append(("safesearch", seguro))
    if endpoint == "web":
        # las comillas piden una búsqueda literal: con la corrección por defecto Brave usaría la consulta corregida
        corregir = correccion if correccion is not None else ('"' not in q)
        if not corregir:
            p.append(("spellcheck", "false"))
        elif correccion is True:
            p.append(("spellcheck", "true"))
        p.append(("text_decorations", "false"))
        f = _filtro("web" if filtro is None else filtro)
        if f:
            p.append(("result_filter", f))
        if snippets_extra:
            p.append(("extra_snippets", "true"))
        if sin_operadores:
            p.append(("operators", "false"))
        if unidades is not None:
            if unidades not in ("metric", "imperial"):
                raise _uso("--unidades debe ser metric o imperial.")
            p.append(("units", unidades))
    p.extend(_no_verificados(endpoint, no_verificados))
    permitidos = PARAMETROS_PERMITIDOS[endpoint] | frozenset(spec["no_verificados"])
    for nombre, _ in p:
        if nombre in PARAMETROS_PROHIBIDOS or nombre not in permitidos:
            raise _uso(f"Parámetro {nombre!r} no permitido para {endpoint}.")
    return p


def url_de(endpoint: str, pares: Sequence[Tuple[str, str]]) -> str:
    import urllib.parse
    return BASE + ENDPOINTS[endpoint]["ruta"] + "?" + urllib.parse.urlencode(list(pares))


# ---------------------------------------------------------------------------------------------
# Cabeceras de límite: ventana por segundo y mes (X-RateLimit-*), guardadas entre procesos
# ---------------------------------------------------------------------------------------------
def _enteros(v: Any) -> Optional[List[int]]:
    if v is None:
        return None
    try:
        return [int(float(x.strip())) for x in str(v).split(",") if x.strip() != ""] or None
    except ValueError:
        return None


def parsear_limites(cab: Optional[Dict[str, str]]) -> Optional[Dict[str, Any]]:
    """`X-RateLimit-Limit|Policy|Remaining|Reset` con un valor por ventana (segundo y mes). None si no hay ninguna."""
    c = {str(k).lower(): v for k, v in (cab or {}).items()}
    limit, resto, reinicio = _enteros(c.get("x-ratelimit-limit")), _enteros(c.get("x-ratelimit-remaining")), _enteros(c.get("x-ratelimit-reset"))
    if limit is None and resto is None and reinicio is None:
        return None
    politica = c.get("x-ratelimit-policy")
    ventanas = [int(x) for x in re.findall(r"w\s*=\s*(\d+)", politica or "")]
    n = max(len(limit or []), len(resto or []), len(reinicio or []))
    i_seg, i_mes = 0, (1 if n > 1 else None)
    if ventanas and len(ventanas) == n:                      # la política dice qué ventana es cada valor
        i_seg = min(range(n), key=lambda i: ventanas[i])
        i_mes = max(range(n), key=lambda i: ventanas[i]) if n > 1 and max(ventanas) >= 86400 else None

    def en(lista: Optional[List[int]], i: Optional[int]) -> Optional[int]:
        return lista[i] if lista is not None and i is not None and i < len(lista) else None

    return {"limit": limit, "remaining": resto, "reset": reinicio, "policy": politica,
            "segundo": {"limit": en(limit, i_seg), "remaining": en(resto, i_seg), "reset": en(reinicio, i_seg)},
            "mes": {"limit": en(limit, i_mes), "remaining": en(resto, i_mes), "reset": en(reinicio, i_mes)}}


def fichero_limites() -> Path:
    return C.dir_base() / "limites.json"


def guardar_limites(cab: Dict[str, str]) -> None:
    lim = parsear_limites(cab)
    if lim is None:
        return
    lim["leido"] = C.iso_local()
    lim["epoch"] = time.time()
    try:
        C.escribir_privado(fichero_limites(), json.dumps({PROVEEDOR: lim}, ensure_ascii=False, indent=1))
    except (OSError, C.ErrorBuscadores):
        pass


def leer_limites() -> Optional[Dict[str, Any]]:
    d = C.leer_json(fichero_limites(), None)
    return d.get(PROVEEDOR) if isinstance(d, dict) and isinstance(d.get(PROVEEDOR), dict) else None


def comprobar_presupuesto_mensual(ahora: Optional[float] = None) -> None:
    """Si la última lectura de las cabeceras dijo que el límite MENSUAL está agotado y su reinicio aún no llegó, no se
    sale a la red. Un límite mensual de 0 significa ilimitado."""
    lim = leer_limites()
    if not lim or not isinstance(lim.get("mes"), dict) or not isinstance(lim.get("epoch"), (int, float)):
        return
    mes = lim["mes"]
    if mes.get("limit") in (None, 0) or mes.get("remaining") is None or mes.get("reset") is None:
        return
    if mes["remaining"] <= 0 and (ahora if ahora is not None else time.time()) < lim["epoch"] + mes["reset"]:
        falta = lim["epoch"] + mes["reset"] - (ahora if ahora is not None else time.time())
        raise C.LimiteAlcanzado(PROVEEDOR, "Brave Search: el límite mensual de solicitudes está agotado según las "
                                f"cabeceras X-RateLimit de la última llamada (reinicio en ≈{falta / 3600:.1f} h). No se sale a la red.",
                                C.proveedores()[PROVEEDOR].get("alternativa", ""))


def _ajustar_429(cab: Dict[str, str]) -> Dict[str, str]:
    """Brave no manda Retry-After: se deriva de X-RateLimit-Reset para que el cliente común espere (ventana por segundo)
    o pare sin reintentar (ventana mensual, siempre mayor que su tope de 30 s)."""
    cab = dict(cab)
    if "retry-after" in cab:
        return cab
    lim = parsear_limites(cab)
    if not lim:
        return cab
    mes, seg = lim["mes"], lim["segundo"]
    if mes.get("limit") not in (None, 0) and mes.get("remaining") is not None and mes["remaining"] <= 0 and mes.get("reset") is not None:
        cab["retry-after"] = str(mes["reset"])
    elif seg.get("reset") is not None:
        cab["retry-after"] = str(max(1, seg["reset"]))
    return cab


# ---------------------------------------------------------------------------------------------
# Normalización al registro común (BUS-C3)
# ---------------------------------------------------------------------------------------------
_DECORACION = re.compile(r"</?(?:strong|b|em|i)\b[^>]*>", re.I)
_FECHA_ISO = re.compile(r"^\d{4}-\d{2}-\d{2}")


def _s(v: Any) -> Optional[str]:
    return v if isinstance(v, str) and v.strip() else None


def _limpiar(v: Any, avisos: List[str]) -> Optional[str]:
    """Quita la decoración HTML que Brave añade (negritas) y deshace las entidades: es el mismo texto del proveedor."""
    t = _s(v)
    if t is None:
        return None
    nuevo = html.unescape(_DECORACION.sub("", t))
    if nuevo != t and "texto_html_normalizado" not in avisos:
        avisos.append("texto_html_normalizado")
    return nuevo


def _fecha(*candidatos: Any) -> Optional[str]:
    """Fecha ISO solo si el proveedor da una absoluta (`page_age`, o un elemento ISO de `age[]` en llm/context). Las
    fechas relativas («3 days ago») NO son fechas: se ignoran."""
    for c in candidatos:
        vals = c if isinstance(c, list) else [c]
        for v in vals:
            if isinstance(v, str) and _FECHA_ISO.match(v.strip()):
                t = C.parse_fecha(v.strip())
                if t is not None:
                    return C.iso_utc(t)
    return None


def _url(v: Any, avisos: List[str]) -> Optional[str]:
    t = _s(v)
    if t is None:
        return None
    if not re.match(r"^https?://", t, re.I):
        avisos.append("url_no_http")
        return None
    return t.strip()


def _resultados(bloque: Any) -> List[Any]:
    if isinstance(bloque, dict) and isinstance(bloque.get("results"), list):
        return bloque["results"]
    return bloque if isinstance(bloque, list) else []


class Norm:
    """Contexto de una normalización: consulta, coste de la llamada y avisos comunes a todos los registros."""

    def __init__(self, consulta: str, coste: Dict[str, Any], avisos: Sequence[str] = (), exigir_url: bool = False):
        self.consulta, self.coste, self.avisos = consulta, coste, list(avisos)
        self.exigir_url = exigir_url
        self.regs: List[Dict[str, Any]] = []
        self.descartados = 0

    def agregar(self, modo: str, *, url: Any = None, titulo: Any = None, texto: Any = None, fecha: Any = None,
                autor: Any = None, referencias: Any = None, extra_avisos: Sequence[str] = ()) -> None:
        av = list(self.avisos) + list(extra_avisos)
        u = _url(url, av)
        if self.exigir_url and u is None:
            texto = None
            av.append("sin_url_atribuible")
        if u is None and _s(titulo) is None and _s(texto) is None and not referencias:
            self.descartados += 1          # sin URL, sin título y sin texto no hay nada que citar
            return
        self.regs.append(C.registro_extracto(
            url=u, titulo=titulo, texto_literal=texto, referencias=referencias, fecha=fecha,
            fecha_fuente="proveedor" if fecha else None, autor=autor, motor="brave", modo=modo,
            consulta=self.consulta, coste=dict(self.coste), avisos=av))


def _pares_qa(x: Any) -> List[Tuple[Optional[str], Optional[str]]]:
    out: List[Tuple[Optional[str], Optional[str]]] = []
    for it in _resultados(x):
        if isinstance(it, dict) and (_s(it.get("answer")) or _s(it.get("question"))):
            out.append((_s(it.get("question")), _s(it.get("answer"))))
    return out


def _item_web(n: Norm, r: Dict[str, Any], modo: str) -> None:
    av: List[str] = []
    extra = [_limpiar(x, av) for x in r["extra_snippets"]] if isinstance(r.get("extra_snippets"), list) else []
    texto = "\n\n".join(p for p in [_limpiar(r.get("description"), av)] + extra if p) or None
    n.agregar(modo, url=r.get("url"), titulo=_limpiar(r.get("title"), av), texto=texto,
              fecha=_fecha(r.get("page_age"), r.get("age")), extra_avisos=av)


def _item_discusion(n: Norm, r: Dict[str, Any]) -> None:
    av: List[str] = []
    data = r.get("data") if isinstance(r.get("data"), dict) else {}
    texto = _limpiar(r.get("description"), av) or _limpiar(data.get("question"), av)
    extra = [_limpiar(x, av) for x in r["extra_snippets"]] if isinstance(r.get("extra_snippets"), list) else []
    texto = "\n\n".join(p for p in [texto] + extra if p) or None
    n.agregar("discussions", url=r.get("url"), titulo=_limpiar(r.get("title"), av), texto=texto,
              fecha=_fecha(r.get("page_age"), r.get("age")), extra_avisos=av)
    for contenedor in (r, data):
        for clave in ("qa", "faq"):
            for pregunta, respuesta in _pares_qa(contenedor.get(clave)):
                av2: List[str] = []
                n.agregar("discussions/" + clave, url=r.get("url"), titulo=_limpiar(pregunta, av2),
                          texto=_limpiar(respuesta, av2), fecha=_fecha(r.get("page_age"), r.get("age")), extra_avisos=av2)


def _item_faq(n: Norm, r: Dict[str, Any]) -> None:
    av: List[str] = []
    n.agregar("faq", url=r.get("url"), titulo=_limpiar(r.get("question"), av) or _limpiar(r.get("title"), av),
              texto=_limpiar(r.get("answer"), av), fecha=_fecha(r.get("page_age"), r.get("age")), extra_avisos=av)


def _item_video(n: Norm, r: Dict[str, Any], modo: str) -> None:
    av: List[str] = []
    video = r.get("video") if isinstance(r.get("video"), dict) else {}
    n.agregar(modo, url=r.get("url"), titulo=_limpiar(r.get("title"), av), texto=_limpiar(r.get("description"), av),
              fecha=_fecha(r.get("page_age"), r.get("age")), autor=_limpiar(video.get("creator"), av), extra_avisos=av)


def _cabecera_meta(datos: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    q = datos.get("query") if isinstance(datos.get("query"), dict) else {}
    original, alterada = _s(q.get("original")), _s(q.get("altered"))
    avisos: List[str] = []
    meta: Dict[str, Any] = {"mas_resultados": q.get("more_results_available") if isinstance(q.get("more_results_available"), bool) else None,
                            "consulta_original": original, "consulta_alterada": None, "bloques_ignorados": [],
                            "descartados_por_forma": 0}
    if alterada and alterada != original:
        meta["consulta_alterada"] = alterada
        avisos.append("consulta_corregida_por_el_proveedor")
    meta["bloques_ignorados"] = [b for b in BLOQUES_IGNORADOS if b in datos]
    return meta, avisos


def _recorrer(n: Norm, items: Any, fn: Any, *args: Any) -> None:
    for it in _resultados(items):
        if isinstance(it, dict):
            fn(n, it, *args)
        else:
            n.descartados += 1


def normalizar_web(datos: Any, consulta: str, coste: Dict[str, Any], permitir_no_verificado: bool = False) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """`web`, `discussions` (con `qa`/`faq` anidados si vienen), `faq`, `news` y `videos` cuando estén en la respuesta.
    `infobox`, `summarizer`, `locations`, `rich` y `mixed` se ignoran y se declaran: ningún texto generado entra."""
    if not isinstance(datos, dict):
        raise C.ErrorDeContrato("Brave devolvió una respuesta que no es un objeto JSON.")
    meta, avisos = _cabecera_meta(datos)
    n = Norm(consulta, coste, avisos)
    _recorrer(n, datos.get("web"), _item_web, "web")
    _recorrer(n, datos.get("discussions"), _item_discusion)
    # La Fase 0 solo confirma qa/faq dentro de discussions; bloques superiores sin smoke.
    for bloque, fn, args in (("faq", _item_faq, ()), ("news", _item_web, ("noticias",)),
                             ("videos", _item_video, ("videos",))):
        if permitir_no_verificado:
            antes = len(n.regs)
            _recorrer(n, datos.get(bloque), fn, *args)
            for registro in n.regs[antes:]:
                registro["avisos"].append("bloque_no_verificado_sin_probar_en_vivo:" + bloque)
        elif bloque in datos:
            meta["bloques_ignorados"].append(bloque)
    meta["descartados_por_forma"] = n.descartados
    return n.regs, meta


def normalizar_noticias(datos: Any, consulta: str, coste: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    if not isinstance(datos, dict):
        raise C.ErrorDeContrato("Brave devolvió una respuesta que no es un objeto JSON.")
    meta, avisos = _cabecera_meta(datos)
    n = Norm(consulta, coste, avisos, exigir_url=True)
    _recorrer(n, datos.get("results"), _item_web, "noticias")
    meta["descartados_por_forma"] = n.descartados
    return n.regs, meta


def normalizar_videos(datos: Any, consulta: str, coste: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    if not isinstance(datos, dict):
        raise C.ErrorDeContrato("Brave devolvió una respuesta que no es un objeto JSON.")
    meta, avisos = _cabecera_meta(datos)
    n = Norm(consulta, coste, avisos, exigir_url=True)
    _recorrer(n, datos.get("results"), _item_video, "videos")
    meta["descartados_por_forma"] = n.descartados
    return n.regs, meta


def _item_imagen(n: Norm, r: Dict[str, Any]) -> None:
    av: List[str] = []
    props = r.get("properties") if isinstance(r.get("properties"), dict) else {}
    archivo = _s(props.get("url"))
    refs = [{"url": archivo, "titulo": "archivo de la imagen"}] if archivo and re.match(r"^https?://", archivo, re.I) else None
    n.agregar("imagenes", url=r.get("url"), titulo=_limpiar(r.get("title"), av),
              texto=_limpiar(r.get("description"), av), referencias=refs,
              fecha=_fecha(r.get("page_age"), r.get("age")),
              extra_avisos=av)


def normalizar_imagenes(datos: Any, consulta: str, coste: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    if not isinstance(datos, dict):
        raise C.ErrorDeContrato("Brave devolvió una respuesta que no es un objeto JSON.")
    meta, avisos = _cabecera_meta(datos)
    n = Norm(consulta, coste, avisos, exigir_url=True)
    _recorrer(n, datos.get("results"), _item_imagen)
    meta["descartados_por_forma"] = n.descartados
    return n.regs, meta


def normalizar_sugerencias(datos: Any, consulta: str, coste: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Una sugerencia no es texto de una fuente: va en `titulo`, sin URL ni `texto_literal`."""
    if not isinstance(datos, dict):
        raise C.ErrorDeContrato("Brave devolvió una respuesta que no es un objeto JSON.")
    meta, avisos = _cabecera_meta(datos)
    n = Norm(consulta, coste, avisos)
    for it in _resultados(datos.get("results")):
        if isinstance(it, dict) and _s(it.get("query")):
            n.agregar("sugerir", titulo=it["query"])
        else:
            n.descartados += 1
    meta["descartados_por_forma"] = n.descartados
    return n.regs, meta


def _snippet(s: Any, av: List[str]) -> Optional[str]:
    """Un fragmento de llm/context: texto, o JSON serializado (datos estructurados de la página). Se entrega TAL CUAL
    (es lo que Brave extrajo de esa URL) y, si es JSON serializado, con el aviso.
    Objetos/listas inesperados no se convierten en cita: el llamador los conserva en referencias."""
    if isinstance(s, (dict, list)):
        if "snippet_estructurado_no_literal" not in av:
            av.append("snippet_estructurado_no_literal")
        return None
    t = _s(s)
    if t is None:
        return None
    if t.lstrip()[:1] in ("{", "["):
        try:
            if isinstance(json.loads(t), (dict, list)) and "snippet_json_serializado" not in av:
                av.append("snippet_json_serializado")
        except ValueError:
            pass
    return t


def normalizar_contexto(datos: Any, consulta: str, coste: Dict[str, Any],
                        pipeline: str = "vigente") -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """`grounding.generic[]` (url, title, snippets) con `sources{url: {title, hostname, age[]}}`. Un registro por URL; sus
    fragmentos en cadena separados por una línea en blanco; objetos inesperados quedan en referencias."""
    if not isinstance(datos, dict):
        raise C.ErrorDeContrato("Brave devolvió una respuesta que no es un objeto JSON.")
    grounding = datos.get("grounding") if isinstance(datos.get("grounding"), dict) else {}
    fuentes = datos.get("sources") if isinstance(datos.get("sources"), dict) else {}
    meta = {"mas_resultados": None, "consulta_original": consulta, "consulta_alterada": None, "bloques_ignorados": [],
            "descartados_por_forma": 0, "pipeline": pipeline}
    for b in ("poi", "map"):
        if grounding.get(b):
            meta["bloques_ignorados"].append("grounding." + b)
    n = Norm(consulta, coste, exigir_url=True)
    for g in _resultados(grounding.get("generic")):
        if not isinstance(g, dict):
            n.descartados += 1
            continue
        av: List[str] = []
        url = _s(g.get("url"))
        fuente = fuentes.get(url) if url and isinstance(fuentes.get(url), dict) else {}
        snippets = [_snippet(x, av) for x in (g.get("snippets") if isinstance(g.get("snippets"), list) else [])]
        texto = "\n\n".join(s for s in snippets if s) or None
        estructurados = [{"url": url, "datos_estructurados": x} for x in g.get("snippets", [])
                         if isinstance(x, (dict, list))] if isinstance(g.get("snippets"), list) else []
        n.agregar("contexto/" + pipeline, url=url, titulo=_limpiar(g.get("title") or fuente.get("title"), av), texto=texto,
                  fecha=_fecha(fuente.get("age")), referencias=estructurados or None, extra_avisos=av)
    meta["descartados_por_forma"] = n.descartados
    return n.regs, meta


# ---------------------------------------------------------------------------------------------
# Llamada con libro de gasto (BUS-C1), caché y búsqueda paginada
# ---------------------------------------------------------------------------------------------
def coste_info(r: "C.Respuesta") -> Dict[str, Any]:
    d: Dict[str, Any] = {"usd": r.coste_usd, "fuente": r.fuente_coste, "estimado": r.fuente_coste != "proveedor",
                         "cache": False}
    if r.fuente_coste == "tarifa":
        d.update({"tarifa_url": TARIFA.url, "tarifa_fecha": TARIFA.fecha, "fuente_evidencia": FUENTE_MEDICION})
    elif r.fuente_coste == "cota":
        d["nota"] = "Autosuggest: cota local estimada de 0,01 USD (2 × tarifa Search Fase 0), no tarifa Autosuggest verificada ni límite contractual."
    return d


COSTE_CACHE = {"usd": 0.0, "fuente": "cache", "estimado": False, "cache": True}


def _normalizador(endpoint: str, pipeline: str, permitir_no_verificado: bool = False):
    if endpoint == "web":
        return lambda d, q, c: normalizar_web(d, q, c, permitir_no_verificado)
    if endpoint == "noticias":
        return normalizar_noticias
    if endpoint == "videos":
        return normalizar_videos
    if endpoint == "imagenes":
        return normalizar_imagenes
    if endpoint == "sugerir":
        return normalizar_sugerencias
    return lambda datos, consulta, coste: normalizar_contexto(datos, consulta, coste, pipeline)


def _llamar(ses: "C.Sesion", endpoint: str, q: str, pares: Sequence[Tuple[str, str]],
           pipeline_antigua: bool = False, avisos: Sequence[str] = (),
           permitir_no_verificado: bool = False, reintentar: bool = True,
           permitir_sugerir: bool = False, permitir_almacenamiento: bool = False) -> Tuple[List[Dict[str, Any]], Dict[str, Any], Dict[str, Any]]:
    """Una solicitud: caché solo con derecho declarado → presupuesto → reservar → llamar → liquidar.
    Devuelve (registros, meta, coste)."""
    _comprobar_almacenamiento(permitir_almacenamiento, ses.salida)
    spec = ENDPOINTS[endpoint]
    _comprobar_endpoint(endpoint, permitir_sugerir)
    url = url_de(endpoint, pares)
    pipeline = "pipeline-" + API_VERSION_ANTIGUA if pipeline_antigua else "vigente"
    clave_cache = {"v": VERSION, "evidencia": "medicion-br0", "permitir_no_verificado": permitir_no_verificado, "url": url, "api_version": API_VERSION_ANTIGUA if pipeline_antigua else None}
    guardado = ses.cache_leer(PROVEEDOR, clave_cache) if permitir_almacenamiento and endpoint != "sugerir" else None
    if isinstance(guardado, dict) and isinstance(guardado.get("registros"), list) and isinstance(guardado.get("meta"), dict):
        regs = []
        for r in guardado["registros"]:
            r = dict(r)
            r["coste"] = dict(COSTE_CACHE)
            r["consultado"] = C.iso_local()
            regs.append(C.validar_registro(r))
        return regs, guardado["meta"], dict(COSTE_CACHE)
    comprobar_presupuesto_mensual()
    cota = TARIFA.usd if spec["tarifa"] else COTA_NO_VERIFICADA_USD

    def hacer() -> Tuple[int, Any, Any, str, Dict[str, str]]:
        cab = {"X-Subscription-Token": C.clave(PROVEEDOR)}
        if pipeline_antigua:
            cab["Api-Version"] = API_VERSION_ANTIGUA
        # Bajo el mismo cerrojo exterior que el presupuesto mensual y la reserva USD.
        ritmo = C.dir_base() / "ritmo.json"
        anterior = C.leer_json(ritmo, {}).get("ultimo", 0)
        pausa = max(0.0, 1.0 - (time.time() - anterior))
        if pausa:
            time.sleep(pausa)
        C.escribir_privado(ritmo, json.dumps({"ultimo": time.time()}))
        estado, datos, resp = C.http_con_cabeceras("GET", url, None, cab)
        resp = dict(resp)
        guardar_limites(resp)
        if estado == 429:
            resp = _ajustar_429(resp)
        if estado == 400 and _opcion_fuera_del_plan(datos):
            # El común liquida el rechazo a cero. Solo el código determina este error:
            # evitar que texto libre como «plan limit» active su cortacircuitos global.
            datos = {"code": "OPTION_NOT_IN_PLAN"}
        coste: Any = None
        if estado == 200 and isinstance(datos, dict):
            coste = TARIFA.coste() if spec["tarifa"] else C.Coste(fuente="cota")
        return estado, datos, coste, "ok", resp

    concepto = f"{endpoint}: {C.slug(q, 40)}"
    try:
        r = ses.pagada(PROVEEDOR, concepto, cota, hacer, reintentar=reintentar and endpoint != "sugerir",
                       antes_de_reservar=comprobar_presupuesto_mensual)
    except C.ErrorHttp as e:
        if e.estado == 400 and _opcion_fuera_del_plan(e.datos):
            detalle = SUGERIR_NO_INCLUIDO if endpoint == "sugerir" else "tu plan no incluye este endpoint (OPTION_NOT_IN_PLAN)"
            raise ErrorDePlan(PROVEEDOR, 400, f"Brave {endpoint}: {detalle}; sin reintento.", e.datos) from None
        raise
    info = coste_info(r)
    regs, meta = _normalizador(endpoint, pipeline, permitir_no_verificado)(r.datos, q, info)
    if avisos:
        for reg in regs:
            for a in avisos:
                if a not in reg["avisos"]:
                    reg["avisos"].append(a)
    ses.uso({"endpoint": endpoint, "consulta": q, "url_sin_clave": url, "coste_usd": r.coste_usd, "fuente_coste": r.fuente_coste,
             "registros": len(regs), "intentos": r.intentos})
    base = []
    for reg in regs:
        b = dict(reg)
        b["coste"] = None
        base.append(b)
    if permitir_almacenamiento and endpoint != "sugerir":
        ses.cache_guardar(PROVEEDOR, clave_cache, {"registros": base, "meta": meta})
    return regs, meta, info


def llamar(ses: "C.Sesion", endpoint: str, q: str, pares: Sequence[Tuple[str, str]],
           pipeline_antigua: bool = False, avisos: Sequence[str] = (),
           permitir_no_verificado: bool = False, reintentar: bool = True, permitir_sugerir: bool = False,
           permitir_almacenamiento: bool = False):
    """Serializa procesos: cabeceras mensuales, reserva USD, envío y actualización comparten este flock.
    El Libro mantiene además su propio bloqueo interno; no se modifica el cliente común.
    """
    _comprobar_almacenamiento(permitir_almacenamiento, ses.salida)
    with C.Bloqueo(C.dir_base() / "brave.lock", espera=60.0):
        return _llamar(ses, endpoint, q, pares, pipeline_antigua, avisos, permitir_no_verificado, reintentar,
                       permitir_sugerir, permitir_almacenamiento)


def ejecutar_busqueda(ses: "C.Sesion", endpoint: str, q: str, *, paginas: int = 1, pipeline_antigua: bool = False,
                      permitir_no_verificado: bool = False, reintentar: bool = True,
                      permitir_sugerir: bool = False, permitir_almacenamiento: bool = False,
                      **opciones: Any) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Búsqueda de `endpoint` con paginación por `offset` (0 a 9, nunca más). Todas las páginas se validan antes de la
    primera llamada. Para si el proveedor dice que no hay más resultados o si una página viene vacía."""
    _comprobar_almacenamiento(permitir_almacenamiento, ses.salida)
    spec = ENDPOINTS[endpoint]
    _comprobar_endpoint(endpoint, permitir_sugerir)
    if pipeline_antigua and endpoint != "contexto":
        raise _uso("El pipeline antiguo solo se admite en contexto.")
    pagina0 = opciones.pop("pagina", None)
    if not isinstance(paginas, int) or isinstance(paginas, bool) or paginas < 1:
        raise _uso("--paginas debe ser un entero mayor o igual que 1.")
    avisos_nv = ["parametro_no_verificado:" + nombre for nombre, _ in _no_verificados(endpoint, opciones.get("no_verificados") or ())]
    if not spec["tarifa"]:
        avisos_nv.append("Autosuggest_tarifa_no_verificada_cota_local_0.01_USD")
    if spec["offset"] is None:
        if paginas > 1 or pagina0 is not None:
            raise _uso(f"{endpoint} no tiene paginación por offset documentada.")
        planes: List[Tuple[Optional[int], List[Tuple[str, str]]]] = [(None, construir_parametros(endpoint, q, **opciones))]
    else:
        inicio = pagina0 or 0
        if inicio + paginas - 1 > spec["offset"]:
            raise _uso(f"Brave solo admite offset de 0 a {spec['offset']} ({spec['offset'] + 1} páginas): se pidió hasta la "
                       f"página {inicio + paginas - 1}.")
        explicito = pagina0 is not None or paginas > 1
        planes = [(p, construir_parametros(endpoint, q, pagina=p if explicito else None, **opciones))
                  for p in range(inicio, inicio + paginas)]
    vistos = set()
    regs: List[Dict[str, Any]] = []
    meta: Dict[str, Any] = {"endpoint": endpoint, "paginas_pedidas": len(planes), "paginas_hechas": 0, "duplicados": 0,
                            "mas_resultados": None, "consulta_alterada": None, "bloques_ignorados": [],
                            "descartados_por_forma": 0}
    for p, pares in planes:
        pagina_regs, m, _ = llamar(ses, endpoint, q, pares, pipeline_antigua, avisos_nv, permitir_no_verificado,
                                  reintentar, permitir_sugerir, permitir_almacenamiento)
        meta["paginas_hechas"] += 1
        meta["mas_resultados"] = m.get("mas_resultados")
        meta["consulta_alterada"] = m.get("consulta_alterada") or meta["consulta_alterada"]
        meta["descartados_por_forma"] += m.get("descartados_por_forma", 0)
        meta["bloques_ignorados"] = sorted(set(meta["bloques_ignorados"]) | set(m.get("bloques_ignorados") or []))
        if m.get("pipeline"):
            meta["pipeline"] = m["pipeline"]
        nuevos = 0
        for r in pagina_regs:
            clave_dup = (r["url"], r["modo"], r["titulo"]) if r["url"] else None
            if clave_dup is not None and endpoint == "contexto":
                clave_dup += (r["texto_literal"],)  # conservar pasajes distintos de una misma URL
            if clave_dup is not None and clave_dup in vistos:
                meta["duplicados"] += 1
                continue
            if clave_dup is not None:
                vistos.add(clave_dup)
            regs.append(r)
            if permitir_almacenamiento and ses.salida is not None:
                ses.registrar(r)  # conservar páginas ya pagadas si una posterior falla
            nuevos += 1
        if m.get("mas_resultados") is False or not pagina_regs:
            break
    return regs, meta


# ---------------------------------------------------------------------------------------------
# Línea de órdenes
# ---------------------------------------------------------------------------------------------
def _opciones_de(a: argparse.Namespace, endpoint: str) -> Dict[str, Any]:
    g = lambda k, d=None: getattr(a, k, d)  # noqa: E731
    frescura = g("frescura")
    rango = frescura_de_rango(g("desde"), g("hasta"))
    if frescura and rango:
        raise _uso("Usa --frescura o --desde/--hasta, no los dos.")
    o: Dict[str, Any] = {"n": g("n"), "pagina": g("pagina"), "frescura": frescura or rango, "pais": g("pais"),
                         "idioma": g("idioma"), "ui": g("ui"), "seguro": g("seguro"),
                         "filtro": g("filtro"), "snippets_extra": bool(g("snippets_extra")), "goggles": g("goggles") or (),
                         "sin_operadores": bool(g("sin_operadores")), "unidades": g("unidades"), "umbral": g("umbral"),
                         "metadatos": bool(g("metadatos")), "max_urls": g("max_urls"), "max_tokens": g("max_tokens"),
                         "max_snippets": g("max_snippets"), "max_tokens_url": g("max_tokens_url"),
                         "max_snippets_url": g("max_snippets_url"), "no_verificados": g("no_verificado") or ()}
    if g("sin_correccion"):
        o["correccion"] = False
    elif g("con_correccion"):
        o["correccion"] = True
    if g("local") is not None:
        o["local"] = g("local") == "si"
    filtrado = {k: v for k, v in o.items() if k in OPCIONES[endpoint] and (not _vacio(v) or (k in ("correccion", "local") and v is False))}
    filtrado["no_verificados"] = list(g("no_verificado") or ())
    return filtrado


def _vacio(v: Any) -> bool:
    return v is None or v is False or (isinstance(v, (list, tuple)) and not v)


def _precisar_coste(e: Dict[str, Any]) -> Dict[str, Any]:
    """Brave no informa coste real por llamada; añadir la fuente de tarifa al desglose común."""
    coste = e["coste"]
    # El común ya desglosa el origen de cada importe en texto y JSON.
    coste["nota"] = "Estimación por tarifa o cota local, no factura ni coste real informado por Brave."
    coste["tarifa_base_url"] = TARIFA.url
    coste["tarifa_base_fecha"] = TARIFA.fecha
    coste["fuente_evidencia"] = FUENTE_MEDICION
    return e


def _cmd_citas(a: argparse.Namespace) -> int:
    _comprobar_almacenamiento(getattr(a, "permitir_almacenamiento", False), citas=True)
    ses = C.sesion_de_args(a)
    ses.exigir_salida()
    regs = ses.registros()
    if not regs:
        raise _uso("No hay registros guardados en --salida; ejecuta antes una búsqueda.")
    e = _precisar_coste(C.entrega_de_sesion(ses, regs, getattr(a, "titulo", None), getattr(a, "consulta", None)))
    md, js = C.guardar_entrega(ses.salida, e)
    if a.json:
        print(json.dumps(e, ensure_ascii=False, indent=1, default=str))
    else:
        print(f"{len(e['registros'])} resultado(s), {len(e['fallos'])} fallo(s) por URL. Coste: {e['coste']['texto']}"
              f"\n  {C.mostrar_ruta(md)}\n  {C.mostrar_ruta(js)}")
    return C.SALIDA_OK


def _cmd_buscar(a: argparse.Namespace) -> int:
    endpoint = a.cmd
    ses = C.sesion_de_args(a)
    opciones = _opciones_de(a, endpoint)
    regs, meta = ejecutar_busqueda(ses, endpoint, a.consulta, paginas=getattr(a, "paginas", 1) or 1,
                                   pipeline_antigua=bool(getattr(a, "pipeline_antiguo", False)),
                                   permitir_sugerir=bool(getattr(a, "permitir_sugerir", False)),
                                   permitir_almacenamiento=bool(getattr(a, "permitir_almacenamiento", False)),
                                   permitir_no_verificado=bool(getattr(a, "permitir_no_verificado", False)), **opciones)
    e = _precisar_coste(C.entrega_de_sesion(ses, regs, f"brave-search · {endpoint}", a.consulta))
    codigo = C.SALIDA_DESCONOCIDO if e["coste"]["desconocido"] else C.SALIDA_OK
    if a.json:
        print(json.dumps(C.redactar_datos({"registros": e["registros"], "fallos": e["fallos"], "meta": meta, "coste": e["coste"], "cobertura": e["cobertura"],
                          "limites": e["limites"]}), ensure_ascii=False, indent=1, default=str))
        return codigo
    print(C.render_entrega(e))
    notas = [f"Páginas: {meta['paginas_hechas']} de {meta['paginas_pedidas']}"
             + ("; hay más resultados" if meta["mas_resultados"] else ("; no hay más resultados" if meta["mas_resultados"] is False else ""))]
    if meta["consulta_alterada"]:
        notas.append("Brave corrigió la consulta a: " + C.limpiar_control(meta["consulta_alterada"]) + " (usa --sin-correccion para una búsqueda literal)")
    if meta["duplicados"]:
        notas.append(f"{meta['duplicados']} duplicado(s) omitido(s)")
    if meta["bloques_ignorados"]:
        notas.append("Bloques de la respuesta que no se leen: " + ", ".join(meta["bloques_ignorados"]))
    print(C.redactar("\n".join(notas)))
    if ses.salida is not None:
        print(f"Guardado en {C.mostrar_ruta(ses.salida)} (registros.jsonl). `citas` genera la entrega .md + .json.")
    return codigo


def _cmd_deshabilitado(a: argparse.Namespace) -> int:
    raise C.ModoDeshabilitado(f"`{a.cmd}` está deshabilitado. " + ENDPOINTS_DESHABILITADOS[a.cmd])


def estado_saldo() -> Dict[str, Any]:
    mes = dt.datetime.now().strftime("%Y-%m")
    gasto = {}
    try:
        gasto = C.Libro().total_mes(mes).get(PROVEEDOR) or {}
    except C.ErrorBuscadores:
        pass
    usd = float(gasto.get("usd", 0.0)) if gasto else 0.0
    return {"mes": mes, "gastado_usd_estimado": round(usd, 4), "credito_gratis_mensual_usd": CREDITO_GRATIS_MENSUAL_USD,
            "restante_orientativo_usd": round(max(0.0, CREDITO_GRATIS_MENSUAL_USD - usd), 4),
            "fuente_credito": "https://brave.com/search/api/ (leída el " + FECHA_FUENTES + ")", "cabeceras": leer_limites()}


def _cmd_saldo(a: argparse.Namespace) -> int:
    s = estado_saldo()
    if a.json:
        print(json.dumps(s, ensure_ascii=False, indent=1))
        return C.SALIDA_OK
    print(f"Gasto de {s['mes']} según el libro de este skill: {s['gastado_usd_estimado']:.4f} USD (estimado por tarifa o cota; "
          "no es una factura).")
    print(f"Crédito gratis mensual del plan Search: {s['credito_gratis_mensual_usd']:.0f} USD (página de precios, "
          f"{FECHA_FUENTES}); restante orientativo {s['restante_orientativo_usd']:.4f} USD. El saldo real está en el panel de Brave.")
    print("No hay una consulta de saldo gratuita verificada en Brave: este comando NO llama a la red.")
    for linea in _lineas_limites(s["cabeceras"]):
        print(linea)
    return C.SALIDA_OK


def _lineas_limites(lim: Optional[Dict[str, Any]]) -> List[str]:
    if not lim:
        return ["Cabeceras X-RateLimit: aún no se ha leído ninguna (se guardan tras cada llamada)."]
    out = [f"Cabeceras X-RateLimit leídas el {lim.get('leido', 's.d.')}:"]
    for nombre in ("segundo", "mes"):
        v = lim.get(nombre) or {}
        if v.get("limit") is None and v.get("remaining") is None:
            continue
        ilimitado = " (límite 0 = ilimitado)" if v.get("limit") == 0 else ""
        out.append(f"  {nombre}: límite {v.get('limit')} · restantes {v.get('remaining')} · reinicio en {v.get('reset')} s{ilimitado}")
    return out


def _cmd_salud(a: argparse.Namespace) -> int:
    # La función común recibe un único tope; aplicar también el total indicado por CLI.
    a.tope_usd = min(a.tope_usd, a.tope_total_usd)
    rc = C.ejecutar_comun(a)
    print("\nEndpoints habilitados: web, noticias, videos, imagenes, contexto; " + FUENTE_MEDICION + ".")
    print("sugerir: " + SUGERIR_NO_INCLUIDO + ". --permitir-sugerir intenta UNA llamada, sin reintentos.")
    print("Deshabilitados y sin probar: respuestas (Answers), lugares (Place Search). Obsoleto y no implementado: Summarizer.")
    print("Estado de la clave sin gasto: no hay sonda gratuita verificada; `salud --en-vivo` hace UNA búsqueda web mínima.")
    try:
        for linea in _lineas_limites(leer_limites()):
            print(linea)
    except C.ErrorBuscadores:
        pass
    return rc if rc is not None else C.SALIDA_OK


def _opciones_comunes_de_busqueda(sp: argparse.ArgumentParser) -> None:
    C.anadir_opciones_comunes(sp, True)
    sp.add_argument("--permitir-no-verificado", action="store_true",
                    help="permite bloques de respuesta web sin forma verificada; no habilita sugerir")
    sp.add_argument("--no-verificado", action="append", metavar="NOMBRE=VALOR", default=None,
                    help="parámetro que la documentación leída no verifica (sin probar en vivo); solo los permitidos del endpoint")


def _paginacion(sp: argparse.ArgumentParser) -> None:
    sp.add_argument("--pagina", type=int, default=None, help=f"página inicial (offset 0-{PAGINA_MAX})")
    sp.add_argument("--paginas", type=int, default=1, help="cuántas páginas seguidas (cada una es una solicitud; máximo hasta offset 9)")


def _fechas(sp: argparse.ArgumentParser, frescura: bool = True) -> None:
    sp.add_argument("--frescura", default=None, help="pd (24 h) · pw (7 días) · pm (31 días) · py (365 días) · AAAA-MM-DDtoAAAA-MM-DD")
    sp.add_argument("--desde", default=None, help="AAAA-MM-DD (con --hasta forma el rango de frescura)")
    sp.add_argument("--hasta", default=None, help="AAAA-MM-DD")


def construir_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="brave_helper.py", description=__doc__.split("\n")[0])
    C.anadir_opciones_comunes(ap)
    sub = ap.add_subparsers(dest="cmd", required=True)
    C.anadir_subcomandos_comunes(sub)
    sa = sub.add_parser("saldo", help="gasto del mes según el libro y cabeceras X-RateLimit guardadas (sin red)")
    C.anadir_opciones_comunes(sa, True)

    w = sub.add_parser("web", help="búsqueda web (/web/search); discusiones con --filtro web,discussions")
    w.add_argument("consulta")
    w.add_argument("--n", type=C.entero_positivo, default=None, help="resultados por página, 1-20 (20)")
    _paginacion(w)
    _fechas(w)
    w.add_argument("--pais", default=None, help="ES, MX, US… o ALL")
    w.add_argument("--idioma", default=None, help="search_lang: es, en, pt-br…")
    w.add_argument("--ui", default=None, help="ui_lang: es-ES, en-US…")
    w.add_argument("--seguro", choices=ENDPOINTS["web"]["seguro"], default=None)
    w.add_argument("--sin-correccion", action="store_true", help="spellcheck=false (consultas literales)")
    w.add_argument("--con-correccion", action="store_true", help="fuerza spellcheck=true aunque la consulta lleve comillas")
    w.add_argument("--filtro", default="web",
                   help="result_filter: " + ", ".join(RESULT_FILTERS) + " (o «todo» para no filtrar). Por defecto web; discusiones con --filtro web,discussions")
    w.add_argument("--snippets-extra", action="store_true", help="extra_snippets: hasta 5 fragmentos más por resultado")
    w.add_argument("--goggles", action="append", default=None, help=f"URL https o definición en línea (hasta {MAX_GOGGLES})")
    w.add_argument("--sin-operadores", action="store_true", help="operators=false")
    w.add_argument("--unidades", choices=("metric", "imperial"), default=None)
    _opciones_comunes_de_busqueda(w)

    nw = sub.add_parser("noticias", help="búsqueda de noticias (/news/search), plan Search medido")
    nw.add_argument("consulta")
    nw.add_argument("--n", type=C.entero_positivo, default=None, help="1-50 (20)")
    _paginacion(nw)
    _fechas(nw)
    nw.add_argument("--seguro", choices=ENDPOINTS["noticias"]["seguro"], default=None, help="por defecto Brave usa strict")
    _opciones_comunes_de_busqueda(nw)

    vd = sub.add_parser("videos", help="búsqueda de vídeos (/videos/search), plan Search medido")
    vd.add_argument("consulta")
    vd.add_argument("--n", type=C.entero_positivo, default=None, help="1-50 (20)")
    _paginacion(vd)
    _fechas(vd)
    _opciones_comunes_de_busqueda(vd)

    im = sub.add_parser("imagenes", help="búsqueda de imágenes (/images/search), plan Search medido")
    im.add_argument("consulta")
    im.add_argument("--n", type=C.entero_positivo, default=None, help="1-200 (50)")
    im.add_argument("--seguro", choices=ENDPOINTS["imagenes"]["seguro"], default=None)
    _opciones_comunes_de_busqueda(im)

    sg = sub.add_parser("sugerir", help="deshabilitado por defecto: requiere plan Autosuggest (OPTION_NOT_IN_PLAN medido)")
    sg.add_argument("consulta")
    sg.add_argument("--permitir-sugerir", action="store_true", help="intenta UNA llamada, sin reintentos, cota local 0,01 USD; no comprueba el plan previamente")
    _opciones_comunes_de_busqueda(sg)

    cx = sub.add_parser("contexto", help="contexto para un modelo (/llm/context): fragmentos literales por URL, plan Search medido")
    cx.add_argument("consulta")
    cx.add_argument("--n", type=C.entero_positivo, default=None, help="count, 1-50 (20)")
    cx.add_argument("--max-urls", type=int, default=None, help="maximum_number_of_urls, 1-50")
    cx.add_argument("--max-tokens", type=int, default=None, help="maximum_number_of_tokens, 1024-32768")
    cx.add_argument("--max-snippets", type=int, default=None, help="maximum_number_of_snippets, 1-256")
    cx.add_argument("--max-tokens-url", type=int, default=None, help="maximum_number_of_tokens_per_url, 512-8192")
    cx.add_argument("--max-snippets-url", type=int, default=None, help="maximum_number_of_snippets_per_url, 1-100")
    cx.add_argument("--umbral", choices=UMBRALES, default=None, help="context_threshold_mode")
    cx.add_argument("--metadatos", action="store_true", help="enable_source_metadata")
    cx.add_argument("--local", choices=("si", "no"), default=None, help="enable_local (por defecto, detección automática)")
    _fechas(cx)
    cx.add_argument("--goggles", action="append", default=None, help=f"URL https o definición en línea (hasta {MAX_GOGGLES})")
    cx.add_argument("--pais", default=None, help="código de dos letras en minúsculas según la documentación (us, es…)")
    cx.add_argument("--idioma", default=None, help="search_lang")
    cx.add_argument("--seguro", choices=ENDPOINTS["contexto"]["seguro"], default=None)
    cx.add_argument("--pipeline-antiguo", action="store_true",
                    help=f"envía Api-Version: {API_VERSION_ANTIGUA} (pipeline anterior al 2026-07-31); por defecto, el vigente")
    _opciones_comunes_de_busqueda(cx)

    for nombre in ENDPOINTS_DESHABILITADOS:
        d = sub.add_parser(nombre, help=f"{nombre}: DESHABILITADO (ver references/costes-y-limites.md)")
        d.add_argument("consulta", nargs="*")
        C.anadir_opciones_comunes(d, True)
    for parser in (ap, *sub.choices.values()):
        parser.add_argument("--permitir-almacenamiento", action="store_true",
                            default=False if parser is ap else argparse.SUPPRESS,
                            help="declara un plan con derecho de almacenamiento; responsabilidad de quien lo activa")
    return ap


def main(argv: Optional[List[str]] = None) -> int:
    ap = construir_parser()
    a = ap.parse_args(argv)

    def ejecutar() -> int:
        if a.cmd in ENDPOINTS or a.cmd == "citas":
            _comprobar_almacenamiento(a.permitir_almacenamiento, a.salida, a.cmd == "citas")
        if not a.permitir_almacenamiento:
            a.sin_cache = True  # evita también la purga al construir la sesión común
        if a.cmd == "salud":
            return _cmd_salud(a)
        if a.cmd == "citas":
            return _cmd_citas(a)
        if a.cmd == "reanudar":
            raise C.ModoDeshabilitado("Brave no tiene trabajos asíncronos habilitados; reanudar está deshabilitado.")
        if getattr(a, "sin_correccion", False) and getattr(a, "con_correccion", False):
            raise _uso("Elige --sin-correccion o --con-correccion.")
        rc = C.ejecutar_comun(a)
        if rc is not None:
            return rc
        if a.cmd == "saldo":
            return _cmd_saldo(a)
        if a.cmd in ENDPOINTS_DESHABILITADOS:
            return _cmd_deshabilitado(a)
        return _cmd_buscar(a)

    diagnostico = a.cmd in ("salud", "conectar") or (a.cmd == "libro" and getattr(a, "liberar_colgadas", False))
    if a.json and diagnostico:
        if a.cmd == "salud" and a.en_vivo:
            print("--en-vivo: UNA llamada de pago mínima, 0,005 USD por tarifa; sin reintentos.", file=sys.stderr, flush=True)
        salida = io.StringIO()
        with contextlib.redirect_stdout(salida):
            rc = C.correr(ejecutar)
        print(json.dumps({"skill": SKILL, "version": VERSION, "comando": a.cmd, "codigo": rc,
                          "diagnostico": C.redactar(salida.getvalue()), "sonda": "ninguna"}, ensure_ascii=False))
        return rc
    return C.correr(ejecutar)


if __name__ == "__main__":
    sys.exit(main())
