# brave-search 1.0.0

Por defecto se usa **modo transitorio**: los resultados solo salen por stdout (texto o
`--json`), sin leer ni escribir caché de resultados, `registros.jsonl` ni entregas en disco.
El modo transitorio evita que este helper guarde resultados. Redirigir stdout, usar `tee` o conservarlo en ficheros, registros o historiales del agente también puede almacenar resultados y requiere los derechos correspondientes.
`--salida` en una búsqueda y `citas` requieren el flag global
`--permitir-almacenamiento`; sin él devuelven código 2 antes de reservar o llamar.
El flag declara que la cuenta tiene un plan con derecho de almacenamiento y recupera
el comportamiento anterior: caché del día (salvo sugerir o `--sin-cache`), registros y
entregas mediante `citas --permitir-almacenamiento --salida DIR`. **La responsabilidad de tener ese derecho es
de quien activa el flag.** El flag no comprueba ni concede derechos y no se envía a Brave.
El libro de gasto (consulta, costes y reservas), las cabeceras de límites y el ritmo se
siguen guardando sin resultados. `uso.jsonl` sigue dependiendo de `--salida` y solo
contiene datos de la petición y del consumo; en modo transitorio no se crea.

[Términos de Brave, apartado b «Use Restrictions», (i)](https://api-dashboard.search.brave.com/terms-of-service),
lectura **2026-10-17**: «store, cache, or create a database of Search Results, in whole or in part,
other than transient storage required for operation of Customer Applications or related software, service or systems».


Busca fuentes web, noticias, vídeos, imágenes y contexto por URL con Brave Search. Plan Search medido el 2026-10-15 (medicion-br0); sin flag especial. Sugerir está deshabilitado por defecto: tu plan no lo incluye (OPTION_NOT_IN_PLAN, medido); requiere el plan Autosuggest. Python ≥ 3.9, sin paquetes.
Copia la carpeta completa a la carpeta de skills de tu agente y sitúate en ella:

```bash
python3 scripts/brave_helper.py salud
python3 scripts/brave_helper.py conectar brave
python3 scripts/brave_helper.py web "lanzamiento curso online" --idioma es \
  --investigacion ejemplo --tope-total-usd 0.10 --json
# Solo con derecho de almacenamiento:
python3 scripts/brave_helper.py web "consulta" --permitir-almacenamiento \
  --salida estudio --investigacion ejemplo --json
python3 scripts/brave_helper.py citas --permitir-almacenamiento --salida estudio --investigacion ejemplo
```

Copia la clave al portapapeles antes de conectar. Alternativa: `conectar brave --desde-fichero RUTA`.
No pongas su valor en argumentos ni en el chat. `BRAVE_SEARCH_API_KEY` también se admite desde
el entorno. Configuración privada: `~/.brave-search`, sustituible mediante `BRAVE_SEARCH_HOME`.

`salud` es local: «clave presente, validez no comprobada». `salud --en-vivo` hace una búsqueda
mínima de pago, sin reintentos. `saldo` solo muestra gasto local y cabeceras históricas.
Web/noticias/videos/imagenes/contexto: cota y tarifa de 0,005 USD por solicitud; fuente «medición 2026-10-15 (medicion-br0) + tarifa Fase 0». Sugerir sin flag devuelve 2 sin HTTP ni reserva; --permitir-sugerir intenta UNA llamada sin reintentos con cota local 0,01 USD, no tarifa Autosuggest verificada. Cualquier 400 OPTION_NOT_IN_PLAN devuelve 5 y deja disponibles los otros endpoints.
Por defecto 0,50 USD por llamada y 1,50 USD por investigación. Cada página y reintento cuenta.

La medición propia del 2026-10-15 confirma HTTP 200 y política compartida del plan Search; suggest devolvió 400 OPTION_NOT_IN_PLAN. Los fixtures de contrato son sintéticos; `scripts/fixtures/smoke_sintetico.json` prueba estructura y costes con contenido inventado; no se redistribuyen resultados reales. Evals con juez ciego (16-oct-2026): ver `evals/resultados.md`. Windows sin probar.

Lee `SKILL.md` para elegir receta, parámetros, límites y contrato de entrega.
Pruebas sin red únicamente en el entorno de verificación:
`cd scripts && python3 -m unittest -v test_brave_helper`.
