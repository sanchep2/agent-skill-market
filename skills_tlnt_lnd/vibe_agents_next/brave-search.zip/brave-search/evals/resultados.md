# Resultados — brave-search 1.0.0

Fecha: 16-oct-2026. Lo que sigue es lo medido, tal cual; donde el skill no gana o no se pudo comprobar algo, se dice.

Las evals del 16-oct-2026 guardaron resultados en ficheros. Desde esta versión, eso
exige `--permitir-almacenamiento` y un plan con derecho de almacenamiento; la
responsabilidad de tener ese derecho es de quien activa el flag. El modo predeterminado
es transitorio, con resultados solo en stdout. Véanse los [términos b (i)](https://api-dashboard.search.brave.com/terms-of-service),
lectura 2026-10-17. Los prompts siguientes documentan las evaluaciones históricas.

## Pruebas automáticas

- `cd scripts && python3 -m unittest discover -p "test_*.py"`: **117 pruebas, OK**, sin red, con HOME vacío y
  Python 3.14. La sintaxis de los módulos se comprueba también con la gramática de Python 3.9; no se ha ejecutado en un
  intérprete 3.9 real.
- La copia de `buscadores_comun.py` coincide con el SHA-256 declarado en `scripts/COMUN.sha256`
  (`c2520164bfe171b7812420fad0ed39b8bad287ba3349b945fd946488e39f65bb`) y con las copias de los otros tres skills de
  buscadores. Las pruebas del cliente común viajan con exa-search.
- Auditoría adversarial en seis rondas, con todos los hallazgos corregidos; la sexta da APTO. Intentó que el skill pasara
  el tope, apuntara 0 cuando el coste es desconocido, usara funciones retiradas, siguiera instrucciones de una página o
  imprimiera una clave.
- Medición del plan (15-oct-2026): news, videos, images y llm/context responden 200 con la misma política de límite que
  web; suggest responde 400 `OPTION_NOT_IN_PLAN` en el plan Search.

## Smoke real (15-oct-2026)

Revisión manual, ficha a ficha, de títulos, URL y extractos guardados. «Útil» significa que la ficha responde a la
pregunta del tema con contenido propio y en un idioma útil para la consulta. T1: «AI automation agency clients» (inglés,
negocio); T2: «lanzamiento de curso online» (español, marketing); T3: «vibe coding» (técnico).

| Modo | T1 | T2 | T3 | Nota |
|---|---|---|---|---|
| web | 11/20 | 10/10 web + **0/10 discusiones** | 10/10 | T1: 8 listas de «mejores agencias», que no responden a «primeros clientes». T2: el bloque de discusiones trae hilos de Reddit sobre cursos gratis, fuera de tema |
| noticias / vídeos / imágenes | — | — | 10/10 · 5/5 · 3/5 | Imágenes: 2 hilos de Reddit sin relación directa |
| contexto (llm/context) | 16/17 | — | — | El mejor modo de Brave para el tema de negocio |

Coste del smoke: **0,040 USD estimados por tarifa** (Brave no devuelve coste por llamada).

Todos los modos pasan la puerta de ≥ 50 % útil, salvo el bloque de discusiones de T2 en español (0/10). Por eso `web` ya
no pide discusiones por defecto (`result_filter=web`); se piden con `--filtro web,discussions`. El smoke no se ha
repetido tras ese cambio.

## Evals con y sin el skill (16-oct-2026)

**Método.** Dos escenarios de `evals.json`. El mismo agente de código hace cada escenario dos veces: con el skill y sin él
(su búsqueda web normal, sin navegador ni APIs de pago). Las entregas se copian como X e Y al azar y la clave se guarda
aparte. Juzgan:

- **Un juez que solo ve las dos respuestas.**
- **Tres jueces de tres proveedores distintos que ven además la evidencia de cada lado** (traza del agente y ficheros
  generados: registros, libro de gasto). Los criterios de proceso solo se pueden comprobar con ella. Cada juez comprueba
  a mano al menos 3 URL por entrega.

**Escenarios.**

- **e1:** fuentes originales en español sobre captación de alumnos y lanzamiento de cursos online entre el 1 y el 14 de
  octubre de 2026; hasta cinco extractos, como mucho dos páginas de resultados y un presupuesto de 0,10 USD.
- **e2:** contexto original en inglés para evaluar la recuperación híbrida en RAG, con `llm/context` (8.192 tokens, 10 URL
  y metadatos), pasajes por URL y un presupuesto de 0,10 USD.

| Escenario | Juez | Criterios con skill | Criterios sin skill | Calidad con skill (0-10) | Calidad sin skill | Mejor |
|---|---|---|---|---|---|---|
| e1 | Solo respuestas | 2/6 | 2/6 | 5 | 7 | **sin el skill** |
| e1 | Juez A (con evidencia) | 6/6 | 3/6 | 6 | 6 | con el skill |
| e1 | Juez B (con evidencia) | 6/6 | 3/6 | 6 | 5 | con el skill |
| e1 | Juez C (con evidencia) | 4/6 | 2/6 | 6,5 | 6 | con el skill |
| e2 | Solo respuestas | 1/7 | 2/7 | 7 | 8 | **sin el skill** |
| e2 | Juez A (con evidencia) | 4/7 | 1/7 | 8 | 7 | con el skill |
| e2 | Juez B (con evidencia) | 5/5 | 1/5 | 8 | 7 | con el skill |
| e2 | Juez C (con evidencia) | 3/7 | 2/7 | 7,5 | 7 | con el skill |

Los tres jueces con evidencia eligen el skill en los dos escenarios, **pero con poca diferencia de calidad**: entre 0 y
1 punto. El juez que solo ve las respuestas prefiere la línea base en los dos.

**Lo que decide la diferencia, según los jueces:**

- **Con el skill:** los parámetros pedidos están en las llamadas reales (`count`, `offset`, idioma, `freshness` por
  rango); las citas son subcadena exacta del texto de la fuente; los autores y fechas ausentes quedan en blanco, sin
  inventar; el libro cuenta la solicitud y no los resultados (0,010 y 0,005 USD); se revisan los descartes y se guardan
  el JSON y el Markdown.
- **Sin el skill:** **acierta más en el contenido**. En e1 encuentra dos fuentes en español muy pertinentes, con cita,
  autor y fecha comprobados en la página. En e2 hace una selección académica más sólida. No acredita los parámetros ni el
  presupuesto, y no guarda los ficheros.

**Punto débil del skill.** En e1, el skill entrega un solo extracto, de pertinencia indirecta, cuando existían fuentes más
directas (las que encontró la línea base). El índice de Brave en español para fechas tan recientes es pobre. En e2,
`llm/context` devuelve buen texto, pero menos fuentes primarias que una búsqueda académica.

**Invenciones.**

- **Con el skill: ninguna.**
- **Sin el skill:** autores institucionales («Microsoft», «Elastic») atribuidos por el dominio, que la página no nombra.

**Lo que no se pudo comprobar:** los casos simulados de noticias, vídeos, imágenes, sugerir y `OPTION_NOT_IN_PLAN` no se
ejecutaron en la eval; solo estaban descritos en la documentación que leyó el agente. Los cubren las pruebas automáticas.

**Coste real de las evals con el skill** (estimado por tarifa: 5 USD por 1.000 solicitudes):

| Escenario | Solicitudes | Coste |
|---|---|---|
| e1 | 2 | 0,010 USD |
| e2 | 1 | 0,005 USD |

## Límites conocidos

- La ventaja del skill es de trazabilidad (parámetros, citas literales, coste y ficheros), no de mejores fuentes. Para
  temas en español muy recientes, combínalo con otro buscador.
- Brave no devuelve coste: se calcula por tarifa y se etiqueta como estimado.
- `sugerir` solo con `--permitir-sugerir`: el plan Search devuelve `OPTION_NOT_IN_PLAN`. Answers y Place van en otros
  planes y no se han probado.
- Las discusiones no van por defecto: en español trajeron hilos fuera de tema.
- Pruebas automáticas en Linux; smoke y evals en macOS. En Windows no se ha probado.
