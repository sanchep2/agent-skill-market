# Usar desde otro skill

Por defecto se usa **modo transitorio**: los resultados solo salen por stdout (texto o
`--json`), sin leer ni escribir caché de resultados, `registros.jsonl` ni entregas en disco.
El modo transitorio evita que este helper guarde resultados. Redirigir stdout, usar `tee` o conservarlo en ficheros, registros o historiales del agente también puede almacenar resultados y requiere los derechos correspondientes.
`--salida` en una búsqueda y `citas` requieren el flag global
`--permitir-almacenamiento`; sin él devuelven código 2 antes de reservar o llamar.
El flag declara que la cuenta tiene un plan con derecho de almacenamiento y recupera
el comportamiento anterior: caché del día (salvo sugerir o `--sin-cache`), registros y
entregas mediante `citas --permitir-almacenamiento --salida DIR`. **La responsabilidad de tener ese derecho es
de quien activa el flag.** El flag no comprueba ni concede derechos y no se envía a Brave.
El libro de gasto (consulta, costes y reservas), las cabeceras de límites y el ritmo se
siguen guardando sin resultados. `uso.jsonl` sigue dependiendo de `--salida` y solo
contiene datos de la petición y del consumo; en modo transitorio no se crea.

[Términos de Brave, apartado b «Use Restrictions», (i)](https://api-dashboard.search.brave.com/terms-of-service),
lectura **2026-10-17**: «store, cache, or create a database of Search Results, in whole or in part,
other than transient storage required for operation of Customer Applications or related software, service or systems».


## Contenido
- [Invocación](#invocación)
- [JSON y estado](#json-y-estado)
- [Códigos](#códigos)

## Invocación

Proceso separado Python ≥3.9; importa su propia copia scripts/buscadores_comun.py.
No necesita otra carpeta instalada. La configuración común es global al intérprete: no
mezclar varios helpers importados en un solo proceso. La ficha TOML solo declara contrato;
no instala adaptador ni prueba integración con un consumidor.

```bash
python3 "$SKILL_DIR/scripts/brave_helper.py" web "hybrid retrieval evaluation" \
  --n 10 --idioma en --sin-correccion --investigacion estudio-01 \
  --tope-usd 0.01 --tope-total-usd 0.10 --json
# Para guardar, repetir la búsqueda con el derecho declarado:
python3 "$SKILL_DIR/scripts/brave_helper.py" web "hybrid retrieval evaluation" \
  --permitir-almacenamiento --salida "$SALIDA" --investigacion estudio-01 --json
python3 "$SKILL_DIR/scripts/brave_helper.py" citas --permitir-almacenamiento --salida "$SALIDA" \
  --investigacion estudio-01 --json
```

Solo registros con URL y texto_literal alimentan citas literales. Referencias y cualquier
respuesta_generada permanecen contexto separado. Sin comando leer ni lectura completa por URL.
`--permitir-almacenamiento` y `--salida` son obligatorios para guardar registros y
entregas. Solo con el flag se mantiene caché de resultados incluso sin salida; el libro
y las cabeceras se mantienen en ambos modos. ID por defecto: salida absoluta, o sin-salida.
Usa ID explícito al compartir presupuesto y no mezcles investigaciones en una carpeta.

## JSON y estado

Web/noticias/videos/imagenes/sugerir/contexto --json: objeto con registros[], fallos[], meta,
coste (texto/desglose/desconocido), cobertura y limites. Coste es de toda la investigación,
no solo último intento; guarda DESCONOCIDO si hubo pérdidas antes de éxito.
Citas --json: sobre común con skill, version, titulo, consulta, consultado, registros,
fallos, coste, cobertura y limites. Libro --ver y pendientes: JSON del cliente común.
Salud/conectar/libro --liberar-colgadas --json: skill, version, comando, codigo,
diagnostico redactado y sonda=ninguna. Salud en vivo anuncia pago en stderr antes de llamar.
Saldo --json: mes, gastado_usd_estimado, credito_gratis_mensual_usd,
restante_orientativo_usd, fuente_credito y cabeceras históricas. No hay saldo remoto.

Errores van a stderr redactado. Comprobar código antes de parsear stdout; algunos errores
comunes (p. ej. citas sin registros) imprimen diagnóstico textual. No hacer reintentos
externos automáticos: el helper ya hace hasta dos para llamadas síncronas y pueden costar.
`--sin-cache` evita lectura y escritura de caché aun con `--permitir-almacenamiento`;
sin este último, la caché siempre está desactivada. No evita libro ni reserva.
Al importar el helper directamente, construye `C.Sesion(usar_cache=False)` en modo
transitorio para evitar la purga del cliente común. Las funciones `ejecutar_busqueda`,
`llamar` y `_llamar` exigen `permitir_almacenamiento=True` para acceder a la caché o
aceptar una sesión con salida; su valor por defecto es `False`.

## Códigos

| Código | Significado |
|---|---|
| 0 | Éxito, búsqueda vacía o salud diagnóstica incluso con clave FALTA/MAL |
| 1 | Error general/contrato/HTTP no clasificado |
| 2 | Uso incorrecto o modo deshabilitado (incluye --salida o citas sin --permitir-almacenamiento, sugerir sin --permitir-sugerir, reanudar y citas sin registros) |
| 3 | Clave ausente, mal formada o rechazada |
| 4 | Cota no cabe en tope por llamada o investigación |
| 5 | Error de plan de endpoint: 400 OPTION_NOT_IN_PLAN; también límite proveedor/cuota, 402/429 o cabecera mensual agotada |
| 6 | Resultado desconocido o reservas pendientes |

Medición 2026-10-15 (medicion-br0) + tarifa Fase 0: Search habilita web/noticias/videos/imagenes/contexto sin flags (cota 0,005 USD). Sugerir requiere Autosuggest: --permitir-sugerir intenta UNA llamada con cota local 0,01 USD, sin reintento ni caché. Un 400 OPTION_NOT_IN_PLAN no rechaza la clave ni para otros endpoints.

No hay trabajos asíncronos Brave habilitados (BUS-C2); no se inventan sondeos ni cancelación.
Libro --liberar-colgadas liquida cota entera. Es recuperación explícita tras comprobar que
el proceso terminó, no forma de liberar presupuesto de un trabajo posiblemente activo.
