# Parámetros

Por defecto se usa **modo transitorio**: los resultados solo salen por stdout (texto o
`--json`), sin leer ni escribir caché de resultados, `registros.jsonl` ni entregas en disco.
`--salida` en una búsqueda y `citas` requieren el flag global
`--permitir-almacenamiento`; sin él devuelven código 2 antes de reservar o llamar.
El flag declara que la cuenta tiene un plan con derecho de almacenamiento y recupera
el comportamiento anterior: caché del día (salvo sugerir o `--sin-cache`), registros y
entregas mediante `citas --permitir-almacenamiento --salida DIR`. **La responsabilidad de tener ese derecho es
de quien activa el flag.** El flag no comprueba ni concede derechos y no se envía a Brave.
El libro de gasto (consulta, costes y reservas), las cabeceras de límites y el ritmo se
siguen guardando sin resultados. `uso.jsonl` sigue dependiendo de `--salida` y solo
contiene datos de la petición y del consumo; en modo transitorio no se crea.

[Términos de Brave, apartado b «Use Restrictions», (i)](https://api-dashboard.search.brave.com/terms-of-service),
lectura **2026-10-17**: «store, cache, or create a database of Search Results, in whole or in part,
other than transient storage required for operation of Customer Applications or related software, service or systems».


## Contenido
- [Web](#web)
- [Otros endpoints](#otros-endpoints)
- [Contexto](#contexto)
- [Sin verificar y retirados](#sin-verificar-y-retirados)

## Opciones globales locales

`--permitir-almacenamiento` se admite antes o después del subcomando, no cambia
parámetros de API y exige que quien lo active tenga el derecho correspondiente.
`--sin-cache` mantiene desactivada la caché incluso con ese permiso.

```bash
python3 scripts/brave_helper.py web "consulta" --investigacion ejemplo --json
python3 scripts/brave_helper.py web "consulta" --permitir-almacenamiento --salida estudio --json
python3 scripts/brave_helper.py citas --permitir-almacenamiento --salida estudio
```

## Web

GET `https://api.search.brave.com/res/v1/web/search`, sin cuerpo; cabecera
`X-Subscription-Token`, nunca clave en URL. Fuente B1:
https://api-dashboard.search.brave.com/api-reference/web/search/get (2026-10-15).

| CLI | Query string | Validación |
|---|---|---|
| consulta | q | 1–600 caracteres, ≤75 palabras |
| --n | count | 1–20; defecto 20 |
| --pagina | offset | 0–9; --paginas repite llamadas sin pasar 9 |
| --frescura | freshness | pd/pw/pm/py o AAAA-MM-DDtoAAAA-MM-DD |
| --desde, --hasta | freshness | ambos, fechas reales y ordenadas; incompatible con --frescura |
| --pais | country | dos letras mayúsculas o ALL |
| --idioma | search_lang | es/en/pt-br/zh-hans; valida forma, no catálogo completo |
| --ui | ui_lang | es-ES/en-US; valida forma |
| --seguro | safesearch | off/moderate/strict |
| --sin-correccion | spellcheck=false | también automático si q contiene comillas dobles |
| --con-correccion | spellcheck=true | fuerza corrección incluso con comillas |
| --filtro | result_filter | defecto web; web,discussions solicita discusiones; también faq,news,videos,query; todo omite filtro |
| --snippets-extra | extra_snippets=true | hasta cinco según la documentación |
| --goggles (repetible) | goggles repetido | hasta tres, HTTPS o definición en línea |
| --sin-operadores | operators=false | desactiva operadores |
| --unidades | units | metric/imperial |

Siempre envía `text_decorations=false`. No hay cuerpo POST en los seis endpoints implementados.
El catálogo de filtros documentado es más amplio: infobox/locations/summarizer se rechazan
por forma sin verificar, dependencia de otro endpoint u obsolescencia. news/videos/faq
superiores no se normalizan salvo aceptación explícita; qa/faq anidados sí.

## Otros endpoints

Todas las rutas siguientes llevan prefijo `/res/v1`. Noticias, vídeos e imágenes están habilitados sin flag: medición 2026-10-15 (medicion-br0) + tarifa Fase 0, 0,005 USD por solicitud. Sugerir sigue deshabilitado por defecto: tu plan no lo incluye (OPTION_NOT_IN_PLAN, medido); requiere el plan Autosuggest. --permitir-sugerir permite UNA llamada sin reintento (cota local 0,01 USD, no precio Autosuggest verificado); el flag nunca se envía al proveedor.

| Comando | Ruta | Parámetros verificados |
|---|---|---|
| noticias | /news/search | q, count 1–50 (20), offset 0–9, freshness, safesearch off/moderate/strict |
| videos | /videos/search | q, count 1–50 (20), offset 0–9, freshness |
| imagenes | /images/search | q, count 1–200 (50), safesearch off/strict |
| sugerir | /suggest/search | q; solo variante simple, sin rich |

Fuentes del 2026-10-15: [noticias](https://api-dashboard.search.brave.com/documentation/services/news-search),
[vídeos](https://api-dashboard.search.brave.com/documentation/services/video-search),
[imágenes](https://api-dashboard.search.brave.com/documentation/services/image-search),
[sugerencias](https://api-dashboard.search.brave.com/documentation/services/suggest).
Las cotas inferiores conservadoras para count son validaciones propias donde la Fase 0 solo recoge máximo.

## Contexto

GET `/res/v1/llm/context`, habilitado sin flag especial por la medición 2026-10-15 (medicion-br0) + tarifa Fase 0, cota 0,005 USD por solicitud. Fuente: https://api-dashboard.search.brave.com/documentation/services/llm-context,
2026-10-15. `q`, `count` 1–50 (20), frescura, goggles, país minúsculo, idioma y seguro.

| CLI | Nombre de API | Rango; defecto del proveedor si se omite |
|---|---|---|
| --max-urls | maximum_number_of_urls | 1–50; 20 |
| --max-tokens | maximum_number_of_tokens | 1024–32768; 8192 |
| --max-snippets | maximum_number_of_snippets | 1–256; 50 |
| --max-tokens-url | maximum_number_of_tokens_per_url | 512–8192; 4096 |
| --max-snippets-url | maximum_number_of_snippets_per_url | 1–100; 50 |
| --umbral | context_threshold_mode | strict/balanced/lenient/disabled |
| --metadatos | enable_source_metadata=true | false por defecto |
| --local si/no | enable_local=true/false | detección automática si se omite |

Pipeline vigente desde 2026-07-31; `--pipeline-antiguo` añade `Api-Version: 2026-02-06`.
Los límites de snippets no son duros en el pipeline vigente. `--metadatos` solicita metadatos,
pero no inventa autor ni fecha. La normalización usa título y age ISO de sources; no exporta
favicon, thumbnail o fetched_content_timestamp como campos del registro común.

## Sin verificar y retirados

`--no-verificado NOMBRE=VALOR` es repetible; marca cada registro como sin probar en vivo:
noticias admite country/search_lang/ui_lang/spellcheck/extra_snippets/goggles;
vídeos country/search_lang/ui_lang/spellcheck/safesearch;
imágenes country/search_lang/spellcheck; sugerir country/lang/count.
Son hipótesis de contrato, no opciones confirmadas. Web/contexto no admiten este escape.

`summary`, `enable_rich_callback`, `include_fetch_metadata` no salen nunca. Solo summary
está relacionado con el Summarizer obsoleto; los otros dos se excluyen por descripción
insuficiente o capacidad no usada, no se afirma que hayan sido retirados.
Spellcheck separado no implementado: parámetros no verificados (Fase 0 §6).
