# Instalación y alta

## Contenido
- [Instalar](#instalar)
- [Conectar](#conectar)
- [Estado y diagnóstico](#estado-y-diagnóstico)

## Instalar

Copia íntegra de brave-search a la carpeta de skills de tu agente, por ejemplo
~/.claude/skills/brave-search o ~/.codex/skills/brave-search. No requiere pip ni SDK.
Python ≥3.9, solo biblioteca estándar; Windows sin probar. Invoca desde esa carpeta o por
ruta absoluta. scripts/buscadores_comun.py y COMUN.sha256 deben viajar juntos.

## Conectar

Panel y documentación oficial: https://api-dashboard.search.brave.com/documentation.
Precios: https://brave.com/search/api/, leídos el 2026-10-15. Search anuncia crédito mensual
5 USD, no afirmar 2000 consultas gratis de la guía antigua. Verifica el plan en el panel;
la medición 2026-10-15 (medicion-br0) confirmó los cinco endpoints Search (web, noticias, vídeos, imágenes y contexto), con tarifa Fase 0 de 0,005 USD por solicitud. Sugerir devolvió OPTION_NOT_IN_PLAN: requiere Autosuggest; otras claves solo se comprueban con --permitir-sugerir (UNA llamada, cota local 0,01 USD, sin reintentos). No se verificaron menús actuales.

Copia la clave al portapapeles y ejecuta:

```bash
python3 scripts/brave_helper.py conectar brave
python3 scripts/brave_helper.py conectar brave --desde-fichero clave.txt
python3 scripts/brave_helper.py salud
```

Alternativas portapapeles/fichero son independientes. Nunca valor de clave en chat o argv.
El helper guarda claves.env 0600 en ~/.brave-search; BRAVE_SEARCH_HOME permite otra carpeta.
También acepta BRAVE_SEARCH_API_KEY previamente definida en el entorno. El entorno tiene
prioridad. No copies claves.env al skill, al repositorio ni a las entregas.

## Estado y diagnóstico

Sin clave → salud 0 con FALTA y capacidad perdida → conectar → salud local.
Clave presente → «validez no comprobada», no OK de autenticación. Salud --en-vivo anuncia
una búsqueda mínima pagada (0,005 USD), sin reintentos y con tope máximo 0,05 USD.
El código 0 de salud indica diagnóstico completado, no éxito de autenticación remota.

Estado privado: gasto.jsonl y cerrojos, cache, limites.json y ritmo.json. Saldo no consulta
la cuenta: muestra gasto local y cabeceras históricas. Las pruebas usan HOME temporal y
clave falsa; nunca necesitan claves reales ni otra instalación. No imprimir claves al
diagnosticar errores; compartir solo mensajes saneados y evidencia sin secretos.
