# Método y recetas

Por defecto se usa **modo transitorio**: los resultados solo salen por stdout (texto o
`--json`), sin leer ni escribir caché de resultados, `registros.jsonl` ni entregas en disco.
`--salida` en una búsqueda y `citas` requieren el flag global
`--permitir-almacenamiento`; sin él devuelven código 2 antes de reservar o llamar.
El flag declara que la cuenta tiene un plan con derecho de almacenamiento y recupera
el comportamiento anterior: caché del día (salvo sugerir o `--sin-cache`), registros y
entregas mediante `citas --permitir-almacenamiento --salida DIR`. **La responsabilidad de tener ese derecho es
de quien activa el flag.** El flag no comprueba ni concede derechos y no se envía a Brave.
El libro de gasto (consulta, costes y reservas), las cabeceras de límites y el ritmo se
siguen guardando sin resultados. `uso.jsonl` sigue dependiendo de `--salida` y solo
contiene datos de la petición y del consumo; en modo transitorio no se crea.

[Términos de Brave, apartado b «Use Restrictions», (i)](https://api-dashboard.search.brave.com/terms-of-service),
lectura **2026-10-17**: «store, cache, or create a database of Search Results, in whole or in part,
other than transient storage required for operation of Customer Applications or related software, service or systems».

## Contenido
- [Elegir](#elegir)
- [Recetas](#recetas)
- [Comprobar](#comprobar)

## Elegir

Pregunta → idioma/país/ventana → endpoint → reserva → stdout → revisión.
Solo con derecho de almacenamiento declarado: registros → citas.
Las recetas siguen la finalidad declarada en las páginas oficiales. El [smoke real del 15-oct-2026](../evals/resultados.md#smoke-real-15-oct-2026) revisó cada ficha: en T2, español, web obtuvo 10/10 útiles y discusiones 0/10 (hilos sobre cursos gratis, fuera de tema). Por ello `web` envía `result_filter=web` por defecto; pide discusiones con `--filtro web,discussions` y revisa su pertinencia por separado. Fuentes oficiales leídas el 2026-10-15; esta corrección no repite llamadas.

| Necesidad | Modo | Fuente | Coste esperado por solicitud |
|---|---|---|---|
| Descubrir páginas; foros solo con `--filtro web,discussions` | web | https://api-dashboard.search.brave.com/documentation/services/web-search | 0,005 USD por tarifa Search |
| Noticias por ventana | noticias | https://api-dashboard.search.brave.com/documentation/services/news-search | 0,005 USD, plan Search medido + tarifa Fase 0 |
| Vídeos | videos | https://api-dashboard.search.brave.com/documentation/services/video-search | 0,005 USD, plan Search medido + tarifa Fase 0 |
| Imágenes | imagenes | https://api-dashboard.search.brave.com/documentation/services/image-search | 0,005 USD, plan Search medido + tarifa Fase 0 |
| Completar consultas | sugerir | https://api-dashboard.search.brave.com/documentation/services/suggest | Autosuggest requerido; --permitir-sugerir, una llamada, cota local 0,01 USD |
| Grounding para LLM | contexto | https://api-dashboard.search.brave.com/documentation/services/llm-context | 0,005 USD, plan Search medido + tarifa Fase 0 |

Web, noticias, vídeos, imágenes y contexto están habilitados sin flag especial: medición 2026-10-15 (medicion-br0) + tarifa Fase 0. Sugerir: tu plan no lo incluye (OPTION_NOT_IN_PLAN, medido); requiere el plan Autosuggest. --permitir-sugerir intenta UNA llamada sin reintento con cota local 0,01 USD; un 400 de plan devuelve 5 sin parar los demás endpoints.
Las sugerencias no son citas; las imágenes no dan automáticamente texto fuente ni licencia.

## Recetas

Ejemplo transitorio desde la raíz del skill:

```bash
python3 scripts/brave_helper.py web "consulta" --investigacion ejemplo --json
```

Los ejemplos siguientes guardan resultados: requieren tener derecho de almacenamiento
y activar el flag. Mantén salidas e ID coherentes en toda la investigación:

```bash
python3 scripts/brave_helper.py web '"online course launch"' --sin-correccion \
  --idioma en --pais ALL --n 20 --paginas 2 --snippets-extra \
  --permitir-almacenamiento --salida estudio --investigacion ejemplo --tope-total-usd 0.10 --json
# Solo si se necesitan discusiones: el smoke T2 en español obtuvo 0/10 útiles.
python3 scripts/brave_helper.py web 'lanzamiento de curso online' --idioma es --filtro web,discussions \
  --permitir-almacenamiento --salida estudio --investigacion ejemplo --tope-total-usd 0.10 --json
python3 scripts/brave_helper.py noticias 'AI release' --n 5 --frescura pd --permitir-almacenamiento --salida estudio --investigacion ejemplo
python3 scripts/brave_helper.py contexto 'hybrid retrieval' --max-tokens 8192 --max-urls 10 --metadatos \
  --permitir-almacenamiento --salida estudio --investigacion ejemplo --tope-total-usd 0.10 --json
python3 scripts/brave_helper.py citas --permitir-almacenamiento --salida estudio --investigacion ejemplo
```

Goggles solo indicados por la persona: `--goggles https://example.org/reglas.goggle`.
No se crean ni descargan goggles desde este helper. Un operador `site:` va dentro de la consulta.

## Comprobar

Comprueba URL, relevancia, idioma y fecha fuente. Una fecha no disponible sigue null, aunque
se filtró por frescura. Menos resultados que `--n` es válido; la paginación no garantiza
resultados nuevos. Revisa duplicados y bloques ignorados en meta. No uses una búsqueda por
URL como prueba de lectura íntegra. Ante cuota agotada, conserva evidencia y declara el límite.
