# Costes y límites

Por defecto se usa **modo transitorio**: los resultados solo salen por stdout (texto o
`--json`), sin leer ni escribir caché de resultados, `registros.jsonl` ni entregas en disco.
`--salida` en una búsqueda y `citas` requieren el flag global
`--permitir-almacenamiento`; sin él devuelven código 2 antes de reservar o llamar.
El flag declara que la cuenta tiene un plan con derecho de almacenamiento y recupera
el comportamiento anterior: caché del día (salvo sugerir o `--sin-cache`), registros y
entregas mediante `citas --permitir-almacenamiento --salida DIR`. **La responsabilidad de tener ese derecho es
de quien activa el flag.** El flag no comprueba ni concede derechos y no se envía a Brave.
El libro de gasto (consulta, costes y reservas), las cabeceras de límites y el ritmo se
siguen guardando sin resultados. `uso.jsonl` sigue dependiendo de `--salida` y solo
contiene datos de la petición y del consumo; en modo transitorio no se crea.

[Términos de Brave, apartado b «Use Restrictions», (i)](https://api-dashboard.search.brave.com/terms-of-service),
lectura **2026-10-17**: «store, cache, or create a database of Search Results, in whole or in part,
other than transient storage required for operation of Customer Applications or related software, service or systems».


## Contenido
- [Tarifa y cotas](#tarifa-y-cotas)
- [Libro y cabeceras](#libro-y-cabeceras)
- [Errores](#errores)
- [Modos deshabilitados](#modos-deshabilitados)

## Tarifa y cotas

Fuente B13, leída el 2026-10-15: https://brave.com/search/api/.
Search anuncia **5 USD/1000 solicitudes**, crédito mensual 5 USD, 50 QPS.
Una solicitud web: 5/1000 = **0,005 USD**; diez páginas: 0,05 USD antes de reintentos.
El resultado del libro es estimación por tarifa, nunca factura ni coste real informado.
No se encontró campo de coste en Brave (Fase 0 §10); coste real por llamada no verificado.

La incertidumbre de Fase 0 §7 sobre inclusión de endpoints queda resuelta por BUS-C4:
medición 2026-10-15 23:03 CDMX (medicion-br0, registro.json), aportada por el usuario,
coste aproximado 0,025 USD. news/search, videos/search, images/search y llm/context:
HTTP 200; igual que web/search, X-RateLimit-Policy `50;w=1, 0;w=2678400` y
X-RateLimit-Limit `50, 0`. Cota por solicitud = tarifa Search 0,005 USD; fuente
«medición 2026-10-15 (medicion-br0) + tarifa Fase 0». Es combinación de plan medido
y precio publicado, no coste informado en cada respuesta ni medición de relevancia.
Suggest/search devolvió HTTP 400, code OPTION_NOT_IN_PLAN, «The option is not included
in the plan.»: tu plan no lo incluye (OPTION_NOT_IN_PLAN, medido); requiere el plan Autosuggest.
Sin --permitir-sugerir: código 2, sin reserva ni envío. Con el flag: UNA llamada, sin
reintentos ni caché; cota local estimada 0,01 USD (2 × tarifa Search histórica), no
precio Autosuggest verificado ni límite contractual. La inclusión de otra clave no se
puede conocer sin llamar; no se presenta este intento como sondeo gratuito.

| Caso | Registro |
|---|---|
| Search correcto (web/noticias/videos/imagenes/contexto) | tarifa y cota 0,005 con tarifa_url, tarifa_fecha y fuente_evidencia |
| Sugerir sin flag | rechazo local con código 2, sin reserva ni envío |
| Sugerir con flag correcto | cota local 0,01 USD, una llamada |
| 400 OPTION_NOT_IN_PLAN (cualquier endpoint) | error de plan, código 5; rechazo a cero, sin reintento ni cortacircuitos de clave |
| Respuesta perdida/red/5xx | cota completa liquidada; DESCONOCIDO, nunca cero |
| Pérdida seguida de éxito | coste total conserva ambos intentos y DESCONOCIDO; código 6 en texto y JSON |
| Caché | sin llamada nueva, 0 USD adicional; el gasto anterior sigue en el libro |
| Proveedor informara coste real en el futuro | no se inventa: ampliar contrato tras verificar campo |

Topes: 0,50 USD por llamada y 1,50 USD por investigación; ajustables con --tope-usd y
--tope-total-usd. No sumar costes repetidos en cada registro: consultar entrega.coste.
Brave usa USD; créditos siempre cero. Saldo orientativo = max(0, 5 − gasto local del mes),
no representa pagos, otras herramientas, créditos previos ni saldo de cuenta.
La guía antigua de 2000 consultas gratis y 3 USD/mil contradice la página de precios;
se usa la página de precios como fija la Fase 0 §7.

## Libro y cabeceras

Flujo: cerrojo brave.lock → comprobar mes → reservar USD (cerrojo interno del Libro)
→ pausa ≥1 s → envío → guardar X-RateLimit → liquidar. Reintentos conservan el cerrojo
exterior y vuelven a comprobar el mes ANTES de cada reserva; procesos de este skill comparten presupuestos y última lectura mensual.
La exclusión no alcanza otras aplicaciones, máquinas ni HOME distintos.
La entrega precisa que tarifa/cota son estimación, incluso tras pérdida seguida de éxito.
Petición al cliente común: texto_coste debería distinguir la fuente del resto liquidado
en vez de llamarlo siempre «coste informado»; este helper corrige esa presentación localmente.

Fuente B12, 2026-10-15:
https://api-dashboard.search.brave.com/documentation/guides/rate-limiting.
Se guardan Limit/Policy/Remaining/Reset; una entrada por segundo y mes. Ventana por segundo
deslizante de 1 s. Mes con límite 0 = ilimitado. `saldo` muestra fecha de lectura y reinicio
relativo al instante leído, no una consulta nueva. Un mes agotado impide reservar/envíar
hasta su reinicio. La ausencia de cabeceras no se convierte en saldo ilimitado verificado.

## Errores

Un 400 con code `OPTION_NOT_IN_PLAN` (superior o dentro de error) es error de plan de ese endpoint, código 5. Se liquida rechazo a cero, sin reintentar ni parar otros endpoints de la sesión. El texto libre no se usa para clasificarlo como clave o cuota global.

429 es documentado. Se deriva Retry-After de Reset si falta: segundo espera ≥1 s;
mes agotado con reinicio >30 s para sin reintentar. Otros Retry-After >30 s también paran.
Red/5xx/429 síncronos: máximo dos reintentos, cada uno con reserva y liquidación propias.
401/403 de clave paran sin reintento; 402 se trata como cuota agotada, 422 como error.
Su tabla para Brave es **NO VERIFICADA** (Fase 0 §7): estas son guardas conservadoras
comunes, no confirmación de sus códigos reales. No se compra crédito ni cambia el plan.

## Modos deshabilitados

- **Answers / respuestas**: Fase 0 §6, B5 https://api-dashboard.search.brave.com/documentation/services/answers,
  2026-10-15: «Las citas y el modo research exigen streaming». Otro plan; 4 USD/1000 +
  5 USD/millón de tokens según B13. No se verificó plan de clave ni cota de gasto impuesta
  por proveedor. Deshabilitado completo, sin probar en vivo; no se aplica BUS-C2 a una
  función fingida. Este skill no crea trabajos asíncronos.
- **Place / lugares**: Fase 0 §6, B10 https://api-dashboard.search.brave.com/documentation/services/place-search,
  2026-10-15: solo recoge parámetros; ruta y respuesta no verificadas. Deshabilitado.
  locations tampoco se lee: sus IDs caducan aproximadamente a las 8 h (B1, §5).
- **Summarizer**: Fase 0 §6, B11 https://api-dashboard.search.brave.com/app/documentation/summarizer-search,
  2026-10-15, fuente descubierta por búsqueda y no leída directamente: «está obsoleto y
  lo sustituye Answers». No implementado; se declara el límite de evidencia.
- **Spellcheck**: Fase 0 §6, B3 https://api-dashboard.search.brave.com/documentation/resources/skills,
  2026-10-15: «Parámetros NO VERIFICADOS». No implementado.
- **reanudar**: sin manejador Brave, retorna 2 antes de cualquier consulta remota. Pendientes
  conserva interfaz común, pero no se crean trabajos ni se repite un POST perdido.

## Coste después del smoke del 2026-10-15

La entrega y `coste_entrega()` desglosan el coste por origen, en texto y JSON.
El total liquidado es contable: no implica que todo sea una factura o una estimación.
En `desglose`:

- `usd_real_proveedor`: USD informados por el proveedor (Exa `costDollars`, Perplexity Agent `usage.cost`).
- `usd_estimado_tarifa`: USD calculados con tarifa, sin medición monetaria de esa llamada.
- `usd_valoracion_creditos`: conversión estimada a USD de créditos de Firecrawl; nunca USD reales informados.
- `creditos_informados_proveedor`: créditos medidos por el proveedor, separados de su valoración monetaria.
- `usd_cota_sin_coste_real`: cota liquidada cuyo coste real es DESCONOCIDO, incluso con HTTP exitoso sin uso.
- `reservado_sin_liquidar_usd` y `reservado_sin_liquidar_creditos`: reservas pendientes, fuera del total liquidado.

`valoracion_estimada: true` indica que hay componentes estimados; no etiqueta los USD
reales del proveedor como estimados. `coste_real_desconocido: true` cubre cotas sin coste real y pendientes. El flag preexistente `desconocido` conserva su significado de respuesta incierta (pérdida o pendiente), para mantener los códigos de salida de respuestas válidas sin uso informado. No sumar una llamada por cada resultado ni sumar créditos a USD.
