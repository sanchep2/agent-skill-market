# Resultados de las evals — linkedin-search 1.0.0

**Fecha:** 15-oct-2026. **Agentes:** el mismo modelo de tamaño medio en los dos lados. **Juez:** otro agente del mismo
modelo, ciego (respuestas copiadas como X/Y al azar; la clave se guardó aparte y se desveló después).

## Método

- Escenarios e1, e2 y e3 de `evals.json`.
- **Con el skill:** el agente lee `SKILL.md` y usa el helper con `--tope-total-usd 0.30` por escenario y `--max-urls 10`.
- **Sin el skill (línea base):** el mismo agente con su búsqueda web normal y lectura de páginas; sin navegador, sin
  sesión ni cookies de LinkedIn y sin APIs de pago.
- **Juez:** puntúa cada respuesta de 0 a 10 en cinco ejes (cumplimiento de lo pedido, data original y verificable,
  honestidad, relevancia, utilidad para decidir) y comprueba la fecha contra el ID del enlace (`id >> 22`).

## Notas (sobre 50)

| Escenario | Con el skill | Sin el skill | Ganador |
|---|---|---|---|
| e1 inglés, negocio (captar clientes para una agencia de automatización con IA) | **43** | 30 | con el skill |
| e2 español, marketing (lanzamientos de cursos online; sin nombres de autores) | **41** | 32 | con el skill |
| e3 técnico («vibe coding») | **42** | 33 | con el skill |
| **Total** | **126 / 150** | 95 / 150 | |

Lo que decide la diferencia, según el juez:

- **Con el skill:** texto íntegro, fecha ISO que casa con el ID, las tres métricas (incluidos los compartidos) con su
  procedencia y el contraste entre dos fuentes; seudónimo y sin enlaces cuando se pide anonimato, con el aviso de que el
  texto sigue identificando.
- **Sin el skill:** sin compartidos en ningún caso (la página pública no los muestra), textos recortados, métricas de
  una sola lectura y, en e2, un anexo con los enlaces dentro del mismo fichero que se iba a compartir. A favor: una
  síntesis de «qué dicen» que la respuesta con el skill no hizo.
- **Las dos:** honestas, ninguna inventa datos. Ninguna logra anonimato real en e2: las marcas y nombres dentro del texto
  delatan al autor (ver `references/privacidad-y-riesgos.md`).

## Coste real de las evals con el skill

| Escenario | Coste (libro del skill) |
|---|---|
| e1 | 0,123 USD |
| e2 | 0,082 USD (una consulta salió de la caché del día) |
| e3 | 0,187 USD |

El gasto de Apify del libro (0,2803 USD) coincidió con el contador mensual de la cuenta (+0,2802 USD). Bright Data se
valora a 0,0015 USD por registro (créditos del plan gratuito).

## Fallos que encontraron las evals (y su arreglo)

Ver `references/entrega-y-credibilidad.md` y el historial de cambios del skill. Los encontrados en esta ronda:

1. El listado de `descubrir` no daba un fragmento del texto para juzgar la relevancia antes de pagar métricas.
2. La búsqueda de pago partía el tema en ventanas de palabras y podía perder el término clave
   («what developers think about vibe coding» → «developers think about», «about vibe coding»).
3. Una lectura 0/0 sin texto se aceptaba como métrica cuando la otra fuente había fallado.
4. `citas` no sumaba los descartes hechos en `descubrir`.
5. La consola de `citas` cortaba en 20 líneas sin avisar.
6. La cabecera de `citas` no reflejaba el idioma ni el tema de la investigación.
7. Con `--anonimizar-autores`, los teléfonos y correos dentro del texto seguían visibles y no se avisaba de que los
   ficheros de trabajo de `--salida` guardan los datos sin seudonimizar.
8. `leer` mostraba comentarios de terceros con su nombre.

## Arreglos tras las evals y la auditoría (ronda 2)

Versión 1.1.0 del helper. Cada arreglo tiene su prueba en `scripts/test_linkedin_helper.py` (clases `TestR2*`); se
comprobó que esas pruebas fallan contra el helper anterior y pasan con el nuevo.

- **Evals:** el `.md` de `descubrir` lleva un fragmento de hasta 200 caracteres por candidato (E1); `palabras_clave`
  respeta una frase entre comillas y descarta más palabras vacías, de modo que «what developers think about vibe coding»
  da `developers vibe coding` (E2); una lectura 0/0 sin texto ni autor que nadie confirma no es métrica (E3); `citas`
  suma los descartes de `descubrir` (E4); la consola dice cuántas líneas faltan y dónde están (E5); la cabecera de `citas`
  toma tema e idioma de `registros.json` (E6); `--anonimizar-autores` omite correos y teléfonos y avisa de que los
  ficheros de trabajo no están seudonimizados (E7); `leer` no imprime ni guarda comentarios de terceros (E8); `metricas`
  dice «N lecturas (M URL × fuentes)» y `uso.jsonl` marca `eventos_retrasados` (E9).
- **Auditoría, Majors:** resultado desconocido de Apify y de Bright Data liquidado por su cota, sin reintentar el
  `POST` que crea la ejecución y sin cachear (M1, M2); claves mal formadas rechazadas sin mostrarlas y fallos
  imprevistos sin traceback (M3); cortacircuitos por sesión tras un límite o una clave rechazada, y el 422 de Brave
  reconocido (M4); lecturas a menos de 300 s contrastadas solo por su diferencia (M5); `SIGTERM`/`SIGINT` liquidan la
  llamada en vuelo y el subcomando `libro` ve y libera reservas colgadas (M6); un texto corto con enlace y 50+
  reacciones o 10+ comentarios ya no es relleno (M7).
- **Auditoría, menores (m1-m12):** aviso de compartidos discrepantes, primera frente a última con 3 lecturas,
  `salud --en-vivo` con investigación por ejecución, cabeceras secretas sin distinguir mayúsculas, `leer` con
  delimitadores y avisos de inyección más amplios (también en el autor), topes finitos y positivos, `a_entero` con
  decimales y millares y fechas por ID en el futuro descartadas, lecturas ya pagadas conservadas si un lote para, «cumplen»
  exige reacciones y comentarios, error claro sin `HOME`, fixtures sin contactos ni URL firmadas y documentación sin
  referencias internas, y textos de proveedor redactados y limpios al imprimirse.


## Arreglos tras la auditoría adversarial de la ronda 2 (ronda 3)

Versión 1.2.0 del helper. Cada arreglo tiene su prueba en `scripts/test_linkedin_helper.py` (clases `TestR3*`); se
comprobó que cada una de esas pruebas falla contra el helper anterior (1.1.0) y pasa con el nuevo. El auditor cerró la
ronda 2 como «apto con menores»: 17 hallazgos nuevos (N1-N17) y tres cierres parciales (M7, M6, E3).

- **Cierres parciales:** M7/N1, con una lectura de 50+ reacciones o 10+ comentarios ni los cupones son relleno (al
  descubrir, sin medir, solo se descartan cupones y solo-enlaces sin interacción conocida); M6/N3, `SIGHUP` y `SIGQUIT`
  como `SIGTERM`, proceso «cerrando» que rechaza reservas nuevas bajo el cerrojo del libro, aborto de las ejecuciones de
  Apify vivas y respeto a un `SIGHUP` ya ignorado (`nohup`); E3/N4, dos registros 0/0 vacíos no se confirman entre sí.
- **Texto y entrega:** el corte de comentarios solo toca el texto de respaldo y solo con un bloque con forma de
  comentario detrás (N2); delimitadores de `leer` con marca aleatoria y líneas imitadoras escapadas, aviso y limpieza de
  caracteres invisibles (N9); ID de la ruta = el último, aviso si hay varios (N10); una lectura con otro ID se guarda
  aparte (N11); valor de ficha = el mayor con lecturas simultáneas (N12); `leer` sigue con Exa/Firecrawl si la clave de
  Apify está mal (N13); teléfonos solo con forma de teléfono y sin tocar cifras con moneda o unidad (N14); `citas-*` con
  sufijo único que no se sobrescribe y `--sin-url` sin IDs en la cobertura (N15); `.md` con campos de una línea y
  markdown escapado (N16); `palabras_clave` sin podar palabras con significado ni símbolos (N17).
- **Dinero y claves:** clave con caracteres no ASCII rechazada al cargarla y fallo local antes de enviar liberado con
  coste 0 (`no_enviada`) (N5); `--max-urls` ≥ 1 y cota de una llamada ≤ `--tope-usd` (N6); `LINKEDIN_SEARCH_PRECIO_BD`
  finito y > 0 (N7); solo un mensaje de la cuenta para a Apify y tras un resultado desconocido el proveedor queda parado
  la sesión (N8); un 403 de Firecrawl solo es clave rechazada si habla de la clave.
- **Lo que queda, dicho:** al descubrir, un post corto con enlace y sin lectura sigue descartándose como relleno antes de
  medirse (decisión del responsable: solo se salva lo que ya tiene una lectura con interacción alta); una serie de
  pares de dígitos («10 20 30 40 50 60») se parece a un teléfono y con `--anonimizar-autores` se omite; el 403 de
  Firecrawl ante páginas de LinkedIn y el cobro de Apify/Bright Data ante cortes siguen sin medirse con claves reales.

## Ronda 4 (versión 1.2.1)

La verificación de la ronda 3 dio APTO CON MENORES con siete hallazgos nuevos, efectos laterales de sus arreglos. Cada
uno tiene su prueba en la clase `TestR4`, que falla contra la versión 1.2.0 y pasa con la 1.2.1:

- Con `--anonimizar-autores`, 9-15 cifras seguidas («whatsapp al 659743666») vuelven a omitirse, y las fechas con punto,
  guion o espacio («31.10.2026», «15 10 2026») y los millares con espacio («12 000 000») ya no se toman por teléfonos.
- El corte de comentarios de `leer` reconoce también «Nombre 1w» y «nombre, línea en blanco, fecha», y ya no corta una
  lista del autor como «Notion · 5 años» (un tiempo relativo largo solo cuenta con «hace» o «ago»).
- Solo los mensajes de la CUENTA de Apify (uso mensual, saldo, plan gratis) paran el proveedor; «exceeded rate limit»,
  «usage limit» o «plan limit» de LinkedIn ya no.
- Un fallo después de abrir la conexión (por ejemplo, una redirección con un destino inválido) cuenta como resultado
  desconocido y se liquida por la cota; «no enviada» queda solo para lo que falla en la validación local previa.
- Las contracciones y los posesivos («what's», «LinkedIn’s») ya no dejan palabras sueltas en la búsqueda de pago.
- La receta de `SKILL.md` para leer la última entrega usa la fecha de modificación, no el orden del nombre.
- Las banderas de subdivisión (Inglaterra, Escocia, Gales), que usan caracteres Tags, se conservan y no disparan el aviso
  de caracteres invisibles.


## Ronda 5 (versión 1.2.2)

Una auditoría externa del árbol 1.2.1 encontró tres fallos graves. Cada uno tiene sus pruebas en las clases `TestR5*`,
que fallan contra la versión 1.2.1 y pasan con la 1.2.2:

- **Gasto (C1).** Una respuesta perdida de un buscador (red o 5xx) se liquidaba a 0 y se reintentaba; ahora cada
  intento se liquida por su cota, el tope total frena el reintento que no cabe y, tras agotar los reintentos, ese
  proveedor queda parado la sesión. En Apify, un timeout ya no libera la cota: el aborto se confirma leyendo un estado
  final y, sin esa confirmación, se liquida la cota entera como `resultado_desconocido` y Apify queda parado.
- **Entrega (C2/C4).** Una publicación `ugcPost`/`share` que cambiaba de clave al enriquecer desaparecía de la
  entrega si se le pasaba la selección de antes (`--completo` o un `descubrir-*.json`). `registros.json` guarda ahora
  el alias de cada clave reindexada; las selecciones antiguas se resuelven por él y una clave que no aparece se cuenta
  como `clave_desconocida`.
- **Coste y cobertura de la entrega.** `citas` declaraba coste 0 y ninguna parada. Ahora trae el coste de toda la
  investigación desde el libro de gasto (con el desglose por proveedor y las reservas sin liquidar) y las paradas,
  avisos y proveedores de cada fase; si el coste no se puede saber, dice DESCONOCIDO.
