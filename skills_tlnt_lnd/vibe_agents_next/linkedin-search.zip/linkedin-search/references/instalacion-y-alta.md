# Instalación y alta de proveedores

Qué hacer cuando `salud` dice que falta una clave. Todo lo de terceros lleva fuente y fecha de consulta; si una fuente
cambia, manda la fuente. **Este skill no dicta rutas de menús de los paneles de los proveedores**: sus interfaces
cambian sin aviso. Abre la documentación oficial, busca «API key» o «API token» y, si algo no coincide, comparte lo que
ves en pantalla con tu agente.

## Table of Contents

1. [Qué necesitas como mínimo](#1-qué-necesitas-como-mínimo)
2. [Dar de alta cada proveedor](#2-dar-de-alta-cada-proveedor)
3. [Guardar una clave sin mostrarla](#3-guardar-una-clave-sin-mostrarla)
4. [Comprobar con `salud`](#4-comprobar-con-salud)
5. [Límites de gasto en la cuenta del proveedor](#5-límites-de-gasto-en-la-cuenta-del-proveedor)
6. [Windows](#6-windows)
7. [Qué hace y qué no hace el agente](#7-qué-hace-y-qué-no-hace-el-agente)
8. [Errores frecuentes](#8-errores-frecuentes)

---

## 1. Qué necesitas como mínimo

```text
Descubrir  ── al menos UN buscador. Recomendado: Exa (motor principal en español).
Medir      ── Apify (apimaestro post-detail) y/o Bright Data. Con los dos, las métricas se contrastan.
Pago opcional ── Apify también da la búsqueda de pago (solo inglés, con --pago).
```

| Combinación | Qué consigues |
|---|---|
| Exa + Apify + Bright Data | Lo completo: descubrir, medir y contrastar |
| Exa + Apify | Descubrir y medir con una sola fuente (todo `una_fuente`) |
| Los cuatro buscadores, sin medir | Candidatos; todo queda en «cobertura incompleta» por `sin_metricas` |
| Sin buscadores, con Apify o Bright Data | `metricas` de URL que ya tengas (por ejemplo, de la búsqueda web del propio agente) |
| Nada | `salud` lo dice y explica cómo empezar; el skill no inventa resultados |

No hace falta tarjeta para empezar con los planes gratis de abajo, salvo que el proveedor la pida (consulta cada alta).

---

## 2. Dar de alta cada proveedor

Planes y cifras: `proveedores-y-costes.md` (verificadas el 14-oct-2026; los planes cambian: confírmalos al darte de alta).

| Proveedor | Plan gratis o modelo | Documentación oficial | Variable |
|---|---|---|---|
| Apify | Crédito gratis mensual de 5 USD | <https://docs.apify.com/> | `APIFY_TOKEN` |
| Bright Data | 5.000 registros/créditos gratis al mes (según su página, ≈7,50 USD de valor) | <https://docs.brightdata.com/> (LinkedIn: <https://docs.brightdata.com/datasets/scrapers/linkedin/introduction>) | `BRIGHTDATA_API_KEY` |
| Exa | Pago por búsqueda (≈0,007 USD); consulta su página de precios por si hay créditos de bienvenida | <https://docs.exa.ai/> | `EXA_API_KEY` |
| Perplexity (Search API) | Pago por uso (5 USD por 1.000 consultas) | <https://docs.perplexity.ai/> | `PERPLEXITY_API_KEY` |
| Brave Search API | Crédito gratis mensual (5 USD, según su página, 8-oct-2026) y 5 USD por 1.000 consultas | <https://api-dashboard.search.brave.com/> | `BRAVE_SEARCH_API_KEY` |
| Firecrawl | 1.000 créditos gratis al mes sin tarjeta (según su página, 8-oct-2026) | <https://docs.firecrawl.dev/> | `FIRECRAWL_API_KEY` |

Pasos comunes:

1. Crea la cuenta en el proveedor.
2. Crea una clave de API (la documentación oficial indica dónde; no hay un camino fijo que podamos garantizar).
3. Si el proveedor permite ponerle **un límite de gasto** o un presupuesto mensual, pónselo (ver §5).
4. Cópiala **al portapapeles** y sigue con §3. No la pegues en el chat.

Cuentas inactivas: Bright Data puede responder «Customer is not active» hasta que actives la cuenta en su panel; el
skill lo trata como un límite y para.

---

## 3. Guardar una clave sin mostrarla

```bash
SKILL_DIR="${SKILL_DIR:-$HOME/.claude/skills/linkedin-search}"        # o la carpeta de tu agente (tabla de SKILL.md)
python3 "$SKILL_DIR/scripts/linkedin_helper.py" conectar apify        # lee el portapapeles
python3 "$SKILL_DIR/scripts/linkedin_helper.py" conectar brightdata --desde-fichero clave.txt
```

- Lee la clave del **portapapeles** (macOS `pbpaste`; Linux `xclip`, `xsel` o `wl-paste`; Windows `Get-Clipboard`) o de un
  **fichero** que contenga solo la clave o una línea `VARIABLE=valor`.
- La guarda en `~/.linkedin-search/claves.env` con permisos **0600** (carpeta 0700). `LINKEDIN_SEARCH_HOME` cambia la
  carpeta. Si ya había una clave de ese proveedor, la reemplaza y deja las demás.
- **No la imprime ni la muestra, ni siquiera parcialmente**: dice cuántos caracteres tenía y de dónde la leyó.
- Rechaza lo que no parece una clave (una frase, varias líneas, algo muy corto) y no escribe nada.
- Al **leer** una clave (entorno o fichero) se recortan los espacios de los extremos y se rechaza, sin mostrar su valor, la
  que lleve saltos de línea, espacios internos, caracteres de control o cualquier carácter que no sea ASCII imprimible
  (un espacio de ancho cero U+200B, una comilla tipográfica «’», un guion largo…): `salud` la marca como mal formada.
  `conectar` rechaza esos caracteres al cargarla (nombra los puntos de código, p. ej. `U+200B`, nunca la clave) y no
  guarda nada. Un fallo local antes de enviar la petición (cabecera inválida) no gasta: la reserva se libera con coste
  0 (`no_enviada`). Si `HOME` no existe, define `LINKEDIN_SEARCH_HOME`: el skill nunca escribe en el directorio actual.
- Comprueba la clave con una llamada **gratuita** cuando existe (Apify: uso del mes; Bright Data: ver abajo; Firecrawl:
  créditos). Exa, Perplexity y Brave no tienen una comprobación gratuita: la primera búsqueda lo dirá, o
  `salud --en-vivo` (≈0,017 USD).
- Alternativa sin fichero: variables de entorno en la sesión (`export EXA_API_KEY=…`), que mandan sobre el fichero.

Cómo se comprueba Bright Data sin gastar: no tiene un endpoint de saldo; el skill consulta el progreso de un snapshot
que no existe y distingue «clave rechazada» (401/403) de «clave aceptada». **Es una inferencia**: el saldo real, míralo
en su panel.

Tras guardar, **borra el portapapeles** (copia cualquier otra cosa) y no dejes la clave en el historial del shell, en
ficheros del proyecto ni en un chat.

---

## 4. Comprobar con `salud`

```bash
python3 "$SKILL_DIR/scripts/linkedin_helper.py" salud     # SKILL_DIR como arriba
```

| Línea de `salud` | Qué hacer |
|---|---|
| `FALTA <Proveedor>` + lo que se pierde | Dar de alta (§2) o aceptar la pérdida |
| `OK … (entorno)` / `(fichero)` | Nada |
| `SIN VALIDAR` | Normal en Exa, Perplexity y Brave: no hay comprobación gratuita |
| `MAL … HTTP 401/403` | Clave revocada o de otra cuenta: crea otra y `conectar` de nuevo |
| `Modo: ninguno` | Conecta un buscador y Apify o Bright Data (instrucciones en pantalla) |
| `Gasto liquidado este mes` | Suma del libro por proveedor (`~/.linkedin-search/gasto.jsonl`) |

Con un HOME vacío, `salud` termina sin error, no crea ficheros y dice qué falta y cómo conectarlo.

---

## 5. Límites de gasto en la cuenta del proveedor

El skill se frena con su libro (`--tope-usd` y `--tope-total-usd`), pero un límite **del proveedor** protege también si
algo falla fuera del skill. Si tu cuenta permite fijarlo, hazlo. En Apify, el skill lee el límite mensual y el uso antes
de cada llamada de pago (la consulta gratuita de límites de la API de Apify (`…/me/limits`)) y no lanza si no queda margen.

---

## 6. Windows

**No probado en Windows.** Lo que cambia sobre el papel: la carpeta es `%USERPROFILE%\.linkedin-search`, el
portapapeles se lee con `powershell Get-Clipboard` y el bloqueo del libro usa `msvcrt.locking` en lugar de `fcntl.flock`.
Si algo falla, usa variables de entorno y `--desde-fichero`, y cuéntalo.

---

## 7. Qué hace y qué no hace el agente

| El agente SÍ | El agente NO |
|---|---|
| Correr `salud` y explicar lo que falta | Pedirte la clave por el chat |
| Ejecutar `conectar` cuando le dices «guarda esta clave de X» tras copiarla | Leer el portapapeles sin que se lo pidas |
| Respetar los topes y parar ante un límite | Comprar créditos, cambiar de plan o activar recargas |
| Decirte qué proveedor falta y qué pierdes | Usar una cuenta o cookies de LinkedIn |
| Abrir la documentación oficial para que busques «API key» | Dictarte rutas de menús que no ha verificado |

---

## 8. Errores frecuentes

| Síntoma | Causa probable | Solución |
|---|---|---|
| `PARADA: … límite o cuenta sin saldo (HTTP 402)` | Plan agotado o sin saldo | Esperar el ciclo o subir el límite tú; ver `proveedores-y-costes.md` §6 |
| `PARADA: … (HTTP 429)` | Límite de tasa | Esperar; usar otro buscador |
| `Apify: uso del mes … > límite mensual` | Sin margen en el plan gratis | Medir solo con Bright Data o esperar |
| `El portapapeles está vacío o no se pudo leer` | No hay herramienta de portapapeles (servidor sin entorno gráfico) | `--desde-fichero` |
| `Lo copiado no parece una clave` | Se copió otra cosa | Copiar solo la clave |
| `Falta --salida DIR` | Se olvidó la carpeta de trabajo | Añadir `--salida` (nunca escribe en el directorio actual) |
| Todo `sin_clave` | Variables no exportadas en esta sesión | `salud` muestra el origen de cada clave |
