# Proveedores, precios, topes y límites

Todo lo de terceros lleva fecha de verificación. **Verificado el 2026-10-14** (fichas de actores de Apify, respuestas
reales de los buscadores en las pruebas del 14-15 de octubre de 2026 y documentación de Bright Data); si una fuente cambia, manda la fuente. Lo que es
cálculo propio o supuesto lo dice.

## Table of Contents

1. [Cuánto cuesta una investigación](#1-cuánto-cuesta-una-investigación)
2. [Apify](#2-apify)
3. [Bright Data](#3-bright-data)
4. [Los cuatro buscadores](#4-los-cuatro-buscadores)
5. [Libro de gasto y topes](#5-libro-de-gasto-y-topes)
6. [Errores de límite: qué hace el skill y qué alternativa queda](#6-errores-de-límite-qué-hace-el-skill-y-qué-alternativa-queda)
7. [Entradas probadas de los actores](#7-entradas-probadas-de-los-actores)
8. [Lo que el skill nunca hace con el dinero](#8-lo-que-el-skill-nunca-hace-con-el-dinero)

---

## 1. Cuánto cuesta una investigación

Cálculo propio (14-oct-2026) con las tarifas de abajo, para LinkedIn solo:

| Partida | Cuenta | USD |
|---|---|---|
| 3 consultas × 4 buscadores | Exa 0,007 + Perplexity 0,005 + Brave 0,005 + Firecrawl 0 = 0,017 por consulta | 0,05 |
| Búsqueda de pago (solo inglés, opcional) | 2 consultas × 10 posts × 0,002 + arranque 0,00005 | 0,04 |
| Métricas de 25 URL con Apify | 25 × 0,005 (reserva; el cobro real puede ser menor) | 0,13 |
| Métricas de 25 URL con Bright Data | 25 × 0,0015 equivalente; cubierto por los créditos gratis | 0,04 |
| **Total aproximado** | | **0,15-0,30** |

El plan gratis de Apify (**5 USD de crédito al mes**) da para decenas de investigaciones de este tamaño; los 5.000
créditos gratis de Bright Data al mes, para cientos de URL. En las pruebas del 14-15 de octubre de 2026, tres
investigaciones completas de LinkedIn costaron 0,08-0,19 USD cada una (cálculo propio: decenas al mes con el plan gratis).

---

## 2. Apify

Cobra por **evento**. Fichas leídas el 14-oct-2026:

| Actor | Evento | Precio USD | Nota |
|---|---|---|---|
| `harvestapi~linkedin-post-search` | `post` (resultado) | 0,002 (plan gratis y Bronze; 0,00175 Silver; 0,0015 Gold y superiores) | Medido en las pruebas del 14-15 de octubre de 2026: 0,12 por 60 posts |
| | `apify-actor-start` | 0,00005 por GB de memoria (mínimo 1 evento) | Se cobra aunque falle |
| | `no-result` | 0,001 | Una consulta sin resultados también se cobra |
| | `main-profile` / `reaction` / `comment` | 0,002 | No se activan: el skill usa `profileScraperMode: short` |
| | `full-profile` | 0,004 | No se activa |
| | mínimo de `maxTotalChargeUsd` | 0,01 | Por debajo, el skill no lanza |
| `apimaestro~linkedin-post-detail` | resultado | **no leído en ficha** | Reserva conservadora de 0,005 por post (el mismo precio por resultado que el actor de búsqueda de apimaestro). El cobro real se lee al terminar |

- **Tope duro por llamada**: `maxTotalChargeUsd` = lo reservado en el libro (`--tope-usd`, 0,5 USD por defecto). Apify
  detiene la ejecución al llegar.
- **Uso del mes**: antes de cada llamada de pago, la consulta gratuita de límites de la API de Apify (`…/me/limits`). Si lo usado más lo reservado supera el
  límite mensual, no se lanza. Si no se puede leer, se sigue con un aviso (el tope por llamada y el total siguen vigentes).
- **El coste real sale con retraso**: se relee la ejecución al terminar (hasta 3 veces) y se liquida con el MAYOR
  entre ese coste y la estimación por eventos (arranque + posts recibidos × precio), nunca por encima de la reserva. En
  una prueba real (15-oct-2026) la ejecución terminada marcaba 0,00005 USD («post: 0») para 20 posts que el contador
  mensual cobró a 0,04: fiarse solo del coste leído deja el libro por debajo de lo gastado.
- **Arranque fallido**: una ejecución rechazada por la entrada se cobra igual el arranque. Se cuenta en
  `arranques_fallidos` de la cobertura y en el libro (`estado: arranque_fallido`).
- **Resultado desconocido** (nunca se liquida de menos):
  - El `POST` que crea la ejecución **no es idempotente y no se reintenta jamás**. Si falla por red o con 5xx, la
    ejecución puede existir: se liquida la cota entera (`estado: resultado_desconocido`) y se para con un mensaje que
    manda a la consola de Apify (Actors → Runs) para verla y abortarla antes de repetir.
  - Si el sondeo falla 3 veces, se llama a `/abort` y se liquida la cota entera (`resultado_desconocido`); Apify queda
    parado el resto de la sesión.
  - Si la ejecución supera el tiempo de espera, se pide `/abort` y se **confirma** leyendo un estado final (`ABORTED`,
    `SUCCEEDED`, `FAILED` o `TIMED-OUT`). Solo con el final confirmado se liquida por lo que llegó a producir (como
    `arranque_fallido`). Sin confirmación la ejecución puede seguir viva y cobrando: se liquida la cota entera
    (`resultado_desconocido`), Apify queda parado la sesión y el aviso manda a la consola a abortarla.
  - Si la descarga del dataset falla (se reintenta 2 veces), se liquida el mayor entre el coste leído y la estimación
    por eventos cobrados (`chargedEventCounts`); sin estimación, la cota. No se guarda en la caché y la cobertura
    lleva un aviso con el ID del dataset.
  - Si los eventos cobrados vienen a 0 pero hay posts, `uso.jsonl` lleva `"eventos_retrasados": true`.
- **Autenticación**: cabecera `Authorization: Bearer <token>`; el token nunca va en la URL.
- **Plan gratis**: algunos actores se deshabilitan para usuarios gratis («Temporalmente deshabilitado para usuarios
  gratis»). El skill lo trata como límite: para y no reintenta.
- **Qué para a Apify y qué no**: solo un mensaje que habla de la CUENTA (saldo, plan, uso mensual, «not available for
  free users», «insufficient credits»…) activa el cortacircuitos de Apify. Un «rate limit» o «too many requests» dentro
  de una ejecución `FAILED` suele venir de LinkedIn: cuenta como fallo del actor (`arranque_fallido`) y no bloquea al
  otro actor ni a lo que sigue. El 402 y el 429 de la API de Apify siguen parando.

## 3. Bright Data

- **Dataset de publicaciones de LinkedIn por URL**: `gd_lyy3tktm25m4avu764`. Petición:
  `POST https://api.brightdata.com/datasets/v3/scrape?dataset_id=…&include_errors=true&format=json`, cuerpo `[{"url": …}]`.
  Respuesta síncrona con los registros; si tarda, `202` con `snapshot_id` y el skill consulta
  `/datasets/v3/progress/{id}` y `/datasets/v3/snapshot/{id}?format=json`.
- **Lotes**: su documentación dice «hasta 20 URL por petición» (documentación de la LinkedIn Scraper API, 14-oct-2026).
  El skill envía lotes de 20.
- **Precio**: 5.000 registros/créditos gratis al mes (≈7,50 USD de valor, según su página, vía buscador el 12-oct-2026);
  de pago, **1,50 USD por 1.000 registros** (blogs de terceros, 30-sep-2026; **derivado, no contrastado en el panel**).
  El skill reserva `registros × 0,0015 USD` (configurable con `LINKEDIN_SEARCH_PRECIO_BD`) aunque usen créditos gratis.
- **Saldo**: la clave de API no puede leerlo; míralo en el panel del proveedor.
- **Registros vacíos**: 2 de 11 lecturas de las pruebas del 14-15 de octubre de 2026 fueron 0/0 sin texto con la otra fuente mostrando valores reales. El
  skill los descarta con la regla de `entrega-y-credibilidad.md`.
- **Cuenta inactiva**: una cuenta sin activar devuelve «Customer is not active» y ningún registro. Es un límite de la cuenta: se para.
- **Resultado desconocido**: si el `POST` no obtiene respuesta, o el snapshot queda `ready` y no se puede descargar (2
  reintentos), o el sondeo se agota, los registros pueden estar cobrados: se liquida la cota (URL × precio) como
  `resultado_desconocido`, el `snapshot_id` queda en `uso.jsonl`, en el libro y en un aviso de la cobertura, y no se
  guarda en la caché. Descarga ese snapshot desde el panel en vez de repetir la petición. Si un lote para, las
  lecturas ya pagadas de los lotes anteriores se conservan y se emparejan.
- **Precio configurable**: `LINKEDIN_SEARCH_PRECIO_BD` debe ser un número finito mayor que 0; `nan`, `inf`, negativos,
  0 o texto dan un error claro antes de llamar (un precio no finito desactivaría el tope total).

## 4. Los cuatro buscadores

| Motor | Endpoint | Cabecera | Precio por llamada | Coste real |
|---|---|---|---|---|
| Exa | `POST https://api.exa.ai/search` (`includeDomains`, `startPublishedDate`, `contents.text`) | `x-api-key` | 0,007 | `costDollars.total` de la respuesta |
| Exa contents (texto de respaldo) | `POST https://api.exa.ai/contents` | `x-api-key` | 0,001 por página (medido el 14-oct-2026) | `costDollars.total` |
| Perplexity | `POST https://api.perplexity.ai/search` (`search_domain_filter`, `search_recency_filter`) | `Authorization: Bearer` | 0,005 | por llamada |
| Brave | `GET https://api.search.brave.com/res/v1/web/search` (`q`, `count`, `freshness`, `extra_snippets`) | `X-Subscription-Token` | 0,005 | por llamada |
| Firecrawl search | `POST https://api.firecrawl.dev/v2/search` (`query`, `limit`, `tbs`) | `Authorization: Bearer` | 0 USD; 2 créditos por 10 resultados | créditos del plan |
| Firecrawl scrape (respaldo) | `POST https://api.firecrawl.dev/v2/scrape` | `Authorization: Bearer` | 0 USD; 1 crédito por página | créditos del plan |

Precios por llamada de Brave y Perplexity: publicados (5 USD por 1.000 consultas). Planes gratis y altas:
`instalacion-y-alta.md`. Brave responde **HTTP 422** con `SUBSCRIPTION_TOKEN_INVALID` cuando la clave no vale: el skill
lo trata como clave rechazada (igual que cualquier 401/403/422 cuyo cuerpo hable de un token o clave inválidos).

**El 403 de Firecrawl puede ser un bloqueo de la PÁGINA, no de la clave.** Firecrawl responde 403 cuando un sitio no
admite el rastreo («This website is no longer supported…»), y LinkedIn puede caer ahí; esa respuesta no dice nada de la
clave. El skill solo trata como «clave rechazada: revócala» un 401, o un 403 cuyo cuerpo hable de la clave, el token o la
API key. Cualquier otro 403 es un error de esa página (`leer` cae al siguiente proveedor de texto) y **no** bloquea a
Firecrawl para el resto de la sesión. Qué devuelve exactamente Firecrawl ante páginas de LinkedIn no se ha medido
con una clave real: si ves un 403 en una URL concreta, no revoques la clave sin comprobarla antes con `salud`.

---

## 5. Libro de gasto y topes

Un fichero único por usuario: `~/.linkedin-search/gasto.jsonl` (permisos 0600; `LINKEDIN_SEARCH_HOME` lo cambia).

```text
reserva      {id, investigacion, proveedor, concepto, cota_usd}          ← ANTES de llamar
liquidacion  {id, investigacion, coste_usd, estado}                      ← DESPUÉS, con el coste real
estados      ok · rechazada · respuesta_perdida · arranque_fallido · excepcion · sin_registros
             resultado_desconocido · interrumpida · liberada_colgada · no_enviada
```

- **Tope por llamada (`--tope-usd`, 0,5 por defecto)**: la cota de UNA llamada nunca lo supera. Si las URL de
  `metricas` no caben (URL × precio por registro), se envían las que caben y la cobertura avisa de las que quedan sin
  pedir; una llamada directa cuya cota lo supera no se lanza. `--max-urls` debe ser un entero ≥ 1 (se rechaza en el
  parseo), y una cota o un tope no finitos no se aceptan en el libro.
- **Tope total (`--tope-total-usd`, 1,5 por defecto) por investigación** = suma de liquidaciones + reservas en vuelo +
  la llamada que se quiere lanzar. Si no cabe, **no se lanza**. Una investigación es la carpeta `--salida` (o el nombre
  que des con `--investigacion`). `salud --en-vivo` usa una investigación por ejecución (`salud-AAAAMMDD-HHMMSS`).
  Los dos topes (`--tope-total-usd` y `--tope-usd`) deben ser números finitos mayores que 0: se rechazan `nan`,
  `inf`, negativos y 0.
- **Bloqueo**: `fcntl.flock` (POSIX) o `msvcrt.locking` (Windows, no probado) más un cerrojo de hilos; reservar y
  comprobar el remanente ocurren bajo el mismo bloqueo. Dos procesos que intentan reservar el mismo remanente: solo uno pasa.
- **Cortacircuitos**: tras un límite (402/429, cuenta inactiva, actor deshabilitado), una clave rechazada o un
  `resultado_desconocido`, ese proveedor no se vuelve a llamar en toda la sesión: la llamada siguiente para sin red y con
  el mismo motivo (así un lote de temas no repite un `POST` que quizá ya creó una ejecución). `lote` usa una sola sesión
  para todos sus temas.
- **Fallo local antes de enviar** (cabecera inválida, error de codificación, URL inválida): no salió nada a la red, así
  que no hay nada que cobrar. La reserva se libera con coste 0 y `estado: no_enviada`, sin reintentos; casi siempre es
  una clave con un carácter raro (`salud` la marca).
- **Una reserva sin liquidar** (proceso caído) sigue contando: es conservador. El skill intenta que no queden:
  `SIGTERM`, `SIGINT`, `SIGHUP` y `SIGQUIT` (los que existan) liquidan POR SU COTA ENTERA toda llamada en vuelo antes
  de salir (`estado: interrumpida`). Al recibir la señal el proceso se marca «cerrando» bajo el mismo cerrojo del libro:
  una reserva nueva se rechaza, y una ya anotada está en el registro de llamadas en vuelo (se anotan juntas, dentro del
  mismo bloqueo). Además intenta, de mejor esfuerzo y con 3 s de tope, abortar las ejecuciones de Apify que sigan vivas
  para no seguir gastando. Un `SIGHUP` que ya se ignora (`nohup`) se respeta. Si aun así queda alguna reserva (por
  ejemplo, un `SIGKILL`), míralas y libéralas con el subcomando `libro`:

  ```bash
  python3 "$H" libro --ver                                            # gastado y reservado por investigación
  python3 "$H" libro --liberar-colgadas --investigacion NOMBRE        # liquida cada reserva por su cota entera
  ```

  Liberar **cuenta como gastado** (el gasto nunca baja) y solo se hace cuando no hay ninguna ejecución en curso.
  **No cambies de `--investigacion` para esquivar una reserva**: eso reinicia el tope total y hace desaparecer del
  cómputo el gasto real de esa ejecución.
- **Llamadas largas**: Apify y Bright Data pueden tardar minutos (hasta 15). Si tu herramienta mata los comandos a los
  2 minutos, lánzalas en segundo plano.
- **`<salida>/uso.jsonl`**: una fila por llamada con proveedor, actor o dataset, eventos cobrados, coste real, segundos
  y posts útiles. `salud` suma el gasto del mes por proveedor.
- **Caché** (`~/.linkedin-search/cache`): por hash de consulta + proveedor + día. Una repetición el mismo día no cuesta.
  `--sin-cache` la salta.

## 6. Errores de límite: qué hace el skill y qué alternativa queda

| Señal | Qué es | Acción | Alternativa |
|---|---|---|---|
| HTTP 402 | Sin saldo o plan agotado | Para, no reintenta | Esperar al ciclo del plan o elevar el límite tú |
| HTTP 429 | Límite de tasa o de uso | Para, no reintenta | Espera; usa otro buscador |
| «Customer is not active» | Cuenta sin activar | Para | Activar la cuenta en el panel |
| Actor deshabilitado para plan gratis | Restricción del actor | Para | Usar el otro proveedor |
| «Rate limit» de LinkedIn dentro de una ejecución `FAILED` de Apify | Fallo del actor, no de la cuenta | `arranque_fallido`; no para a Apify | Repetir más tarde o medir con Bright Data |
| `resultado_desconocido` (POST sin respuesta, snapshot sin descargar…) | No se sabe si el proveedor cobró | Liquida la cota entera y para a ESE proveedor en la sesión | Mirar la consola del proveedor antes de repetir |
| Uso mensual de Apify sin margen | la consulta gratuita de límites de la API de Apify (`…/me/limits`) | No lanza | Esperar al ciclo; medir solo con Bright Data |
| 401 / 403 (y 422 cuyo cuerpo hable de un token o clave inválidos, como Brave) | Clave rechazada | Para | Revocar y `conectar` otra |
| 403 de Firecrawl cuyo cuerpo NO habla de la clave | Bloqueo de la página | Error de esa URL; no para a Firecrawl | Probar otro proveedor de texto |
| Red, 500, 502, 503, 504 | Respuesta perdida: la petición salió y el proveedor PUDO cobrarla | Cada intento se liquida por su **cota entera** (`respuesta_perdida`), nunca a 0. **Máximo 2 reintentos** de lo idempotente, cada uno con su reserva (si el tope total no da para otra cota, no se reintenta). Tras agotarlos, ese proveedor queda parado la sesión. El `POST` que crea una ejecución de Apify **nunca** se reintenta: se liquida la cota (`resultado_desconocido`) | Los demás proveedores |

Una parada de un proveedor **no detiene a los demás**: `descubrir` sigue con los otros buscadores y `metricas` con el otro
proveedor; queda en `paradas` de la cobertura con su alternativa. El código de salida es 2 si la parada deja sin
resultado.

## 7. Entradas probadas de los actores

El esquema de un actor solo sugiere valores, y un actor puede cobrar el arranque aunque rechace la entrada (en las
pruebas, `search_language: "spanish"` en un actor de búsqueda costó 0,08 USD y no dio ningún post). Por eso el script lleva la tabla
`ACTORES` y **rechaza antes de llamar** cualquier clave que no esté en ella y cualquier valor que no esté en la columna
«Probado en vivo» (los demás valores del esquema se listan como referencia, pero no se lanzan):

| Actor | Claves admitidas | Valores admitidos | Probado en vivo |
|---|---|---|---|
| `harvestapi~linkedin-post-search` | `searchQueries`, `maxPosts`, `postedLimit`, `sortBy`, `profileScraperMode` | `postedLimit`: any, 1h, 24h, week, month, 3months, 6months, year · `sortBy`: relevance, date · `profileScraperMode`: short | `month`, `relevance`, `short` |
| `apimaestro~linkedin-post-detail` | `post_urls` | lista de URL de publicaciones | sí (11 URL distintas en las pruebas del 14-15 de octubre de 2026) |

Para añadir un valor: pruébalo aparte con un tope bajo (≥ 0,01 USD), comprueba el resultado y solo entonces amplía la
tabla y el test.

## 8. Lo que el skill nunca hace con el dinero

- Comprar créditos, cambiar de plan, activar recargas o subir un límite.
- Lanzar una llamada de pago sin reserva en el libro.
- Reintentar tras un 402 o un 429.
- Imprimir una clave, o mandarla por argumento o URL.
- Gastar por encima de `--tope-total-usd` sin que lo suba quien paga.
