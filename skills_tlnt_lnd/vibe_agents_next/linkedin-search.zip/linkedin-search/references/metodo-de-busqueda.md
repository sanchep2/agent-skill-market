# Método de búsqueda en LinkedIn

Cómo plantear consultas que devuelvan publicaciones útiles con poco gasto. Lo medido lleva fecha (pruebas del
14-15 de octubre de 2026, 7 consultas en 2 idiomas, ventana de 1 mes); lo demás es método.

## Table of Contents

1. [Qué se puede buscar y qué no](#1-qué-se-puede-buscar-y-qué-no)
2. [Qué motor para qué](#2-qué-motor-para-qué)
3. [Escribir la consulta](#3-escribir-la-consulta)
4. [Idioma](#4-idioma)
5. [Ventanas de fecha](#5-ventanas-de-fecha)
6. [Cuánto pedir y cuándo parar](#6-cuánto-pedir-y-cuándo-parar)
7. [Limpieza que hace el skill y por qué](#7-limpieza-que-hace-el-skill-y-por-qué)
8. [Errores típicos](#8-errores-típicos)

---

## 1. Qué se puede buscar y qué no

- **Sí:** publicaciones (posts) públicas de LinkedIn por tema, con su texto, autor, fecha y métricas.
- **No:** perfiles, empresas, ofertas de empleo, mensajes, contenido que exige iniciar sesión, ni artículos largos
  (`/pulse/`): no son publicaciones y se descartan y se cuentan (`no_es_publicacion`).
- **Sin sesión:** no hay búsqueda de LinkedIn desde dentro de una cuenta. Las únicas vías son buscadores externos que
  indexan LinkedIn y proveedores de datos públicos con clave. Por qué no se usa una cuenta: `privacidad-y-riesgos.md`.

---

## 2. Qué motor para qué

Medido el 14-oct-2026 con 4 consultas (2 en inglés, 2 en español), 4 buscadores, ventana de 1 mes:

| Motor | URL únicas de LinkedIn | Lo que aporta |
|---|---|---|
| **Exa** (`includeDomains: linkedin.com`) | 40 (38 con fecha) | Motor principal. En español: «lanzamiento de curso online» 10/10 relevantes y en español; «inteligencia artificial para emprendedores» 10/10 relevantes y 9/10 en español. Descubre la URL; el autor viene vacío y la fecha solo a nivel de día |
| **Firecrawl** (`site:linkedin.com/posts`) | 29 | Sin fecha. Mezcla publicaciones y artículos `/pulse/` |
| **Perplexity** (`search_domain_filter`) | 5 | Pocas, pero con fecha; encuentra alguna que los demás no ven |
| **Brave** (`site:linkedin.com/posts`) | 0 publicaciones | En las pruebas del 14-15 de octubre de 2026, solo perfiles. Es el más barato de descartar si hay que ahorrar |

Casi cero URL repetidas entre motores (1 en 73): **cada buscador encuentra publicaciones distintas y los cuatro suman**.
Por eso `descubrir` los lanza todos los que tengan clave.

La **búsqueda de pago** (Apify `harvestapi~linkedin-post-search`, sin cookies) es un motor más, no el principal:

| Idioma | Resultado medido |
|---|---|
| Inglés | «AI automation agency clients» 9/10 y «vibe coding» 8-9/10 relevantes; los 5 datos de cada post |
| Español, frases largas | 2/10 y 0-1/10 |
| Español, palabras cortas | «curso online» 4/10 relevantes (1 en español); «emprendedores» 4/10 (1 en español) |

Por eso solo se lanza con `--pago` y tema en inglés. En español, **Exa descubre y Apify mide**.

---

## 3. Escribir la consulta

```text
BIEN  «lanzamiento de curso online»              (frase natural, como la escribiría quien publica)
BIEN  «AI automation agency clients»
BIEN  «vibe coding»                              (corta; con --idioma en si quieres la búsqueda de pago)
MAL   «("curso" OR "bootcamp") AND (lanzamiento OR "abrimos inscripciones") -empleo»
```

- Los buscadores semánticos (Exa, Perplexity) entienden frases; los operadores booleanos no están verificados en
  ninguno de los cuatro. No los fuerces.
- **La búsqueda de pago necesita consultas CORTAS**: el skill parte el tema en 1-3 palabras clave y lanza hasta 2
  consultas (las 3 primeras y las 3 últimas palabras significativas). Solo se quitan palabras **funcionales y de
  petición** (*what*, *how*, *about*, *think*, *qué*, *cómo*, *dicen*, *sobre*, *publicaciones*, artículos,
  preposiciones…); nunca palabras con significado («people analytics» sigue siendo `people analytics`) y los términos con
  símbolos se conservan enteros (`c++`, `c#`, `gpt-5`, `.net`, `node.js`, `go-to-market`). «AI automation agency
  clients» → `ai automation agency` + `automation agency clients`; «what developers think about vibe coding» →
  `developers vibe coding`. Las consultas elegidas se muestran **antes** de lanzar la búsqueda de pago (línea
  «consultas elegidas […]» en la salida de error) y quedan en la cobertura.
  **Si el tema lleva una frase entre comillas** («», "" o “”), esa frase es la consulta:
  `qué dicen de «vibe coding» en LinkedIn` → `vibe coding`.
- Una consulta por idea. Varias ideas en una sola frase diluyen el resultado de los cuatro motores.
- Hashtags: no son una consulta propia (no se midieron en LinkedIn); si el tema los usa, ponlos como palabra.

---

## 4. Idioma

- **Escribe la consulta en el idioma de quien publica.** Una consulta en español devuelve publicaciones en español y
  alguna en inglés o portugués.
- `--idioma es|en` filtra después de buscar con una detección simple por palabras frecuentes. Si el texto es corto o
  mezclado, la detección dice «no sé» y **no descarta**: es preferible dejar pasar a perder una publicación.
- `--idioma auto` (por defecto) infiere el idioma del tema; si no puede (p. ej. «vibe coding»), no filtra, y la
  búsqueda de pago no se lanza hasta que pases `--idioma en` explícito.
- Un tema en portugués no está soportado por el filtro: se tratará como «otro idioma» si pides `es` o `en`.

---

## 5. Ventanas de fecha

- `--desde AAAA-MM-DD` (incluido) y `--hasta AAAA-MM-DD` (excluido). Por defecto, los últimos 30 días.
- **La fecha de cada publicación sale del número del enlace**: `ID de actividad >> 22` son milisegundos UTC. En las pruebas
  del 14-15 de octubre de 2026 coincidió al segundo con la fecha del proveedor en 60/60 posts. Las fechas de los buscadores son solo a nivel de día
  y a veces faltan; no se usan.
- **Dos momentos de filtrado:**
  1. `descubrir` descarta lo que ya tiene fecha por el ID y queda fuera de la ventana (ahorra pagar sus métricas).
  2. `citas` aplica la ventana final **después de enriquecer**. Una publicación cuya URL no trae ID de actividad
     (formas `ugcPost`/`share`) sigue en juego hasta que un proveedor devuelva su ID; si tampoco entonces, va a
     «cobertura incompleta» como `sin_fecha`.
- Los proveedores reciben la ventana como filtro de recencia (`postedLimit` en Apify; día/semana/mes/año en los
  buscadores). Solo `month` está probado en vivo para Apify, así que la búsqueda de pago va SIEMPRE con `month` (con un
  aviso en la cobertura si la ventana pedida es otra) y la ventana exacta se aplica después, en `citas`. Si la ventana
  es mayor de un mes, la búsqueda de pago solo cubre el último mes.

---

## 6. Cuánto pedir y cuándo parar

```text
descubrir: --n 5-10 por buscador (máximo 10). 4 buscadores ≈ 0,017 USD por consulta.
metricas:  solo lo que pasa el triage. Cada URL ≈ 0,005 USD en Apify (reserva) y ≈ 0,0015 USD en Bright Data.
parar:     cuando dos consultas seguidas no traen publicaciones nuevas relevantes (el skill cuenta `duplicado`).
```

- Una investigación típica de LinkedIn: 3 consultas × 4 buscadores + 20-30 URL medidas ≈ 0,05-0,25 USD, y la búsqueda
  de pago en inglés suma ≈ 0,04 USD por tanda de 2 consultas × 10 posts (cálculo propio con las tarifas de
  `proveedores-y-costes.md`).
- **El tope total protege, no sustituye al criterio**: antes de medir 100 URL, pregúntate si 25 bastan.
- Para barridos grandes, un modelo barato lanza `descubrir` y vuelca lo literal; el análisis lo hace un modelo fuerte
  sobre `citas`. Lanzar `metricas` desde un agente caro esperando respuestas quema tokens sin aportar.

---

## 7. Limpieza que hace el skill y por qué

| Descarte | Qué detecta | Por qué |
|---|---|---|
| `no_es_publicacion` | perfiles, `/pulse/`, empresas | los buscadores devuelven de todo |
| `duplicado` | misma publicación por varios motores o formas de URL | la clave es el ID de actividad |
| `idioma` | texto de otro idioma (detección por palabras frecuentes) | «curso online» trae portugués e inglés |
| `relleno` | cupones de cursos, «¡SUSCRÍBETE!» con enlaces, bloques solo de enlaces, 0 interacción y sin texto propio. Con una lectura de 50+ reacciones o 10+ comentarios nada es relleno (tampoco los cupones; la ficha lleva un aviso). Al descubrir, antes de medir, solo se descartan `cupones` y `solo_enlaces` sin interacción conocida; el «0 interacción» exige haber medido | medido en la búsqueda de pago: sin ninguna interacción, 4 de 10 en «curso online» y 6 de 10 en «lanzamiento de curso online» |
| `tope_por_autor` | más de 2 publicaciones del mismo autor (`--max-por-autor`) | un autor llegó a salir 4 veces en 60 resultados |
| `fuera_de_ventana` | fecha por ID fuera de `--desde/--hasta` | los motores no respetan siempre la ventana |

Todo se **cuenta con su motivo** en la cobertura y en `registros.json` (`descartados`, sin texto). Si crees que un
descarte es injusto, ajusta el filtro (`--idioma`, `--max-por-autor`), no lo ocultes.

---

## 8. Errores típicos

- **Pedir métricas de todo lo descubierto sin triage**: es el mayor gasto evitable.
- **Usar `--pago` con un tema en español**: se ignora y se avisa; las pruebas la midieron mala.
- **Confiar en la fecha de un buscador**: usa la del ID.
- **Entregar los candidatos de `descubrir` como si fueran citas**: no tienen métricas ni texto literal; son pistas.
- **Interpretar `reacciones_totales` como «me gusta»**: incluye todos los tipos de reacción.
- **Buscar a una persona concreta**: este skill busca por tema. Los perfiles no se leen (ver privacidad).
