# Privacidad y riesgos

Qué riesgos tiene recoger publicaciones de LinkedIn, qué decide este skill para evitarlos y qué te toca decidir a ti.
**No es asesoría jurídica**: las fuentes legales de abajo son periodísticas o de despachos, ninguna es el fallo original,
y hay partes sin verificar (se dice cuáles). Corte: 14-oct-2026.

## Table of Contents

1. [Regla de oro: sin cuentas, sin cookies, sin navegador](#1-regla-de-oro-sin-cuentas-sin-cookies-sin-navegador)
2. [Casos de la investigación previa](#2-casos-de-la-investigación-previa)
3. [Términos de LinkedIn](#3-términos-de-linkedin)
4. [Qué hace el skill para reducir el riesgo](#4-qué-hace-el-skill-para-reducir-el-riesgo)
5. [Datos personales de los autores](#5-datos-personales-de-los-autores)
6. [Seudonimizar no es anonimizar](#6-seudonimizar-no-es-anonimizar)
7. [Antes de publicar o compartir](#7-antes-de-publicar-o-compartir)
8. [Si alguien pide saltarse la regla](#8-si-alguien-pide-saltarse-la-regla)

---

## 1. Regla de oro: sin cuentas, sin cookies, sin navegador

Este skill **no inicia sesión en LinkedIn, no usa cookies de sesión, no abre un navegador, no usa extensiones ni
agentes con navegador y no usa actores o servicios que pidan cookies o credenciales de LinkedIn**. Solo llama a APIs de
terceros con su propia clave (buscadores y proveedores de datos públicos) y lee publicaciones **visibles sin iniciar
sesión**.

La razón es doble: el riesgo de cierre de la cuenta que se conecte y el de litigio de los proveedores que operan con
cuentas falsas. Ver §2.

---

## 2. Casos de la investigación previa

Cada cita lleva su fuente y fecha. Lo marcado «sin verificar» no se ha podido contrastar con una fuente primaria.

**Demandas a proveedores**

- **Proxycurl** (proveedor de datos de LinkedIn). Demandada el 24-ene-2025 (caso 3:25-cv-00828, N.D. Cal.). Su fundador,
  4-jul-2025 (<https://nubela.co/blog/goodbye-proxycurl/>):
  > In January earlier this year (2025), LinkedIn filed a lawsuit against Proxycurl. Today, we are shutting Proxycurl
  > down. … Regardless of the merits of LinkedIn's lawsuit, there is no winning in fighting this.

  LinkedIn, 28-jul-2025:
  > LinkedIn has successfully resolved its lawsuit against Proxycurl, addressing allegations of unauthorized data
  > scraping, fraud, and trademark misuse.

  La acusación habría sido «hundreds of thousands of fake accounts» (fuente secundaria).
- **ProAPIs / Netswift.** LinkedIn demandó en oct-2025 por cuentas falsas. Sentencia firmada por consentimiento el
  16-sep-2026 (Sigma Law Group, 18-sep; RecordingLaw, 6-oct). Prohíbe
  > accessing LinkedIn through fake accounts, scraping, bots, or any circumvention of its access controls

  y obliga a destruir los datos. RecordingLaw aclara que la sentencia
  > binds only these three defendants.

  Las fechas de cierre difieren entre fuentes (16, 17, ≈20 y 21 de septiembre). ProAPIs responde que
  > does not offer tools to scrape LinkedIn.
- **Bright Data: una «medida cautelar de sep-2026» NO está verificada.** Solo la cita una fuente (WebProNews) y su página
  daba «Page not found»; el resto de fuentes jurídicas habla solo de ProAPIs. Lo que sí consta (Sigma, secundaria):
  > Meta Platforms v. Bright Data in 2024, holding that logged-out scraping of public pages did not breach Meta's terms.

  (Es un caso de Meta, no de LinkedIn.)
- **hiQ.** Fuentes en conflicto sobre el desenlace; no se usa.

**Cierres y restricciones de cuentas** (anécdotas, no estadística: no permiten estimar una probabilidad)

- Un usuario de r/openclaw (15-mar-2026, 46 votos), con un agente que solo navegaba:
  > 48 hours later my LinkedIn account was restricted. the agent had done nothing wrong technically, it was just
  > browsing. … that restriction cost me 2 weeks of downtime
- Otro, en r/recruiting (14-sep-2026, 16 votos), usando un asistente para ver perfiles:
  > My LinkedIn account has been temporarily restricted because “we detected that over time, it has accessed an
  > unusually high volume of LinkedIn profile data”.

  Una respuesta con 57 votos: «LinkedIn are cracking down on users who breach their ToS».
- En X (cifras y textos **sin verificar**): quien dijo que un agente le dejó la cuenta «fully blocked» sin haber
  extraído datos (3-mar-2026), y otros cierres de cuentas de empresas de automatización (jun-2026).
- Contraevidencia: el autor de uno de los casos dice que la misma tarea corre cada mañana con llamadas de API «without
  issues»; alguien con unas quince cuentas con rotación aún tenía «soft locks». No hay un nivel seguro garantizado.

**Lo que no trata ninguno de estos casos**: leer publicaciones públicas sin sesión. Los datos del actor de búsqueda
que usa el skill traen el marcador «Visible to anyone on or off LinkedIn».

---

## 3. Términos de LinkedIn

LinkedIn Ayuda («Prohibited software and extensions», 13-ago-2026,
<https://www.linkedin.com/help/linkedin/answer/a1341387/prohibited-software-and-extensions>):
> we don't permit the use of any third party software, including “crawlers”, bots, browser plug-ins, or browser
> extensions that scrape, modify the appearance of, or automate activity on LinkedIn's website.

Un litigante de Proxycurl (hoy vende otro producto: hay conflicto de interés) cita el 8.2(4) del User Agreement:
> Copy, use, display or distribute any information (including content) obtained from the Services, whether directly or
> through third parties (such as search tools or data aggregators or brokers)

(<https://nubela.co/blog/is-scraping-linkedin-legal-in-2026/>, mayo-2026). **Es su interpretación, no un fallo.**

Qué significa para ti: los términos de LinkedIn prohíben el scraping y la redistribución de contenido obtenido de sus
servicios. Este skill no accede a LinkedIn: recibe de terceros lo que ellos recogen. Si tu uso (producto comercial,
reventa, publicación de lo obtenido) es compatible con esos términos y con la ley de tu país, **no lo decide este
skill**: requiere criterio legal.

---

## 4. Qué hace el skill para reducir el riesgo

| Medida | Cómo |
|---|---|
| Sin cuenta ni cookie | No hay código de inicio de sesión ni de cookies; los actores admitidos están en la tabla `ACTORES` y ninguno las pide |
| Sin navegador | Solo HTTP a APIs de proveedores; ningún enlace de un post se abre por cuenta propia |
| Solo publicaciones | Perfiles, empresas y artículos se descartan (`no_es_publicacion`) y no se leen |
| Solo lo público | Lo que devuelve un proveedor sin sesión; si es privado o borrado, `no_disponible` |
| Mínimo necesario | Lee una publicación por URL; no recorre perfiles ni listas de contactos |
| Entradas probadas | Una tabla cerrada de parámetros por actor; nada nuevo sin prueba |
| Claves | Nunca en el chat, en argumentos ni en URL; fichero 0600 |
| Seudonimización | `--anonimizar-autores` y `--sin-url` (ver §6) |

---

## 5. Datos personales de los autores

Una publicación pública de LinkedIn contiene datos personales: nombre, cargo implícito, opiniones, a veces datos de
terceros. El skill guarda por publicación: URL, autor, fecha, texto, métricas y qué buscadores la encontraron. **No
guarda** perfiles, seguidores, fotos ni comentarios: si el texto de respaldo (Exa o Firecrawl) trae un bloque de
comentarios de otras personas, `leer` lo corta antes de él, no lo imprime ni lo guarda y avisa
(`comentarios_de_terceros_omitidos`).

Buenas prácticas:

- **Recoge lo necesario para la pregunta.** Una investigación de mercado no necesita fichar a personas concretas.
- **Borra al terminar** lo que no vayas a conservar: la carpeta `--salida` (`registros.json`, `citas-*`) y la caché
  (`~/.linkedin-search/cache`). El libro de gasto (`gasto.jsonl`) no contiene datos de autores.
- **No cruces con otras fuentes para identificar** a los autores si no es el fin legítimo de tu trabajo.
- **Respeta peticiones de retirada**: si alguien te pide quitar su publicación de un informe, quítala.
- **Obligaciones de protección de datos** (según tu país y tu uso) pueden aplicar a lo que guardes y publiques. Consúltalo
  antes de conservar a largo plazo, vender o publicar.

---

## 6. Seudonimizar no es anonimizar

```text
--anonimizar-autores   cambia el nombre por «autor-» + 10 caracteres de un hash estable del nombre (SHA-256)
--sin-url              quita la URL y el ID de actividad (los sustituye por «pub-» + hash)
```

- **El mismo autor sale con el mismo seudónimo** en todas las entregas: sirve para contar publicaciones por autor sin
  nombrarlo.
- **No es anonimato**: con `--anonimizar-autores` solo, la **URL sigue identificando al autor** (lleva su identificador).
  Con `--sin-url` también, **el texto literal sigue siendo localizable** con un buscador. Para anonimizar de verdad habría
  que no citar el texto, y entonces ya no es data original.
- **`--anonimizar-autores` también omite los datos de contacto del texto**: correos y teléfonos (incluidos los de
  `wa.me/…`) se sustituyen por «[correo omitido]» / «[teléfono omitido]». Es una **alteración del literal**, declarada
  con el aviso `datos_de_contacto_omitidos` en cada ficha afectada. Solo se omite lo que **tiene forma de teléfono**:
  prefijo `+` o paréntesis, grupos de 2-4 dígitos separados por espacio, punto o guion, con 8-15 dígitos en total, o
  9-15 cifras seguidas sin separadores (o cifras sueltas justo después de «móvil», «WhatsApp», «tel»…). No se tocan las
  cifras junto a una moneda o unidad (USD, $, €, %, millones, M, K…), un ISBN, una fecha (2026-10-15, 31.10.2026,
  15 10 2026) ni un número con separador de millares (1.200.000, 12 000 000). Es de mejor esfuerzo: una cantidad grande
  escrita sin separadores ni unidad («100000000»), una con grupos de 3 tras un primer grupo de 3 («120 000 000») o una
  serie de pares de dígitos («10 20 30 40 50 60») se parecen a un teléfono y se omiten. Los nombres de personas, las marcas
  y los dominios dentro del texto no se tocan: quítalos tú si hace falta.
- **Con `--sin-url` la cobertura de `citas-*.json` no lleva IDs ni claves de lo descartado**, solo recuentos.
- **Los ficheros de trabajo de `--salida` NO están seudonimizados**: `registros.json` y `descubrir-*.json|md` guardan
  nombres, enlaces y textos reales. `citas` lo avisa siempre que usas `--anonimizar-autores` o `--sin-url`. Comparte
  solo `citas-<sello>.md|json`, nunca la carpeta entera.
- El hash no lleva sal por defecto: quien tenga una lista de nombres puede comprobar cuál produce cada seudónimo. Define
  `LINKEDIN_SEARCH_SAL` con un valor privado para evitarlo.
- Recomendación: **actívalas siempre que el material vaya a terceros** (informes, formación, publicaciones). Para uso interno
  de investigación no hace falta.

---

## 7. Antes de publicar o compartir

- [ ] ¿Citas texto literal de personas identificables? Valora `--anonimizar-autores`, `--sin-url` o pedir permiso.
- [ ] ¿Hay datos de terceros dentro de los textos (nombres, marcas)? Quítalos (correos y teléfonos los omite `--anonimizar-autores`).
- [ ] ¿Vas a vender, publicar o entrenar con lo obtenido? Eso no lo decide el skill: criterio legal primero.
- [ ] ¿Consta en el informe de dónde y cuándo se obtuvo (proveedor, fecha de consulta)? El `.md` de `citas` ya lo trae.
- [ ] ¿Compartes solo la entrega (`citas-*`) y no la carpeta `--salida` con `registros.json`? ¿Borraste la carpeta y la caché si no hacen falta?

---

## 8. Si alguien pide saltarse la regla

«Usa mi cuenta», «pásame las cookies al actor», «abre LinkedIn en el navegador y copia»: **no**. Explica el motivo (§1–§3)
y ofrece lo que sí hay: más buscadores, más consultas, `metricas` con las URL que el propio usuario te dé y, si necesita
algo que solo hay con sesión, que lo haga él, a mano, en su cuenta y bajo su responsabilidad.
