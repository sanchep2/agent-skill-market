# linkedin-search

Skill para que tu agente busque en LinkedIn cualquier tema y te entregue **publicaciones literales** con su enlace,
autor, fecha y métricas (reacciones totales, comentarios, compartidos). No hace resúmenes inventados: el texto es el que
devuelve el proveedor, la fecha sale del número del propio enlace y las métricas se contrastan con dos fuentes.

**No usa tu cuenta de LinkedIn, ni cookies, ni navegador.** Solo llama a servicios de terceros con sus propias claves.

## Instalar

Descarga `linkedin-search.zip` y dile a tu agente (Claude Code, Codex o Hermes):

> «Instala el skill linkedin-search de este zip y comprueba que funciona.»

Lo descomprime en su carpeta de skills, comprueba que tenga Python 3.9 o superior y ejecuta `salud`, que te dice qué
falta.

| Agente | Carpeta de skills |
|---|---|
| Claude Code | `~/.claude/skills/linkedin-search` |
| Codex | `~/.codex/skills/linkedin-search` |
| Hermes | `~/.hermes/skills/linkedin-search` |

## Qué necesitas

Una clave de **un buscador** para descubrir publicaciones y una de **Apify o Bright Data** para medirlas. Con las dos de
medición, las métricas se contrastan entre fuentes. Todos tienen un plan gratis o un precio por uso muy bajo
(`references/proveedores-y-costes.md`):

| Para qué | Proveedores |
|---|---|
| Descubrir | Exa (recomendado), Perplexity, Firecrawl, Brave |
| Medir | Apify, Bright Data |

Cuando tengas una clave, **cópiala al portapapeles** y dile a tu agente:

> «Guarda esta clave de Exa para linkedin-search.»

La guarda sin mostrarla, con permisos privados. **Nunca la pegues en el chat.** Cómo dar de alta cada servicio:
`references/instalacion-y-alta.md`.

## Usar

> «Busca en LinkedIn qué se publica sobre [tu tema] desde el 15 de septiembre y dame las 10 publicaciones con más
> reacciones.»

> «Mide las reacciones y comentarios de estas publicaciones de LinkedIn: [enlaces].»

> «Dame las citas literales de LinkedIn sobre [tema], sin nombres de autores, para un informe.» (usa
> `--anonimizar-autores`; ver el aviso de abajo)

Cada entrega trae dos bloques: lo que **cumple** el contrato (texto, URL, autor, fecha y métricas) y la **cobertura
incompleta**, con el motivo de cada caso. Nada se descarta en silencio.

## Cuánto cuesta

Una investigación típica ronda **0,15-0,30 USD**. El skill lleva un libro de gasto, reserva el máximo de cada llamada
antes de lanzarla y **se detiene** si no cabe en el tope (por defecto 1,5 USD por investigación y 0,5 USD por llamada).
Nunca compra créditos ni cambia tu plan. Si un servicio devuelve un error de límite, para y te dice la alternativa.

## Requisitos

- Un agente con acceso a internet que pueda ejecutar programas.
- Python 3.9 o superior.
- Claves de los servicios que quieras usar.

**Windows:** **no probado en Windows.** Debería funcionar con variables de entorno o `--desde-fichero`, pero no lo hemos
comprobado.

## Aviso

Sin afiliación con LinkedIn ni con ninguno de los proveedores. El skill solo lee publicaciones visibles sin iniciar
sesión. Los términos de LinkedIn restringen el scraping y la redistribución de su contenido; qué puedes hacer con lo
obtenido depende de tu uso y de tu país, y **no es asesoría jurídica**: léelo en `references/privacidad-y-riesgos.md`
antes de publicar o compartir. `--anonimizar-autores` es **seudonimización**, no anonimato: la URL y el texto literal
siguen permitiendo identificar al autor (`--sin-url` quita la URL, no el texto). Con esa opción, los correos y teléfonos
del texto se sustituyen por marcas visibles (alteración declarada en la ficha), pero los ficheros de trabajo de la
carpeta `--salida` (`registros.json`, `descubrir-*`) guardan los datos sin seudonimizar: comparte solo `citas-*`.
