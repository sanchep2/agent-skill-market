# grok-search

Skill para que tu agente busque en X (Twitter) cualquier tema y te entregue **posts literales** con su enlace, autor,
fecha y métricas (me gusta, reposts, respuestas, vistas). No hace resúmenes inventados: cada cita se contrasta con la
versión pública del post en X.

## Instalar

Descarga `grok-search.zip` y dile a tu agente (Claude Code, Codex o Hermes):

> «Instala el skill grok-search de este zip y comprueba que funciona.»

Lo descomprime en su carpeta de skills, comprueba que tenga Python 3.9 o superior y ejecuta `salud`, que te dice qué
modo puedes usar.

| Agente | Carpeta de skills |
|---|---|
| Claude Code | `~/.claude/skills/grok-search` |
| Codex | `~/.codex/skills/grok-search` |
| Hermes | `~/.hermes/skills/grok-search` |

## Dos modos

- **Con suscripción de Grok (modo cli):** usa Grok Build, la herramienta de terminal oficial de xAI, con tu cuenta de
  grok.com (SuperGrok o X Premium Plus). No paga por búsqueda: consume tu cuota semanal.
  - Si no tienes Grok Build, `salud` te enseña el comando oficial para instalarlo. Tu agente te lo **ofrece** y solo lo
    instala si le dices que sí; después comprueba `grok --version`.
  - El inicio de sesión lo haces tú en tu terminal con `grok login` (abre el navegador; en un servidor sin navegador,
    `grok login --device-auth`).
- **Sin suscripción (modo api):** usa OpenRouter con un modelo de xAI que busca en X. Se paga por uso (entre 0,26 y 0,35 USD
  por búsqueda el 13-oct-2026).
  - Crea una clave en <https://openrouter.ai/settings/keys> **con límite de crédito** («Key limit»): es lo que de
    verdad pone techo al gasto, y el skill no usa claves sin límite. El skill además se frena antes de cada llamada
    con un umbral (`--tope-usd`, 1 USD por defecto), pero una búsqueda puede costar algo más de lo previsto.
  - Dile a tu agente:

    > «Guarda esta clave de OpenRouter para grok-search.»

  - Tu agente la guarda sin mostrarla. Nunca la pegues en el chat si tu agente puede leerla del portapapeles.

## Usar

> «Busca en X qué dice la gente de [tu tema] en el último mes.»

> «¿Qué se ha dicho en X de [tema] en las últimas 24 horas?» (el skill corta por la hora exacta de cada post)

> «Lee el hilo de este post y dame las respuestas más útiles: [enlace].»

> «¿Quién habla en X de [tema]? Dame las cuentas con un post de cada una.»

## Requisitos

- Un agente con acceso a internet que pueda ejecutar programas.
- Python 3.9 o superior.
- Para el modo cli: macOS o Linux, y suscripción de Grok.
- Para el modo api: una clave de OpenRouter con saldo.

**Windows:** el modo api está pensado para funcionar, pero **no se ha probado en Windows**. El modo cli no está soportado
allí: el aislamiento de Grok Build y el bloqueo de procesos que usa el skill no se han probado en Windows.

## Aviso

Sin afiliación con X, xAI ni OpenRouter. El skill solo lee contenido público. El uso automatizado de una cuenta de
consumidor tiene sus riesgos: léelos en `references/limites-cuota-y-costes.md` §6 antes de hacer barridos grandes.
