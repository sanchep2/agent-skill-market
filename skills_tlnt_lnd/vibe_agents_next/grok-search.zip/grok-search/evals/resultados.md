# Resultados de los evals (13-oct-2026)

Mismo agente (modelo de la gama media), mismas cuatro tareas de `evals.json`, CON el skill y SIN él. Sin el skill, el
agente tenía búsqueda web, Exa y peticiones HTTP, y tenía prohibidos el navegador, nitter/xcancel y la CLI `grok`
sin aislar.

| Tarea | Con el skill | Sin el skill | Gana |
|---|---|---|---|
| e1 · 5 posts literales de las últimas 48 h | 8 posts de una búsqueda real en X, los 8 verificados con el oEmbed (5 idénticos, 3 recortados por X), dentro de la ventana; 209 s | 5 posts reales, pero sacados leyendo a mano las líneas de tiempo de ~30 cuentas elegidas por el agente: no es una búsqueda, la muestra está sesgada (lo declara) | Con |
| e2 · 5 respuestas de un hilo | 1.ª ejecución: tiempo agotado (900 s) con la máquina saturada por otro proceso de 16+ búsquedas; 0 respuestas, sin inventar. Repetición: post principal + 5 respuestas en 156 s, las 6 verificadas | Post principal verificado; 5 respuestas copiadas de un espejo de terceros, sin URL, hora ni métricas y sin poder contrastarlas con X | Con (en la repetición) |
| e3 · «no tengo nada instalado» | `salud` en una máquina limpia: comando oficial de instalación con su URL y fecha, login a cargo de la persona, alternativa api; sin instalar nada | Tres caminos razonables, pero sin poder confirmar el comando oficial de instalación | Con |
| e4 · posts recientes de una cuenta + petición de abrir navegador | Sin navegador ni espejos; detecta (por las notas de Grok) que la cuenta cambió de handle y entrega 8 posts del handle nuevo, los 8 verificados | Sin navegador; misma conclusión del cambio de handle; 3 posts sin poder confirmarlos contra X | Con |

Conclusión: con el skill, 4 de 4 tareas resueltas con citas verificadas (e2 en la segunda ejecución); sin el skill,
resultados parciales y sin verificación contra X en 3 de 4.

Problemas que el eval destapó y se corrigieron en el skill:

- `citas` sobrescribía la tanda anterior → ahora escribe `citas-<fecha>.md`.
- Grok puso «Two days ago» como nombre de un autor → tras verificar, el nombre es el que muestra X.
- 0 posts por un cambio de handle sin explicación en pantalla → ahora se muestran las notas de Grok.
- Tiempo agotado sin pista → el mensaje explica la causa probable (saturación) y cómo seguir.
