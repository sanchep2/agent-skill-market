# Límites, cuota, costes y términos de uso

Cuánto cuesta buscar en X con cada modo, cómo se controla el gasto, qué modelo usar y qué riesgo contractual tiene
automatizar una cuenta de consumidor. Todo con fuente y fecha; los precios cambian.

## Table of Contents

1. [Resumen](#1-resumen)
2. [Modo cli: la cuota semanal de la suscripción](#2-modo-cli-la-cuota-semanal-de-la-suscripción)
3. [Modo api: precios de OpenRouter y xAI](#3-modo-api-precios-de-openrouter-y-xai)
4. [Tope y cota del modo api](#4-tope-y-cota-del-modo-api)
5. [Qué modelo y qué esfuerzo (medido)](#5-qué-modelo-y-qué-esfuerzo-medido)
6. [Términos de uso y riesgo para la cuenta](#6-términos-de-uso-y-riesgo-para-la-cuenta)
7. [Errores de límite](#7-errores-de-límite)

---

## 1. Resumen

```text
                 coste por búsqueda              límite                    lo mide el skill con
modo cli   0 € marginal (cuota semanal)    pool semanal compartido       total_cost_usd (EQUIVALENTE) + segundos
modo api   0,26-0,35 USD con grok-4.7      saldo de OpenRouter + tope    usage.cost (REAL), conciliado con /key
```

---

## 2. Modo cli: la cuota semanal de la suscripción

Fuente: FAQ oficial de Grok (<https://docs.x.ai/grok/faq>, consultada el 13-oct-2026):

> Instead of separate daily limits for each product (like Chat, Imagine, Voice, or Build), you get one shared weekly
> usage pool that you can spend however you like across any Grok product.

> When your weekly usage limit is met, paid features will pause until your weekly limit resets.

- El porcentaje usado y la fecha de reinicio se ven en grok.com → Settings → Usage (por producto: API, Build, Chat,
  Imagine, Voice). xAI **no publica** el tamaño del pool.
- La CLI no expone la cuota en modo sin interfaz: `grok usage <sesión>` da tokens y coste por sesión, no el porcentaje
  semanal (`~/.grok/docs/user-guide/17-sessions.md`, línea 288: «Interactive credit and billing stay on `/usage` in the
  TUI.»).
- `total_cost_usd` del modo cli es un **equivalente**: la suscripción no factura por llamada. Sirve como indicador
  relativo de consumo de cuota. La guía avisa: «Read an all-zero `usage` here as "unknown", not "free".»
  (`14-headless-mode.md`, línea 318).
- Medido el 13-oct-2026: entre 0,45 y 1,57 USD equivalentes por búsqueda de 8-10 posts, y de 36 s a 4 min, según
  modelo y esfuerzo (§5).

---

## 3. Modo api: precios de OpenRouter y xAI

Búsqueda en X de xAI (<https://docs.x.ai/developers/pricing>, 13-oct-2026):

> X Search is billed per item fetched rather than per call: every post returned by a search or thread fetch,
> including parent and quoted posts, counts toward the post rate

Tarifa: 5 USD por 1.000 posts y 10 USD por 1.000 perfiles, más tokens, «in effect as of September 21, 2026»
(<https://docs.x.ai/developers/tools/x-search>).

OpenRouter (<https://openrouter.ai/docs/guides/features/server-tools/web-search>, 13-oct-2026): la búsqueda nativa se
cobra «Passed through from the provider» más los tokens. Modelos de xAI listados en `GET /api/v1/models` el 13-oct-2026
(USD por millón de tokens, entrada / salida):

| Modelo | Entrada | Salida |
|---|---|---|
| `x-ai/grok-build-0.1` | 1,00 | 2,00 |
| `x-ai/grok-4.3` | 1,25 | 2,50 |
| `x-ai/grok-4.5`, `grok-4.6`, `grok-4.7` (por defecto del skill: `grok-4.7`) | 2,00 | 6,00 |

Mediciones reales (13-oct-2026, `x-ai/grok-build-0.1`, esfuerzo `low`):

| Búsqueda | Tokens de entrada | Salida | Tiempo | Coste |
|---|---|---|---|---|
| 5 posts, desde el 1-mar | 31.668 | 7.184 | 94 s | 0,1632 USD |
| 6 posts, desde el 1-oct | — | — | 79 s | 0,2910 USD |
| 8 posts, últimas 24 h | 361.511 | 9.862 | 62 s | 0,4780 USD |
| 8 posts, últimas 24 h, `max_tool_calls` 6 | 282.079 | — | 108 s | 0,5105 USD |

El contador de la clave (`GET /api/v1/key`) cuadró con la suma de `usage.cost` de las llamadas. OpenRouter no desglosó
un cargo aparte por posts de X.

---

## 4. Tope y cota del modo api

**Contrato de gasto** (decidido el 13-oct-2026): ningún mecanismo garantiza que UNA llamada no pase de una cifra,
porque la búsqueda en X de xAI hace sus rondas en el servidor de xAI. Por eso hay dos capas:

| Capa | Qué es | Quién la impone |
|---|---|---|
| **Límite del proveedor** | El **límite de crédito de la clave** de OpenRouter (o el presupuesto que bloquee antes) | OpenRouter: rechaza la petición antes de enviarla al proveedor cuando el límite está agotado |
| Umbral previo | `--tope-usd`: no se llama si `gastado + reservas + cota` no cabe | El skill |

- **Sin límite en la clave, el modo api no se usa** (`PRESUPUESTO`), salvo con `--sin-limite-en-clave`, que acepta
  explícitamente el riesgo. `salud` dice si la clave tiene límite y cuánto le queda.
- Riesgo residual declarado, con la cita de OpenRouter (<https://openrouter.zendesk.com/hc/en-us/articles/51680687417499>,
  13-oct-2026): «Once a key reaches its limit, further requests on that key are rejected before they're sent to the
  provider […] Because the check runs per request, a burst of simultaneous requests can slightly overshoot the
  limit». Es decir: la última llamada admitida puede cerrar un poco por encima del límite.
- Para fijar el límite: en <https://openrouter.ai/settings/keys>, «Key limit» de la clave (también por API con una
  clave de gestión: `PATCH /api/v1/keys/{hash}` con `"limit"`). Una clave dedicada al skill con su propio límite es lo
  más limpio.

```text
antes de CADA llamada: GET /api/v1/key (gratis) ─► ¿límite del proveedor? ── no ──► PRESUPUESTO (o --sin-limite-en-clave)
                                                      ── agotado ──► LÍMITE
después, bajo un bloqueo de fichero:
   gastado + reservas pendientes + cota_conservadora  ≤  --tope-usd ?   ── no ──► PRESUPUESTO: no se llama
                                                       │ sí ─► se escribe una RESERVA
                                                       ▼
   llamada ─► nada más recibirla (ANTES de analizar la respuesta) se escribe el GASTO = usage.cost
              (si no viene el coste, o falla la red tras enviar: se cuenta la cota entera)
           ─► uso.jsonl de la salida + ~/.grok-search/uso.jsonl ─► conciliable con GET /api/v1/key

cota_conservadora = máximo de:
    · fórmula: precio_entrada × 120.000 + precio_salida × 16.000 (max_tokens) + 0,005 × 60 posts (+ 0,010 × 20 perfiles)
    · 1,5 × el mayor coste REAL ya registrado con ese modelo (~/.grok-search/uso.jsonl)
    · 0,60 USD de suelo
```

Por qué no basta el precio de lista (medido el 13-oct-2026): una búsqueda de 24 h encadenó **361.511 tokens de
entrada** (327.808 en caché) y costó 0,478 USD, por encima de la fórmula. La búsqueda en X de xAI hace sus rondas en el
servidor de xAI: el campo `max_tool_calls` de OpenRouter (que el skill envía con valor 6) no las limita — en la prueba
siguiente OpenRouter contó 2 pasos y la llamada costó 0,51 USD. Si una llamada supera su cota, el resultado lo avisa y
la cota siguiente sube con ese dato.

- `--tope-usd` por defecto 1 USD, por carpeta de `--salida` (suma todas las llamadas api de esa carpeta). Varios
  procesos con la misma salida comparten el tope gracias a las reservas; con salidas distintas, cada una tiene el suyo.
- Una reserva sin gasto (proceso caído a mitad) sigue contando: es conservador; bórrala a mano solo si sabes que no
  se cobró.
- Con `x-ai/grok-4.7` la cota es de ~0,60 USD (el suelo): con el tope por defecto (1 USD) cabe UNA llamada por carpeta
  de salida; para más, sube `--tope-usd` con el OK de quien paga.
- `max_tokens` limita la salida; la entrada (resultados de búsqueda) no se puede limitar por adelantado: una llamada
  puede superar su cota y el umbral. Se avisa en el resultado, se registra, y la siguiente ya no cabe. Lo que de verdad
  impide pasar de una cifra acordada es el límite de la clave.
- Subir el tope es decisión de quien paga. El skill nunca compra créditos ni activa recargas.

---

## 5. Qué modelo y qué esfuerzo (medido)

Evaluación propia del 13-oct-2026 (modo cli, cuenta de grok.com). Tres consultas distintas (desarrolladores en
solitario con juegos en Steam hechos con agentes; la CLI Grok Build; experiencias de pymes con agentes, en español),
mismo prompt en las cuatro configuraciones de cada consulta. Los 79 posts resultantes se mezclaron sin indicar de qué
configuración venían y los puntuaron **dos jueces ciegos independientes** con una rúbrica fija (relevancia 0-3,
evidencia 0-2, autor 0-2, fuera de tema). Acuerdo entre jueces: nota de relevancia idéntica en 69/79, a un punto en
79/79. «Útil» = relevancia media ≥ 2 y no marcado fuera de tema por ambos.

| Configuración | Útiles | Fuera de tema | Tiempo total | Consumo equivalente | Equivalente por útil |
|---|---|---|---|---|---|
| **`grok-4.7`, esfuerzo por defecto** (defecto del skill) | **22** | **0** | 728 s | 4,88 USD | 0,22 USD |
| `grok-4.7`, `--esfuerzo low` | 17 | 1 | 275 s | 1,49 USD | 0,09 USD |
| `grok-4.5`, esfuerzo por defecto | 15 | 2 | 392 s | 4,54 USD | 0,30 USD |
| `grok-4.7-build-fast`, `--esfuerzo low` | 19 | 2 | 96 s | 2,21 USD | 0,12 USD |

- Literalidad: los 79 posts de las cuatro configuraciones pasaron `citas --verificar` (oEmbed); ninguno inventado.
- Más llamadas internas = más tiempo y consumo, pero también menos posts fuera de tema: el ahorro de esfuerzo se paga
  en relevancia, sobre todo en español (9 útiles de 10 con el defecto frente a 4-5 con las configuraciones rápidas).
- Uso recomendado: el defecto para investigar; `--modelo grok-4.7-build-fast --esfuerzo low` solo para barridos
  rápidos y baratos en los que se acepta más ruido.
- Límites de la medición: tres consultas, una ejecución por configuración y jueces automáticos; es una medida, no una
  ley. Repítela si cambia el modelo por defecto de la CLI.

Modo api: ver la tabla de búsquedas de las últimas horas. `x-ai/grok-4.7` resultó más barato por búsqueda que
`x-ai/grok-build-0.1` pese a su mayor precio por token (hace menos rondas de búsqueda) y es el defecto del skill.

### Búsquedas de las últimas horas (`--horas`), medidas el 13-oct-2026

Tres consultas de 24 h (novedades y problemas de Claude Code; anuncios de OpenAI y reacciones; noticias de IA
comentadas por programadores, en español), misma rúbrica y dos jueces ciegos que en la tabla anterior. «v1» = primer
prompt («Latest primero»); «v2» = prompt actual («Latest y Top; dentro de la ventana, lo más sustancioso: ser lo más
nuevo no es un mérito»).

| Configuración | Útiles | Fuera de tema | Antigüedad mediana | Tiempo por búsqueda | Coste por búsqueda |
|---|---|---|---|---|---|
| **cli `grok-4.7`, prompt v2** (defecto) | **22/24** | 0 | 3,8-7,0 h | ~3,5 min | cuota (0,64-0,81 USD eq.) |
| **api `x-ai/grok-4.7`, prompt v2** (defecto api) | **22/24** | 0 | 0,8-5,4 h | ~37 s | 0,28-0,35 USD |
| cli `grok-4.7`, prompt v1 | 21/24 | 0 | 1,3-7,1 h | ~3,7 min | cuota |
| api `x-ai/grok-4.7`, prompt v1 | 12/24 | 0 | 0,7-4,0 h | ~35 s | 0,26 USD |
| api `x-ai/grok-build-0.1`, prompt v1 | 14/23 | 1 (+1 cita con ID de otro post) | 0,2-2,0 h | ~80 s | 0,39-0,51 USD |

- 100 % de los posts de las 15 búsquedas dentro de la ventana: el skill además corta por la hora exacta del ID.
- La nota media (relevancia + evidencia + autor, 0-7) fue algo mayor en cli (5,06) que en api (4,56): más
  experiencia de primera mano. La api es unas 6 veces más rápida.
- El prompt v2 dobló los útiles de la api (12 → 22): sin él, la api devolvía lo más nuevo aunque no aportara.
- `x-ai/grok-build-0.1` quedó descartado como defecto de la api: más caro, más lento y con un emparejamiento falso de
  texto e ID (lo cazó `citas --verificar`).
- Límite de la medición: tres consultas en una sola noche; una de ellas (OpenAI) dominada por una única noticia.

---

## 6. Términos de uso y riesgo para la cuenta

Lo que dicen las fuentes (13-oct-2026):

- Política de uso aceptable de xAI (<https://x.ai/legal/acceptable-use-policy>, «Effective: August 14, 2026»):

  > Accessing the Services through unauthorized automated or non-human means, whether through a bot, script, or otherwise

  y «Violating our policies could result in action against your account, up to suspension or termination.»
- La misma política cambió en agosto de 2026 de «automated» a «**unauthorized** automated» (registro de cambios de
  <https://www.termsobservatory.org/changes.html>, 15-ago-2026).
- xAI publica el modo sin interfaz para scripts: «Headless mode (`-p`) allows easily running agents inside scripts and
  automations» (<https://x.ai/news/grok-build-cli>, 25-may-2026) y «Use headless mode for scripts, bots, or other
  machine-friendly tasks» (<https://docs.x.ai/build/cli/headless-scripting>).
- Términos de consumidor (<https://x.ai/legal/terms-of-service>, «Last Updated: October 12, 2026»): «we may implement
  rate limitations» y pueden suspender el acceso si se incumplen los términos o la política.

Lectura (no es asesoría legal):

```text
MENOR riesgo   modo api (cuenta de desarrollador, uso previsto para automatización)
               modo cli con la CLI oficial, ritmo humano, consultas dirigidas (lo que hace este skill)
MAYOR riesgo   reutilizar el token de ~/.grok/auth.json fuera de la CLI (este skill NO lo hace)
               barridos masivos sin pausa, muchos procesos a la vez, reventa de resultados
```

No se encontraron casos publicados de cuentas suspendidas por usar `grok -p` en scripts; la ausencia de casos no es una
garantía. Quien use el modo cli asume ese riesgo para su cuenta: mantén `--n` pequeño, la caché activada y el bloqueo
de 3 procesos.

---

## 7. Errores de límite

| Señal | Modo | Qué hace el skill |
|---|---|---|
| Error del proceso con «usage limit», «quota», «rate limit», «limit reached» | cli | `LÍMITE`, código 3, sin reintento |
| Fin anormal (`stopReason` distinto del normal) sin resultado | cli | Para con error, sin reintento (puede ser un límite con otra redacción) |
| HTTP 402 (sin saldo) o 429 (demasiadas peticiones) | api | `LÍMITE`, código 3, sin reintento |
| Límite de crédito de la clave agotado | api | `LÍMITE`, código 3, sin llamar |
| Clave sin límite de crédito | api | `PRESUPUESTO`, código 4, sin llamar (salvo `--sin-limite-en-clave`) |
| `gastado + reservas + cota > --tope-usd` | api | `PRESUPUESTO`, código 4, sin llamar |

Solo se mira el error del proceso o de la respuesta HTTP, nunca el texto de los posts (un post puede hablar de
«usage limits» sin que haya ningún límite).
