# Aislamiento y seguridad del modo cli

Por qué Grok Build se ejecuta aislado, qué capas tiene el aislamiento, qué comprueba el script antes y después de cada
búsqueda y qué riesgos quedan.

## Table of Contents

1. [El riesgo](#1-el-riesgo)
2. [Capas del aislamiento](#2-capas-del-aislamiento)
3. [Herramientas excluidas](#3-herramientas-excluidas)
4. [Comprobaciones antes, durante y después](#4-comprobaciones-antes-durante-y-después)
5. [Lo que el skill toca en disco](#5-lo-que-el-skill-toca-en-disco)
6. [Riesgos residuales](#6-riesgos-residuales)
7. [Cómo probarlo tú](#7-cómo-probarlo-tú)

---

## 1. El riesgo

Grok Build está pensado como agente de programación: lee ficheros, ejecuta comandos y, por compatibilidad, **importa la
configuración de otros agentes** de tu máquina.

- Guía oficial de la CLI (`~/.grok/docs/user-guide/08-skills.md`, v1.0.52): «Grok scans the Claude and Cursor skill
  directories by default.»
- Misma guía, `07-mcp-servers.md`: «The Claude and Cursor MCP sources are scanned by default.»
- `10-hooks.md`: los hooks se cargan de `~/.grok/hooks/*.json`, de `~/.claude/settings.json`, de `~/.cursor/hooks.json`,
  de la configuración y de los plugins instalados.

Incidente real (13-oct-2026): ejecutada con el HOME normal, Grok cargó el MCP de navegador de otro agente, abrió un
navegador e intentó leer posts en un espejo de X suspendido. Un buscador no necesita nada de eso.

---

## 2. Capas del aislamiento

```text
proceso grok -p
 ├─ HOME = ~/.cache/grok-search/home     solo contiene el enlace .grok → ~/.grok (sesión y modelos)
 │                                        sin ~/.claude, ~/.cursor, ~/.codex… → nada que importar
 ├─ cwd = carpeta nueva y vacía           sin .claude/.grok/.cursor de proyecto, sin hooks de proyecto
 ├─ GROK_CLAUDE_{SKILLS,MCPS,AGENTS,HOOKS,RULES}_ENABLED=false
 ├─ GROK_CURSOR_{SKILLS,MCPS,AGENTS,HOOKS,RULES}_ENABLED=false
 ├─ GROK_MEMORY=0                         sin memoria entre sesiones
 ├─ entorno por LISTA BLANCA (PATH, LANG, TERM, TMPDIR, TZ, proxies…): ni credenciales ni GROK_HOME,
 │                                        CLAUDE_CONFIG_DIR o XDG_CONFIG_HOME que redirijan la configuración
 ├─ --no-subagents · --no-auto-update
 └─ --disallowed-tools <todas las locales> (§3)   ← nunca --tools (quita las de X)
```

Las variables `GROK_CLAUDE_*_ENABLED` y `GROK_CURSOR_*_ENABLED` están documentadas en
`~/.grok/docs/user-guide/26-config-reference.md` («Scan Claude MCP config. Also GROK_CLAUDE_MCPS_ENABLED.»).

Por qué no `--sandbox`: la guía `18-sandbox.md` dice «A symlinked `$GROK_HOME` … is refused at sandbox start». Con un HOME
enlazado el sandbox de la CLI no arranca; el aislamiento del skill se apoya en el entorno, en la exclusión de
herramientas y en las comprobaciones de §4.

---

## 3. Herramientas excluidas

Grok Build 1.0.52, con la lista de exclusiones que circula en ejemplos públicos, **seguía ofreciendo** `read_file`,
`list_dir`, `grep`, `enter_plan_mode`, `exit_plan_mode`, `ask_user_question`, `send_feedback`, `web_search` y `web_fetch`
(evento `available_commands` de una ejecución real, 13-oct-2026). El skill excluye:

```text
run_terminal_command write search_replace read_file list_dir grep image_gen image_edit image_to_video
reference_to_video scheduler_create scheduler_delete scheduler_list workflow use_tool search_tool monitor
todo_write kill_command_or_subagent get_command_or_subagent_output enter_plan_mode exit_plan_mode
ask_user_question send_feedback Agent  +  web_search web_fetch (salvo en el subcomando `web`)
```

Las herramientas de X (`x_keyword_search`, `x_semantic_search`, `x_thread_fetch`, `x_user_search`) son del servidor
(`"backend": true` en el stream) y no aparecen en esa lista: no se pueden excluir por error.

Si una versión nueva de Grok trae otra herramienta local, el script **aborta** (§4) y lo dice. Para añadirla a la
exclusión sin editar el script: `GROK_SEARCH_DENY_EXTRA=nueva_herramienta`.

---

## 4. Comprobaciones antes, durante y después

```text
ANTES    preparar_home(): el enlace .grok apunta a ~/.grok y no hay .claude/.cursor/.codex/.agents/.mcp.json
         (comparación sin mayúsculas: macOS no las distingue)
         grok inspect (aislado, sin coste) → exige:
           MCP Servers (None) · Hooks (None) · Plugins (None) · Project Instructions (None)
           solo skills «bundled» · compatibilidad skills/rules/agents/mcps/hooks = OFF
         cualquier fallo → AISLAMIENTO y NO se lanza la búsqueda
DURANTE  available_commands con una herramienta local no excluida → se corta
         tool_call que no sea de servidor (rawInput.backend ≠ true o variant ≠ XSearch/WebSearch) → se corta
         tool_call_update con un nombre que no es de X → se corta
         «cortar» = matar el GRUPO de procesos entero (Grok y cualquier hijo que haya lanzado)
DESPUÉS  ficheros nuevos en su carpeta o rastro .playwright-mcp → AISLAMIENTO; la carpeta se CONSERVA como evidencia
         procesos de navegador con depuración remota: si suben, aviso (evidencia complementaria, cuenta los de toda
         la máquina)
         si no pasó nada, la carpeta de la ejecución se borra (es del skill)
```

`grok inspect` se ejecuta en la MISMA carpeta y con el MISMO entorno que la búsqueda, y se analiza sección a sección:
`MCP Servers`, `Hooks`, `Plugins`, `Marketplaces`, `LSP Servers` y `Project Instructions` deben estar en `(None)`;
`Skills` solo `bundled` y `Agents` solo `builtin`, con el recuento cuadrando; la configuración de usuario debe ser la
del HOME aislado; cualquier sección repetida o desconocida con contenido falla cerrado.

Datos reales (302 eventos de herramienta, 13-oct-2026): todas las herramientas de X llegan como `tool_call` con
`"rawInput": {"variant": "XSearch", "backend": true}` y la web como `WebSearch`; el nombre exacto
(`x_keyword_search`…) solo llega después, en `tool_call_update`.

La prevención real es `--disallowed-tools` y el entorno aislado (ANTES); el corte de DURANTE es detectivo: actúa en el
primer evento de la herramienta, que ya puede haber empezado. Las comprobaciones de DESPUÉS solo dejan constancia.

---

## 5. Lo que el skill toca en disco

| Ruta | Qué | Quién la escribe |
|---|---|---|
| `~/.cache/grok-search/home/.grok` | Enlace a `~/.grok` | El skill (una vez) |
| `~/.cache/grok-search/runs/run.*` | cwd vacío por llamada; se borra al terminar, salvo que Grok escribiera algo (evidencia) | El skill |
| `~/.cache/grok-search/locks/{0,1,2}.lock` | Bloqueo de 3 procesos | El skill |
| `~/.cache/grok-search/respuestas/` | Caché de respuestas BUENAS (24 h; 30 min con `--horas`) | El skill |
| `~/.grok-search/claves.env` | Clave de OpenRouter (600) | El agente, con tu clave |
| `~/.grok-search/uso.jsonl` | Registro global de uso | El skill |
| `~/.grok/sessions`, `~/.grok/logs`… | Sesiones, logs y refresco de la sesión | **La propia CLI**, como en cualquier uso |
| `~/.grok/config.toml` | Tu configuración | **Nadie**: el skill no la lee ni la cambia |

---

## 6. Riesgos residuales

- **Grok sigue siendo un modelo**: puede inventar texto o métricas. Mitigación: validación por URL e ID, y
  `citas --verificar` con el oEmbed oficial de X.
- **Inyección de instrucciones desde X**: sin herramientas locales, un post que diga «lee ~/.ssh» no tiene con qué
  hacerlo; aun así, el contenido es dato, nunca instrucción.
- **Cambios de la CLI**: una versión nueva puede renombrar herramientas o secciones de `inspect`. El script falla cerrado
  (aborta) en vez de seguir sin aislamiento.
- **Windows**: sin enlace simbólico fiable ni `fcntl`, el modo cli no se ofrece allí (ver `instalacion-y-alta.md` §5).
- **Lo que hace el servidor de xAI** con la consulta queda fuera de este skill.

---

## 7. Cómo probarlo tú

```bash
python3 "$SKILL_DIR/scripts/grok_helper.py" salud          # «OK aislamiento: 0 MCP, 0 hooks, 0 plugins…»
python3 -m unittest discover -s "$SKILL_DIR/scripts"         # incluye los casos de inspect sin aislar y herramienta local
```

Prueba manual de contraste (sin el skill, para ver la diferencia; no lances búsquedas así):

```bash
cd "$(mktemp -d)" && grok inspect | sed -n '/Harness Compatibility/,$p'   # con tu HOME: «on (default)»
```
