# Instalación y alta: Grok Build, sesión y OpenRouter

Qué hacer cuando `salud` dice que falta la CLI, la sesión o la clave. Todo lo de terceros lleva fuente oficial y fecha de
consulta; si una fuente cambia, manda la fuente.

## Table of Contents

1. [Decisión: qué modo te conviene](#1-decisión-qué-modo-te-conviene)
2. [Instalar Grok Build (método oficial)](#2-instalar-grok-build-método-oficial)
3. [Comprobar e iniciar sesión](#3-comprobar-e-iniciar-sesión)
4. [Alta en OpenRouter (modo api)](#4-alta-en-openrouter-modo-api)
5. [Windows](#5-windows)
6. [Qué hace y qué no hace el agente](#6-qué-hace-y-qué-no-hace-el-agente)
7. [Errores frecuentes](#7-errores-frecuentes)

---

## 1. Decisión: qué modo te conviene

```text
¿Tienes SuperGrok o X Premium Plus? ── sí ──► modo cli (coste marginal 0, cuota semanal)
        │ no                                   └─ ¿estás en Windows? ── sí ──► modo api
        ▼
¿Aceptas pagar por uso (~0,26-0,35 USD por búsqueda)? ── sí ──► modo api con --tope-usd
        │ no
        ▼
Sin modo: el skill no puede buscar en X (salud lo explica y termina con código 2)
```

| Estado en `salud` | Siguiente paso |
|---|---|
| `CLI Grok Build: no está instalada` | §2, o el modo api (§4) si no quieres instalarla |
| `MAL sesión` | §3: `grok login` en tu terminal |
| `MAL modo api: la clave da HTTP 401` | Clave revocada o de otra cuenta: crea otra (§4) |
| `modo cli: no soportado en Windows` | §5 |

---

## 2. Instalar Grok Build (método oficial)

Verificado el 13-oct-2026 en la documentación oficial de xAI (<https://docs.x.ai/build/overview>), en la página
<https://x.ai/cli>, en el README del repositorio oficial <https://github.com/xai-org/grok-build> y en la guía incluida en
la propia CLI (`~/.grok/docs/user-guide/01-getting-started.md`, versión 1.0.52).

| Sistema | Comando oficial |
|---|---|
| macOS, Linux (y Windows con Git Bash) | `curl -fsSL https://x.ai/cli/install.sh \| bash` |
| Windows (PowerShell) | `irm https://x.ai/cli/install.ps1 \| iex` |

Citas literales:

> Install the latest stable release (macOS, Linux, or Windows via Git Bash):

— `01-getting-started.md`, líneas 11-14, seguida del comando `curl` de la tabla.

> On **Windows (PowerShell)**, use the native PowerShell installer:

— `01-getting-started.md`, líneas 23-26.

> The PowerShell installer automatically adds `%USERPROFILE%\.grok\bin` to your User PATH.

— `01-getting-started.md`, línea 35.

Detalles verificados:

- El instalador deja el binario en `~/.grok/bin` y pide añadirlo al `PATH` (`export PATH="$HOME/.grok/bin:$PATH"`),
  según la cabecera de <https://x.ai/cli/install.sh> (13-oct-2026).
- Variables del instalador: `GROK_CHANNEL` (`stable`, `alpha`, `enterprise`; por defecto `stable`), `GROK_BIN_DIR`.
- Actualizar: `grok update`. Si se instaló con WinGet: `winget upgrade --id xAI.GrokBuild -e`.
- Requisito de cuenta, según el anuncio oficial (<https://x.ai/news/grok-build-cli>, 25-may-2026): «Available now to
  all SuperGrok and X Premium Plus subscribers».

> **Sobre `curl | bash`:** ejecuta un script descargado. Es el método que publica xAI; el agente lo enseña tal cual,
> te pide OK y no lo ejecuta sin él. Si prefieres revisarlo antes, descárgalo, léelo y ejecútalo tú.

---

## 3. Comprobar e iniciar sesión

```bash
grok --version        # p. ej. «grok 1.0.52 (…) [stable]»
grok login            # abre el navegador y guarda la sesión en ~/.grok/auth.json
grok login --device-auth   # servidores sin navegador: código de dispositivo
python3 "$SKILL_DIR/scripts/grok_helper.py" salud
```

- `grok login` es **interactivo**: lo hace la persona en su terminal. El agente no teclea contraseñas ni toca
  `~/.grok/auth.json`.
- Fuente: `~/.grok/docs/user-guide/02-authentication.md`, líneas 30-38 («`--device-auth` (alias `--device-code`) | Sign in
  with the device-code flow for headless or remote environments.»).
- Las credenciales sin caducidad del servidor duran 30 días (misma guía, línea 15). Si `salud` vuelve a decir
  `MAL sesión`, repite `grok login`.
- `salud` comprueba la sesión con `grok models` dentro del HOME aislado: no gasta cuota.

---

## 4. Alta en OpenRouter (modo api)

1. Crea una cuenta y una clave en <https://openrouter.ai/settings/keys> y ponle un **límite de crédito** («Key limit»):
   es el límite del proveedor sobre el gasto y el skill no usa claves sin límite (salvo `--sin-limite-en-clave`).
2. Añade saldo. El skill nunca compra créditos ni activa recargas.
3. Dile a tu agente: «Guarda esta clave de OpenRouter para grok-search». La guarda en `~/.grok-search/claves.env`
   (permisos 600) con la línea `OPENROUTER_API_KEY=…`. Si tu agente puede leer el portapapeles, cópiala ahí en lugar de
   pegarla en el chat.
4. `salud` comprueba la clave contra `GET https://openrouter.ai/api/v1/key` (gratis) y muestra lo gastado y lo que queda.

Qué modelos buscan en X por OpenRouter (verificado el 13-oct-2026 en
<https://openrouter.ai/docs/guides/features/server-tools/web-search>):

> Opt in to X/Twitter search on SpaceXAI models, with optional filters. Only used with native provider search on
> SpaceXAI; ignored elsewhere

El skill envía `{"type": "openrouter:web_search", "parameters": {"engine": "native", "x_search": {…}}}` con un modelo
`x-ai/…`. Con otro proveedor no hay búsqueda en X.

---

## 5. Windows

- **Modo cli: no soportado.** El aislamiento depende de un enlace simbólico (`.grok`), que en Windows exige permisos
  especiales, y del bloqueo `fcntl`, que no existe allí. `salud` lo dice y `--modo auto` elige api.
- **Modo api: no probado en Windows.** Solo usa la biblioteca estándar de Python y HTTP, pero no se ha ejecutado en
  Windows. Rutas: `%USERPROFILE%\.grok-search\claves.env` y `%USERPROFILE%\.cache\grok-search\`.
- Si necesitas la CLI en Windows, usa WSL: el instalador de Linux funciona dentro de WSL («WSL users get the Linux
  binary automatically», `01-getting-started.md`, línea 35) y el skill la trata como Linux.

---

## 6. Qué hace y qué no hace el agente

| Hace | No hace |
|---|---|
| Muestra el comando oficial con su fuente y fecha | Instalar sin tu OK |
| Ejecuta la instalación si dices que sí y comprueba `grok --version` | Iniciar sesión por ti o leer `~/.grok/auth.json` |
| Guarda tu clave de OpenRouter en el fichero del skill | Repetir la clave en el chat o en un comando visible |
| Te ofrece el modo api si no quieres la CLI | Comprar créditos o activar recargas |

---

## 7. Errores frecuentes

| Síntoma | Causa | Arreglo |
|---|---|---|
| `grok: command not found` tras instalar | `~/.grok/bin` no está en el `PATH` | Abre otra terminal o añade la línea `export PATH=…` |
| `MAL sesión: Not signed in` | Sesión caducada o nunca iniciada | `grok login` |
| `No existe ~/.grok` | CLI recién instalada sin abrir | `grok login` |
| `MAL modo api: HTTP 401` | Clave revocada, de otra cuenta o mal copiada | Clave nueva |
| `MAL modo api: … NO tiene límite de crédito` | La clave no tiene «Key limit» | Pónselo en openrouter.ai/settings/keys |
| `SIN MODO` | Ni CLI con sesión ni clave | Este documento, §1 |
