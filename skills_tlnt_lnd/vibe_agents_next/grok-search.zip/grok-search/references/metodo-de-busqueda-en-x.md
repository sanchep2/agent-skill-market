# Método de búsqueda en X

Cómo plantear consultas que devuelvan posts útiles con poco gasto. Lo medido lleva fecha; lo demás es método.

## Table of Contents

1. [Qué herramientas usa Grok](#1-qué-herramientas-usa-grok)
2. [Escribir la consulta](#2-escribir-la-consulta)
3. [Ventanas de fecha](#3-ventanas-de-fecha)
4. [Cuentas e idiomas](#4-cuentas-e-idiomas)
5. [Hilos y cuentas](#5-hilos-y-cuentas)
6. [Cuánto pedir y cuándo parar](#6-cuánto-pedir-y-cuándo-parar)
   - [Barridos grandes](#6b-barridos-grandes-decenas-de-consultas)
7. [Errores típicos](#7-errores-típicos)

---

## 1. Qué herramientas usa Grok

Documentación oficial de xAI (<https://docs.x.ai/developers/tools/x-search>, «Last updated: October 10, 2026», consultada
el 13-oct-2026):

```text
| x_keyword_search  | Keyword search with X's advanced search operators, sorted by Top or Latest | Posts fetched    |
| x_semantic_search | Search by meaning rather than exact words                                  | Posts fetched    |
| x_user_search     | Find users by name or description                                          | Profiles fetched |
| x_thread_fetch    | Fetch one post with its parent posts and replies                           | Posts fetched    |
```

El modelo decide qué herramienta usar y cuántas veces. En el modo cli el skill registra las consultas reales que hizo
(campo `consultas_reales` de `resultado.json`): sirven para ver si Grok entendió el tema. Ejemplo real del 13-oct-2026:

```text
x_keyword_search  "grok build" (bug OR broken OR crash OR quota OR "weekly limit") since:2026-03-01  mode=Latest
x_semantic_search "Grok Build weekly quota SuperGrok usage limits coding agent CLI"
x_thread_fetch    {"post_id": "2107922648626033144"}
```

Grok escribe por su cuenta operadores de la búsqueda avanzada de X (`since:`, `from:`, `OR`). La documentación oficial no
los enumera; que funcionen `min_faves:` o `lang:` no está verificado. No los fuerces en el tema: describe lo que buscas
y deja que Grok componga la consulta.

---

## 2. Escribir la consulta

```text
BIEN  «local LLM inference speed on consumer GPUs, real tokens per second numbers»
BIEN  «experiencias reales automatizando tareas de una pequeña empresa con agentes de IA»
MAL   «("LLM" OR "model") AND (GPU OR "graphics card") AND (speed OR tok/s) since:2026-09-01»
MAL   «IA»  (demasiado amplio: devuelve ruido viral)
```

- Escribe el tema como lo diría quien publica, en su idioma.
- Pide lo que hace útil un post: «real numbers», «first-hand experience», «shipped», «after N months».
- Una consulta por pregunta. Para tres ángulos, tres `descubrir`.
- Observado el 13-oct-2026 en cinco búsquedas reales: la única que volvió vacía fue la que llevaba operadores `OR`
  en el tema; las escritas en lenguaje natural devolvieron posts. Es un indicio, no una medida.

---

## 3. Ventanas de fecha

| Parámetro | Efecto |
|---|---|
| `--desde YYYY-MM-DD` | Incluido. Va en el prompt y, en modo api, en `x_search.from_date` |
| `--hasta YYYY-MM-DD` | Excluido (como `to_date` de xAI: «up to, but not including») |
| `--horas N` | Solo las últimas N horas: corte exacto por la hora del ID, orden del más nuevo al más viejo, caché de 30 min |

- Las fechas de la ventana son días **UTC** (igual que `from_date` de xAI: «from 00:00 UTC»). Un post del 29 a las
  01:00 UTC sale en la entrega como el 28 por la tarde en América: está dentro de la ventana.
- El skill **vuelve a filtrar** por la fecha codificada en el ID de cada post: lo que Grok devuelva fuera de la ventana
  se descarta y se cuenta en `cobertura.descartes.fuera_de_ventana`.
- En modo api, los filtros de fecha y cuentas no se aplican a `x_thread_fetch` (documentación de xAI: «Thread fetches
  don't use them.»).
- Para «lo último»: `--horas 24` o `--horas 48`. Medido el 13-oct-2026 con juez ciego: 22 de 24 posts útiles en
  modo cli y 22 de 24 en modo api, todos dentro de la ventana (ver `limites-cuota-y-costes.md` §5). El prompt pide
  buscar en Latest y Top y elegir lo más sustancioso dentro de la ventana: sin esa instrucción, la api devolvía lo más
  nuevo aunque no aportara (12 de 24 útiles).
- Para tendencias, `--desde` con una semana o un mes. Ventanas largas diluyen la relevancia.
- En búsquedas de últimas horas, la caché dura 30 min: repetir la misma consulta una hora después vuelve a buscar.

---

## 4. Cuentas e idiomas

```bash
python3 "$H" --salida S descubrir "pricing changes" --de @cuenta1,@cuenta2
python3 "$H" --salida S descubrir "opiniones sobre el lanzamiento" --idioma español
```

- `--de` limita a esas cuentas (modo api: `allowed_x_handles`, máximo 20 según xAI).
- `--idioma` pide posts en ese idioma; sin él, cualquier idioma. El texto se entrega SIEMPRE en el idioma original.
  Si hace falta, la traducción va aparte y marcada.
- Idioma no es país: una consulta en español trae España, México, Argentina…; si el país importa, dilo en el tema y
  compruébalo en `quien_es` y en el texto.

---

## 5. Hilos y cuentas

- `hilo URL` lee el post y sus respuestas (`x_thread_fetch`). Úsalo para los posts con conversación que aporta: datos,
  objeciones, correcciones del autor. `x_thread_fetch` devuelve pocas respuestas (medido: 2 de 23), así que el skill
  pide además una búsqueda `conversation_id:<id>`: con ella se leyeron 8 de 23. La cobertura dice «respuestas leídas N
  de M declaradas»; nunca promete el hilo completo.
- `lote resultado.json --top N` lee los hilos de los N posts con más interacción de una búsqueda.
- `cuentas "tema"` devuelve quién habla del tema, con un post representativo y la descripción del perfil. Sirve para
  armar luego `--de` con las cuentas buenas.

---

## 6. Cuánto pedir y cuándo parar

```text
--n 5-10 por consulta ─► triage ─► ¿hay 3+ posts útiles de autores distintos? ── sí ──► hilo/lote de los mejores
                                         │ no
                                         ▼
                            reformular (más concreto, otro idioma, otra ventana) ── 2 intentos sin mejora ──► PARAR
```

- Parar cuando las nuevas consultas solo repiten autores y posts ya vistos.
- No hagas barridos de decenas de temas sin necesidad: cada búsqueda consume cuota (cli) o dinero (api).
- Si dos consultas seguidas devuelven 0 posts válidos, revisa `consultas_reales` y la ventana antes de repetir.

---

## 6b. Barridos grandes (decenas de consultas)

Patrón medido el 13-oct-2026 en un barrido real (43 búsquedas + 12 hilos, 464 posts únicos; 15 de 15 al azar
coincidieron en texto y autor con el oEmbed):

```text
RECOLECTOR (modelo ligero)  → prepara 40-60 consultas variadas (varios idiomas), las lanza con el skill
                              (3-4 a la vez), hace `hilo` de los 10-15 posts con más evidencia y lo vuelca LITERAL
                              a un fichero deduplicado por URL. No interpreta ni concluye.
ANALISTA (modelo fuerte)    → lee el volcado, selecciona, contrasta con otras fuentes y escribe el informe.
VERIFICADOR (modelo fuerte) → `citas --verificar` y revisión adversarial por muestreo.
```

- Recolectar con un modelo caro sale mal: en la misma prueba, cuatro agentes de modelo fuerte pasaron el tiempo
  esperando turno y consultando la cola, gastando sin aportar.
- Una cola por tarea: `GROK_SEARCH_LOCKS` apuntando a una carpeta propia. Si dos tareas comparten cola, una no
  consigue turno y sus tiempos salen mal medidos.
- Si vigilas el progreso, que el aviso llegue al terminar la cola o ante un error, no por cada búsqueda.
- Para parar procesos, por su PID, nunca con patrones amplios (`pkill -f grok` mata los de otras tareas).
- En macOS, `xargs` no tiene `-d`: `tr '\n' '\0' < consultas.txt | xargs -0 -P 3 -I{} python3 "$H" --salida S descubrir "{}"`.

---

## 7. Errores típicos

1. **Confundir volumen con relevancia**: un post con un millón de vistas puede no responder a la pregunta.
2. **Un solo autor domina el resultado**: pide «different authors» en el tema o usa `cuentas` y luego `--de`.
3. **Bots y cuentas de reacción** (incluidas las respuestas automáticas de asistentes): no son testimonios; ver
   `entrega-y-credibilidad.md`.
4. **Citar sin verificar**: todo lo que se entrega pasa por `citas --verificar`.
5. **Pedir cifras a Grok y no al post**: los números valen si están en el texto literal del post, no en las notas del
   modelo.
