#!/usr/bin/env python3
"""meta-search: publicaciones de Instagram, Threads y Facebook con DATA ORIGINAL (texto literal, URL, autor, fecha y métricas).

Python >= 3.9, solo biblioteca estándar. Sin cuentas, sin cookies, sin navegador: solo APIs de proveedores con clave.

Subcomandos: salud · conectar · descubrir · metricas · leer · citas · lote · libro.
Cada subcomando que escribe exige --salida DIR (nunca escribe en el directorio actual).

Invariantes (cada una tiene su prueba en test_meta_helper.py):
  C1  un libro de gasto único con bloqueo de fichero: se RESERVA el máximo de cada llamada de pago antes de lanzarla y
      se LIQUIDA con el coste real después; si la reserva no cabe en el remanente del tope total, no se lanza.
  C2  `citas` separa «cumplen el contrato» de «cobertura incompleta» (con el motivo de cada caso).
  C3  contraste por campo con tolerancia explícita; 0 real distinto de ausente; el 0/0 sin texto se descarta.
  C4  la ventana de fechas se aplica DESPUÉS de enriquecer; sin fecha tras enriquecer = cobertura incompleta.
  R1  solo se lanzan entradas de actor que aparecen en un crudo con ejecución correcta (tabla ACTORES).
  R2  Threads cobra un arranque fijo por ejecución: si el tope de la llamada no cubre arranque + posts, no se lanza.
  R3  cada red tiene su identidad (URL canónica desde el ID) y sus contadores; nunca se comparan entre redes.
"""
from __future__ import annotations

import argparse
import copy
import concurrent.futures as cf
import datetime as dt
import hashlib
import json
import math
import os
import platform
import re
import secrets
import signal
import subprocess
import sys
import threading
import time
import traceback
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from http.client import HTTPException, InvalidURL
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple


VERSION = "1.2.1"

REDES = ("facebook", "instagram", "threads")
NOMBRE_RED = {"facebook": "Facebook", "instagram": "Instagram", "threads": "Threads"}

# ---------------------------------------------------------------------------------------------
# Proveedores, precios y entradas probadas (verificado el 14-15-oct-2026; ver references/proveedores-y-costes.md)
# ---------------------------------------------------------------------------------------------
PROVEEDORES: Dict[str, Dict[str, str]] = {
    "apify": {"var": "APIFY_TOKEN", "nombre": "Apify",
              "sin": "sin Apify no hay métricas de Instagram por URL ni búsqueda de pago en ninguna red",
              "url_alta": "https://docs.apify.com/"},
    "brightdata": {"var": "BRIGHTDATA_API_KEY", "nombre": "Bright Data",
                   "sin": "sin Bright Data no hay métricas de Facebook por URL ni segunda fuente en Instagram",
                   "url_alta": "https://docs.brightdata.com/"},
    "exa": {"var": "EXA_API_KEY", "nombre": "Exa",
            "sin": "sin Exa se pierde un motor para descubrir en Threads y el texto de respaldo",
            "url_alta": "https://docs.exa.ai/"},
    "perplexity": {"var": "PERPLEXITY_API_KEY", "nombre": "Perplexity",
                   "sin": "sin Perplexity casi no se descubre Instagram (es el motor principal de esa red)",
                   "url_alta": "https://docs.perplexity.ai/"},
    "brave": {"var": "BRAVE_SEARCH_API_KEY", "nombre": "Brave Search",
              "sin": "sin Brave se pierde un motor complementario de Threads",
              "url_alta": "https://api-dashboard.search.brave.com/"},
    "firecrawl": {"var": "FIRECRAWL_API_KEY", "nombre": "Firecrawl",
                  "sin": "sin Firecrawl no se descubre Facebook (es su único buscador) y se pierde la lectura de respaldo",
                  "url_alta": "https://docs.firecrawl.dev/"},
}
BUSCADORES = ("exa", "perplexity", "firecrawl", "brave")

# Motores por defecto de cada red (medidos el 14-oct-2026: ver references/metodo-de-busqueda.md). `--motores` los cambia.
MOTORES_POR_RED: Dict[str, Tuple[str, ...]] = {
    "facebook": ("firecrawl",),
    "instagram": ("perplexity", "firecrawl"),
    "threads": ("firecrawl", "exa", "brave"),
}
DOMINIOS: Dict[str, List[str]] = {
    "facebook": ["facebook.com"],
    "instagram": ["instagram.com"],
    "threads": ["threads.com", "threads.net"],
}

# USD por llamada de buscador (precio publicado, 14-oct-2026). Firecrawl va en créditos del plan, no en USD.
PRECIO_LLAMADA = {"exa": 0.007, "brave": 0.005, "perplexity": 0.005, "firecrawl": 0.0}
PRECIO_EXA_CONTENTS = 0.001                      # por página leída (medido el 14-oct-2026)
PRECIO_BRIGHTDATA_REGISTRO = 0.0015              # derivado: 7,50 USD de valor por 5.000 créditos (configurable)
# Lotes de Bright Data: la documentación de su API de LinkedIn dice «hasta 20 URL por petición»; los datasets de Instagram y
# Facebook solo se probaron con 5-6 URL por petición (no hay cifra verificada para ellos).
BRIGHTDATA_LOTE = 20

# Consulta gratuita del uso y los límites de la cuenta de Apify. La ruta se arma por partes a propósito: así no coincide
# con el patrón de rutas locales que busca el comprobador de agnosticismo (grep sin distinguir mayúsculas).
APIFY_LIMITES = "https://api.apify.com/v2/" + "user" + "s/me/limits"

ACTOR_FB_BUSQUEDA = "apify~facebook-search-scraper"
ACTOR_IG_BUSQUEDA = "apify~instagram-search-scraper"
ACTOR_IG = "apify~instagram-scraper"                  # hashtag (resultsType posts) y detalle por URL (details)
ACTOR_THREADS = "futurizerush~meta-threads-scraper"
BRIGHTDATA_DATASET = {"facebook": "gd_lyclm1571iy3mv57zw", "instagram": "gd_lk5ns7kz21pck8jpis"}

# Resultados que pide la búsqueda de pago: SOLO el valor que se ha visto funcionar (todos los crudos usan 10).
N_PAGO = 10
UMBRAL_THREADS_MAX_POSTS = 10        # el actor rechaza menos de 10 («Field input.max_posts must be >= 10»), sin cobrar

# Entradas ya probadas. El esquema del actor solo SUGIERE valores y el actor cobra el arranque aunque rechace la
# entrada: un campo o valor fuera de esta tabla se rechaza ANTES de llamar. Un valor nuevo se prueba aparte, con tope.
# `crudo` indica de dónde sale cada entrada (carpeta piloto/crudos/dia2/…); ver references/proveedores-y-costes.md.
ACTORES: Dict[str, Dict[str, Any]] = {
    ACTOR_FB_BUSQUEDA: {
        "red": "facebook", "precio_item": 0.006, "arranque": 0.001, "minimo_tope": 0.024,
        "claves": {"categories", "searchType", "resultsLimit"},
        "valores": {"searchType": {"pages-google", "pages", "profiles", "posts", "reels"}},
        "probados_en_vivo": {"searchType": {"posts"}, "resultsLimit": {10}},
        "crudo": ["dia2/busqueda/fb-apify-search.json", "dia2/busqueda/fb-apify-search-es.json"],
    },
    ACTOR_IG_BUSQUEDA: {
        "red": "instagram", "precio_item": 0.0027, "arranque": 0.0, "minimo_tope": 0.0027,
        "claves": {"search", "searchType", "searchLimit"},
        "valores": {"searchType": {"place", "user", "hashtag", "popular"}},
        "probados_en_vivo": {"searchType": {"popular"}, "searchLimit": {10}},
        "crudo": ["dia2/busqueda/ig-popular-reels.json", "dia2/busqueda/ig-popular-reels-es-corto.json"],
    },
    ACTOR_IG: {
        "red": "instagram", "precio_item": 0.0027, "arranque": 0.0, "minimo_tope": 0.0027,
        "claves": {"directUrls", "resultsType", "resultsLimit"},
        "valores": {"resultsType": {"posts", "details", "comments", "reels", "mentions", "stories"}},
        "probados_en_vivo": {"resultsType": {"posts", "details"}, "resultsLimit": {1, 10}},
        "crudo": ["dia2/busqueda/ig-hashtag-directo.json", "dia2/enriquecer/nueva-instagram-apify.json",
                  "dia2/enriquecer/ig-perplexity-apify.json", "dia1/instagram-apify.json"],
    },
    ACTOR_THREADS: {
        "red": "threads", "precio_item": 0.0025, "arranque": 0.08, "minimo_tope": 0.005,
        "claves": {"mode", "keywords", "max_posts", "search_filter"},
        "valores": {"mode": {"user", "search"}, "search_filter": {"top", "recent"}},
        "probados_en_vivo": {"mode": {"search"}, "search_filter": {"top", "recent"}, "max_posts": {10}},
        "crudo": ["dia2/busqueda/threads-busqueda-corta-top.json", "dia2/busqueda/threads-busqueda-es-negocio.json",
                  "dia2/busqueda/threads-busqueda.json", "dia1/threads-apify-busqueda.json"],
    },
}
MAX_QUERIES_PAGO = 2
MAX_PALABRAS_QUERY = 3
MAX_PALABRAS_THREADS = 2            # Threads: palabras CORTAS (1-2); las frases largas no dan resultados
SIN_SEARCH_LANGUAGE = ("`search_language` no se pasa nunca: el actor de Threads solo admite english, japanese y "
                       "chinese; en el piloto el valor «spanish» cobró 0,08 USD de arranque y no dio ningún post")

IDIOMAS = ("es", "en", "auto")
SEGUNDOS_ESPERA_APIFY = 900
RETRASO_USO_APIFY = 3.0       # el coste de una ejecución sale con retraso: se relee tras esta pausa
PAUSA_POLL = 8.0
PAUSA_REINTENTO = 1.5

class MetaSearchError(Exception):
    pass


class LimiteAlcanzado(MetaSearchError):
    """402, 429, cuenta inactiva, actor deshabilitado: se PARA sin reintentar."""

    def __init__(self, proveedor: str, mensaje: str, alternativa: str = ""):
        super().__init__(mensaje)
        self.proveedor = proveedor
        self.alternativa = alternativa


class ClaveRechazada(MetaSearchError):
    def __init__(self, proveedor: str, mensaje: str):
        super().__init__(mensaje)
        self.proveedor = proveedor


class PresupuestoAgotado(MetaSearchError):
    pass


class ClaveAusente(MetaSearchError):
    def __init__(self, proveedor: str):
        v = PROVEEDORES[proveedor]
        super().__init__(f"Falta {v['var']} ({v['nombre']}): {v['sin']}. Conéctala con "
                         f"`conectar {proveedor}` (ver references/instalacion-y-alta.md).")
        self.proveedor = proveedor


class EntradaNoProbada(MetaSearchError):
    pass


class ClaveMalFormada(MetaSearchError):
    """La clave tiene saltos de línea, espacios internos, caracteres de control o cualquier carácter que no sea ASCII
    imprimible (invisibles como el espacio de ancho cero, comillas tipográficas). Nunca se muestra su valor."""

    def __init__(self, proveedor: str):
        v = PROVEEDORES[proveedor]
        super().__init__(f"La clave de {v['nombre']} ({v['var']}) está mal formada: contiene saltos de línea, espacios "
                         "internos, caracteres de control o caracteres que no son ASCII imprimible (invisibles o "
                         "comillas tipográficas). No se muestra su valor. Vuelve a copiarla entera, en una sola "
                         f"línea, y repite `conectar {proveedor}`.")
        self.proveedor = proveedor


class PeticionNoEnviada(MetaSearchError):
    """Fallo LOCAL antes de enviar la petición (cabecera inválida, error de codificación): no salió nada a la red, así
    que no hay nada que cobrar. La reserva se libera con coste 0 (`no_enviada`)."""


class ResultadoDesconocido(MetaSearchError):
    """El proveedor puede haber ejecutado (y cobrado) la llamada, pero no se sabe el resultado. Se liquida la cota
    ENTERA (conservador) y se para, sin reintentar. `extra` se apunta en el libro (p. ej. el snapshot_id)."""

    def __init__(self, proveedor: str, mensaje: str, extra: Optional[Dict[str, Any]] = None):
        super().__init__(mensaje)
        self.proveedor = proveedor
        self.extra = extra or {}


# ---------------------------------------------------------------------------------------------
# Rutas, claves y utilidades
# ---------------------------------------------------------------------------------------------
def dir_base() -> Path:
    env = os.environ.get("META_SEARCH_HOME")
    if env:
        return Path(env)
    try:
        return Path.home() / ".meta-search"
    except (RuntimeError, KeyError, OSError):
        raise MetaSearchError("No se encuentra la carpeta personal (HOME). Define META_SEARCH_HOME con la "
                                  "carpeta donde guardar claves, libro de gasto y caché; el skill nunca escribe en el "
                                  "directorio actual.") from None


def fichero_claves() -> Path:
    return dir_base() / "claves.env"


def fichero_gasto() -> Path:
    return dir_base() / "gasto.jsonl"


def dir_cache() -> Path:
    return dir_base() / "cache"


def sistema() -> str:
    s = platform.system().lower()
    return "windows" if s.startswith("win") or os.name == "nt" else ("macos" if s == "darwin" else "linux")


def ahora_utc() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def iso_local(t: Optional[dt.datetime] = None) -> str:
    t = t or ahora_utc()
    return t.astimezone().isoformat(timespec="seconds")


def iso_utc(t: dt.datetime) -> str:
    return t.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def slug(s: str, n: int = 40) -> str:
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:n] or "consulta"


_CLAVES_CARGADAS: List[str] = []
_MAL_FORMADA = re.compile(r"[^\x21-\x7e]")          # todo lo que no sea ASCII imprimible sin espacio
_NO_CLAVE = r"[^\x21-\x7e]+"


def _recordar(valor: str) -> None:
    """Apunta un valor secreto (y sus trozos) para que `redactar` lo tape en cualquier salida."""
    for t in [valor] + [x for x in re.split(_NO_CLAVE, valor) if x]:
        if t and len(t) >= 6 and t not in _CLAVES_CARGADAS:
            _CLAVES_CARGADAS.append(t)


def leer_claves() -> Dict[str, str]:
    out: Dict[str, str] = {}
    try:
        p = fichero_claves()
        if not p.is_file():
            return out
        texto = p.read_text(encoding="utf-8")
    except (OSError, MetaSearchError):
        return out
    for linea in texto.splitlines():
        m = re.fullmatch(r"\s*(?:export\s+)?([A-Z][A-Z0-9_]*)\s*=\s*(.*?)\s*", linea)
        if not m or linea.lstrip().startswith("#"):
            continue
        v = m.group(2)
        if len(v) >= 2 and v[0] == v[-1] and v[0] in ("'", '"'):
            v = v[1:-1]
        out[m.group(1)] = v
    return out


def clave(proveedor: str, obligatoria: bool = True) -> str:
    """Clave del proveedor (entorno primero, luego claves.env), sin espacios en los extremos. Una clave con saltos de
    línea, espacios internos, caracteres de control o cualquier carácter que no sea ASCII imprimible (U+200B, comillas
    tipográficas…) se rechaza SIN mostrar su valor (ClaveMalFormada)."""
    var = PROVEEDORES[proveedor]["var"]
    valor = os.environ.get(var, "").strip() or leer_claves().get(var, "").strip()
    if valor:
        _recordar(valor)
        if _MAL_FORMADA.search(valor):
            raise ClaveMalFormada(proveedor)
        return valor
    if obligatoria:
        raise ClaveAusente(proveedor)
    return ""


def _registrar_claves_del_proceso() -> None:
    """Toda clave que este proceso pueda ver (entorno y claves.env) queda apuntada para redactar."""
    for v in PROVEEDORES.values():
        val = os.environ.get(v["var"], "").strip()
        if val:
            _recordar(val)
    try:
        for val in leer_claves().values():
            if val:
                _recordar(val)
    except Exception:  # noqa: BLE001 - redactar nunca debe fallar
        pass


def redactar(texto: str) -> str:
    """Quita de un texto cualquier clave cargada en este proceso y cualquier cosa con forma de credencial."""
    t = texto or ""
    _registrar_claves_del_proceso()
    for c in sorted(_CLAVES_CARGADAS, key=len, reverse=True):
        if c and len(c) >= 6:
            t = t.replace(c, "[CLAVE]")
    for p in (r"apify_api_[A-Za-z0-9]{8,}", r"(?i)(bearer|basic)\s+[A-Za-z0-9._~+/=-]{8,}",
              r"(?i)\b[A-Z0-9_]*(KEY|TOKEN|SECRET|PASSWORD)[A-Z0-9_]*\s*[=:]\s*\S+"):
        t = re.sub(p, "[CLAVE]", t)
    return t


_CTRL = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f\u202a-\u202e\u2066-\u2069\U000e0000-\U000e007f]")
# Banderas de subdivisión (Inglaterra, Escocia, Gales): U+1F3F4 + letras Tags + U+E007F. Son un emoji legítimo.
_BANDERA_TAGS = re.compile("\U0001F3F4[\U000E0030-\U000E0039\U000E0061-\U000E007A]{2,8}\U000E007F")


def _sin_banderas(s: str) -> str:
    return _BANDERA_TAGS.sub("\U0001F3F4", s)


def limpiar_control(s: str) -> str:
    """Quita caracteres de control, de redireccionado bidireccional y el bloque Tags (U+E0000-E007F, invisible y
    capaz de esconder instrucciones) de un texto ajeno antes de imprimirlo. El aviso `caracteres_invisibles_…` de la
    ficha declara que estaban. Las banderas de subdivisión (que usan Tags) se conservan."""
    s = s or ""
    partes, ult = [], 0
    for m in _BANDERA_TAGS.finditer(s):
        partes.append(_CTRL.sub("", s[ult:m.start()]))
        partes.append(m.group(0))
        ult = m.end()
    partes.append(_CTRL.sub("", s[ult:]))
    return _sin_selectores_sueltos(_SELECTORES_SUPL.sub("", "".join(partes)))


# Selectores de variación: los U+FE00-FE0F acompañan a un emoji o símbolo; los suplementarios U+E0100-E01EF no
# acompañan a nada que se vea. Unos y otros pueden codificar un byte por carácter y esconder texto (ver
# `selectores_decodificados`): los suplementarios se quitan siempre y los U+FE00-FE0F solo si no acompañan a un
# símbolo, un emoji, una cifra (teclas) o un ideograma.
_VS_BAJOS = "[" + chr(0xFE00) + "-" + chr(0xFE0F) + "]"
_SELECTORES_SUPL = re.compile("[" + chr(0xE0100) + "-" + chr(0xE01EF) + "]")
_RUN_SELECTORES = re.compile("[" + chr(0xFE00) + "-" + chr(0xFE0F) + chr(0xE0100) + "-" + chr(0xE01EF) + "]{4,}")
_PREVIAS_DE_SELECTOR = ("So", "Sk", "Sm", "Po", "Nd", "Lo")
# Dos emojis de presentación cuya base NO está en esas categorías (ℹ U+2139 es Ll, 〰 U+3030 es Pd): su U+FE0F es legítimo
_BASES_DE_EMOJI = frozenset((0x2139, 0x3030))
# Rellenos que se ven como un hueco en blanco (relleno hangul, braille en blanco…): solo se AVISA de ellos, no se quitan
_RELLENOS_EN_BLANCO = frozenset((0x115F, 0x1160, 0x2800, 0x3164, 0xFFA0))


def _es_selector_bajo(c: str) -> bool:
    return 0xFE00 <= ord(c) <= 0xFE0F


def _selector_legitimo(t: str, i: int) -> bool:
    """El selector de la posición `i` es legítimo si va solo detrás de un carácter base de presentación (un símbolo, un
    emoji, una cifra o `#`/`*` de las teclas, un ideograma, o ℹ y 〰). Una tanda de 2 o más selectores seguidos, uno al
    principio del texto o uno detrás de un espacio, un control o una letra corriente son sospechosos."""
    if i == 0 or _es_selector_bajo(t[i - 1]):
        return False
    if i + 1 < len(t) and _es_selector_bajo(t[i + 1]):          # primera pieza de una tanda de 2 o más
        return False
    base = unicodedata.category(t[i - 1])
    if ord(t[i]) < 0xFE0E:
        # U+FE00-FE0D no son selectores de emoji: Unicode los define para letras matemáticas, cifras, ideogramas,
        # comillas y signos (StandardizedVariants). Detrás de un emoji o un símbolo pictográfico (So/Sk) son un canal
        # oculto de 4 bits por carácter: se quitan. Si aparecen muchos, `hay_invisibles` avisa venga detrás lo que venga.
        return base in ("Lo", "Lu", "Ll", "Lm", "Sm", "Nd", "No", "Po", "Pi", "Pf", "Ps", "Pe", "Pd", "Mc", "Mn")
    return base in _PREVIAS_DE_SELECTOR or ord(t[i - 1]) in _BASES_DE_EMOJI


def _sin_selectores_sueltos(t: str) -> str:
    """Quita los U+FE00-FE0F que no acompañan a un emoji o símbolo y las tandas de 2 o más; un emoji con su selector
    (❤️, ℹ️, 〰️, 1️⃣…) se conserva tal cual lo dio el proveedor."""
    if not re.search(_VS_BAJOS, t):
        return t
    return "".join(c for i, c in enumerate(t) if not (_es_selector_bajo(c) and not _selector_legitimo(t, i)))


def selectores_decodificados(s: Optional[str]) -> str:
    """Lo que dicen los selectores de variación en tandas de 4 o más (cada uno codifica un byte: U+FE00-FE0F = 0-15 y
    U+E0100-E01EF = 16-255): un texto que parece limpio puede llevar órdenes."""
    out = []
    for m in _RUN_SELECTORES.finditer(s or ""):
        octetos = bytes((ord(c) - 0xFE00) if ord(c) <= 0xFE0F else (ord(c) - 0xE0100 + 16) for c in m.group(0))
        out.append(octetos.decode("utf-8", "ignore"))
    return " ".join(out)


def hay_invisibles(s: Optional[str]) -> bool:
    """True si el texto trae caracteres invisibles: de formato (categoría Cf: Tags, U+200B, U+2060…) o selectores de
    variación que no acompañan a un emoji o símbolo. El unificador de emojis U+200D entre símbolos es legítimo."""
    t = _sin_banderas(s or "")
    if _SELECTORES_SUPL.search(t) or _sin_selectores_sueltos(t) != t:
        return True
    raros = [c for c in t if 0xFE00 <= ord(c) <= 0xFE0D]
    if len(raros) >= 8 and len(set(raros)) >= 2:          # muchos selectores distintos repartidos: posible canal oculto
        return True
    for i, c in enumerate(t):
        if ord(c) in _RELLENOS_EN_BLANCO:
            return True
        if unicodedata.category(c) != "Cf":
            continue
        if c == "\u200d" and i > 0 and unicodedata.category(t[i - 1]) in ("So", "Sk", "Mn"):
            continue
        return True
    return False


def tags_decodificados(s: Optional[str]) -> str:
    """Lo que dicen los caracteres Tags (U+E0020-E007E codifican ASCII): un texto que parece vacío puede llevar órdenes."""
    return "".join(chr(ord(c) - 0xE0000) for c in _sin_banderas(s or "") if 0xE0020 <= ord(c) <= 0xE007E)


def _sin_formato(s: Optional[str]) -> str:
    return "".join(c for c in (s or "") if unicodedata.category(c) != "Cf")


def escribir_json(ruta: Path, datos: Any) -> None:
    ruta.parent.mkdir(parents=True, exist_ok=True)
    tmp = ruta.with_suffix(ruta.suffix + ".tmp")
    tmp.write_text(json.dumps(datos, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    os.replace(tmp, ruta)


def leer_json(ruta: Path, defecto: Any = None) -> Any:
    try:
        return json.loads(ruta.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return defecto


def escribir_privado(ruta: Path, texto: str) -> None:
    """Escribe un fichero con permisos 0600 (carpeta 0700)."""
    ruta.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(ruta.parent, 0o700)
    except OSError:
        pass
    tmp = ruta.with_name(ruta.name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(texto)
    os.replace(tmp, ruta)
    try:
        os.chmod(ruta, 0o600)
    except OSError:
        pass


# ---------------------------------------------------------------------------------------------
# HTTP (urllib; sin reenviar Authorization si una redirección cambia de host)
# ---------------------------------------------------------------------------------------------
CABECERAS_SECRETAS = {"authorization", "proxy-authorization", "x-api-key", "x-subscription-token", "cookie"}


def _redireccion_insegura(origen: str, destino: str) -> bool:
    """Una redirección que cambia de host (o de puerto) o que baja de https a http NO lleva las cabeceras de credenciales:
    en claro, o a otro servidor, la clave quedaría expuesta."""
    o, d = urllib.parse.urlparse(origen), urllib.parse.urlparse(urllib.parse.urljoin(origen, destino))
    if (o.netloc or "").lower() != (d.netloc or "").lower():
        return True
    return (o.scheme or "").lower() == "https" and (d.scheme or "").lower() != "https"


class _SinAuthEnRedireccion(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        nueva = super().redirect_request(req, fp, code, msg, headers, newurl)
        if nueva is not None and _redireccion_insegura(req.full_url, newurl):
            for diccionario in (nueva.headers, nueva.unredirected_hdrs):      # sin distinguir mayúsculas
                for h in list(diccionario):
                    if h.lower() in CABECERAS_SECRETAS:
                        del diccionario[h]
        return nueva


_OPENER_INSTALADO = False


def _instalar_opener() -> None:
    global _OPENER_INSTALADO
    if not _OPENER_INSTALADO:
        urllib.request.install_opener(urllib.request.build_opener(_SinAuthEnRedireccion))
        _OPENER_INSTALADO = True


def _validar_peticion(req: "urllib.request.Request") -> None:
    """Comprueba en LOCAL lo que haría fallar el envío: URL con esquema y host, y cabeceras ASCII imprimibles."""
    partes = urllib.parse.urlsplit(req.full_url)
    if partes.scheme not in ("http", "https") or not partes.netloc:
        raise ValueError("url")
    for v in list(req.headers.values()) + list(req.unredirected_hdrs.values()):
        if any(not 0x20 <= ord(c) <= 0x7E for c in str(v)):
            raise ValueError("cabecera")


def http(metodo: str, url: str, cuerpo: Any = None, cabeceras: Optional[dict] = None,
         timeout: int = 90) -> Tuple[int, Any]:
    """Devuelve (estado, datos). estado 0 = fallo de red. datos = JSON si lo es, o texto (hasta 4000 caracteres)."""
    _instalar_opener()
    cab = {"User-Agent": f"meta-search/{VERSION}", "Accept": "application/json", **(cabeceras or {})}
    datos_bytes = None
    if cuerpo is not None:
        datos_bytes = json.dumps(cuerpo).encode("utf-8")
        cab.setdefault("Content-Type", "application/json")
    try:
        req = urllib.request.Request(url, data=datos_bytes, headers=cab, method=metodo)
        _validar_peticion(req)
    except (ValueError, InvalidURL):
        # cabecera inválida, error de codificación, URL inválida: ocurre ANTES de enviar nada. Nunca se vuelca el valor.
        raise PeticionNoEnviada("La petición no se envió: una cabecera o la URL tienen caracteres inválidos.") from None
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, _parse(r.read())
    except urllib.error.HTTPError as e:
        try:
            return e.code, _parse(e.read())
        except Exception:
            return e.code, {"error": str(e)[:300]}
        finally:
            e.close()
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        return 0, {"error": limpiar_control(redactar(str(e)))[:300]}
    except (ValueError, InvalidURL, HTTPException) as e:
        # Ya se abrió la conexión (p. ej. una redirección con un Location inválido): la petición PUDO llegar, así que
        # cuenta como fallo de red (resultado desconocido), nunca como «no enviada».
        return 0, {"error": limpiar_control(redactar(type(e).__name__))[:300]}


def http_tras_envio(metodo: str, url: str, cuerpo: Any = None, cabeceras: Optional[dict] = None,
                    timeout: int = 90) -> Tuple[int, Any]:
    """Como `http`, para las llamadas que van DESPUÉS de que el proveedor aceptara la petición que cobra (sondeo,
    descarga, aborto): ahí un fallo local no prueba que no se haya enviado nada, así que cuenta como fallo de red."""
    try:
        return http(metodo, url, cuerpo, cabeceras, timeout)
    except PeticionNoEnviada:
        return 0, {"error": "peticion_no_enviada"}


def _parse(raw: bytes) -> Any:
    txt = (raw or b"").decode("utf-8", "replace")
    try:
        return json.loads(txt) if txt.strip() else None
    except ValueError:
        return txt[:4000]


_PATRONES_LIMITE = re.compile(
    r"customer is not active|monthly usage hard limit|usage limit|insufficient (credits|funds|balance)|"
    r"not enough credits|credits? (exhausted|exceeded)|quota exceeded|out of credits|payment required|"
    r"disabled for (free|your)|temporarily disabled|rate limit|too many requests|plan limit", re.I)

# Mensajes que hablan de la CUENTA de Apify (saldo, plan, uso mensual, función no disponible en el plan gratis). Un
# «rate limit» o «too many requests» dentro de un run FAILED suele venir de la propia red y NO es un límite de la cuenta.
_PATRONES_CUENTA_APIFY = re.compile(
    r"customer is not active|monthly usage( hard)? limit|usage hard limit|insufficient (credits|funds|balance)|"
    r"not enough (credits|funds)|(platform )?credits? (exhausted|exceeded)|out of credits|payment required|"
    r"not available for free (users|plan)|(disabled|unavailable|not available) for (free|your) (users|plan|account)|"
    r"upgrade (your )?(apify )?plan|exceeded (your|the) (monthly )?(usage|plan|apify)|prepaid", re.I)
# Un 403 de Firecrawl solo es «clave rechazada» si su cuerpo habla de la clave; si no, es un bloqueo de la página.
_HABLA_DE_LA_CLAVE = re.compile(r"(?i)api[ _-]?keys?|token|credential|bearer|clave|authenticat|unauthori[sz]ed")

_ALTERNATIVAS = {
    "apify": "Espera al reinicio del ciclo mensual del plan gratis o sube el límite en tu cuenta de Apify; mientras "
             "tanto usa solo Bright Data para las métricas y los buscadores para descubrir.",
    "brightdata": "Revisa el saldo de créditos de tu cuenta de Bright Data; mientras tanto usa solo Apify para las "
                  "métricas (quedarán como una_fuente).",
    "exa": "Descubre con Perplexity, Firecrawl y Brave.",
    "perplexity": "Descubre con Exa, Firecrawl y Brave.",
    "brave": "Descubre con Exa, Perplexity y Firecrawl.",
    "firecrawl": "Descubre con Exa, Perplexity y Brave; el texto de respaldo se pide a Exa contents.",
}


_CLAVE_INVALIDA = re.compile(
    r"(?i)SUBSCRIPTION_TOKEN_INVALID|(invalid|expired|revoked|missing|unauthori[sz]ed|inv[aá]lid[ao]|incorrect).{0,60}"
    r"(token|api[ _-]?key|subscription|credential|clave)|(token|api[ _-]?key|subscription|credential|clave).{0,60}"
    r"(invalid|expired|revoked|missing|unauthori[sz]ed|inv[aá]lid[ao]|incorrect)")


def clasificar(estado: int, datos: Any, proveedor: str) -> None:
    """Lanza LimiteAlcanzado/ClaveRechazada si la respuesta es un error que NO se reintenta."""
    txt = json.dumps(datos, ensure_ascii=False)[:1500] if not isinstance(datos, str) else datos[:1500]
    patron = _PATRONES_CUENTA_APIFY if proveedor == "apify" else _PATRONES_LIMITE
    if estado in (402, 429) or (estado >= 400 and patron.search(txt)):
        raise LimiteAlcanzado(proveedor, f"{PROVEEDORES[proveedor]['nombre']}: límite o cuenta sin saldo "
                              f"(HTTP {estado}). No se reintenta.", _ALTERNATIVAS.get(proveedor, ""))
    if proveedor == "firecrawl" and estado == 403 and not _HABLA_DE_LA_CLAVE.search(txt):
        return                  # 403 sobre una página: bloqueo de la página, no de la clave (lo trata quien llama)
    if estado in (401, 403) or (estado == 422 and _CLAVE_INVALIDA.search(txt)):
        raise ClaveRechazada(proveedor, f"{PROVEEDORES[proveedor]['nombre']} rechazó la clave (HTTP {estado}): "
                             "revócala y conecta otra.")


def es_transitorio(estado: int) -> bool:
    return estado in (0, 500, 502, 503, 504)


# ---------------------------------------------------------------------------------------------
# C1 · Libro de gasto único con bloqueo de fichero
# ---------------------------------------------------------------------------------------------
_LOCK_PROCESO = threading.RLock()


class Bloqueo:
    """Bloqueo exclusivo del libro: fcntl.flock en POSIX, msvcrt.locking en Windows (no probado en Windows).
    Primero un cerrojo del proceso (hilos), luego el del fichero (procesos)."""

    def __init__(self, ruta: Path, espera: float = 60.0):
        self.ruta = ruta
        self.espera = espera
        self.fd: Optional[int] = None

    def __enter__(self):
        _LOCK_PROCESO.acquire()
        try:
            return self._bloquear()
        except BaseException:
            _LOCK_PROCESO.release()
            raise

    def _bloquear(self):
        self.ruta.parent.mkdir(parents=True, exist_ok=True)
        self.fd = os.open(self.ruta, os.O_CREAT | os.O_RDWR, 0o600)
        t0 = time.time()
        while True:
            try:
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(self.fd, msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return self
            except OSError:
                if time.time() - t0 > self.espera:
                    os.close(self.fd)
                    raise MetaSearchError(f"No se pudo bloquear {self.ruta} en {self.espera:.0f} s.")
                time.sleep(0.02)

    def __exit__(self, *a):
        try:
            if self.fd is not None:
                try:
                    if os.name == "nt":
                        import msvcrt
                        msvcrt.locking(self.fd, msvcrt.LK_UNLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(self.fd, fcntl.LOCK_UN)
                finally:
                    os.close(self.fd)
                    self.fd = None
        finally:
            _LOCK_PROCESO.release()


class Libro:
    """Libro de gasto global (`gasto.jsonl`). Filas: reserva | liquidacion. El tope es POR INVESTIGACIÓN.

    gastado = suma de liquidaciones; pendiente = reservas sin liquidar (en vuelo o de un proceso caído: cuentan,
    conservador). Reservar y comprobar el remanente ocurren bajo el MISMO bloqueo, así dos procesos no pueden
    quedarse con el mismo remanente."""

    def __init__(self, ruta: Optional[Path] = None):
        self.ruta = ruta or fichero_gasto()
        self.cerrojo = self.ruta.with_suffix(".lock")

    def _filas(self) -> List[dict]:
        out: List[dict] = []
        try:
            with open(self.ruta, encoding="utf-8") as f:
                for linea in f:
                    try:
                        out.append(json.loads(linea))
                    except ValueError:
                        continue
        except OSError:
            pass
        return out

    @staticmethod
    def _estado(filas: List[dict], investigacion: str) -> Tuple[float, float]:
        reservas: Dict[str, float] = {}
        liquidadas = set()
        gastado = 0.0
        for r in filas:
            if r.get("investigacion") != investigacion:
                continue
            if r.get("tipo") == "reserva":
                reservas[r["id"]] = float(r.get("cota_usd") or 0)
            elif r.get("tipo") == "liquidacion":
                if r.get("id") in liquidadas:       # solo cuenta la PRIMERA liquidación de cada reserva
                    continue
                gastado += float(r.get("coste_usd") or 0)
                liquidadas.add(r.get("id"))
        pendiente = sum(c for i, c in reservas.items() if i not in liquidadas)
        return gastado, pendiente

    def estado(self, investigacion: str) -> Tuple[float, float]:
        with Bloqueo(self.cerrojo):
            return self._estado(self._filas(), investigacion)

    def _anexar(self, fila: dict) -> None:
        self.ruta.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(self.ruta, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
        with os.fdopen(fd, "a", encoding="utf-8") as f:
            f.write(json.dumps(fila, ensure_ascii=False) + "\n")
            f.flush()
            os.fsync(f.fileno())

    def reservar(self, investigacion: str, tope_total: float, proveedor: str, concepto: str, cota: float,
                 en_vuelo: bool = False) -> str:
        """Reserva `cota` bajo el bloqueo del libro. Con `en_vuelo=True` la anota TAMBIÉN en el registro de llamadas en
        vuelo de este proceso dentro del mismo bloqueo: una señal no puede caer entre las dos cosas. Si el proceso
        está cerrando (señal recibida) no se reserva nada."""
        if not (isinstance(cota, (int, float)) and math.isfinite(cota) and cota >= 0
                and isinstance(tope_total, (int, float)) and math.isfinite(tope_total)):
            raise PresupuestoAgotado(f"No se lanza {proveedor} ({concepto}): la cota ({cota!r}) o el tope total "
                                     f"({tope_total!r}) no son números finitos válidos.")
        with Bloqueo(self.cerrojo):
            if _CERRANDO.is_set():
                raise MetaSearchError(f"No se lanza {proveedor} ({concepto}): el proceso está cerrando por una señal.")
            gastado, pendiente = self._estado(self._filas(), investigacion)
            if gastado + pendiente + cota > tope_total + 1e-9:
                raise PresupuestoAgotado(
                    f"No se lanza {proveedor} ({concepto}): gastado {gastado:.4f} USD + reservado {pendiente:.4f} + "
                    f"esta llamada {cota:.4f} > tope total {tope_total:.2f} USD. Sube --tope-total-usd solo con el "
                    "OK de quien paga.")
            rid = hashlib.sha256(f"{time.time_ns()}-{os.getpid()}-{proveedor}-{concepto}".encode()).hexdigest()[:14]
            if en_vuelo:             # primero el registro en vuelo: una reserva anotada nunca queda fuera de él
                _en_vuelo_alta(rid, self, investigacion, cota, proveedor)
            try:
                self._anexar({"tipo": "reserva", "id": rid, "investigacion": investigacion, "proveedor": proveedor,
                              "concepto": concepto, "cota_usd": round(cota, 6), "fecha": iso_local()})
            except BaseException:
                if en_vuelo:
                    _en_vuelo_baja(rid)
                raise
            return rid

    def liquidar(self, rid: str, investigacion: str, coste: float, estado: str = "ok", **extra: Any) -> None:
        with Bloqueo(self.cerrojo):
            self._anexar({"tipo": "liquidacion", "id": rid, "investigacion": investigacion,
                          "coste_usd": round(max(0.0, coste), 7), "estado": estado, "fecha": iso_local(), **extra})

    def liquidar_sin_bloqueo(self, rid: str, investigacion: str, coste: float, estado: str, **extra: Any) -> None:
        """Para el manejador de señales: una sola escritura en modo append, sin esperar al cerrojo."""
        self._anexar({"tipo": "liquidacion", "id": rid, "investigacion": investigacion,
                      "coste_usd": round(max(0.0, coste), 7), "estado": estado, "fecha": iso_local(), **extra})

    def resumen(self) -> Dict[str, Dict[str, Any]]:
        """Por investigación: gastado, reservado y las reservas sin liquidar (colgadas o en vuelo)."""
        with Bloqueo(self.cerrojo):
            filas = self._filas()
        invs: Dict[str, Dict[str, Any]] = {}
        reservas: Dict[str, dict] = {}
        liquidadas = set()
        for r in filas:
            inv = r.get("investigacion")
            if inv is None:
                continue
            invs.setdefault(inv, {"gastado": 0.0, "reservado": 0.0, "colgadas": []})
            if r.get("tipo") == "reserva":
                reservas[r["id"]] = r
            elif r.get("tipo") == "liquidacion" and r.get("id") not in liquidadas:
                invs[inv]["gastado"] += float(r.get("coste_usd") or 0)
                liquidadas.add(r.get("id"))
        for rid, r in reservas.items():
            if rid not in liquidadas:
                d = invs[r["investigacion"]]
                d["reservado"] += float(r.get("cota_usd") or 0)
                d["colgadas"].append({"id": rid, "proveedor": r.get("proveedor"), "concepto": r.get("concepto"),
                                      "cota_usd": float(r.get("cota_usd") or 0), "fecha": r.get("fecha")})
        return invs

    def desglose(self, investigaciones: Iterable[str]) -> Optional[Dict[str, Any]]:
        """Gastado (liquidado), reservado sin liquidar y gasto por proveedor de esas investigaciones. None si el
        libro existe pero no se puede leer: el coste es entonces DESCONOCIDO, nunca 0."""
        invs = set(investigaciones)
        if self.ruta.exists():
            try:
                with Bloqueo(self.cerrojo):
                    with open(self.ruta, encoding="utf-8") as f:
                        lineas = f.read().splitlines()
            except OSError:
                return None
        else:
            lineas = []
        reservas: Dict[str, dict] = {}
        liquidadas = set()
        out: Dict[str, Any] = {"gastado_usd": 0.0, "reservado_sin_liquidar_usd": 0.0, "por_proveedor": {},
                               "filas": 0}
        for linea in lineas:
            try:
                r = json.loads(linea)
            except ValueError:
                continue
            if not isinstance(r, dict) or r.get("investigacion") not in invs:
                continue
            out["filas"] += 1
            if r.get("tipo") == "reserva":
                reservas[r.get("id")] = r
            elif r.get("tipo") == "liquidacion" and r.get("id") not in liquidadas:
                liquidadas.add(r.get("id"))
                c = float(r.get("coste_usd") or 0)
                out["gastado_usd"] += c
                prov = r.get("proveedor") or (reservas.get(r.get("id")) or {}).get("proveedor") or "desconocido"
                out["por_proveedor"][prov] = round(out["por_proveedor"].get(prov, 0.0) + c, 7)
        for rid, r in reservas.items():
            if rid not in liquidadas:
                out["reservado_sin_liquidar_usd"] += float(r.get("cota_usd") or 0)
        out["gastado_usd"] = round(out["gastado_usd"], 7)
        out["reservado_sin_liquidar_usd"] = round(out["reservado_sin_liquidar_usd"], 7)
        return out

    def liberar_colgadas(self, investigacion: str) -> List[dict]:
        """Liquida cada reserva sin liquidar de la investigación POR SU COTA ENTERA: cuenta como gastada y el gasto
        nunca baja. Solo para reservas de procesos que ya no existen."""
        with Bloqueo(self.cerrojo):
            filas = self._filas()
            liquidadas = {r.get("id") for r in filas if r.get("tipo") == "liquidacion"}
            hechas = []
            for r in filas:
                if (r.get("tipo") == "reserva" and r.get("investigacion") == investigacion
                        and r.get("id") not in liquidadas):
                    cota = float(r.get("cota_usd") or 0)
                    self._anexar({"tipo": "liquidacion", "id": r["id"], "investigacion": investigacion,
                                  "coste_usd": round(cota, 7), "estado": "liberada_colgada",
                                  "proveedor": r.get("proveedor"), "fecha": iso_local()})
                    hechas.append({"id": r["id"], "proveedor": r.get("proveedor"), "concepto": r.get("concepto"),
                                   "cota_usd": cota})
            return hechas

    def total_mes(self, prefijo_mes: str) -> Dict[str, float]:
        """Gasto liquidado por proveedor en un mes (AAAA-MM), sobre todo el libro."""
        porid: Dict[str, str] = {}
        out: Dict[str, float] = {}
        if not self.ruta.exists():
            return out
        with Bloqueo(self.cerrojo):
            filas = self._filas()
        for r in filas:
            if r.get("tipo") == "reserva":
                porid[r["id"]] = r.get("proveedor", "?")
        vistos = set()
        for r in filas:
            if r.get("tipo") == "liquidacion":
                if r.get("id") in vistos:
                    continue
                vistos.add(r.get("id"))
                if str(r.get("fecha", "")).startswith(prefijo_mes):
                    p = porid.get(r.get("id"), "?")
                    out[p] = out.get(p, 0.0) + float(r.get("coste_usd") or 0)
        return out


# ---------------------------------------------------------------------------------------------
# URL, ID y fecha de una publicación (cada red tiene su identidad)
# ---------------------------------------------------------------------------------------------
_ALFABETO_CODIGO = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
# Los códigos de /p/, /reel/ y /tv/ de Instagram y de /post/ y /video/ de Threads son un número en base 64: el ID del
# medio. Su parte alta es el instante en milisegundos desde esta época (comprobado con 63 publicaciones de Instagram y 80
# de Threads de los crudos del piloto: ver references/metodo-de-busqueda.md §5 y test_fecha_del_codigo).
EPOCH_CODIGO_MS = 1314220021721
_RE_IG = re.compile(r"^/(?:(?P<user>[A-Za-z0-9._]{1,30})/)?(?P<kind>p|reels?|tv)/(?P<code>[A-Za-z0-9_-]{8,40})(?:/|$)")
_RE_TH = re.compile(r"^/@(?P<user>[A-Za-z0-9._]{1,40})/(?P<kind>post|video)/(?P<code>[A-Za-z0-9_-]{8,40})(?:/|$)")
_RE_TH_CORTO = re.compile(r"^/t/(?P<code>[A-Za-z0-9_-]{8,40})(?:/|$)")
_RE_FB_NUM = re.compile(r"^[0-9]{8,}\Z")
_RE_FB_PFBID = re.compile(r"^pfbid[A-Za-z0-9]{10,}\Z")
_RE_FB_PAGINA = re.compile(r"^[A-Za-z][A-Za-z0-9.\-]{0,79}\Z")
_RE_FB_COMPARTIDO = re.compile(r"^[A-Za-z0-9_-]{6,}\Z")
_RE_FB_SEGMENTO = re.compile(r"^[\w.\-]{1,100}\Z")      # un segmento de ruta normal: letras (de cualquier idioma), cifras, . _ -


def _q_fb(segmento: str) -> str:
    return urllib.parse.quote(segmento, safe="")


def _host(p: "urllib.parse.ParseResult") -> str:
    return (p.netloc or "").lower().split("@")[-1].split(":")[0]


def red_de_host(host: str) -> Optional[str]:
    h = (host or "").lower()
    if h == "instagram.com" or h.endswith(".instagram.com"):
        return "instagram"
    if h in ("threads.com", "threads.net") or h.endswith((".threads.com", ".threads.net")):
        return "threads"
    if h in ("facebook.com", "fb.com") or h.endswith((".facebook.com", ".fb.com")):
        return "facebook"
    return None


def _info(red: str, clave: str, url: str, ident: str, tipo: str, handle: Optional[str]) -> Dict[str, Any]:
    return {"url": url, "clave": clave, "red": red, "id": ident, "tipo": tipo, "handle": handle, "id_ambiguo": False}


def _parsear_instagram(p: "urllib.parse.ParseResult") -> Optional[Dict[str, Any]]:
    m = _RE_IG.match(urllib.parse.unquote(p.path))
    if not m:
        return None
    tipo = {"p": "p", "reel": "reel", "reels": "reel", "tv": "tv"}[m.group("kind")]
    code = m.group("code")
    return _info("instagram", f"ig:{code}", f"https://www.instagram.com/{tipo}/{code}/", code, tipo, m.group("user"))


def _parsear_threads(p: "urllib.parse.ParseResult") -> Optional[Dict[str, Any]]:
    ruta = urllib.parse.unquote(p.path)
    m = _RE_TH.match(ruta)
    if m:
        user, tipo, code = m.group("user"), m.group("kind"), m.group("code")
        return _info("threads", f"th:{code}", f"https://www.threads.com/@{user}/{tipo}/{code}", code, tipo, user)
    m = _RE_TH_CORTO.match(ruta)
    if m:
        code = m.group("code")
        return _info("threads", f"th:{code}", f"https://www.threads.com/t/{code}", code, "corto", None)
    return None


def _clave_fb(ident: str) -> Optional[str]:
    return "fb:" + ident if (_RE_FB_NUM.match(ident or "") or _RE_FB_PFBID.match(ident or "")) else None


def _parsear_facebook(p: "urllib.parse.ParseResult") -> Optional[Dict[str, Any]]:
    """Formas de publicación vistas en los crudos: /groups/<g>/posts|permalink/<id>, /<página>/posts/<slug>/<id>,
    /<página>/posts/pfbid…, /<página>/videos/<slug>/<id>, /reel/<id>, permalink.php?story_fbid=…&id=…, /watch/?v=<id> y
    /share/p|v|r/<código>. Lo demás (perfiles, páginas, hashtags, fotos, eventos, búsquedas) no es una publicación."""
    q = dict(urllib.parse.parse_qsl(p.query))
    segs = [s for s in urllib.parse.unquote(p.path).split("/") if s]
    if not segs:
        return None
    base = "https://www.facebook.com"
    primero = segs[0].lower()
    if primero in ("permalink.php", "story.php"):
        sid = q.get("story_fbid") or q.get("fbid") or ""
        clave = _clave_fb(sid)
        if not clave:
            return None
        pagina = q.get("id", "")
        url = f"{base}/permalink.php?story_fbid={sid}" + (f"&id={pagina}" if re.fullmatch(r"[A-Za-z0-9.]+", pagina) else "")
        return _info("facebook", clave, url, sid, "permalink", None)
    if primero == "watch":
        v = q.get("v", "")
        return _info("facebook", "fb:" + v, f"{base}/watch/?v={v}", v, "video", None) if _RE_FB_NUM.match(v) else None
    if primero in ("reel", "reels") and len(segs) >= 2 and _RE_FB_NUM.match(segs[1]):
        return _info("facebook", "fb:" + segs[1], f"{base}/reel/{segs[1]}/", segs[1], "reel", None)
    if primero == "share":
        if len(segs) == 3 and segs[1].lower() in ("p", "v", "r") and _RE_FB_COMPARTIDO.match(segs[2]):
            return _info("facebook", "fbshare:" + segs[2], f"{base}/share/{segs[1].lower()}/{segs[2]}/", segs[2], "compartido", None)
        if len(segs) == 2 and _RE_FB_COMPARTIDO.match(segs[1]):
            return _info("facebook", "fbshare:" + segs[1], f"{base}/share/{segs[1]}/", segs[1], "compartido", None)
        return None
    if primero == "groups":
        if len(segs) >= 4 and segs[2].lower() in ("posts", "permalink") and _RE_FB_SEGMENTO.match(segs[1]):
            clave = _clave_fb(segs[3])
            if clave:
                return _info("facebook", clave, f"{base}/groups/{_q_fb(segs[1])}/posts/{segs[3]}/", segs[3], "grupo", None)
        return None
    if len(segs) >= 3 and segs[1].lower() in ("posts", "videos"):
        for i in range(len(segs) - 1, 1, -1):
            clave = _clave_fb(segs[i])
            if clave:
                if not _RE_FB_SEGMENTO.match(segs[0]):      # una «página» con saltos de línea, `?`, `&`… no es una página
                    return None
                handle = segs[0] if _RE_FB_PAGINA.match(segs[0]) else None
                tipo = "video" if segs[1].lower() == "videos" else "post"
                # la URL canónica se arma con segmentos validados y codificados: nada de lo decodificado pasa tal cual
                ruta = [_q_fb(segs[0]), segs[1].lower()] + [_q_fb(s) for s in segs[2:i] if _RE_FB_SEGMENTO.match(s)] \
                    + [segs[i]]
                return _info("facebook", clave, f"{base}/{'/'.join(ruta)}/", segs[i], tipo, handle)
    return None


def parsear_url(url: str) -> Optional[Dict[str, Any]]:
    """Reconoce una URL de PUBLICACIÓN de Instagram, Threads o Facebook. None si es perfil, página, hashtag, foto, etc.

    Devuelve {url, clave, red, id, tipo, handle|None, id_ambiguo}. La clave de deduplicación sale del ID de la red:
    `ig:<código>`, `th:<código>`, `fb:<número|pfbid…>` o `fbshare:<código>` (enlace corto de Facebook, que se reindexa
    cuando un proveedor revela la forma canónica). La URL devuelta es la canónica: sin parámetros de seguimiento."""
    if not url or not isinstance(url, str):
        return None
    try:
        p = urllib.parse.urlparse(url.strip())
    except ValueError:
        return None
    if p.scheme not in ("http", "https"):
        return None
    red = red_de_host(_host(p))
    if red == "instagram":
        return _parsear_instagram(p)
    if red == "threads":
        return _parsear_threads(p)
    if red == "facebook":
        return _parsear_facebook(p)
    return None


def limpiar_url(url: str) -> str:
    """Forma canónica de una publicación; para cualquier otra URL, host en minúsculas y sin parámetros ni fragmento."""
    info = parsear_url(url)
    if info:
        return info["url"]
    p = urllib.parse.urlparse((url or "").strip())
    return urllib.parse.urlunparse(("https", (p.netloc or "").lower(), p.path.rstrip("/"), "", "", ""))


def misma_url(a: str, b: str) -> bool:
    return bool(a and b) and limpiar_url(a).rstrip("/") == limpiar_url(b).rstrip("/")


def id_de_codigo(code: str) -> Optional[int]:
    """ID numérico de un código de Instagram/Threads (base 64 con A-Z a-z 0-9 - _). None si algún carácter no es del alfabeto."""
    n = 0
    for c in code or "":
        i = _ALFABETO_CODIGO.find(c)
        if i < 0:
            return None
        n = n * 64 + i
    return n if code else None


def ms_de_codigo(code: str) -> Optional[int]:
    """Instante de creación en ms UTC según el código (parte alta del ID). None si el código no sirve para fechar: ni
    11 caracteres como mucho, ni una fecha entre 2012 y mañana (un código no puede ser de algo que aún no existe)."""
    if not code or not 8 <= len(code) <= 11:
        return None
    n = id_de_codigo(code)
    if n is None:
        return None
    ms = (n >> 23) + EPOCH_CODIGO_MS
    futuro = int(ahora_utc().timestamp() * 1000) + 86_400_000
    return ms if 1325376000000 <= ms <= min(4102444800000, futuro) else None


def fecha_de_codigo(code: str) -> Optional[dt.datetime]:
    ms = ms_de_codigo(code)
    return dt.datetime.fromtimestamp(ms / 1000, dt.timezone.utc) if ms is not None else None


def parse_fecha(v: Any) -> Optional[dt.datetime]:
    if v in (None, ""):
        return None
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        try:
            s = v / 1e6 if v > 1e14 else (v / 1000 if v > 1e11 else v)      # microsegundos, milisegundos o segundos
            return dt.datetime.fromtimestamp(s, dt.timezone.utc)
        except (OverflowError, OSError, ValueError):        # NaN, infinito, microsegundos o un número fuera de rango
            return None
    txt = str(v).strip().replace(" ", "T").replace("Z", "+00:00")
    txt = re.sub(r"([+-]\d{2})(\d{2})$", r"\1:\2", txt)      # «-0600» → «-06:00» (Python 3.9)
    txt = re.sub(r"\.(\d{1,6})\d*", lambda m: "." + m.group(1).ljust(6, "0"), txt, count=1)   # fracciones para Python 3.9
    try:
        t = dt.datetime.fromisoformat(txt)
    except ValueError:
        try:
            t = dt.datetime.strptime(txt[:10], "%Y-%m-%d")
        except ValueError:
            return None
    t = t if t.tzinfo else t.replace(tzinfo=dt.timezone.utc)
    try:
        t.astimezone(dt.timezone.utc)                  # una fecha en el borde del calendario con zona se sale de rango
        t.timestamp()
    except (OverflowError, OSError, ValueError):
        return None
    return t


def parse_dia(s: Optional[str]) -> Optional[dt.datetime]:
    if not s:
        return None
    try:
        return dt.datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=dt.timezone.utc)
    except ValueError:
        raise MetaSearchError(f"Fecha inválida {s!r}: usa AAAA-MM-DD.")


def en_ventana(fecha_iso: Optional[str], desde: Optional[str], hasta: Optional[str]) -> Optional[bool]:
    """True/False si hay fecha; None si no hay fecha (el llamador decide: C4). desde incluido, hasta excluido."""
    if not fecha_iso:
        return None
    t = parse_fecha(fecha_iso)
    if t is None:
        return None
    d, h = parse_dia(desde), parse_dia(hasta)
    if d and t < d:
        return False
    if h and t >= h:
        return False
    return True


# ---------------------------------------------------------------------------------------------
# Idioma (detección simple por palabras frecuentes) y relleno
# ---------------------------------------------------------------------------------------------
# Solo palabras EXCLUSIVAS de cada idioma (las compartidas, como «de», «para» o «que», no cuentan).
_PAL_ES = set("""el los las del una un con pero más muy también están son es sus lo al sin sobre hay ya nuestro nuestros
nuestra nuestras tu tus esto esta estos estas cuando desde mejorar quiero puedes tienes todos todas sido hacer y en la
ahora aquí cómo qué porque aprende inscríbete gratis curso""".split()) - {"gratis", "curso"}
_PAL_PT = set("""você voce não nao uma com mais muito também são é os as dos das pelo pela seu sua seus suas ao aos em
mas isso esse essa sem já têm estão nossa nosso nós leia aqui e um ou vagas você's""".split())
_PAL_EN = set("""the and of to is that it with are this be at by from your you we our not what how will can have has all
about free new for in on as i my their they was were been more""".split())
_FUNCIONALES_ES = {"de", "para", "la", "que", "y", "en", "por", "del", "los", "las"}
_PALABRAS = re.compile(r"[^\W\d_]+", re.UNICODE)
_URL = re.compile(r"(?:https?://|www\.)\S+|\blnkd\.in/\S+|\S+@\S+\.\S+", re.I)
_HASHTAG = re.compile(r"#[\w\-]+", re.UNICODE)


def palabras_texto(texto: str) -> List[str]:
    t = _HASHTAG.sub(" ", _URL.sub(" ", texto or ""))
    return _PALABRAS.findall(t.lower())


def detectar_idioma(texto: str) -> Optional[str]:
    """es | en | pt | None. None = no se puede decir (texto corto o mezclado): NUNCA descarta."""
    pal = palabras_texto(texto)
    if len(pal) < 3:
        return None
    n = {"es": sum(p in _PAL_ES for p in pal), "pt": sum(p in _PAL_PT for p in pal),
         "en": sum(p in _PAL_EN for p in pal)}
    ord_ = sorted(n.items(), key=lambda kv: kv[1], reverse=True)
    (mejor, a), (_, b) = ord_[0], ord_[1]
    if a >= 2 and a >= 1.5 * b:
        return mejor
    if a >= 1 and b == 0 and len(pal) <= 6:
        return mejor
    return None


def idioma_de_tema(tema: str) -> Optional[str]:
    """Idioma probable de una consulta. Las consultas cortas sin palabras funcionales (p. ej. «vibe coding»)
    devuelven None: para lanzar la búsqueda de pago hay que pasar --idioma en explícitamente."""
    d = detectar_idioma(tema)
    if d:
        return d
    pal = palabras_texto(tema)
    if any(p in _FUNCIONALES_ES for p in pal) and not any(p in _PAL_EN for p in pal):
        return "es"
    if any(p in _PAL_EN for p in pal) and not any(p in _FUNCIONALES_ES for p in pal):
        return "en"
    return None


_CUPONES = re.compile(
    r"(?i)\bfree\s+udemy\b|udemy\s+(free\s+)?(courses?|coupons?)|\b(cup[oó]n|coupon)(es|s)?\s+(de\s+)?"
    r"(udemy|descuento|gratis|100)|100\s*%\s*(off|descuento)|free for a limited time|cursos?\s+gratis\s+de\s+udemy")
_SUSCRIBETE = re.compile(r"(?i)^\W*(suscr[ií]bete|subscribe|s[ií]guenos|follow\s+us|sigue\s+mis\s+redes)\b")
_SOLO_ENLACE = re.compile(r"^\s*(?:[^\w\s]{0,3}\s*)?[\w\s/().+\-·X]{0,40}:?\s*(?:https?://|www\.|lnkd\.in/)\S+\s*$", re.I)
_INSTRUCCION = re.compile(
    r"(?i)(ignore|disregard|forget|override|bypass|descarta|omite)\s+(?:(?:all|any|every|todas?|tus|your|my|the|las|of)\s+)*"
    r"(?:(?:previous|prior|above|earlier|preceding|system|anteriores|previas)\s+)*"
    r"(?:instructions?|prompts?|rules|guidelines|directives|instrucciones|reglas)|"
    r"(ignora|olvida|descarta|omite)\s+(?:todas?\s+)?(?:las\s+|tus\s+)?(?:instrucciones|reglas)|"
    r"(ignora|olvida|descarta|ignore|forget)\s+(?:todo\s+)?(?:lo|everything|all)\s+(?:anterior|above|before|previous)|"
    r"(?:ahora\s+eres|you\s+are\s+now|from\s+now\s+on\s+you|a\s+partir\s+de\s+ahora\s+eres)\b|"
    r"system\s+prompt|developer\s+message|mensaje\s+del\s+sistema|"
    r"(?:^|\n)\s*(?:system|sistema|assistant|asistente)\s*:|"
    r"(run|execute|ejecuta|ejecutar)\s+(this|the\s+following|el\s+siguiente)\s+(command|comando|script|code|c[oó]digo)|"
    r"\b(?:curl|wget)\s+[^|\n]*\|\s*(?:ba|z)?sh|\bsudo\s+rm\s+-|"
    r"<\s*/?\s*(?:system|assistant|developer)\s*>|\[\s*/?INST\s*\]")


def texto_propio(texto: str) -> List[str]:
    """Palabras del autor, sin enlaces ni hashtags."""
    return palabras_texto(texto)


def es_bloque_de_enlaces(texto: str) -> bool:
    lineas = [l for l in (texto or "").splitlines() if l.strip() and not re.fullmatch(r"[\s\-_=─┄•·]+", l)]
    if len(lineas) < 3:
        return False
    enlaces = sum(1 for l in lineas if _SOLO_ENLACE.match(l) or _HASHTAG.fullmatch(l.strip()))
    return enlaces / len(lineas) >= 0.6


MIN_ME_GUSTA_INTERACCION = 50
MIN_COMENTARIOS_INTERACCION = 10


def interaccion_alta(me_gusta: Optional[int], comentarios: Optional[int]) -> bool:
    """Una publicación con 50+ me gusta o 10+ comentarios no es relleno por muy corto que sea su texto."""
    return (me_gusta or 0) >= MIN_ME_GUSTA_INTERACCION or (comentarios or 0) >= MIN_COMENTARIOS_INTERACCION


def texto_corto_con_enlace(texto: Optional[str]) -> bool:
    """Texto de 6 palabras o menos con un enlace (sin ser un «¡SUSCRÍBETE!»): candidato a «solo_enlaces»."""
    t = texto or ""
    return bool(t) and len(texto_propio(t)) <= 6 and bool(_URL.search(t)) and not _SUSCRIBETE.match(t)


def motivo_relleno(texto: Optional[str], me_gusta: Optional[int], comentarios: Optional[int],
                   hay_lectura: bool = True) -> Optional[str]:
    """Motivo por el que una publicación es relleno, o None. Se CUENTA siempre; nunca se oculta.

    Con una lectura de 50+ me gusta o 10+ comentarios NADA es relleno, ni un texto corto con enlace, ni uno de solo etiquetas, ni uno de cupones
    (la ficha lleva el aviso `texto_corto_con_enlace` / `texto_de_cupones_con_interaccion_alta`). Al DESCUBRIR, antes de
    medir, solo se descartan `cupones` y `solo_enlaces` sin interacción conocida; `sin_interaccion_ni_texto` exige una
    lectura (hay_lectura), es decir, haber medido."""
    t = texto or ""
    if t and _CUPONES.search(t):
        return None if interaccion_alta(me_gusta, comentarios) else "cupones"
    if t:
        pal = texto_propio(t)
        if len(pal) <= 6 and (_URL.search(t) or _SUSCRIBETE.match(t) or not pal):
            solo_etiquetas = not pal and not _URL.search(t) and not _SUSCRIBETE.match(t)
            if not ((texto_corto_con_enlace(t) or solo_etiquetas) and interaccion_alta(me_gusta, comentarios)):
                return "solo_enlaces"
        if _SUSCRIBETE.match(t) and es_bloque_de_enlaces(t):
            return "solo_enlaces"
        if es_bloque_de_enlaces(t):
            return "solo_enlaces"
    if hay_lectura and me_gusta == 0 and comentarios == 0 and len(texto_propio(t)) < 4:
        return "sin_interaccion_ni_texto"
    return None


def avisos_texto(texto: Optional[str]) -> List[str]:
    """Avisa de una posible instrucción en el texto, también la escondida: en caracteres Tags (U+E0000-E007F) o con
    caracteres de formato invisibles intercalados («ig\u200bnore»)."""
    if not texto:
        return []
    vistas = (texto, _sin_formato(texto), tags_decodificados(texto), selectores_decodificados(texto))
    return ["posible_instruccion_en_el_texto"] if any(v and _INSTRUCCION.search(v) for v in vistas) else []


# Solo palabras FUNCIONALES (artículos, preposiciones, conjunciones, auxiliares) y palabras de PETICIÓN (qué, cómo,
# dicen, about, think…): nunca palabras con significado («people analytics» es un término, no una petición).
_VACIAS = _FUNCIONALES_ES | {
    "a", "an", "the", "of", "to", "in", "on", "for", "and", "or", "with", "at", "by", "from", "as", "is", "are", "be",
    "it", "its", "into", "over", "vs", "versus", "el", "un", "una", "con", "su", "sus", "se", "es", "lo", "al", "o", "u",
    "e", "como", "sobre", "entre", "esto", "eso", "este", "esta", "estos", "this", "that", "these", "those", "they",
    "their", "do", "does", "did",
    # petición: verbos y rellenos de una pregunta que no son el tema
    "how", "what", "why", "who", "which", "when", "where", "about", "think", "thinks", "say", "says", "said", "latest",
    "recent", "recently", "post", "posts", "instagram", "facebook", "threads", "meta", "cómo", "qué", "cuál", "cual", "cuáles", "quién", "quien",
    "dicen", "dice", "piensan", "piensa", "opinan", "opina", "publicaciones", "publicación", "publicacion", "últimos",
    "ultimos", "últimas", "ultimas", "recientes", "reciente"}
_TOKEN_TEMA = re.compile(r"[^\s\"“”«»‘’,;:!?()\[\]{}¿¡]+")


def _tokens_tema(texto: str) -> List[str]:
    """Palabras de un tema que CONSERVAN sus símbolos con significado (C++, C#, GPT-5, .NET, Node.js, go-to-market)."""
    out = []
    for t in _TOKEN_TEMA.findall(texto.lower()):
        t = t.strip("'").rstrip(".")
        if re.search(r"[^\W_]", t, re.UNICODE):
            out.append(t)
    return out


def palabras_clave(tema: str, max_palabras: int = MAX_PALABRAS_QUERY, max_queries: int = MAX_QUERIES_PAGO) -> List[str]:
    """Parte un tema largo en consultas CORTAS (1-3 palabras) para la búsqueda de pago: las pruebas del 14-15 de octubre de 2026 mostraron que las
    frases largas fallan. Hasta 3 palabras → una consulta; si no, las 3 primeras y las 3 últimas (se solapan).
    Si el tema trae una frase entre comillas («», "", “”), esa frase es la consulta. Solo se quitan palabras
    funcionales y de petición; los términos con símbolos (C++, GPT-5, .NET, Node.js) se conservan enteros."""
    # «what's», «how's», «Meta’s» → «what», «how», «Meta» (contracción o posesivo, no un término)
    tema = re.sub(r"(?i)\b([^\W\d_][\w.+#-]*)['’]s\b", r"\1", tema)
    entre_comillas = re.search(r"[«\"“]([^»\"”]{2,80})[»\"”]", tema)
    if entre_comillas:
        frase = " ".join(_tokens_tema(entre_comillas.group(1)))
        if frase:
            return [frase]
    pal = [p for p in _tokens_tema(tema) if p not in _VACIAS and (len(p) > 1 or p.isalnum())]
    vistos: List[str] = []
    for p in pal:
        if p not in vistos:
            vistos.append(p)
    if not vistos:
        return []
    if len(vistos) <= max_palabras:
        return [" ".join(vistos)]
    primera = " ".join(vistos[:max_palabras])
    ultima = " ".join(vistos[-max_palabras:])
    return [primera] if max_queries < 2 or primera == ultima else [primera, ultima]


# ---------------------------------------------------------------------------------------------
# Normalización de cada proveedor → «lectura» (métricas y texto) o «candidato» (buscadores)
# ---------------------------------------------------------------------------------------------
def a_entero(v: Any) -> Optional[int]:
    """Entero o None. 0 es un dato real; ausente/ilegible es None, NUNCA 0."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return int(v) if math.isfinite(v) else None
    s = str(v).strip().replace(" ", "").replace("\u00a0", "")
    if s.lower() in ("", "none", "null", "nan"):
        return None
    if re.fullmatch(r"-?\d+", s):
        return int(s)
    # separador de millares: un solo separador seguido de EXACTAMENTE 3 dígitos, o varios grupos de 3 («1.234»,
    # «1,234», «1.234.567»). Un decimal («4.5», «12,5») se trunca a su parte entera.
    m = re.fullmatch(r"(-?[1-9]\d{0,2})((?:([.,])\d{3})+)", s)
    if m and len(set(re.findall(r"[.,]", m.group(2)))) == 1:
        return int(m.group(1) + re.sub(r"[.,]", "", m.group(2)))
    m = re.fullmatch(r"(-?\d+)[.,]\d+", s)
    if m:
        return int(m.group(1))
    return None


def _txt(v: Any) -> Optional[str]:
    if v is None:
        return None
    s = str(v).replace("\r\n", "\n").replace("\r", "\n").strip()
    return s if s and s.lower() not in ("none", "null") else None


def _lectura(proveedor: str, **kw: Any) -> Dict[str, Any]:
    base = {"proveedor": proveedor, "red": None, "consultado": iso_local(), "me_gusta": None, "comentarios": None,
            "compartidos": None, "vistas": None, "texto": None, "autor": None, "id": None, "url": None, "entrada": None,
            "fecha_proveedor": None, "error": None, "ts_proveedor": False, "via": None}
    base.update(kw)
    return base


def _contador(v: Any) -> Optional[int]:
    """Contador de Instagram: -1 es «el autor oculta los me gusta» → ausente (None), nunca 0 ni negativo."""
    n = a_entero(v)
    return None if n is not None and n < 0 else n


def _error_bd(item: dict) -> Optional[str]:
    err, cod = item.get("error"), item.get("error_code")
    if not (err or cod):
        return None
    return (f"{cod}: {err}" if (err and cod) else str(err or cod))[:200]


def _entrada_bd(item: dict) -> Optional[str]:
    inp = item.get("input")
    return inp.get("url") if isinstance(inp, dict) else (inp if isinstance(inp, str) and inp.startswith("http") else None)


def _nombre_de(v: Any) -> Optional[str]:
    """`name` de un objeto del proveedor; si el campo cambia de forma (un texto, una lista…), ausente."""
    return v.get("name") if isinstance(v, dict) else None


def normalizar_seguro(normalizador: Callable[[Any], Optional[Dict[str, Any]]], item: Any,
                      cob: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Normaliza UN registro de un proveedor sin que uno con forma inesperada aborte el comando después de pagar: el
    registro ilegible se cuenta (`registro_ilegible`), se avisa y el resto sigue."""
    try:
        return normalizador(item)
    except Exception:  # noqa: BLE001 - un proveedor puede cambiar la forma de cualquier campo
        cob["descartes"]["registro_ilegible"] = cob["descartes"].get("registro_ilegible", 0) + 1
        _avisar_registro_ilegible(cob)
        return None


def _avisar_registro_ilegible(cob: Dict[str, Any]) -> None:
    texto = ("Algún registro del proveedor tenía una forma inesperada y se descartó sin interrumpir el resto "
             "(descarte `registro_ilegible`).")
    if texto not in cob["avisos"]:
        cob["avisos"].append(texto)


# -- Facebook ---------------------------------------------------------------------------------
def norm_fb_busqueda(item: dict) -> Optional[Dict[str, Any]]:
    """apify~facebook-search-scraper con searchType «posts». Los contadores salen de `likes` (todas las reacciones),
    `comments` y `shares`; los alias `*Count` no se usan: en una página de registro bloqueada vienen como 0 falsos."""
    if not isinstance(item, dict) or not item.get("url") or not (item.get("postId") or item.get("legacyId")):
        return None
    autor = _nombre_de(item.get("user")) or _nombre_de(item.get("pageName"))
    return _lectura("apify_fb_busqueda", red="facebook", id=_txt(item.get("postId")), url=item.get("url"),
                    texto=_txt(item.get("text")), autor=_txt(autor), me_gusta=a_entero(item.get("likes")),
                    comentarios=a_entero(item.get("comments")), compartidos=a_entero(item.get("shares")),
                    fecha_proveedor=item.get("time"), via="busqueda_de_pago")


def _reacciones_fb(item: dict) -> Optional[int]:
    """Bright Data da `likes` = solo el tipo «Me gusta»; el total de reacciones (lo que cuenta el actor de búsqueda y lo
    que muestra Facebook) es la suma de `num_likes_type`. Sin esa lista, `likes`."""
    tipos = item.get("num_likes_type")
    if isinstance(tipos, list) and tipos:
        cifras = [a_entero(t.get("num")) for t in tipos if isinstance(t, dict)]
        cifras = [c for c in cifras if c is not None]
        if cifras:
            return sum(cifras)
    return a_entero(item.get("likes"))


def norm_brightdata_facebook(item: dict) -> Optional[Dict[str, Any]]:
    """Dataset gd_lyclm1571iy3mv57zw (publicación de Facebook por URL). No se usan las vistas (`video_view_count` y
    `play_count` difieren y no se ha verificado su significado) ni los comentarios de terceros."""
    if not isinstance(item, dict):
        return None
    ts = item.get("timestamp") if parse_fecha(item.get("timestamp")) else None
    extra = {"consultado": ts} if ts else {}
    return _lectura("brightdata", red="facebook", id=_txt(item.get("post_id")), url=item.get("url"),
                    entrada=_entrada_bd(item), ts_proveedor=bool(ts), texto=_txt(item.get("content")),
                    autor=_txt(item.get("user_username_raw")), **extra, me_gusta=_reacciones_fb(item),
                    comentarios=a_entero(item.get("num_comments")), compartidos=a_entero(item.get("num_shares")),
                    fecha_proveedor=item.get("date_posted"), error=_error_bd(item))


# -- Instagram --------------------------------------------------------------------------------
def _norm_ig(item: dict, proveedor: str, via: Optional[str], con_entrada: bool) -> Optional[Dict[str, Any]]:
    if not isinstance(item, dict):
        return None
    code = _txt(item.get("shortCode"))
    entrada = item.get("inputUrl") if con_entrada and isinstance(item.get("inputUrl"), str) else None
    if item.get("error") or not code:
        if con_entrada and entrada:
            return _lectura(proveedor, red="instagram", entrada=entrada, via=via,
                            error=str(item.get("error") or item.get("errorDescription") or "sin_datos")[:200])
        return None
    likes = a_entero(item.get("likesCount"))
    vistas = item.get("videoPlayCount") if item.get("videoPlayCount") is not None else item.get("videoViewCount")
    # `isCommentsDisabled`: el autor cerró los comentarios. Un 0 ahí no mide ninguna conversación: es «sin dato» y la
    # ficha lo avisa (comentarios_desactivados_por_el_autor); no se entrega como un 0 medido.
    cerrados = item.get("isCommentsDisabled") is True
    return _lectura(proveedor, red="instagram", id=code, url=item.get("url") or f"https://www.instagram.com/p/{code}/",
                    entrada=entrada, texto=_txt(item.get("caption")),
                    autor=_txt(item.get("ownerUsername")) or _txt(item.get("ownerFullName")),
                    me_gusta=_contador(likes), comentarios=None if cerrados else _contador(item.get("commentsCount")),
                    vistas=_contador(vistas), fecha_proveedor=item.get("timestamp"), via=via,
                    me_gusta_oculto=bool(likes is not None and likes < 0), comentarios_desactivados=cerrados)


def norm_apify_ig_detalle(item: dict) -> Optional[Dict[str, Any]]:
    """apify~instagram-scraper con resultsType «details» (una URL de publicación)."""
    return _norm_ig(item, "apify_ig", None, True)


def norm_apify_ig_busqueda(item: dict) -> Optional[Dict[str, Any]]:
    """apify~instagram-search-scraper con searchType «popular»: reels relevantes pero antiguos."""
    return _norm_ig(item, "apify_ig_busqueda", "populares_antiguos", False)


def norm_apify_ig_hashtag(item: dict) -> Optional[Dict[str, Any]]:
    """apify~instagram-scraper sobre la página de un hashtag: solo «lo último», casi sin interacción todavía."""
    return _norm_ig(item, "apify_ig_hashtag", "lo_ultimo_sin_traccion", False)


def norm_brightdata_instagram(item: dict) -> Optional[Dict[str, Any]]:
    """Dataset gd_lk5ns7kz21pck8jpis (publicación de Instagram por URL)."""
    if not isinstance(item, dict):
        return None
    ts = item.get("timestamp") if parse_fecha(item.get("timestamp")) else None
    extra = {"consultado": ts} if ts else {}
    likes = a_entero(item.get("likes"))
    return _lectura("brightdata", red="instagram", id=_txt(item.get("shortcode")), url=item.get("url"),
                    entrada=_entrada_bd(item), ts_proveedor=bool(ts), texto=_txt(item.get("description")),
                    autor=_txt(item.get("user_posted")), **extra, me_gusta=_contador(likes),
                    comentarios=_contador(item.get("num_comments")), fecha_proveedor=item.get("date_posted"),
                    error=_error_bd(item), me_gusta_oculto=bool(likes is not None and likes < 0))


# -- Threads ----------------------------------------------------------------------------------
def norm_threads(item: dict) -> Optional[Dict[str, Any]]:
    """futurizerush~meta-threads-scraper en modo «search». `compartidos` = share_count; los reposts y las citas se
    guardan aparte en la lectura y no se suman. Las vistas son ausentes mientras `view_count_status` no sea «available»."""
    if not isinstance(item, dict) or item.get("record_type", "post") != "post":
        return None
    code, url = _txt(item.get("post_code")), item.get("post_url")
    if not (code or url):
        return None
    vistas = a_entero(item.get("view_count")) if item.get("view_count_status", "available") == "available" else None
    return _lectura("apify_threads", red="threads", id=code, url=url, texto=_txt(item.get("text_content")),
                    autor=_txt(item.get("username")), me_gusta=a_entero(item.get("like_count")),
                    comentarios=a_entero(item.get("reply_count")), compartidos=a_entero(item.get("share_count")),
                    vistas=vistas, fecha_proveedor=item.get("created_at"), via="busqueda_de_pago",
                    consulta=_txt(item.get("search_keyword")), es_respuesta=bool(item.get("is_reply")), es_repost=bool(item.get("is_repost")),
                    reposts=a_entero(item.get("repost_count")), citas=a_entero(item.get("quote_count")))


# Proveedores de lectura (nombre interno) y su orden: sirve para desempatar lecturas simultáneas y para elegir texto,
# autor y fecha. El primero de la lista manda cuando varios traen el mismo dato.
PRIORIDAD_TEXTO = ("apify_ig", "apify_fb_busqueda", "apify_threads", "brightdata", "apify_ig_busqueda", "apify_ig_hashtag")
ORDEN_PROVEEDOR = {p: i for i, p in enumerate(PRIORIDAD_TEXTO)}



def _cand(motor: str, url: str, titulo: Any = None, texto: Any = None, fecha: Any = None, autor: Any = None) -> Dict:
    return {"motor": motor, "url": url, "titulo": _txt(titulo), "snippet": _txt(texto), "fecha_motor": _txt(fecha),
            "autor": _txt(autor)}


_PAL_COMENTARIOS = r"(?:comments?|comentarios?|coment[aá]rios?|replies|respuestas)"
_BLOQUE_COMENTARIOS = re.compile(
    # un encabezado (# Comments, ## Comments (10 shown of 31 reported)) o una línea que es SOLO «31 comments» / «**Comments**»;
    # una frase del autor como «Comment AUDIT below» no cuenta
    r"(?im)^[ \t]*#{1,6}[ \t]*(?:\d[\d.,]*[ \t]+)?(?:top[ \t]+|most[ \t]+relevant[ \t]+|all[ \t]+)?" + _PAL_COMENTARIOS
    + r"\b[^\n]*$|^[ \t]*(?:\*\*|__)?(?:\d[\d.,]*[ \t]+)?" + _PAL_COMENTARIOS
    + r"(?:[ \t]*\([^)\n]*\))?(?:\*\*|__)?[ \t]*:?[ \t]*$")


_FECHA_COMENTARIO = (
    r"(?:\d{4}-\d{2}-\d{2}(?:[T ][\d:.+Zz\-]*)?|\d{1,2}[/.\-]\d{1,2}[/.\-]\d{2,4}|\d+\s?(?:s|m|min|h|d|w|mo|y|yr|sem)(?!\w)|"
    r"hace\s+\d+\s+(?:segundos?|minutos?|horas?|d[ií]as?|semanas?|mes(?:es)?|a[ñn]os?)|"
    r"\d+\s+(?:seconds?|minutes?|hours?|days?|weeks?|months?|years?)\s+ago)(?!\w)")
# un BLOQUE con forma de comentario: «**Nombre** · fecha», «Nombre · 2d» o un nombre y, en la línea siguiente, su fecha
_FORMA_COMENTARIO = re.compile(
    r"(?im)^[ \t>*_#\-]*(?:\*\*|__)[^\n*_]{1,80}(?:\*\*|__)[ \t]*(?:[·•|—–\-][ \t]*)?" + _FECHA_COMENTARIO
    + r"|^[ \t>*_#\-]*[^\n·•|]{1,80}[ \t]*[·•][ \t]*" + _FECHA_COMENTARIO
    + r"|^[ \t>*_#\-]*[^\n·•|]{1,80}?[ \t]+" + _FECHA_COMENTARIO + r"[ \t]*$"
    + r"|^[ \t>*_#\-]*[^\n]{1,80}\n(?:[ \t]*\n)?[ \t>*_]*" + _FECHA_COMENTARIO + r"(?:[ \t]*[·•][^\n]*)?[ \t]*$")
VENTANA_FORMA_COMENTARIO = 2500


def cortar_comentarios(texto: Optional[str]) -> Tuple[Optional[str], bool]:
    """Corta el texto ANTES del bloque de comentarios de terceros (si lo hay). Devuelve (texto, se_cortó).

    Solo se aplica al texto de RESPALDO (Exa/Firecrawl), nunca al del proveedor de métricas, y solo corta si el marcador
    («## Comments», «31 comments», «Respuestas:»…) va seguido de al menos un bloque con forma de comentario (nombre +
    fecha o «·»). Una línea «Respuestas:» o un encabezado «## Comentarios» del propio autor, sin comentarios detrás,
    no corta nada."""
    if not texto:
        return texto, False
    for m in _BLOQUE_COMENTARIOS.finditer(texto):
        if not texto[:m.start()].strip():
            continue
        if _FORMA_COMENTARIO.search(texto, m.end(), min(len(texto), m.end() + VENTANA_FORMA_COMENTARIO)):
            return texto[:m.start()].rstrip(), True
    return texto, False


def limpiar_texto_exa(texto: Optional[str]) -> Optional[str]:
    """Quita lo que Exa añade al texto de una página: la línea «# título · fecha», el pie «## Engagement» y el bloque
    de comentarios de terceros."""
    if not texto:
        return None
    t = re.sub(r"^#\s.*?\s·\s\d{4}-\d{2}-\d{2}T[\d:.+Z\-]+\s*\n+", "", texto, count=1)
    t = re.sub(r"\n+## Engagement\b.*\Z", "", t, flags=re.S)
    t = re.split(r"\n+# Thread\n", t, maxsplit=1)[0]          # Threads: tras el post, Exa pega la página entera (con respuestas de terceros)
    t, _ = cortar_comentarios(t)
    return (t or "").strip() or None


def norm_exa(resp: dict) -> List[Dict[str, Any]]:
    return [_cand("exa", r.get("url") or r.get("id"), r.get("title"), limpiar_texto_exa(r.get("text")),
                  r.get("publishedDate"), r.get("author"))
            for r in (resp or {}).get("results", []) if isinstance(r, dict) and (r.get("url") or r.get("id"))]


def norm_brave(resp: dict) -> List[Dict[str, Any]]:
    web = ((resp or {}).get("web") or {}).get("results", [])
    out = []
    for r in web:
        if not isinstance(r, dict) or not r.get("url"):
            continue
        extra = " | ".join(r.get("extra_snippets") or [])
        out.append(_cand("brave", r["url"], r.get("title"), (r.get("description") or "") + (" | " + extra if extra else ""),
                         r.get("page_age") or r.get("age")))
    return out


def norm_perplexity(resp: dict) -> List[Dict[str, Any]]:
    return [_cand("perplexity", r["url"], r.get("title"), r.get("snippet"), r.get("date") or r.get("last_updated"))
            for r in (resp or {}).get("results", []) if isinstance(r, dict) and r.get("url")]


def norm_firecrawl(resp: dict) -> List[Dict[str, Any]]:
    d = (resp or {}).get("data", {})
    web = d.get("web", []) if isinstance(d, dict) else (d if isinstance(d, list) else [])
    return [_cand("firecrawl", r["url"], r.get("title"), r.get("description"), r.get("date"))
            for r in (web or []) if isinstance(r, dict) and r.get("url")]


NORMALIZADORES = {"exa": norm_exa, "brave": norm_brave, "perplexity": norm_perplexity, "firecrawl": norm_firecrawl}


# ---------------------------------------------------------------------------------------------
# C3 · Contraste de métricas
# ---------------------------------------------------------------------------------------------
TOLERANCIA_REL = 0.02
TOLERANCIA_ABS = 5
VENTANA_SIMULTANEAS = 300       # s: dos lecturas más cerca que esto no tienen un orden temporal fiable


def contrastar_valor(anterior: Optional[int], posterior: Optional[int], anterior_sospechosa: bool = False,
                     posterior_sospechosa: bool = False, orden_fiable: bool = True) -> Dict[str, Any]:
    """Contraste de UN campo entre dos lecturas (anterior y posterior en el tiempo).

    contrastado           |dif| <= max(2 %, 5 unidades) Y la lectura posterior >= la anterior (las métricas solo suben).
                          Con `orden_fiable=False` (lecturas a menos de 300 s una de otra) solo cuenta la diferencia.
    discrepante           en otro caso; se conservan los dos valores. El valor de la ficha es el MAYOR (solo suben)
    una_fuente            un valor es None (campo ausente, NO 0)
    sospechoso_descartado una lectura 0 «sin texto» frente a otra > 0: se descarta la sospechosa
    sin_dato              ambos None"""
    vals = {"anterior": anterior, "posterior": posterior}
    if anterior is None and posterior is None:
        return {"estado": "sin_dato", "valor": None, "valores": vals}
    if anterior is None or posterior is None:
        return {"estado": "una_fuente", "valor": posterior if anterior is None else anterior, "valores": vals}
    if anterior_sospechosa and anterior == 0 and posterior > 0:
        return {"estado": "sospechoso_descartado", "valor": posterior, "valores": vals}
    if posterior_sospechosa and posterior == 0 and anterior > 0:
        return {"estado": "sospechoso_descartado", "valor": anterior, "valores": vals}
    tol = max(TOLERANCIA_REL * max(anterior, posterior), TOLERANCIA_ABS)
    if abs(anterior - posterior) <= tol and (posterior >= anterior or not orden_fiable):
        return {"estado": "contrastado", "valor": max(anterior, posterior) if not orden_fiable else posterior,
                "valores": vals}
    return {"estado": "discrepante", "valor": max(anterior, posterior), "valores": vals}


def _ts(valor: Any) -> float:
    t = parse_fecha(valor)
    return t.timestamp() if t else 0.0


def _orden_lecturas(lecturas: List[dict]) -> List[dict]:
    return sorted(lecturas, key=lambda l: (_ts(l.get("consultado")), ORDEN_PROVEEDOR.get(l.get("proveedor"), 9)))


def _orden_fiable(a: dict, b: dict) -> bool:
    """Hay orden temporal fiable entre dos lecturas si distan 300 s o más (y las dos tienen instante)."""
    ta, tb = _ts(a.get("consultado")), _ts(b.get("consultado"))
    return ta > 0 and tb > 0 and abs(tb - ta) >= VENTANA_SIMULTANEAS


def es_cero_sin_texto(l: dict) -> bool:
    return l.get("me_gusta") == 0 and l.get("comentarios") == 0 and not l.get("texto")


def lecturas_sospechosas(lecturas: List[dict]) -> List[dict]:
    """Lecturas «0/0 sin texto» mientras otra lectura da algo > 0: el proveedor devolvió un registro vacío (2 de 11
    lecturas de Bright Data en las pruebas del 14-15 de octubre de 2026). Se descartan COMPLETAS, para todos los campos."""
    ls = [l for l in lecturas if not l.get("error")]
    out = []
    for l in ls:
        if es_cero_sin_texto(l) and any((o.get("me_gusta") or 0) > 0 or (o.get("comentarios") or 0) > 0
                                        for o in ls if o is not l):
            out.append(l)
    return out


def lecturas_cero_sin_confirmar(lecturas: List[dict]) -> List[dict]:
    """Lecturas «0 me gusta, 0 comentarios, sin texto y sin autor» que no son métrica: probablemente un registro vacío
    (página bloqueada). Un 0/0 vacío solo es dato si ALGUNA lectura de la publicación trae texto o autor del proveedor
    de métricas; dos registros vacíos NO se confirman entre sí (ni el texto de respaldo de Exa/Firecrawl lo arregla).
    Si otra lectura da algo > 0 es otro caso (sospechoso_descartado)."""
    ls = [l for l in lecturas if not l.get("error")]
    hay_senal = any(l.get("texto") or l.get("autor") for l in ls)
    out = []
    for l in ls:
        if not (es_cero_sin_texto(l) and not l.get("autor")):
            continue
        mayor = any((o.get("me_gusta") or 0) > 0 or (o.get("comentarios") or 0) > 0 for o in ls if o is not l)
        if not hay_senal and not mayor:
            out.append(l)
    return out


def empresa_de(proveedor: str) -> str:
    """Empresa que hay detrás de una lectura: todas las `apify_*` (búsqueda, hashtag, detalle, Threads…) son Apify;
    `brightdata` es Bright Data. El contraste exige al menos DOS empresas distintas."""
    p = str(proveedor or "")
    return "apify" if p.startswith("apify") else p


def contrastar_campo(lecturas: List[dict], campo: str) -> Dict[str, Any]:
    """Contraste de un campo entre las lecturas de al menos DOS EMPRESAS distintas (en orden temporal): las reglas de C3
    por pares consecutivos. Dos lecturas de la misma empresa cuentan como una (la más reciente) y dan `una_fuente`."""
    ls = _orden_lecturas([l for l in lecturas if not l.get("error")])
    todas = {l["proveedor"]: l.get(campo) for l in ls}
    sin_confirmar = lecturas_cero_sin_confirmar(ls)             # 0/0 sin texto ni autor y nadie lo confirma: no es métrica
    con = [l for l in ls if l.get(campo) is not None and not any(l is x for x in sin_confirmar)]
    if not con:
        return {"estado": "sin_dato", "valor": None, "valores": todas}
    descartadas = [l for l in lecturas_sospechosas(ls) if l in con]
    con = [l for l in con if l not in descartadas]
    if not con:
        return {"estado": "sin_dato", "valor": None, "valores": todas}
    # UNA lectura por EMPRESA: dos lecturas del mismo proveedor (el actor de búsqueda de Apify y el de detalle de Apify,
    # por ejemplo) leen el mismo backend con minutos de diferencia y coinciden casi siempre: no son dos fuentes. La más
    # reciente manda (a igual instante, la mayor, porque las métricas solo suben) y la otra queda como dato.
    por_empresa: Dict[str, dict] = {}
    for l in con:
        e = empresa_de(l["proveedor"])
        previa = por_empresa.get(e)
        if previa is None or (_ts(l.get("consultado")), l[campo]) >= (_ts(previa.get("consultado")), previa[campo]):
            por_empresa[e] = l
    reps = _orden_lecturas(list(por_empresa.values()))
    como_dato = [l["proveedor"] for l in con if not any(l is r for r in reps)]
    info = {"valores": todas, "empresas": sorted(por_empresa), "como_dato": como_dato}
    if len(reps) == 1:
        return {"estado": "sospechoso_descartado" if descartadas else "una_fuente", "valor": reps[0][campo], **info}
    pares = list(zip(reps, reps[1:]))
    if len(reps) >= 3:
        pares.append((reps[0], reps[-1]))     # la deriva encadenada no se cuela: también primera frente a última
    resultados = [contrastar_valor(a[campo], b[campo], orden_fiable=_orden_fiable(a, b)) for a, b in pares]
    if any(r["estado"] == "discrepante" for r in resultados):
        return {"estado": "discrepante", "valor": max(l[campo] for l in reps), **info}
    # contrastado: el mayor (con orden fiable la posterior ya es la mayor; a menos de 300 s no hay orden y el valor
    # no puede depender del nombre del proveedor)
    return {"estado": "contrastado", "valor": max(l[campo] for l in reps), **info}


def contrastar_lecturas(lecturas: List[dict]) -> Dict[str, Any]:
    campos = {"me_gusta": "me_gusta", "comentarios": "comentarios", "compartidos": "compartidos", "vistas": "vistas"}
    return {nombre: contrastar_campo(lecturas, campo) for nombre, campo in campos.items()}


def estado_metricas(contraste: Dict[str, Any]) -> str:
    """Estado de la ficha. discrepante > una_fuente (incluye el descarte de una lectura sospechosa) > contrastado."""
    clave_ = [contraste[c]["estado"] for c in ("me_gusta", "comentarios")]
    if all(e == "sin_dato" for e in clave_):
        return "sin_metricas"
    if "discrepante" in clave_:
        return "discrepante"
    if any(e in ("una_fuente", "sospechoso_descartado", "sin_dato") for e in clave_):
        return "una_fuente"
    return "contrastado"


# ---------------------------------------------------------------------------------------------
# Sesión de una investigación: tope, libro, caché, uso y cobertura
# ---------------------------------------------------------------------------------------------
MOTIVOS_DESCARTE = ("no_es_publicacion", "duplicado", "idioma", "relleno", "tope_por_autor", "fuera_de_ventana")


def nueva_cobertura() -> Dict[str, Any]:
    return {"motores": {}, "descartes": {m: 0 for m in MOTIVOS_DESCARTE}, "descartados": [], "paradas": [],
            "avisos": [], "coste_usd": 0.0, "arranques_fallidos": 0}


def _eventos_cobrados(contadores: Any) -> int:
    """Eventos cobrados por resultado (todos menos el de arranque) que Apify declara en `chargedEventCounts`."""
    if not isinstance(contadores, dict):
        return 0
    return sum(int(v) for k, v in contadores.items() if "start" not in str(k).lower() and isinstance(v, (int, float))
               and not isinstance(v, bool))


def _entero(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def _lista_de_textos(v: Any) -> bool:
    return isinstance(v, list) and bool(v) and all(isinstance(x, str) and x.strip() for x in v)


def validar_entrada(actor: str, entrada: dict) -> None:
    """Solo se lanzan entradas ya probadas: claves y valores de la tabla ACTORES; lo demás, error ANTES de llamar."""
    ficha = ACTORES.get(actor)
    if ficha is None:
        raise EntradaNoProbada(f"Actor no admitido: {actor}.")
    extra = set(entrada) - ficha["claves"]
    if extra:
        aviso = ""
        if actor == ACTOR_THREADS and "search_language" in extra:
            aviso = " " + SIN_SEARCH_LANGUAGE + "."
        raise EntradaNoProbada(f"{actor}: parámetros no probados {sorted(extra)}. Pruébalos aparte, con tope, antes "
                               f"de añadirlos a ACTORES.{aviso}")
    for k, validos in ficha["valores"].items():
        if k in entrada and entrada[k] not in validos:
            raise EntradaNoProbada(f"{actor}: {k}={entrada[k]!r} no está entre los valores aceptados {sorted(validos)}.")
    for k, probados in ficha.get("probados_en_vivo", {}).items():
        if k in entrada and entrada[k] not in probados:
            raise EntradaNoProbada(f"{actor}: {k}={entrada[k]!r} lo admite el esquema pero no se ha probado en vivo "
                                   f"(probados: {sorted(probados)}). Pruébalo aparte, con tope, antes de usarlo.")
    if actor == ACTOR_FB_BUSQUEDA:
        if not _lista_de_textos(entrada.get("categories")):
            raise EntradaNoProbada(f"{actor}: categories debe ser una lista de textos no vacíos.")
        if "searchType" not in entrada or not _entero(entrada.get("resultsLimit")) or entrada["resultsLimit"] < 1:
            raise EntradaNoProbada(f"{actor}: hace falta searchType y resultsLimit (entero >= 1).")
    elif actor == ACTOR_IG_BUSQUEDA:
        if not (isinstance(entrada.get("search"), str) and entrada["search"].strip()):
            raise EntradaNoProbada(f"{actor}: search debe ser un texto no vacío.")
        if "searchType" not in entrada or not _entero(entrada.get("searchLimit")) or entrada["searchLimit"] < 1:
            raise EntradaNoProbada(f"{actor}: hace falta searchType y searchLimit (entero >= 1).")
    elif actor == ACTOR_IG:
        urls = entrada.get("directUrls")
        if not _lista_de_textos(urls):
            raise EntradaNoProbada(f"{actor}: directUrls debe ser una lista de URL no vacía.")
        tipo = entrada.get("resultsType")
        if tipo not in ("posts", "details") or not _entero(entrada.get("resultsLimit")) or entrada["resultsLimit"] < 1:
            raise EntradaNoProbada(f"{actor}: hace falta resultsType («posts» o «details») y resultsLimit (entero >= 1).")
        for u in urls:
            if tipo == "details" and not (parsear_url(u) or {}).get("red") == "instagram":
                raise EntradaNoProbada(f"{actor}: «details» solo se prueba con URL de publicación (/p/, /reel/, /tv/): {u!r}.")
            if tipo == "posts" and "/explore/tags/" not in u:
                raise EntradaNoProbada(f"{actor}: «posts» solo se prueba con la página de un hashtag (/explore/tags/…): {u!r}.")
    elif actor == ACTOR_THREADS:
        if entrada.get("mode") != "search":
            raise EntradaNoProbada(f"{actor}: solo se prueba mode «search».")
        kws = entrada.get("keywords")
        if not _lista_de_textos(kws):
            raise EntradaNoProbada(f"{actor}: keywords debe ser una lista de textos no vacíos.")
        if len(kws) > MAX_PALABRAS_EJECUCION_THREADS:
            raise EntradaNoProbada(f"{actor}: como mucho {MAX_PALABRAS_EJECUCION_THREADS} palabras clave por ejecución (lo "
                                   "probado en vivo con search_filter «top»); más no se ha medido y cada ejecución cobra "
                                   "0,08 USD de arranque.")
        for kw in kws:
            if len(kw.split()) > MAX_PALABRAS_THREADS or len(kw) > 40:
                raise EntradaNoProbada(f"{actor}: palabras clave CORTAS (como mucho {MAX_PALABRAS_THREADS} palabras): "
                                       f"{kw!r}. Las frases largas no dan resultados (3 de 4 «no_results» en el piloto) y "
                                       "cada ejecución cobra 0,08 USD de arranque.")
        if not _entero(entrada.get("max_posts")) or entrada["max_posts"] < UMBRAL_THREADS_MAX_POSTS:
            raise EntradaNoProbada(f"{actor}: max_posts debe ser un entero >= {UMBRAL_THREADS_MAX_POSTS}.")


def posts_de_entrada(actor: str, entrada: dict) -> int:
    """Resultados máximos que una entrada puede producir (cota de coste). En Threads max_posts es POR palabra clave."""
    if actor == ACTOR_FB_BUSQUEDA:
        return int(entrada.get("resultsLimit") or 0)
    if actor == ACTOR_IG_BUSQUEDA:
        return int(entrada.get("searchLimit") or 0)
    if actor == ACTOR_IG:
        return len(entrada.get("directUrls") or []) * int(entrada.get("resultsLimit") or 1)
    if actor == ACTOR_THREADS:
        return len(entrada.get("keywords") or []) * int(entrada.get("max_posts") or UMBRAL_THREADS_MAX_POSTS)
    return 0


def cota_minima(actor: str, entrada: dict) -> float:
    """Cota mínima con la que merece la pena lanzar: el mínimo que declara el actor y, en Threads (arranque fijo de
    0,08 USD por ejecución), arranque + posts × precio. Por debajo, la ejecución se aborta tras cobrar el arranque."""
    ficha = ACTORES[actor]
    if actor == ACTOR_THREADS:
        return round(ficha["arranque"] + posts_de_entrada(actor, entrada) * ficha["precio_item"], 6)
    return ficha["minimo_tope"]


def cota_estimada(actor: str, entrada: dict) -> float:
    ficha = ACTORES[actor]
    return round(ficha["arranque"] + posts_de_entrada(actor, entrada) * ficha["precio_item"], 6)


def mensaje_cota_minima(actor: str, cota: float, minimo: float) -> str:
    if actor == ACTOR_THREADS:
        return (f"No se lanza {actor}: Threads cobra {ACTORES[actor]['arranque']:.2f} USD fijos por ejecución más "
                f"{ACTORES[actor]['precio_item']} por post y esta consulta necesita al menos {minimo:.4f} USD, pero el tope de la "
                f"llamada es {cota:.4f}. Sube --tope-usd o reduce las palabras clave (en el piloto se perdieron 0,24 USD "
                "en ejecuciones abortadas por un tope bajo).")
    return (f"El tope de la llamada ({cota:.4f} USD) es menor que el mínimo del actor ({minimo} USD): no se lanza.")


def recencia_para(desde: Optional[str], hoy: Optional[dt.datetime] = None) -> str:
    """d | w | m | y (o '' si no hay ventana) para los buscadores."""
    d = parse_dia(desde)
    if d is None:
        return ""
    dias = ((hoy or ahora_utc()) - d).days
    return "d" if dias <= 1 else "w" if dias <= 7 else "m" if dias <= 31 else "y"



# ---------------------------------------------------------------------------------------------
# Llamadas en vuelo y señales (SIGTERM/SIGINT): una reserva nunca queda colgada si matan el proceso
# ---------------------------------------------------------------------------------------------
_EN_VUELO: Dict[str, Tuple["Libro", str, float, str]] = {}
_EN_VUELO_LOCK = threading.Lock()
_CERRANDO = threading.Event()        # se activa al recibir una señal de cierre: `reservar` rechaza reservas nuevas
_RUNS_APIFY: Dict[str, Dict[str, str]] = {}       # ejecuciones de Apify vivas de este proceso → cabeceras para abortarlas


def _en_vuelo_alta(rid: str, libro: "Libro", investigacion: str, cota: float, proveedor: str) -> None:
    with _EN_VUELO_LOCK:
        _EN_VUELO[rid] = (libro, investigacion, cota, proveedor)


def _en_vuelo_baja(rid: str) -> None:
    with _EN_VUELO_LOCK:
        _EN_VUELO.pop(rid, None)


def _run_alta(run_id: str, cabeceras: Dict[str, str]) -> None:
    with _EN_VUELO_LOCK:
        _RUNS_APIFY[run_id] = cabeceras


def _run_baja(run_id: str) -> None:
    with _EN_VUELO_LOCK:
        _RUNS_APIFY.pop(run_id, None)


ESTADOS_FINALES_APIFY = ("SUCCEEDED", "FAILED", "ABORTED", "TIMED-OUT")
LECTURAS_CONFIRMAR_ABORTO = 4


def _abortar_y_confirmar(run_id: str, cabeceras: Dict[str, str]) -> Optional[Dict[str, Any]]:
    """Pide el aborto de una ejecución de Apify y lee su estado hasta verlo FINAL. Devuelve los datos de la ejecución
    con estado final confirmado, o None si no se pudo confirmar (sigue pudiendo cobrar: coste desconocido)."""
    base = f"https://api.apify.com/v2/actor-runs/{run_id}"
    st, j = http_tras_envio("POST", base + "/abort", None, cabeceras)
    datos = j.get("data") if st == 200 and isinstance(j, dict) else None
    if isinstance(datos, dict) and datos.get("status") in ESTADOS_FINALES_APIFY:
        return datos
    for i in range(LECTURAS_CONFIRMAR_ABORTO):
        if i:
            time.sleep(PAUSA_POLL)
        st2, j2 = http_tras_envio("GET", base, None, cabeceras)
        datos = j2.get("data") if st2 == 200 and isinstance(j2, dict) else None
        if isinstance(datos, dict) and datos.get("status") in ESTADOS_FINALES_APIFY:
            return datos
    return None


def abortar_runs_conocidos(espera: float = 3.0) -> int:
    """Mejor esfuerzo: aborta las ejecuciones de Apify de este proceso que sigan vivas, para no seguir gastando tras
    una interrupción. Acotado en tiempo (hilo + espera); nunca bloquea el cierre. Devuelve cuántas intentó."""
    tomado = _EN_VUELO_LOCK.acquire(timeout=1)
    try:
        runs = dict(_RUNS_APIFY)
    finally:
        if tomado:
            _EN_VUELO_LOCK.release()
    def abortar(run_id: str, cab: Dict[str, str]) -> None:
        try:
            http("POST", f"https://api.apify.com/v2/actor-runs/{run_id}/abort", None, cab, timeout=2)
        except Exception:  # noqa: BLE001 - de mejor esfuerzo
            pass

    hilos = []
    for run_id, cab in runs.items():
        h = threading.Thread(target=abortar, args=(run_id, cab), daemon=True)
        h.start()
        hilos.append(h)
    limite = time.time() + espera
    for h in hilos:
        h.join(max(0.0, limite - time.time()))
    return len(runs)


def cerrar_en_vuelo(estado: str = "interrumpida") -> int:
    """Marca el proceso como «cerrando» y liquida toda reserva en vuelo, todo bajo el cerrojo del libro del proceso:
    `Libro.reservar` toma ese mismo cerrojo, así que una reserva o está ya en el registro en vuelo (y se liquida aquí)
    o llega después y se rechaza. Si otro hilo tiene el cerrojo esperando al del fichero, no se espera más de 2 s."""
    tomado = _LOCK_PROCESO.acquire(timeout=2)
    try:
        _CERRANDO.set()
        return liquidar_en_vuelo(estado)
    finally:
        if tomado:
            _LOCK_PROCESO.release()


def liquidar_en_vuelo(estado: str = "interrumpida") -> int:
    """Liquida POR SU COTA ENTERA (conservador) toda reserva de este proceso que siga en vuelo. Devuelve cuántas."""
    tomado = _EN_VUELO_LOCK.acquire(timeout=2)       # si la señal llegó con el cerrojo tomado, se sigue sin él
    try:
        pendientes = list(_EN_VUELO.items())
        _EN_VUELO.clear()
    finally:
        if tomado:
            _EN_VUELO_LOCK.release()
    n = 0
    for rid, (libro, inv, cota, prov) in pendientes:
        try:
            libro.liquidar_sin_bloqueo(rid, inv, cota, estado, proveedor=prov)
            n += 1
        except OSError:
            pass
    return n


def _al_recibir_senal(signum: int, frame: Any) -> None:
    n = cerrar_en_vuelo("interrumpida")
    try:
        abortar_runs_conocidos()
    except Exception:  # noqa: BLE001 - abortar es de mejor esfuerzo
        pass
    try:
        print(f"Interrumpido (señal {signum}): {n} llamada(s) en vuelo liquidada(s) por su cota entera (conservador). "
              "Mira `libro --ver`.", file=sys.stderr)
        sys.stderr.flush()
        sys.stdout.flush()
    except Exception:  # noqa: BLE001
        pass
    os._exit(128 + signum)


def instalar_senales() -> Dict[int, Any]:
    """Instala el manejador de SIGTERM, SIGINT, SIGHUP y SIGQUIT (los que existan; solo en el hilo principal). Devuelve
    los manejadores anteriores. Un SIGHUP que ya se ignora (nohup) se respeta: el proceso debe sobrevivir al cierre de
    la terminal si quien lo lanzó lo pidió."""
    previos: Dict[int, Any] = {}
    for nombre in ("SIGTERM", "SIGINT", "SIGHUP", "SIGQUIT"):
        sig = getattr(signal, nombre, None)
        if sig is None:
            continue
        try:
            if nombre == "SIGHUP" and signal.getsignal(sig) == signal.SIG_IGN:
                continue
            previos[sig] = signal.signal(sig, _al_recibir_senal)
        except (ValueError, OSError):
            pass
    return previos


def restaurar_senales(previos: Dict[int, Any]) -> None:
    for sig, h in previos.items():
        try:
            signal.signal(sig, h if h is not None else signal.SIG_DFL)
        except (ValueError, OSError):
            pass


# ---------------------------------------------------------------------------------------------
# Caché de respuestas: solo los campos que el skill usa, 0700/0600 y un día de vida
# ---------------------------------------------------------------------------------------------
CACHE_VIDA_S = 86400
CACHE_FORMATO = "meta-search-cache-3"      # 3: la caché guarda también `isCommentsDisabled` (las entradas de 2 no se sirven)
_FORMATOS_PROPIOS = ("meta-search-cache-2", CACHE_FORMATO)      # marcadores que SOLO escribe este skill dentro de sus ficheros
PREFIJO_CACHE = "meta-search-"             # prefijo de nombre exclusivo de este skill (no lo usa ninguna otra caché)
_T = True                                  # un valor escalar (texto, número, booleano o nulo); cualquier otra cosa se descarta
CAMPOS_CACHE: Dict[str, Any] = {
    # lo que leen norm_fb_busqueda, _norm_ig, norm_threads, norm_brightdata_facebook y norm_brightdata_instagram; el
    # resto del registro (comentarios de terceros, biografías, correos, fotos, IDs de propietario…) no se guarda
    ACTOR_FB_BUSQUEDA: {"url": _T, "postId": _T, "legacyId": _T, "text": _T, "likes": _T, "comments": _T, "shares": _T,
                        "time": _T, "user": {"name": _T}, "pageName": {"name": _T}},
    ACTOR_IG: {"shortCode": _T, "inputUrl": _T, "error": _T, "errorDescription": _T, "likesCount": _T,
               "videoPlayCount": _T, "videoViewCount": _T, "url": _T, "caption": _T, "ownerUsername": _T,
               "ownerFullName": _T, "commentsCount": _T, "isCommentsDisabled": _T, "timestamp": _T},
    ACTOR_THREADS: {"record_type": _T, "post_code": _T, "post_url": _T, "text_content": _T, "username": _T,
                    "like_count": _T, "reply_count": _T, "share_count": _T, "view_count": _T, "view_count_status": _T,
                    "created_at": _T, "search_keyword": _T, "is_reply": _T, "is_repost": _T, "repost_count": _T,
                    "quote_count": _T},
    "brightdata:facebook": {"timestamp": _T, "post_id": _T, "url": _T, "input": "entrada", "content": _T,
                            "user_username_raw": _T, "num_likes_type": [{"type": _T, "num": _T}], "likes": _T,
                            "num_comments": _T, "num_shares": _T, "date_posted": _T, "error": _T, "error_code": _T},
    "brightdata:instagram": {"timestamp": _T, "shortcode": _T, "url": _T, "input": "entrada", "description": _T,
                             "user_posted": _T, "likes": _T, "num_comments": _T, "date_posted": _T, "error": _T,
                             "error_code": _T},
}
CAMPOS_CACHE[ACTOR_IG_BUSQUEDA] = CAMPOS_CACHE[ACTOR_IG]


def _proyectar(valor: Any, esquema: Any) -> Any:
    if esquema is True:
        return valor if valor is None or isinstance(valor, (str, int, float, bool)) else None
    if esquema == "entrada":                    # `input` de Bright Data: {"url": …} o la propia URL
        if isinstance(valor, dict):
            return {"url": valor.get("url") if isinstance(valor.get("url"), str) else None}
        return valor if isinstance(valor, str) else None
    if isinstance(esquema, dict):
        if not isinstance(valor, dict):
            return None
        return {k: _proyectar(valor[k], sub) for k, sub in esquema.items() if k in valor}
    if isinstance(esquema, list):
        return [_proyectar(v, esquema[0]) for v in valor] if isinstance(valor, list) else None
    return None


def proyectar_items(items: Any, clave_esquema: str) -> List[Any]:
    """Los ítems de un proveedor reducidos a los campos que el skill lee (CAMPOS_CACHE[clave_esquema])."""
    esquema = CAMPOS_CACHE[clave_esquema]
    return [_proyectar(it, esquema) for it in (items if isinstance(items, list) else []) if isinstance(it, dict)]


_NOMBRES_CACHE = "exa|brave|perplexity|firecrawl|apify|brightdata"
_RE_CACHE_PROPIA = re.compile(r"%s(?:%s)-[0-9a-f]{24}\.json(?:\.tmp)?" % (re.escape(PREFIJO_CACHE), _NOMBRES_CACHE))
_RE_CACHE_V2 = re.compile(r"(?:%s)-v2-[0-9a-f]{24}\.json(?:\.tmp)?" % _NOMBRES_CACHE)


def _lleva_marcador_propio(f: Path) -> bool:
    """True si el fichero declara, en su cabecera, un formato de caché de ESTE skill (`"formato": "meta-search-cache-N"`).
    Se lee solo el principio: el marcador va primero al escribirlo."""
    try:
        with open(f, "rb") as fh:
            cabecera = fh.read(160).decode("utf-8", "ignore")
    except OSError:
        return False
    return any('"formato": "%s"' % m in cabecera for m in _FORMATOS_PROPIOS)


def _es_cache_propia(f: Path) -> bool:
    """Un fichero es de este skill solo si NO hay duda: el prefijo de nombre exclusivo (`meta-search-…`) o, en el nombre
    del formato 2 (`{proveedor}-v2-{hash}.json`), el marcador de formato dentro del fichero. Un nombre `{proveedor}-{hash}.json`
    (el de la versión 1.0.0) lo usan también otros skills: no se atribuye, no se toca."""
    if _RE_CACHE_PROPIA.fullmatch(f.name):
        return True
    return _RE_CACHE_V2.fullmatch(f.name) is not None and _lleva_marcador_propio(f)


def purgar_cache(max_edad: float = CACHE_VIDA_S) -> int:
    """Borra de la carpeta de caché SOLO ficheros del propio skill (ver `_es_cache_propia`) y SOLO los caducados (más de un
    día) o los de un formato anterior al vigente. Un fichero de nombre ambiguo, de otro skill o del usuario no se toca.
    Deja la carpeta en 0700. Devuelve cuántos borró."""
    d = dir_cache()
    if not d.is_dir():
        return 0
    try:
        os.chmod(d, 0o700)
    except OSError:
        pass
    ahora, n = time.time(), 0
    for f in d.iterdir():
        try:
            if not f.is_file() or f.is_symlink() or not _es_cache_propia(f):
                continue
            anterior = _RE_CACHE_V2.fullmatch(f.name) is not None      # formato 2: ya no se sirve; se retira aunque no caduque
            if anterior or ahora - f.stat().st_mtime > max_edad:
                f.unlink()
                n += 1
        except OSError:
            continue
    return n


def _de_cache(en_cache: Dict[str, Any]) -> Dict[str, Any]:
    """Una ejecución servida de la caché no gasta nada en ESTA ejecución: su coste es 0 y el de la ejecución original se
    conserva aparte (`coste_original_usd`) solo como dato; la cobertura la marca «de caché»."""
    return {**en_cache, "coste_original_usd": en_cache.get("coste_usd"), "coste_usd": 0.0, "cache": True}


class Sesion:
    def __init__(self, salida: Optional[Path] = None, tope_total: float = 1.5, tope_llamada: float = 0.5,
                 usar_cache: bool = True, investigacion: Optional[str] = None, libro: Optional[Libro] = None):
        self.salida = Path(salida) if salida else None
        self.tope_total = float(tope_total)
        self.tope_llamada = float(tope_llamada)
        self.usar_cache = usar_cache
        if investigacion:
            self.investigacion = investigacion
        elif self.salida is not None:
            self.investigacion = str(self.salida.resolve())
        else:
            self.investigacion = "sin-salida"
        self.libro = libro or Libro()
        self.cobertura = nueva_cobertura()
        self._candado = threading.Lock()
        if usar_cache:
            try:
                purgar_cache()
            except (OSError, MetaSearchError):
                pass
        self.inicio = iso_local()
        self.id_sesion = f"{self.inicio}-{os.urandom(3).hex()}"
        # cortacircuitos: proveedor → (clase, mensaje, alternativa) tras un límite o una clave rechazada
        self.parados: Dict[str, Tuple[type, str, str]] = {}

    # -- salida y registros --------------------------------------------------------------------
    def volcar(self, alm: "Almacen") -> None:
        """Deja en registros.json la cobertura de ESTA ejecución (proveedores, paradas, avisos, coste) para que la
        entrega de `citas`, aunque corra en otro proceso, declare la de toda la investigación (C2)."""
        with self._candado:
            c = self.cobertura
            foto = {"inicio": self.inicio, "investigacion": self.investigacion, "coste_usd": c["coste_usd"],
                    "motores": copy.deepcopy(c["motores"]), "paradas": copy.deepcopy(c["paradas"]),
                    "avisos": list(c["avisos"]), "arranques_fallidos": c["arranques_fallidos"]}
        alm.meta.setdefault("sesiones", {})[self.id_sesion] = foto

    def exigir_salida(self) -> Path:
        if self.salida is None:
            raise MetaSearchError("Falta --salida DIR (carpeta de trabajo): el skill nunca escribe en el "
                                      "directorio actual.")
        self.salida.mkdir(parents=True, exist_ok=True)
        return self.salida

    def uso(self, fila: dict) -> None:
        if self.salida is None:
            return
        self.salida.mkdir(parents=True, exist_ok=True)
        with open(self.salida / "uso.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps({"fecha": iso_local(), **fila}, ensure_ascii=False, default=str) + "\n")

    # -- caché ---------------------------------------------------------------------------------
    # La caché guarda SOLO lo que el skill lee de cada respuesta (ver CAMPOS_CACHE y proyectar_items): nunca el crudo del
    # proveedor. Carpeta 0700, ficheros 0600, caducidad de un día (se purga al abrir una sesión con caché).
    def _ruta_cache(self, proveedor: str, params: Any) -> Path:
        dia = dt.datetime.now().strftime("%Y-%m-%d")
        h = hashlib.sha256(json.dumps([proveedor, params, dia], sort_keys=True, default=str).encode()).hexdigest()
        return dir_cache() / f"{PREFIJO_CACHE}{proveedor}-{h[:24]}.json"

    def cache_leer(self, proveedor: str, params: Any) -> Optional[Any]:
        if not self.usar_cache:
            return None
        ruta = self._ruta_cache(proveedor, params)
        try:
            if time.time() - ruta.stat().st_mtime > CACHE_VIDA_S:
                return None
        except OSError:
            return None
        dato = leer_json(ruta)
        return dato.get("datos") if isinstance(dato, dict) and dato.get("formato") == CACHE_FORMATO else None

    def cache_guardar(self, proveedor: str, params: Any, datos: Any) -> None:
        if not self.usar_cache:
            return
        try:
            escribir_privado(self._ruta_cache(proveedor, params),
                             json.dumps({"formato": CACHE_FORMATO, "creada": iso_local(), "datos": datos},
                                        ensure_ascii=False, indent=1, default=str))
        except OSError:
            pass

    def _sumar(self, coste: float) -> None:
        with self._candado:
            self.cobertura["coste_usd"] = round(self.cobertura["coste_usd"] + coste, 7)

    # -- cortacircuitos ------------------------------------------------------------------------
    def _parar(self, proveedor: str, e: Exception) -> None:
        """Tras un límite o una clave rechazada, ese proveedor no se vuelve a llamar en esta sesión."""
        with self._candado:
            self.parados.setdefault(proveedor, (type(e), str(e), getattr(e, "alternativa", "") or ""))

    def _comprobar(self, proveedor: str) -> None:
        """Si el proveedor ya paró en esta sesión, vuelve a parar SIN red y con el mismo motivo."""
        p = self.parados.get(proveedor)
        if p is None:
            return
        clase, mensaje, alternativa = p
        if clase is ClaveRechazada:
            raise ClaveRechazada(proveedor, mensaje)
        raise LimiteAlcanzado(proveedor, mensaje, alternativa)

    def _parar_por_desconocido(self, proveedor: str, mensaje: str) -> None:
        """Tras un resultado_desconocido ese proveedor no se vuelve a llamar en esta sesión: repetir el POST podría
        crear (y cobrar) otra ejecución o registro."""
        with self._candado:
            self.parados.setdefault(proveedor, (ResultadoDesconocido, mensaje + " Parado el resto de la sesión para "
                                                "no repetir la petición.",
                                                "Mira la consola del proveedor y repite el comando solo cuando sepas "
                                                "qué pasó con esa petición."))

    def _liquidar(self, rid: str, coste: float, estado: str, proveedor: str, **extra: Any) -> None:
        self.libro.liquidar(rid, self.investigacion, coste, estado, proveedor=proveedor, **extra)
        _en_vuelo_baja(rid)

    # -- C1: reservar → llamar → liquidar ------------------------------------------------------
    def pagada(self, proveedor: str, concepto: str, cota: float,
               hacer: Callable[[], Tuple[int, Any, float, str]], max_reintentos: int = 2) -> Tuple[int, Any, float]:
        """Ejecuta una llamada de pago bajo el libro único. `hacer()` → (estado_http, datos, coste_real, etiqueta).

        Reserva `cota` ANTES; liquida con el coste real DESPUÉS (también si falla). Ante un límite (402/429/cuenta
        inactiva/actor deshabilitado) o una clave rechazada PARA sin reintentar, y esa parada vale para el resto de la
        sesión (cortacircuitos). Solo reintenta fallos transitorios (red, 5xx), máximo `max_reintentos`; cada intento
        reserva y liquida por separado. Si `hacer()` lanza ResultadoDesconocido se liquida la cota ENTERA."""
        ultimo: Tuple[int, Any] = (0, None)
        for intento in range(max_reintentos + 1):
            self._comprobar(proveedor)
            if cota > self.tope_llamada + 1e-9:
                raise PresupuestoAgotado(f"No se lanza {PROVEEDORES[proveedor]['nombre']} ({concepto}): la cota de la "
                                         f"llamada ({cota:.4f} USD) supera el tope por llamada ({self.tope_llamada:.2f} USD).")
            rid = self.libro.reservar(self.investigacion, self.tope_total, proveedor, concepto, cota, en_vuelo=True)
            try:
                estado, datos, coste, etiqueta = hacer()
            except PeticionNoEnviada:
                # el fallo fue LOCAL y anterior al envío: no salió nada, no hay nada que cobrar
                self._liquidar(rid, 0.0, "no_enviada", proveedor)
                raise ClaveMalFormada(proveedor) from None
            except BaseException as e:
                if isinstance(e, (LimiteAlcanzado, ClaveRechazada)):
                    self._parar(proveedor, e)
                if isinstance(e, ResultadoDesconocido):
                    self._parar_por_desconocido(proveedor, str(e))
                    self._liquidar(rid, cota, "resultado_desconocido", proveedor, **e.extra)
                else:
                    self._liquidar(rid, cota, "excepcion", proveedor)
                self._sumar(cota)
                raise
            try:
                clasificar(estado, datos, proveedor)
            except (LimiteAlcanzado, ClaveRechazada) as e:
                self._parar(proveedor, e)
                self._liquidar(rid, coste, "rechazada", proveedor)
                self._sumar(coste)
                raise
            if es_transitorio(estado):
                # La petición salió y la respuesta se perdió (red) o falló en el servidor (5xx): el proveedor PUDO
                # cobrarla. Se liquida la cota entera (conservador); nunca 0.
                coste = max(coste, cota)
                self._liquidar(rid, coste, "respuesta_perdida", proveedor)
                self._sumar(coste)
                ultimo = (estado, datos)
                if intento < max_reintentos:
                    time.sleep(PAUSA_REINTENTO)
                continue
            if estado >= 400:
                self._liquidar(rid, coste, "error_http", proveedor)
                self._sumar(coste)
                raise MetaSearchError(f"{PROVEEDORES[proveedor]['nombre']} respondió HTTP {estado}: "
                                          f"{limpiar_control(redactar(json.dumps(datos, ensure_ascii=False, default=str)))[:240]}")
            self._liquidar(rid, coste, etiqueta, proveedor)
            self._sumar(coste)
            if etiqueta == "resultado_desconocido":
                self._parar_por_desconocido(proveedor, f"{PROVEEDORES[proveedor]['nombre']}: resultado desconocido "
                                                       "(ver el aviso de la cobertura).")
            return estado, datos, coste
        mensaje = (f"{PROVEEDORES[proveedor]['nombre']} no respondió tras {max_reintentos + 1} intentos (último estado "
                   f"{ultimo[0]}); cada intento se liquidó por su cota: "
                   f"{limpiar_control(redactar(str(ultimo[1])))[:200]}")
        with self._candado:         # sin respuesta repetida: no se sigue gastando cotas en ese proveedor esta sesión
            self.parados.setdefault(proveedor, (LimiteAlcanzado, mensaje + " Parado el resto de la sesión.",
                                                _ALTERNATIVAS.get(proveedor, "")))
        raise MetaSearchError(mensaje)

    # -- buscadores ----------------------------------------------------------------------------
    def buscar(self, motor: str, consulta: str, n: int = 10, desde: Optional[str] = None,
               hasta: Optional[str] = None, red: str = "instagram",
               hoy: Optional[dt.datetime] = None) -> Tuple[List[Dict[str, Any]], float]:
        """Una búsqueda en un motor, limitada a los dominios de una red. Devuelve (candidatos normalizados, coste real)."""
        if red not in DOMINIOS:
            raise MetaSearchError(f"Red desconocida: {red}. Opciones: {', '.join(REDES)}.")
        tok = clave(motor)
        rec = recencia_para(desde, hoy)
        n = max(1, min(n, 10))
        dominios = DOMINIOS[red]
        sitios = " OR ".join("site:" + d for d in dominios)
        params = {"c": consulta, "n": n, "desde": desde, "hasta": hasta, "red": red}
        en_cache = self.cache_leer(motor, params)
        if isinstance(en_cache, list) and all(isinstance(c, dict) and c.get("url") for c in en_cache):
            return en_cache, 0.0           # la caché guarda los candidatos ya normalizados, no la respuesta cruda
        if motor == "exa":
            cuerpo: Dict[str, Any] = {"query": consulta, "numResults": n, "includeDomains": dominios,
                                      "contents": {"text": {"maxCharacters": 1500}}}
            if desde:
                cuerpo["startPublishedDate"] = desde + "T00:00:00.000Z"
            if hasta:
                cuerpo["endPublishedDate"] = hasta + "T00:00:00.000Z"
            pet = ("POST", "https://api.exa.ai/search", cuerpo, {"x-api-key": tok})
        elif motor == "perplexity":
            cuerpo = {"query": consulta, "max_results": n, "search_domain_filter": dominios}
            if rec:
                cuerpo["search_recency_filter"] = {"d": "day", "w": "week", "m": "month", "y": "year"}[rec]
            pet = ("POST", "https://api.perplexity.ai/search", cuerpo, {"Authorization": "Bearer " + tok})
        elif motor == "firecrawl":
            cuerpo = {"query": consulta + " " + sitios, "limit": n}
            if rec:
                cuerpo["tbs"] = "qdr:" + rec
            pet = ("POST", "https://api.firecrawl.dev/v2/search", cuerpo, {"Authorization": "Bearer " + tok})
        elif motor == "brave":
            p = {"q": consulta + " " + sitios, "count": n, "extra_snippets": "true"}
            if rec:
                p["freshness"] = {"d": "pd", "w": "pw", "m": "pm", "y": "py"}[rec]
            pet = ("GET", "https://api.search.brave.com/res/v1/web/search?" + urllib.parse.urlencode(p), None,
                   {"X-Subscription-Token": tok, "Accept": "application/json"})
        else:
            raise MetaSearchError(f"Motor desconocido: {motor}")

        def hacer() -> Tuple[int, Any, float, str]:
            t0 = time.time()
            st, j = http(pet[0], pet[1], pet[2], pet[3])
            coste = 0.0
            if st == 200:
                coste = PRECIO_LLAMADA[motor]
                if motor == "exa" and isinstance(j, dict):
                    real = (j.get("costDollars") or {}).get("total")
                    if isinstance(real, (int, float)):
                        coste = float(real)
            self.uso({"proveedor": motor, "concepto": "busqueda", "red": red, "consulta": consulta, "http": st,
                      "coste_usd": coste, "segundos": round(time.time() - t0, 1)})
            return st, j, coste, "ok"

        st, j, coste = self.pagada(motor, f"busqueda:{red}:{consulta[:60]}", PRECIO_LLAMADA[motor], hacer)
        if not isinstance(j, dict):
            raise MetaSearchError(f"{PROVEEDORES[motor]['nombre']} devolvió una respuesta inesperada.")
        candidatos = NORMALIZADORES[motor](j)
        self.cache_guardar(motor, params, candidatos)
        return candidatos, coste
    # -- Apify ---------------------------------------------------------------------------------
    def apify_margen(self, cota: float) -> Optional[str]:
        """Lee el uso del mes (consulta de límites de Apify; gratis). Lanza PresupuestoAgotado si no deja margen.
        Devuelve un aviso si el uso no se pudo leer (no bloquea: el tope por llamada y el total siguen vigentes)."""
        self._comprobar("apify")
        tok = clave("apify")
        st, j = http("GET", APIFY_LIMITES, None, {"Authorization": "Bearer " + tok})
        try:
            clasificar(st, j, "apify")
        except (LimiteAlcanzado, ClaveRechazada) as e:
            self._parar("apify", e)
            raise
        d = (j or {}).get("data") if isinstance(j, dict) else None
        try:
            tope = float(d["limits"]["maxMonthlyUsageUsd"])
            usado = float(d["current"]["monthlyUsageUsd"])
        except (TypeError, KeyError, ValueError):
            return "No se pudo leer el uso mensual de Apify; se sigue con el tope por llamada y el total."
        if usado + cota > tope + 1e-9:
            raise PresupuestoAgotado(f"Apify: uso del mes {usado:.4f} USD + esta llamada {cota:.4f} > límite mensual "
                                     f"{tope:.2f} USD. No se lanza (no se compra saldo ni se cambia de plan).")
        return None

    def apify_ejecutar(self, actor: str, entrada: dict, cota: float, posts_estimados: int) -> Dict[str, Any]:
        """Ejecuta un actor ya probado con tope duro (maxTotalChargeUsd = cota) y liquida con el coste REAL.

        El POST que crea la ejecución NO es idempotente: nunca se reintenta. Si su resultado es desconocido (red o
        5xx) o el sondeo cae, se liquida la cota (el peor caso) y se para; ver ResultadoDesconocido."""
        self._comprobar("apify")
        validar_entrada(actor, entrada)
        ficha = ACTORES[actor]
        minimo = cota_minima(actor, entrada)
        if cota + 1e-9 < minimo:
            raise PresupuestoAgotado(mensaje_cota_minima(actor, cota, minimo))
        params = {"actor": actor, "entrada": entrada}
        en_cache = self.cache_leer("apify", params)
        if en_cache is not None:
            return _de_cache(en_cache)
        aviso = self.apify_margen(cota)
        if aviso:
            self.cobertura["avisos"].append(aviso)
        tok = clave("apify")
        cab = {"Authorization": "Bearer " + tok}
        resultado: Dict[str, Any] = {}

        def hacer() -> Tuple[int, Any, float, str]:
            t0 = time.time()
            st, j = http("POST", f"https://api.apify.com/v2/acts/{actor}/runs?waitForFinish=240&maxTotalChargeUsd="
                         f"{cota:.4f}", entrada, cab, timeout=300)
            if st == 0 or st >= 500:
                # No se sabe si la ejecución se creó: puede existir y cobrar hasta la cota. Nunca se reintenta.
                self.uso({"proveedor": "apify", "actor": actor, "concepto": "ejecucion", "estado": "resultado_desconocido",
                          "http": st, "coste_usd": cota, "segundos": round(time.time() - t0, 1)})
                raise ResultadoDesconocido(
                    "apify", f"Apify no confirmó si creó la ejecución de {actor} (HTTP {st or 'sin respuesta'}). Puede "
                    f"existir y cobrar hasta {cota:.4f} USD: se liquida la cota entera como resultado_desconocido y NO "
                    "se reintenta. Mírala en la consola de Apify (console.apify.com → Actors → Runs) y, si sigue "
                    "viva, aborta la ejecución antes de repetir.")
            if st >= 400:
                return st, j, 0.0, "ok"
            run = (j or {}).get("data", {}) if isinstance(j, dict) else {}
            rid_run = run.get("id")
            fallos = 0
            desconocido = False
            motivo_desconocido = ""
            if rid_run:
                _run_alta(rid_run, cab)         # si matan el proceso, el manejador de señales intenta abortarla
            try:
                # Todo estado que no sea FINAL (READY, RUNNING, ABORTING, TIMING-OUT o uno desconocido) se sigue sondeando:
                # liquidar sin ver un estado final sería dar por terminada una ejecución que puede seguir cobrando.
                while rid_run and run.get("status") not in ESTADOS_FINALES_APIFY:
                    if time.time() - t0 > SEGUNDOS_ESPERA_APIFY:
                        # Se pide el aborto y se CONFIRMA leyendo un estado final. Sin esa confirmación la ejecución
                        # puede seguir viva y cobrando: el coste es desconocido y la cota no se libera.
                        final = _abortar_y_confirmar(rid_run, cab)
                        if final is None:
                            run["status"] = "TIMED-OUT"
                            desconocido = True
                            motivo_desconocido = "superó el tiempo de espera y el aborto no se pudo confirmar"
                        else:
                            run = final
                            self.cobertura["avisos"].append(
                                f"Apify: la ejecución {rid_run} superó el tiempo de espera; se abortó (estado final "
                                f"{final.get('status')} confirmado) y se liquidó por lo que llegó a producir.")
                        break
                    time.sleep(PAUSA_POLL)
                    st2, j2 = http_tras_envio("GET", f"https://api.apify.com/v2/actor-runs/{rid_run}", None, cab)
                    if st2 == 200 and isinstance(j2, dict):
                        run = j2.get("data", run)
                    else:
                        clasificar(st2, j2, "apify")
                        fallos += 1
                        if fallos >= 3:
                            # sondeo caído: se aborta (como en el timeout) y el coste es desconocido → conservador
                            http_tras_envio("POST", f"https://api.apify.com/v2/actor-runs/{rid_run}/abort", None, cab)
                            run["status"] = "TIMED-OUT"
                            desconocido = True
                            motivo_desconocido = "el sondeo de la ejecución falló 3 veces"
                            break
            finally:
                if rid_run:
                    _run_baja(rid_run)
            items: List[Any] = []
            dataset_id = run.get("defaultDatasetId")
            descarga_fallida = False
            if dataset_id:
                for intento in range(3):         # 1 intento + 2 reintentos (GET: idempotente)
                    st3, it = http_tras_envio("GET", f"https://api.apify.com/v2/datasets/{dataset_id}/items"
                                   "?clean=true&format=json", None, cab)
                    if st3 == 200 and isinstance(it, list):
                        items = it
                        break
                    clasificar(st3, it, "apify")
                    if intento < 2:
                        time.sleep(PAUSA_REINTENTO)
                else:
                    descarga_fallida = True
            real = run.get("usageTotalUsd")
            for _ in range(3):      # el coste sale con retraso: se relee al terminar (hasta 3 veces)
                if real is not None or not rid_run:
                    break
                time.sleep(RETRASO_USO_APIFY)
                st4, j4 = http_tras_envio("GET", f"https://api.apify.com/v2/actor-runs/{rid_run}", None, cab)
                if st4 == 200 and isinstance(j4, dict) and isinstance(j4.get("data"), dict):
                    run = j4["data"]
                    real = run.get("usageTotalUsd")
            if desconocido:
                run["status"] = "TIMED-OUT"       # sin final confirmado: no se toma por bueno un RUNNING releído
            # Estimación por eventos (nunca por encima de la reserva). El coste que Apify da al terminar la
            # ejecución llega con RETRASO: en las pruebas del 15-oct-2026 marcó 0,00005 USD (solo el arranque, con
            # «post: 0») para 20 posts que el contador mensual cobró a 0,04. Se liquida con el MAYOR de los dos.
            n_ev = _eventos_cobrados(run.get("chargedEventCounts"))
            est_eventos = ficha["arranque"] + n_ev * ficha["precio_item"] if n_ev else None
            if items:
                estimado = ficha["arranque"] + len(items) * ficha["precio_item"]
            elif run.get("status") == "SUCCEEDED":
                estimado = ficha["arranque"] + ficha.get("sin_resultado", 0.001)   # evento «no-result» (si el actor lo tiene)
            else:
                estimado = ficha["arranque"]
            if est_eventos is not None:
                estimado = max(estimado, est_eventos)
            estimado = min(estimado, cota)
            coste = max(float(real), estimado) if isinstance(real, (int, float)) else estimado
            etiqueta = "ok"
            estado_run = run.get("status")
            if desconocido:
                coste = max(coste, cota)
                etiqueta = "resultado_desconocido"
                self.cobertura["avisos"].append(
                    f"Apify: la ejecución {rid_run} {motivo_desconocido}; se liquidó la cota ({cota:.4f} USD) como "
                    "resultado_desconocido y Apify queda parado esta sesión. Compruébala en la consola de Apify "
                    "(Actors → Runs) y abórtala si sigue viva.")
            elif descarga_fallida:
                coste = max(coste, est_eventos if est_eventos is not None else cota)
                etiqueta = "resultado_desconocido"
                self.cobertura["avisos"].append(
                    f"Apify: no se pudo descargar el dataset {dataset_id} (ejecución {rid_run}); se liquidó un coste "
                    "conservador y NO se guardó en la caché. Descárgalo desde la consola de Apify (Storage → Datasets).")
                resultado["descarga_fallida"] = True
                resultado["dataset_id"] = dataset_id
            elif estado_run != "SUCCEEDED":
                etiqueta = "arranque_fallido"
                coste = max(coste, ficha["arranque"])
                with self._candado:
                    self.cobertura["arranques_fallidos"] += 1
            fila = {"proveedor": "apify", "actor": actor, "concepto": "ejecucion", "estado": estado_run,
                    "eventos": run.get("chargedEventCounts"), "coste_usd": coste, "items": len(items),
                    "segundos": round(time.time() - t0, 1), "run_id": rid_run}
            if items and isinstance(run.get("chargedEventCounts"), dict) and n_ev == 0:
                fila["eventos_retrasados"] = True         # el contador de eventos aún no refleja los posts cobrados
            if etiqueta == "resultado_desconocido":
                fila["estado_libro"] = etiqueta
                fila["dataset_id"] = dataset_id
            self.uso(fila)
            mensaje = run.get("statusMessage")
            resultado.update({"estado": estado_run, "mensaje": limpiar_control(redactar(str(mensaje))) if mensaje else None,
                              "items": items, "coste_usd": coste, "consultado": iso_local()})
            # Solo un mensaje que habla de la CUENTA (saldo, plan, uso mensual) para el proveedor entero. Un «rate limit»
            # de la red dentro de un run FAILED es un fallo del actor (arranque_fallido): no para a los demás.
            if estado_run == "FAILED" and _PATRONES_CUENTA_APIFY.search(str(run.get("statusMessage") or "")):
                return 402, {"error": limpiar_control(redactar(str(run.get("statusMessage"))))}, coste, "limite"
            return 200, {"ok": True}, coste, etiqueta

        self.pagada("apify", f"{actor}:{posts_estimados}", cota, hacer)
        if resultado.get("estado") == "SUCCEEDED" and not resultado.get("descarga_fallida"):
            self.cache_guardar("apify", params, {**resultado, "items": proyectar_items(resultado.get("items"), actor)})
        return resultado

    # -- Bright Data ---------------------------------------------------------------------------
    def brightdata_ejecutar(self, red: str, urls: List[str], precio: Optional[float] = None) -> Dict[str, Any]:
        """Lee publicaciones por URL en el dataset de Bright Data de esa red (Facebook o Instagram)."""
        if red not in BRIGHTDATA_DATASET:
            raise MetaSearchError(f"Bright Data no lee {NOMBRE_RED.get(red, red)} por URL (solo "
                                  f"{', '.join(NOMBRE_RED[r] for r in BRIGHTDATA_DATASET)}).")
        self._comprobar("brightdata")
        precio = precio_valido(precio, "El precio por registro") if precio is not None else _precio_bd()
        dataset = BRIGHTDATA_DATASET[red]
        tok = clave("brightdata")
        params = {"dataset": dataset, "urls": sorted(urls)}
        en_cache = self.cache_leer("brightdata", params)
        if en_cache is not None:
            return _de_cache(en_cache)
        cab = {"Authorization": "Bearer " + tok}
        cota = round(len(urls) * precio, 7)
        resultado: Dict[str, Any] = {}

        def desconocido(snap: Optional[str], motivo: str, t0: float) -> ResultadoDesconocido:
            """Los registros pueden estar cobrados aunque no se hayan descargado: se liquida la cota entera."""
            extra = {"snapshot_id": snap} if snap else {}
            self.uso({"proveedor": "brightdata", "dataset": dataset, "red": red, "concepto": "scrape",
                      "estado": "resultado_desconocido", "registros": None, "coste_usd": cota,
                      "segundos": round(time.time() - t0, 1), **extra})
            if snap:
                self.cobertura["avisos"].append(
                    f"Bright Data: {motivo} (snapshot_id {snap}); se liquidó la cota ({cota:.4f} USD) como "
                    "resultado_desconocido y NO se guardó en la caché. Descarga ese snapshot desde el panel de Bright "
                    "Data (Datasets → Snapshots) en vez de repetir la petición.")
            return ResultadoDesconocido(
                "brightdata", f"Bright Data: {motivo}" + (f" (snapshot_id {snap})" if snap else "")
                + f". Los registros pueden estar cobrados: se liquida la cota ({cota:.4f} USD) como "
                "resultado_desconocido y no se reintenta. Revísalo en el panel de Bright Data antes de repetir.", extra)

        def hacer() -> Tuple[int, Any, float, str]:
            t0 = time.time()
            st, j = http("POST", "https://api.brightdata.com/datasets/v3/scrape?dataset_id="
                         f"{dataset}&include_errors=true&format=json", [{"url": u} for u in urls], cab,
                         timeout=300)
            if st == 0 or st >= 500:
                raise desconocido(None, f"la petición no obtuvo respuesta (HTTP {st or 'sin respuesta'})", t0)
            if st >= 400:
                return st, j, 0.0, "ok"
            snap = j.get("snapshot_id") if isinstance(j, dict) else None
            if snap and st in (200, 202):
                listo = False
                while time.time() - t0 < SEGUNDOS_ESPERA_APIFY:
                    time.sleep(PAUSA_POLL)
                    s2, p = http_tras_envio("GET", f"https://api.brightdata.com/datasets/v3/progress/{snap}", None, cab)
                    clasificar(s2, p, "brightdata")
                    if isinstance(p, dict) and p.get("status") in ("ready", "failed"):
                        listo = True
                        j = None
                        if p.get("status") == "ready":
                            for intento in range(3):         # 1 intento + 2 reintentos (GET: idempotente)
                                s3, j3 = http_tras_envio("GET", f"https://api.brightdata.com/datasets/v3/snapshot/{snap}?format=json",
                                              None, cab)
                                clasificar(s3, j3, "brightdata")
                                if s3 == 200 and isinstance(j3, list):
                                    j = j3
                                    break
                                if s3 == 200 and isinstance(j3, dict) and ("url" in j3 or "input" in j3):
                                    j = j3
                                    break
                                if intento < 2:
                                    time.sleep(PAUSA_REINTENTO)
                            else:
                                raise desconocido(snap, "el snapshot está listo pero no se pudo descargar", t0)
                        break
                if not listo:
                    raise desconocido(snap, f"el sondeo del snapshot se agotó tras {SEGUNDOS_ESPERA_APIFY} s", t0)
            items = j if isinstance(j, list) else ([j] if isinstance(j, dict) and ("url" in j or "input" in j) else [])
            if not items and isinstance(j, dict) and _PATRONES_LIMITE.search(json.dumps(j)[:800]):
                return 402, j, 0.0, "limite"
            coste = round(len(items) * precio, 7)
            self.uso({"proveedor": "brightdata", "dataset": dataset, "red": red, "concepto": "scrape",
                      "registros": len(items), "coste_usd": coste, "segundos": round(time.time() - t0, 1)})
            resultado.update({"items": items, "coste_usd": coste, "consultado": iso_local()})
            return 200, {"ok": True}, coste, "ok" if items else "sin_registros"

        self.pagada("brightdata", f"scrape:{red}:{len(urls)}", cota, hacer)
        if resultado.get("items"):
            self.cache_guardar("brightdata", params,
                               {**resultado, "items": proyectar_items(resultado.get("items"), "brightdata:" + red)})
        return resultado
    # -- Texto de respaldo (Exa contents → Firecrawl scrape) -----------------------------------
    def exa_contents(self, url: str) -> Tuple[Optional[str], bool]:
        """(texto de respaldo, se cortó un bloque de comentarios de terceros)."""
        tok = clave("exa")

        def hacer() -> Tuple[int, Any, float, str]:
            st, j = http("POST", "https://api.exa.ai/contents", {"urls": [url], "text": {"maxCharacters": 6000}},
                         {"x-api-key": tok})
            coste = PRECIO_EXA_CONTENTS if st == 200 else 0.0
            if st == 200 and isinstance(j, dict):
                real = (j.get("costDollars") or {}).get("total")
                if isinstance(real, (int, float)):
                    coste = float(real)
            self.uso({"proveedor": "exa", "concepto": "contents", "http": st, "coste_usd": coste})
            return st, j, coste, "ok"

        _, j, _ = self.pagada("exa", "contents", PRECIO_EXA_CONTENTS, hacer)
        res = (j or {}).get("results") if isinstance(j, dict) else None
        if not (res and isinstance(res[0], dict)):
            return None, False
        sin_exa = re.sub(r"\n+## Engagement\b.*\Z", "", res[0].get("text") or "", flags=re.S)
        return limpiar_texto_exa(res[0].get("text")), cortar_comentarios(sin_exa)[1]

    def firecrawl_scrape(self, url: str) -> Tuple[Optional[str], bool]:
        """(texto de respaldo, se cortó un bloque de comentarios de terceros)."""
        tok = clave("firecrawl")

        def hacer() -> Tuple[int, Any, float, str]:
            st, j = http("POST", "https://api.firecrawl.dev/v2/scrape",
                         {"url": url, "formats": ["markdown"], "onlyMainContent": True}, {"Authorization": "Bearer " + tok})
            self.uso({"proveedor": "firecrawl", "concepto": "scrape", "http": st, "coste_usd": 0.0})
            return st, j, 0.0, "ok"

        _, j, _ = self.pagada("firecrawl", "scrape", 0.0, hacer)
        md = ((j or {}).get("data") or {}).get("markdown") if isinstance(j, dict) else None
        if not md:
            return None, False
        limpio, cortado = cortar_comentarios(md[:8000])
        return _txt(limpio), cortado


# ---------------------------------------------------------------------------------------------
# Almacén de publicaciones (registros.json) y fusión por ID de cada red
# ---------------------------------------------------------------------------------------------
class Almacen:
    """Todo lo que se sabe de cada publicación, deduplicado por ID. Se guarda en <salida>/registros.json."""

    def __init__(self, ruta: Optional[Path] = None):
        self.ruta = ruta
        datos = leer_json(ruta, None) if ruta else None
        if not isinstance(datos, dict):
            datos = {}
        self.meta: Dict[str, Any] = datos.get("meta") or {}
        self.pubs: Dict[str, Dict[str, Any]] = datos.get("publicaciones") or {}
        self.descartados: Dict[str, str] = datos.get("descartados") or {}
        # clave antigua → clave nueva, cuando enriquecer revela la forma canónica de un enlace corto de Facebook (fbshare:… → fb:…). Así una
        # selección guardada ANTES (descubrir-*.json, la lista de --completo) sigue apuntando a su publicación.
        alias = datos.get("alias")
        self.alias: Dict[str, str] = alias if isinstance(alias, dict) else {}
        if self.pubs and "sesiones" not in self.meta:
            # registros.json de una versión que no apuntaba la cobertura de cada fase: lo anterior es desconocido
            self.meta["fases_sin_registro"] = True

    def guardar(self) -> None:
        if self.ruta is None:
            return
        escribir_json(self.ruta, {"version": VERSION, "meta": self.meta, "publicaciones": self.pubs,
                                  "descartados": self.descartados, "alias": self.alias})

    def resolver(self, clave_: str) -> Optional[str]:
        """La clave vigente de una publicación (sigue los alias de la reindexación), o None si no está."""
        visto = set()
        while clave_ not in self.pubs and clave_ in self.alias and clave_ not in visto:
            visto.add(clave_)
            clave_ = self.alias[clave_]
        return clave_ if clave_ in self.pubs else None

    def resolver_lista(self, claves: Iterable[str]) -> Tuple[List[str], List[str]]:
        """(claves vigentes sin repetir y en orden, claves que no se encuentran)."""
        vigentes: List[str] = []
        perdidas: List[str] = []
        for c in claves:
            r = self.resolver(c)
            if r is None:
                perdidas.append(c)
            elif r not in vigentes:
                vigentes.append(r)
        return vigentes, perdidas


def pub_nueva(info: Dict[str, Any]) -> Dict[str, Any]:
    return {"clave": info["clave"], "red": info["red"], "id": info["id"], "tipo": info["tipo"], "url": info["url"],
            "handle": info["handle"], "motores": [], "consultas": [], "snippets": [], "titulo": None,
            "autor_motor": None, "fechas_motor": [], "vias": [], "lecturas": [], "textos_extra": {},
            "descubierto": iso_local()}


def agregar_candidato(alm: Almacen, cand: Dict[str, Any], consulta: Optional[str] = None,
                      via: Optional[str] = None) -> Tuple[Optional[dict], bool]:
    """Suma un candidato (de un buscador, de una búsqueda de pago o manual). Devuelve (publicación|None si no es una
    publicación, ya_existía). `via` etiqueta el camino por el que llegó: buscador, populares_antiguos, etc."""
    info = parsear_url(cand.get("url") or "")
    if info is None:
        return None, False
    vigente = alm.resolver(info["clave"])           # una clave que cambió al reindexar sigue apuntando a su publicación
    if vigente is None and info["red"] == "facebook" and info["clave"].startswith("fb:"):
        # el mismo post de Facebook con otra forma de URL (pfbid frente a número): un proveedor ya dio la equivalencia
        vigente = next((c for c, p in alm.pubs.items() if info["id"] in (p.get("id_alt") or [])), None)
    if vigente is not None:
        info = dict(info, clave=vigente)
    existente = info["clave"] in alm.pubs
    pub = alm.pubs.get(info["clave"]) or pub_nueva(info)
    alm.pubs[info["clave"]] = pub
    for campo, valor in (("motores", cand.get("motor")), ("consultas", consulta), ("vias", via or cand.get("via"))):
        if valor and valor not in pub[campo]:
            pub[campo].append(valor)
    if cand.get("snippet"):
        pub["snippets"].append({"motor": cand.get("motor"), "texto": cand["snippet"][:2500]})
        pub["snippets"] = pub["snippets"][-6:]
    pub["titulo"] = pub["titulo"] or cand.get("titulo")
    pub["autor_motor"] = pub["autor_motor"] or cand.get("autor")
    if cand.get("fecha_motor"):
        pub["fechas_motor"].append({"motor": cand.get("motor"), "fecha": cand["fecha_motor"]})
    if info["handle"] and not pub.get("handle"):
        pub["handle"] = info["handle"]
    return pub, existente


def _es_num(i: Any) -> bool:
    return isinstance(i, str) and re.fullmatch(r"[0-9]+", i) is not None


def _numeros_fb(*ids: Any) -> set:
    return {i for i in (str(x) for x in ids if x is not None) if _es_num(i)}


def _aviso_pub(pub: Dict[str, Any], aviso: str) -> None:
    avisos = pub.setdefault("avisos_extra", [])
    if aviso not in avisos:
        avisos.append(aviso)


def _aprender_ids_fb(pub: Dict[str, Any], ids: Iterable[Any]) -> None:
    """Apunta como `id_alt` el número que un proveedor da para esta publicación (el `postId` del actor de búsqueda, el
    `post_id` de Bright Data, que pueden acompañar a una URL pfbid): con él, el mismo post hallado con la otra forma
    de URL se funde en `reindexar` y no se cuenta dos veces."""
    for i in _numeros_fb(*ids):
        if i != pub.get("id") and i not in pub.setdefault("id_alt", []):
            pub["id_alt"].append(i)
    if not pub.get("id_alt"):
        pub.pop("id_alt", None)


def _identidad_fb(pub: Dict[str, Any], lectura: Dict[str, Any], info: Dict[str, Any]) -> Tuple[str, set]:
    """¿Es la lectura de ESTA publicación de Facebook, si la clave de su URL no es la de la publicación?
    `otra` | `misma` (con los números que enseña) | `sin_confirmar` (forma distinta y ningún número con que compararla)."""
    ln = _numeros_fb(lectura.get("id"), info["id"])
    if len(ln) > 1:
        return "otra", set()            # la propia lectura se contradice: dos números distintos para un solo post
    pn = _numeros_fb(pub.get("id"), *(pub.get("id_alt") or []))
    if pn and ln:
        return ("misma", ln) if pn & ln else ("otra", set())
    if _es_num(pub["id"]) == _es_num(info["id"]):
        return "otra", set()            # dos números distintos o dos pfbid distintos, sin ningún número en común
    entrada = parsear_url(lectura.get("entrada") or "")
    if entrada and entrada["clave"] == pub["clave"] and ln:
        return "misma", ln              # el proveedor ató su resultado a la URL que se le pidió
    return "sin_confirmar", set()


def agregar_lectura(pub: Dict[str, Any], lectura: Dict[str, Any]) -> None:
    """Una lectura por proveedor (la última manda). Si el proveedor devuelve OTRA publicación para este enlace, la
    lectura no cuenta para la ficha: se guarda aparte y se avisa. En Facebook, un enlace corto (/share/…) admite que el
    proveedor revele su forma canónica: la publicación se reindexa con alias."""
    red = pub["red"]
    otra = False
    if red in ("instagram", "threads"):
        ident = lectura.get("id")
        otra = bool(ident and pub.get("id") and ident != pub["id"])
    elif red == "facebook":
        info = parsear_url(lectura.get("url") or "")
        if info and info["red"] == "facebook":
            if info["clave"] == pub["clave"]:
                _aprender_ids_fb(pub, {lectura.get("id")})        # el proveedor da el número de una URL pfbid
            elif pub["clave"].startswith("fbshare:"):
                pub["clave_revelada"] = info["clave"]
                pub["url_revelada"] = info["url"]
            elif pub["clave"].startswith("fb:") and info["clave"].startswith("fb:"):
                veredicto, aprender = _identidad_fb(pub, lectura, info)
                if veredicto == "otra":
                    otra = True
                elif veredicto == "sin_confirmar":
                    _aviso_pub(pub, "identidad_de_la_lectura_sin_confirmar")
                else:
                    _aprender_ids_fb(pub, aprender)
    if otra:
        pub.setdefault("lecturas_de_otra_publicacion", []).append(lectura)
        avisos = pub.setdefault("avisos_extra", [])
        if "lectura_de_otra_publicacion" not in avisos:
            avisos.append("lectura_de_otra_publicacion")
        return
    pub["lecturas"] = [l for l in pub["lecturas"] if l.get("proveedor") != lectura.get("proveedor")]
    pub["lecturas"].append(lectura)


def _mas_reciente(a: dict, b: dict) -> bool:
    """True si la lectura `a` debe quedarse frente a `b`: una lectura buena gana siempre a una con error; entre dos del mismo
    tipo, la consultada DESPUÉS y, a igual instante, la de más me gusta (las métricas solo suben)."""
    if bool(a.get("error")) != bool(b.get("error")):
        return not a.get("error")
    ta, tb = _ts(a.get("consultado")), _ts(b.get("consultado"))
    if ta != tb:
        return ta > tb
    return (a.get("me_gusta") or 0) > (b.get("me_gusta") or 0)


def fundir_pubs(destino: Dict[str, Any], origen: Dict[str, Any]) -> None:
    for campo in ("motores", "consultas", "vias"):
        for v in origen.get(campo, []):
            if v not in destino[campo]:
                destino[campo].append(v)
    destino["snippets"] = (destino.get("snippets", []) + origen.get("snippets", []))[-6:]
    destino["fechas_motor"] = destino.get("fechas_motor", []) + origen.get("fechas_motor", [])
    for k in ("titulo", "autor_motor", "handle"):
        destino[k] = destino.get(k) or origen.get(k)
    for l in origen.get("lecturas", []):
        previa = next((x for x in destino["lecturas"] if x.get("proveedor") == l.get("proveedor")), None)
        if previa is None:
            destino["lecturas"].append(l)
        elif _mas_reciente(l, previa):                  # por proveedor sobrevive la lectura MÁS RECIENTE, no la del destino
            destino["lecturas"][destino["lecturas"].index(previa)] = l
    if origen.get("lecturas_de_otra_publicacion"):
        destino.setdefault("lecturas_de_otra_publicacion", []).extend(origen["lecturas_de_otra_publicacion"])
    for a in origen.get("avisos_extra", []):
        if a not in destino.setdefault("avisos_extra", []):
            destino["avisos_extra"].append(a)
    for k, v in origen.get("textos_extra", {}).items():
        destino["textos_extra"].setdefault(k, v)
    for u in [origen.get("url")] + origen.get("urls_alt", []):
        if u and u != destino.get("url") and u not in destino.setdefault("urls_alt", []):
            destino["urls_alt"].append(u)
    if destino.get("red") == "facebook":                 # las identidades de las dos formas del mismo post quedan apuntadas
        alts = list(origen.get("id_alt") or [])
        if str(origen.get("clave", "")).startswith("fb:"):
            alts.append(origen.get("id"))
        for a in alts:
            if a and a != destino.get("id") and a not in destino.setdefault("id_alt", []):
                destino["id_alt"].append(a)
        if not destino.get("id_alt"):
            destino.pop("id_alt", None)


def _reindexar_ids_fb(alm: Almacen) -> int:
    """Funde dos publicaciones de Facebook que un proveedor reveló como la MISMA (el `id_alt` de una es la clave de la
    otra): sobrevive la de clave numérica, la estable, y la otra queda como alias."""
    fundidas = 0
    for clave_ in list(alm.pubs):
        pub = alm.pubs.get(clave_)
        if pub is None or pub.get("red") != "facebook":
            continue
        for alt in list(pub.get("id_alt") or []):
            otra_clave = "fb:" + alt
            if otra_clave == clave_ or otra_clave not in alm.pubs:
                continue
            destino, origen = (otra_clave, clave_) if _es_num(alt) and not _es_num(pub["id"]) else (clave_, otra_clave)
            fundir_pubs(alm.pubs[destino], alm.pubs[origen])
            del alm.pubs[origen]
            alm.alias[origen] = destino
            fundidas += 1
            if origen == clave_:
                break
    return fundidas


def reindexar(alm: Almacen) -> int:
    """Funde publicaciones que, tras enriquecer, resultan ser la MISMA: un enlace corto de Facebook (`fbshare:…`) cuya
    forma canónica reveló un proveedor. La clave vieja queda como alias, así una selección guardada antes sigue valiendo."""
    fundidas = _reindexar_ids_fb(alm)
    for clave_ in list(alm.pubs):
        pub = alm.pubs.get(clave_)
        if pub is None or not clave_.startswith("fbshare:"):
            continue
        canon = pub.get("clave_revelada")
        if not canon or canon == clave_:
            continue
        if canon in alm.pubs:
            fundir_pubs(alm.pubs[canon], pub)
            del alm.pubs[clave_]
            fundidas += 1
        else:
            viejo = pub["url"]
            pub["clave"] = canon
            pub["id"] = canon.split(":", 1)[1]
            pub["url"] = pub.get("url_revelada") or pub["url"]
            pub.setdefault("urls_alt", []).append(viejo)
            alm.pubs[canon] = pub
            del alm.pubs[clave_]
        alm.alias[clave_] = canon
    return fundidas


def emparejar(alm: Almacen, lecturas: List[Dict[str, Any]]) -> int:
    """Asigna cada lectura de un proveedor a su publicación: por la URL enviada y, si no, por la URL o el ID que trae."""
    por_url: Dict[str, dict] = {}
    por_id: Dict[Tuple[str, str], dict] = {}
    for p in alm.pubs.values():
        for u in [p["url"]] + p.get("urls_alt", []):
            por_url[limpiar_url(u).rstrip("/")] = p
        por_id[(p["red"], p["id"])] = p
    n = 0
    for l in lecturas:
        pub = None
        if l.get("entrada"):
            pub = por_url.get(limpiar_url(l["entrada"]).rstrip("/"))
        if pub is None and l.get("url"):
            info = parsear_url(l["url"])
            if info:
                vigente = alm.resolver(info["clave"])
                pub = alm.pubs.get(vigente) if vigente else None
        if pub is None and l.get("id") and l.get("red"):
            pub = por_id.get((l["red"], l["id"]))
        if pub is not None:
            agregar_lectura(pub, l)
            n += 1
    reindexar(alm)
    return n


# ---------------------------------------------------------------------------------------------
# Ficha de entrega
# ---------------------------------------------------------------------------------------------
# «La publicación no existe o es privada»: solo los códigos y frases que el proveedor usa para eso. Un fallo transitorio
# («crawl_failed: timeout after 14040 ms», «private network unreachable», «Rate limited…removed 4040 items») NO lo es.
_ERR_NO_DISPONIBLE = re.compile(
    r"(?i)\bdead_page\b|\bnot[_ ]found\b|\b(?:http|status|error)[ _:=]*404\b|\b404[ _:]*(?:not[ _]found|error)\b|"
    r"isn.t available|no longer available|content (?:is )?(?:not|un)available|"
    r"(?:post|page|content|video|reel)\s+(?:is\s+)?(?:private|unavailable|deleted|removed)|"
    r"has been (?:deleted|removed)|was (?:deleted|removed)")
TOLERANCIA_FECHAS_PROVEEDORES = 60      # s: las fechas de dos proveedores coinciden «al minuto»
TOLERANCIA_FECHA_CODIGO = 3600          # s: más que esto entre el proveedor y el código del enlace = aviso


def lecturas_ok(pub: dict) -> List[dict]:
    return [l for l in pub.get("lecturas", []) if not l.get("error")]


def texto_de_pub(pub: dict) -> Tuple[Optional[str], Optional[str]]:
    """Texto literal: el del proveedor; si falta, Exa contents; si falta, Firecrawl scrape. Nunca se reconstruye."""
    por_prov = {l["proveedor"]: l for l in lecturas_ok(pub) if l.get("texto")}
    for p in PRIORIDAD_TEXTO:
        if p in por_prov:
            return por_prov[p]["texto"], p
    for k in ("exa_contents", "firecrawl_scrape"):
        if pub.get("textos_extra", {}).get(k):
            return pub["textos_extra"][k], k
    return None, None


def autor_de_pub(pub: dict) -> Tuple[Optional[str], Optional[str]]:
    for p in PRIORIDAD_TEXTO:
        for l in lecturas_ok(pub):
            if l["proveedor"] == p and l.get("autor"):
                return l["autor"], "proveedor"
    if pub.get("autor_motor"):
        return pub["autor_motor"], "buscador"
    if pub.get("handle") and not str(pub["handle"]).isdigit():
        return pub["handle"], "url"
    return None, None


def texto_para_juzgar(pub: dict) -> str:
    """Texto para idioma y relleno: el literal si lo hay; si no, lo que dieron los buscadores (solo para PODAR)."""
    t, _ = texto_de_pub(pub)
    if t:
        return t
    return "\n".join([s["texto"] for s in pub.get("snippets", [])] + ([pub["titulo"]] if pub.get("titulo") else []))


def _fechas_proveedor(pub: dict) -> List[Tuple[str, dt.datetime]]:
    out = []
    for prov in PRIORIDAD_TEXTO:
        for l in lecturas_ok(pub):
            if l["proveedor"] == prov:
                t = parse_fecha(l.get("fecha_proveedor"))
                if t:
                    out.append((prov, t))
    return out


def fecha_de_pub(pub: dict) -> Tuple[Optional[str], Optional[str]]:
    """(fecha ISO UTC, fecha_fuente). La fecha sale del proveedor de métricas; con dos fuentes que coinciden al minuto es
    `proveedores_contrastados`. En Instagram y Threads, sin fecha del proveedor, sale del código del enlace
    (`codigo_del_enlace`, precisión de unos minutos). Las fechas de los buscadores (solo el día) NO se usan."""
    fp = _fechas_proveedor(pub)
    if fp:
        prov, t = fp[0]
        otras = [x for p, x in fp[1:] if empresa_de(p) != empresa_de(prov)]       # como las métricas: dos EMPRESAS, no dos lecturas
        if not otras:
            return iso_utc(t), f"proveedor:{prov}"
        dif = max(abs((x - t).total_seconds()) for x in otras)
        return iso_utc(t), ("proveedores_contrastados" if dif <= TOLERANCIA_FECHAS_PROVEEDORES else "proveedores_discrepantes")
    if pub.get("red") in ("instagram", "threads"):
        t = fecha_de_codigo(pub.get("id") or "")
        if t:
            return iso_utc(t), "codigo_del_enlace"
    return None, None


def _norm_texto(s: str) -> str:
    s = unicodedata.normalize("NFKC", s or "").casefold()
    s = _URL.sub(" ", s)
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s]", "", s)).strip()


def verificar_texto(pub: dict) -> Dict[str, Any]:
    """Compara el texto de las lecturas que lo traen (solo local, sin red)."""
    textos: Dict[str, str] = {}
    empresas = set()
    for prov in PRIORIDAD_TEXTO:                      # un texto por EMPRESA: dos lecturas de Apify no son dos fuentes
        for l in lecturas_ok(pub):
            if l["proveedor"] == prov and l.get("texto") and empresa_de(prov) not in empresas:
                empresas.add(empresa_de(prov))
                textos[prov] = _norm_texto(l["texto"])
    if len(textos) < 2:
        return {"estado": "una_fuente", "fuentes": sorted(textos)}
    a, b = list(textos.values())[:2]
    if a == b:
        estado = "identico"
    elif (a.startswith(b) or b.startswith(a)) and min(len(a), len(b)) >= 40:
        estado = "uno_recortado"
    else:
        import difflib
        r = difflib.SequenceMatcher(None, a[:3000], b[:3000]).ratio()
        estado = "casi_identico" if r >= 0.9 else "discrepante"
    return {"estado": estado, "fuentes": sorted(textos)}


def fuentes_de_pub(pub: dict) -> List[str]:
    nombres = {"apify_fb_busqueda": f"apify:{ACTOR_FB_BUSQUEDA}", "apify_ig_busqueda": f"apify:{ACTOR_IG_BUSQUEDA}",
               "apify_ig_hashtag": f"apify:{ACTOR_IG}#hashtag", "apify_ig": f"apify:{ACTOR_IG}",
               "apify_threads": f"apify:{ACTOR_THREADS}",
               "brightdata": f"brightdata:{BRIGHTDATA_DATASET.get(pub.get('red'), '')}"}
    return [nombres.get(l["proveedor"], l["proveedor"]) for l in lecturas_ok(pub)]


def construir_ficha(pub: dict) -> Dict[str, Any]:
    """Ficha de una publicación + los motivos por los que NO cumple el contrato (lista vacía = cumple)."""
    ident = pub.get("id")
    fecha, fecha_fuente = fecha_de_pub(pub)
    autor, autor_fuente = autor_de_pub(pub)
    texto, texto_fuente = texto_de_pub(pub)
    lects = lecturas_ok(pub)
    contraste = contrastar_lecturas(lects)
    cerrados = any(l.get("comentarios_desactivados") for l in lects)
    if cerrados:        # el autor cerró los comentarios: ningún 0 (tampoco el de otro proveedor) es una medida de ellos
        contraste["comentarios"] = {"estado": "sin_dato", "valor": None, "valores": contraste["comentarios"]["valores"],
                                    "desactivados_por_el_autor": True}
    estado = estado_metricas(contraste)
    sospechosas = {l["proveedor"] for l in lecturas_sospechosas(lects)}
    consultado = max([l.get("consultado") for l in lects if l.get("consultado")] or [pub.get("descubierto")],
                     key=_ts, default=None)
    avisos = avisos_texto(texto)
    if autor and avisos_texto(autor):
        avisos.append("posible_instruccion_en_el_autor")
    if hay_invisibles(texto):
        avisos.append("caracteres_invisibles_en_el_texto")
    if hay_invisibles(autor):
        avisos.append("caracteres_invisibles_en_el_autor")
    if texto_fuente in ("exa_contents", "firecrawl_scrape"):
        avisos.append(f"texto_de_respaldo_{texto_fuente}")
    for a in pub.get("avisos_extra", []):
        if a not in avisos:
            avisos.append(a)
    if lecturas_cero_sin_confirmar(lects):
        avisos.append("lectura_cero_sin_texto_sin_confirmar")
    if sospechosas:
        avisos.append("lectura_sospechosa_descartada:" + ",".join(sorted(sospechosas)))
    if fecha_fuente == "proveedores_discrepantes":
        avisos.append("fechas_discrepantes_entre_proveedores")
    t_codigo = fecha_de_codigo(ident or "") if pub.get("red") in ("instagram", "threads") else None
    if t_codigo and fecha_fuente and fecha_fuente != "codigo_del_enlace":
        t_fecha = parse_fecha(fecha)
        if t_fecha and abs((t_fecha - t_codigo).total_seconds()) > TOLERANCIA_FECHA_CODIGO:
            avisos.append("fecha_del_proveedor_discrepante")
    if any(l.get("me_gusta_oculto") for l in lects):
        avisos.append("me_gusta_ocultos_por_el_autor")
    if cerrados:
        avisos.append("comentarios_desactivados_por_el_autor")
    if any(l.get("es_respuesta") for l in lects):
        avisos.append("es_una_respuesta")
    if any(l.get("es_repost") for l in lects):
        avisos.append("es_un_repost")
    if estado == "discrepante":
        avisos.append("metricas_discrepantes_entre_fuentes")
    if contraste["compartidos"]["estado"] == "discrepante":
        avisos.append("compartidos_discrepantes")        # el estado de la ficha no cambia: solo me gusta y comentarios
    if estado != "sin_metricas" and contraste["compartidos"]["valor"] is None:
        avisos.append("sin_compartidos")
    if interaccion_alta(contraste["me_gusta"]["valor"], contraste["comentarios"]["valor"]):
        if texto_corto_con_enlace(texto):
            avisos.append("texto_corto_con_enlace")
        if texto and _CUPONES.search(texto):
            avisos.append("texto_de_cupones_con_interaccion_alta")
    faltantes = [c for c in ("me_gusta", "comentarios") if contraste[c]["valor"] is None]
    ficha = {
        "url": pub["url"], "red": pub.get("red"), "autor": autor, "fecha": fecha, "fecha_fuente": fecha_fuente,
        "texto": texto, "me_gusta": contraste["me_gusta"]["valor"], "comentarios": contraste["comentarios"]["valor"],
        "compartidos": contraste["compartidos"]["valor"], "vistas": contraste["vistas"]["valor"],
        "estado_metricas": estado, "fuentes": fuentes_de_pub(pub),
        "motor_descubrimiento": list(pub.get("motores", [])), "via": list(pub.get("vias", [])), "consultado": consultado,
        "id_publicacion": ident, "autor_fuente": autor_fuente, "texto_fuente": texto_fuente,
        "metricas_faltantes": faltantes if estado != "sin_metricas" else ["me_gusta", "comentarios"],
        "contraste": contraste, "avisos": avisos,
    }
    motivos = []
    errores = [l for l in pub.get("lecturas", []) if l.get("error")]
    if errores and not lects and any(_ERR_NO_DISPONIBLE.search(str(l["error"])) for l in errores):
        motivos.append("no_disponible")
    if estado == "sin_metricas" or faltantes:
        motivos.append("sin_metricas")             # para «cumplen» hacen falta me gusta Y comentarios
    if not texto:
        motivos.append("sin_texto")
    if not autor:
        motivos.append("sin_autor")
    if not fecha:
        motivos.append("sin_fecha")
    ficha["motivos"] = motivos
    if "no_disponible" in motivos:
        ficha["estado_metricas"] = "no_disponible"          # el proveedor dice que la publicación no existe o es privada
    return ficha


def seudonimo(autor: str) -> str:
    """Hash estable del nombre (SEUDONIMIZACIÓN, no anonimato: la URL y el texto siguen identificando al autor)."""
    sal = os.environ.get("META_SEARCH_SAL", "")
    return "autor-" + hashlib.sha256((sal + _norm_texto(autor)).encode()).hexdigest()[:10]


_CORREO = re.compile(r"[\w.+\-]+@[\w\-]+(?:\.[\w\-]+)+")
_TEL_ENLACE = re.compile(r"(?i)(wa\.me/|[?&]phone=|tel:)\+?\d{8,15}")
_TEL_LARGO = re.compile(r"(?<![\w@/])\+?\(?\d[\d \t().\-]{6,}\d(?![\w@])")
_MONEDA_O_UNIDAD_DESPUES = re.compile(
    r"(?i)^\s*(?:[%$€£¥]|(?:usd|eur|mxn|gbp|cop|ars|clp|pen|brl)\b|(?:millones|millón|millon|mil|miles|million|millions|"
    r"billion|billones|bn|mm|m|k|kg|km|mb|gb|tb)\b)")
_MONEDA_O_UNIDAD_ANTES = re.compile(r"(?i)(?:[$€£¥]|\b(?:usd|eur|mxn|gbp|cop|ars|clp|pen|brl)\b)\s*$")
_PALABRA_TELEFONO_ANTES = re.compile(
    r"(?i)(?:tel[eé]fono|tel\.?|tfno?\.?|m[oó]vil|whats\s?app|wsp|celular|cel\.?|phone|mobile|call|llama(?:me)?)\W{0,6}$")
_ISBN_ANTES = re.compile(r"(?i)\b(?:isbn|issn|doi)[\s:\-]*(?:\d[\d\-]*\s*)?$")


def _tel_a_omitir(m: "re.Match[str]") -> str:
    """Solo se omite lo que TIENE FORMA de teléfono: prefijo `+`, paréntesis o grupos de 2-4 dígitos separados por
    espacio, punto o guion, con 8-15 dígitos en total. Nunca se tocan cifras junto a una moneda o unidad (USD, $, €, %,
    millones, M, K…), un ISBN, una fecha ISO ni un número con separador de millares (1.200.000)."""
    crudo = m.group(0)
    digitos = re.sub(r"\D", "", crudo)
    if not 8 <= len(digitos) <= 15:
        return crudo
    s = crudo.strip()
    if re.fullmatch(r"\d{1,2}[ ./\-]\d{1,2}[ ./\-]\d{2,4}|\d{4}[ ./\-]\d{1,2}[ ./\-]\d{1,2}", s):   # una fecha
        return crudo
    antes = m.string[max(0, m.start() - 12):m.start()]
    despues = m.string[m.end():m.end() + 14]
    if (_MONEDA_O_UNIDAD_ANTES.search(antes) or _MONEDA_O_UNIDAD_DESPUES.search(despues)
            or _ISBN_ANTES.search(antes)):
        return crudo
    con_prefijo = crudo.lstrip().startswith("+") or "(" in crudo
    if not con_prefijo and len(digitos) >= 9 and _PALABRA_TELEFONO_ANTES.search(antes):
        return "[teléfono omitido]"         # cifras sueltas justo después de «móvil», «WhatsApp», «tel»…
    if not con_prefijo and re.fullmatch(r"\d{9,15}", s):
        return "[teléfono omitido]"         # 9-15 cifras seguidas sin moneda ni unidad: forma de teléfono
    if not con_prefijo and re.fullmatch(r"\d{1,3}(?:[.,]\d{3})+|\d{1,2}(?:[ \u00a0]\d{3})+", s):
        return crudo                        # 1.200.000 / 12 000 000: separador de millares, un número
        # (3-3-3 con espacios, «612 345 678», sigue siendo un teléfono: es la forma habitual en España)
    if not con_prefijo:
        grupos = [g for g in re.split(r"[ \t().\-]+", crudo.strip()) if g]
        if len(grupos) < 2 or not all(2 <= len(g) <= 4 for g in grupos):
            return crudo
        if re.fullmatch(r"\d{1,3}(?:[.,]\d{3})+", crudo.strip()):    # 12.345.678: un número, no un teléfono
            return crudo
    return "[teléfono omitido]"


def omitir_contacto(texto: Optional[str]) -> Tuple[Optional[str], bool]:
    """Sustituye correos y teléfonos por marcas visibles. Es una ALTERACIÓN del literal y se declara en la ficha."""
    if not texto:
        return texto, False
    t = _CORREO.sub("[correo omitido]", texto)
    t = _TEL_ENLACE.sub(lambda m: m.group(1) + "[teléfono omitido]", t)
    t = _TEL_LARGO.sub(_tel_a_omitir, t)
    return t, t != texto


def aplicar_privacidad(ficha: dict, anonimizar: bool = False, sin_url: bool = False) -> dict:
    f = dict(ficha)
    if anonimizar:
        if f.get("autor"):
            f["autor"] = seudonimo(f["autor"])
            f["autor_fuente"] = "seudonimo"
        f["texto"], cambiado = omitir_contacto(f.get("texto"))
        if cambiado:
            f["avisos"] = list(f.get("avisos", [])) + ["datos_de_contacto_omitidos"]
    if sin_url:
        ref = "pub-" + hashlib.sha256(str(f.get("id_publicacion") or f.get("url")).encode()).hexdigest()[:10]
        f["url"] = None
        f["id_publicacion"] = ref
    return f


# ---------------------------------------------------------------------------------------------
# Limpieza: idioma, relleno, ventana, tope por autor (todo lo descartado se CUENTA con su motivo)
# ---------------------------------------------------------------------------------------------
def anotar_descarte(cob: Dict[str, Any], clave_: str, motivo: str, alm: Optional[Almacen] = None) -> None:
    """Cuenta el descarte en la cobertura (y, si se da el almacén, lo apunta ahí). Nunca guarda texto."""
    cob["descartes"][motivo] = cob["descartes"].get(motivo, 0) + 1
    cob["descartados"].append({"clave": clave_, "motivo": motivo})
    if alm is not None:
        alm.descartados[clave_] = motivo


def resolver_idioma(idioma: str, tema: Optional[str]) -> Optional[str]:
    if idioma in ("es", "en"):
        return idioma
    return idioma_de_tema(tema) if tema else None


def filtrar(alm: Almacen, claves: Iterable[str], cob: Dict[str, Any], idioma: Optional[str] = None,
            desde: Optional[str] = None, hasta: Optional[str] = None, max_por_autor: int = 0,
            eliminar: bool = False, ventana: bool = True) -> List[str]:
    """Aplica idioma, relleno, ventana (solo a lo que YA tiene fecha) y tope por autor. Devuelve las claves que quedan.

    La ventana NO descarta lo que no tiene fecha: eso lo decide `citas` DESPUÉS de enriquecer (C4)."""
    quedan: List[str] = []
    vigentes, perdidas = alm.resolver_lista(claves)
    if perdidas:
        cob["descartes"]["clave_desconocida"] = cob["descartes"].get("clave_desconocida", 0) + len(perdidas)
    for c in vigentes:
        pub = alm.pubs[c]
        motivo = None
        juzgar = texto_para_juzgar(pub)
        lang = detectar_idioma(juzgar)
        if idioma and lang and lang != idioma:
            motivo = "idioma"
        if motivo is None:
            lects = lecturas_ok(pub)
            r = motivo_relleno(juzgar, max([l["me_gusta"] for l in lects if l.get("me_gusta") is not None] or [None]),
                               max([l["comentarios"] for l in lects if l.get("comentarios") is not None] or [None]),
                               hay_lectura=bool(lects))
            if r:
                motivo = "relleno"
        if motivo is None and ventana:
            fecha, _ = fecha_de_pub(pub)
            if fecha and en_ventana(fecha, desde, hasta) is False:
                motivo = "fuera_de_ventana"
        if motivo:
            anotar_descarte(cob, c, motivo, alm if eliminar else None)
            if eliminar:
                alm.pubs.pop(c, None)
        else:
            quedan.append(c)
    if max_por_autor and max_por_autor > 0:
        # Un autor es de UNA red: «Nike» de Instagram y «Nike» de Facebook son cuentas distintas y sus contadores no se
        # comparan entre redes. Dentro de una misma red, el orden usa los me gusta de esa red.
        grupos: Dict[Tuple[str, str], List[str]] = {}
        for c in quedan:
            autor, _ = autor_de_pub(alm.pubs[c])
            if autor:
                grupos.setdefault((alm.pubs[c].get("red") or "", _norm_texto(autor)), []).append(c)
        quitar = set()
        for _, cs in grupos.items():
            cs.sort(key=lambda k: max([l["me_gusta"] for l in lecturas_ok(alm.pubs[k]) if l.get("me_gusta") is not None]
                                      or [-1]), reverse=True)
            for k in cs[max_por_autor:]:
                quitar.add(k)
        for k in quitar:
            anotar_descarte(cob, k, "tope_por_autor", alm if eliminar else None)
            if eliminar:
                alm.pubs.pop(k, None)
        quedan = [c for c in quedan if c not in quitar]
    return quedan


# ---------------------------------------------------------------------------------------------
# Operaciones: descubrir · metricas · leer · citas · lote
# ---------------------------------------------------------------------------------------------
def _motor(cob: Dict[str, Any], nombre: str, estado: str, **kw: Any) -> None:
    cob["motores"].setdefault(nombre, {}).update({"estado": estado, **kw})


def _avisar(cob: Dict[str, Any], texto: str) -> None:
    if texto not in cob["avisos"]:
        cob["avisos"].append(texto)


def _parada(cob: Dict[str, Any], proveedor: str, e: Exception) -> None:
    p = {"proveedor": proveedor, "motivo": limpiar_control(redactar(str(e)))[:300],
         "alternativa": getattr(e, "alternativa", "") or ""}
    if p not in cob["paradas"]:                        # el cortacircuitos repite el mismo motivo: se anota una vez
        cob["paradas"].append(p)


AVISO_THREADS_ES = ("Threads en español: la búsqueda de pago es débil salvo con palabras propias del español (medido: "
                    "«emprendedores» 10/10 en español; «curso online» trajo portugués; «marketing digital», inglés e "
                    "indonesio). El actor no tiene filtro de español: el idioma se filtra después.")


def hashtag_de(consulta: str) -> str:
    """Hashtag probable de una consulta corta: sin espacios, sin acentos, solo letras minúsculas, cifras y guion bajo."""
    s = unicodedata.normalize("NFKD", consulta.lower()).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9_]", "", s)


def _lanzar_pago(ses: Sesion, alm: Almacen, cob: Dict[str, Any], nombre: str, actor: str, entrada: dict,
                 normalizador: Callable[[dict], Optional[Dict[str, Any]]], tema: str, claves_run: List[str],
                 via: str, extra_motor: Optional[Dict[str, Any]] = None) -> None:
    """Una ejecución de la búsqueda de pago: valida la entrada ANTES de llamar, respeta el arranque fijo de Threads y
    vuelca cada resultado como candidato con su primera lectura de métricas."""
    try:
        validar_entrada(actor, entrada)
        estimado = cota_estimada(actor, entrada)
        minimo = cota_minima(actor, entrada)
        if actor == ACTOR_THREADS:
            if ses.tope_llamada + 1e-9 < minimo:
                _motor(cob, nombre, "omitida_tope", cota_minima_usd=round(minimo, 4), tope_usd=round(ses.tope_llamada, 4))
                _avisar(cob, mensaje_cota_minima(actor, ses.tope_llamada, minimo))
                return
            cota = estimado                           # el arranque es fijo: no se puede recortar la cota
        else:
            cota = min(ses.tope_llamada, estimado)
        print(f"Búsqueda de pago ({nombre}): consultas elegidas {(extra_motor or {}).get('consultas')} · tope de la llamada "
              f"{cota:.4f} USD.", file=sys.stderr, flush=True)
        r = ses.apify_ejecutar(actor, entrada, cota, posts_de_entrada(actor, entrada))
        nuevas = 0
        for it in r.get("items", []):
            try:
                lect = normalizador(it)
                if not lect or not lect.get("url"):
                    continue
                lect["consultado"] = r.get("consultado") or lect["consultado"]
                info = parsear_url(lect["url"])
                if info is None or info["red"] != lect["red"]:
                    cob["descartes"]["no_es_publicacion"] += 1
                    continue
                pub, existia = agregar_candidato(alm, {"motor": "apify_busqueda", "url": lect["url"]},
                                                 lect.get("consulta") or tema, via=via)
                agregar_lectura(pub, lect)
            except Exception:  # noqa: BLE001 - un registro con forma inesperada no debe tirar lo ya pagado
                cob["descartes"]["registro_ilegible"] = cob["descartes"].get("registro_ilegible", 0) + 1
                _avisar_registro_ilegible(cob)
                continue
            if existia or pub["clave"] in claves_run:
                cob["descartes"]["duplicado"] += 1
            else:
                nuevas += 1
            if pub["clave"] not in claves_run:
                claves_run.append(pub["clave"])
        _motor(cob, nombre, r.get("estado") or "ok", resultados=len(r.get("items", [])), nuevas=nuevas, via=via,
               coste_usd=r.get("coste_usd"), **({"de_cache": True} if r.get("cache") else {}), **(extra_motor or {}),
               mensaje=limpiar_control(redactar(str(r["mensaje"]))) if r.get("mensaje") else None)
    except ClaveAusente as e:
        _motor(cob, nombre, "sin_clave")
        _avisar(cob, str(e))
    except (LimiteAlcanzado, PresupuestoAgotado, ClaveRechazada, ClaveMalFormada, EntradaNoProbada, MetaSearchError) as e:
        _motor(cob, nombre, "parada")
        _parada(cob, "apify", e)


def _pago_red(ses: Sesion, alm: Almacen, cob: Dict[str, Any], red: str, tema: str, idioma: Optional[str],
              claves_run: List[str]) -> None:
    if red == "facebook":
        entrada = {"categories": [tema], "searchType": "posts", "resultsLimit": N_PAGO}
        _lanzar_pago(ses, alm, cob, "facebook/apify_busqueda", ACTOR_FB_BUSQUEDA, entrada, norm_fb_busqueda, tema,
                     claves_run, "busqueda_de_pago", {"consultas": [tema]})
        _avisar(cob, "Facebook: el actor de búsqueda no respeta la ventana de fechas (se filtra después) y a una parte de "
                     "los resultados les faltan los comentarios (quedan en cobertura incompleta como sin_metricas).")
    elif red == "instagram":
        qs = palabras_clave(tema, MAX_PALABRAS_THREADS, 1)
        if not qs:
            _motor(cob, "instagram/apify_busqueda", "omitida_sin_palabras")
            _avisar(cob, "Instagram: el tema no tiene palabras clave utilizables para la búsqueda de pago.")
            return
        _lanzar_pago(ses, alm, cob, "instagram/apify_populares", ACTOR_IG_BUSQUEDA,
                     {"search": qs[0], "searchType": "popular", "searchLimit": N_PAGO}, norm_apify_ig_busqueda, tema,
                     claves_run, "populares_antiguos", {"consultas": qs})
        tag = hashtag_de(qs[0])
        if tag:
            _lanzar_pago(ses, alm, cob, "instagram/apify_hashtag", ACTOR_IG,
                         {"directUrls": [f"https://www.instagram.com/explore/tags/{tag}/"], "resultsType": "posts",
                          "resultsLimit": N_PAGO}, norm_apify_ig_hashtag, tema, claves_run, "lo_ultimo_sin_traccion",
                         {"consultas": ["#" + tag]})
        _avisar(cob, "Instagram: la búsqueda de pago es complementaria. «populares» trae reels relevantes pero antiguos y "
                     "«hashtag» solo lo último, sin tracción; el camino principal es descubrir con Perplexity y medir por URL.")
    elif red == "threads":
        qs = palabras_clave(tema, MAX_PALABRAS_THREADS, MAX_QUERIES_PAGO)
        if not qs:
            _motor(cob, "threads/apify_busqueda", "omitida_sin_palabras")
            _avisar(cob, "Threads: el tema no tiene palabras clave utilizables para la búsqueda de pago.")
            return
        if idioma == "es":
            _avisar(cob, AVISO_THREADS_ES)
        entrada = {"mode": "search", "keywords": qs, "max_posts": N_PAGO, "search_filter": "top"}
        _lanzar_pago(ses, alm, cob, "threads/apify_busqueda", ACTOR_THREADS, entrada, norm_threads, tema, claves_run,
                     "busqueda_de_pago", {"consultas": qs})


# Máximo de palabras clave (cada una de 1-2 palabras) en UNA ejecución de Threads con `search_filter: "top"`, el único que
# usa el skill: 3 palabras clave, SUCCEEDED, 20 posts (piloto, dia2/busqueda/threads-busqueda-corta-top.json). Con 4 solo hay
# una ejecución, con `recent` y frases largas (dia2/busqueda/threads-busqueda.json: 10 posts, 3 «no_results»): no vale como
# prueba de `top`. Lo valida `validar_entrada` antes de llamar.
MAX_PALABRAS_EJECUCION_THREADS = 3


def _diferir_pago_threads(cob: Dict[str, Any], tema: str, idioma: Optional[str], diferidas: Dict[str, List[Any]]) -> None:
    """En `lote`, la búsqueda de pago de Threads no se lanza por tema (0,08 USD de arranque cada vez): se apuntan las
    palabras de cada tema y `pago_threads_lote` las lanza juntas al final."""
    qs = palabras_clave(tema, MAX_PALABRAS_THREADS, MAX_QUERIES_PAGO)
    if not qs:
        _motor(cob, "threads/apify_busqueda", "omitida_sin_palabras")
        _avisar(cob, "Threads: el tema no tiene palabras clave utilizables para la búsqueda de pago.")
        return
    if idioma == "es":
        _avisar(cob, AVISO_THREADS_ES)
    diferidas.setdefault("palabras", []).extend(qs)
    diferidas.setdefault("idiomas", []).append(idioma)


def pago_threads_lote(ses: Sesion, alm: Almacen, diferidas: Dict[str, List[Any]]) -> List[str]:
    """Una sola ejecución de la búsqueda de pago de Threads con las palabras de TODOS los temas de un `lote`, si caben en la
    cota de la llamada (arranque fijo 0,08 USD + 0,025 USD por palabra) y en MAX_PALABRAS_EJECUCION_THREADS; si no caben,
    en las ejecuciones justas, y lo declara. Poda lo traído como `descubrir` (idioma, relleno, ventana)."""
    cob = ses.cobertura
    palabras = list(dict.fromkeys(diferidas.get("palabras") or []))
    if not palabras:
        return []
    ficha = ACTORES[ACTOR_THREADS]
    caben = int((ses.tope_llamada + 1e-9 - ficha["arranque"]) / (N_PAGO * ficha["precio_item"]))
    por_ejecucion = max(1, min(caben, MAX_PALABRAS_EJECUCION_THREADS))
    trozos = [palabras[i:i + por_ejecucion] for i in range(0, len(palabras), por_ejecucion)]
    cabe_alguna = ses.tope_llamada + 1e-9 >= ficha["arranque"] + N_PAGO * ficha["precio_item"]       # ni una palabra cabe → ninguna se lanza
    if len(trozos) > 1 and cabe_alguna:
        _avisar(cob, f"Threads: las {len(palabras)} palabras de los temas no caben en una sola ejecución con --tope-usd "
                     f"{ses.tope_llamada:.2f} (cota = 0,08 + 0,025 por palabra; como mucho {MAX_PALABRAS_EJECUCION_THREADS} "
                     f"por ejecución): se lanzan en {len(trozos)} ejecuciones, cada una con su arranque de 0,08 USD.")
    descartes_antes = dict(cob["descartes"])
    medidas_antes = {c for c, p in alm.pubs.items() if lecturas_ok(p)}
    claves_run: List[str] = []
    for tr in trozos:
        _lanzar_pago(ses, alm, cob, "threads/apify_busqueda", ACTOR_THREADS,
                     {"mode": "search", "keywords": tr, "max_posts": N_PAGO, "search_filter": "top"}, norm_threads, "",
                     claves_run, "busqueda_de_pago", {"consultas": tr})
    reindexar(alm)
    claves = [c for c in dict.fromkeys(claves_run) if c in alm.pubs]
    idiomas = {i for i in diferidas.get("idiomas") or []}
    idioma = next(iter(idiomas)) if len(idiomas) == 1 else None          # con temas en idiomas distintos, no se filtra
    quedan = [c for c in claves if c in medidas_antes] + filtrar(
        alm, [c for c in claves if c not in medidas_antes], cob, idioma, alm.meta.get("desde"), alm.meta.get("hasta"), 0,
        eliminar=True)
    acumulado = alm.meta.setdefault("descartes_descubrir", {})
    for k, v in cob["descartes"].items():
        delta = v - descartes_antes.get(k, 0)
        if delta:
            acumulado[k] = acumulado.get(k, 0) + delta
    ses.volcar(alm)
    alm.guardar()
    return quedan


def descubrir(ses: Sesion, alm: Almacen, tema: str, desde: Optional[str] = None, hasta: Optional[str] = None,
              n: int = 10, idioma: str = "auto", pago: bool = False, motores: Optional[Iterable[str]] = None,
              redes: Iterable[str] = REDES, hoy: Optional[dt.datetime] = None,
              diferir_threads: Optional[Dict[str, List[Any]]] = None) -> Dict[str, Any]:
    """Descubre publicaciones en una o varias redes: buscadores de cada red (+ búsqueda de pago de Apify con pago=True).

    La ventana por defecto son los últimos 30 días. Se poda lo que ya se sabe malo (otro idioma, relleno, fuera de
    ventana por una fecha ya conocida) antes de pagar métricas; lo que no tiene fecha sigue en juego hasta enriquecer (C4)."""
    cob = ses.cobertura
    hoy = hoy or ahora_utc()
    desde = desde or (hoy - dt.timedelta(days=30)).strftime("%Y-%m-%d")
    parse_dia(desde)
    parse_dia(hasta)
    redes = [r for r in REDES if r in set(redes)]
    if not redes:
        raise MetaSearchError(f"Ninguna red válida. Opciones: {', '.join(REDES)} o todas.")
    idioma_res = resolver_idioma(idioma, tema)
    alm.meta.update({"tema": tema, "desde": desde, "hasta": hasta, "idioma": idioma_res})
    alm.meta["redes"] = sorted(set(alm.meta.get("redes") or []) | set(redes))
    temas = alm.meta.setdefault("temas", [])
    if tema not in temas:
        temas.append(tema)
    descartes_antes = dict(cob["descartes"])
    pares: List[Tuple[str, str]] = []
    for red in redes:
        elegidos = MOTORES_POR_RED[red] if motores is None else tuple(motores)
        pares += [(red, m) for m in elegidos if m in BUSCADORES]

    def uno(par: Tuple[str, str]) -> Tuple[Tuple[str, str], str, List[dict], Optional[Exception]]:
        red, m = par
        try:
            cands, _ = ses.buscar(m, tema, n, desde, hasta, red, hoy)
            return par, "ok", cands, None
        except ClaveAusente as e:
            return par, "sin_clave", [], e
        except (LimiteAlcanzado, PresupuestoAgotado) as e:
            return par, "limite" if isinstance(e, LimiteAlcanzado) else "sin_presupuesto", [], e
        except ClaveRechazada as e:
            return par, "clave_rechazada", [], e
        except ClaveMalFormada as e:
            return par, "clave_mal_formada", [], e
        except MetaSearchError as e:
            return par, "error", [], e

    resultados: Dict[Tuple[str, str], Tuple[str, List[dict], Optional[Exception]]] = {}
    if pares:
        with cf.ThreadPoolExecutor(max_workers=len(pares)) as ex:
            for par, estado, cands, err in ex.map(uno, pares):
                resultados[par] = (estado, cands, err)

    medidas_antes = {c for c, p in alm.pubs.items() if lecturas_ok(p)}
    claves_run: List[str] = []
    for par in pares:
        red, m = par
        estado, cands, err = resultados[par]
        nuevas = 0
        for c in cands:
            info = parsear_url(c.get("url") or "")
            if info is None or info["red"] != red:
                cob["descartes"]["no_es_publicacion"] += 1
                continue
            pub, existia = agregar_candidato(alm, c, tema, via="buscador")
            if existia or pub["clave"] in claves_run:
                cob["descartes"]["duplicado"] += 1
            else:
                nuevas += 1
            if pub["clave"] not in claves_run:
                claves_run.append(pub["clave"])
        _motor(cob, f"{red}/{m}", estado, resultados=len(cands), nuevas=nuevas)
        if err is not None:
            if estado == "sin_clave":
                _avisar(cob, str(err))
            else:
                _parada(cob, m, err)

    if pago:
        for red in redes:
            if red == "threads" and diferir_threads is not None:
                _diferir_pago_threads(cob, tema, idioma_res, diferir_threads)      # `lote`: una sola ejecución al final
            else:
                _pago_red(ses, alm, cob, red, tema, idioma_res, claves_run)
    objetos = [alm.pubs[c] for c in dict.fromkeys(claves_run) if c in alm.pubs]
    reindexar(alm)
    claves_run = []
    for p in objetos:
        k = p["clave"] if p["clave"] in alm.pubs else (alm.resolver(p["clave"]) or p["clave"])
        if k in alm.pubs and k not in claves_run:
            claves_run.append(k)
    por_podar = [c for c in claves_run if c not in medidas_antes]       # lo ya medido antes no se poda
    quedan = [c for c in claves_run if c in medidas_antes] + filtrar(alm, por_podar, cob, idioma_res, desde, hasta, 0,
                                                                      eliminar=True)
    acumulado = alm.meta.setdefault("descartes_descubrir", {})      # lo que ESTA llamada descartó, por motivo
    for k, v in cob["descartes"].items():
        delta = v - descartes_antes.get(k, 0)
        if delta:
            acumulado[k] = acumulado.get(k, 0) + delta
    ses.volcar(alm)
    alm.guardar()
    return {"tema": tema, "ventana": {"desde": desde, "hasta": hasta}, "idioma": idioma_res, "redes": redes,
            "claves": quedan, "cobertura": cob}


def precio_valido(v: Any, origen: str) -> float:
    """Precio por registro: un número finito y mayor que 0, o un error claro (nan, inf, negativo y 0 desactivarían el tope)."""
    try:
        x = float(v)
    except (TypeError, ValueError):
        raise MetaSearchError(f"{origen} debe ser un número finito mayor que 0 (recibido {limpiar_control(redactar(str(v)))[:40]!r}).") from None
    if not math.isfinite(x) or x <= 0:
        raise MetaSearchError(f"{origen} debe ser un número finito mayor que 0 (recibido {limpiar_control(redactar(str(v)))[:40]!r}).")
    return x


def _precio_bd() -> float:
    return precio_valido(os.environ.get("META_SEARCH_PRECIO_BD", PRECIO_BRIGHTDATA_REGISTRO), "META_SEARCH_PRECIO_BD")


def _medida_por_apify(pub: Dict[str, Any]) -> bool:
    """True si la publicación ya trae una lectura COMPLETA de la búsqueda de pago de Instagram (`apify_ig_busqueda`): me
    gusta, comentarios y texto. Es la misma empresa que el detalle: pagar el detalle (0,0027 USD por URL) solo refrescaría
    una lectura que ya no puede contrastarse con otra de Apify. Si a la de la búsqueda le falta alguno de los tres campos
    (un reel sin pie de foto, comentarios cerrados o sin dato) NO cuenta como detalle y se sigue pagando. La del hashtag
    tampoco cuenta nunca: trae lo último de la página, casi sin interacción todavía, y el detalle sí la refresca."""
    return any(l.get("proveedor") == "apify_ig_busqueda" and not l.get("error") and l.get("me_gusta") is not None
               and l.get("comentarios") is not None and bool(l.get("texto")) for l in pub.get("lecturas", []))


def metricas(ses: Sesion, alm: Almacen, claves: Optional[List[str]] = None, urls: Optional[List[str]] = None,
             max_urls: int = 25, proveedores: Iterable[str] = ("apify", "brightdata")) -> Dict[str, Any]:
    """Pide las métricas por URL (Instagram: Apify y Bright Data; Facebook: Bright Data; Threads: ningún proveedor lee
    Threads por URL) y las cruza (C3)."""
    cob = ses.cobertura
    if isinstance(max_urls, bool) or not isinstance(max_urls, int) or max_urls < 1:
        raise MetaSearchError(f"max_urls debe ser un entero >= 1 (recibido {max_urls!r}).")
    proveedores = tuple(proveedores)
    nuevas: List[str] = []
    for u in urls or []:
        pub, _ = agregar_candidato(alm, {"motor": "manual", "url": u}, via="manual")
        if pub is None:
            cob["descartes"]["no_es_publicacion"] += 1
        else:
            nuevas.append(pub["clave"])
    if claves is None:
        claves = nuevas if urls else list(alm.pubs)
    else:
        claves = list(claves) + nuevas
    objetivo, perdidas = alm.resolver_lista(claves)
    if perdidas:
        _avisar(cob, f"{len(perdidas)} claves de la selección no están en registros.json (¿otra carpeta "
                     "--salida?): no se piden.")
    pend: Dict[str, List[str]] = {"apify_ig": [], "brightdata_instagram": [], "brightdata_facebook": []}
    threads_sin_lector = 0
    for c in objetivo:
        pub = alm.pubs[c]
        tiene = {l["proveedor"] for l in pub["lecturas"]}        # también las que dieron error: no se vuelve a pagar
        if pub["red"] == "instagram":
            if "apify" in proveedores and "apify_ig" not in tiene and not _medida_por_apify(pub):
                pend["apify_ig"].append(pub["url"])
            if "brightdata" in proveedores and "brightdata" not in tiene:
                pend["brightdata_instagram"].append(pub["url"])
        elif pub["red"] == "facebook":
            if "brightdata" in proveedores and "brightdata" not in tiene:
                pend["brightdata_facebook"].append(pub["url"])
        elif pub["red"] == "threads":
            threads_sin_lector += 1
    precio = {"apify_ig": ACTORES[ACTOR_IG]["precio_item"], "brightdata_instagram": _precio_bd(),
              "brightdata_facebook": _precio_bd()}
    for prov, lista in pend.items():
        lista[:] = list(dict.fromkeys(lista))
        limite = min(max_urls, int((ses.tope_llamada + 1e-9) / precio[prov]))   # la cota de UNA llamada nunca supera el tope
        limite = max(0, limite)
        if len(lista) > limite:
            _avisar(cob, f"{prov}: {len(lista) - limite} URL quedan sin pedir por el tope (--max-urls o "
                         "--tope-usd por llamada); repite `metricas` para el resto.")
            del lista[limite:]
    if threads_sin_lector:
        _motor(cob, "threads", "sin_lector_por_url", publicaciones=threads_sin_lector)
        _avisar(cob, f"Threads: el skill no lee Threads por URL (ningún proveedor lo ha dado de forma fiable en las "
                     f"pruebas); {threads_sin_lector} publicación(es) solo tendrán métricas si salieron de la búsqueda de "
                     "pago (`descubrir --pago`). El texto de respaldo se pide con `leer`.")

    def apify_ig() -> List[dict]:
        urls_ = pend["apify_ig"]
        entrada = {"directUrls": urls_, "resultsType": "details", "resultsLimit": 1}
        r = ses.apify_ejecutar(ACTOR_IG, entrada, round(len(urls_) * precio["apify_ig"], 7), len(urls_))
        out = []
        for it in r.get("items", []):
            l = normalizar_seguro(norm_apify_ig_detalle, it, cob)
            if l:
                l["consultado"] = r.get("consultado") or l["consultado"]
                out.append(l)
        _motor(cob, "apify_ig", r.get("estado") or "ok", enviadas=len(urls_), lecturas=len(out),
               coste_usd=r.get("coste_usd"), **({"de_cache": True} if r.get("cache") else {}),
               mensaje=limpiar_control(redactar(str(r["mensaje"]))) if r.get("mensaje") else None)
        return out

    def brightdata(red: str) -> List[dict]:
        nombre = f"brightdata_{red}"
        urls_ = pend[nombre]
        norm = norm_brightdata_instagram if red == "instagram" else norm_brightdata_facebook
        out: List[dict] = []
        coste = 0.0
        de_cache = False
        for i in range(0, len(urls_), BRIGHTDATA_LOTE):
            try:
                r = ses.brightdata_ejecutar(red, urls_[i:i + BRIGHTDATA_LOTE], precio[nombre])
            except MetaSearchError as e:
                e.parciales = out        # lo ya pagado de los lotes anteriores no se pierde: se empareja igualmente
                _motor(cob, nombre, "parada", enviadas=len(urls_), lecturas=len(out), coste_usd=round(coste, 6))
                raise
            coste += r.get("coste_usd") or 0.0
            de_cache = de_cache or bool(r.get("cache"))
            for it in r.get("items", []):
                l = normalizar_seguro(norm, it, cob)
                if l:
                    if not l["ts_proveedor"]:
                        l["consultado"] = r.get("consultado") or l["consultado"]
                    out.append(l)
        _motor(cob, nombre, "ok", enviadas=len(urls_), lecturas=len(out), coste_usd=round(coste, 6),
               **({"de_cache": True} if de_cache else {}))
        return out

    def correr(nombre: str, fn: Callable[[], List[dict]]) -> Tuple[str, List[dict], Optional[Exception]]:
        if not pend[nombre]:
            _motor(cob, nombre, "nada_que_pedir")
            return nombre, [], None
        try:
            return nombre, fn(), None
        except Exception as e:  # noqa: BLE001 - se informa en la cobertura, no se oculta
            return nombre, list(getattr(e, "parciales", [])), e

    trabajos: List[Tuple[str, Callable[[], List[dict]]]] = []
    if "apify" in proveedores:
        trabajos.append(("apify_ig", apify_ig))
    if "brightdata" in proveedores:
        trabajos += [("brightdata_instagram", lambda: brightdata("instagram")),
                     ("brightdata_facebook", lambda: brightdata("facebook"))]
    lecturas: List[dict] = []
    if trabajos:
        with cf.ThreadPoolExecutor(max_workers=len(trabajos)) as ex:
            for nombre, lects, err in ex.map(lambda t: correr(*t), trabajos):
                lecturas.extend(lects)
                if err is None:
                    continue
                prov_err = "apify" if nombre.startswith("apify") else "brightdata"
                if isinstance(err, ClaveAusente):
                    _motor(cob, nombre, "sin_clave")
                    _avisar(cob, str(err))
                elif isinstance(err, MetaSearchError):
                    _motor(cob, nombre, "parada")
                    _parada(cob, prov_err, err)
                else:
                    raise err
    emparejadas = emparejar(alm, lecturas)
    ses.volcar(alm)
    alm.guardar()
    return {"claves": objetivo, "lecturas": len(lecturas), "emparejadas": emparejadas, "cobertura": cob}


# Muro de inicio de sesión que Facebook, Instagram o Threads sirven a un lector sin cuenta: NO es el texto de la
# publicación. Heurística: hacen falta señales de TRES familias distintas (entrar, contraseña, correo o teléfono, crear
# cuenta, «olvidé la contraseña», «continuar con Instagram»…) en un texto corto; un post que solo diga «inicia sesión»
# no cae. No es una garantía: un muro con otras palabras pasaría y se declara como «texto de respaldo».
_MURO_SESION = tuple(re.compile(p) for p in (
    r"(?i)\blog\s?(?:in|into|on)\b|\bsign\s?in\b|iniciar\s+sesi[oó]n|inicia\s+sesi[oó]n|iniciar\s+sess[aã]o|connectez-vous",
    r"(?i)\bpassword\b|contrase[ñn]a|\bsenha\b|mot de passe",
    r"(?i)email or phone|phone number,? or email|correo electr[oó]nico o (?:tel[eé]fono|n[uú]mero)|e-?mail ou telefone",
    r"(?i)create (?:a )?(?:new )?account|\bsign\s?up\b|crear (?:una )?cuenta|reg[ií]strate|criar (?:nova )?conta",
    r"(?i)forgot(?:ten)?\b.{0,20}(?:password|account)|olvidaste|esqueceu",
    r"(?i)continue with (?:instagram|facebook)|continuar con (?:instagram|facebook)|log in with username|"
    r"inicia sesi[oó]n con (?:tu )?(?:nombre|usuario)"))


# Un muro es CASI TODO formulario: rótulos cortos («Email or phone number», «Log In», «Forgot account?»). Un texto que habla de
# iniciar sesión o recuperar la cuenta pero lo hace en frases (un tutorial, una pieza de soporte) no es un muro.
MAX_CARACTERES_MURO = 1500                  # un muro de verdad es breve (con el pie de enlaces e idiomas ronda 1.300)
MAX_PALABRAS_FRASE_MURO = 12                # y ninguna de sus «frases» (separadas por . ! ? · | • o salto de línea) es larga
MIN_PALABRAS_REFERENCIA = 3                 # una referencia con menos palabras distintivas («Instagram photo») no decide nada
# Lemas literales del muro de cada red (medidos en los crudos del piloto: Brave y Firecrawl devuelven el muro de Threads).
# Con uno de ellos bastan DOS familias de señales.
_LEMAS_MURO = re.compile(
    r"(?i)log in or sign up for threads|see what people are talking about and join the conversation|"
    r"log in with username instead|facebook helps you connect and share|sign up to see photos and videos|"
    r"log in to facebook|log into facebook|inicia sesi[oó]n o reg[ií]strate|reg[ií]strate para ver (?:fotos|las fotos)|"
    r"inicia sesi[oó]n en facebook|entre ou cadastre-se")
# Vocabulario del propio formulario: compartirlo con el fragmento del buscador no prueba que el texto sea de la publicación
_PALABRAS_DE_FORMULARIO = frozenset((
    "instagram", "facebook", "threads", "meta", "password", "account", "login", "sign", "phone", "email", "number",
    "forgot", "forgotten", "create", "continue", "username", "contraseña", "contrasena", "cuenta", "sesión", "sesion",
    "correo", "electrónico", "electronico", "teléfono", "telefono", "inicia", "iniciar", "regístrate", "registrate",
    "olvidaste", "senha", "conta", "connectez", "english", "español", "português", "portugues", "brasil"))


def _palabras_distintivas(s: Optional[str]) -> set:
    """Palabras de 5 o más letras, en minúsculas, que no son vocabulario de formulario."""
    return {w for w in re.findall(r"[^\W\d_]{5,}", (s or "").lower()) if w not in _PALABRAS_DE_FORMULARIO}


def _familias_de_muro(t: str) -> int:
    return sum(1 for p in _MURO_SESION if p.search(t))


def _es_lista(frase: str) -> bool:
    """Una «frase» que es una lista (pie de enlaces, idiomas): la mayoría de sus palabras empiezan en mayúscula o no son
    letras. No cuenta como frase larga."""
    ps = frase.split()
    if len(ps) <= MAX_PALABRAS_FRASE_MURO:
        return False
    return sum(1 for w in ps if not w[0].isalpha() or w[0].isupper()) >= 0.6 * len(ps)


def es_muro_de_sesion(texto: Optional[str], referencia: Optional[str] = None) -> bool:
    """True si el texto es un muro de inicio de sesión: señales de TRES familias, texto de menos de 1.500 caracteres y,
    además, casi todo formulario (breve y sin ninguna frase larga) o sin ninguna palabra en común con la `referencia`
    (el título o el fragmento con que el buscador dio esa publicación). Un texto que cuente cómo iniciar sesión o
    recuperar la cuenta, en frases, no cae. Heurística: no es una garantía."""
    t = texto or ""
    if len(t) > MAX_CARACTERES_MURO:
        return False
    frases = re.split(r"[.!?\n·|•]+", t)
    prosa = sum(1 for f in frases if len(f.split()) > MAX_PALABRAS_FRASE_MURO and not _es_lista(f))
    if prosa >= 2:
        return False      # dos o más frases largas en prosa: es un texto (quizá con el muro pegado detrás), no un formulario
    familias = _familias_de_muro(t)
    if familias >= 2 and _LEMAS_MURO.search(t):
        return True
    if familias < 3:
        return False
    if prosa == 0:
        return True                                     # casi todo formulario: rótulos cortos y listas de enlaces
    # Texto con frases: decide la referencia (título o fragmento del buscador) solo si sirve: con palabras distintivas
    # suficientes y sin ser ella misma un muro (un muro no avala a otro muro).
    ref = referencia or ""
    distintivas = _palabras_distintivas(ref)
    if len(distintivas) < MIN_PALABRAS_REFERENCIA or _familias_de_muro(ref) >= 2 or _LEMAS_MURO.search(ref):
        return False
    return not (_palabras_distintivas(t) & distintivas)


def completar_texto(ses: Sesion, alm: Almacen, pub: Dict[str, Any], con_proveedor: bool = True) -> Optional[str]:
    """Texto literal: el del proveedor de métricas; si falta, Exa contents; si falta, Firecrawl. Sin texto → None."""
    cob = ses.cobertura
    texto, _ = texto_de_pub(pub)
    if texto:
        return texto
    prov = {"instagram": "apify", "facebook": "brightdata"}.get(pub["red"])      # Threads no tiene lector por URL
    hay_proveedor = False
    if con_proveedor and prov:
        try:
            hay_proveedor = bool(clave(prov, obligatoria=False))
        except ClaveMalFormada as e:
            _avisar(cob, f"{e} Se sigue con Exa/Firecrawl para el texto.")
    if hay_proveedor:
        try:
            metricas(ses, alm, [pub["clave"]], proveedores=(prov,))
            pub = alm.pubs.get(alm.resolver(pub["clave"]) or "") or pub
            texto, _ = texto_de_pub(pub)
            if texto:
                return texto
        except MetaSearchError as e:
            _parada(cob, prov, e)
    for k, fn, prov2 in (("exa_contents", ses.exa_contents, "exa"), ("firecrawl_scrape", ses.firecrawl_scrape, "firecrawl")):
        try:
            if not clave(prov2, obligatoria=False):
                continue
            t, cortado = fn(pub["url"])
        except ClaveMalFormada as e:
            _avisar(cob, f"{e} Se sigue con el siguiente proveedor de texto.")
            continue
        except MetaSearchError as e:
            _parada(cob, prov2, e)
            continue
        if t and es_muro_de_sesion(t, texto_para_juzgar(pub)):        # sin texto propio: título + fragmentos del buscador
            # la página pidió iniciar sesión: ese texto no es de la publicación y no se entrega como si lo fuera
            _aviso_pub(pub, "texto_de_respaldo_descartado_muro_de_sesion")
            _avisar(cob, f"{k}: la página devolvió un muro de inicio de sesión, no el texto de la publicación; se descartó "
                         "(la ficha queda sin_texto).")
            continue
        if t:
            pub["textos_extra"][k] = t
            if cortado:
                avisos = pub.setdefault("avisos_extra", [])
                if "comentarios_de_terceros_omitidos" not in avisos:
                    avisos.append("comentarios_de_terceros_omitidos")
                aviso = ("comentarios_de_terceros_omitidos: el texto de respaldo traía un bloque de comentarios de "
                         "otras personas; se cortó antes de él y no se imprime ni se guarda.")
                if aviso not in cob["avisos"]:
                    cob["avisos"].append(aviso)
            return t
    return None


def leer(ses: Sesion, alm: Almacen, url: str) -> Dict[str, Any]:
    info = parsear_url(url)
    if info is None:
        raise MetaSearchError("Esa URL no es una publicación de Instagram (/p/, /reel/, /tv/), Threads (/@usuario/post/…) "
                              "ni Facebook (/posts/, /videos/, /reel/, /groups/…/posts/, permalink.php, /share/…).")
    pub, _ = agregar_candidato(alm, {"motor": "manual", "url": url}, via="manual")
    assert pub is not None
    texto = completar_texto(ses, alm, pub)
    ses.volcar(alm)
    alm.guardar()
    ficha = construir_ficha(alm.pubs.get(alm.resolver(pub["clave"]) or "") or pub)
    return {"url": ficha["url"], "texto": texto, "texto_fuente": ficha["texto_fuente"],
            "estado": "ok" if texto else "sin_texto", "avisos": ficha["avisos"], "autor": ficha["autor"],
            "cobertura": ses.cobertura}


def citas(ses: Sesion, alm: Almacen, claves: Optional[List[str]] = None, desde: Optional[str] = None,
          hasta: Optional[str] = None, idioma: Optional[str] = None, max_por_autor: int = 2, verificar: bool = False,
          buscar: Optional[str] = None, min_me_gusta: int = 0, anonimizar: bool = False,
          sin_url: bool = False, redes: Optional[Iterable[str]] = None) -> Dict[str, Any]:
    """Entrega final en DOS bloques (C2): «cumplen el contrato» y «cobertura incompleta» con el motivo de cada caso.

    La ventana (C4) se aplica AQUÍ, después de enriquecer: lo que no tiene fecha ni tras enriquecer va a la cobertura
    incompleta como sin_fecha y NO cuenta como dentro de la ventana."""
    cob = nueva_cobertura()
    desde = desde or alm.meta.get("desde")
    hasta = hasta or alm.meta.get("hasta")
    patron = re.compile(buscar, re.I) if buscar else None
    elegidas = [r for r in REDES if r in set(redes)] if redes is not None else list(REDES)
    previas: Dict[str, int] = dict(alm.meta.get("descartes_descubrir") or {})
    if not previas:                                  # registros antiguos: solo lo que quedó apuntado clave a clave
        for motivo in alm.descartados.values():
            previas[motivo] = previas.get(motivo, 0) + 1
    seleccion = claves if claves is not None else list(alm.pubs)
    seleccion = [c for c in seleccion if (alm.resolver(c) is None) or alm.pubs[alm.resolver(c)]["red"] in elegidas]
    quedan = filtrar(alm, seleccion, cob, idioma, desde, hasta, max_por_autor, eliminar=False)
    cumplen: List[dict] = []
    incompletas: List[dict] = []
    for c in quedan:
        pub = alm.pubs[c]
        ficha = construir_ficha(pub)
        if desde or hasta:
            if ficha["fecha"] is None and "sin_fecha" not in ficha["motivos"]:
                ficha["motivos"].append("sin_fecha")
        if patron and not (ficha["texto"] and patron.search(ficha["texto"])):
            cob["descartes"]["no_coincide_patron"] = cob["descartes"].get("no_coincide_patron", 0) + 1
            continue
        if verificar:
            ficha["verificacion_texto"] = verificar_texto(pub)
        if not ficha["motivos"] and min_me_gusta and (ficha["me_gusta"] or 0) < min_me_gusta:
            cob["descartes"]["bajo_minimo_me_gusta"] = cob["descartes"].get("bajo_minimo_me_gusta", 0) + 1
            continue
        ficha = aplicar_privacidad(ficha, anonimizar, sin_url)
        (incompletas if ficha["motivos"] else cumplen).append(ficha)
    cumplen.sort(key=lambda f: (f["fecha"] or ""), reverse=True)
    motivos_total: Dict[str, int] = {}
    for f in incompletas:
        for m in f["motivos"]:
            motivos_total[m] = motivos_total.get(m, 0) + 1
    cob["incompletas_por_motivo"] = motivos_total
    if sin_url:
        cob["descartados"] = []              # con --sin-url la cobertura lleva solo recuentos, nunca IDs ni claves
    cob["descartes_previos"] = previas
    total = dict(previas)
    for k, v in cob["descartes"].items():
        if v:
            total[k] = total.get(k, 0) + v
    cob["descartes_total"] = total
    ses.volcar(alm)                       # lo de este proceso (p. ej. dentro de --completo) también cuenta
    cobertura_de_investigacion(alm, ses, cob)
    cob["calidad_medida"] = {r: CALIDAD_MEDIDA[r] for r in REDES
                             if r in CALIDAD_MEDIDA and any(f.get("red") == r for f in cumplen + incompletas)}
    temas = alm.meta.get("temas") or ([alm.meta["tema"]] if alm.meta.get("tema") else [])
    return {"consultado": iso_local(), "tema": " · ".join(temas) if temas else None,
            "ventana": {"desde": desde, "hasta": hasta}, "redes": elegidas,
            "idioma": idioma or alm.meta.get("idioma"), "idioma_filtrado": idioma,
            "cumplen": cumplen, "cobertura_incompleta": incompletas, "cobertura": cob,
            "privacidad": {"anonimizar_autores": anonimizar, "sin_url": sin_url,
                           "ficheros_de_trabajo_sin_seudonimizar": bool(anonimizar or sin_url)}}



def cobertura_de_investigacion(alm: Almacen, ses: Sesion, cob: Dict[str, Any]) -> None:
    """Trae a la entrega el coste y la cobertura de TODAS las fases de la investigación (descubrir, metricas, leer;
    en este proceso o en otros). El coste sale del libro de gasto; lo que no se puede saber se declara desconocido."""
    sesiones = alm.meta.get("sesiones") if isinstance(alm.meta.get("sesiones"), dict) else {}
    motores: Dict[str, List[str]] = {}
    arranques = 0
    coste_sesiones = 0.0
    for _, f in sorted(sesiones.items(), key=lambda kv: str(kv[1].get("inicio") or "")):
        for p in f.get("paradas") or []:
            if p not in cob["paradas"]:
                cob["paradas"].append(p)
        for a in f.get("avisos") or []:
            _avisar(cob, a)
        for m, d in (f.get("motores") or {}).items():
            e = (d or {}).get("estado")
            if e and e not in motores.setdefault(m, []):
                motores[m].append(e)
        arranques += int(f.get("arranques_fallidos") or 0)
        coste_sesiones += float(f.get("coste_usd") or 0)
    cob["motores"] = {m: {"estado": ", ".join(es)} for m, es in motores.items()}
    cob["arranques_fallidos"] = arranques
    invs = {f.get("investigacion") for f in sesiones.values() if f.get("investigacion")} | {ses.investigacion}
    d = ses.libro.desglose(invs)
    coste: Dict[str, Any] = {"fuente": "libro_de_gasto", "investigaciones": len(invs)}
    trabajo = any(f.get("motores") or f.get("coste_usd") for f in sesiones.values())
    if d is None:
        coste.update({"estado": "desconocido", "usd": None})
        _avisar(cob, "Coste DESCONOCIDO: el libro de gasto existe pero no se pudo leer. No se declara 0.")
    elif d["filas"] == 0 and not trabajo and alm.pubs:
        coste.update({"estado": "desconocido", "usd": None})
        _avisar(cob, "Coste y cobertura de las fases anteriores DESCONOCIDOS: ni el libro de gasto ni registros.json "
                     "tienen nada de esta investigación (¿otra --investigacion, otro equipo o una versión anterior?).")
    else:
        usd = d["gastado_usd"] + d["reservado_sin_liquidar_usd"]
        estado = "liquidado"
        if d["reservado_sin_liquidar_usd"] > 0:
            estado = "incluye_reservas_sin_liquidar"
            _avisar(cob, f"El coste incluye {d['reservado_sin_liquidar_usd']:.4f} USD de reservas sin liquidar (en vuelo "
                         "o de un proceso caído; `libro --ver`). Se cuentan enteras.")
        if coste_sesiones > usd + 1e-6:          # el libro no cubre todo lo apuntado: manda el mayor, nunca el menor
            usd = coste_sesiones
            estado = "minimo_por_registros"
            _avisar(cob, "El libro de gasto no cubre todo lo que registros.json apunta (¿se movió o borró?): el coste "
                         "declarado es el de los registros, como mínimo.")
        coste.update({"estado": estado, "usd": round(usd, 6), "gastado_usd": d["gastado_usd"],
                      "reservado_sin_liquidar_usd": d["reservado_sin_liquidar_usd"],
                      "por_proveedor": d["por_proveedor"]})
    if alm.meta.get("fases_sin_registro"):
        _avisar(cob, "La cobertura de las fases anteriores (proveedores parados y avisos) no quedó registrada "
                     "(registros.json de una versión anterior): se desconoce; el coste sí sale del libro.")
    cob["coste_usd"] = coste["usd"]
    cob["coste"] = coste


def fragmento_de_pub(pub: dict, n: int = 200) -> str:
    """Hasta 200 caracteres para juzgar la relevancia ANTES de pagar métricas: el texto literal si ya se leyó; si no,
    el título o el texto que dio el buscador. Limpio de controles y en una sola línea."""
    limpio = re.sub(r"\s+", " ", limpiar_control(redactar(_fuente_del_fragmento(pub)))).strip()
    return limpio if len(limpio) <= n else limpio[:n - 1].rstrip() + "…"


def _fuente_del_fragmento(pub: dict) -> str:
    t, _ = texto_de_pub(pub)
    return t or pub.get("titulo") or next((x["texto"] for x in pub.get("snippets", []) if x.get("texto")), "") or ""


def avisos_del_fragmento(pub: dict) -> List[str]:
    """El fragmento del buscador es el texto más ajeno de todo el flujo (viene de páginas web arbitrarias) y es lo que se
    lee para decidir qué pagar: se le pasan los mismos avisos que a una ficha, sobre el texto entero de donde sale."""
    crudo = _fuente_del_fragmento(pub)
    avisos = avisos_texto(crudo)
    if hay_invisibles(crudo):
        avisos.append("caracteres_invisibles_en_el_texto")
    return avisos


_MD_ESPECIALES = re.compile(r"([\\`*_\[\]<>#|~])")


def md_linea(valor: Any) -> str:
    """Un campo de UNA línea del .md: sin saltos de línea (ni los Unicode), controles fuera y el markdown escapado, para
    que un autor o un texto ajeno no pueda abrir un encabezado, una lista ni un enlace fuera de su sitio."""
    t = re.sub(r"\s+", " ", limpiar_control(str(valor if valor is not None else ""))).strip()
    return _MD_ESPECIALES.sub(r"\\\1", t)


def md_url(valor: Any) -> str:
    """Una URL (o referencia) en una línea del .md: sin espacios ni controles y con los caracteres de markdown/HTML
    en porcentaje, para que no pueda cerrar el enlace ni abrir otro elemento."""
    t = re.sub(r"\s+", "", limpiar_control(str(valor if valor is not None else "")))
    return re.sub(r"[<>`\[\]|\\*]", lambda m: "%%%02X" % ord(m.group(0)), t)


def md_cita(texto: Any) -> str:
    """Texto literal en un blockquote: cada línea (incluidos los saltos Unicode) lleva su `> `."""
    lineas = limpiar_control(str(texto or "")).splitlines() or [""]
    return "\n".join("> " + l for l in lineas)


def fmt_n(v: Any) -> str:
    return "s.d." if v is None else f"{v:,}".replace(",", ".")


def linea_meta(f: dict) -> str:
    partes = [md_linea(f.get("autor")) or "autor s.d.", f.get("fecha") or "fecha s.d.",
              f"me gusta {fmt_n(f.get('me_gusta'))}", f"comentarios {fmt_n(f.get('comentarios'))}",
              f"compartidos {fmt_n(f.get('compartidos'))}"]
    if f.get("vistas") is not None:
        partes.append(f"vistas {fmt_n(f['vistas'])}")
    partes.append(f"métricas: {f.get('estado_metricas')}")
    if f.get("via"):
        partes.append("vía: " + ", ".join(md_linea(v.replace("_", " ")) for v in f["via"]))
    if f.get("fuentes"):
        partes.append("fuentes: " + ", ".join(f["fuentes"]))
    if f.get("verificacion_texto"):
        partes.append("texto: " + f["verificacion_texto"]["estado"])
    if f.get("fecha_fuente"):
        partes.append(f"fecha por {md_linea(f['fecha_fuente'].replace('_', ' '))}")
    if f.get("avisos"):
        partes.append("avisos: " + re.sub(r"\s+", " ", limpiar_control(", ".join(f["avisos"]))))
    partes.append(md_url(f.get("url") or f.get("id_publicacion") or ""))
    return " · ".join(p for p in partes if p)


AVISO_FICHEROS_DE_TRABAJO = ("AVISO: los ficheros de trabajo de la carpeta --salida (registros.json, descubrir-*.json y "
                             "descubrir-*.md) guardan los datos SIN seudonimizar (nombres, enlaces, textos). No los "
                             "compartas: comparte solo esta entrega.")


# Calidad medida a mano en las pruebas reales del 15-oct-2026 (3 temas: inglés negocio, español marketing, técnico; útil =
# del tema, en el idioma pedido y sin relleno). Facebook es la red principal; Instagram y Threads, complementarias. Se
# declara en cada entrega que traiga publicaciones de esas redes: revisa a mano antes de usarlas para decidir.
CALIDAD_MEDIDA = {
    "facebook": "Facebook (red principal): en las pruebas del 15-oct-2026, entre el 77 % y el 86 % de lo que cumple el "
                "contrato era útil (del tema, en el idioma pedido y sin relleno).",
    "instagram": "Instagram (complementaria): en las pruebas del 15-oct-2026, solo entre el 37 % y el 68 % de lo que "
                 "cumple el contrato era útil; abundan las promociones genéricas, los ganchos «comenta X» y los posts de "
                 "una línea. Revísalo a mano antes de decidir con ello.",
    "threads": "Threads (complementaria): en las pruebas del 15-oct-2026, solo entre el 0 % y el 40 % de lo que cumple "
               "el contrato era útil; la búsqueda de pago trae spam y otros idiomas, sobre todo en español. Revísalo a "
               "mano antes de decidir con ello.",
}


def render_citas(res: dict) -> str:
    cob = res["cobertura"]
    v = res["ventana"]
    redes = res.get("redes") or list(REDES)
    out = [f"# Meta · {md_linea(res.get('tema')) or 'publicaciones'} · corte {md_linea(res['consultado'])}", "",
           f"Redes: {', '.join(NOMBRE_RED[r] for r in redes if r in NOMBRE_RED)} · Ventana: {v.get('desde') or 's.d.'} → "
           f"{v.get('hasta') or 'hoy'} · idioma: {res.get('idioma') or 'cualquiera'} · "
           f"{len(res['cumplen'])} cumplen el contrato · {len(res['cobertura_incompleta'])} con cobertura incompleta",
           "", "Los contadores son los de cada red y NO se comparan entre redes: los «me gusta» de Instagram, Threads y "
           "Facebook (en Facebook, todas las reacciones) son magnitudes distintas.",
           "Las métricas son las de la fecha de consulta. La fecha sale del proveedor de métricas; en Instagram y Threads, "
           "sin fecha del proveedor, del código del enlace (precisión de unos minutos)."]
    for nota in (cob.get("calidad_medida") or {}).values():
        out.append("Calidad medida: " + nota)
    if res["privacidad"]["anonimizar_autores"] or res["privacidad"]["sin_url"]:
        out.append("Privacidad: los autores van seudonimizados (hash estable) y/o sin URL; el texto literal sigue "
                   "permitiendo localizar al autor.")
        if res["privacidad"]["anonimizar_autores"]:
            out.append("Los correos y teléfonos del texto se han sustituido por «[correo omitido]» / «[teléfono "
                       "omitido]» (alteración del literal declarada en cada ficha afectada).")
        out.append(AVISO_FICHEROS_DE_TRABAJO)
    out += ["", "## Cumplen el contrato", ""]
    for red in REDES:
        grupo = [f for f in res["cumplen"] if f.get("red") == red]
        if not grupo:
            continue
        out += [f"### {NOMBRE_RED[red]} ({len(grupo)})", ""]
        for f in grupo:
            out += [md_cita(f["texto"]), "", "— " + linea_meta(f), ""]
    if not res["cumplen"]:
        out += ["(ninguna)", ""]
    out += ["## Cobertura incompleta", ""]
    for f in res["cobertura_incompleta"]:
        txt = re.sub(r"\s+", " ", limpiar_control(f["texto"] or "")).strip()
        corto = md_linea((txt[:140] + "…") if len(txt) > 140 else txt)
        falta = f" (faltan: {', '.join(f['metricas_faltantes'])})" if "sin_metricas" in f["motivos"] and f.get("metricas_faltantes") else ""
        out.append(f"- **{', '.join(f['motivos'])}**{falta} · {NOMBRE_RED.get(f.get('red'), '?')} · "
                   f"{md_linea(f.get('autor')) or 'autor s.d.'} · "
                   f"{f.get('fecha') or 'fecha s.d.'} · {md_url(f.get('url') or f.get('id_publicacion'))}"
                   + (f" · «{corto}»" if corto else ""))
    if not res["cobertura_incompleta"]:
        out.append("(ninguna)")
    out += ["", "## Cobertura y huecos", ""]
    co = cob.get("coste") or {}
    if co.get("usd") is None:
        out.append("- Coste de la investigación: DESCONOCIDO (ver avisos)")
    else:
        prov = ", ".join(f"{md_linea(k)} {v_:.4f}" for k, v_ in sorted((co.get("por_proveedor") or {}).items()))
        out.append(f"- Coste de la investigación: {co['usd']:.4f} USD ({md_linea(co.get('estado'))}; libro de gasto"
                   + (f"; {prov}" if prov else "") + ")")
    if cob.get("motores"):
        out.append("- Motores y proveedores: " + ", ".join(f"{md_linea(m)} {md_linea(d_.get('estado'))}"
                                                           for m, d_ in cob["motores"].items()))
    for p in cob.get("paradas") or []:
        out.append(f"- PARADA {md_linea(p.get('proveedor'))}: {md_linea(p.get('motivo'))}"
                   + (f" Alternativa: {md_linea(p['alternativa'])}" if p.get("alternativa") else ""))
    if cob.get("arranques_fallidos"):
        out.append(f"- Ejecuciones fallidas (se cobra el arranque): {cob['arranques_fallidos']}")
    for a in cob.get("avisos") or []:
        out.append(f"- Aviso: {md_linea(a)}")
    d = {k: v_ for k, v_ in cob["descartes"].items() if v_}
    out.append("- Descartes de esta entrega: " + (", ".join(f"{k} {v_}" for k, v_ in d.items()) or "ninguno"))
    if cob.get("descartes_previos"):
        out.append("- Descartes al descubrir: " + ", ".join(f"{k} {v_}" for k, v_ in cob["descartes_previos"].items()))
    if cob.get("descartes_total"):
        out.append("- Descartes en total (descubrir + entrega): "
                   + ", ".join(f"{k} {v_}" for k, v_ in cob["descartes_total"].items()))
    if cob.get("incompletas_por_motivo"):
        out.append("- Cobertura incompleta por motivo: " + ", ".join(f"{k} {v_}" for k, v_ in cob["incompletas_por_motivo"].items()))
    return "\n".join(out) + "\n"



def res_para_json(res: dict) -> dict:
    """La entrega que va al `citas-*.json` (la que se lleva a hojas de cálculo e informes): el texto y el autor ajenos
    pasan por la misma limpieza que el `.md` y la consola (controles, redireccionado bidireccional, Tags y selectores de
    variación invisibles). El aviso `caracteres_invisibles_…` de la ficha dice que los había; `registros.json` los
    conserva tal cual llegaron."""
    out = copy.deepcopy(res)
    for bloque in ("cumplen", "cobertura_incompleta"):
        for f in out.get(bloque) or []:
            for k in ("texto", "autor"):
                if isinstance(f.get(k), str):
                    f[k] = limpiar_control(f[k])
    return out


def guardar_citas(ses: Sesion, res: dict) -> Tuple[Path, Path]:
    d = ses.exigir_salida()
    sello = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    for _ in range(100):
        suf = secrets.token_hex(2)
        pj, pm = d / f"citas-{sello}-{suf}.json", d / f"citas-{sello}-{suf}.md"
        try:        # se reservan los dos nombres de forma atómica: una entrega anterior no se sobrescribe NUNCA
            for ruta in (pj, pm):
                os.close(os.open(ruta, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644))
        except FileExistsError:
            continue
        escribir_json(pj, res_para_json(res))
        pm.write_text(render_citas(res), encoding="utf-8")
        return pm, pj
    raise MetaSearchError("No se pudo elegir un nombre libre para la entrega (citas-*): revisa la carpeta --salida.")


def leer_lista(fichero: Path) -> Tuple[List[str], List[str]]:
    temas, urls = [], []
    for l in fichero.read_text(encoding="utf-8").splitlines():
        l = l.strip()
        if not l or l.startswith("#"):
            continue
        (urls if l.lower().startswith("http") else temas).append(l)
    return temas, urls


# ---------------------------------------------------------------------------------------------
# salud y conectar
# ---------------------------------------------------------------------------------------------
def mostrar_ruta(p: Path) -> str:
    try:
        return str(p).replace(str(Path.home()), "~")
    except (RuntimeError, KeyError):
        return str(p)


def origen_clave(proveedor: str) -> Optional[str]:
    var = PROVEEDORES[proveedor]["var"]
    if os.environ.get(var, "").strip():
        return "entorno"
    if leer_claves().get(var, "").strip():
        return "fichero"
    return None


def validar_clave_gratis(proveedor: str) -> Tuple[Optional[bool], str]:
    """Comprobación SIN gasto, si el proveedor la tiene. (True|False|None si no se puede validar sin gastar, texto)."""
    try:
        tok = clave(proveedor, obligatoria=False)
    except ClaveMalFormada as e:
        return False, str(e)
    if not tok:
        return None, "sin clave"
    try:
        return _validar_clave_gratis(proveedor, tok)
    except PeticionNoEnviada:
        return None, "la petición no se pudo enviar (cabecera inválida): vuelve a copiar la clave"


def _validar_clave_gratis(proveedor: str, tok: str) -> Tuple[Optional[bool], str]:
    if proveedor == "apify":
        st, j = http("GET", APIFY_LIMITES, None, {"Authorization": "Bearer " + tok}, 30)
        if st == 200 and isinstance(j, dict):
            d = j.get("data") or {}
            try:
                return True, (f"uso del mes {float(d['current']['monthlyUsageUsd']):.2f} de "
                              f"{float(d['limits']['maxMonthlyUsageUsd']):.2f} USD")
            except (KeyError, TypeError, ValueError):
                return True, "la clave responde (no se pudo leer el uso mensual)"
        return (False if st in (401, 403) else None), f"HTTP {st}"
    if proveedor == "brightdata":
        # sin endpoint de saldo: se consulta el progreso de un snapshot inexistente; 401/403 = clave inválida
        st, _ = http("GET", "https://api.brightdata.com/datasets/v3/progress/s_comprobacion_sin_gasto", None,
                     {"Authorization": "Bearer " + tok}, 30)
        if st in (401, 403):
            return False, f"HTTP {st}: clave rechazada"
        if st == 0:
            return None, "sin red"
        return True, "la clave es aceptada (el saldo no se puede leer por API; míralo en el panel)"
    if proveedor == "firecrawl":
        st, j = http("GET", "https://api.firecrawl.dev/v2/team/credit-usage", None, {"Authorization": "Bearer " + tok}, 30)
        if st == 200:
            return True, "la clave responde"
        return (False if st in (401, 403) else None), f"HTTP {st}"
    return None, "no hay comprobación gratuita: se valida con la primera búsqueda (`salud --en-vivo`, ≈0,017 USD)"

def salud(en_vivo: bool = False, tope_usd: float = 0.05) -> int:
    print(f"meta-search {VERSION} · Python {sys.version.split()[0]} · {sistema()}")
    if sistema() == "windows":
        print("AVISO: no probado en Windows (el bloqueo del libro de gasto usa msvcrt y no se ha ejercitado).")
    base = dir_base()
    print(f"Datos y claves: {mostrar_ruta(base)}  (claves.env: "
          f"{'existe' if fichero_claves().is_file() else 'no existe'})")
    print("\nClaves (se leen del entorno o de claves.env; nunca se imprimen):")
    hay: Dict[str, bool] = {}
    for prov, v in PROVEEDORES.items():
        o = origen_clave(prov)
        hay[prov] = o is not None
        if o is None:
            print(f"  FALTA  {v['nombre']:<13} {v['var']}: {v['sin']}.")
            continue
        ok, txt = validar_clave_gratis(prov)
        marca = "OK   " if ok else ("MAL  " if ok is False else "SIN VALIDAR")
        print(f"  {marca} {v['nombre']:<13} ({o}) {limpiar_control(redactar(txt))}")
        if ok is False:
            hay[prov] = False
    print("\nCapacidades hoy:")
    descubre_algo = False
    for red in REDES:
        mot = [PROVEEDORES[m]["nombre"] for m in MOTORES_POR_RED[red] if hay.get(m)]
        descubre_algo = descubre_algo or bool(mot)
        print(f"  {NOMBRE_RED[red]:<10} descubrir: {', '.join(mot) if mot else 'ninguno'}")
    ig = [n for p, n in (("apify", "Apify"), ("brightdata", "Bright Data")) if hay.get(p)]
    print("  Métricas por URL:")
    # El contraste exige DOS EMPRESAS distintas: las lecturas de búsqueda, hashtag y detalle de Apify cuentan como una.
    if len(ig) == 1:
        extra_ig = (" (una sola empresa: todo quedará como una_fuente; la búsqueda de pago y el detalle de Apify cuentan "
                    "como una)" if hay.get("apify") else
                    " (una sola empresa: todo quedará como una_fuente; con Apify tendrías una segunda empresa para contrastar)")
    else:
        extra_ig = " (dos empresas: se pueden contrastar)" if len(ig) == 2 else ""
    print(f"    Instagram: {' + '.join(ig) if ig else 'ninguna'}" + extra_ig)
    print(f"    Facebook:  {'Bright Data' if hay.get('brightdata') else 'ninguna'}"
          + ((" (con --pago, la búsqueda de Apify es una segunda empresa y permite el contraste)" if hay.get("apify")
              else " (una sola fuente)") if hay.get("brightdata") else ""))
    print("    Threads:   sin lector por URL (solo trae métricas la búsqueda de pago; una sola fuente)")
    print("  Búsqueda de pago (con --pago): " + ("sí, las tres redes (Apify)" if hay.get("apify") else "no (necesita Apify)"))
    try:
        mes = Libro().total_mes(dt.datetime.now().strftime("%Y-%m"))
        if mes:
            print("\nGasto liquidado este mes en el libro (USD): " + ", ".join(f"{k} {v:.4f}" for k, v in sorted(mes.items())))
    except MetaSearchError:
        pass
    mide = hay.get("apify") or hay.get("brightdata")
    if not descubre_algo and not mide:
        print("\nModo: ninguno. Conecta al menos un buscador para descubrir y Apify o Bright Data para las métricas:")
        print("  python3 meta_helper.py conectar firecrawl    (copia antes la clave al portapapeles)")
        print("  guía de altas: references/instalacion-y-alta.md")
    elif not mide:
        print("\nSin Apify ni Bright Data se puede descubrir pero no medir: las publicaciones saldrán como cobertura "
              "incompleta (sin_metricas). Conecta uno de los dos.")
    elif not descubre_algo:
        print("\nSin buscadores no se descubre, pero `metricas` sí acepta URL que ya tengas (por ejemplo, de la "
              "búsqueda web de tu agente).")
    if en_vivo:
        ses = Sesion(None, tope_total=tope_usd, tope_llamada=tope_usd, usar_cache=False,
                     investigacion="salud-" + dt.datetime.now().strftime("%Y%m%d-%H%M%S"))
        print(f"\n--en-vivo: UNA búsqueda mínima por buscador (≈0,017 USD en total, tope {tope_usd:.2f}).")
        for m in BUSCADORES:
            if not hay.get(m):
                continue
            try:
                cands, coste = ses.buscar(m, "ai", 1, red="instagram")
                print(f"  OK   {PROVEEDORES[m]['nombre']:<13} {len(cands)} resultado(s), {coste:.4f} USD")
            except MetaSearchError as e:
                print(f"  MAL  {PROVEEDORES[m]['nombre']:<13} {redactar(str(e))[:200]}")
    return 0


def leer_portapapeles() -> Optional[str]:
    cmds = {"macos": [["pbpaste"]],
            "linux": [["xclip", "-selection", "clipboard", "-o"], ["xsel", "-ob"], ["wl-paste", "-n"]],
            "windows": [["powershell", "-NoProfile", "-Command", "Get-Clipboard"]]}[sistema()]
    for cmd in cmds:
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            continue
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout
    return None


def _exigir_ascii(valor: str) -> None:
    """Una clave solo lleva ASCII imprimible: un carácter invisible (U+200B) o una comilla tipográfica se rechaza al
    cargarla. Se nombran los puntos de código ofensores, nunca el valor."""
    malos = sorted({f"U+{ord(c):04X}" for c in valor if not "!" <= c <= "~"})
    if malos:
        raise MetaSearchError("Lo copiado contiene caracteres que no son ASCII imprimible (" + ", ".join(malos[:6])
                                  + "): invisibles, comillas tipográficas o espacios raros que rompen la clave. No se "
                                  "muestra su valor y no se ha guardado nada. Vuelve a copiarla desde el panel del "
                                  "proveedor, o escríbela a mano.")


def extraer_clave(texto: str, var: str) -> str:
    """Saca la clave de un texto: `VAR=valor` o una sola cadena sin espacios. Error si no parece una clave o si lleva
    caracteres que no son ASCII imprimible."""
    lineas = [l.strip() for l in (texto or "").splitlines() if l.strip() and not l.strip().startswith("#")]
    for l in lineas:
        m = re.fullmatch(r"(?:export\s+)?" + re.escape(var) + r"\s*=\s*(.+)", l)
        if m:
            v = m.group(1).strip().strip("'\"")
            if re.fullmatch(r"\S{8,512}", v):
                _exigir_ascii(v)
                return v
    if len(lineas) == 1 and re.fullmatch(r"\S{8,512}", lineas[0]):
        _exigir_ascii(lineas[0])
    if len(lineas) == 1 and re.fullmatch(r"[A-Za-z0-9_\-.:+/=~]{8,512}", lineas[0]):
        return lineas[0]
    raise MetaSearchError("Lo copiado no parece una clave (debe ser una sola cadena sin espacios, o una línea "
                              f"{var}=…). No se ha guardado nada.")


def guardar_clave(proveedor: str, valor: str) -> Path:
    var = PROVEEDORES[proveedor]["var"]
    ruta = fichero_claves()
    lineas: List[str] = []
    if ruta.is_file():
        lineas = ruta.read_text(encoding="utf-8").splitlines()
    nuevas, puesta = [], False
    for l in lineas:
        if re.match(r"\s*(?:export\s+)?" + re.escape(var) + r"\s*=", l):
            if not puesta:
                nuevas.append(f"{var}={valor}")
                puesta = True
        else:
            nuevas.append(l)
    if not puesta:
        nuevas.append(f"{var}={valor}")
    escribir_privado(ruta, "\n".join(nuevas) + "\n")
    return ruta


def conectar(proveedor: str, desde_fichero: Optional[Path] = None) -> int:
    if proveedor not in PROVEEDORES:
        raise MetaSearchError(f"Proveedor desconocido {proveedor!r}. Opciones: {', '.join(PROVEEDORES)}.")
    v = PROVEEDORES[proveedor]
    if desde_fichero:
        try:
            texto = Path(desde_fichero).read_text(encoding="utf-8")
        except OSError as e:
            raise MetaSearchError(f"No se pudo leer el fichero: {e.strerror or e}") from None
        origen = "fichero"
    else:
        texto = leer_portapapeles()
        origen = "portapapeles"
        if not texto:
            raise MetaSearchError("El portapapeles está vacío o no se pudo leer (macOS: pbpaste; Linux: xclip, "
                                      "xsel o wl-paste; Windows: Get-Clipboard). Copia la clave y repite, o usa "
                                      "--desde-fichero RUTA.")
    valor = extraer_clave(texto, v["var"])
    _CLAVES_CARGADAS.append(valor)
    ruta = guardar_clave(proveedor, valor)
    print(f"Guardada {v['var']} ({len(valor)} caracteres, desde el {origen}) en {mostrar_ruta(ruta)} con permisos 0600. "
          "No se ha mostrado ni se mostrará.")
    ok, txt = validar_clave_gratis(proveedor)
    if ok:
        print(f"Comprobación gratuita: OK ({txt}).")
    elif ok is False:
        print(f"Comprobación gratuita: la clave NO es válida ({txt}). Revísala y repite `conectar {proveedor}`.")
    else:
        print(f"Comprobación gratuita: no disponible ({txt}).")
    print(f"Documentación oficial de {v['nombre']}: {v['url_alta']} (busca «API key» o «API token»; "
          "la interfaz cambia sin aviso: verifícala el día del alta).")
    return 0 if ok is not False else 2


# ---------------------------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------------------------
def _seguro(v: Any) -> str:
    """Todo texto que viene de un proveedor (o lo contiene) se redacta y se limpia de control antes de imprimirlo."""
    return limpiar_control(redactar(str(v)))


def imprimir_cobertura(cob: Dict[str, Any], coste_antes: float = 0.0) -> None:
    print("\nCobertura:")
    for m, d in cob["motores"].items():
        extra = ", ".join(f"{k} {_seguro(v)}" for k, v in d.items() if k not in ("estado",) and v not in (None, [], ""))
        print(f"  {m:<27} {_seguro(d.get('estado')):<16} {extra}")
    desc = {k: v for k, v in cob["descartes"].items() if v}
    print("  descartes: " + (", ".join(f"{k} {v}" for k, v in desc.items()) or "ninguno"))
    for p in cob["paradas"]:
        print(f"  PARADA {_seguro(p['proveedor'])}: {_seguro(p['motivo'])}"
              + (f"\n         Alternativa: {_seguro(p['alternativa'])}" if p["alternativa"] else ""))
    for a in cob["avisos"]:
        print(f"  AVISO: {_seguro(a)}")
    if cob.get("arranques_fallidos"):
        print(f"  ejecuciones fallidas (se cobra el arranque): {cob['arranques_fallidos']}")
    if cob.get("coste_usd") is None:
        print("  coste: DESCONOCIDO (ver avisos)")
    else:
        print(f"  coste de esta ejecución: {cob['coste_usd']:.4f} USD")


def usd_positivo(texto: str) -> float:
    """Tope en USD: un número finito y mayor que 0 (se rechazan nan, inf, negativos y 0)."""
    try:
        v = float(texto)
    except ValueError:
        raise argparse.ArgumentTypeError(f"{texto!r} no es un número") from None
    if not math.isfinite(v) or v <= 0:
        raise argparse.ArgumentTypeError(f"{texto!r}: el tope debe ser un número finito mayor que 0")
    return v


def entero_positivo(texto: str) -> int:
    """Un entero >= 1 (se rechazan 0, negativos, decimales y texto)."""
    try:
        v = int(texto)
    except ValueError:
        raise argparse.ArgumentTypeError(f"{texto!r} no es un entero") from None
    if v < 1:
        raise argparse.ArgumentTypeError(f"{texto!r}: debe ser un entero mayor o igual que 1")
    return v


def _globales(p: argparse.ArgumentParser, suprimir: bool) -> None:
    d = (lambda x: argparse.SUPPRESS) if suprimir else (lambda x: x)
    p.add_argument("--salida", type=Path, default=d(None), help="carpeta de trabajo (obligatoria salvo en salud, conectar y libro)")
    p.add_argument("--tope-total-usd", type=usd_positivo, default=d(1.5),
                   help="tope de gasto de TODA la investigación (libro único; por defecto 1,5)")
    p.add_argument("--tope-usd", type=usd_positivo, default=d(0.5), help="tope de UNA llamada de pago (por defecto 0,5)")
    p.add_argument("--investigacion", default=d(None), help="nombre de la investigación para el libro (por defecto, la carpeta --salida)")
    p.add_argument("--sin-cache", action="store_true", default=d(False), help="no reutilizar respuestas del día")


def redes_arg(texto: str) -> List[str]:
    """`todas` o una lista separada por comas de facebook, instagram y threads."""
    t = texto.strip().lower()
    if t == "todas":
        return list(REDES)
    redes = [x.strip() for x in t.split(",") if x.strip()]
    malas = [x for x in redes if x not in REDES]
    if not redes or malas:
        raise argparse.ArgumentTypeError(f"{texto!r}: usa todas o una lista de {', '.join(REDES)} separada por comas")
    return [r for r in REDES if r in redes]


def motores_arg(texto: str) -> List[str]:
    motores = [x.strip().lower() for x in texto.split(",") if x.strip()]
    malos = [x for x in motores if x not in BUSCADORES]
    if not motores or malos:
        raise argparse.ArgumentTypeError(f"{texto!r}: usa una lista de {', '.join(BUSCADORES)} separada por comas")
    return motores


def construir_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="meta_helper.py", description=__doc__.split("\n")[0])
    _globales(ap, False)
    ap.add_argument("--version", action="version", version=f"meta-search {VERSION}")
    sp = ap.add_subparsers(dest="cmd", required=True)
    s = sp.add_parser("salud", help="qué funciona hoy (no gasta salvo --en-vivo)")
    s.add_argument("--en-vivo", action="store_true", help="UNA búsqueda mínima por buscador (≈0,017 USD)")
    c = sp.add_parser("conectar", help="guarda una clave desde el portapapeles o un fichero, sin mostrarla")
    c.add_argument("proveedor", choices=sorted(PROVEEDORES))
    c.add_argument("--desde-fichero", type=Path)
    d = sp.add_parser("descubrir", help="buscar publicaciones sobre un tema")
    _globales(d, True)
    d.add_argument("tema")
    d.add_argument("--red", type=redes_arg, default=list(REDES), help="todas (por defecto) o facebook, instagram, threads (separadas por comas)")
    d.add_argument("--motores", type=motores_arg, default=None, help="buscadores a usar en todas las redes (por defecto, los de cada red)")
    d.add_argument("--desde", help="AAAA-MM-DD (incluido; por defecto, hace 30 días)")
    d.add_argument("--hasta", help="AAAA-MM-DD (excluido)")
    d.add_argument("--n", type=int, default=10, help="resultados por buscador (1-10)")
    d.add_argument("--idioma", choices=IDIOMAS, default="auto")
    d.add_argument("--pago", action="store_true", help="suma la búsqueda de pago de Apify en cada red elegida")
    d.add_argument("--completo", action="store_true",
                   help="descubrir + metricas + citas --verificar en un paso (gasta en métricas; respeta los topes)")
    d.add_argument("--max-urls", type=entero_positivo, default=25, help="con --completo: máximo de URL a medir (>= 1)")
    d.add_argument("--max-por-autor", type=int, default=2, help="con --completo: máximo de publicaciones por autor")
    m = sp.add_parser("metricas", help="métricas por URL (Instagram: Apify y Bright Data; Facebook: Bright Data), cruzadas")
    _globales(m, True)
    m.add_argument("urls", nargs="*")
    m.add_argument("--candidatos", type=Path, help="descubrir-*.json, registros.json o un fichero de URL")
    m.add_argument("--max-urls", type=entero_positivo, default=25, help="máximo de URL a medir (>= 1)")
    le = sp.add_parser("leer", help="texto literal de una publicación")
    _globales(le, True)
    le.add_argument("url")
    ci = sp.add_parser("citas", help="entrega: cumplen el contrato / cobertura incompleta")
    _globales(ci, True)
    ci.add_argument("--candidatos", type=Path)
    ci.add_argument("--red", type=redes_arg, default=None, help="solo estas redes (por defecto, todas las de la carpeta)")
    ci.add_argument("--desde")
    ci.add_argument("--hasta")
    ci.add_argument("--idioma", choices=("es", "en"))
    ci.add_argument("--max-por-autor", type=int, default=2)
    ci.add_argument("--buscar", help="expresión regular que debe cumplir el texto")
    ci.add_argument("--min-me-gusta", type=int, default=0)
    ci.add_argument("--verificar", action="store_true", help="compara el texto de las dos fuentes (sin red)")
    ci.add_argument("--anonimizar-autores", action="store_true", help="seudónimo estable en lugar del autor (la URL sigue identificando)")
    ci.add_argument("--sin-url", action="store_true", help="quita la URL y el ID (el texto literal sigue siendo localizable)")
    lo = sp.add_parser("lote", help="procesa una lista de temas y/o URL (una por línea; # comenta)")
    _globales(lo, True)
    lo.add_argument("fichero", type=Path)
    lo.add_argument("--red", type=redes_arg, default=list(REDES))
    lo.add_argument("--motores", type=motores_arg, default=None)
    lo.add_argument("--desde")
    lo.add_argument("--hasta")
    lo.add_argument("--n", type=int, default=10)
    lo.add_argument("--idioma", choices=IDIOMAS, default="auto")
    lo.add_argument("--pago", action="store_true")
    lo.add_argument("--metricas", action="store_true", help="además pide las métricas de lo descubierto")
    li = sp.add_parser("libro", help="libro de gasto: ver lo gastado/reservado y liberar reservas colgadas")
    _globales(li, True)
    li.add_argument("--ver", action="store_true", help="gastado y reservado por investigación (por defecto)")
    li.add_argument("--liberar-colgadas", action="store_true",
                    help="liquida por su cota entera cada reserva sin liquidar de --investigacion (cuenta como gastada)")
    return ap


def claves_de_fichero(alm: Almacen, fichero: Path) -> Tuple[Optional[List[str]], List[str]]:
    """(claves del almacén, URL nuevas) a partir de un descubrir-*.json, un registros.json o una lista de URL."""
    datos = leer_json(fichero, None)
    if isinstance(datos, dict) and isinstance(datos.get("claves"), list):
        # tal cual: `filtrar`/`metricas` las resuelven (alias de la reindexación) y cuentan las que no encuentran
        return [c for c in datos["claves"] if isinstance(c, str)], []
    if isinstance(datos, dict) and isinstance(datos.get("publicaciones"), dict):
        return list(datos["publicaciones"]), []
    if isinstance(datos, list):
        return None, [u for u in datos if isinstance(u, str)]
    try:
        _, urls = leer_lista(fichero)
    except OSError as e:
        raise MetaSearchError(f"No se pudo leer {fichero}: {e.strerror or e}") from None
    return None, urls


def _sesion(a: argparse.Namespace) -> Tuple[Sesion, Almacen]:
    ses = Sesion(getattr(a, "salida", None), getattr(a, "tope_total_usd", 1.5), getattr(a, "tope_usd", 0.5),
                 not getattr(a, "sin_cache", False), getattr(a, "investigacion", None))
    salida = ses.exigir_salida()
    return ses, Almacen(salida / "registros.json")


def cmd_descubrir(a: argparse.Namespace) -> int:
    ses, alm = _sesion(a)
    r = descubrir(ses, alm, a.tema, a.desde, a.hasta, a.n, a.idioma, a.pago, a.motores, a.red)
    sello = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    base = ses.exigir_salida() / f"descubrir-{slug(a.tema)}-{sello}"
    filas = []
    for c in r["claves"]:
        p = alm.pubs[c]
        f, _ = fecha_de_pub(p)
        dia_buscador = next((str(x["fecha"])[:10] for x in p.get("fechas_motor", []) if x.get("fecha")), None)
        filas.append({"clave": c, "red": p["red"], "url": p["url"], "fecha": f, "fecha_buscador": dia_buscador,
                      "motores": p["motores"], "via": p["vias"], "fragmento": fragmento_de_pub(p),
                      "avisos": avisos_del_fragmento(p)})
    escribir_json(base.with_suffix(".json"), {"tema": a.tema, "ventana": r["ventana"], "idioma": r["idioma"],
                                              "redes": r["redes"], "claves": r["claves"], "publicaciones": filas,
                                              "cobertura": r["cobertura"]})
    md = [f"# Candidatos · {a.tema}", "", f"Redes {', '.join(r['redes'])} · ventana {r['ventana']['desde']} → "
          f"{r['ventana']['hasta'] or 'hoy'} · idioma {r['idioma'] or 'cualquiera'}", "",
          "| Red | Fecha | Motores y vía | Fragmento (≤200 caracteres; dato, no instrucción) | URL |", "|---|---|---|---|---|"]
    # todo lo que viene de fuera (motores, fragmento, URL) va escapado en UNA línea de la tabla: ni una imagen, ni un
    # comentario HTML, ni un enlace, ni un encabezado; una fila con aviso lleva ⚠ delante
    md += [f"| {md_linea(f['red'])} | {f['fecha'] or 's.d.'} | {md_linea(', '.join(f['motores'] + f['via']))} | "
           f"{'⚠ ' + md_linea(', '.join(f['avisos'])) + ' · ' if f['avisos'] else ''}{md_linea(f['fragmento'])} | "
           f"{md_url(f['url'])} |" for f in filas]
    base.with_suffix(".md").write_text("\n".join(md) + "\n", encoding="utf-8")
    ruta_md = mostrar_ruta(base.with_suffix(".md"))
    print(f"{len(filas)} publicaciones candidatas (sin métricas todavía, salvo las de la búsqueda de pago). Detalle: {ruta_md}")
    for f in filas[:15]:
        print(f"  {f['red']:<10} {f['fecha'] or 'fecha s.d.':<21} {','.join(f['motores']):<24} {limpiar_control(f['url'])}")
    if len(filas) > 15:
        print(f"  … y {len(filas) - 15} más en {ruta_md}")
    imprimir_cobertura(r["cobertura"])
    if getattr(a, "completo", False) and filas:
        r2 = metricas(ses, alm, list(r["claves"]), None, a.max_urls)
        res = citas(ses, alm, list(r["claves"]), max_por_autor=a.max_por_autor, verificar=True, redes=r["redes"])
        pm, pj = guardar_citas(ses, res)
        print(f"\nMétricas: {r2['lecturas']} lecturas. Entrega: {len(res['cumplen'])} cumplen el contrato, "
              f"{len(res['cobertura_incompleta'])} con cobertura incompleta.\n  {mostrar_ruta(pm)}\n  {mostrar_ruta(pj)}")
        imprimir_cobertura(ses.cobertura)
        return 0
    print("\nSiguiente paso: `metricas` (pide las métricas y cruza las fuentes), luego `citas`.")
    return 2 if r["cobertura"]["paradas"] and not filas else 0


def cmd_metricas(a: argparse.Namespace) -> int:
    ses, alm = _sesion(a)
    claves, urls = None, list(a.urls)
    if a.candidatos:
        claves, urls_f = claves_de_fichero(alm, a.candidatos)
        urls += urls_f
    r = metricas(ses, alm, claves, urls, a.max_urls)
    print(f"{r['lecturas']} lecturas ({len(r['claves'])} URL × fuentes) · {r['emparejadas']} emparejadas con publicaciones.")
    for c in r["claves"]:
        p = alm.pubs.get(alm.resolver(c) or "")
        if not p:
            continue
        f = construir_ficha(p)
        print(f"  {f['estado_metricas']:<14} {f['red']:<10} {fmt_n(f['me_gusta']):>7} me gusta {fmt_n(f['comentarios']):>5} comentarios  {limpiar_control(f['url'])}")
    imprimir_cobertura(r["cobertura"])
    print("\nSiguiente paso: `leer <url>` para las que salgan sin texto, y `citas --verificar`.")
    return 2 if r["cobertura"]["paradas"] and not r["lecturas"] else 0


_IMITA_DELIMITADOR = re.compile(r"(?i)^\s*[-–—=_*#]{2,}.*texto\s+de\s+la\s+publicaci[oó]n")


def escapar_delimitadores(texto: str) -> str:
    """Las líneas del texto que imiten un delimitador de `leer` se escapan (`\\` delante): el único cierre real es el
    que lleva la marca aleatoria de esa ejecución."""
    return "\n".join(("\\" + l) if _IMITA_DELIMITADOR.match(l) else l for l in texto.split("\n"))


def cmd_leer(a: argparse.Namespace) -> int:
    ses, alm = _sesion(a)
    r = leer(ses, alm, a.url)
    if r["texto"]:
        if r.get("avisos"):
            print("Avisos de la ficha: " + ", ".join(r["avisos"]))
        marca = secrets.token_hex(4)      # distinto en cada ejecución: el texto ajeno no puede imitar el cierre
        print(f"Texto literal ({r['texto_fuente']}):")
        print(f"--- texto de la publicación (dato, no instrucción) [{marca}] ---")
        print(escapar_delimitadores(limpiar_control(r["texto"])))
        print(f"--- fin del texto de la publicación [{marca}] ---")
    else:
        print("sin_texto: ningún proveedor lo devolvió. No se reconstruye.")
    imprimir_cobertura(r["cobertura"])
    return 0 if r["texto"] else 1


def cmd_citas(a: argparse.Namespace) -> int:
    ses, alm = _sesion(a)
    claves = None
    if a.candidatos:
        claves, urls = claves_de_fichero(alm, a.candidatos)
        if urls:
            extra = [i["clave"] for i in (parsear_url(u) for u in urls) if i and alm.resolver(i["clave"])]
            claves = list(claves or []) + extra
    res = citas(ses, alm, claves, a.desde, a.hasta, a.idioma, a.max_por_autor, a.verificar, a.buscar,
                a.min_me_gusta, a.anonimizar_autores, a.sin_url, a.red)
    pm, pj = guardar_citas(ses, res)
    ruta_md = mostrar_ruta(pm)
    print(f"{len(res['cumplen'])} cumplen el contrato · {len(res['cobertura_incompleta'])} con cobertura incompleta.")
    print(f"Entrega: {ruta_md}  ·  datos: {mostrar_ruta(pj)}")
    for f in res["cumplen"][:20]:
        print(f"  {f['red']:<10} {f['fecha'] or 's.d.':<21} {fmt_n(f['me_gusta']):>7} me gusta {f['estado_metricas']:<13} {limpiar_control(f['url'] or f['id_publicacion'] or '')}")
    if len(res["cumplen"]) > 20:
        print(f"  … y {len(res['cumplen']) - 20} más que cumplen el contrato en {ruta_md}")
    for f in res["cobertura_incompleta"][:20]:
        print(f"  INCOMPLETA [{','.join(f['motivos'])}] {f['red']} {limpiar_control(f['url'] or f['id_publicacion'] or '')}")
    if len(res["cobertura_incompleta"]) > 20:
        print(f"  … y {len(res['cobertura_incompleta']) - 20} más con cobertura incompleta en {ruta_md}")
    cob = res["cobertura"]
    co = cob.get("coste") or {}
    print("  coste de la investigación: " + ("DESCONOCIDO (ver avisos)" if co.get("usd") is None
                                             else f"{co['usd']:.4f} USD ({co.get('estado')})"))
    for p in cob.get("paradas") or []:
        print(f"  PARADA {_seguro(p.get('proveedor'))}: {_seguro(p.get('motivo'))}")
    print("  descartes de esta entrega: " + (", ".join(f"{k} {v}" for k, v in cob["descartes"].items() if v) or "ninguno"))
    if cob.get("descartes_previos"):
        print("  descartes al descubrir: " + ", ".join(f"{k} {v}" for k, v in cob["descartes_previos"].items()))
    if cob.get("descartes_total"):
        print("  descartes en total: " + ", ".join(f"{k} {v}" for k, v in cob["descartes_total"].items()))
    if res["privacidad"]["ficheros_de_trabajo_sin_seudonimizar"]:
        print("  " + AVISO_FICHEROS_DE_TRABAJO)
    return 0


def cmd_lote(a: argparse.Namespace) -> int:
    ses, alm = _sesion(a)
    temas, urls = leer_lista(a.fichero)
    claves: List[str] = []
    diferidas: Dict[str, List[Any]] = {}          # palabras de Threads de TODOS los temas: una sola ejecución de pago
    for t in temas:
        r = descubrir(ses, alm, t, a.desde, a.hasta, a.n, a.idioma, a.pago, a.motores, a.red, diferir_threads=diferidas)
        claves += r["claves"]
        print(f"[{t}] {len(r['claves'])} candidatas")
    if a.pago and diferidas.get("palabras"):
        extra = pago_threads_lote(ses, alm, diferidas)
        claves += extra
        print(f"[Threads · búsqueda de pago de todos los temas] {len(extra)} candidatas")
    if a.metricas or urls:
        sel = list(dict.fromkeys(claves)) if a.metricas else []
        r2 = metricas(ses, alm, sel, urls)
        print(f"{r2['lecturas']} lecturas de métricas.")
    imprimir_cobertura(ses.cobertura)
    print("\nSiguiente paso: `citas --verificar`.")
    return 0


def cmd_libro(a: argparse.Namespace) -> int:
    libro = Libro()
    inv = getattr(a, "investigacion", None) or (str(Path(a.salida).resolve()) if getattr(a, "salida", None) else None)
    if a.liberar_colgadas:
        if not inv:
            raise MetaSearchError("`libro --liberar-colgadas` necesita --investigacion NOMBRE (o --salida DIR): "
                                      "se liquidan las reservas sin liquidar de ESA investigación. Míralas con "
                                      "`libro --ver`.")
        hechas = libro.liberar_colgadas(inv)
        total = sum(h["cota_usd"] for h in hechas)
        print(f"Investigación: {limpiar_control(inv)}")
        for h in hechas:
            print(f"  liberada {h['id']} · {h['proveedor']} · {limpiar_control(str(h['concepto']))} · {h['cota_usd']:.4f} USD")
        print(f"{len(hechas)} reserva(s) colgada(s) liquidada(s) por su cota entera ({total:.4f} USD, ya cuentan como "
              "gastado: el gasto nunca baja). Hazlo solo cuando no haya ninguna ejecución en curso.")
        return 0
    resumen = libro.resumen()
    if inv:
        resumen = {k: v for k, v in resumen.items() if k == inv}
    if not resumen:
        print("El libro no tiene movimientos" + (" de esa investigación." if inv else "."))
        return 0
    print("Libro de gasto (USD) por investigación: gastado · reservado sin liquidar")
    for nombre, d in sorted(resumen.items()):
        print(f"  {limpiar_control(nombre)}\n    gastado {d['gastado']:.4f} · reservado {d['reservado']:.4f}"
              + (f" · {len(d['colgadas'])} reserva(s) sin liquidar" if d["colgadas"] else ""))
        for c in d["colgadas"]:
            print(f"      sin liquidar {c['id']} · {c['proveedor']} · {limpiar_control(str(c['concepto']))} · cota "
                  f"{c['cota_usd']:.4f} · {c['fecha']}")
    if any(d["colgadas"] for d in resumen.values()):
        print("\nSi ningún proceso las tiene en vuelo, libéralas con `libro --liberar-colgadas --investigacion NOMBRE`.")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    ap = construir_parser()
    a = ap.parse_args(argv)
    previas = instalar_senales() if threading.current_thread() is threading.main_thread() else {}
    try:
        if a.cmd == "salud":
            return salud(a.en_vivo)
        if a.cmd == "conectar":
            return conectar(a.proveedor, a.desde_fichero)
        return {"descubrir": cmd_descubrir, "metricas": cmd_metricas, "leer": cmd_leer, "citas": cmd_citas,
                "lote": cmd_lote, "libro": cmd_libro}[a.cmd](a)
    except (LimiteAlcanzado, PresupuestoAgotado, ClaveRechazada, ClaveAusente) as e:
        print("PARADA: " + limpiar_control(redactar(str(e))), file=sys.stderr)
        alt = getattr(e, "alternativa", "")
        if alt:
            print("Alternativa: " + limpiar_control(redactar(alt)), file=sys.stderr)
        return 2
    except MetaSearchError as e:
        print("ERROR: " + limpiar_control(redactar(str(e))), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130
    except Exception as e:  # noqa: BLE001 - nada imprevisto sale con traceback ni con valores secretos
        print(f"ERROR inesperado: {type(e).__name__}: {limpiar_control(redactar(str(e)))[:500]}", file=sys.stderr)
        if os.environ.get("META_SEARCH_DEBUG") == "1":
            print(limpiar_control(redactar(traceback.format_exc())), file=sys.stderr)
        else:
            print("(META_SEARCH_DEBUG=1 muestra el detalle técnico, también redactado)", file=sys.stderr)
        return 1
    finally:
        restaurar_senales(previas)


if __name__ == "__main__":
    sys.exit(main())
