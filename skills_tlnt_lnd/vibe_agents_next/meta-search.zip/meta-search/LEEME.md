# meta-search

Skill para que tu agente busque en **Instagram, Threads y Facebook** cualquier tema y te entregue **publicaciones literales**
con su enlace, autor, fecha y métricas (me gusta, comentarios, compartidos, vistas). No hace resúmenes inventados: el texto es el
que devuelve el proveedor, la fecha sale del proveedor de métricas (o, en Instagram y Threads, del propio código del enlace) y las
métricas se contrastan cuando hay dos fuentes de empresas distintas (Apify y Bright Data; dos lecturas de Apify cuentan como una).

**No usa tus cuentas de Meta, ni cookies, ni navegador, ni la API oficial de Meta.** Solo llama a servicios de terceros con sus
propias claves.

## Instalar

Descarga `meta-search.zip` y dile a tu agente (Claude Code, Codex o Hermes):

> «Instala el skill meta-search de este zip y comprueba que funciona.»

Lo descomprime en su carpeta de skills, comprueba que tenga Python 3.9 o superior y ejecuta `salud`, que te dice qué falta.

| Agente | Carpeta de skills |
|---|---|
| Claude Code | `~/.claude/skills/meta-search` |
| Codex | `~/.codex/skills/meta-search` |
| Hermes | `~/.hermes/skills/meta-search` |

## Qué necesitas

Una clave de **un buscador por red** para descubrir publicaciones y una de **Apify o Bright Data** para medirlas. Todos tienen un
plan gratis o un precio por uso muy bajo (`references/proveedores-y-costes.md`):

| Red | Descubrir | Medir por URL |
|---|---|---|
| Instagram | Perplexity (recomendado) y Firecrawl | Apify y Bright Data (se contrastan) |
| Facebook | Firecrawl | Bright Data |
| Threads | Firecrawl, Exa y Brave | No hay lector por URL: solo trae métricas la búsqueda de pago de Apify (`--pago`) |

Cuando tengas una clave, **cópiala al portapapeles** y dile a tu agente:

> «Guarda esta clave de Firecrawl para meta-search.»

La guarda sin mostrarla, con permisos privados. **Nunca la pegues en el chat.** Cómo dar de alta cada servicio:
`references/instalacion-y-alta.md`.

## Usar

> «Busca en Instagram qué se publica sobre [tu tema] desde el 15 de septiembre y dame las 10 publicaciones con más me gusta.»

> «Busca en Facebook, Instagram y Threads publicaciones sobre [tema] en español y dime qué falta si algo no se pudo obtener.»

> «Mide los me gusta y comentarios de estas publicaciones de Instagram: [enlaces].»

> «Dame las citas literales de Threads sobre [tema], sin nombres de autores, para un informe.» (usa `--anonimizar-autores`; ver el
> aviso de abajo)

Cada entrega trae dos bloques: lo que **cumple** el contrato (texto, URL, autor, fecha y métricas), agrupado por red, y la
**cobertura incompleta**, con el motivo de cada caso. Nada se descarta en silencio. Los contadores de cada red no se comparan entre
sí (en Facebook, los me gusta suman todas las reacciones).

## Cuánto cuesta

Una investigación típica de las tres redes ronda **0,15-0,40 USD** (los buscadores cuestan céntimos; la búsqueda de pago de
Threads cobra 0,08 USD fijos por ejecución más 0,0025 por post). El skill lleva un libro de gasto, reserva el máximo de cada
llamada antes de lanzarla y **se detiene** si no cabe en el tope (por defecto 1,5 USD por investigación y 0,5 USD por llamada).
Nunca compra créditos ni cambia tu plan. Si un servicio devuelve un error de límite, para y te dice la alternativa.

## Requisitos

- Un agente con acceso a internet que pueda ejecutar programas.
- Python 3.9 o superior.
- Claves de los servicios que quieras usar.

**Windows:** **no probado en Windows.** Debería funcionar con variables de entorno o `--desde-fichero`, pero no lo hemos comprobado.

## Aviso

Sin afiliación con Meta ni con ninguno de los proveedores. El skill solo lee publicaciones visibles sin iniciar sesión. Las
condiciones de Meta restringen la recolección automática y la redistribución de su contenido; qué puedes hacer con lo obtenido
depende de tu uso y de tu país, y **no es asesoría jurídica**: léelo en `references/privacidad-y-riesgos.md` antes de publicar o
compartir. `--anonimizar-autores` es **seudonimización**, no anonimato: la URL y el texto literal siguen permitiendo identificar
al autor (`--sin-url` quita la URL, no el texto). Con esa opción, los correos y teléfonos del texto se sustituyen por marcas
visibles (alteración declarada en la ficha), pero los ficheros de trabajo de la carpeta `--salida` (`registros.json`,
`descubrir-*`) guardan los datos sin seudonimizar: comparte solo `citas-*`.
