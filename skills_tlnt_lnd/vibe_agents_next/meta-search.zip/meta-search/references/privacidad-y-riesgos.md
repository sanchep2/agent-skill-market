# Privacidad y riesgos

Qué riesgos tiene recoger publicaciones de Instagram, Threads y Facebook, qué decide este skill para evitarlos y qué te toca
decidir a ti. **No es asesoría jurídica**: las fuentes de abajo son periodísticas, de despachos o de proveedores con interés
comercial, ninguna es el fallo original, y hay partes sin verificar (se dice cuáles). Corte: 14-oct-2026.

## Table of Contents

1. [Regla de oro: sin cuentas, sin cookies, sin navegador](#1-regla-de-oro-sin-cuentas-sin-cookies-sin-navegador)
2. [Casos de la investigación previa](#2-casos-de-la-investigación-previa)
3. [Condiciones de Meta](#3-condiciones-de-meta)
4. [Qué hace el skill para reducir el riesgo](#4-qué-hace-el-skill-para-reducir-el-riesgo)
5. [Datos personales de los autores](#5-datos-personales-de-los-autores)
6. [Seudonimizar no es anonimizar](#6-seudonimizar-no-es-anonimizar)
7. [Antes de publicar o compartir](#7-antes-de-publicar-o-compartir)
8. [Si alguien pide saltarse la regla](#8-si-alguien-pide-saltarse-la-regla)

---

## 1. Regla de oro: sin cuentas, sin cookies, sin navegador

Este skill **no inicia sesión en Instagram, Threads ni Facebook, no usa cookies de sesión, no abre un navegador, no usa
extensiones ni agentes con navegador y no usa actores o servicios que pidan cookies o credenciales**. Solo llama a APIs de
terceros con su propia clave (buscadores y proveedores de datos públicos) y lee publicaciones **visibles sin iniciar sesión**.
Tampoco usa la API oficial de Meta: no necesita app, cuenta de desarrollador ni revisión.

La razón es doble: el riesgo de cierre de la cuenta que se conecte y el de litigio de quien opera con cuentas falsas. Ver §2.

---

## 2. Casos de la investigación previa

Cada cita lleva su fuente y fecha. Lo marcado «sin verificar» no se ha podido contrastar con una fuente primaria.

**Demandas**

- **Meta frente a Bright Data (2024).** En enero de 2024 un juez federal de California desestimó el reclamo contractual de Meta
  (no declaró legal el scraping en general):
  > a federal judge this week threw out Meta's breach-of-contract claim because the defendant obtained only public data from
  > Facebook and Instagram.

  (Ars Technica, 25-ene-2024.) Meta retiró después la demanda (TechCrunch, 26-feb-2024). La interpretación de una empresa del
  sector, con interés comercial: «Data not behind a login is considered public data» (Zyte, 8-oct-2025).
- **Quien usa cuentas falsas o inicio de sesión sí es demandado.** Voyager Labs (más de 38.000 cuentas falsas; el juez dejó seguir
  el caso, 23-may-2024); BrandTotal y Unimania (acuerdo de 2022 con prohibición permanente); y, según una nota de 30-jun-2026,
  Octopus (no se leyó la demanda).

**Cierres de cuentas** (anécdotas, no estadística: no permiten estimar una probabilidad)

- Dos reportes de cuentas de Threads cerradas tras usar o probar la API oficial: un usuario de r/ThreadsApp (18-sep-2026, 46
  votos), cuya cuenta de pruebas solo recibió una verificación con selfie y sospecha que Meta las enlazó («that's only a guess»),
  y uno en X (21-sep-2026, **sin verificar**). La causa real: no verificada.
- Un intento con navegador automatizado e inicio de sesión en Instagram: «We burned the IG IP on this VPS. […] 429 immediately»
  (r/AI_Agents, 1-mar-2026).
- No se encontró ningún caso publicado de cierre por leer publicaciones públicas sin sesión. **Ausencia de evidencia no es
  seguridad.**

**Lo que no trata ninguno de estos casos**: leer publicaciones públicas sin sesión a través de un proveedor.

---

## 3. Condiciones de Meta

Los términos de Meta sí prohíben la recolección automática sin permiso (Thunderbit, 30-jul-2026: las condiciones de Instagram
establecen que los usuarios no pueden «access/collect information in unauthorized ways»). Un usuario de Reddit resume que existe
«an official notice from Meta that they don't support scrapers» (r/programmingHungary, 14-abr-2026, traducido).

La documentación de oEmbed de Threads (actualizada el 3-mar-2026) y la de Instagram (15-may-2026) prohíben usar los metadatos y el
contenido para otro fin que mostrar la publicación (análisis, extracción, persistencia). Esa prohibición es de **esos endpoints
oficiales**, que este skill no usa; se menciona porque dice cómo trata Meta el uso analítico de su contenido.

Qué significa para ti: si tu uso (producto comercial, reventa, publicación de lo obtenido, entrenamiento de modelos) es compatible
con esas condiciones y con la ley de tu país, **no lo decide este skill**: requiere criterio legal. Lectura práctica del informe
previo: leer datos públicos sin sesión mediante un proveedor, sin cuentas propias de Meta de por medio, es el escenario con mejor
respaldo; **no hay seguridad**. Qué norma de protección de datos aplica a tu caso: no verificado.

---

## 4. Qué hace el skill para reducir el riesgo

| Medida | Cómo |
|---|---|
| Sin cuenta ni cookie | No hay código de inicio de sesión ni de cookies; los actores admitidos están en la tabla `ACTORES` y ninguno las pide |
| Sin navegador | Solo HTTP a APIs de proveedores; ningún enlace de un post se abre por cuenta propia |
| Solo publicaciones | Perfiles, páginas, hashtags, fotos y eventos se descartan (`no_es_publicacion`) y no se leen |
| Solo lo público | Lo que devuelve un proveedor sin sesión; si es privado o borrado, `no_disponible` |
| Mínimo necesario | Lee una publicación por URL; no recorre perfiles, seguidores ni listas de contactos |
| Entradas probadas | Una tabla cerrada de parámetros por actor; nada nuevo sin prueba |
| Lo que no se guarda | Bios, seguidores, correos y teléfonos de perfil, fotos, enlaces de medios y comentarios de terceros no pasan a `registros.json`, a las fichas ni a la caché (ver §5) |
| Claves | Nunca en el chat, en argumentos ni en URL; fichero 0600 |
| Seudonimización | `--anonimizar-autores` y `--sin-url` (ver §6) |

---

## 5. Datos personales de los autores

Una publicación pública contiene datos personales: nombre de usuario, opiniones, a veces datos de terceros. Los actores de
Instagram, Threads y Facebook devuelven además campos de perfil y de terceros (biografía, enlaces, correos y teléfonos
publicados, seguidores, fotos, identificadores del propietario, últimos comentarios de otras personas): el skill **no los
guarda**, ni en `registros.json` ni en la caché. Por publicación conserva: URL, autor, fecha, texto, métricas y qué motores la
encontraron. Si el texto de respaldo (Exa o Firecrawl) trae un bloque de comentarios de otras personas, `leer` lo corta antes de
él, no lo imprime ni lo guarda y avisa (`comentarios_de_terceros_omitidos`).

**Qué guarda exactamente la caché** (`~/.meta-search/cache`; carpeta 0700, ficheros 0600, una repetición el mismo día no cuesta,
**caduca al día** y se purga al abrir una sesión con caché): de cada respuesta de un proveedor de datos, **solo los campos que el
skill lee** para armar una ficha: URL, identificador de la publicación (`shortCode`, `postId`, `post_code`, `post_id`), texto,
nombre o usuario del autor, fecha, contadores (me gusta, reacciones por tipo, comentarios, compartidos, vistas) y, en Bright Data,
la URL que se pidió y el error del registro. De los buscadores, **los candidatos ya normalizados** (URL, título, fragmento, fecha
y autor que dio el motor, con el bloque de comentarios de terceros ya cortado), no la respuesta cruda. No guarda comentarios de
terceros, biografías, correos ni teléfonos de perfil, fotos, enlaces de medios, seguidores ni identificadores de propietario. Lo
que sí contiene la caché es el **texto y el nombre de las publicaciones** (datos personales públicos, igual que
`registros.json`): bórrala al terminar (`--sin-cache` evita escribirla). Guarda también si el autor cerró los comentarios
(`isCommentsDisabled`), para que una lectura servida de la caché no convierta ese «sin dato» en un 0 medido. Los ficheros se
llaman `meta-search-{proveedor}-{hash}.json` y llevan dentro `"formato": "meta-search-cache-3"`. Al abrir una sesión con caché
se borran, y solo estos: los de este skill con más de un día y los del formato 2 (1.1.0, que reconoce por su marcador dentro del
fichero); un fichero de otro skill o tuyo en esa carpeta no se toca. **Las cachés de la versión 1.0.0** guardaban la respuesta
cruda con el nombre `{proveedor}-{hash}.json`, que otros skills también usan: la 1.2.0 ya no las borra porque no puede saber de
quién son. Si vienes de la 1.0.0, borra a mano los `*.json` de `~/.meta-search/cache` que no empiecen por `meta-search-`.

Buenas prácticas:

- **Recoge lo necesario para la pregunta.** Una investigación de mercado no necesita fichar a personas concretas.
- **Borra al terminar** lo que no vayas a conservar: la carpeta `--salida` (`registros.json`, `citas-*`) y la caché
  (`~/.meta-search/cache`). El libro de gasto (`gasto.jsonl`) no contiene datos de autores.
- **No cruces con otras fuentes para identificar** a los autores si no es el fin legítimo de tu trabajo.
- **Respeta peticiones de retirada**: si alguien te pide quitar su publicación de un informe, quítala.
- **Obligaciones de protección de datos** (según tu país y tu uso) pueden aplicar a lo que guardes y publiques. Consúltalo antes
  de conservar a largo plazo, vender o publicar. El nombre de usuario junto a su texto es dato personal.

---

## 6. Seudonimizar no es anonimizar

```text
--anonimizar-autores   cambia el nombre por «autor-» + 10 caracteres de un hash estable del nombre (SHA-256)
--sin-url              quita la URL y el ID de la publicación (los sustituye por «pub-» + hash)
```

- **El mismo autor sale con el mismo seudónimo** en todas las entregas: sirve para contar publicaciones por autor sin nombrarlo.
- **No es anonimato**: con `--anonimizar-autores` solo, la **URL sigue identificando al autor** (en Threads lleva el `@usuario`).
  Con `--sin-url` también, **el texto literal sigue siendo localizable** con un buscador. Para anonimizar de verdad habría que no
  citar el texto, y entonces ya no es data original.
- **`--anonimizar-autores` también omite los datos de contacto del texto**: correos y teléfonos (incluidos los de `wa.me/…`) se
  sustituyen por «[correo omitido]» / «[teléfono omitido]». Es una **alteración del literal**, declarada con el aviso
  `datos_de_contacto_omitidos` en cada ficha afectada. Solo se omite lo que **tiene forma de teléfono**: prefijo `+` o
  paréntesis, grupos de 2-4 dígitos separados por espacio, punto o guion, con 8-15 dígitos en total, o 9-15 cifras seguidas sin
  separadores (o cifras sueltas justo después de «móvil», «WhatsApp», «tel»…). No se tocan las cifras junto a una moneda o unidad
  (USD, $, €, %, millones, M, K…), un ISBN, una fecha ni un número con separador de millares. Es de mejor esfuerzo: una cantidad
  grande escrita sin separadores ni unidad se parece a un teléfono y se omite. Los nombres de personas, las marcas, los @usuario
  y los dominios dentro del texto no se tocan: quítalos tú si hace falta.
- **Con `--sin-url` la cobertura de `citas-*.json` no lleva IDs ni claves de lo descartado**, solo recuentos.
- **Los ficheros de trabajo de `--salida` NO están seudonimizados**: `registros.json` y `descubrir-*.json|md` guardan nombres,
  enlaces y textos reales. `citas` lo avisa siempre que usas `--anonimizar-autores` o `--sin-url`. Comparte solo
  `citas-<sello>.md|json`, nunca la carpeta entera.
- El hash no lleva sal por defecto: quien tenga una lista de nombres puede comprobar cuál produce cada seudónimo. Define
  `META_SEARCH_SAL` con un valor privado para evitarlo.
- Recomendación: **actívalas siempre que el material vaya a terceros** (informes, formación, publicaciones). Para uso interno de
  investigación no hace falta.

---

## 7. Antes de publicar o compartir

- [ ] ¿Citas texto literal de personas identificables? Valora `--anonimizar-autores`, `--sin-url` o pedir permiso.
- [ ] ¿Hay datos de terceros dentro de los textos (nombres, marcas, @usuario)? Quítalos (correos y teléfonos los omite
  `--anonimizar-autores`).
- [ ] ¿Vas a vender, publicar o entrenar con lo obtenido? Eso no lo decide el skill: criterio legal primero.
- [ ] ¿Consta en el informe de dónde y cuándo se obtuvo (proveedor, fecha de consulta)? El `.md` de `citas` ya lo trae.
- [ ] ¿Compartes solo la entrega (`citas-*`) y no la carpeta `--salida` con `registros.json`? ¿Borraste la carpeta y la caché si
  no hacen falta?

---

## 8. Si alguien pide saltarse la regla

«Usa mi cuenta», «pásame las cookies al actor», «abre Instagram en el navegador y copia», «conéctate a la API de Threads con mi
app»: **no**. Explica el motivo (§1-§3) y ofrece lo que sí hay: más buscadores, más consultas, `metricas` con las URL que el propio
usuario te dé y, si necesita algo que solo hay con sesión, que lo haga él, a mano, en su cuenta y bajo su responsabilidad.
