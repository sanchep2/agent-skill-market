# Método de búsqueda en Instagram, Threads y Facebook

Cómo plantear consultas que devuelvan publicaciones útiles con poco gasto. Lo medido lleva fecha (pruebas del
14-15 de octubre de 2026, consultas en dos idiomas, ventana de 1 mes, muestras de 6 a 20 publicaciones por red); lo demás
es método. Cada red tiene sus motores: no es el mismo camino en las tres.

## Table of Contents

1. [Qué se puede buscar y qué no](#1-qué-se-puede-buscar-y-qué-no)
2. [Qué motor para qué, red por red](#2-qué-motor-para-qué-red-por-red)
3. [Escribir la consulta](#3-escribir-la-consulta)
4. [Idioma](#4-idioma)
5. [Ventanas de fecha y de dónde sale la fecha](#5-ventanas-de-fecha-y-de-dónde-sale-la-fecha)
6. [Cuánto pedir y cuándo parar](#6-cuánto-pedir-y-cuándo-parar)
7. [Limpieza que hace el skill y por qué](#7-limpieza-que-hace-el-skill-y-por-qué)
8. [Errores típicos](#8-errores-típicos)

---

## 1. Qué se puede buscar y qué no

- **Sí:** publicaciones públicas por tema, con su texto, autor, fecha y métricas:
  - Instagram: posts (`/p/`), reels (`/reel/`) y `/tv/`.
  - Threads: posts y vídeos (`/@usuario/post/…`, `/@usuario/video/…`).
  - Facebook: posts de páginas, de grupos públicos, vídeos, reels y publicaciones compartidas.
- **No:** perfiles, páginas, hashtags, fotos sueltas, eventos, mensajes, historias ni contenido que exige iniciar sesión.
  No son publicaciones: se descartan y se cuentan (`no_es_publicacion`).
- **Sin sesión:** no hay búsqueda desde dentro de una cuenta. Las únicas vías son buscadores externos que indexan las
  redes y proveedores de datos públicos con clave. Por qué no se usa una cuenta: `privacidad-y-riesgos.md`.
- **Cada red se pide por separado** con `--red facebook|instagram|threads|todas` (o una lista separada por comas).
  `todas` lanza los motores de cada red y la cobertura dice qué motor dio qué (`instagram/perplexity`, `threads/exa`…).

---

## 2. Qué motor para qué, red por red

Medido el 14-oct-2026 con 4 consultas (2 en inglés, 2 en español), 4 buscadores y ventana de 1 mes. «Únicas» son URL
distintas de cada red; entre paréntesis, cuántas traen fecha del buscador (solo el día).

| Red | Firecrawl | Perplexity | Exa | Brave | Motores por defecto |
|---|---|---|---|---|---|
| Facebook | **40** (sin fecha) | 0 | 0 | 0 publicaciones (13 URL, todas páginas genéricas) | Firecrawl |
| Instagram | 40 (sin fecha) | **40** (con fecha) | 0 | 1 | Perplexity y Firecrawl |
| Threads | **40** (sin fecha) | 0 | 20 (con fecha) | 16 (con fecha) | Firecrawl, Exa y Brave |

Casi cero URL repetidas entre motores: **cada buscador encuentra publicaciones distintas y suman**. Por eso `descubrir`
lanza los motores de cada red y no los de las demás (los que dieron 0 no se pagan). Para añadir otros a una red
concreta: `--motores exa,brave,firecrawl,perplexity` (esos buscadores, en todas las redes elegidas).

Calidad de lo descubierto (revisión manual de cada texto, `n` pequeño):

- **Instagram, Perplexity y lectura por URL:** de 20 posts, 15 relevantes y 5 parciales (anuncios genéricos de agencias).
  Con «lanzamiento de curso online», 5/5 en español; con «inteligencia artificial para emprendedores», solo 1/5 (tres en
  inglés y uno en portugués). Los 20 tienen los cinco datos (texto, URL, autor, fecha, métricas) y caen en la ventana;
  7 de 20 tienen tracción (100 o más me gusta) y la mediana ronda los 20.
- **Facebook, Firecrawl:** descubre las URL; las métricas salen del actor de búsqueda de pago o de Bright Data.
- **Threads, Firecrawl en español:** 20/20 posts en español y del tema en las dos consultas largas, pero sin fecha (la fecha
  sale del código del enlace). Exa trajo 7 posts (3 en español) y Brave 11, ninguno del tema (revisión manual).

**Búsqueda de pago** (`--pago`, Apify), un motor más y nunca el principal:

| Red | Actor | Lo medido |
|---|---|---|
| Facebook | `apify/facebook-search-scraper` (posts) | Bien en los dos idiomas: «vibe coding» 5/5, «IA para emprendedores» 5/5 (4 en español), «lanzamiento de curso online» 9/10 en español. **No filtra por fecha** (5/10 de esa consulta, fuera de los 30 días, uno de 2024) y a **7 de 20 les faltan los comentarios** |
| Instagram | reels «populares» (`apify/instagram-search-scraper`) | Relevantes y con métricas altas, pero **viejos**: 2/10 y 3/10 en 30 días. Etiqueta `populares_antiguos`. El orden de «popular» no está documentado |
| Instagram | página del hashtag (`apify/instagram-scraper`) | Devuelve **lo publicado minutos antes**: 15/16 con 1 me gusta o menos, ≈ 8/16 relevantes. No mide tracción. Etiqueta `lo_ultimo_sin_traccion` |
| Threads | `futurizerush/meta-threads-scraper` (search, «top») | Inglés: «AI agency» 8/10. Español solo con palabras propias: «emprendedores» 10/10 en español y 9/10 relevantes; «curso online» **10/10 en portugués**; «marketing digital» 0/10 en español (inglés e indonesio); «emprendedores IA» dio 0. El actor no tiene filtro de español |

Por eso, para español, **descubre con los buscadores y mide por URL**; la búsqueda de pago es complemento (y en Threads,
la única forma de obtener métricas).

---

### Calidad medida en las pruebas reales (15-oct-2026)

Tres investigaciones con `descubrir --red todas --pago --completo` («AI automation agency clients» en inglés, «lanzamiento
de curso online» en español y «vibe coding»), revisadas a mano ficha a ficha. Útil = del tema (sí o parcial), en el idioma
pedido y sin relleno:

| Red | Inglés, negocio | Español, marketing | Técnico | Papel |
|---|---|---|---|---|
| Facebook | 77 % | 86 % | 83 % | **Principal**: 45 de 53 URL con los cinco datos |
| Instagram | 37 % | 68 % | 43 % | Complementaria: mucho relleno (promociones genéricas, «comenta X», posts de una línea); la vía «lo último del hashtag» rinde poco |
| Threads | 10 % | 0 % (2 fichas) | 40 % | Complementaria: la búsqueda de pago trae spam y otros idiomas, sobre todo en español |

Cada entrega con publicaciones de esas redes lo declara (`calidad_medida` en la cobertura y una línea en el `.md`). Para
decidir con Instagram o Threads, revisa las fichas a mano o filtra con `citas --buscar` y `--min-me-gusta`.

## 3. Escribir la consulta

```text
BIEN  «lanzamiento de curso online»              (frase natural, como la escribiría quien publica; buscadores)
BIEN  «AI automation agency clients»
BIEN  «emprendedores»                            (palabra corta y propia del idioma: Threads de pago y Reels populares)
MAL   «("curso" OR "bootcamp") AND (lanzamiento OR "abrimos inscripciones") -empleo»
```

- Los buscadores semánticos (Firecrawl, Perplexity, Exa) entienden frases; los operadores booleanos no están verificados en
  ninguno. No los fuerces. El skill añade solo `site:dominio` (Firecrawl y Brave) o el filtro de dominio del motor.
- **Cada actor de pago tiene su regla de consulta:**
  - Facebook acepta frases largas (la consulta entera es el término).
  - Instagram usa UNA consulta corta (1-2 palabras) y, de ella, un hashtag sin espacios («vibe coding» → `#vibecoding`).
    Con «emprendedores inteligencia artificial» devolvió `no_items`.
  - **Threads necesita palabras CORTAS (1-2) y todas juntas en una ejecución**: las frases largas dieron «no_results» en
    3 de 4 consultas, y cada ejecución cobra 0,08 USD de arranque. «AI automation agency clients» →
    `ai automation` + `agency clients`; «what developers think about vibe coding» → `developers vibe` + `vibe coding`.
    Las consultas elegidas se muestran **antes** de lanzar («consultas elegidas […]» en la salida de error) y quedan en la
    cobertura.
  - Solo se quitan palabras **funcionales y de petición** (*what*, *how*, *about*, *qué*, *cómo*, *publicaciones*…);
    nunca palabras con significado («people analytics»), y los términos con símbolos se conservan enteros (`c++`,
    `gpt-5`, `.net`). Una frase entre comillas («», "" o “”) es la consulta.
- Una consulta por idea. Varias ideas en una sola frase diluyen el resultado de los motores.
- **Hashtags:** no son una consulta propia salvo en Instagram con `--pago` (la página del hashtag). En Threads y
  Facebook, ponlos como palabra.

---

## 4. Idioma

- **Escribe la consulta en el idioma de quien publica.** Una consulta en español devuelve publicaciones en español y alguna
  en inglés o portugués.
- `--idioma es|en` filtra después de buscar con una detección simple por palabras frecuentes. Si el texto es corto o
  mezclado, la detección dice «no sé» y **no descarta**: es preferible dejar pasar a perder una publicación.
- `--idioma auto` (por defecto) infiere el idioma del tema; si no puede (p. ej. «vibe coding»), no filtra.
- **En Threads de pago, un tema en español produce un aviso** (la búsqueda es débil salvo con palabras propias del español)
  y el filtro de idioma retira después lo que llegue en otro idioma (en el piloto, 23 de 40 resultados de cuatro consultas).
- Un tema en portugués no está soportado por el filtro: se tratará como «otro idioma» si pides `es` o `en`.

---

## 5. Ventanas de fecha y de dónde sale la fecha

- `--desde AAAA-MM-DD` (incluido) y `--hasta AAAA-MM-DD` (excluido). Por defecto, los últimos 30 días.
- **De dónde sale la fecha de cada publicación** (campo `fecha_fuente`):

  | `fecha_fuente` | Cuándo | Precisión |
  |---|---|---|
  | `proveedor:<nombre>` | Una lectura de un proveedor de métricas trae la fecha | La que da el proveedor (a veces redondeada al minuto) |
  | `proveedores_contrastados` | Dos EMPRESAS (Apify y Bright Data; las lecturas de Apify cuentan como una) coinciden al minuto (≤ 60 s) | Igual |
  | `proveedores_discrepantes` | Dos empresas difieren más de 60 s: manda el primero por prioridad y la ficha avisa | — |
  | `codigo_del_enlace` | Instagram o Threads sin fecha del proveedor | Minutos en Instagram, segundos en Threads |

  Facebook no lleva la fecha en el enlace (`/posts/…/1749…`, `pfbid…`): sin proveedor no hay fecha (`sin_fecha`). **Las fechas
  de los buscadores (Perplexity, Exa, Brave: solo el día, a veces ausentes) no se usan para fechar**: son un dato de
  descubrimiento (`fecha_buscador` en `descubrir-*.json`).
- **La regla del código del enlace, demostrada con los crudos del piloto.** El código de `/p/`, `/reel/`, `/tv/` y
  `/post/` es un número en base 64 (alfabeto `A-Za-z0-9-_`); su parte alta es el instante de creación en milisegundos
  desde la época 1314220021721: `(id >> 23) + 1314220021721`. Con 63 publicaciones distintas de Instagram, la hora del
  proveedor quedó entre 1 minuto antes y 19 minutos después de la del código (a veces el proveedor la redondea al minuto,
  y en los reels da la hora de procesado); con 80 de Threads, entre 1 s antes y 24 s después. El skill la usa con
  tolerancia de una hora para avisar (`fecha_del_proveedor_discrepante`) y solo como fecha final cuando falta el proveedor.
  Un código de más de 11 caracteres, con un carácter fuera del alfabeto o con una fecha anterior a 2012 o posterior a mañana
  no sirve para fechar.
- **Dos momentos de filtrado:**
  1. `descubrir` descarta lo que ya tiene fecha (del proveedor o del código) y queda fuera de la ventana: ahorra pagar sus
     métricas. Es lo que quita los Facebook de 2024 de la búsqueda de pago.
  2. `citas` aplica la ventana final **después de enriquecer**. Una publicación sin fecha sigue en juego hasta que un proveedor
     la data; si tampoco entonces, va a «cobertura incompleta» como `sin_fecha`.
- Ningún actor admitido recibe la ventana como parámetro (los filtros de fecha de Apify no se han probado): se aplica siempre
  después. Los buscadores sí reciben la recencia (día/semana/mes/año).

---

## 6. Cuánto pedir y cuándo parar

```text
descubrir: --n 5-10 por buscador (máximo 10). ≈ 0,005-0,017 USD por consulta y red según los motores.
metricas:  solo lo que pasa el triage. Cada URL ≈ 0,0027 USD en Apify (Instagram) y ≈ 0,0015 USD en Bright Data.
parar:     cuando dos consultas seguidas no traen publicaciones nuevas relevantes (el skill cuenta `duplicado`).
```

- Una investigación típica de las tres redes: 3 consultas × motores de cada red + 20-30 URL medidas ≈ 0,10-0,30 USD; con
  `--pago` suma ≈ 0,06 (Facebook) + 0,03-0,06 (Instagram) + ≈ 0,13 (Threads con 2 palabras). Cálculo propio con las
  tarifas de `proveedores-y-costes.md`.
- **El tope total protege, no sustituye al criterio**: antes de medir 100 URL, pregúntate si 25 bastan.
- Para barridos grandes, un modelo barato lanza `descubrir` y vuelca lo literal; el análisis lo hace un modelo fuerte sobre
  `citas`. Lanzar `metricas` desde un agente caro esperando respuestas quema tokens sin aportar.

---

## 7. Limpieza que hace el skill y por qué

| Descarte | Qué detecta | Por qué |
|---|---|---|
| `no_es_publicacion` | perfiles, páginas, hashtags, fotos, eventos, resultados de otra red | los buscadores devuelven de todo |
| `duplicado` | misma publicación por varios motores o formas de URL (en Facebook, también un `pfbid…` y su URL numérica cuando un proveedor da el número del post: se funden en una publicación con alias) | la clave es el ID de la red |
| `idioma` | texto de otro idioma (detección por palabras frecuentes) | «curso online» en Threads trae portugués; el inglés también aparece |
| `relleno` | cupones de cursos, «¡SUSCRÍBETE!» con enlaces, bloques solo de enlaces, 0 interacción y sin texto propio. Con una lectura de 50+ me gusta o 10+ comentarios nada es relleno (tampoco un texto de solo etiquetas ni los cupones: la ficha lleva un aviso), salvo un «¡SUSCRÍBETE!» con enlaces. Al descubrir, antes de medir, solo se descartan `cupones` y `solo_enlaces` sin interacción conocida | los reels populares con «#vibecoder» y 6.048 me gusta son reales; el relleno clásico no tiene ninguna interacción |
| `tope_por_autor` | más de 2 publicaciones del mismo autor **en la misma red** (`--max-por-autor`) | un autor puede repetirse en cada consulta; el mismo nombre en dos redes son cuentas distintas |
| `registro_ilegible` | un registro del proveedor con una forma inesperada (un campo que cambia de tipo) | no debe tirar lo ya pagado: se cuenta y el resto sigue |
| `fuera_de_ventana` | fecha del proveedor o del código fuera de `--desde/--hasta` | Facebook y los reels populares no respetan la ventana |

Todo se **cuenta con su motivo** en la cobertura y en `registros.json` (`descartados`, sin texto). Si crees que un descarte
es injusto, ajusta el filtro (`--idioma`, `--max-por-autor`), no lo ocultes.

---

## 8. Errores típicos

- **Pedir métricas de todo lo descubierto sin triage**: es el mayor gasto evitable.
- **Lanzar `--pago` en Threads con un tope menor que 0,08 + posts × 0,0025**: el skill no lo lanza y lo avisa; súbelo o usa
  menos palabras.
- **Confiar en la fecha de un buscador**: usa la del proveedor o la del código.
- **Entregar los candidatos de `descubrir` como si fueran citas**: no tienen métricas ni texto literal; son pistas. Los de
  Threads que solo traen los buscadores acaban en cobertura incompleta (`sin_metricas`).
- **Comparar contadores entre redes**: los me gusta de Facebook suman todas las reacciones.
- **Buscar a una persona concreta**: este skill busca por tema. Los perfiles no se leen (ver privacidad).
