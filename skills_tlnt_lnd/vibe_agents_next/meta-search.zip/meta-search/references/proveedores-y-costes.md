# Proveedores, precios, topes y límites

Todo lo de terceros lleva fecha de verificación. **Verificado el 2026-10-14/15** (fichas de los actores de Apify leídas
con su API, respuestas reales de los buscadores y de los proveedores en las pruebas del piloto y documentación de Bright
Data); si una fuente cambia, manda la fuente. Lo que es cálculo propio o supuesto lo dice. Los nombres de ficheros de
«crudos» son los de las respuestas guardadas en el piloto (no viajan en este paquete): sirven para saber de dónde sale
cada entrada y para repetir la comprobación.

## Table of Contents

1. [Cuánto cuesta una investigación](#1-cuánto-cuesta-una-investigación)
2. [Apify](#2-apify)
3. [Entradas probadas de los actores y su crudo de origen](#3-entradas-probadas-de-los-actores-y-su-crudo-de-origen)
4. [Bright Data](#4-bright-data)
5. [Los cuatro buscadores](#5-los-cuatro-buscadores)
6. [Libro de gasto y topes](#6-libro-de-gasto-y-topes)
7. [Errores de límite: qué hace el skill y qué alternativa queda](#7-errores-de-límite-qué-hace-el-skill-y-qué-alternativa-queda)
8. [Planes gratis, créditos y altas](#8-planes-gratis-créditos-y-altas)
9. [Lo que el skill nunca hace con el dinero](#9-lo-que-el-skill-nunca-hace-con-el-dinero)

---

## 1. Cuánto cuesta una investigación

Cálculo propio (14-oct-2026) con las tarifas de abajo, plan gratis de Apify:

| Partida | Cuenta | USD |
|---|---|---|
| 3 consultas con los motores de cada red | Por consulta: Facebook (Firecrawl 0) + Instagram (Perplexity 0,005 + Firecrawl 0) + Threads (Firecrawl 0 + Exa 0,007 + Brave 0,005) = 0,017 | 0,05 |
| Búsqueda de pago de Facebook (opcional) | arranque 0,001 + 10 posts × 0,006 | 0,061 |
| Búsqueda de pago de Instagram (opcional) | 2 ejecuciones (populares y hashtag) × 10 × 0,0027 | 0,054 |
| Búsqueda de pago de Threads (opcional) | arranque 0,08 + 2 palabras × 10 posts × 0,0025 | 0,13 |
| Métricas de 25 URL de Instagram con Apify | 25 × 0,0027 (reserva; el cobro real puede ser menor; `metricas` no repaga el detalle de una URL que ya trae una lectura COMPLETA —me gusta, comentarios y texto— de la búsqueda de pago de Instagram: es la misma empresa y solo refrescaría; sí lo paga si a esa lectura le falta alguno de los tres campos, o si es la del hashtag) | 0,07 |
| Métricas de 25 URL con Bright Data | 25 × 0,0015 equivalente; cubierto por los créditos gratis | 0,04 |
| **Total aproximado** | sin búsqueda de pago ≈ 0,16 · con las tres búsquedas de pago ≈ 0,41 | **0,16-0,41** |

El piloto estimó, para una investigación de CUATRO redes (esas tres y LinkedIn) con Apify, entre **0,65 y 1,00 USD** (suma base
≈ 0,66: LinkedIn 0,08, Facebook 0,24, Instagram 0,08, Threads 0,18 y métricas de unas 20 URL 0,08), y más si se parten las
consultas en más palabras o hay ejecuciones fallidas (en el piloto se perdieron 0,25 USD). Con el **plan gratis de Apify
(5 USD al mes)** caben entre 5 y 7 investigaciones de ese tamaño. Los buscadores van aparte: ≈ 0,22 USD por investigación de
cuatro redes (4 consultas × 4 redes costaron 0,216 USD en el piloto). Bright Data: ≈ 25 registros por investigación frente a
5.000 créditos gratis al mes (supuesto: el saldo no se pudo contrastar con el panel).

---

## 2. Apify

Cobra por **evento**. Fichas leídas el 14-oct-2026 (precios del plan gratis; los planes de pago son menores):

| Actor | Evento | Precio USD | Nota |
|---|---|---|---|
| `apify/facebook-search-scraper` | `facebook-result` (post, reel, página o perfil de la búsqueda) | 0,006 (0,005 Bronze · 0,004 Silver · 0,003 Gold · 0,0025 Platinum · 0,002 Diamond) | 0,061 por 10 posts (cálculo; el coste leído al terminar fue 0) |
| | `actor-start` | 0,001 | Se cobra aunque falle |
| | mínimo de `maxTotalChargeUsd` | 0,024 | Por debajo, el skill no lanza |
| `apify/instagram-search-scraper` | `result` | 0,0027 (0,0023 Bronze … 0,0005 Diamond) | Reels «populares». Medido: 0,0243 por 9 resultados cobrados |
| | `live-search-result` | 0,0027 | No se activa (`liveSearch` no se ha probado) |
| | mínimo de `maxTotalChargeUsd` | 0,0027 | |
| `apify/instagram-scraper` | `result` | 0,0027 | Por URL en `details` (0,0135 por 5 resultados) y por post en la página de un hashtag |
| | mínimo de `maxTotalChargeUsd` | 0,0027 | |
| `futurizerush/meta-threads-scraper` | `apify-default-dataset-item` | 0,0025 | Por post |
| | `apify-actor-start` | **0,02 por GB de memoria en el plan gratis** (0,005 en Bronze y superiores), mínimo un evento | Memoria por defecto 4096 MB → **4 eventos = 0,08 USD fijos por ejecución**, antes del primer post y aunque falle |
| | mínimo de `maxTotalChargeUsd` | 0,005 | El skill exige más: ver §3 |
| `danek/facebook-search-ppr` | — | — | «Temporalmente deshabilitado para usuarios gratis» (cobró 0,0001 de arranque): no admitido |

- **Tope duro por llamada**: `maxTotalChargeUsd` = lo reservado en el libro (`--tope-usd`, 0,5 USD por defecto). Apify
  detiene la ejecución al llegar. En Threads el skill **no recorta la cota**: o cabe `0,08 + palabras × 10 × 0,0025` o no se
  lanza (con un tope de 0,08 una ejecución con una palabra terminó `ABORTED` —«This run's max charge limit was too low to
  deliver any posts»— tras cobrar los 0,08).
- **Uso del mes**: antes de cada llamada de pago, la consulta gratuita de límites de la API de Apify. Si lo usado más lo
  reservado supera el límite mensual, no se lanza. Si no se puede leer, se sigue con un aviso (el tope por llamada y el total
  siguen vigentes).
- **El coste real sale con retraso**: se relee la ejecución al terminar (hasta 3 veces) y se liquida con el MAYOR entre ese
  coste y la estimación por eventos (arranque + resultados × precio), nunca por encima de la reserva. En las ejecuciones de
  Threads del piloto el coste leído al terminar fue 0,08 USD (solo el arranque) con el contador de posts a 0 aunque la
  ejecución había devuelto 20 posts; en Facebook e Instagram, 0 mientras los eventos de resultado marcaban 0. Fiarse solo del coste leído deja el libro por debajo de lo gastado.
- **Arranque fallido**: una ejecución rechazada por la entrada se cobra igual el arranque (en Threads, 0,08). Se cuenta en
  `arranques_fallidos` de la cobertura y en el libro (`estado: arranque_fallido`).
- **Resultado desconocido** (nunca se liquida de menos):
  - El `POST` que crea la ejecución **no es idempotente y no se reintenta jamás**. Si falla por red o con 5xx, la ejecución
    puede existir: se liquida la cota entera (`estado: resultado_desconocido`) y se para con un mensaje que manda a la consola
    de Apify (Actors → Runs) para verla y abortarla antes de repetir.
  - Si el sondeo falla 3 veces, se llama a `/abort` y se liquida la cota entera; Apify queda parado el resto de la sesión.
  - **Solo un estado FINAL da por terminada una ejecución** (`SUCCEEDED`, `FAILED`, `ABORTED`, `TIMED-OUT`). Cualquier otro
    (`READY`, `RUNNING`, `ABORTING`, `TIMING-OUT` o uno desconocido) se sigue sondeando; si no llega a un final dentro del
    tiempo de espera, se aborta y se confirma como arriba. Liquidar lo estimado sobre una ejecución que aún se cierra podría
    dejar sin contar lo que sigue cobrando.
  - Si la ejecución supera el tiempo de espera, se pide `/abort` y se **confirma** leyendo un estado final (`ABORTED`,
    `SUCCEEDED`, `FAILED` o `TIMED-OUT`). Solo con el final confirmado se liquida por lo que llegó a producir. Sin confirmación
    la ejecución puede seguir viva y cobrando: se liquida la cota entera y Apify queda parado la sesión.
  - Si la descarga del dataset falla (se reintenta 2 veces), se liquida el mayor entre el coste leído y la estimación por
    eventos cobrados; sin estimación, la cota. No se guarda en la caché y la cobertura lleva un aviso con el ID del dataset.
  - Si los eventos cobrados vienen a 0 pero hay resultados, `uso.jsonl` lleva `"eventos_retrasados": true`.
- **Autenticación**: cabecera `Authorization: Bearer <token>`; el token nunca va en la URL.
- **Qué para a Apify y qué no**: solo un mensaje que habla de la CUENTA (saldo, plan, uso mensual, «not available for free
  users», «insufficient credits»…) activa el cortacircuitos. Un «rate limit» o «too many requests» dentro de una ejecución
  `FAILED` suele venir de la propia red: cuenta como fallo del actor (`arranque_fallido`) y no bloquea a los demás actores. El
  402 y el 429 de la API de Apify siguen parando.

---

## 3. Entradas probadas de los actores y su crudo de origen

El esquema de un actor solo sugiere valores, y un actor puede cobrar el arranque aunque rechace la entrada. Por eso el script
lleva la tabla `ACTORES` y **rechaza antes de llamar** cualquier clave que no esté en ella y cualquier valor que no esté en
«probado en vivo». Cada entrada sale de un crudo donde la ejecución terminó bien (`SUCCEEDED`) y devolvió resultados:

| Actor y modo | Entrada probada | Crudo de origen (ejecución correcta) | Resultado |
|---|---|---|---|
| `apify/facebook-search-scraper` | `categories` (lista), `searchType: "posts"`, `resultsLimit: 10` | `dia2/busqueda/fb-apify-search.json` (2 términos: 5 posts de cada uno) y `dia2/busqueda/fb-apify-search-es.json` | 10 posts cada uno; el límite se reparte entre los términos |
| `apify/instagram-search-scraper` | `search` (una consulta corta), `searchType: "popular"`, `searchLimit: 10` | `dia2/busqueda/ig-popular-reels.json` («vibe coding») y `dia2/busqueda/ig-popular-reels-es-corto.json` («emprendedores») | 10 reels cada uno |
| `apify/instagram-scraper`, hashtag | `directUrls: [".../explore/tags/<hashtag>/"]`, `resultsType: "posts"`, `resultsLimit: 10` | `dia2/busqueda/ig-hashtag-directo.json` | 16 posts de 2 hashtags |
| `apify/instagram-scraper`, detalle | `directUrls: [URL de publicación…]`, `resultsType: "details"`, `resultsLimit: 1` | `dia1/instagram-apify.json` (5 URL), `dia2/enriquecer/nueva-instagram-apify.json` (6), `dia2/enriquecer/repite-instagram-apify.json` (5), `dia2/enriquecer/ig-perplexity-apify.json` (20) | un registro por URL, con texto, autor, fecha y contadores |
| `futurizerush/meta-threads-scraper` | `mode: "search"`, `keywords` (lista de 1-2 palabras), `max_posts: 10`, `search_filter: "top"` | `dia2/busqueda/threads-busqueda-corta-top.json` (3 palabras clave, `SUCCEEDED`, «Scraped 20 posts for 3 keywords»: **el máximo probado con `top`**) y `dia2/busqueda/threads-busqueda-es-negocio.json` (2 palabras clave, 20 posts) | 10 posts por palabra clave |
| `futurizerush/meta-threads-scraper` | `search_filter: "recent"` | `dia1/threads-apify-busqueda.json` (3 palabras clave, 30 posts) y `dia2/busqueda/threads-busqueda.json` (4 frases largas: 10 posts y 3 «no_results») | probado, pero el skill usa «top»; el caso de 4 se vio una sola vez y con `recent`, así que no vale como prueba de `top` |

**Lo que NO se admite y por qué:**

| Entrada | Qué pasó | Crudo |
|---|---|---|
| Threads `search_language: "spanish"` | `FAILED`: «Invalid search_language: 'spanish'. Choose one of: english, japanese, chinese.» **Cobró los 0,08 USD de arranque** y no dio ningún post. El campo no se pasa nunca | `dia2/busqueda/threads-busqueda-es-idioma-spanish.json` |
| Threads `max_posts` < 10 | Rechazado sin ejecutar y sin cobro: «Field input.max_posts must be >= 10» | `dia1/fallidos/threads-apify-max_posts.json` |
| Threads con el tope en 0,08 | `ABORTED` («max charge limit was too low to deliver any posts»), 0,08 cobrados. De ahí la regla de la cota mínima | `dia2/busqueda/threads-busqueda-es-corto.json` |
| Threads con frases largas | 3 de 4 consultas con «no_results» (incluida una en inglés): las palabras van cortas | `dia2/busqueda/threads-busqueda.json` |
| Instagram `search` + `searchType: "hashtag"` en `apify/instagram-scraper` | Busca el hashtag en Google y devuelve hashtags equivocados («enacter», «enavl»); 0,0054 perdidos | `dia2/busqueda/ig-hashtag.json` |
| Instagram «popular» con una frase larga | Error `no_items` | `dia2/busqueda/ig-popular-reels-es.json` |
| Facebook `danek/facebook-search-ppr` | «Temporalmente deshabilitado para usuarios gratis» | `dia2/busqueda/fb-danek-1.json` |

Cuantías: el skill solo lanza los números vistos (10 resultados por búsqueda de pago; 1 por URL en el detalle). Para añadir un
valor: pruébalo aparte con un tope bajo (≥ el mínimo del actor), comprueba el resultado y solo entonces amplía la tabla y el test.

---

## 4. Bright Data

- **Datasets por URL**: Instagram `gd_lk5ns7kz21pck8jpis` y Facebook `gd_lyclm1571iy3mv57zw`. Petición:
  `POST https://api.brightdata.com/datasets/v3/scrape?dataset_id=…&include_errors=true&format=json`, cuerpo `[{"url": …}]`.
  Respuesta síncrona con los registros; si tarda, `202` con `snapshot_id` y el skill consulta
  `/datasets/v3/progress/{id}` y `/datasets/v3/snapshot/{id}?format=json`.
- **Threads no se lee por URL (decisión del skill)**: el dataset de Threads de Bright Data (`gd_md75myxy14rihbjksa`) devolvió
  `parse_error` en 3 de 5 URL, y los otros 2 registros SÍ traían contadores (9 y 299 me gusta, 0 y 15 comentarios, 16 y 19
  compartidos, 3.221 y 73.523 vistas; crudo `dia1/threads-brightdata.json`). El informe del piloto los dio por «sin métricas»
  porque leyó mal los nombres de los campos (`number_of_likes`, `number_of_comments`, `views`…). Con 2 lecturas válidas de 5 no
  hay muestra para adoptarlo como segunda fuente: el skill no lo lanza y Threads queda como `una_fuente`. **Pendiente del
  smoke real**: probar unas 20 URL de Threads con ese dataset; si lee la mayoría, bastaría un normalizador más.
- **Instagram**: 11 de 11 URL coinciden con Apify en me gusta, comentarios y fecha (una con 4 me gusta de diferencia: 19.665
  frente a 19.669, leída con minutos de diferencia). No da vistas en lo probado. Muestra pequeña y de baja interacción.
- **Facebook**: sirve para posts de grupos públicos (3 de 4) y de páginas con comentarios, pero **falla en los me gusta de
  páginas** (3 de 7) y en las URL muertas (`dead_page`, 2 de 11: se cobran igual). Su campo `likes` es solo el tipo «Me gusta»;
  el total de reacciones es la suma de `num_likes_type` (así coincide con el actor de búsqueda: 620 frente a 620 en un vídeo
  de 516 `likes`). Sus vistas (`video_view_count` y `play_count`) difieren entre sí y no se usan.
- **Lotes**: el skill envía lotes de 20 URL. La documentación de Bright Data dice «hasta 20 URL por petición» para su API de
  LinkedIn; para los datasets de Instagram y Facebook solo se probó con 5-6 URL por petición (sin cifra verificada).
- **Precio**: 5.000 registros/créditos gratis al mes (≈ 7,50 USD de valor, según su página); de pago, **1,50 USD por 1.000
  registros** (blogs de terceros, 30-sep-2026; **derivado, no contrastado en el panel**). El skill reserva
  `registros × 0,0015 USD` (configurable con `META_SEARCH_PRECIO_BD`) aunque usen créditos gratis.
- **Saldo**: la clave de API no puede leerlo; míralo en el panel del proveedor.
- **Cuenta inactiva**: una cuenta sin activar devuelve «Customer is not active» (HTTP 400) y ningún registro. Pasó con
  Instagram en el primer intento del piloto y funcionó al reintentar. Es un límite de la cuenta: se para.
- **Resultado desconocido**: si el `POST` no obtiene respuesta, o el snapshot queda `ready` y no se puede descargar (2
  reintentos), o el sondeo se agota, los registros pueden estar cobrados: se liquida la cota (URL × precio) como
  `resultado_desconocido`, el `snapshot_id` queda en `uso.jsonl`, en el libro y en un aviso de la cobertura, y no se guarda en
  la caché. Descarga ese snapshot desde el panel en vez de repetir la petición. Si un lote para, las lecturas ya pagadas de los
  lotes anteriores se conservan y se emparejan.
- **Precio configurable**: `META_SEARCH_PRECIO_BD` debe ser un número finito mayor que 0; `nan`, `inf`, negativos, 0 o texto
  dan un error claro antes de llamar (un precio no finito desactivaría el tope total).
- **No probado**: el producto «Instagram Hashtag Scraper API» de Bright Data (anunciado en su web) no se probó.

---

## 5. Los cuatro buscadores

| Motor | Endpoint | Cabecera | Precio por llamada | Coste real |
|---|---|---|---|---|
| Exa | `POST https://api.exa.ai/search` (`includeDomains`, `startPublishedDate`, `contents.text`) | `x-api-key` | 0,007 | `costDollars.total` de la respuesta |
| Exa contents (texto de respaldo) | `POST https://api.exa.ai/contents` | `x-api-key` | 0,001 por página | `costDollars.total` |
| Perplexity | `POST https://api.perplexity.ai/search` (`search_domain_filter`, `search_recency_filter`) | `Authorization: Bearer` | 0,005 | por llamada |
| Brave | `GET https://api.search.brave.com/res/v1/web/search` (`q`, `count`, `freshness`, `extra_snippets`) | `X-Subscription-Token` | 0,005 | por llamada |
| Firecrawl search | `POST https://api.firecrawl.dev/v2/search` (`query`, `limit`, `tbs`) | `Authorization: Bearer` | 0 USD; 2 créditos por 10 resultados | créditos del plan |
| Firecrawl scrape (respaldo) | `POST https://api.firecrawl.dev/v2/scrape` | `Authorization: Bearer` | 0 USD; 1 crédito por página | créditos del plan |

Dominios por red: Facebook `facebook.com`; Instagram `instagram.com`; Threads `threads.com` y `threads.net`. Exa y Perplexity los
reciben como filtro; Firecrawl y Brave, como `site:dominio` (con `OR` para Threads). Precios por llamada de Brave y Perplexity:
publicados (5 USD por 1.000 consultas). Brave responde **HTTP 422** con `SUBSCRIPTION_TOKEN_INVALID` cuando la clave no vale: el
skill lo trata como clave rechazada.

**El 403 de Firecrawl puede ser un bloqueo de la PÁGINA, no de la clave.** Solo se trata como «clave rechazada: revócala» un 401,
o un 403 cuyo cuerpo hable de la clave, el token o la API key. Cualquier otro 403 es un error de esa página (`leer` cae al
siguiente proveedor de texto) y **no** bloquea a Firecrawl para el resto de la sesión. Qué devuelve exactamente Firecrawl ante
páginas de Instagram, Threads o Facebook al leer una URL no se ha medido con una clave real.

---

## 6. Libro de gasto y topes

Un fichero único por usuario: `~/.meta-search/gasto.jsonl` (permisos 0600; `META_SEARCH_HOME` lo cambia).

```text
reserva      {id, investigacion, proveedor, concepto, cota_usd}          ← ANTES de llamar
liquidacion  {id, investigacion, coste_usd, estado}                      ← DESPUÉS, con el coste real
estados      ok · rechazada · respuesta_perdida · arranque_fallido · excepcion · sin_registros
             resultado_desconocido · interrumpida · liberada_colgada · no_enviada
```

- **Tope por llamada (`--tope-usd`, 0,5 por defecto)**: la cota de UNA llamada nunca lo supera. Si las URL de `metricas` no
  caben (URL × precio por registro), se envían las que caben y la cobertura avisa de las que quedan sin pedir; una llamada
  directa cuya cota lo supera no se lanza. `--max-urls` debe ser un entero ≥ 1, y una cota o un tope no finitos no se aceptan.
- **Tope total (`--tope-total-usd`, 1,5 por defecto) por investigación** = suma de liquidaciones + reservas en vuelo + la
  llamada que se quiere lanzar. Si no cabe, **no se lanza**. Una investigación es la carpeta `--salida` (o el nombre que des con
  `--investigacion`). `salud --en-vivo` usa una investigación por ejecución (`salud-AAAAMMDD-HHMMSS`). Los dos topes deben ser
  números finitos mayores que 0: se rechazan `nan`, `inf`, negativos y 0.
- **Bloqueo**: `fcntl.flock` (POSIX) o `msvcrt.locking` (Windows, no probado) más un cerrojo de hilos; reservar y comprobar el
  remanente ocurren bajo el mismo bloqueo. Dos procesos que intentan reservar el mismo remanente: solo uno pasa.
- **Cortacircuitos**: tras un límite (402/429, cuenta inactiva, actor deshabilitado), una clave rechazada o un
  `resultado_desconocido`, ese proveedor no se vuelve a llamar en toda la sesión: la llamada siguiente para sin red y con el
  mismo motivo (así un lote de temas no repite un `POST` que quizá ya creó una ejecución). `lote` usa una sola sesión.
- **Fallo local antes de enviar** (cabecera inválida, error de codificación, URL inválida): no salió nada a la red, así que no
  hay nada que cobrar. La reserva se libera con coste 0 y `estado: no_enviada`, sin reintentos; casi siempre es una clave con un
  carácter raro (`salud` la marca).
- **Una reserva sin liquidar** (proceso caído) sigue contando: es conservador. El skill intenta que no queden: `SIGTERM`,
  `SIGINT`, `SIGHUP` y `SIGQUIT` (los que existan) liquidan POR SU COTA ENTERA toda llamada en vuelo antes de salir
  (`estado: interrumpida`) e intentan, de mejor esfuerzo y con 3 s de tope, abortar las ejecuciones de Apify vivas. Un `SIGHUP`
  que ya se ignora (`nohup`) se respeta. Si aun así queda alguna reserva (por ejemplo, un `SIGKILL`):

  ```bash
  python3 "$H" libro --ver                                            # gastado y reservado por investigación
  python3 "$H" libro --liberar-colgadas --investigacion NOMBRE        # liquida cada reserva por su cota entera
  ```

  Liberar **cuenta como gastado** (el gasto nunca baja) y solo se hace cuando no hay ninguna ejecución en curso. **No cambies
  de `--investigacion` para esquivar una reserva**: eso reinicia el tope total.
- **Llamadas largas**: Apify y Bright Data pueden tardar minutos (hasta 15). Si tu herramienta mata los comandos a los 2
  minutos, lánzalas en segundo plano. Threads tardó 25-40 s por ejecución en el piloto; Bright Data, de 26 s a 4 min.
- **`<salida>/uso.jsonl`**: una fila por llamada con proveedor, actor o dataset, red, eventos cobrados, coste real, segundos y
  resultados. `salud` suma el gasto del mes por proveedor.
- **Caché** (`~/.meta-search/cache`): por hash de consulta + proveedor + red + día. Una repetición el mismo día no cuesta.
  `--sin-cache` la salta. Guarda solo los campos que el skill lee de cada respuesta (los candidatos normalizados en los
  buscadores), con la carpeta en 0700, los ficheros en 0600 y un día de vida; qué se guarda exactamente, en
  `privacidad-y-riesgos.md` §5. Una ejecución servida de la caché declara en la cobertura `coste_usd 0.0` y `de_cache True`
  (el coste de la ejecución original no se repite).
- **`lote --pago` y Threads**: la búsqueda de pago de Threads cobra 0,08 USD de arranque por ejecución, así que `lote` NO la
  lanza por tema: junta las palabras de TODOS los temas y hace una sola ejecución (cota = 0,08 + 10 × 0,0025 por palabra) si
  caben en `--tope-usd` y en 3 palabras clave (`MAX_PALABRAS_EJECUCION_THREADS`: el máximo probado en vivo con `search_filter:
  "top"`, el único que usa el skill; ver la tabla de entradas probadas). Si no caben, las parte en las ejecuciones justas, cada
  una con su arranque, y la cobertura lo dice (si ni siquiera una palabra cabe en el tope, no se lanza ninguna y el aviso lo
  dice). Con 4 o más palabras en una ejecución el skill la rechaza antes de llamar (`EntradaNoProbada`): no hay prueba con `top`
  y, si el actor la rechazara, se perdería el arranque de 0,08 USD.

---

## 7. Errores de límite: qué hace el skill y qué alternativa queda

| Señal | Qué es | Acción | Alternativa |
|---|---|---|---|
| HTTP 402 | Sin saldo o plan agotado | Para, no reintenta | Esperar al ciclo del plan o elevar el límite tú |
| HTTP 429 | Límite de tasa o de uso | Para, no reintenta | Espera; usa otro buscador |
| «Customer is not active» | Cuenta sin activar | Para | Activar la cuenta en el panel |
| Actor deshabilitado para plan gratis | Restricción del actor | Para | Usar el otro proveedor |
| «Rate limit» de la red dentro de una ejecución `FAILED` de Apify | Fallo del actor, no de la cuenta | `arranque_fallido`; no para a Apify | Repetir más tarde o medir con Bright Data |
| `resultado_desconocido` (POST sin respuesta, snapshot sin descargar…) | No se sabe si el proveedor cobró | Liquida la cota entera y para a ESE proveedor en la sesión | Mirar la consola del proveedor antes de repetir |
| Uso mensual de Apify sin margen | la consulta gratuita de límites de la API de Apify | No lanza | Esperar al ciclo; medir solo con Bright Data |
| Tope de la llamada menor que el mínimo (Threads: 0,08 + posts × 0,0025) | El arranque fijo se perdería | No lanza; avisa de cuánto hace falta | Subir `--tope-usd` o usar menos palabras |
| 401 / 403 (y 422 cuyo cuerpo hable de un token o clave inválidos, como Brave) | Clave rechazada | Para | Revocar y `conectar` otra |
| 403 de Firecrawl cuyo cuerpo NO habla de la clave | Bloqueo de la página | Error de esa URL; no para a Firecrawl | Probar otro proveedor de texto |
| Red, 500, 502, 503, 504 | Respuesta perdida: la petición salió y el proveedor PUDO cobrarla | Cada intento se liquida por su **cota entera** (`respuesta_perdida`). **Máximo 2 reintentos** de lo idempotente, cada uno con su reserva. Tras agotarlos, ese proveedor queda parado. El `POST` que crea una ejecución de Apify **nunca** se reintenta | Los demás proveedores |

Una parada de un proveedor **no detiene a los demás**: `descubrir` sigue con los otros buscadores y `metricas` con el otro
proveedor; queda en `paradas` de la cobertura con su alternativa. El código de salida es 2 si la parada deja sin resultado.

---

## 8. Planes gratis, créditos y altas

| Proveedor | Plan gratis o modelo (según su página, verifícalo al darte de alta) | Qué pasa al agotarlo |
|---|---|---|
| Apify | 5 USD de crédito mensual | `402`/«usage limit»: el skill para y no compra saldo; `metricas` sigue con Bright Data |
| Bright Data | 5.000 registros/créditos al mes (≈ 7,50 USD de valor) | `402`/«insufficient credits»: para; Instagram sigue con Apify, Facebook queda sin lector |
| Firecrawl | créditos gratis al mes sin tarjeta (2 por 10 resultados de búsqueda; 1 por página leída) | Para; descubre con los otros motores (Facebook se queda sin buscador) |
| Exa, Perplexity, Brave | pago por llamada (0,007 · 0,005 · 0,005 USD); Brave anuncia un crédito mensual | Para ese motor; los demás siguen |

Cómo dar de alta cada servicio, dónde está la documentación oficial y por qué este skill **no dicta rutas de menús**: las
interfaces cambian sin aviso, así que **verifica la interfaz a la fecha** en la documentación del proveedor y busca «API key»
o «API token». Detalle y límites de gasto en la cuenta del proveedor: `instalacion-y-alta.md`.

---

## 9. Lo que el skill nunca hace con el dinero

- Comprar créditos, cambiar de plan, activar recargas o subir un límite.
- Lanzar una llamada de pago sin reserva en el libro.
- Reintentar tras un 402 o un 429.
- Lanzar una ejecución de Threads con un tope que no cubre su arranque fijo.
- Imprimir una clave, o mandarla por argumento o URL.
- Gastar por encima de `--tope-total-usd` sin que lo suba quien paga.
