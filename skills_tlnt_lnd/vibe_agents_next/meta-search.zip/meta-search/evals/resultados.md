# Resultados y cambios

Este fichero recoge qué se corrigió en cada ronda de revisión del skill y con qué prueba. Las pruebas están en
`scripts/test_meta_helper.py` y se corren sin red: `cd scripts && python3 -m unittest`. Los escenarios con claves reales (`evals.json`)
siguen sin ejecutarse: los hace otra persona después.

## Evals con juez ciego (15-oct-2026, versión 1.2.1)

Tres escenarios de `evals.json` (e1 inglés negocio Instagram + Facebook, e2 español marketing Instagram + Threads con autores
anónimos, e3 técnico Threads + Facebook). Con el skill: el agente lee `SKILL.md` y usa el helper con `--tope-total-usd 0.30`.
Sin el skill: el mismo modelo con su búsqueda web normal y lectura de páginas, sin navegador, sin sesiones y sin APIs de
pago. Juez: otro agente del mismo modelo, ciego (respuestas copiadas como X/Y al azar; la clave se guardó aparte), con cinco
ejes de 0 a 10: cumplimiento, data original y verificable, honestidad, relevancia y utilidad para decidir.

| Escenario | Con el skill | Sin el skill |
|---|---|---|
| e1 inglés, negocio (Instagram y Facebook) | **37** | 19 |
| e2 español, marketing, autores anónimos (Instagram y Threads) | **36** | 19 |
| e3 técnico (Threads y Facebook) | **39** | 24 |
| **Total** | **112 / 150** | 62 / 150 |

- **Con el skill:** entrega las publicaciones pedidas con texto literal, enlace, autor, fecha y métricas (con su estado de
  contraste) y declara lo que falta (los compartidos de Instagram, Threads sin lector por URL). En e2 seudonimiza a los
  autores y avisa de que el texto literal sigue identificando.
- **Sin el skill:** perfiles y enlaces que no son publicaciones, fragmentos fuera de la ventana pedida y, en e2, los nombres
  reales de los usuarios en un anexo del mismo documento.
- **Las dos:** honestas en lo que declaran. El juez comprobó cuatro URL y no encontró texto inventado.
- **Punto flojo del skill, según el juez:** la relevancia de Instagram (muchas agencias que se anuncian), coherente con la
  calidad medida que declara cada entrega.
- **Coste con el skill:** e1 0,144 USD, e2 0,158 USD, e3 0 (salió de la caché del día). El contador de Apify cuadró con el
  libro al milésimo.

## Prueba real (15-oct-2026, versión 1.2.0)

Tres investigaciones con `descubrir … --red todas --pago --completo --max-urls 30 --tope-total-usd 0.60`:

| Tema | Cumplen (Facebook / Instagram / Threads) | Coste del libro |
|---|---|---|
| «AI automation agency clients» (inglés) | 13 / 30 / 10 | 0,380 USD |
| «lanzamiento de curso online» (español) | 14 / 19 / 2 | 0,314 USD |
| «vibe coding» | 18 / 30 / 10 | 0,385 USD |

- **Gasto:** el contador mensual de Apify subió 0,836 USD; el libro apuntó 0,8295 de Apify (la diferencia es la lectura de
  los datasets, que Apify cobra como uso de plataforma). Buscadores 0,051 USD; Bright Data 132 registros en créditos.
- **Facebook:** 45 de 53 URL con los cinco datos.
- **Instagram:** casi todo contrastado entre Apify y Bright Data.
- **Threads:** solo cumple lo que trae su búsqueda de pago.
- **Calidad, revisión manual:** ver la tabla de `references/metodo-de-busqueda.md` §2. Facebook es la red principal;
  Instagram y Threads quedan como complementarias, con su calidad declarada en cada entrega (decisión del responsable).

## Ronda 4 (versión 1.2.1)

La verificación de la ronda 3 dio APTO CON MENORES con tres hallazgos nuevos. Cada uno tiene su prueba en las clases
`TestR4*`, que fallan contra la versión 1.2.0 y pasan con la 1.2.1:

- **Muro de inicio de sesión (MS3-1).** Los muros reales de Threads de las pruebas («Log in or sign up for Threads…», «Inicia
  sesión o regístrate en Threads…») ya no se escapaban como texto. Ahora un lema literal del muro de cada red más dos familias
  de señales bastan, las frases se separan también por `·`, `|` y `•`, y una lista de enlaces o idiomas no cuenta como frase.
  La referencia del buscador solo decide si tiene tres o más palabras distintivas y no es ella misma un muro. Un texto con dos
  o más frases largas en prosa nunca es un muro: en las pruebas reales, un post con el muro pegado detrás conserva su texto.
  Sobre las 7.052 cadenas reales de las pruebas, se marcan como muro exactamente los 5 muros de Threads que hay; un tutorial
  legítimo de 975 caracteres no cae con ninguna referencia.
- **Fusión de lecturas (MS3-2).** Al juntar dos formas del mismo post, una lectura buena gana siempre a una con error, aunque
  la de error sea más reciente.
- **Selectores tras emoji (MS3-3).** U+FE00-FE0D no son selectores de emoji: detrás de un emoji o símbolo pictográfico se
  quitan y se avisa (podían esconder 4 bits por carácter). Detrás de letras, cifras, ideogramas o comillas son variantes
  estándar de Unicode y se conservan. Ocho o más con valores distintos en un texto dan aviso. Con el fichero oficial de
  Unicode: 742 de 742 secuencias de emoji y 1.246 de 1.246 variantes estándar intactas, 0 avisos falsos, y el texto literal
  de las 11.189 cadenas reales sin cambios.

## Ronda 3 (versión 1.2.0)

Corrige los seis menores (MS2-1…MS2-6) y las observaciones baratas de la verificación de la versión 1.1.0. Cada arreglo lleva su
prueba en una clase `TestR3…` de `scripts/test_meta_helper.py`; se escribieron para fallar con la 1.1.0 y pasar con la 1.2.0 (las
que pasan con las dos fijan un comportamiento que no cambia: una tanda de selectores sigue siendo sospechosa, un muro de verdad
sigue cayendo, la lectura del destino gana si es la más reciente, la del hashtag y las incompletas se siguen pagando).

| Hallazgo | Qué cambia | Prueba |
|---|---|---|
| MS2-1 | La caché guarda también `isCommentsDisabled` y su formato sube a `meta-search-cache-3`: una lectura servida de la caché sigue sin comentarios medidos (aviso `comentarios_desactivados_por_el_autor`, no cumple). Una prueba vigilante recorre los fixtures y exige que todo campo de primer nivel que lea un normalizador esté en `CAMPOS_CACHE` | `TestR3Ms21CacheYComentariosDesactivados` |
| MS2-2 | `limpiar_control` y `hay_invisibles` conservan el U+FE0F que sigue a un carácter base de presentación (símbolos, emojis, cifras y `#`/`*` de las teclas, ideogramas, y ahora ℹ y 〰); se quitan el suelto tras una letra o un espacio o al principio, y toda tanda de dos o más. El literal del `citas-*.json` sale igual al del proveedor salvo invisibles reales | `TestR3Ms22SelectoresDeEmoji` |
| MS2-3 | La caché se escribe como `meta-search-{proveedor}-{hash}.json` con el marcador de formato dentro. `purgar_cache` solo borra ficheros identificados como de este skill —prefijo exclusivo, o formato 2 reconocido por su marcador— y solo si están caducados o son del formato anterior; los nombres `{proveedor}-{hash}.json` (los de 1.0.0, que otros skills también usan) ya no se tocan | `TestR3Ms23PurgarCache` |
| MS2-4 | `es_muro_de_sesion` exige, además de tres familias de señales, que el texto sea casi todo formulario (hasta 1.000 caracteres y ninguna frase de más de 12 palabras) o, si es más largo, que no comparta palabras con el título o el fragmento del buscador. Un tutorial o una pieza de soporte sobre iniciar sesión ya no se descartan | `TestR3Ms24MuroDeSesion` |
| MS2-5 | `MAX_PALABRAS_EJECUCION_THREADS = 3`, validado en `validar_entrada`: con `search_filter: "top"` lo máximo visto con `SUCCEEDED` son 3 palabras clave (`dia2/busqueda/threads-busqueda-corta-top.json`: «Scraped 20 posts for 3 keywords»). Las 4 solo se vieron con `recent` y frases largas (`dia2/busqueda/threads-busqueda.json`: 10 posts, 3 «no_results»). `SKILL.md` y las referencias dicen lo mismo | `TestR3Ms25ThreadsTresPalabras`, `TestR2ThreadsMaxPalabrasProbadas` |
| MS2-6 | Al fundir dos publicaciones, por proveedor sobrevive la lectura más reciente (por `consultado`; a igual instante, la de más me gusta), no la del destino | `TestR3Ms26FundirLecturasDelMismoProveedor` |
| O2-1 | `metricas` no repaga el detalle de Apify (0,0027 USD por URL) si la publicación ya trae una lectura COMPLETA de la búsqueda de pago de Instagram (me gusta, comentarios y texto): es la misma empresa y solo refrescaría. Si le falta un campo, o es la del hashtag (lo último, sin interacción), se sigue pagando | `TestR3ObservacionesBaratas` |
| O2-2 | Una ejecución servida de la caché declara en la cobertura `coste_usd 0.0` y `de_cache True` (antes repetía el coste de la ejecución original) | `TestR3ObservacionesBaratas` |
| O2-4 | `lote` no dice «se lanzan en N ejecuciones» cuando el tope no cubre ni una palabra de Threads; `salud` con solo Bright Data ya no habla de «la búsqueda de pago y el detalle de Apify» | `TestR3ObservacionesBaratas` |

Quedan sin cambio, a propósito (declarado): la rama `len(reps) >= 3` de `contrastar_campo` sigue siendo código que hoy no se alcanza
(solo hay dos empresas; se deja por si se añade una tercera); `registro_ilegible` no tiene umbral (si el proveedor cambia la forma
de todos los registros se descartan todos, se avisa y la cobertura muestra el recuento); los `pfbid` que varían entre lecturas
(O2-3) siguen sin poder comprobarse y fallan del lado seguro. Una decisión de esta ronda: los ficheros de caché de la versión 1.0.0
(`{proveedor}-{hash}.json`, con la respuesta cruda) ya NO se borran solos, porque ese nombre no permite saber de qué skill son; la
privacidad lo dice y indica cómo borrarlos a mano.

Sigue sin comprobarse con proveedores reales (no hay red en las pruebas): si el actor de Threads acepta más de 3 palabras clave por
ejecución con `top`; qué devuelven Exa y Firecrawl ante estas redes (las señales del muro son una suposición); si Bright Data trae un
campo equivalente a `isCommentsDisabled`.

## Ronda 2 (versión 1.1.0)

Corrige los hallazgos de la auditoría adversarial de la versión 1.0.0 (un Major, doce menores, cuatro observaciones y el campo
`isCommentsDisabled`). Cada arreglo lleva su prueba en una clase `TestR2Ms…`, `TestR2O…` o `TestR2Coment…` de
`scripts/test_meta_helper.py`; cada prueba se escribió para fallar con la 1.0.0 y pasar con la 1.1.0 (las que pasan con las dos son
regresiones que fijan un comportamiento que no cambia, y así se indica).

| Hallazgo | Qué cambia | Prueba |
|---|---|---|
| MS-1 (Major) | El contraste exige lecturas de **dos empresas** distintas: todo `apify_*` es Apify. Dos lecturas de la misma empresa cuentan como una (manda la más reciente) y dan `una_fuente`. Lo mismo para la fecha (`proveedores_contrastados`) y para la comparación de textos (`citas --verificar`). `salud` lo dice; `SKILL.md` y `entrega-y-credibilidad.md` §4 igual | `TestR2Ms01ContrasteEntreEmpresas` |
| MS-2 | La caché guarda solo los campos que el skill lee (candidatos normalizados en los buscadores), con carpeta 0700, ficheros 0600 y un día de vida; se purgan las cachés caducadas y las del formato antiguo. La documentación dice exactamente qué se guarda | `TestR2Ms02Cache` |
| MS-3 | La guardia de «lectura de otra publicación» también actúa en Facebook con `pfbid`; si la forma de la URL difiere y no hay con qué comparar, la lectura entra con el aviso `identidad_de_la_lectura_sin_confirmar` | `TestR2Ms03Ms13FacebookPfbid` |
| MS-4 | La URL canónica de Facebook se arma con segmentos validados y codificados; una «página» con saltos de línea, `?` o `&` no es una página | `TestR2Ms04UrlCanonicaDeFacebook` |
| MS-5 | Un muro de inicio de sesión devuelto por Exa o Firecrawl se descarta (la ficha queda `sin_texto`) | `TestR2Ms05MuroDeSesion` |
| MS-6 | El fragmento de `descubrir-*.md` se escapa en una línea y pasa por los avisos; la fila con aviso lleva «⚠» | `TestR2Ms06FragmentoDeDescubrir` |
| MS-7 | Los selectores de variación (y los rellenos en blanco) se detectan, los suplementarios se quitan, el `citas-*.json` sale sin invisibles y se declara que la detección de instrucciones es una heurística | `TestR2Ms07Invisibles` |
| MS-8 | `ABORTING`, `TIMING-OUT` y cualquier estado no final de Apify se siguen sondeando; sin estado final, se aborta y se liquida la cota | `TestR2Ms08EstadosNoFinalesDeApify` |
| MS-9 | El tope por autor agrupa por red y autor | `TestR2Ms09TopePorAutor` |
| MS-10 | Un registro de forma inesperada se cuenta (`registro_ilegible`) y el resto sigue; las fechas fuera de rango son ausentes | `TestR2Ms10Robustez` |
| MS-11 | `no_disponible` solo para páginas muertas o privadas, no para fallos transitorios | `TestR2Ms11NoDisponible` |
| MS-12 | Los fixtures no llevan palabras sustituidas: donde se retiró una, hay la marca visible «[…]»; el encabezado de las pruebas declara que están saneados y truncados | `TestR2Ms12Fixtures` |
| MS-13 | El número que da un proveedor para una URL `pfbid` se apunta y las dos formas del mismo post se funden con alias | `TestR2Ms03Ms13FacebookPfbid` |
| O-2 | `lote --pago` junta las palabras de Threads de todos los temas en una ejecución si caben en la cota; si no, las parte y lo declara (el máximo por ejecución era 4 en esta ronda; la ronda 3 lo deja en 3, ver abajo) | `TestR2O2LoteDeThreads` |
| O-3 | Sin cambio de comportamiento: un `comentarios` nulo del proveedor no se asume 0 (queda `sin_metricas`); se documenta | `TestR2ComentariosDesactivadosYNulos` |
| `isCommentsDisabled` | Los comentarios cerrados por el autor no son un 0 medido: `comentarios` es nulo, aviso `comentarios_desactivados_por_el_autor` y la ficha no cumple por ese campo | `TestR2ComentariosDesactivadosYNulos` |
| O-5 | Una redirección que baja de https a http no conserva las credenciales | `TestR2O5RedireccionSinCredenciales` |

Quedan sin cambio, a propósito: el tope total es por investigación (O-1); el aviso por U+200C legítimo en texto persa o indio se
mantiene (O-4, es solo un aviso).

Cosas que esta ronda no pudo comprobar con proveedores reales (no hay red en las pruebas): qué devuelven Exa y Firecrawl ante una
página de Instagram, Threads o Facebook (la lista de señales del muro es una suposición); si los `pfbid` de un mismo post varían
entre lecturas; si el actor de Threads acepta más de 3 palabras clave por ejecución; si un campo `isCommentsDisabled` aparece con
otro nombre en Bright Data.
