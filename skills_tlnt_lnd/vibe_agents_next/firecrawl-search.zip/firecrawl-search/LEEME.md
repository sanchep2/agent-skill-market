# firecrawl-search

Busca fuentes web, noticias e imágenes con Firecrawl, lee páginas y descubre enlaces de un sitio.
También permite trabajos por lote y rastreo con cotas previas. Entrega texto de fuentes con URL;
las respuestas de modelos se presentan aparte. Versión 1.0.0, Python 3.9+, sin dependencias externas.

## Instalar

Copia la carpeta completa a la carpeta de skills de tu agente, por ejemplo
`~/.claude/skills/firecrawl-search` o `~/.codex/skills/firecrawl-search`.
Desde la carpeta del skill:

```bash
python3 scripts/firecrawl_helper.py salud
```

El diagnóstico termina bien incluso sin clave y explica qué falta. Si hay clave, comprueba
`credit-usage`, sonda gratis medida el 2026-10-15. La instalación no incluye credenciales.

Obtén tu clave en [Firecrawl](https://www.firecrawl.dev/), cópiala al portapapeles y ejecuta:

```bash
python3 scripts/firecrawl_helper.py conectar firecrawl
```

No pegues claves en el chat o en los argumentos. [Alta e instalación](references/instalacion-y-alta.md).

## Usar

> «Busca documentación oficial sobre recuperación híbrida y entrega los pasajes con sus enlaces.»

> «Descubre las páginas de precios de este sitio con mapa y lee solo las necesarias.»

> «Consulta los trabajos pendientes, conserva su reserva y genera la entrega en Markdown y JSON.»

Ejemplo desde la carpeta del skill (el precio es una valoración que debes ajustar a tu plan):

```bash
python3 scripts/firecrawl_helper.py buscar 'recuperación híbrida RAG' --n 10 \
  --precio-credito 0.00083 --tope-creditos 20 --salida ./fuentes --json
python3 scripts/firecrawl_helper.py citas --salida ./fuentes --json
```

## Coste y alcance

La unidad es el crédito. Búsqueda: 2 por 10 resultados, redondeando hacia arriba;
lectura simple: base 1, reserva 2 para cubrir un PDF oculto de una página; mapa: 1 por llamada. PDF y formatos generados pueden subir la cota.
El USD es una **valoración estimada, no factura**: `--precio-credito` es opcional (defecto 0.0038 USD/crédito, Hobby mensual 19/5000; Fase 0 §3, 2026-10-15) para
consultas de pago y simulaciones. Tope inicial 100 créditos, 0,50 USD por llamada y 1,50 USD total.
Nunca compra créditos ni cambia de plan. Ver [costes y límites](references/costes-y-limites.md).

LinkedIn, Facebook, Instagram y Threads rechazaron la lectura de publicaciones con 403 y
0 créditos en la medición recibida del 2026-10-15: se rechazan localmente, sin reserva.
El smoke real del 2026-10-15 aporta capturas públicas saneadas de búsqueda, lectura, mapa, lote, rastreo y Agent; no verifica todos los parámetros.
Agente requiere habilitación explícita y `maxCredits` bajo. No implementa Extract, Deep Research,
Parse, Interact, Monitor ni webhooks. Windows: sin probar.

Los fixtures de contrato son ejemplos construidos; smoke_real_20261015.json contiene la captura normalizada saneada del smoke real. Las evals con y sin el skill (16-oct-2026) están en `evals/resultados.md`.
