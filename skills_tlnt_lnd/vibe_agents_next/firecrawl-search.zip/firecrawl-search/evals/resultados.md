# Resultados — firecrawl-search 1.0.0

Fecha: 16-oct-2026. Lo que sigue es lo medido, tal cual; donde el skill no gana o no se pudo comprobar algo, se dice.

## Pruebas automáticas

- `cd scripts && python3 -m unittest discover -p "test_*.py"`: **152 pruebas, OK**, sin red, con HOME vacío y
  Python 3.14. La sintaxis de los módulos se comprueba también con la gramática de Python 3.9; no se ha ejecutado en un
  intérprete 3.9 real.
- La copia de `buscadores_comun.py` coincide con el SHA-256 declarado en `scripts/COMUN.sha256`
  (`c2520164bfe171b7812420fad0ed39b8bad287ba3349b945fd946488e39f65bb`) y con las copias de los otros tres skills de
  buscadores. Las pruebas del cliente común viajan con exa-search.
- Auditoría adversarial en seis rondas, con todos los hallazgos corregidos; la sexta da APTO. Intentó que el skill pasara
  el tope en créditos o en USD, repitiera un POST de pago, liberara la reserva de un trabajo sin estado final, apuntara 0
  cuando el coste es desconocido, siguiera instrucciones de una página o imprimiera una clave.
- Medición (15-oct-2026): `credit-usage` es gratis; `/v2/search` con `limit` 10 gasta 2 créditos; leer publicaciones de
  LinkedIn, Facebook, Instagram o Threads da 403 «we do not support this site», sin coste. El skill las rechaza antes de
  llamar.

## Smoke real (15-oct-2026)

Revisión manual, ficha a ficha, de títulos, URL y extractos guardados. «Útil» significa que la ficha responde a la
pregunta del tema con contenido propio y en un idioma útil para la consulta. T1: «AI automation agency clients» (inglés,
negocio); T2: «lanzamiento de curso online» (español, marketing); T3: «vibe coding» (técnico).

| Modo | T1 | T2 | T3 | Nota |
|---|---|---|---|---|
| buscar web | 9/10 | 9/10 | 9/10 | T1: 1 de plataformas de agentes; T2: 1 página de venta de curso |
| buscar news | — | — | 10/10 | Las fechas relativas («2 days ago») no se convierten: salen como `fecha s.d.` con aviso, sin inventar |
| leer / mapa / lote / rastrear / agente | 2 de 3 (LinkedIn: no admitida, sin llamada ni coste) · 20 URL · 3 de 3 · 3 páginas · 3 artículos con URL | | | |

Coste del smoke: **17 créditos medidos por diferencia de saldo**. El libro liquidó 19 créditos porque, cuando el
proveedor no informa del consumo, liquida por la cota. No hay coste en USD medido: la conversión a USD es una valoración
estimada.

Todos los modos pasan la puerta de ≥ 50 % útil.

## Evals con y sin el skill (16-oct-2026)

**Método.** Dos escenarios de `evals.json`. El mismo agente de código hace cada escenario dos veces: con el skill y sin él
(su búsqueda web normal, sin navegador ni APIs de pago). Las entregas se copian como X e Y al azar y la clave se guarda
aparte. Juzgan:

- **Un juez que solo ve las dos respuestas.**
- **Tres jueces de tres proveedores distintos que ven además la evidencia de cada lado** (traza del agente y ficheros
  generados: registros, libro de gasto). Los criterios de proceso solo se pueden comprobar con ella. Cada juez comprueba
  a mano al menos 3 URL por entrega.

**Escenarios.**

- **e1:** fuentes originales en español sobre lanzamiento de cursos online entre el 1 y el 14 de octubre de 2026; web y
  noticias con 10 resultados por fuente, hasta cinco extractos y un máximo de 30 créditos.
- **e2:** en un sitio de documentación oficial elegido antes de empezar, `mapa` de hasta 20 URL sobre recuperación híbrida
  en RAG, lectura de como mucho tres por `lote` con concurrencia 2 y un máximo de 30 créditos.

| Escenario | Juez | Criterios con skill | Criterios sin skill | Calidad con skill (0-10) | Calidad sin skill | Mejor |
|---|---|---|---|---|---|---|
| e1 | Solo respuestas | 2/6 | 2/6 | 6 | 7 | **sin el skill** |
| e1 | Juez A (con evidencia) | 6/6 | 2/6 | 8 | 6 | con el skill |
| e1 | Juez B (con evidencia) | 6/6 | 2/6 | 8 | 6 | con el skill |
| e1 | Juez C (con evidencia) | 4/6 | 3/6 | 7 | 6,5 | con el skill |
| e2 | Solo respuestas | 2/7 | 1/7 | 7,5 | 6 | con el skill |
| e2 | Juez A (con evidencia) | 5/7 | 2/7 | 8 | 6 | con el skill |
| e2 | Juez B (con evidencia) | 5/7 | 2/7 | 8 | 5 | con el skill |
| e2 | Juez C (con evidencia) | 4/7 | 1/7 | 8 | 6 | con el skill |

Los tres jueces con evidencia eligen el skill en los dos escenarios. El juez que solo ve las respuestas prefiere la línea
base en e1.

**Lo que decide la diferencia, según los jueces:**

- **Con el skill:** en e1, búsqueda web y de noticias con `limit` 10 y el rango de fechas en `tbs`, previsión de créditos
  antes de gastar, liquidación con `creditsUsed`, citas literales y las fechas relativas sin convertir. En e2, sitio
  elegido antes de ejecutar, `mapa` de 20 URL, tres lecturas en un solo lote, reserva de 6 créditos liquidada a 3, y los
  pasajes coinciden con las páginas.
- **Sin el skill:** en e1 localiza **tres anuncios reales, una selección más concentrada y útil**, pero no sigue el método
  pedido ni guarda los ficheros. En e2 aporta dos citas correctas, sin mapa, sin lote y sin cuenta de créditos.

**Punto débil del skill en e1.** Solo encuentra un lanzamiento primario con fecha sólida, y lo declara. Su libro llegó a
los 30 créditos del tope porque 7 de sus 14 llamadas se liquidaron por la cota: el proveedor no informó del consumo en
esas lecturas.

**Invenciones.**

- **Con el skill: ninguna.** Una nota de «dato del proveedor no verificable»: fechas tomadas de los metadatos de la
  página, que la entrega atribuía a esos metadatos.
- **Sin el skill:** un autor («admin») que no está en la fuente, un recuento de 13 consultas cuando la traza solo
  registra 4, y pasajes y fechas sin respaldo en la traza.

**Lo que no se pudo comprobar:** las rutas de respuesta perdida, timeout y cancelación de un trabajo, y un caso con
instrucciones dentro de una página, no se ejecutaron en la eval. Los cubren las pruebas automáticas.

**Coste de las evals con el skill** (créditos de Firecrawl):

| Escenario | Llamadas | Liquidado en el libro | Procedencia |
|---|---|---|---|
| e1 | 14 | 30 | 7 llamadas informadas por el proveedor y 7 liquidadas por la cota |
| e2 | 2 | 4 | mapa por tarifa (1) y lote informado por el proveedor (3) |

**Consumo medido por diferencia de saldo, los dos escenarios juntos: 27 créditos.** El libro liquidó 34 porque, sin
consumo informado, apunta la cota: es conservador a propósito.

## Límites conocidos

- LinkedIn, Facebook, Instagram y Threads no se pueden leer con Firecrawl (403 sin coste): el skill las rechaza antes de
  llamar.
- `rastrear` exige `limit` y `maxDiscoveryDepth`: sin `limit`, Firecrawl usa 10.000 páginas.
- La conversión a USD usa un precio por crédito por defecto de 0,0038, etiquetado como valoración estimada; cada reserva
  guarda su precio.
- Cuando el proveedor no informa del consumo, el libro liquida por la cota: el gasto anotado puede ser mayor que el real.
- `summary` y la lectura con texto completo en la búsqueda no se piden: no tienen una cota verificada.
- Pruebas automáticas en Linux; smoke y evals en macOS. En Windows no se ha probado.
