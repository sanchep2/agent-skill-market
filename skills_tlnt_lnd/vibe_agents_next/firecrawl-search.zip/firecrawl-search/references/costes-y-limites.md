# Costes y límites

## Índice

- [1. Fuentes y medición](#1-fuentes-y-medición)
- [2. Tabla de recargos](#2-tabla-de-recargos)
- [3. Presupuesto y trabajos](#3-presupuesto-y-trabajos)
- [4. Límites y cambios](#4-límites-y-cambios)

## 1. Fuentes y medición

Fuentes oficiales leídas en Fase 0 el **2026-10-15**:
[billing](https://docs.firecrawl.dev/billing), [pricing](https://www.firecrawl.dev/pricing),
[Search](https://docs.firecrawl.dev/features/search),
[Scrape](https://docs.firecrawl.dev/features/scrape),
[credit-usage](https://docs.firecrawl.dev/api-reference/endpoint/credit-usage),
[rate limits](https://docs.firecrawl.dev/rate-limits).
No se consultaron proveedores durante la construcción. Medición recibida del 15-oct:
credit-usage dos veces sin gasto; search limit=10 consume 2 y devuelve creditsUsed=2;
lectura de publicaciones LinkedIn/Facebook/Instagram/Threads devuelve 403
«we do not support this site», delta de créditos 0. La cuenta medida tiene planCredits=100000;
no se infiere nombre, precio ni concurrencia del plan de esa cifra.

| Endpoint habilitado | Cota en créditos y fuente |
|---|---|
| search sin lectura | 2 × ceil(limit × fuentes × max(1,categorías) / 10); categorías multiplican por prudencia, sin medición. Search + billing |
| scrape | base 1 (X/Twitter 30 según billing, sin medir) + recargos + N PDF; N=1 por defecto para PDF oculto, maxPages enviado |
| map | 1 fijo, billing; sin campo de uso documentado |
| batch | suma de cotas scrape de URL admitidas, maxPages en cada documento; batch + billing |
| crawl | limit × cota por página; X usa base 30; maxDiscoveryDepth y limit enviados; crawl + billing |
| agent optativo | maxCredits 1..200, referencia Agent; cancelación cooperativa; captura real de Agent en el smoke |
| credit-usage | gratis medido; histórico documentado, sin probar en vivo |

La lectura HTML ordinaria reserva y, sin coste informado, liquida 2 por cota (1 base +
1 PDF posible). No se presenta como tarifa HTML ni como consumo observado. El parser
maxPages está documentado; su cumplimiento y la cota del rastreo no se han medido aparte:
compruébalos en tu primer uso con un tope bajo. La exclusión por extensión sola no acota PDF ocultos.

## 2. Tabla de recargos

Créditos adicionales por página/documento según [billing](https://docs.firecrawl.dev/billing),
lectura 2026-10-15; [change tracking](https://docs.firecrawl.dev/features/change-tracking)
para su modo JSON. Los recargos se acumulan.

| Opción | Recargo documentado | Estado en el helper |
|---|---|---|
| PDF | +1 por página PDF | maxPages explícito; PDF oculto hasta 1 página por defecto |
| json | +4 | --permitir-recargos y esquema/prompt |
| question/highlights/audio/video | +4 cada uno | no solicitados, respuesta sin verificar |
| redactPII | +4 | no solicitado |
| checkPromptInjection | +4; 5 si falla tras ejecutarse | no solicitado |
| zeroDataRetention | +1 | no solicitado |
| changeTracking modes:[json] | +5 | no solicitado |
| changeTracking git-diff | sin recargo | no solicitado |
| lockdown | acierto de caché 5, fallo 1 | no solicitado |
| proxy enhanced/auto | sin recargo según billing y enhanced-mode | no se envía; parámetro deprecado |
| summary | NO VERIFICADO: no aparece en tabla Fase 0 | solicitud deshabilitada; no se inventa +4 |
| X/Twitter | base total 30, 34 con json | exige aceptación de recargo; no medido |
| proveedores de enriquecimiento LinkedIn | 5..40 según proveedor | no son lectura de publicaciones; estas se rechazan |

Ejemplo: json + zeroDataRetention = 6 base incluida; esas dos opciones no están ambas
habilitadas. Un PDF de 200 páginas reserva 201 (más formatos). Caché de Firecrawl cobra
igual; caché local de buscar evita la llamada y marca coste local 0.

## 3. Presupuesto y trabajos

```text
cerrojo único → comprobar USD y créditos (gastado + pendiente) → reservar → enviar
        éxito con uso → liquidar proveedor       sin uso → cota/tarifa documentada
        pérdida síncrona → cota y DESCONOCIDO     trabajo incierto → mantener pendiente
```

--precio-credito opcional, defecto 0.0038 USD/crédito: USD = créditos × precio, siempre
`valoracion_estimada`, no factura (Hobby mensual 19/5000, Fase 0 §3, 2026-10-15). La tabla anual de pricing da Standard 83 USD/100000
créditos: 0.00083 es cálculo ilustrativo. Hobby anual 16/5000=0.0032 y mensual
19/5000=0.0038; no usar esos precios como factura de otra cuenta.
Topes por defecto: 100 créditos por investigación, 0.50 USD por llamada, 1.50 USD total.
Mantener el mismo ID y HOME; cambiarlo evita el presupuesto de esa investigación.

creditsUsed de búsqueda/estado y creditsCost de scrape se liquidan como proveedor.
Mapa es tarifa. Scrape sin dato liquida cota entera. Un delta global de saldo no es
atribuible con concurrencia. No sumar costes de los registros que comparten una llamada.

POST de trabajo se envía una vez. Respuesta perdida, timeout o cancelación sin terminal
conservan reserva; código 6. Cancelación aceptada no libera: Fase 0 §5 «¿Se cobra lo
cancelado? NO VERIFICADO» y «Cooperativo: puede subir tras cancelar». Batch solo completed
liquida; agent cancelled sigue pendiente. Si se libera manualmente un pendiente sin
ID, se liquida cota completa y se declara desconocido.

## 4. Límites y cambios

Fase 0 §1: «/crawl sin limit: el valor por defecto es 10.000 páginas»; §7:
«/agent: maxCredits por defecto es 2.500». El helper exige valores explícitos bajos.
La comprobación previa de saldo crawl se contradice: asumir 402 cuando no cubre limit.
402/401/403 no se reintentan; 403 unsupported-site es por URL. Síncronos reintentan
red/5xx/429 hasta dos veces con nueva reserva; Retry-After hasta 30 s, mayor detiene.
GET/POST de mapa no crea trabajo. No recargar créditos ni cambiar de plan automáticamente.

Free documentado: 1000 créditos únicos, concurrencia 2, 10/min scrape/map/search y
2/min crawl/agent. Límites por equipo; cola caduca a las 48 h, llena devuelve 429.
No asumir que corresponden a una cuenta de 100000 créditos.

Fase 0 §2 y [releases](https://github.com/firecrawl/firecrawl/releases), 2026-10-15:
Extract deprecado v2.9.0; Deep Research y llmstxt deprecados v2.10. `research` cambia
el 16-nov-2026 a data.research: deshabilitado. persistentSession pasa a profile;
pii retirado; ignoreRobots booleano no válido. Interact/Parse/Monitor vigentes pero
fuera de v1; tarifa Parse NO VERIFICADA; modo sin clave con límites NO VERIFICADOS,
no usado. Webhooks documentados (crawl firma HMAC-SHA256) pero no implementados.

## Coste después del smoke del 2026-10-15

La entrega y `coste_entrega()` desglosan el coste por origen, en texto y JSON.
El total liquidado es contable: no implica que todo sea una factura o una estimación.
En `desglose`:

- `usd_real_proveedor`: USD informados por el proveedor (Exa `costDollars`, Perplexity Agent `usage.cost`).
- `usd_estimado_tarifa`: USD calculados con tarifa, sin medición monetaria de esa llamada.
- `usd_valoracion_creditos`: conversión estimada a USD de créditos de Firecrawl; nunca USD reales informados.
- `creditos_informados_proveedor`: créditos medidos por el proveedor, separados de su valoración monetaria.
- `usd_cota_sin_coste_real`: cota liquidada cuyo coste real es DESCONOCIDO, incluso con HTTP exitoso sin uso.
- `reservado_sin_liquidar_usd` y `reservado_sin_liquidar_creditos`: reservas pendientes, fuera del total liquidado.

`valoracion_estimada: true` indica que hay componentes estimados; no etiqueta los USD
reales del proveedor como estimados. `coste_real_desconocido: true` cubre cotas sin coste real y pendientes. El flag preexistente `desconocido` conserva su significado de respuesta incierta (pérdida o pendiente), para mantener los códigos de salida de respuestas válidas sin uso informado. No sumar una llamada por cada resultado ni sumar créditos a USD.

## Valoración por defecto y sugerencias

Desde el ajuste del smoke, `--precio-credito` es opcional: **0.0038 USD/crédito**,
valoración estimada, no factura. Cálculo: Hobby mensual, **19 USD / 5000 créditos**,
Fase 0 `03-fase0-firecrawl.md` §3, **2026-10-15**, [pricing](https://www.firecrawl.dev/pricing).
El presupuesto y la simulación usan ese valor salvo sustitución explícita con el flag.

`salud` aprovecha su única sonda gratuita y `saldo` su lectura de `credit-usage` para
sugerir valores orientativos según `planCredits`; no cambian el defecto, la sesión ni
las reservas guardadas. El volumen no identifica el contrato ni la modalidad de pago.

| planCredits | Sugerencia USD/crédito | Base de la sugerencia, Fase 0 §3 |
|---|---|---|
| 5000 | 0.0038 | Hobby mensual 19/5000; anual 16/5000=0.0032 también documentado |
| 100000 | 0.00083 | Standard anual 83/100000 |
| 500000 | 0.000666 | Growth anual 333/500000, cociente sin redondear |
| 1000000 | 0.000599 | Scale anual 599/1000000, cociente sin redondear |
| Free, ausente u otro | sin precio sugerido | comprobar contrato; no asumir precio cero |

`saldo --json` añade `valoracion_credito`: `precio_usd_aplicado`, `precio_usd_defecto`,
`precio_usd_sugerido` (null si no se conoce), `valoracion_estimada: true`,
`referencia_precio` y `texto`. La sugerencia exige cambiar `--precio-credito` explícitamente.
