# Parámetros y cuerpos de petición

## Índice

- [1. Búsqueda y mapa](#1-búsqueda-y-mapa)
- [2. Lectura](#2-lectura)
- [3. Trabajos](#3-trabajos)
- [4. Superficie excluida](#4-superficie-excluida)

## 1. Búsqueda y mapa

Base `https://api.firecrawl.dev/v2`, Bearer en cabecera. Python estándar, sin SDK.
Fuente de todos los parámetros: [referencia oficial](https://docs.firecrawl.dev/api-reference/introduction),
endpoints search/scrape/map/crawl/batch-scrape/agent y Fase 0, lectura 2026-10-15.

| CLI buscar | JSON POST /search |
|---|---|
| consulta | query, 1-500 caracteres |
| --n 1..100 | limit redondeado arriba a 10, por fuente |
| --fuentes web,news,images | sources (se omite para web por defecto) |
| --categorias developer,gov,pdf | categories; research rechazado |
| --dominios / --excluir | includeDomains / excludeDomains, excluyentes; máximo local 50 |
| --recencia h,d,w,m,y | tbs qdr:X |
| --desde/--hasta AAAA-MM-DD | tbs cdr:1,cd_min:MM/DD/YYYY,cd_max:MM/DD/YYYY |
| --por-fecha | prefijo tbs sbd:1, combinable con fechas o recencia |
| --pais / --ubicacion | country de dos letras / location texto |

`--recencia` no se mezcla con fechas absolutas. `tbs` solo afecta web. No se reescribe
la consulta con site:. `--con-texto` se rechaza antes de red: falta cota verificable
para todas las URL y recargos que podría descubrir.

Mapa: `url`, `search` (--buscar), `limit` 1..100000 (--limite, defecto local 100),
`sitemap` include/skip/only, `includeSubdomains` (false con --sin-subdominios).

## 2. Lectura

```text
URL → validar red/PDF → construir opciones → reserva → POST /scrape
```

| CLI | Campo JSON |
|---|---|
| --formatos | formats: markdown/html/rawHtml/links/images/json |
| --esquema / --prompt-json | objeto formats con type=json, schema y/o prompt |
| --pagina-completa | onlyMainContent=false (defecto true) |
| --esperar 0..60000 | waitFor, ms |
| --movil | mobile=true |
| --pais / --idiomas | location.country / location.languages |
| --edad-max | maxAge en ms (0 fuerza lectura nueva en Firecrawl) |
| --timeout-ms 1000..300000 | timeout |
| --pdf-paginas N | parsers=[{type:pdf,mode:fast,maxPages:N}] |

Se envía siempre el parser PDF con maxPages=1 si no se proporciona N; reserva una
página extra incluso en URL HTML para cubrir un PDF oculto. Un sufijo .pdf conocido
exige N explícito. JSON requiere --permitir-recargos. `summary` se normaliza si aparece
en fixtures/respuestas guardadas, pero no se solicita: tarifa no verificada.
`--sondear-red-no-admitida` permite repetir explícitamente el contrato medido de 403,
**sin probar en vivo** aquí. `--medir-saldo` observa delta global y no lo atribuye a
una solicitud ni lo usa como coste real.

## 3. Trabajos

Lote: `urls` deduplicadas, `ignoreInvalidURLs=true`, `maxConcurrency` opcional y opciones
de scrape al mismo nivel. Máximo propio 100; el máximo del proveedor no está verificado.
Rastreo: `url`, `limit` y `maxDiscoveryDepth` obligatorios; `scrapeOptions` anidado;
`includePaths`/`excludePaths`, `sitemap`, `crawlEntireDomain`, `allowSubdomains`, `delay`,
`maxConcurrency`. Por defecto excluye rutas terminadas en .pdf; el parser acota también
PDF ocultos. `--incluir-pdf` exige --pdf-paginas. No se habilitan enlaces externos.

Agente: solo --habilitar-agente, `prompt` ≤10000, `maxCredits` 1..200 obligatorio;
`urls`, `strictConstrainToURLs` (--solo-urls), `schema`, `effort` low/medium/high opcionales.
Probado en vivo en el smoke del 2026-10-15 con maxCredits 50: 3 artículos con URL y 0 créditos
consumidos según el saldo. El máximo 200 es propio; no es el máximo del proveedor.

GET de estado y DELETE usan ID validado. Paginación next solo por HTTPS al host
api.firecrawl.dev, máximo propio 50 respuestas. `completed` es el único terminal batch
verificado; crawl admite completed/failed/cancelled y agent completed/failed.

## 4. Superficie excluida

No se envían proxy, persistentSession, ignoreRobots booleano, pii, research ni webhooks.
No se implementan Extract, Deep Research, llmstxt ni versiones v0/v1.
No se solicitan question/highlights/audio/video/screenshot/rawBase64/changeTracking/
attributes/branding/product/menu/deterministicJson: forma de respuesta o cota no
verificada en esta implementación. No hay escape de parámetros JSON arbitrarios.

`--precio-credito` es opcional y vale 0.0038 USD/crédito por defecto (valoración estimada, no factura; Hobby mensual 19/5000, Fase 0 §3, 2026-10-15). `salud` y `saldo` sugieren según `planCredits` sin cambiarlo: véase [costes y límites](costes-y-limites.md#valoración-por-defecto-y-sugerencias).
