# Usar desde otro skill

## Índice

- [1. CLI y códigos](#1-cli-y-códigos)
- [2. JSON y persistencia](#2-json-y-persistencia)
- [3. Importación](#3-importación)

## 1. CLI y códigos

Usar un proceso separado: configurar() del común cambia estado global del intérprete.
La carpeta contiene su propia copia de buscadores_comun.py con COMUN.sha256; no depende
de otro skill instalado. La ficha TOML es declarativa; el consumidor aún debe integrarla.

```bash
python3 "$SKILL_DIR/scripts/firecrawl_helper.py" buscar 'hybrid retrieval documentation' \
  --n 10 --precio-credito 0.00083 --tope-creditos 20 --tope-total-usd 0.10 \
  --investigacion estudio-01 --salida ./fuentes --json
python3 "$SKILL_DIR/scripts/firecrawl_helper.py" citas --salida ./fuentes --json
python3 "$SKILL_DIR/scripts/firecrawl_helper.py" pendientes --salida ./fuentes --json
python3 "$SKILL_DIR/scripts/firecrawl_helper.py" reanudar ID_RESERVA --salida ./fuentes --json
```

| Código | Significado |
|---|---|
| 0 | Operación terminada; salud es diagnóstico y puede declarar clave ausente; búsqueda vacía válida |
| 1 | Error general/contrato; todas las lecturas fallaron; citas sin registros |
| 2 | Uso incorrecto o modo deshabilitado |
| 3 | Clave ausente, mal formada o rechazada |
| 4 | Tope por llamada o investigación agotado (USD o créditos) |
| 5 | Límite del proveedor 402/429 |
| 6 | Resultado desconocido o pendiente; no crear de nuevo automáticamente |

No añadir reintentos externos: buscar/leer ya hacen hasta dos; cada intento vuelve a
reservar. Los POST de creación no se repiten. `reanudar` y `cancelar` usan ID de reserva
persistido; `pendientes` también muestra ID remoto. El precio de una reserva se conserva
al reanudar. Mantén la misma salida e investigación; cancelar puede devolver 6.

## 2. JSON y persistencia

`--salida DIR` es obligatoria para resultados persistidos y reanudar; no para salud,
saldo, libro ni simulación. La salida guarda registros.jsonl y uso.jsonl; citas genera
Markdown y JSON fechados. Libro y caché privados están bajo FIRECRAWL_SEARCH_HOME o
~/.firecrawl-search. No mezclar investigaciones en una carpeta. --sin-cache evita caché
local de buscar; no sustituye --edad-max 0 para caché remota de lectura.

Buscar/leer/mapa y trabajos terminados con --json entregan el sobre común:
`skill`, `version`, `titulo`, `consulta`, `consultado`, `registros`, `fallos`, `coste`,
`cobertura`, `limites`; algunos añaden `detalle`. Trabajos pendientes entregan
`pendiente`, `id_reserva`, `trabajo_id`, `estado`, `avisos` sin registros todavía.
Simulación entrega el cuerpo y cotas; leer puede tener varias en una lista `simulacion`.
Saldo entrega remainingCredits, planCredits, billingPeriodStart/End, investigacion,
limites y opcional historico saneado sin apiKey. Salud JSON contiene diagnóstico;
libro/pendientes usan la salida del cliente común. Errores redactados van a stderr.
Comprobar código antes de interpretar stdout. No sumar el coste de cada registro.

```text
consumidor → CLI --json → registros con URL y texto_literal → cita literal
                       → respuesta_generada → contexto etiquetado
                       → coste del sobre → presupuesto de investigación
```

## 3. Importación

```python
import sys
from pathlib import Path
skill = Path('./firecrawl-search').resolve()
sys.path.insert(0, str(skill / 'scripts'))
import firecrawl_helper as F
import buscadores_comun as C
ses = C.Sesion(salida=Path('./fuentes'), precio_credito=0.00083,
               tope_total_creditos=20, tope_llamada_usd=0.05,
               tope_total_usd=0.10, investigacion='estudio-01')
prevision = F.buscar(ses, 'hybrid retrieval', simular=True, n=10)
# La llamada real, cuando esté autorizada, usa simular=False.
```

Exportados: cuerpo_busqueda/lectura/mapa/lote/rastreo/agente; normalizar_busqueda/pagina/
mapa/agente; buscar/leer/mapa/lote/rastrear/agente/saldo/reanudar. Los adaptadores deben
respetar las mismas validaciones, presupuesto y separación literal/generado.

La CLI usa `--precio-credito 0.0038` si se omite al crear una reserva (valoración estimada, no factura). Una sesión Python del común requiere pasar explícitamente `precio_credito=H.PRECIO_CREDITO_DEFECTO` o el valor elegido. `saldo` añade `valoracion_credito` con precio aplicado, defecto y sugerencia según `planCredits`; véase [costes](costes-y-limites.md#valoración-por-defecto-y-sugerencias). No sustituye el precio de la sesión.

La reserva guarda `precio_credito` y `fuente_precio_credito` antes del envío. `reanudar` y `cancelar`
usan ese precio histórico aunque se omita el flag o se pase otro: si difiere, se avisa por stderr y en
`cobertura.avisos` y se ignora para ese trabajo. Las operaciones nuevas usan el precio de su invocación.
La liberación y la liquidación sin coste confirmado consumen la cota histórica entera, sin revalorarla.
Para reservas antiguas sin precio guardado se conserva `cota_usd / cota_creditos`; una cota USD más
conservadora no permite reconstruir un precio inferior y mantiene esa proporción. No se reescriben las
filas antiguas. Si las cotas no permiten recuperar el precio, no se liquida un coste confirmado en créditos;
queda disponible la liberación por la cota histórica. En Python, `fuente_precio_credito` permite documentar
el origen del precio; la CLI distingue precio explícito y predeterminado del parser.
