# Método y recetas

## Índice

- [1. Elegir modalidad](#1-elegir-modalidad)
- [2. Recetas](#2-recetas)
- [3. Continuaciones](#3-continuaciones)

## 1. Elegir modalidad

```text
pregunta → buscar → revisar URL → leer → citas
sitio conocido → mapa → seleccionar URL → lote → sondeo → citas
sitio completo → rastrear con limit y maxDiscoveryDepth → sondeo → citas
```

Fuentes: [Search](https://docs.firecrawl.dev/features/search),
[Map](https://docs.firecrawl.dev/features/map), [Scrape](https://docs.firecrawl.dev/features/scrape),
[Crawl](https://docs.firecrawl.dev/features/crawl), [Batch](https://docs.firecrawl.dev/features/batch-scrape).
Lectura documental: 2026-10-15. Sin medición propia de relevancia ni velocidad.

## 2. Recetas

Ejecuta desde la carpeta del skill. Ajusta el precio estimado a tu contrato.

```bash
python3 scripts/firecrawl_helper.py buscar 'lanzamiento de cursos online' \
  --fuentes web,news --n 10 --por-fecha --desde 2026-10-01 --hasta 2026-10-14 \
  --precio-credito 0.00083 --tope-creditos 20 --salida ./noticias --simular --json
python3 scripts/firecrawl_helper.py mapa https://example.org \
  --buscar precios --limite 20 --precio-credito 0.00083 --salida ./sitio --json
python3 scripts/firecrawl_helper.py leer https://example.org/precios \
  --precio-credito 0.00083 --salida ./sitio --json
python3 scripts/firecrawl_helper.py lote https://example.org/a https://example.org/b \
  --concurrencia 2 --espera-s 60 --precio-credito 0.00083 --salida ./sitio --json
python3 scripts/firecrawl_helper.py rastrear https://example.org \
  --limite 5 --profundidad 1 --precio-credito 0.00083 --salida ./sitio --simular --json
python3 scripts/firecrawl_helper.py citas --salida ./sitio --json
```

| Caso | Modalidad y previsión |
|---|---|
| Noticias y web | Buscar: hasta 4 créditos con 10 por cada una de dos fuentes. `tbs` solo filtra web; inspeccionar las fechas de news |
| Imágenes | Buscar `--fuentes images`: 2 por 10; imagen y URL en referencias, sin inventar texto |
| Descubrir y leer | Mapa: 1; cada lectura ordinaria reserva 2 (1 base + margen para PDF oculto de 1 página) |
| Lista de dos URL ordinarias | Lote: reserva 4; el máximo local es 100 URL, no es un límite comprobado del proveedor |
| Sitio de hasta cinco páginas | Rastrear: reserva 10 por defecto; profundidad obligatoria y PDF explícitos excluidos |
| PDF conocido de hasta N páginas | Leer con `--pdf-paginas N`: reserva 1+N; el proveedor recibe maxPages=N |
| Extraer campos con JSON | Leer con esquema/prompt y `--permitir-recargos`: +4 por página; salida generada |

Los importes son cotas de reserva, salvo el coste fijo de mapa. Sin créditos informados,
la lectura se liquida por la cota completa, aunque el documento termine siendo HTML.
`--con-texto` está deshabilitado: primero descubre y luego fija la cota por URL.

## 3. Continuaciones

Conserva carpeta e identificador de investigación. `pendientes` lista reservas; `reanudar`
recibe el ID de reserva, no el ID remoto. `cancelar` pide DELETE y confirma mediante GET.
Un tiempo agotado o una respuesta perdida no permite volver a crear el trabajo.
Los resultados remotos duran 24 horas según la documentación; guardar los registros.
La relevancia e idioma se revisan fuente por fuente. Menos fuentes útiles se declara como
cobertura incompleta, sin llenar huecos con texto generado.
