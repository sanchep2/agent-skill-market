# Instalación y alta

## Índice

- [1. Instalar](#1-instalar)
- [2. Conectar](#2-conectar)
- [3. Diagnóstico](#3-diagnóstico)

## 1. Instalar

Copia la carpeta completa en la carpeta de skills del agente. Python ≥3.9, biblioteca
estándar; no requiere SDK, pip, navegador ni cuentas de redes sociales. Windows sin probar.
No se crean enlaces ni se modifica la configuración de otro agente automáticamente.

```bash
python3 scripts/firecrawl_helper.py --version
python3 scripts/firecrawl_helper.py salud
```

## 2. Conectar

Obtén la clave en [Firecrawl](https://www.firecrawl.dev/), con ayuda de
[la documentación](https://docs.firecrawl.dev/introduction). Lectura documental 2026-10-15.
Revisa el precio y límites de tu contrato sin activar recargas ni cambiar plan por defecto.

```text
panel → copiar clave → portapapeles / fichero privado → conectar → salud gratis
```

```bash
python3 scripts/firecrawl_helper.py conectar firecrawl
# Alternativa: fichero privado existente, nunca la clave en el argumento:
python3 scripts/firecrawl_helper.py conectar firecrawl --desde-fichero ./clave-privada.env
```

También admite FIRECRAWL_API_KEY en el entorno. Se guarda en ~/.firecrawl-search/claves.env
con permisos 0600 y carpeta 0700. FIRECRAWL_SEARCH_HOME cambia el directorio privado.
No imprimir la clave, no incluirla en chat, ejemplos reales, argv, registros ni repositorio.
Los ficheros de prueba solo contienen claves sintéticas aisladas.

## 3. Diagnóstico

Salud sin clave termina 0 y dice qué falta. Con clave usa GET /v2/team/credit-usage:
sonda gratuita verificada mediante dos lecturas sin cambio de saldo el 2026-10-15.
Un fallo transitorio da conclusión incierta; nunca afirmar validez por mera presencia.
Salud --en-vivo hace además una búsqueda limit=10 de 2 créditos: requiere
--precio-credito y presupuesto. No es necesario para instalar.

```bash
python3 scripts/firecrawl_helper.py saldo --historico --json
python3 scripts/firecrawl_helper.py libro --ver --json
```

saldo histórico es documentado, sin probar en vivo aquí. No expone apiKey del histórico.
La cuenta medida reportó 100000 créditos/mes; no garantiza el plan de quien lo instala.
Ante 401/403 de clave revocar/reconectar. Ante 402 detenerse; 429 respetar espera acotada.
Un 403 unsupported-site afecta a la URL; no reconectar la clave por ese caso.
Para presupuesto usar --precio-credito ajustado al contrato, siempre valoración estimada.
