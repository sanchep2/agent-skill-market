# Acceso oficial, cierres de 2026-2027 y archivos

Por qué el skill no usa la API oficial ni el RSS, qué cambiaría si pidieras acceso y qué hacer con Pushshift, PullPush,
volcados y Devvit. Fechas verificadas en el texto original de los anuncios el **7-oct-2026** (Arctic Shift `/posts/ids`,
`created_utc` 2026-09-30T17:37:11Z y 17:41:27Z).

## Table of Contents

1. [Calendario de cierres](#1-calendario-de-cierres)
2. [Qué funciona hoy sin credenciales](#2-qué-funciona-hoy-sin-credenciales)
3. [API oficial: aprobación, uso comercial y cuotas](#3-api-oficial-aprobación-uso-comercial-y-cuotas)
4. [Si algún día hay credenciales](#4-si-algún-día-hay-credenciales)
5. [Devvit, Reddit Answers y Reddit for Researchers](#5-devvit-reddit-answers-y-reddit-for-researchers)
6. [Pushshift, PullPush y volcados](#6-pushshift-pullpush-y-volcados)
7. [Decisiones que te tocan](#7-decisiones-que-te-tocan)

---

## 1. Calendario de cierres

```text
2026-09-30  anuncios en r/redditdev (1wubcvf) y r/modnews (1wubgvt)
2026-10-31  ── la Data API pública deja de aceptar solicitudes NUEVAS
2026-11-10  informe de progreso
2026-11-13  ── se retiran los feeds RSS
2026-11-30  cierra el registro del programa de incentivos de migración
2027-01-12  empieza a retirarse el acceso a apps/usuarios no registrados
2027-02-23  recordatorio
2027-03     ── fin del acceso público restante
```

Texto literal (r/redditdev, u/boat-botany, 2026-09-30T17:37:11Z):

> |**October 31, 2026**|New requests for public API access will no longer be accepted. |

Y en el mismo post:

> Starting January 12, 2027, we’ll begin removing API access for apps and users that haven’t registered or engaged with us.
> Remaining public API access will end in March 2027.

Texto literal (r/modnews, u/judy-funnie, 2026-09-30T17:41:27Z):

> …helping mods move RSS-based alerts to the Discord Relay Devvit app before RSS feeds are retired on November 13, […] and
> adding safeguards to Old Reddit by limiting access to logged-in mods and recent users.

Fuentes: <https://www.reddit.com/r/redditdev/comments/1wubcvf/>, <https://www.reddit.com/r/modnews/comments/1wubgvt/>. Esto
describe el acceso **público**; no prueba que los contratos comerciales de datos terminen en esas fechas.

---

## 2. Qué funciona hoy sin credenciales

| Vía | 7-oct-2026 | Después |
|---|---|---|
| `www.reddit.com/…/.json`, `api.reddit.com` | 403 | — |
| `oauth.reddit.com` sin token | 403 | — |
| old.reddit | 302 a login | Más restringido «en los próximos meses» |
| RSS (`/r/SUB/new/.rss`, `/comments/ID/.rss`) | 200 a ratos, 429 enseguida | Retirado el 13-nov-2026 |
| Arctic Shift (archivo vivo) | 200, ~11-26 s de retraso | Depende de su operador; recomprobar con `salud` |
| Redlib (espejos) | 200 en 3 instancias | Sin garantía; lista viva de instancias |

El script mira la fecha: a partir del 13-nov-2026 `salud` informa del RSS como retirado sin llamarlo.

---

## 3. API oficial: aprobación, uso comercial y cuotas

OFICIAL (consultado el 7-oct-2026):

- **Responsible Builder Policy** (actualizada 5-oct-2026,
  <https://support.reddithelp.com/hc/en-us/articles/42728983564564-Responsible-Builder-Policy>): aprobación explícita previa
  para cualquier acceso por API; uso comercial con autorización escrita; prohibido eludir límites; los agentes de IA están
  incluidos. «Investigar cualquier tema para una empresa» no debe etiquetarse como uso personal gratuito.
- **Data API Wiki** (11-may-2026): 100 peticiones/min por client ID OAuth para el acceso gratuito ELEGIBLE, promediadas en
  10 min; el tráfico sin OAuth se bloquea.
- **Data API Terms** (revisión 20-jul-2026, <https://redditinc.com/policies/data-api-terms>): uso comercial e investigación por
  encima de límites requieren acuerdo aparte; Reddit fija tarifas y puede revocar.
- Precio comercial: sin tarifa pública vigente (0,24 USD/1.000 llamadas fue el anuncio de 2023; sin verificar para 2026).
- Plazos de aprobación: testimonios de 2026 con 11 días (UNA) y más de 53 días sin respuesta (VARIAS); sin SLA público.

---

## 4. Si algún día hay credenciales

Solo con aprobación vigente y dentro de su alcance. Base `https://oauth.reddit.com`, token app-only con
`POST https://www.reddit.com/api/v1/access_token` (`grant_type=client_credentials`) y User-Agent real
(`python:mi-investigacion:v1.0 (by /u/TU_USUARIO)`, con tu usuario real).

| Endpoint | Para qué |
|---|---|
| `GET /search`, `/r/SUB/search` (`q`, `sort=new\|top\|relevance\|comments`, `t=hour…all`, `restrict_sr`) | Descubrir sin depender de índices externos |
| `GET /r/SUB/new` | Lo último publicado |
| `GET /comments/ID` (`sort`, `limit`, `depth`) | Árbol inicial con votos actuales |
| `GET /api/morechildren` (`link_id=t3_ID`, `children`, hasta 100) | Expandir `more`, UNA petición a la vez |

Cuidado: `limit=0` en PRAW `replace_more` borra los `more` sin leerlos; los listados se cortan en ~1.000 elementos; los IDs
nuevos de comentario llegan a 13 caracteres y no son cronológicos (anuncio 15-sep-2026, `1whal6a`): guardarlos como texto y
ordenar por `created_utc`. Este módulo NO está implementado en el script: se añadiría como fuente opcional si en el
futuro tienes credenciales aprobadas.

---

## 5. Devvit, Reddit Answers y Reddit for Researchers

- **Devvit** (OFICIAL): `searchPosts` con `query`, `sort` y `timeframe`, `subredditName` opcional; se ejecuta DENTRO de Reddit,
  con revisión de la app (~1 semana) y sin credenciales para un script externo. Que autorice un servicio de investigación
  externo: sin verificar.
- **Reddit Answers** (integrado en la búsqueda desde el 26-may-2026): síntesis con enlaces en la interfaz; sin API pública
  localizada. Sus respuestas no son citas.
- **Reddit for Researchers** (5-oct-2026): académico, no comercial, BigQuery, cinco años con **seis meses de retraso**. No sirve
  para actualidad ni para una empresa.

---

## 6. Pushshift, PullPush y volcados

| Vía | Estado | Uso |
|---|---|---|
| Pushshift | 403 sin token; solo moderadores aprobados y para moderar | No |
| PullPush (`api.pullpush.io`) | ~3,15 días de retraso; 429 «This website does not provide free scraping resources for agents» | No (sus condiciones excluyen agentes gratis) |
| Volcados Arctic Shift (Academic Torrents) | Hasta 2026-08; 74,6 GB/mes; licencia no especificada; páginas retiradas a petición de Reddit el 24-jul-2026 | Solo historia masiva, con decisión de almacenamiento y derechos |
| Wayback | CDX exacto funciona; capturas parciales | Rescate puntual de una URL |

---

## 7. Decisiones que te tocan

| Decisión | Contexto verificado | Default del skill |
|---|---|---|
| ¿Pedir acceso no comercial a la API? | Solicitudes hasta el 31-oct-2026; acceso público hasta marzo de 2027; el uso de una empresa difícilmente encaja como no comercial; una sola solicitud por caso de uso, sin enmascarar el uso | No usa la API |
| ¿Contratar acceso comercial? | Sin precio público; aprobación lenta | — |
| ¿Probar Tavily, Parallel, Linkup, SerpAPI, Kagi? | Documentados, sin prueba en Reddit | Fuentes actuales |
| ¿Montar una instancia Redlib propia? | Las públicas no tienen SLA | Instancias públicas |
