# Lectura de hilos y cobertura

Cómo `leer` y `lote` obtienen el texto original, qué significan sus campos y cuándo una lectura es completa. Todo lo marcado
PROBADO se midió el 7-oct-2026 con el hilo de control `1wubcvf` (r/redditdev) y los tests offline del script.

## Table of Contents

1. [La cadena de lectura](#1-la-cadena-de-lectura)
2. [Campos del JSON de un hilo](#2-campos-del-json-de-un-hilo)
3. [Texto: captura frente a versión actual](#3-texto-captura-frente-a-versión-actual)
4. [Votos: captura frente a ahora](#4-votos-captura-frente-a-ahora)
5. [Cobertura y denominadores](#5-cobertura-y-denominadores)
6. [Orden de lectura de un hilo](#6-orden-de-lectura-de-un-hilo)
7. [Lote y corpus](#7-lote-y-corpus)
8. [Errores de lectura y respuesta](#8-errores-de-lectura-y-respuesta)

---

## 1. La cadena de lectura

```text
leer <ID | t3_ID | URL reddit.com | redd.it | URL de espejo>
  │
  ├─1 Arctic Shift /posts/ids ─► post (texto markdown de la captura, created_utc, votos de la captura)
  │   Arctic Shift /comments/tree?link_id=ID&limit=9999 ─► árbol con replies; nodos «more» ─► /comments/ids
  │
  ├─2 Redlib (safereddit → artemislena → synth), identidad por og:url: si hay Arctic → UNIÓN por ID: votos ACTUALES,
  │     texto actual de los editados, comentarios que faltan en el archivo y retirados ([deleted]/[removed])
  │                                              si NO hay Arctic: post + árbol visible desde el HTML (siempre «parcial»)
  │
  ├─3 sin texto todavía: Brave LLM Context ─► fragmentos SOLO de la fuente con el mismo ID
  └─4 sin fragmentos: Wayback CDX exacto ─► última captura 200 que no sea login
```

PROBADO: Arctic 126 comentarios del hilo de control en 3 s y Redlib uno más (`pd2v83h`) que el archivo no tenía: la unión da
127; Redlib 3/3 instancias con el hilo; respaldo Redlib-solo con ≥ 100 comentarios y autores (`test_sin_arctic_cae_a_redlib`).
Cada vía comprueba la identidad: post por ID exacto, comentarios por `link_id` y permalink, Redlib por `og:url`, Wayback por la
URL original de la captura.

---

## 2. Campos del JSON de un hilo

`<salida>/hilos/<id>.json`:

| Campo | Contenido |
|---|---|
| `post.titulo`, `post.autor`, `post.subreddit` | Del archivo o del espejo |
| `post.fecha` | ISO 8601 en hora local con desfase (o la zona de `REDDIT_SEARCH_TZ`) a partir de `created_utc` |
| `post.cuerpo` | Texto literal (markdown de Arctic; texto renderizado si vino de Redlib) |
| `post.votos`, `post.votos_fuente`, `post.votos_capturados` | Votos y de dónde/cuándo salen; `votos_arctic` conserva el de la captura |
| `post.num_comentarios`, `post.num_comentarios_actual` | Contador de la captura y recuento actual del espejo |
| `comentarios[].id`, `.padre`, `.padre_tipo` | ID del comentario y de su padre; `padre_tipo` = `t3` (raíz, el padre es el post), `t1` (otro comentario) o `?` (sin prefijo reconocible) |
| `comentarios[].comunidad`, `.created_utc`, `.fecha` | Comunidad conocida de la pieza (`""` = desconocida) y su creación (epoch e ISO en hora local) |
| `comentarios[].profundidad` | 0 = raíz |
| `comentarios[].cuerpo`, `.cuerpo_fuente`, `.cuerpo_capturado` | Texto entregable; origen; texto antiguo si se editó |
| `comentarios[].votos`, `.votos_fuente` | `null` = oculto o sin dato (nunca 0 inventado) |
| `comentarios[].es_op`, `.es_bot`, `.distinguido`, `.editado` | Marcas para valorar el testimonio |
| `comentarios[].retirado` | `true` si hoy está borrado o retirado: se entrega el tombstone, nunca el texto archivado |
| `comentarios[].url` | Permalink del comentario (para citar) |
| `cobertura.estado` | `completa` · `parcial` · `fragmentos` · `sin_texto` |
| `cobertura.comentarios_leidos`, `.con_texto`, `.declarados`, `.intentos_fallidos` | Denominadores y fallos |
| `cobertura.pendientes`, `.completitud_verificada` | IDs «more» sin resolver; `true` solo si se cumplen las 3 condiciones de §5 |
| `cobertura.motivos_parcial` | Lista legible de por qué no es completa (vacía si lo es) |
| `comentarios[].identidad_verificada`, `.representacion`, `.redactado`, `.texto_reparado` | Ancla al hilo comprobada; `markdown` (Arctic) o `texto_renderizado` (Redlib); contenía una clave (sustituida por [CLAVE]); UTF-8 reparado |
| `cobertura.descartados_identidad`, `.huerfanos`, `.conflictos`, `.sin_identidad` | Comentarios de otro hilo o de otra comunidad descartados; sin padre conocido (`profundidad: null`); piezas que Arctic y Redlib no reconocen como la misma (autor, creación, padre tipado o comunidad incompatibles: se conserva Arctic) |
| `cobertura.duplicados_incompatibles` | Copias del mismo ID que no son la misma pieza: el ID entero se descarta |
| `cobertura.more_sin_ids`, `.more_ids_invalidos`, `.avisos_more`, `.more_count_invalido` | Nodos «more» sin IDs expandibles, con IDs inválidos, con recuento mayor que lo obtenido, o con `count` ausente o inválido (nunca vale 0 implícito) |
| `cobertura.votos_no_verificados`, `.descartados_datos` | Votos de Redlib sin enlace propio verificado (no sustituyen a los archivados); registros con tipos inválidos omitidos |
| `fragmentos[]` | Solo si no hubo texto: trozos con su URL; no son comentarios |
| `leido` | Momento de la lectura (hora local) |

---

## 3. Texto: captura frente a versión actual

Arctic Shift guarda el texto **del momento de la captura** (segundos tras publicarse). Si el autor lo edita, el archivo no
cambia el cuerpo; solo marca `_meta.is_edited`.

```text
pd1pln5 (u/shiruken)
  Arctic (captura 17:46:57 UTC):  ![gif](giphy|lD76yTC5zxZPG)
  Redlib (ahora, editado 18:05):  Disappointed to see this finally happen but I can't say I'm surprised. …
  leer entrega:                   cuerpo = texto de Redlib · cuerpo_fuente = redlib:safereddit.com
                                  cuerpo_capturado = el gif · editado = true
```

Regla del script: si Arctic o Redlib muestran una marca de retirada (`[deleted]`, `[removed]`, `[ Removed by Reddit ]`,
`[deleted by user]`…) o el post trae `removed_by_category`, la pieza queda `retirado` y el texto archivado se descarta en
todas las salidas (JSON, Markdown y citas). Manda el estado de HOY: si el archivo marcó el post como retirado al
capturarlo pero Redlib lo muestra hoy (mismo autor declarado y misma creación), se entrega el texto de hoy, nunca el
archivado (`retirado_en_archivo: true`); sin esa confirmación, ninguna pieza retirada recupera texto en la unión;
las retiradas por ID se aplican siempre, también las de contenedores descartados por identidad o comunidad. Si el comentario
está marcado como editado (en Arctic o en Redlib) y el texto de Redlib difiere, manda Redlib, pero solo si es la MISMA pieza:
autor, creación (al segundo), padre tipado y comunidad compatibles. Si algo no cuadra, no se fusiona (se conserva Arctic y se
cuenta en `conflictos`). Si la página de Redlib declara otra comunidad que el hilo, no aporta texto, votos ni comentarios. En los NO editados manda Arctic, porque conserva el markdown con las URL de los enlaces (Redlib deja solo el texto del
enlace). El test `test_redlib_cuerpo_literal_igual_que_arctic` comprueba que, sin ediciones, ambos coinciden palabra por
palabra (salvo escapes de markdown como `\>` y medios incrustados).

Al citar un comentario editado, menciónalo («[editado]» ya aparece en la línea de metadatos).

---

## 4. Votos: captura frente a ahora

| Dónde | Post de control | `pd1pln5` |
|---|---|---|
| Arctic (2.ª captura, ~36 h) | 6 | 30 |
| Redlib (7-oct-2026) | 11 | 33 |

- `descubrir` usa los votos de Arctic (rápido, en lote). En hilos de menos de ~36 h son de la primera captura: 1 voto, 0
  comentarios. El índice los marca con «?» (`votos_provisionales`).
- `leer` toma los de Redlib y lo dice en `votos_fuente`. Si Redlib no responde, quedan los de Arctic con `votos_capturados`.
- Los votos sirven para triage, no para decidir qué es verdad (Glenski et al., 2015: los votos iniciales influyen en los
  posteriores).

---

## 5. Cobertura y denominadores

```text
declarados = max(num_comments de Arctic, comentarios contados en Redlib)
leidos     = comentarios únicos con ID (unión Arctic + Redlib; incluye [deleted]/[removed])
con_texto  = leidos con cuerpo real
estado     = completa  si Arctic leído Y 0 «more» pendientes Y leidos ≥ declarados Y todos los contadores de §2 a 0:
                       huérfanos, sin identidad, descartados (identidad o datos), more sin IDs / IDs inválidos /
                       recuento no comprobado / count inválido, duplicados incompatibles, votos no verificados
                       y conflictos                                             (completitud_verificada = true)
             parcial   si hay post pero falla cualquiera de ellas, si solo hubo Redlib o si el árbol de Arctic no
                       respondió: el post ya leído se conserva (motivos_parcial lo dice)
             fragmentos / sin_texto  si no hubo árbol
```

- `num_comments` cuenta borrados y cambia con el tiempo: es un indicio, no un censo. En el control, Arctic decía 85 y se
  leyeron 126.
- «Completa» significa **todo lo accesible**, no lo borrado ni lo de comunidades privadas o en cuarentena.
- Si hay nodos `more` que no se pudieron expandir, el aviso queda en `indice/corpus.avisos`. Los pendientes y los avisos
  de `more` se calculan tras la unión con Redlib: un comentario que trae Redlib ya no cuenta como pendiente.

### Copias del mismo ID y comunidad

```text
varias copias de un ID ─► ¿misma pieza? (autor salvo borrado, creación, padre tipado, comunidad)
                            ├─ no ─► ID descartado entero ─► duplicados_incompatibles (parcial)
                            └─ sí ─► la RETIRADA manda sobre la viva; si no, la primera recibida
                                     + comunidad/creación que solo traiga otra copia (en una copia de la elegida)
hilo sin comunidad en el post ─► una sola comunidad en sus comentarios ─► pasa al post (y a sus URL)
                               └► varias ─► los comentarios que declaran comunidad se excluyen (descartados_identidad)
página Redlib ─► comunidad = og/canonical/metadato o, sin ellos, la única de sus enlaces propios
               └► distinta de la del hilo ─► conflicto; solo se aplican sus retiradas por ID
```

Una copia retirada del post cuyos IDs (`name`, permalink) son coherentes pero cuya comunidad contradice se admite como
retirada sin comunidad: retira el post igualmente. Con IDs contrarios no se rescata.

---

## 6. Orden de lectura de un hilo

1. Post y sus ediciones; distinguir relato, pregunta, anuncio y sátira.
2. `--orden votos`: primeros comentarios pertinentes, sin dar nada por solución todavía.
3. `--orden arbol`: respuestas a esos comentarios; las correcciones cambian el sentido.
4. Intervenciones del OP (`[OP]`): confirman o descartan lo sugerido. PROBADO (método §2.6): «I have ruled that out!».
5. `--orden fecha`: seguimientos y novedades.
6. Bots fuera del testimonio; moderadores (`[moderator]`) explican reglas, no rendimiento.

```bash
python3 reddit_helper.py leer 1wubcvf --orden votos --max 15      # lo más votado
python3 reddit_helper.py leer 1wubcvf --orden fecha --max 15      # lo último
python3 reddit_helper.py leer 1wubcvf --json | python3 -c 'import json,sys; d=json.load(sys.stdin); print([c["autor"] for c in d["comentarios"] if c["es_op"]])'
```

---

## 7. Lote y corpus

```bash
python3 reddit_helper.py lote reddit-salida/<carpeta>/indice.json --top 15 --solo-ventana --min-relevancia 0.5
python3 reddit_helper.py lote lista.txt --pausa 2          # una URL o ID por línea; # = comentario
cat ids.txt | python3 reddit_helper.py lote -              # desde stdin
```

- Lee en serie con pausa (1 s por defecto) por cortesía con Arctic y Redlib.
- Escribe `corpus.json` (todo) y `corpus.md` (citas ordenadas por votos, con metadatos) en la carpeta del índice.
- `citas corpus.json --buscar "regex" --min-votos N` devuelve párrafos literales; excluye bots por defecto.

```python
from reddit_helper import citas
import json
corpus = json.load(open("reddit-salida/qrevo/corpus.json"))
originales = {c["url"]: c["cuerpo"] for h in corpus["hilos"] for c in h["comentarios"]}
originales.update({h["url"]: h["post"]["cuerpo"] for h in corpus["hilos"] if h.get("post")})
for c in citas(corpus, r"mop|fregona", min_votos=3):
    assert c["texto"] in originales[c["url"]]   # literal: trozo exacto del original de ESA URL
    print(c["texto"][:80], "—", c["autor"], c["fecha"], c["votos"])
```

---

## 8. Errores de lectura y respuesta

| Salida | Significado | Acción |
|---|---|---|
| `Arctic Shift no tiene el post` | ID inexistente, privado o en cuarentena | Comprobar el ID; leer con Redlib (lo hace solo) |
| `redlib: … sin hilo (desafío antibot…)` | Anubis o caída | Normal; si Arctic leyó, solo se pierden los votos actuales |
| `cobertura parcial` | Faltan > 10 % | Citar con la etiqueta; repetir más tarde si importa |
| `fragmentos` | Solo Brave LLM o Wayback | Citar como «fragmento», sin votos por comentario |
| `sin_texto` (exit 4) | Nada legible | Listar el hilo como no leído; no inventar su contenido |
| `no reconozco un hilo` | URL de perfil, índice o wiki | Pasar una URL `/r/<sub>/comments/<id>/` |
