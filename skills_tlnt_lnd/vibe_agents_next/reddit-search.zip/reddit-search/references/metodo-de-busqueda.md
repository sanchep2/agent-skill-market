# Método de búsqueda: exprimir Reddit sobre cualquier tema

Basado en más de 60 búsquedas medidas el 7-oct-2026 (temas técnicos, de consumo, de negocio y locales) y en las pruebas en
vivo de este skill. Lo PROBADO lleva su prueba; lo demás es propuesta operativa.

## Table of Contents

1. [Antes de buscar: fijar la pregunta](#1-antes-de-buscar-fijar-la-pregunta)
2. [Mapa de subreddits](#2-mapa-de-subreddits)
3. [Consultas como escriben los redditors](#3-consultas-como-escriben-los-redditors)
4. [Ventanas de tiempo y recencia](#4-ventanas-de-tiempo-y-recencia)
5. [Cobertura: cuántas rondas y cuándo parar](#5-cobertura-cuántas-rondas-y-cuándo-parar)
6. [Idioma, país y traducciones](#6-idioma-país-y-traducciones)
7. [Recetas por tipo de tema](#7-recetas-por-tipo-de-tema)
8. [Errores de método frecuentes](#8-errores-de-método-frecuentes)

---

## 1. Antes de buscar: fijar la pregunta

Escribe en una línea, antes de la primera llamada:

```text
PREGUNTA:  qué quiero saber (afirmaciones concretas, no «qué opina la gente»)
CONTEXTO:  producto/versión/modelo, país/ciudad, idioma, perfil (usuario, comprador, profesional)
VENTANA:   d (incidente) · w (software, disponibilidad) · m (uso, mercado) · y/todo (antecedentes, durabilidad)
CORTE:     fecha y hora de ejecución, en hora local con su desfase (date)
SALIDA:    citas literales + índice + cobertura (y análisis solo si se pide)
```

Separa **posts nuevos** de **comentarios nuevos en posts viejos**: un hilo de 2025 con respuestas de esta semana también es
actualidad, pero no es «un post de esta semana». `leer` da la fecha de cada comentario.

---

## 2. Mapa de subreddits

Nunca inventes comunidades por intuición: sácalas de URL reales.

```text
1. descubrir "<tema>" --ventana todo           → mira la columna «Sub» del índice
2. descubrir "<problema en palabras del usuario>" --ventana m
3. Lee 1-2 hilos de las comunidades que se repiten: reglas, «ask in r/X», crossposts → comunidades vecinas
4. Rellena las casillas y repite descubrir con --sub en cada una
```

| Casilla | Ejemplo (aspiradora robot) | Ejemplo (CRM pyme) |
|---|---|---|
| Categoría | r/RobotVacuums | r/CRM |
| Marca/producto | r/Roborock, r/Dreame | r/hubspot, r/salesforce |
| Tarea/problema | r/CleaningTips | r/sales, r/smallbusiness |
| Profesión que hace el trabajo | r/homeautomation | r/CustomerSuccess, r/agency |
| Compra/durabilidad | r/BuyItForLife | r/SaaS |
| Local | r/MexicoFinanciero, r/askspain | r/mexico, r/Entrepreneur |

PROBADO (método §4): las búsquedas de churn descubrieron r/CustomerSuccess y r/agency además de r/CRM; las técnicas,
r/vectordatabase y r/Rag. Objetivo práctico: 5-12 comunidades pertinentes en una investigación profunda. Una especializada no
es por ello independiente: r/WhichCRM y los megathreads de marketplace están llenos de oferta comercial.

---

## 3. Consultas como escriben los redditors

Una consulta = **ancla temática + señal de intención**. Sin ancla, el lenguaje coloquial trae ruido: `grinder "anyone else"`
devolvió cannabis y videojuegos; `"espresso grinder" "anyone else"` devolvió r/espresso (PROBADO).

| Busco | Vocabulario (EN / ES) | Ejemplo para `descubrir` |
|---|---|---|
| Síntoma, incidente | anyone else, stopped working, keeps failing · me pasa, dejó de funcionar | `"Roborock S8" "anyone else" mop` |
| Diagnóstico técnico | I tried, workaround, fixed, mensaje de error exacto | `pgvector "I tried" slow query` |
| Qué funcionó | what worked, finally fixed, turned out · lo resolví | `uv lockfile "what worked"` |
| Cambio de herramienta | switched from, migrated, regret, cancelled · me cambié a, volví a | `CRM "switched from" hubspot regret` |
| Uso real y durabilidad | after 6 months, long term, broke, repair | `"Eufy E25" "after 6 months"` |
| Evidencia adversa | didn't work, overrated, returned, not worth · no funciona, no lo recomiendo | `"<producto>" "didn't work"` |
| Mercado, disposición a pagar | too expensive, paying for, still using spreadsheets, looking for alternative | `bookkeeping "still using spreadsheets"` |
| Local | me cobraron, anualidad, nómina + nombre de la comunidad | `MexicoFinanciero "me cobraron" comisión` |

Reglas:

- Lee ~5 hilos antes de fijar el léxico: la gente llama a las cosas distinto que el fabricante.
- Si una frase da 0, cambia de sinónimo, de síntoma o pon el subreddit como término; **0 resultados no es «no hay casos»**.
- «[Solved]», «PSA», «Update» son pistas, no pruebas (en r/msp «PSA» resultó ser un tipo de software).
- La gramática nativa de Reddit (`subreddit:`, `title:`, `selftext:`, `flair:`) es de la búsqueda de Reddit, no de Brave ni
  de Firecrawl: no la mezcles en `descubrir`.

---

## 4. Ventanas de tiempo y recencia

```text
            ┌── d  (24 h) ─ incidentes, caídas, lanzamientos del día
--ventana ──┼── w  (7 d)  ─ por defecto, con m
            ├── m  (31 d) ─ uso, comparativas, mercado
            ├── y  (366 d) ─ antecedentes, durabilidad
            └── todo ───── mapa de comunidades, historia
El corte lo aplica el script con created_utc verificado (no el buscador).
```

- Por defecto `--ventana w,m`: el índice pone primero lo que está dentro de la ventana MÁS AMPLIA pedida y ordenado por fecha
  (o `--orden relevancia|votos`).
- `--ventana d` para cerrar: ¿ha pasado algo hoy que cambie la conclusión?
- Un hilo viejo y decisivo se relee con `leer` para ver comentarios nuevos (`--orden fecha`).
- La fecha de rastreo de un buscador no convierte un consejo viejo en actual.

---

## 5. Cobertura: cuántas rondas y cuándo parar

| Profundidad | Consultas | Subreddits | Hilos leídos | Uso |
|---|---|---|---|---|
| Rápida | 2-3 | 0-2 | 5-8 | Pregunta puntual |
| Normal | 4-6 | 3-6 | 10-20 | Por defecto |
| Profunda | 8-12 | 6-12 | 25-40 | Estudio de mercado o de producto |

Criterio de cierre (operativo, no saturación científica): se cubrieron las casillas comunidad × intención × ventana, se hizo
la pasada de disenso y la de novedades, y **dos rondas seguidas no aportaron IDs con afirmaciones nuevas**. Anota en la entrega
lo que quedó sin cubrir.

PROBADO: las fuentes se complementan. En una prueba técnica, Brave, Firecrawl y Perplexity dieron 8, 8 y 39 IDs sin ninguno
en común; en otra, Firecrawl y Perplexity coincidieron en 3-10 de 20. En la verificación de este skill, `descubrir` reunió 92-94
hilos únicos por tema en 24-35 s. Más IDs no es más evidencia: el triage elimina lo ajeno.

---

## 6. Idioma, país y traducciones

- Busca en el idioma de la comunidad. Para México, España o Latinoamérica: español + nombre de la comunidad local.
- `"heat pump" Mexico` trajo **New Mexico**; `"bomba de calor" México` trajo posts alemanes y daneses traducidos
  automáticamente (`?tl=es-419`) (PROBADO). El script normaliza la URL al ID: la cita sale del original.
- Si traduces una cita para el usuario, la traducción va aparte y marcada; la cita literal queda en su idioma.

---

## 7. Recetas por tipo de tema

```bash
H="$SKILL_DIR/scripts/reddit_helper.py"   # SKILL_DIR = carpeta de este skill
# Técnico: error, versión, «I tried»
python3 "$H" descubrir '"uv sync" error lockfile' --ventana w,m --sub Python --sub learnpython
# Consumo: modelo + uso real + adverso
python3 "$H" descubrir '"Roborock Qrevo" long term' --ventana m,y --sub RobotVacuums --sub Roborock
python3 "$H" descubrir '"Roborock Qrevo" "didn'"'"'t work"' --ventana m,y
# Negocio / mercado: fricción y gasto, desde quien hace el trabajo
python3 "$H" descubrir 'invoicing "still using spreadsheets"' --ventana m --sub smallbusiness --sub Bookkeeping
# Local
python3 "$H" descubrir 'comisión tarjeta "me cobraron"' --ventana m,y --sub MexicoFinanciero
```

```python
# Varias consultas, un solo corpus (deduplicado por ID)
import os, sys; from pathlib import Path
sys.path.insert(0, str(Path(os.environ["SKILL_DIR"]) / "scripts"))
from reddit_helper import RedditHelper
h = RedditHelper()
ids = []
for q in ['"Roborock Qrevo" long term', '"Roborock Qrevo" problem', '"Roborock Qrevo" vs dreame']:
    ix = h.descubrir(q, ventanas=["m", "y"], subs=["RobotVacuums"])
    ids += [x["id"] for x in ix["hilos"] if x["relevancia"] >= 0.5 and x["id"] not in ids][:8]
corpus = h.lote(ids, Path("reddit-salida/qrevo"))
```

---

## 8. Errores de método frecuentes

| Error | Corrección |
|---|---|
| Una sola consulta genérica | 4-6 consultas por intención (tabla §3) |
| Fiarse del filtro de fecha del buscador | `fecha_verificada` del índice; la columna «Ventana» |
| «Más reciente = más relevante» | Ordenar por relevancia dentro de la ventana y leer |
| Solo comunidades de la marca | Casillas de tarea, profesión, compra y local |
| Contar hilos como personas | Contar autores distintos y casos, agrupar crossposts |
| Parar al primer «solved» | Leer las respuestas del OP: a veces lo descarta («I have ruled that out!», r/Rag) |
| Buscar solo posts del mes | Releer hilos viejos clave con `--orden fecha` |
