# Fuentes y endpoints: qué usar para qué (verificado el 7 y el 8-oct-2026)

Cada afirmación lleva su grado: **PROBADO** (ejecutado y con crudo, `--guardar-crudo`), **OFICIAL** (documentación del proveedor consultada el
7-oct-2026; precios y altas re-verificados el 8-oct-2026) o **sin verificar**. Las medidas proceden de la verificación en
vivo de este skill (más de 300 pruebas el 7-oct-2026).

## Table of Contents

1. [Mapa de fuentes](#1-mapa-de-fuentes)
2. [Brave Search API](#2-brave-search-api)
3. [Perplexity Search API](#3-perplexity-search-api)
4. [Firecrawl Search](#4-firecrawl-search)
5. [You.com MCP gratuito](#5-youcom-mcp-gratuito)
6. [Arctic Shift](#6-arctic-shift)
7. [Redlib](#7-redlib)
8. [Wayback Machine](#8-wayback-machine)
9. [Buscador y lector propios del agente](#9-buscador-y-lector-propios-del-agente)
10. [Fuentes descartadas y por qué](#10-fuentes-descartadas-y-por-qué)
11. [Errores y cómo los trata el script](#11-errores-y-cómo-los-trata-el-script)
12. [Candidatos sin probar](#12-candidatos-sin-probar)
13. [Modo base y modo experto: conectar cada clave](#13-modo-base-y-modo-experto-conectar-cada-clave)

---

## 1. Mapa de fuentes

```text
                       DESCUBRIR (URL)                 FECHAR / LEER (texto original)
                ┌──────────────────────────┐        ┌──────────────────────────────┐
  experto       │ Brave web   (pd|pw|pm|py)│        │ Brave LLM Context (fragmentos)│
                │ Perplexity  /search      │        └──────────────────────────────┘
                │ Firecrawl   /v2/search   │        ┌──────────────────────────────┐
  base          │ You.com MCP (100/día)    │  IDs   │ Arctic Shift posts/ids, tree │
                │ Arctic Shift (por sub)   │ ─────► │ Redlib (votos/texto actuales)│
  base (agente) │ buscador web del agente  │        │ Wayback CDX (captura exacta) │
                └──────────────────────────┘        └──────────────────────────────┘
  descartadas: Exa (0 reddit.com) · Firecrawl scrape (403) · Jina (bloqueo con 200) · PullPush · Pushshift · RSS (13-nov)
```

| Fuente | Descubre | Lee | Fecha fiable | Coste | Estado 7-oct-2026 |
|---|---|---|---|---|---|
| Brave web | Sí | Fragmentos + `qa` | No | 5 USD/1.000 | PROBADO |
| Brave LLM Context | Sí | Fragmentos largos (hasta 47 por hilo) | No | 5 USD/1.000 | PROBADO |
| Perplexity `/search` | Sí (20/20 de reddit.com) | Snippets REFORMULADOS | `date` orientativa | 5 USD/1.000 (fast 1) | PROBADO |
| Firecrawl `/v2/search` | Sí (10/10) | No | No | 2 créditos/10 | PROBADO |
| You.com MCP | Sí | Highlights literales | No | Gratis, 100/día | PROBADO |
| Arctic Shift | Por subreddit | Post + árbol completo | **Sí** (`created_utc`) | Gratis, límites dinámicos | PROBADO |
| Redlib | No | Hilo visible + votos actuales | **Sí** (title UTC) | Gratis | PROBADO (3 instancias) |
| Wayback | No | Captura | Fecha de captura | Gratis | PROBADO (CDX exacto) |

---

## 2. Brave Search API

**OFICIAL + PROBADO.** `GET https://api.search.brave.com/res/v1/web/search`, cabecera `X-Subscription-Token`.

| Parámetro | Uso en el skill |
|---|---|
| `q` | `site:reddit.com <tema>`; con subreddit: `site:reddit.com <Sub> <tema>` (nombre como término) |
| `freshness` | `pd`, `pw`, `pm`, `py` o `AAAA-MM-DDtoAAAA-MM-DD` (edad atribuida a la página, no al post) |
| `count` | hasta 20; `offset` = número de página (hasta 9) |
| `extra_snippets=true` | hasta 5 fragmentos extra (observados ≤ 4) |
| `result_filter=web,discussions` | `discussions` vino `null` en 31/31 pruebas: el valor está en `web.results` |

Hallazgos que cambian el diseño:

- **`web.results[].qa`** (PROBADO): `qa.question` trae el post entero (4.341 caracteres en la prueba) y
  `qa.answer.text` una respuesta con `upvoteCount`, sin autor ni permalink. El script los añade como «POST:» y «RESPUESTA:» al
  fragmento de triage. No son citables: falta autor del comentario.
- **`site:reddit.com/r/SUB`** devolvió 0 en varias comunidades (por ejemplo `r/Python`) y funcionó en `r/espresso`. La causa no está
  verificada; el nombre como término sí recuperó resultados de esa comunidad. El script lo hace así y filtra por URL.
- **Goggles inline** (`goggles="$discard\n$boost=10,site=reddit.com"`) reordena, no amplía el índice ni hace estricta la
  fecha (devolvió 2022-2025 con `pw`).

**LLM Context** — `GET /res/v1/llm/context` con `q`, `count`, `maximum_number_of_tokens` (≤ 32.768 total, ≤ 8.192 por URL),
`freshness`, `enable_source_metadata`. Devuelve `grounding.generic[].{url,snippets}`. PROBADO: 47 fragmentos / 14.426
caracteres de un hilo frente a 4 en web. Es una búsqueda, no un fetch: con la URL como `q` devolvió otros hilos. El script
solo acepta fragmentos cuyo ID coincide.

```bash
python3 reddit_helper.py brave "uv lockfile slow" 10 --ventana w     # impresión rápida (modo experto)
```

---

## 3. Perplexity Search API

**OFICIAL + PROBADO.** `POST https://api.perplexity.ai/search`, `Authorization: Bearer`.

```json
{"query": "robot vacuum pet hair", "search_domain_filter": ["reddit.com"], "search_recency_filter": "week",
 "max_results": 20, "max_tokens_per_page": 1024}
```

- 20/20 resultados de reddit.com con `url`, `title`, `date`, `last_updated`, `snippet` (PROBADO 7-oct-2026).
- `search_recency_filter`: `day|week|month|year`. Fechas absolutas: `search_after_date_filter="09/30/2026"` y
  `search_before_date_filter` (PROBADO; `MM/DD/AAAA`).
- **`snippet` está reformulado** (PROBADO): no es cita. Tampoco `fetch_url` de su Agent API.
- **Sonar**: soporte terminado el 27-sep-2026 (OFICIAL, guía de migración); `sonar-deep-research` gastó 0,375 USD y no dio
  ninguna URL. Se usa `/search`.
- `query` con una URL devuelve OTROS hilos: no es un lector.
- Hasta 5 consultas por solicitud, pero `max_results` es total, no por consulta.

---

## 4. Firecrawl Search

**OFICIAL + PROBADO.** `POST https://api.firecrawl.dev/v2/search`, `Authorization: Bearer`.

```json
{"query": "site:reddit.com robot vacuum pet hair", "limit": 20, "sources": ["web"], "tbs": "qdr:w"}
```

- `tbs`: `qdr:h|d|w|m|y`, rango `cdr:1,cd_min:MM/DD/YYYY,cd_max:MM/DD/YYYY`, `sbd:1`. Solo aplica a `sources=["web"]`, no a
  `news` ni `images` (OFICIAL). `sbd:1` no dio orden cronológico estricto (PROBADO).
- Devuelve título, URL y `description` con edad, votos y nº de comentarios en texto («7 days ago · 33 votes»), sin
  timestamp estructurado. Incluye índices de subreddit y paginaciones: el script los descarta.
- Coste: 2 créditos por cada 10 resultados (PROBADO, `creditsUsed`). 429 cerca de 10 peticiones/min en cuentas compartidas.
- **`/v2/scrape` de reddit.com da 403** «we do not support this site»; `scrapeOptions` dentro de search no trae markdown de
  Reddit; `/v2/extract` y `/v1/deep-research` están deprecados (PROBADO).

---

## 5. You.com MCP gratuito

**OFICIAL + PROBADO.** `POST https://api.you.com/mcp?profile=free`, JSON-RPC 2.0 sobre HTTP con respuesta SSE, sin clave y
sin sesión. Cabecera obligatoria `Accept: application/json, text/event-stream` (sin ella, 406).

```json
{"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "you-search", "arguments":
  {"query": "site:reddit.com robot vacuum", "freshness": "week", "count": 10, "extraction": "highlights"}}}
```

- Límite OFICIAL: 100 consultas al día con `profile=free`, sin clave. PROBADO: se agotó el 7-oct-2026 tras varios agentes en
  paralelo → HTTP 402 con «Search API call failed: Free tier limit exceeded. Please upgrade to continue.». El script la marca
  como FALLO en `indice.json` (no como 0 resultados), pone la fuente en pausa hasta las 00:00 UTC siguientes y sigue con el
  resto. Correlaciona el `id` JSON-RPC de la respuesta con el de la petición.
- `highlights`: bloques literales con encabezados de autor («### usuario»). PROBADO: 41 bloques / 12.770
  caracteres en un hilo. Sirven de triage; para citar, `leer`.
- `freshness=week` dejó pasar un post de febrero de 2026 (PROBADO hoy): fecha siempre por Arctic Shift.
- `extraction=full_page` con caché devolvió `pages_extracted: 0` (PROBADO).

---

## 6. Arctic Shift

**OFICIAL + PROBADO.** Base `https://arctic-shift.photon-reddit.com/api`, sin clave. Proyecto:
<https://github.com/ArthurHeitmann/arctic_shift> (README de la API consultado el 7-oct-2026). Archiva posts y comentarios
**unos 11-26 s después de publicarse** (PROBADO: último post con 25 s de antigüedad en `salud`) y los vuelve a capturar
hacia las 36 h (`_meta.retrieved_2nd_on`).

| Endpoint | Uso | Notas medidas |
|---|---|---|
| `/posts/ids?ids=a,b,c` | Fechar e hidratar (hasta 500 por la doc; el script usa 100) | 200 en ~2 s |
| `/comments/tree?link_id=ID&limit=9999` | Árbol completo con `replies` anidadas | 126 comentarios en 3 s; puede traer nodos `more` |
| `/comments/ids?ids=…` | Expandir nodos `more` | OFICIAL; sin prueba propia |
| `/comments/search?link_id=ID&limit=100` | Plano, 100 por página | `sort=asc` dio 422 intermitente |
| `/posts/search?subreddit=S&query=…&after=AAAA-MM-DD` | Descubrir dentro de un subreddit | `query` sin `subreddit`/`author` → 400; varias palabras → 422 frecuente |

Lo que hay que saber:

- **No es completo.** En el hilo de control faltaba `pd2v83h` (u/Merari01), visible en Redlib: por eso `leer` une ambas.
- **El texto es el de la captura.** Si el autor edita después, Arctic conserva el original (`_meta.is_edited=true`). Caso
  PROBADO `pd1pln5`: `![gif](giphy|…)` en Arctic, texto completo en Redlib.
- **Votos y contadores son de la captura** (primera o segunda). Post de control: 6 votos en Arctic, 11 en Redlib; comentario
  `pd1pln5`: 30 frente a 33.
- Conserva a veces texto borrado después (`_meta.was_deleted_later`). No reproducir contenido borrado por su autor: Reddit
  exige retirarlo (Public Content Policy, 6-oct-2026).
- Excluye comunidades privadas y en cuarentena (OFICIAL).
- Los volcados mensuales (Academic Torrents) llegan hasta agosto de 2026 y pesan 74,6 GB/mes: no son para recencia.

---

## 7. Redlib

Frontend alternativo de Reddit (<https://github.com/redlib-org/redlib>). Lista viva de instancias:
<https://raw.githubusercontent.com/redlib-org/redlib-instances/main/instances.json> (`updated: 2026-10-07`).

- Funcionan hoy (PROBADO): `safereddit.com`, `red.artemislena.eu`, `redlib.synth.download` (antes `reddit.synth.download`, mudado el 7-oct-2026). Fallan: catsarch (429 Anubis),
  nadeko (418), privacyredirect/privadency (200 con Anubis), r4fo (502), cow.rip y vanillax (403 Cloudflare).
- Ruta: `https://<instancia>/r/<sub>/comments/<id>/`. Marcado estable: `div.comment#<id>`, `p.comment_score[title]`,
  `a.comment_author`, `a.created[title="Sep 30 2026, 17:46:40 UTC"]`, `span.edited`, `div.comment_body`; post en
  `div.post` con `post_title`, `post_author`, `span.created`, `div.post_score[title]`, `div.post_body`.
- `.json` y `.rss` en Redlib devuelven HTML o 404: no es una API.
- Texto renderizado: los enlaces pierden la URL (queda el texto del enlace) y los gifs salen como URL. Por eso el texto de
  Arctic (markdown) manda salvo en comentarios editados.

---

## 8. Wayback Machine

**OFICIAL + PROBADO.** CDX exacto: `https://web.archive.org/cdx/search/cdx?url=<url>&output=json&filter=statuscode:200&limit=-3`.
La consulta con comodín expiró a los 22 s; Availability dio 429. La captura se pide con `id_` para el HTML original:
`https://web.archive.org/web/<timestamp>id_/<url>`. Trampas: el timestamp pedido se resuelve al más cercano (pedir 5-sep dio
30-ago), y `statuscode:200` no excluye pantallas de login. El script descarta capturas que parecen login.

---

## 9. Buscador y lector propios del agente

- **Buscador web del agente** (la herramienta de búsqueda de Claude Code, Codex, Hermes u otro): en modo base es la fuente
  principal de descubrimiento. PROBADO con uno de ellos: encuentra y abre hilos, pero su filtro de días devolvió posts de
  meses atrás y su lector mostró «18h ago» en un post de 3 días (caché).
- No todos llegan a Reddit: el 8-oct-2026 el buscador web de Claude Code no tenía acceso a reddit.com (lo dijo el propio
  agente y no devolvió ninguna URL), mientras que el de Codex encontró y abrió hilos. Sin él, el modo base depende de
  You.com y de Arctic Shift por subreddit; Firecrawl (plan gratuito) es la forma más barata de añadir un buscador global.
- Tratarlos todos igual: sus URL entran por `--mas-urls` y el script las fecha en Arctic Shift.
- No asumir que son índices independientes de Brave o Google: medir cuántos IDs nuevos aportan.

```bash
# El agente guarda las URL de su buscador y las fusiona con el resto
printf '%s\n' "https://www.reddit.com/r/Python/comments/1wwv97o/" > mis_urls.txt
python3 reddit_helper.py descubrir "uv vs pip" --ventana w,m --mas-urls mis_urls.txt
```

---

## 10. Fuentes descartadas y por qué

| Fuente | Prueba | Uso permitido |
|---|---|---|
| Exa `/search`, `/contents` | 0 URL de reddit.com en 15+ consultas; contents `SOURCE_NOT_AVAILABLE` (403 de origen) | Docs, papers y espejos (`web`, `exa`) |
| Firecrawl `/v2/scrape` | 403 «we do not support this site» | Páginas que NO son Reddit |
| Jina Reader | HTTP 200 con «You've been blocked by network security» | Ninguno para Reddit |
| `.json`, `api.reddit.com`, `oauth.reddit.com` sin token | 403 | — |
| old.reddit | 302 a login | — |
| RSS | 200 hoy, 429 rápido; retirado el 13-nov-2026 | Nada nuevo debe depender de él |
| PullPush | ~3 días de retraso y 429 «does not provide free scraping resources for agents» | No usar |
| Pushshift | 403; solo moderadores aprobados para moderar | No usar |
| Reveddit, archive.today, teddit, libreddit | Sin contenido recuperado | No usar |

---

## 11. Errores y cómo los trata el script

```text
respuesta ──► HTTP ≥ 400, o 200 con cuerpo de error (JSON-RPC de You, success:false de Firecrawl, error de Arctic)
                 │      ──► HttpError(code, cuerpo sin claves); > 64 MB (también tras gzip) ─► 413, sin reintento
                 │
                 ├─ 408/425/429/5xx, 520-524, red, timeout, JSON/gzip roto, 422 «Timeout» de Arctic ─► reintento: 1,5 s·2^n + jitter,
                 │     ≥ 5 s si 429 y nunca antes de Retry-After; Retry-After > 120 s ─► fuente en pausa hasta esa hora
                 └─ resto (400, 401, 403, 404, 422 de validación) ─► sin reintento ─► CircuitBreaker.record_failure
Redirecciones: nunca a otro host ni de https a http; con clave, tampoco a otro puerto.
CircuitBreaker por fuente: 4 fallos ─► abierto 60 s ─► half_open ─► UNA sola llamada de prueba ─► cerrado | abierto
descubrir: una fuente caída queda en indice.json → fuentes[...] = {ok:false, error} y el resto sigue
leer: cada vía fallida queda en cobertura.intentos_fallidos
```

| Síntoma | Causa probable | Qué hacer |
|---|---|---|
| `falta BRAVE_SEARCH_API_KEY` | Pediste esa fuente con `--fuentes` y no hay clave | Conectar la clave (§13) o no pedir esa fuente: sin `--fuentes`, el script usa solo las disponibles |
| `clave demasiado corta` | Valor de clave de < 8 caracteres (mal copiado) | Revisar `~/.reddit-search/claves.env` |
| `fuente en pausa hasta …` | Retry-After largo o cuota agotada | Esperar a esa hora; el resto de fuentes sigue |
| `Name or service not known` | El agente corre sin acceso a internet | Darle red al agente |
| Arctic 422 repetido | Saturación | Esperar y repetir; reducir ventana o `--sub` |
| `circuito … abierto` | 4 fallos seguidos | Esperar 60 s; revisar `salud` |
| Redlib «sin hilo» en las 3 | Anubis o caída | `leer` sigue con Arctic; votos quedan de la captura |
| Código de salida 3 | 0 hilos / 0 citas | Relajar consulta (método §3) |
| Código de salida 4 | Hilo sin texto | Probar otro hilo; citar solo lo leído |

---

## 12. Candidatos sin probar

OFICIAL, sin clave ni prueba en Reddit: **Tavily** (`include_domains_mode:"restrict"`, `time_range`, `/extract`; 1.000
créditos gratis/mes), **Parallel** (`/v1/search` con `after_date`, `/v1/extract` `full_content`), **Linkup** (`/v1/search`
`searchResults` + `/v1/fetch` `includeRawContent`), **SerpAPI** (`tbs=qdr:w`; corrigió `site:`+`qdr` el 11-ago-2026),
**Serper**, **Kagi** (12 USD/1.000). Requieren alta y clave. Ninguno es necesario para el pipeline actual; añadirlos solo tras
un piloto que mida cuántos hilos nuevos y citables aportan.

---

## 13. Modo base y modo experto: conectar cada clave

```text
salud ──► modo: base     (0 claves)  buscador del agente + You.com + Arctic Shift; lectura completa igual
      ──► modo: parcial  (1-2)       lo anterior + los servicios conectados
      ──► modo: experto  (3)         lo anterior + Brave + Perplexity + Firecrawl
servicio NO configurado ─► no se llama, no sale como fallo, figura en «falta para el modo experto»
servicio configurado ─► CFG en salud (no se prueba: no gasta créditos); salud --en-vivo lo prueba de verdad
salud prueba en vivo las fuentes gratuitas: consume 1 de las 100 consultas diarias de You.com
servicio configurado que falla ─► FALLO visible en indice.json y MAL en salud --en-vivo (revisar clave o saldo)
```

La lectura (Arctic Shift, Redlib, Wayback) es la misma en los dos modos. El modo experto amplía el **descubrimiento**: puede
encontrar más hilos, sobre todo en temas de nicho y ventanas cortas, sin garantía de cantidad.

| Servicio | Variable | Dónde se saca la clave | Precio y plan gratis (OFICIAL, 8-oct-2026) |
|---|---|---|---|
| Brave Search API | `BRAVE_SEARCH_API_KEY` | `https://api-dashboard.search.brave.com/register` (plan «Search») | 5 USD/1.000 consultas; 5 USD de crédito gratis cada mes. Pide tarjeta solo para verificar identidad |
| Perplexity Search API | `PERPLEXITY_API_KEY` | `https://console.perplexity.ai/project/keys` | 5 USD/1.000 consultas (modo fast 1 USD/1.000); pago por uso, sin suscripción |
| Firecrawl | `FIRECRAWL_API_KEY` | `https://www.firecrawl.dev/signin?view=signup` | Plan gratis: 1.000 créditos/mes, sin tarjeta; búsqueda = 2 créditos por cada 10 resultados |
| You.com MCP (ya incluido) | — | No hace falta | 100 consultas/día gratis sin clave |

Cómo se conecta (la clave NUNCA pasa por el chat):

1. El usuario copia la clave en el panel del servicio y dice: «Conecta Brave Search para reddit-search; ya copié la clave».
2. El agente corre `python3 "$H" conectar brave`: lee el portapapeles (macOS `pbpaste`, Windows `Get-Clipboard`, Linux
   `wl-paste`/`xclip`/`xsel`), valida que sea una sola línea de 8-512 caracteres sin espacios y la guarda en
   `~/.reddit-search/claves.env` (Windows: `%USERPROFILE%\.reddit-search\claves.env`), con permisos 600 en macOS y Linux,
   sin tocar las demás claves. Solo muestra los 4 últimos caracteres.
3. Sin portapapeles accesible: `conectar brave --preparar-fichero` crea el fichero con la línea `BRAVE_SEARCH_API_KEY=`
   vacía; el usuario lo abre, pega la clave en esa línea y guarda.
4. El agente corre `salud` (modo resultante) y, si el usuario quiere comprobar la clave, `salud --en-vivo` (gasta créditos).

Si el usuario pega la clave en el chat, el agente no la usa: le pide que la revoque, genere otra y la copie al portapapeles.

Alternativas: la variable de entorno con el mismo nombre (tiene prioridad) o `REDDIT_SEARCH_ENV=<ruta>` para usar otro fichero
de claves. El script acepta `NOMBRE=valor` y `export NOMBRE=valor`, con o sin comillas.
