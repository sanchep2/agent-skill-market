#!/usr/bin/env python3
"""
reddit_helper.py — Búsqueda en Reddit para agentes: descubrir hilos, leerlos completos y citar DATA ORIGINAL.

Pipeline de búsqueda pública, lectura y citas verificadas:

  descubrir  Brave + Perplexity Search + Firecrawl Search (+ Arctic Shift por subreddit, + URLs del buscador
             propio del agente) en paralelo → deduplicar por ID de post → fecha y votos verificados en Arctic Shift
             → índice ordenado por fecha absoluta y votos.
  leer       Un hilo por ID o URL: Arctic Shift (post + árbol completo) + votos actuales de un espejo Redlib;
             respaldo: Redlib solo → Brave LLM Context (parcial) → Wayback (parcial). Declara la cobertura.
  lote       Lee varios hilos (lista o índice de `descubrir`) y monta un corpus literal.
  citas      Extrae del corpus los párrafos LITERALES que casan con un patrón, con URL, subreddit, autor, fecha y votos.
  salud      Sondea todas las fuentes y dice cuáles funcionan hoy (correr al empezar cada sesión).
  exa | web | brave | hilo | firecrawl   Subcomandos auxiliares (Exa NO devuelve reddit.com).

Dependencias:
    Ninguna: solo la biblioteca estándar de Python ≥ 3.9 (urllib, json, html.parser, zoneinfo, concurrent.futures).

Variables de entorno (o líneas NOMBRE=valor en el fichero de claves; NUNCA se imprimen):
    BRAVE_SEARCH_API_KEY   Brave Search API (web/search y llm/context)
    PERPLEXITY_API_KEY     Perplexity Search API (POST /search)
    FIRECRAWL_API_KEY      Firecrawl (/v2/search)
    EXA_API_KEY            Exa (solo subcomandos heredados exa/web)
    REDDIT_SEARCH_ENV      ruta del fichero de claves (por defecto ~/.reddit-search/claves.env)
    REDDIT_SEARCH_SALIDA   carpeta de salida (por defecto ./reddit-salida)
    REDDIT_SEARCH_TZ       zona IANA opcional (por defecto la hora local del sistema)
    Arctic Shift, Redlib y Wayback no usan clave.

Uso CLI:
    python3 reddit_helper.py salud
    python3 reddit_helper.py descubrir "uv python package manager" --ventana w,m --sub Python --sub learnpython
    python3 reddit_helper.py descubrir "precios pequeño negocio" --mas-urls urls_de_mi_buscador.txt
    python3 reddit_helper.py leer 1wubcvf
    python3 reddit_helper.py leer https://www.reddit.com/r/redditdev/comments/1wubcvf/ --orden votos --max 40
    python3 reddit_helper.py lote reddit-salida/<carpeta>/indice.json --top 15 --solo-ventana
    python3 reddit_helper.py citas reddit-salida/<carpeta>/corpus.json --buscar "battery|batería" --min-votos 5

Como módulo:
    from reddit_helper import RedditHelper
    h = RedditHelper()
    indice = h.descubrir("iPhone battery", ventanas=["w"])
    hilo = h.leer("1wubcvf")
"""

from __future__ import annotations

import sys

if sys.version_info < (3, 9):
    print("reddit-search requiere Python >= 3.9. Instala Python 3.12: "
          "Windows: winget install Python.Python.3.12; "
          "macOS: brew install python@3.12 o python.org; "
          "Linux: usa el gestor de paquetes de tu distribución.", file=sys.stderr)
    sys.exit(2)

import argparse
import dataclasses
import gzip
import hashlib
import html
import html.entities
import http.client
import math
import zlib
from email.utils import parsedate_to_datetime
import json
import logging
import os
import random
import re
import shutil
import string
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone, tzinfo
from functools import lru_cache
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple, TypeVar

from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

ZONA_FORZADA: Optional[tzinfo] = None


class _ZonaSistema(tzinfo):
    """Hora local del sistema cuando no hay zona IANA disponible (p. ej. Windows sin base de zonas). Para «ahora» usa el
    desfase actual; `iso_local` resuelve cada fecha con las reglas locales de SU instante (horario de verano incluido)."""

    def utcoffset(self, dt):
        return datetime.now().astimezone().utcoffset()

    def dst(self, dt):
        return timedelta(0)

    def tzname(self, dt):
        return datetime.now().astimezone().tzname()


_ZONA_SISTEMA = _ZonaSistema()


def _zona() -> tzinfo:
    """Zona inyectada, IANA explícita o zona local; el fallback no necesita tzdata."""
    if ZONA_FORZADA is not None:
        return ZONA_FORZADA
    if "REDDIT_SEARCH_TZ" in os.environ:
        nombre = os.environ["REDDIT_SEARCH_TZ"]
        try:
            return ZoneInfo(nombre)
        except (ZoneInfoNotFoundError, ValueError):
            raise ValueError("REDDIT_SEARCH_TZ: zona IANA inválida o base de zonas no disponible; "
                             "instala la base de zonas del sistema o elimina REDDIT_SEARCH_TZ "
                             "para usar la hora local") from None
    try:
        localtime = Path("/etc/localtime")
        if localtime.is_symlink():
            destino = localtime.resolve().as_posix()
            if "/zoneinfo/" in destino:
                nombre = destino.split("/zoneinfo/", 1)[1]
                if nombre:
                    return ZoneInfo(nombre)
    except (OSError, ValueError, ZoneInfoNotFoundError):
        pass
    return _ZONA_SISTEMA


# ============================================================================
# Logging
# ============================================================================

logging.basicConfig(level=logging.WARNING, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s", datefmt="%H:%M:%S")
logger = logging.getLogger("reddit_helper")

T = TypeVar("T")

VERSION = "1.3.0"
UA = f"reddit-search/{VERSION} (investigacion de foros; sin afiliacion con Reddit)"

ARCTIC = "https://arctic-shift.photon-reddit.com/api"
# Instancias Redlib que sirvieron el hilo completo en HTML el 7-oct-2026 (lista viva:
# https://raw.githubusercontent.com/redlib-org/redlib-instances/main/instances.json). Se prueban en orden.
REDLIB = ["safereddit.com", "red.artemislena.eu", "redlib.synth.download"]  # synth se mudó el 7-oct-2026 (302 desde reddit.synth.download)

# Respaldo de Arctic (listado del subreddit filtrado aquí): al menos la mitad de los términos. Con > 0, en r/StandingDesk
# entraban casi todos los posts por coincidir en «desk» (prueba en vivo 7-oct-2026).
UMBRAL_FILTRO_LOCAL = 0.5
VENTANAS: Dict[str, Optional[int]] = {"d": 1, "w": 7, "m": 31, "y": 366, "todo": None}
BRAVE_FRESH = {"d": "pd", "w": "pw", "m": "pm", "y": "py"}
PPLX_RECENCY = {"d": "day", "w": "week", "m": "month", "y": "year"}
FIRE_TBS = {"d": "qdr:d", "w": "qdr:w", "m": "qdr:m", "y": "qdr:y"}

# ID de post: base36 en minúsculas. Los IDs de comentario nuevos llegan a 13 caracteres (anuncio 15-sep-2026).
RE_ID = re.compile(r"^(t3_)?([a-z0-9]{4,13})$", re.I)

STOP = set("""a al algo como con de del el en es esta este for from how in is la las lo los mas más mi my of on or para
pero por que qué se sin su the to un una uno y with what why when where which who does do reddit""".split())


# ============================================================================
# Errores y utilidades
# ============================================================================


class HttpError(Exception):
    """Error HTTP con código y un extracto del cuerpo (ya sin claves)."""

    def __init__(self, code: int, cuerpo: str, url: str, retry_after: float = 0.0):
        partes = urllib.parse.urlsplit(str(url))
        if partes.query and (redactar(partes.query) != partes.query or
                             redactar(urllib.parse.unquote_plus(partes.query)) != urllib.parse.unquote_plus(partes.query)):
            url = urllib.parse.urlunsplit((partes.scheme, partes.netloc, partes.path, "", partes.fragment))
        cuerpo, url = redactar(str(cuerpo)), redactar(str(url))
        self.retry_after = retry_after
        super().__init__(f"HTTP {code} en {url}: {cuerpo[:240]}")
        self.code = code
        self.cuerpo = cuerpo
        self.url = url


_CLAVES_CARGADAS: List[str] = []


# Redacción de claves por VISTAS DECODIFICADAS con mapa de posiciones.
# Una clave puede aparecer escrita en cualquier composición de codificaciones reversibles estándar: escapes JSON (\" \\
# \/ \n \uXXXX y pares sustitutos, sobre CUALQUIER carácter), porcentaje (%XX en UTF-8, + como espacio en formularios)
# y entidades HTML (&#82; &#x52; &amp;…), en cualquier orden y número de capas. En lugar de describir todas las formas
# con una expresión regular (incompleta y con retroceso), se decodifica el texto capa a capa: cada vista es el texto con
# una capa más deshecha y, para cada carácter, la posición del tramo original del que sale. La clave se busca con
# str.find en cada vista y se sustituye SOLO su tramo en el texto original; el resto de la evidencia no se toca.
_RE_JSON = re.compile(r'\\(?:u[0-9a-fA-F]{4}|["\\/bfnrt])')
_RE_PCT = re.compile(r"(?:%[0-9a-fA-F]{2})+")
_RE_PCT_MAS = re.compile(r"(?:%[0-9a-fA-F]{2})+|\+")
# Misma gramática de referencias que html.unescape (CPython Lib/html/__init__.py, _charref): números de cualquier
# longitud y con ceros a la izquierda, «;» opcional y nombres tolerantes (p. ej. «&ampX» = «&X»).
_RE_HTML = re.compile(r"&(#[0-9]+;?|#[xX][0-9a-fA-F]+;?|[^\t\n\f <&#;]{1,32};?)")
_JSON_SIMPLE = {'"': '"', "\\": "\\", "/": "/", "b": "\b", "f": "\f", "n": "\n", "r": "\r", "t": "\t"}
# Topes por texto: vistas distintas y caracteres decodificados en total. Los datos reales del 7-oct-2026 generan 2-4
# vistas (HTML Redlib 158 KB: 4; árbol Arctic 346 KB: 2). Una cadena deliberada de capas (%2525…, \\u005c…) los agota;
# entonces no se puede asegurar la ausencia de claves y el texto entero se retiene (falla cerrado).
MAX_VISTAS = 1024
MAX_FACTOR_TRABAJO = 64
RETENIDO = "[RETENIDO: tramo con demasiadas capas de escape para comprobar que no contiene claves]"


def _piezas_json(m, texto):
    """Escapes JSON del tramo: [(carácter, inicio, fin)] en coordenadas de la vista de entrada (nunca None)."""
    t = m.group(0)
    if t[1] != "u":
        return [(_JSON_SIMPLE[t[1]], m.start(), m.end())]
    return [(chr(int(t[2:], 16)), m.start(), m.end())]


def _unir_sustitutos(piezas):
    out = []
    for c, a, b in piezas:
        if out and 0xD800 <= ord(out[-1][0]) <= 0xDBFF and 0xDC00 <= ord(c) <= 0xDFFF and out[-1][2] == a:
            alto = out.pop()
            c = chr(0x10000 + ((ord(alto[0]) - 0xD800) << 10) + (ord(c) - 0xDC00))
            a = alto[1]
        out.append((c, a, b))
    return out


def _piezas_pct(m, texto):
    t = m.group(0)
    if t == "+":
        return [(" ", m.start(), m.end())]
    datos = bytes(int(t[i + 1:i + 3], 16) for i in range(0, len(t), 3))
    out, i = [], 0
    while i < len(datos):
        b = datos[i]
        largo = 1 if b < 0x80 else 2 if 0xC2 <= b <= 0xDF else 3 if 0xE0 <= b <= 0xEF else 4 if 0xF0 <= b <= 0xF4 else 0
        try:
            c = datos[i:i + largo].decode("utf-8") if largo and i + largo <= len(datos) else None
        except UnicodeDecodeError:
            c = None
        a = m.start() + 3 * i
        if c is None:  # byte suelto inválido: el «%XX» se queda tal cual
            out.extend((x, a + k, a + k + 1) for k, x in enumerate(t[3 * i:3 * i + 3]))
            i += 1
        else:
            out.append((c, a, a + 3 * largo))
            i += largo
    return out


def _piezas_html(m, texto):
    """Piezas de una referencia HTML con la semántica de html.unescape. None = sin cambio; [] = la referencia se
    ELIMINA (html.unescape borra p. ej. &#11; o &#xFFFF;), que también es un cambio."""
    t = m.group(0)
    a = m.start()
    if t.startswith("&#"):
        hexa = t[2:3] in "xX"
        cifras = t[3:] if hexa else t[2:]
        cifras = cifras.rstrip(";").lstrip("0") or "0"
        # Más de 8 cifras supera siempre U+10FFFF: html.unescape da U+FFFD. Se evita convertir números gigantes.
        c = "\ufffd" if len(cifras) > 8 else html.unescape("&#" + ("x" if hexa else "") + cifras + ";")
        return [(x, a, m.end()) for x in c]
    nombre = t[1:]
    if nombre in html.entities.html5:
        return [(x, a, m.end()) for x in html.entities.html5[nombre]]
    # Nombre tolerante sin «;»: el prefijo más largo conocido (como html.unescape) y el resto queda tal cual, con sus
    # posiciones propias (no se asigna todo el tramo de la referencia a un sufijo que no se transformó).
    for x in range(len(nombre) - 1, 1, -1):
        if nombre[:x] in html.entities.html5:
            fin_ref = a + 1 + x
            return [(y, a, fin_ref) for y in html.entities.html5[nombre[:x]]] + \
                   [(y, fin_ref + i, fin_ref + i + 1) for i, y in enumerate(nombre[x:])]
    return None


def _decodificadores():
    capas = [("json", "\\", _RE_JSON, _piezas_json), ("pct", "%", _RE_PCT, _piezas_pct),
             ("html", "&", _RE_HTML, _piezas_html)]
    if any(" " in k for k in _CLAVES_CARGADAS):
        capas.append(("form", "%+", _RE_PCT_MAS, _piezas_pct))
    return capas


def _decodificar_capa(texto, patron, piezas_de, ini=None, fin=None):
    """Una capa deshecha. Con ini/fin (tramo original de cada carácter de `texto`) devuelve también los de la vista."""
    con_mapa = ini is not None
    salida, nuevo_ini, nuevo_fin, pendientes = [], [], [], []
    pos, cambiado = 0, False

    def volcar():
        for c, a, b in _unir_sustitutos(pendientes):
            salida.append(c)
            if con_mapa:
                nuevo_ini.append(ini[a])
                nuevo_fin.append(fin[b - 1])
        pendientes.clear()

    for m in patron.finditer(texto):
        piezas = piezas_de(m, texto)
        if piezas is None:  # sin transformación ([] sí es un cambio: el tramo se elimina)
            continue
        if m.start() > pos:
            volcar()
            salida.append(texto[pos:m.start()])
            if con_mapa:
                nuevo_ini.extend(ini[pos:m.start()])
                nuevo_fin.extend(fin[pos:m.start()])
        pendientes.extend(piezas)
        pos, cambiado = m.end(), True
    if not cambiado:
        return (texto, ini, fin) if con_mapa else texto
    volcar()
    salida.append(texto[pos:])
    if con_mapa:
        nuevo_ini.extend(ini[pos:])
        nuevo_fin.extend(fin[pos:])
        return "".join(salida), nuevo_ini, nuevo_fin
    return "".join(salida)


def _tramos_clave(texto: str, claves: List[str]) -> Optional[List[Tuple[int, int]]]:
    """Tramos del texto ORIGINAL que, decodificados por alguna secuencia de capas, son una clave. None = tope agotado.

    Recorre en profundidad las secuencias de capas (cualquier orden y número), deduplica las vistas por huella y busca
    las claves en cada vista al crearla: en memoria solo queda la rama en curso. Solo para las vistas con hallazgos se
    repite la secuencia con mapa de posiciones.
    """
    capas = _decodificadores()
    por_nombre = {c[0]: c for c in capas}

    def huella(t):
        return hashlib.blake2b(t.encode("utf-8", "surrogatepass"), digest_size=16).digest()

    vistas = {huella(texto)}
    pila = [(texto, ())]
    presupuesto = MAX_FACTOR_TRABAJO * len(texto) + 65536
    con_hallazgos = []
    while pila:
        v, cadena = pila.pop()
        hallazgos = []
        for k in claves:
            i = v.find(k)
            while i != -1:
                hallazgos.append((i, i + len(k)))
                i = v.find(k, i + 1)
        if hallazgos:
            con_hallazgos.append((cadena, hallazgos))
        for nombre, disparadores, patron, piezas_de in capas:
            if not any(d in v for d in disparadores):
                continue
            presupuesto -= len(v)
            if presupuesto < 0:
                return None
            w = _decodificar_capa(v, patron, piezas_de)
            if w == v:
                continue
            h = huella(w)
            if h in vistas:
                continue
            if len(vistas) >= MAX_VISTAS:
                return None
            vistas.add(h)
            pila.append((w, cadena + (nombre,)))
    tramos = []
    for cadena, hallazgos in con_hallazgos:
        actual, ini, fin = texto, list(range(len(texto))), list(range(1, len(texto) + 1))
        for nombre in cadena:
            _, _, patron, piezas_de = por_nombre[nombre]
            actual, ini, fin = _decodificar_capa(actual, patron, piezas_de, ini, fin)
        tramos.extend((ini[a], fin[b - 1]) for a, b in hallazgos)
    return tramos


@lru_cache(maxsize=64)
def _re_tramos(claves: Tuple[str, ...]):
    """Tramos donde puede estar una clave codificada: caracteres de las claves + letras, dígitos y sintaxis de escape.

    El alfabeto es cerrado por las capas: un escape JSON, porcentual o HTML de un carácter de este conjunto solo produce
    caracteres del conjunto (\\ u x # ; & % + letras y dígitos; «"» o «/» solo si la clave los contiene). Una clave
    codificada nunca cruza un carácter ajeno, así que cada tramo se explora por separado: los escapes de palabras
    distintas no se combinan entre sí y, si un tramo agota los topes, solo ese tramo se retiene.
    """
    alfabeto = set(string.ascii_letters + string.digits + "\\%&#;+") | {c for k in claves for c in k}
    return re.compile("[" + "".join(re.escape(c) for c in sorted(alfabeto)) + "]+")


def redactar(texto: str) -> str:
    """Sustituye cualquier clave cargada por [CLAVE] (defensa en profundidad: ningún mensaje la imprime).

    Reconoce la clave escrita en cualquier composición de escapes JSON, porcentaje/formulario y entidades HTML (ver
    `_tramos_clave` y `_re_tramos`). Solo se sustituye el tramo reconocido; el resto del texto no se decodifica ni se
    reescribe. Un tramo que agota los topes de exploración se sustituye por RETENIDO (falla cerrado solo en ese tramo).
    """
    claves = tuple(sorted({k for k in _CLAVES_CARGADAS if k}, key=len, reverse=True))
    if not claves or not texto:
        return texto
    tramos: List[Tuple[int, int, str]] = []
    for k in claves:  # apariciones literales (rápido; nunca cruzan tramos)
        i = texto.find(k)
        while i != -1:
            tramos.append((i, i + len(k), "[CLAVE]"))
            i = texto.find(k, i + 1)
    if any(d in texto for d in "\\%&+"):
        minimo = min(len(k) for k in claves)
        for m in _re_tramos(claves).finditer(texto):
            tramo = m.group(0)
            if len(tramo) < minimo or not any(d in tramo for d in "\\%&+"):
                continue
            hallados = _tramos_clave(tramo, list(claves))
            if hallados is None:
                tramos.append((m.start(), m.end(), RETENIDO))
            else:
                tramos.extend((m.start() + a, m.start() + b, "[CLAVE]") for a, b in hallados)
    if not tramos:
        return texto
    # Une solapes; RETENIDO prevalece sobre [CLAVE] dentro del mismo tramo unido.
    tramos.sort()
    unidos = [list(tramos[0])]
    for a, b, marca in tramos[1:]:
        if a <= unidos[-1][1]:
            unidos[-1][1] = max(unidos[-1][1], b)
            if marca == RETENIDO:
                unidos[-1][2] = RETENIDO
        else:
            unidos.append([a, b, marca])
    partes, pos = [], 0
    for a, b, marca in unidos:
        partes.extend((texto[pos:a], marca))
        pos = b
    partes.append(texto[pos:])
    return "".join(partes)


def _sanear(valor):
    """Redacta cadenas antes de serializar; marca cada pieza transformada y conserva tipos."""
    if isinstance(valor, str):
        return redactar(valor)
    if isinstance(valor, list):
        return [_sanear(x) for x in valor]
    if isinstance(valor, dict):
        out = {}
        cambiado = False
        for k, v in valor.items():
            nuevo_k = redactar(k) if isinstance(k, str) else k
            if nuevo_k in out:
                raise ValueError("colisión de campos al redactar JSON")
            nuevo_v = _sanear(v)
            cambiado |= nuevo_k != k or (isinstance(v, str) and nuevo_v != v)
            out[nuevo_k] = nuevo_v
        if cambiado:
            out["redactado"] = True
        return out
    return valor


def _json_seguro(valor, **kwargs):
    return json.dumps(_sanear(valor), ensure_ascii=False, **kwargs)


def _salida_segura(texto):
    # Compatibilidad con sinks existentes que reciben JSON ya serializado.
    if texto.lstrip().startswith(("{", "[")):
        try:
            return _json_seguro(json.loads(texto), indent=1)
        except json.JSONDecodeError:
            pass
    return redactar(texto)


def _guardar_texto(ruta: Path, texto: str) -> None:
    ruta.write_text(_salida_segura(texto), encoding="utf-8")


def _imprimir(*args, **kwargs) -> None:
    print(*(_salida_segura(str(x)) for x in args), **kwargs)


class _FiltroSecretos(logging.Filter):
    def filter(self, record):
        record.msg = redactar(record.getMessage())
        record.args = ()
        return True


logger.addFilter(_FiltroSecretos())


class ParserSeguro(argparse.ArgumentParser):
    def _print_message(self, message, file=None):
        if message:
            _imprimir(message, end="", file=file or sys.stderr)


def _obj(valor: Any, contexto: str = "respuesta") -> dict:
    if not isinstance(valor, dict):
        raise ValueError(f"{contexto}: se esperaba un objeto JSON")
    return valor


def _lista(valor: Any, contexto: str = "respuesta") -> list:
    if not isinstance(valor, list):
        raise ValueError(f"{contexto}: se esperaba una lista JSON")
    return valor


def _objetos(valor: Any, contexto: str = "respuesta") -> list:
    return [_obj(x, contexto) for x in _lista(valor, contexto)]


def _cadena(valor, contexto="texto", no_vacia=False):
    if not isinstance(valor, str) or (no_vacia and not valor.strip()):
        raise ValueError(f"{contexto}: se esperaba str" + (" no vacío" if no_vacia else ""))
    return valor


def _snippets(valor):
    return [_cadena(x, "snippet", no_vacia=True) for x in _lista(valor, "snippets")]


def _validar_resultados(res, texto_reparado=False):
    for r in res:
        for campo in ("url", "titulo", "texto"):
            _cadena(r.get(campo, ""), campo)
        if texto_reparado:
            r["texto_reparado"] = True
    return res


def _validar_post(p):
    _obj(p, "post")
    if not isinstance(p.get("id"), str) or not re.fullmatch(r"[a-z0-9]{4,13}", p["id"]):
        raise ValueError("post id: se esperaba ID base36 válido")
    for campo in ("id", "title", "subreddit", "author", "url"):
        if campo in p:
            _cadena(p[campo], "post " + campo)
    for campo in ("selftext", "body"):
        if p.get(campo) is not None:
            _cadena(p[campo], "post " + campo)
    _numero_metadato(p.get("score"), "score")
    _numero_metadato(p.get("num_comments"), "num_comments", no_negativo=True)
    return p


def _validar_submission(p, comunidad=True):
    """Post de Arctic: además de los tipos, sus señales de identidad propias deben coincidir con su ID.

    `name` (si existe) debe ser «t3_<id>» y `permalink` (si existe) debe identificar el mismo post. `url` no cuenta:
    en un post de enlace apunta legítimamente a otra página. `comunidad=False` comprueba solo los IDs."""
    _validar_post(p)
    nombre = p.get("name")
    if nombre is not None and nombre != "t3_" + p["id"]:
        raise ValueError("post: «name» contradice el ID")
    if p.get("permalink") is not None:
        ref = _ref_relativa(_cadena(p["permalink"], "post permalink"))
        if not ref or ref[1] != p["id"]:
            raise ValueError("post: permalink contradice el ID")
        if comunidad and ref[0] and _comunidad(p.get("subreddit")) and _comunidad(ref[0]) != _comunidad(p.get("subreddit")):
            raise ValueError("post: permalink contradice la comunidad")
    return p


def _admitir_submission(p):
    """Valida un post de Arctic. Una copia RETIRADA cuyos IDs son coherentes y que solo falla por comunidad se admite
    como retirada sin comunidad: su retirada por ID se respeta en la política de copias, pero no aporta
    comunidad (ni, al estar retirada, texto citable). Devuelve el registro admitido (una copia en ese caso)."""
    try:
        return _validar_submission(p)
    except ValueError:
        if not isinstance(p, dict) or not _campo_submission(p, "retirado"):
            raise
        _validar_submission(p, comunidad=False)  # name/permalink contrarios al ID: no se rescata
        return dict(p, subreddit="", _comunidad_descartada=True)


def _numero_metadato(valor, campo, no_negativo=False):
    if valor is not None and (type(valor) is not int or (no_negativo and valor < 0)):
        raise ValueError(f"{campo}: se esperaba int" + (" >= 0" if no_negativo else "") + " o None")
    return valor


def _epoch(valor: Any) -> Optional[float]:
    if valor is None:
        return None
    if isinstance(valor, bool) or not isinstance(valor, (int, float, str)):
        raise ValueError("created_utc debe ser un número finito")
    try:
        t = float(valor)
        if not math.isfinite(t):
            raise ValueError()
        return t
    except (TypeError, ValueError, OverflowError):
        raise ValueError("created_utc debe ser un número finito") from None


def _limite(valor, nombre="límite"):
    if valor is None:
        return valor
    if isinstance(valor, int):
        valido = 0 <= valor <= sys.maxsize
    else:
        valido = math.isfinite(valor) and valor >= 0
    if not valido:
        raise ValueError(f"{nombre} debe ser no negativo, finito y estar dentro del rango soportado")
    return valor


def _rango_entero(valor, nombre="entero"):
    if valor is not None and (not isinstance(valor, int) or not -sys.maxsize - 1 <= valor <= sys.maxsize):
        raise ValueError(f"{nombre} fuera del rango entero soportado")
    return valor


def _ratio(valor):
    if not math.isfinite(valor) or not 0 <= valor <= 1:
        raise ValueError("relevancia debe estar en [0,1]")
    return valor


def _retry_after(valor):
    try:
        segundos = float(valor)
    except (ValueError, TypeError):
        try:
            segundos = parsedate_to_datetime(valor).timestamp() - time.time()
        except (ValueError, TypeError, OverflowError):
            return 0.0
    return max(0.0, segundos) if math.isfinite(segundos) else 0.0


def fichero_claves() -> Optional[Path]:
    """Fichero de claves: REDDIT_SEARCH_ENV o ~/.reddit-search/claves.env. None si no hay carpeta de usuario detectable
    (p. ej. un servicio de Windows sin USERPROFILE): entonces solo cuentan las variables de entorno (modo base si no hay)."""
    if "REDDIT_SEARCH_ENV" in os.environ:
        return Path(os.environ["REDDIT_SEARCH_ENV"])
    try:
        return Path.home() / ".reddit-search" / "claves.env"
    except (RuntimeError, KeyError):
        return None


def clave(nombre: str, obligatoria: bool = True) -> str:
    """Lee y registra una clave del entorno o fichero para redacción; rechaza menos de 8 caracteres."""
    valor = os.environ.get(nombre, "").strip()
    if not valor:
        f = fichero_claves()
        if f is not None and f.is_file():
            for linea in f.read_text(encoding="utf-8").splitlines():
                m = re.fullmatch(r"\s*(?:export\s+)?" + re.escape(nombre) + r"\s*=\s*(.*?)\s*", linea)
                if m:
                    valor = m.group(1)
                    if len(valor) >= 2 and valor[0] == valor[-1] and valor[0] in ("'", '"'):
                        valor = valor[1:-1]
                    break
    if valor:
        if len(valor) < 8:
            raise ValueError(f"{nombre}: clave demasiado corta")
        if valor not in _CLAVES_CARGADAS:
            _CLAVES_CARGADAS.append(valor)
        return valor
    if obligatoria:
        proveedor = {"BRAVE_SEARCH_API_KEY": "Brave Search", "PERPLEXITY_API_KEY": "Perplexity",
                     "FIRECRAWL_API_KEY": "Firecrawl", "EXA_API_KEY": "Exa"}.get(nombre, nombre)
        raise RuntimeError(f'falta {nombre} (modo experto): pide a tu agente "conecta {proveedor} para reddit-search"')
    return ""


CLAVES_CONFIGURADAS = ("BRAVE_SEARCH_API_KEY", "PERPLEXITY_API_KEY", "FIRECRAWL_API_KEY", "EXA_API_KEY")


PROVEEDORES_EXPERTOS = {"brave": "BRAVE_SEARCH_API_KEY", "perplexity": "PERPLEXITY_API_KEY",
                       "firecrawl": "FIRECRAWL_API_KEY"}
AVISO_MODO_EXPERTO = ("Modo experto disponible: con BRAVE_SEARCH_API_KEY, PERPLEXITY_API_KEY y "
                      "FIRECRAWL_API_KEY la búsqueda puede encontrar más hilos.")


def modo_busqueda() -> Dict[str, Any]:
    """Detecta el modo sin sondear proveedores ni consumir créditos."""
    configuradas, faltan = [], []
    for nombre in PROVEEDORES_EXPERTOS.values():
        (configuradas if clave(nombre, obligatoria=False) else faltan).append(nombre)
    return {"modo": "experto" if not faltan else "parcial" if configuradas else "base",
            "configuradas": configuradas, "faltan": faltan}


def _registrar_claves():
    errores = []
    for nombre in CLAVES_CONFIGURADAS:
        try:
            clave(nombre, obligatoria=False)
        except ValueError as e:
            errores.append(str(e))
    if errores:
        raise ValueError("; ".join(errores))


def iso_local(ts: Optional[float]) -> Optional[str]:
    """Epoch → ISO 8601 en la zona local o configurada."""
    if ts is None:
        return None
    zona = _zona()
    try:
        if zona is _ZONA_SISTEMA:  # reglas locales del instante concreto, no el desfase de hoy
            return datetime.fromtimestamp(_epoch(ts)).astimezone().isoformat()
        return datetime.fromtimestamp(_epoch(ts), zona).isoformat()
    except (OverflowError, OSError, ValueError):
        raise ValueError("created_utc debe ser finito y representable como fecha") from None


def ahora() -> float:
    return time.time()


def slug(texto: str, n: int = 40) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", texto.lower()).strip("-")
    return (s[:n] or "consulta").strip("-")


def terminos(consulta: str) -> List[str]:
    limpia = re.sub(r"site:\S+|-\S+|[\"'()]", " ", consulta.lower())
    return [t for t in re.findall(r"[\wáéíóúñü]+", limpia) if len(t) > 2 and t not in STOP]


def relevancia(consulta: str, texto: str) -> float:
    """Fracción de términos de la consulta presentes en el texto (0-1). Orientativa: el agente decide."""
    ts = terminos(consulta)
    if not ts:
        return 0.0
    bajo = texto.lower()
    return round(sum(1 for t in ts if t in bajo) / len(ts), 2)


def extraer_post(url: str) -> Optional[Tuple[str, str]]:
    """URL de hilo (reddit.com, redd.it o espejo con la misma ruta) → (subreddit, id_post). Perfiles, wikis e índices → None."""
    try:
        u = urllib.parse.urlsplit(url or "")
        host = (u.hostname or "").lower()
    except ValueError:
        return None
    if u.scheme not in ("http", "https") or u.username or u.password:
        return None
    # Un parámetro de navegación nunca identifica un hilo.
    if "/" in urllib.parse.unquote(u.query) or "/" in urllib.parse.unquote(u.fragment):
        return None
    if host == "redd.it":
        m = re.fullmatch(r"/([a-z0-9]{4,13})/?", u.path, re.I)
        return ("", m[1].lower()) if m else None
    if not (host == "reddit.com" or host.endswith(".reddit.com") or host in REDLIB):
        return None
    m = re.fullmatch(r"/r/([A-Za-z0-9_]{1,32})/comments/([a-z0-9]{4,13})(?:/[^?#]*)?", u.path, re.I)
    if m:
        return m[1], m[2].lower()
    m = re.fullmatch(r"/comments/([a-z0-9]{4,13})(?:/[^?#]*)?", u.path, re.I)
    return ("", m[1].lower()) if m else None


def ref_a_id(ref: str) -> str:
    """ID, t3_ID, URL de reddit.com/redd.it o de un espejo con la ruta /r/SUB/comments/ID → ID de post."""
    ref = ref.strip()
    m = RE_ID.match(ref)
    if m:
        return m.group(2).lower()
    p = extraer_post(ref)
    if p:
        return p[1]
    raise ValueError(f"no reconozco un hilo de Reddit en: {ref!r}")


def url_canonica(sub: str, pid: str) -> str:
    return f"https://www.reddit.com/r/{sub}/comments/{pid}/" if sub else f"https://www.reddit.com/comments/{pid}/"


# ============================================================================
# Circuit Breaker
# ============================================================================


@dataclass
class CircuitBreaker:
    """Protección por fuente contra fallos en cascada y límites de tasa.

    States:
        closed    — operación normal
        open      — demasiados fallos seguidos: se rechaza sin llamar hasta recovery_timeout
        half_open — se deja pasar una llamada de prueba; éxito → closed, fallo → open
    """

    nombre: str = "fuente"
    failure_threshold: int = 4
    recovery_timeout: float = 60.0

    _failure_count: int = field(default=0, init=False, repr=False)
    _state: str = field(default="closed", init=False, repr=False)
    _last_failure_time: float = field(default=0.0, init=False, repr=False)
    _pause_until: float = field(default=0.0, init=False, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    _generation: int = field(default=0, init=False, repr=False)

    def acquire(self):
        with self._lock:
            if time.time() < self._pause_until:
                return None
            if self._state == "closed":
                return self._generation
            if self._state == "open":
                if self._pause_until or time.time() - self._last_failure_time >= self.recovery_timeout:
                    self._state = "half_open"
                    return self._generation
            return None

    def can_execute(self) -> bool:
        return self.acquire() is not None

    def record_success(self, generation=None) -> None:
        with self._lock:
            if generation is not None and generation != self._generation:
                return
            if time.time() < self._pause_until:
                return
            self._failure_count = 0
            self._pause_until = 0.0
            self._state = "closed"

    def record_failure(self, generation=None) -> None:
        with self._lock:
            if generation is not None and generation != self._generation:
                return
            self._failure_count += 1
            self._last_failure_time = time.time()
            if self._state == "half_open" or self._failure_count >= self.failure_threshold:
                self._state = "open"
                self._generation += 1
                logger.warning("circuit %s ABIERTO tras %d fallos; recovery en %.0fs", self.nombre,
                               self._failure_count, self.recovery_timeout)

    def pause(self, hasta: float) -> None:
        with self._lock:
            self._pause_until = max(self._pause_until, hasta)
            self._last_failure_time = time.time()
            self._state = "open"
            self._generation += 1

    def restante(self):
        with self._lock:
            return max(0.0, self._pause_until - time.time())

    def pausa_activa(self) -> bool:
        with self._lock:
            return time.time() < self._pause_until

    def permiso_vigente(self, generation) -> bool:
        with self._lock:
            return generation == self._generation and self._state != "open" and time.time() >= self._pause_until

    def mensaje_pausa(self) -> str:
        if self._pause_until:
            return "fuente en pausa hasta " + datetime.fromtimestamp(self._pause_until, timezone.utc).isoformat()
        return f"fuente en pausa ({self.recovery_timeout:.0f}s)"

    @property
    def state(self) -> str:
        return self._state


# ============================================================================
# Retry con Backoff Exponencial
# ============================================================================

RETRYABLE = (408, 425, 429, 500, 502, 503, 504, 520, 521, 522, 523, 524)  # 52x: Cloudflare delante de Arctic/Redlib


def es_reintentable(e: Exception) -> bool:
    """429/5xx, red caída y el 422 «Timeout. Maybe slow down a bit» de Arctic Shift (intermitente, medido 7-oct-2026)."""
    if isinstance(e, HttpError):
        if e.code in RETRYABLE:
            return True
        return e.code == 422 and "timeout" in e.cuerpo.lower()
    return isinstance(e, (urllib.error.URLError, TimeoutError, ConnectionError, http.client.IncompleteRead))


def with_retry(fn: Callable[[], T], max_retries: int = 4, base_delay: float = 1.5, max_delay: float = 30.0,
               circuit_breaker: Optional[CircuitBreaker] = None, sleep: Callable[[float], None] = time.sleep) -> T:
    """Ejecuta fn con reintentos (backoff exponencial + jitter) y circuit breaker.

    Raises:
        RuntimeError: circuito abierto.
        Exception: el último error si no es reintentable o se agotan los intentos.
    """
    def permiso():
        if not circuit_breaker:
            return None
        restante = circuit_breaker.restante()
        if restante:
            if restante > 120:
                raise RuntimeError(circuit_breaker.mensaje_pausa())
            sleep(restante)
        token = circuit_breaker.acquire()
        if token is None:
            raise RuntimeError(redactar(f"circuito {circuit_breaker.nombre} abierto: {circuit_breaker.mensaje_pausa()}"))
        return token

    generation = permiso()
    for intento in range(max_retries):
        if circuit_breaker and not circuit_breaker.permiso_vigente(generation):
            generation = permiso()
        try:
            res = fn()
            if circuit_breaker:
                circuit_breaker.record_success(generation)
            return res
        except Exception as e:
            if isinstance(e, HttpError) and e.retry_after > 0:
                hasta = time.time() + e.retry_after
                if circuit_breaker:
                    circuit_breaker.pause(hasta)
                if e.retry_after > 120:
                    raise RuntimeError("fuente en pausa hasta " + datetime.fromtimestamp(hasta, timezone.utc).isoformat()) from None
            if es_reintentable(e) and intento < max_retries - 1:
                espera = min(base_delay * (2 ** intento) + random.uniform(0, 1), max_delay)
                if isinstance(e, HttpError) and e.code == 429:
                    espera = max(espera, 5.0)
                if isinstance(e, HttpError):
                    espera = max(espera, e.retry_after)
                logger.warning("reintento %d/%d en %.1fs (%s)", intento + 1, max_retries, espera, redactar(str(e))[:120])
                sleep(espera)
                if circuit_breaker and isinstance(e, HttpError) and e.retry_after > 0:
                    generation = permiso()
                continue
            if circuit_breaker:
                circuit_breaker.record_failure(generation)
            raise
    raise RuntimeError("reintentos agotados")  # pragma: no cover


# ============================================================================
# Modelos de datos
# ============================================================================


@dataclass
class Hilo:
    """Un hilo descubierto. fecha_verificada=True solo si created_utc viene de Arctic Shift o Redlib (no del buscador)."""

    id: str
    url: str
    subreddit: str = ""
    titulo: str = ""
    autor: str = ""
    created_utc: Optional[float] = None
    fecha: Optional[str] = None
    votos: Optional[int] = None
    num_comentarios: Optional[int] = None
    fecha_verificada: bool = False
    votos_provisionales: bool = True
    en_ventana: Optional[bool] = None
    relevancia: float = 0.0
    fuentes: List[str] = field(default_factory=list)
    fragmentos: List[Dict[str, str]] = field(default_factory=list)


@dataclass
class Comentario:
    id: str
    padre: str
    autor: str
    created_utc: Optional[float]
    fecha: Optional[str]
    votos: Optional[int]
    votos_fuente: str
    cuerpo: str
    profundidad: Optional[int]
    url: str
    editado: bool = False
    es_op: Optional[bool] = None
    es_bot: bool = False
    distinguido: Optional[str] = None  # moderator | admin
    cuerpo_fuente: str = "arctic-shift"
    retirado: bool = False
    identidad_verificada: bool = True
    representacion: str = "markdown"
    texto_reparado: bool = False
    redactado: bool = False
    cuerpo_capturado: Optional[str] = None  # texto que guardó Arctic Shift si el autor lo editó después
    # Tipo del padre: "t3" = el post (comentario raíz), "t1" = otro comentario, "?" = sin prefijo reconocible.
    # `padre` lleva solo el ID base36; sin el tipo, un comentario padre «t1_aaaa1» se confundiría con el post «t3_aaaa1».
    padre_tipo: str = "t1"
    # Comunidad conocida de la pieza (minúsculas; "" = desconocida). Entra en la política de duplicados y en la fusión
    # aunque el post no la declare: una señal recibida no se pierde al convertir.
    comunidad: str = ""


# ============================================================================
# Parser HTML de Redlib (marcado verificado el 7-oct-2026)
# ============================================================================


def _fecha_redlib(titulo: str) -> Optional[float]:
    """«Sep 30 2026, 17:46:40 UTC» → epoch."""
    try:
        return datetime.strptime(titulo.strip(), "%b %d %Y, %H:%M:%S UTC").replace(tzinfo=timezone.utc).timestamp()
    except (ValueError, AttributeError):
        return None


class RedlibParser(HTMLParser):
    """Extrae post y comentarios como texto renderizado de Redlib, conservando bloques de código."""

    BLOQUES = {"p", "li", "pre", "blockquote", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "table", "ul", "ol"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.post: Dict[str, Any] = {}
        self.comentarios: List[Dict[str, Any]] = []
        self._div = 0
        self._pila: List[Tuple[Dict[str, Any], int]] = []
        self._captura: Optional[Tuple[Dict[str, Any], str, int, str]] = None  # (destino, campo, nivel, etiqueta)
        self._buf: List[Any] = []
        self._pre_buf: List[str] = []
        self.identidades_comentarios: List[Optional[str]] = []
        self.identidades_hilo: List[Optional[str]] = []
        self.comunidades_hilo: List[str] = []  # comunidad de cada señal og/canonical que la trae
        # Identidad propia por comentario (id(dict) → (hilo, comentario) del primer enlace, o None si hubo contradicción).
        self._enlaces_propios: Dict[int, Optional[Tuple[Optional[str], Optional[str]]]] = {}
        self._og_presente = False
        self._en_post = False
        self._en_flair = 0
        self._texto_de: Optional[Tuple[Dict[str, Any], str, str]] = None  # (destino, campo, etiqueta de cierre)
        self._quote = 0
        self._li = 0
        self._pre = 0
        self._code = False
        self._code_buf = []
        self._visto_post = False

    @staticmethod
    def _clases(attrs: List[Tuple[str, Optional[str]]]) -> List[str]:
        return [x for v in _atributos(attrs)[1].get("class", []) for x in v.split()]

    def handle_starttag(self, tag: str, attrs: List[Tuple[str, Optional[str]]]) -> None:
        a, _, repetidos = _atributos(attrs)
        cls = self._clases(attrs)
        señal = _señal_identidad(tag, attrs)
        if señal:
            ref = _ref_relativa(señal[1]) if señal[1] is not None else None
            if señal[0] == "og":
                self._og_presente = True
                self.post["id"] = ref[1] if ref else None
            self.identidades_hilo.append(ref[1] if ref else None)
            if ref and ref[0]:
                self.comunidades_hilo.append(ref[0])
        # Solo los metadatos del comentario identifican; un enlace dentro del cuerpo (self._captura) nunca cuenta.
        propio = bool(self._pila) and ("created" in cls or "comment_link" in cls)
        if tag == "a" and self._captura is None and ("comment_link" in cls or propio):
            ambiguo = bool(repetidos & {"href", "class"})
            ref = None if ambiguo else _ref_relativa(a.get("href") or "")
            self.identidades_comentarios.append(ref[1] if ref else None)
            if propio:
                c = self._pila[-1][0]
                enlace = "" if ambiguo else (a.get("href") or "")
                identidad = (ref[1] if ref else None, _id_enlace_comentario(enlace) if ref else None)
                comunidad = _comunidad(ref[0]) if ref else ""
                clave = id(c)
                previo = self._enlaces_propios.get(clave, "nuevo")
                if previo == "nuevo":
                    self._enlaces_propios[clave] = identidad + (comunidad,)
                elif previo is None or previo[:2] != identidad or (previo[2] and comunidad and previo[2] != comunidad):
                    self._enlaces_propios[clave] = None  # contradicción (IDs o comunidad): irreversible
                elif comunidad and not previo[2]:
                    self._enlaces_propios[clave] = identidad + (comunidad,)
                if self._enlaces_propios[clave] is None or ambiguo:
                    self._enlaces_propios[clave] = None
                    c["enlace_propio"] = ""
                    c["identidad_verificada"] = False
                else:
                    # Un enlace sin comunidad no borra la comunidad ya conocida de otro enlace coherente.
                    anterior = _ref_relativa(c.get("enlace_propio") or "")
                    if not (anterior and anterior[0] and not comunidad):
                        c["enlace_propio"] = enlace
                    c["identidad_verificada"] = bool(ref and identidad[1] == c["id"])
        if self._en_post and "edited" in cls:
            self.post["editado"] = True
        if a.get("id") == "comment_count":
            self._texto_de = (self.post, "num_comentarios", tag)
        if self._en_post and tag == "a" and "post_comments" in cls:
            self._texto_de = (self.post, "num_comentarios", "a")
        actual = self._pila[-1][0] if self._pila else None
        if tag == "div":
            self._div += 1
            if "post" in cls and not self._visto_post:
                self._en_post = self._visto_post = True
            if "comment" in cls:
                c = {"id": "" if repetidos & {"id", "class"} else (a.get("id") or ""), "padre": actual["id"] if actual else None, "profundidad": len(self._pila),
                     "autor": "", "votos": None, "created_utc": None, "editado": False, "cuerpo": "",
                     "identidad_verificada": False}
                self.comentarios.append(c)
                self._pila.append((c, self._div))
                self._en_post = False
                return
            if "comment_body" in cls and actual is not None and self._captura is None:
                self._captura = (actual, "cuerpo", self._div, "div")
                self._buf = []
                self._li = 0
                return
            if "post_body" in cls and self._en_post and self._captura is None:
                self._captura = (self.post, "cuerpo", self._div, "div")
                self._buf = []
                self._li = 0
                return
        if self._captura:
            if self._code:
                if tag == "br":
                    self._code_buf.append("\n")
                return
            if self._pre:
                if tag == "br":
                    self._pre_buf.append("\n")
                return
            if tag in ("td", "th"):
                self._buf.append(" ")
            elif tag == "br":
                self._buf.append("\n")
            elif tag == "li":
                self._li += 1
                self._buf.append("\n" + ("> " * self._quote) + "- ")
            elif tag == "blockquote":
                self._quote += 1
                self._buf.append("\n")
            elif tag == "p" and self._quote:
                self._buf.append("\n" + self._prefijo_cita())
            elif tag == "code":
                if self._quote and self._buf and isinstance(self._buf[-1], str) and self._buf[-1].endswith("\n"):
                    self._buf.append(self._prefijo_cita())
                self._code = True
                self._code_buf = []
            elif tag == "pre":
                self._pre += 1
                self._pre_buf = []
                self._buf.append("\n\n")
            elif tag in self.BLOQUES:
                self._buf.append("\n")
            return
        if tag == "p" and "comment_score" in cls and actual is not None:
            actual["votos"] = _entero(a.get("title"))
        elif tag == "a" and "comment_author" in cls and actual is not None:
            self._texto_de = (actual, "autor", "a")
        elif tag == "a" and "created" in cls and actual is not None and actual["created_utc"] is None:
            actual["created_utc"] = _fecha_redlib(a.get("title") or "")
        elif tag == "span" and "edited" in cls and actual is not None:
            actual["editado"] = True
        elif self._en_post and not self._pila:
            if "post_subreddit" in cls:
                self._texto_de = (self.post, "subreddit", "a")
            elif "post_author" in cls:
                self._texto_de = (self.post, "autor", "a")
            elif tag == "span" and "created" in cls and "created_utc" not in self.post:
                self.post["created_utc"] = _fecha_redlib(a.get("title") or "")
            elif "post_score" in cls:
                self.post["votos"] = _entero(a.get("title"))
            elif tag == "h1" and "post_title" in cls:
                self._texto_de = (self.post, "titulo", "h1")
            elif "post_flair" in cls:
                self._en_flair += 1

    def handle_endtag(self, tag: str) -> None:
        if tag == "div":
            if self._captura and self._captura[2] == self._div:
                destino, campo, _, _ = self._captura
                destino[campo] = _normaliza_segmentos(self._buf)
                self._captura = None
            if self._pila and self._pila[-1][1] == self._div:
                self._pila.pop()
            self._div -= 1
            return
        if self._captura:
            if self._code:
                if tag == "code":
                    if self._quote and not self._pre:
                        texto = "".join(self._code_buf).replace("\n", "\n" + self._prefijo_cita())
                        self._buf.append((texto,))
                    else:
                        self._buf.append(tuple(self._code_buf))
                    self._code = False
                return
            if self._pre:
                if tag == "pre":
                    texto = "".join(self._pre_buf)
                    if self._quote:
                        texto = "\n".join(self._prefijo_cita() + l for l in texto.split("\n"))
                    self._buf.append((texto,))
                    self._pre = 0
                    self._buf.append("\n\n")
                return
            if tag == "blockquote" and self._quote:
                self._quote -= 1
                while self._buf and isinstance(self._buf[-1], str) and not self._buf[-1].strip():
                    self._buf.pop()
                if self._buf and self._buf[-1] == "\n>":
                    self._buf.pop()
                self._buf.append("\n")
            elif tag == "p" and self._quote:
                self._buf.append("\n" if self._li else "\n" + ">" * self._quote)
            elif tag == "li":
                self._li = max(0, self._li - 1)
                self._buf.append("\n")
            elif tag in self.BLOQUES:
                self._buf.append("\n")
            return
        if tag == "a" and self._en_flair:
            self._en_flair -= 1
            return
        if self._texto_de and tag == self._texto_de[2]:
            destino, campo, _ = self._texto_de
            destino[campo] = _normaliza(destino.get(campo, ""))
            if campo == "num_comentarios":
                m = re.search(r"[\d,]+", destino[campo])
                destino[campo] = _entero(m[0]) if m else None
            if campo == "autor":
                destino[campo] = destino[campo].removeprefix("u/")
            if campo == "subreddit":
                destino[campo] = destino[campo].removeprefix("r/")
            self._texto_de = None

    def handle_data(self, data: str) -> None:
        if self._captura:
            if self._code:
                self._code_buf.append(data)
            elif self._pre:
                self._pre_buf.append(data)  # código: espacios y saltos literales
            else:
                if self._li and self._quote and not data.strip() and self._buf and self._buf[-1] == "\n":
                    return
                if self._quote and data.strip() and self._buf and isinstance(self._buf[-1], str) and self._buf[-1].endswith("\n"):
                    self._buf.append(self._prefijo_cita())
                self._buf.append(data.replace("\n", " ") if data.strip() else " ")
        elif self._texto_de and not self._en_flair:
            destino, campo, _ = self._texto_de
            destino[campo] = destino.get(campo, "") + data

    def _prefijo_cita(self):
        return "> " * self._quote if self._li else ">" * self._quote + " "


def _entero(v: Any) -> Optional[int]:
    try:
        return int(str(v).strip().replace(",", ""))
    except (TypeError, ValueError):
        return None


def _normaliza(texto: str) -> str:
    """Normaliza espacios de prosa; nunca se aplica a segmentos pre."""
    lineas = [re.sub(r"[ \t ]+", " ", l).strip() for l in texto.replace("\r", "").split("\n")]
    out: List[str] = []
    for l in lineas:
        if l or (out and out[-1]):
            out.append(l)
    return "\n".join(out).strip()


def _ref_relativa(url):
    try:
        return extraer_post(urllib.parse.urljoin("https://www.reddit.com", url))
    except ValueError:
        return None


def _id_enlace_comentario(url):
    path = urllib.parse.urlsplit(url).path
    m = re.search(r"/comments/[a-z0-9]+/[^/]+/([a-z0-9]+)/?$", path, re.I)
    return m[1].lower() if m else None


def _normaliza_segmentos(segmentos):
    # Marcadores locales que no pueden colisionar con el contenido recibido.
    base = "CLAVEPROTEGIDA"
    completo = "".join("".join(x) if isinstance(x, tuple) else x for x in segmentos)
    while base in completo:
        base += "X"
    protegidos, partes = {}, []
    for segmento in segmentos:
        if isinstance(segmento, tuple):
            token = base + str(len(protegidos)) + "FIN"
            protegidos[token] = "".join(segmento)
            partes.append(token)
        else:
            partes.append(segmento)
    texto = _normaliza("".join(partes))
    for token, literal in protegidos.items():
        texto = texto.replace(token, literal)
    return texto


def _comunidad(nombre) -> str:
    return (nombre or "").strip().removeprefix("r/").removeprefix("/r/").lower() if isinstance(nombre, str) else ""


def _comunidades_redlib(red) -> set:
    """Comunidades que declara una página Redlib (señales og/canonical y metadato del post), en minúsculas."""
    p = red.get("post") or {}
    return {_comunidad(x) for x in list(red.get("comunidades_hilo") or []) + [p.get("subreddit")]} - {""}


def _comunidad_pagina(red) -> set:
    """Comunidad de una página Redlib ya validada: sus señales explícitas (og/canonical/metadato) o, sin ellas,
    la única de los enlaces propios de sus comentarios validados. La misma definición sirve al fallback y a la fusión."""
    return _comunidades_redlib(red) or {_comunidad_enlace(c) for c in red.get("comentarios") or []} - {""}


def _comunidad_enlace(c) -> str:
    ref = _ref_relativa(c.get("enlace_propio") or "") if isinstance(c, dict) else None
    return _comunidad(ref[0]) if ref else ""


def _validar_redlib(red, pid):
    p = _obj(_obj(red, "Redlib")["post"], "Redlib post")
    _objetos(red["comentarios"], "Redlib comentarios")
    señales = red.get("identidades_hilo", [])
    if not señales or any(x != pid for x in señales):
        raise ValueError("Redlib: identidad contradictoria para el hilo solicitado")
    comunidades = _comunidades_redlib(red)
    if len(comunidades) > 1:
        raise ValueError("Redlib: comunidad contradictoria para el hilo solicitado")
    enlaces = {_comunidad_enlace(c) for c in _objetos(red["comentarios"], "Redlib comentarios")} - {""}
    if not comunidades and len(enlaces) > 1:
        raise ValueError("Redlib: enlaces propios de comunidades distintas")
    # Comentario cuyo enlace propio declara otra comunidad: fuera, salvo su retirada por ID.
    ajenos = [c for c in red["comentarios"] if comunidades and _comunidad_enlace(c) and _comunidad_enlace(c) not in comunidades]
    for c in ajenos:  # su retirada, si la hay, ya consta en retiradas_ids
        red["comentarios"].remove(c)
        red["descartados_identidad"] = red.get("descartados_identidad", 0) + 1
    p["id"] = pid
    ids = list(red.get("identidades_comentarios", []))
    descartados = [c for c in red["comentarios"] if
                   not isinstance(c.get("id"), str) or not re.fullmatch(r"[a-z0-9]{4,13}", c["id"]) or
                   ("enlace_propio" in c and
                    (not c.get("identidad_verificada") or not _ref_relativa(c["enlace_propio"]) or
                     _ref_relativa(c["enlace_propio"])[1] != pid))]
    for c in descartados:
        ref = _ref_relativa(c.get("enlace_propio", ""))
        identidad = ref[1] if ref else None
        if identidad in ids:
            ids.remove(identidad)
    red["identidades_comentarios"] = ids
    red["descartados_identidad"] = red.get("descartados_identidad", 0) + len(descartados)
    red["comentarios"] = [c for c in red["comentarios"] if c not in descartados]
    _numero_metadato(p.get("votos"), "votos")
    _numero_metadato(p.get("num_comentarios"), "num_comentarios", no_negativo=True)
    for c in red["comentarios"]:
        _numero_metadato(c.get("votos"), "votos")
    if not p.get("titulo") and not red["comentarios"]:
        raise ValueError("Redlib: sin hilo")
    if any(x != pid for x in ids):
        raise ValueError("Redlib: identidad no verificada para el hilo solicitado")
    return red


def parse_redlib(html_texto: str) -> Dict[str, Any]:
    if not isinstance(html_texto, str):
        raise ValueError("Redlib: se esperaba HTML de texto")
    p = RedlibParser()
    p.feed(html_texto)
    p.close()
    if getattr(html_texto, "texto_reparado", False):
        p.post["texto_reparado"] = True
        for c in p.comentarios:
            c["texto_reparado"] = True
    validos = [c for c in p.comentarios if re.fullmatch(r"[a-z0-9]{4,13}", c["id"])]
    # Identidad LÓGICA: varias instancias del mismo ID solo se funden si todas tienen la misma identidad propia
    # verificada; si alguna difiere o no se verificó, el ID entero se descarta y cuenta (no se elige una en silencio).
    grupos: Dict[str, List[Dict[str, Any]]] = {}
    for c in validos:
        grupos.setdefault(c["id"], []).append(c)

    def firma(c):
        ref = _ref_relativa(c.get("enlace_propio") or "")
        return (c.get("identidad_verificada"), ref[1] if ref else None, _id_enlace_comentario(c.get("enlace_propio") or ""),
                _comunidad(ref[0]) if ref else "")

    def campo(c, nombre):
        if nombre == "padre_tipo":
            return "t1" if c.get("padre") else "t3"
        if nombre == "retirado":
            return es_retirado(c.get("cuerpo"))
        return c.get(nombre)

    elegidos, ambiguos, incompatibles = {}, set(), 0
    for cid, g in grupos.items():
        if len(g) > 1 and (len({firma(c) for c in g}) > 1 or not all(c.get("identidad_verificada") for c in g)):
            ambiguos.add(cid)
            continue
        elegida, n = _fundir_instancias(g, campo, lambda c, faltan: dict(
            c, **{k: v for k, v in faltan.items() if k == "created_utc"}))
        if elegida is None:
            incompatibles += n
        else:
            elegidos[cid] = elegida
    unicos = [c for c in validos if c["id"] not in ambiguos]
    primeras = {}
    for c in p.comentarios:
        primeras.setdefault(c["id"], c)
    return {"post": p.post, "comentarios": [elegidos[c["id"]] for c in p.comentarios
                                            if c["id"] in elegidos and primeras[c["id"]] is c],
            "descartados_identidad": len(p.comentarios) - len(unicos),
            "duplicados_incompatibles": incompatibles,
            # Retiradas por ID de CUALQUIER contenedor, aunque se descarte por identidad o comunidad: se aplican siempre
            # en la fusión (conservador: como mucho oculta una pieza; nunca entrega lo retirado).
            "retiradas_ids": {c["id"]: c["cuerpo"] for c in validos if es_retirado(c.get("cuerpo"))},
            "og_presente": p._og_presente, "identidades_hilo": p.identidades_hilo, "comunidades_hilo": p.comunidades_hilo,
            "identidades_comentarios": p.identidades_comentarios}


def _atributos(attrs) -> Tuple[Dict[str, str], Dict[str, List[str]], set]:
    """Atributos de una etiqueta sin perder repeticiones (HTML malformado).

    Devuelve (último valor por nombre, todos los valores por nombre, nombres repetidos). Las señales de identidad se
    deciden con TODOS los valores: un dict normal se queda con el último y esconde la contradicción.
    """
    todos: Dict[str, List[str]] = {}
    for k, v in attrs:
        todos.setdefault((k or "").lower(), []).append(v or "")
    return {k: v[-1] for k, v in todos.items()}, todos, {k for k, v in todos.items() if len(v) > 1}


def _señal_identidad(tag, attrs) -> Optional[Tuple[str, Optional[str]]]:
    """(tipo, url) si la etiqueta es una señal de identidad de hilo; url None si es ambigua por atributos repetidos."""
    _, todos, rep = _atributos(attrs)
    if tag == "meta" and any(v.lower() == "og:url" for v in todos.get("property", [])):
        return ("og", None if rep & {"property", "content"} else (todos.get("content") or [""])[0])
    if tag == "link" and any("canonical" in v.lower().split() for v in todos.get("rel", [])):
        return ("canonical", None if rep & {"rel", "href"} else (todos.get("href") or [""])[0])
    return None


class _IdentidadHTML(HTMLParser):
    def __init__(self):
        super().__init__()
        self.urls = []

    def handle_starttag(self, tag, attrs):
        señal = _señal_identidad(tag, attrs)
        if señal:
            self.urls.append(señal[1] or "")  # ambigua → URL vacía → identidad rechazada
            return
        _, todos, rep = _atributos(attrs)
        marcas = [m for v in todos.get("class", []) + todos.get("rel", []) for m in v.lower().split()]
        if tag == "a" and "permalink" in marcas:
            self.urls.append("" if rep & {"class", "rel", "href"} else (todos.get("href") or [""])[0])


def html_a_texto(h: str) -> str:
    """HTML → texto plano (para Wayback). Sin dependencias."""
    h = re.sub(r"(?is)<(script|style|noscript)[^>]*>.*?</\1>", " ", h)
    h = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</li>|</h\d>", "\n", h)
    h = re.sub(r"(?s)<[^>]+>", " ", h)
    return _normaliza(html.unescape(h))


# ============================================================================
# RedditHelper
# ============================================================================


class _TextoHTTP(str):
    texto_reparado = False


def _decodificar(raw):
    try:
        return _TextoHTTP(raw.decode("utf-8"))
    except UnicodeDecodeError:
        texto = _TextoHTTP(raw.decode("utf-8", "replace"))
        texto.texto_reparado = True
        return texto


def _marcar_reparado(valor):
    if isinstance(valor, dict):
        valor["texto_reparado"] = True
        for x in list(valor.values()):
            _marcar_reparado(x)
    elif isinstance(valor, list):
        for x in valor:
            _marcar_reparado(x)


MAX_RESPUESTA = 64 * 1024 * 1024  # bytes, también tras descomprimir (un árbol enorme de Arctic ronda pocos MB)


def _leer_acotado(r: Any, gzip_declarado: bool, url: str) -> bytes:
    """Lee como mucho MAX_RESPUESTA bytes y descomprime gzip con el mismo tope. Si se supera, HttpError 413
    (no reintentable): nunca se entrega una respuesta truncada como si fuera completa."""
    raw = r.read(MAX_RESPUESTA + 1) or b""
    if len(raw) > MAX_RESPUESTA:
        raise HttpError(413, f"respuesta mayor de {MAX_RESPUESTA // 2 ** 20} MB; descartada", url)
    if not (gzip_declarado or raw[:2] == b"\x1f\x8b"):
        return raw
    d = zlib.decompressobj(16 + zlib.MAX_WBITS)
    out = d.decompress(raw, MAX_RESPUESTA + 1)
    if len(out) > MAX_RESPUESTA or d.unconsumed_tail:
        raise HttpError(413, f"respuesta descomprimida mayor de {MAX_RESPUESTA // 2 ** 20} MB; descartada", url)
    if not d.eof:
        raise EOFError("gzip incompleto")
    return out


def _validar_cuerpo(fuente: str) -> Callable[[Any], Any]:
    """200 con cuerpo de error → HttpError(502), reintentable (Firecrawl `success:false`, Arctic `{"error": …}`)."""
    def validar(valor: Any) -> Any:
        if isinstance(valor, dict):
            if fuente == "firecrawl" and valor.get("success") is False:
                raise HttpError(502, "Firecrawl success:false: " + str(valor.get("error") or "sin detalle")[:200], fuente)
            if fuente == "arctic" and valor.get("error") not in (None, "") and not valor.get("data"):
                raise HttpError(502, "Arctic error: " + str(valor["error"])[:200], fuente)
        return valor
    return validar


def _mas_resultados_brave(d: Dict[str, Any]) -> bool:
    """Brave declara la existencia de más resultados en query.more_results_available (no hay `has_more`)."""
    q = d.get("query")
    return isinstance(q, dict) and q.get("more_results_available") is True


class _RedirectSeguro(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        origen, destino = urllib.parse.urlsplit(req.full_url), urllib.parse.urlsplit(newurl)
        def autoridad(p):
            return (p.scheme.lower(), p.hostname, p.port if p.port is not None else
                    (443 if p.scheme.lower() == "https" else 80))
        credencial = any(k.lower() in {"authorization", "x-subscription-token", "x-api-key"}
                         for k, _ in req.header_items())
        degradada = origen.scheme.lower() == "https" and destino.scheme.lower() != "https"  # nunca https → http
        if degradada or (credencial and autoridad(origen) != autoridad(destino)) or origen.hostname != destino.hostname:
            raise urllib.error.HTTPError(req.full_url, code, "redirect fuera del origen autorizado", headers, fp)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class RedditHelper:
    """Pipeline de investigación en Reddit. Cada fuente tiene su CircuitBreaker; toda llamada pasa por with_retry.

    salida: carpeta donde se guardan índices, hilos y corpus. El crudo de cada respuesta solo con guardar_crudo=True
    (depuración): es la respuesta íntegra de la fuente y puede contener texto que hoy está retirado.
    """

    def __init__(self, salida: Optional[Path] = None, guardar_crudo: bool = False, timeout: float = 60.0):
        _registrar_claves()
        _zona()
        self.salida = Path(salida or os.environ.get("REDDIT_SEARCH_SALIDA") or (Path.cwd() / "reddit-salida"))
        self.guardar_crudo = guardar_crudo
        self.timeout = timeout
        self.cb: Dict[str, CircuitBreaker] = {}
        self.avisos: List[str] = []
        self._lock = threading.Lock()

    # ─── HTTP ──────────────────────────────────────────────────────────────

    def _breaker(self, nombre: str) -> CircuitBreaker:
        with self._lock:
            if nombre not in self.cb:
                self.cb[nombre] = CircuitBreaker(nombre=nombre)
            return self.cb[nombre]

    def _http(self, fuente: str, url: str, cuerpo: Any = None, cabeceras: Optional[Dict[str, str]] = None,
              json_resp: bool = True, reintentos: int = 4, procesar: Optional[Callable[[Any], Any]] = None) -> Any:
        """GET/POST con reintentos. `procesar` interpreta la respuesta dentro del intento: si lanza un HttpError
        reintentable (p. ej. 200 con cuerpo de error), se reintenta y el circuito lo cuenta como fallo."""
        procesar = procesar or _validar_cuerpo(fuente)
        opener = urllib.request.build_opener(_RedirectSeguro())
        def llamada() -> Any:
            datos = json.dumps(cuerpo).encode() if cuerpo is not None else None
            h = {"User-Agent": UA, "Accept": "application/json" if json_resp else "text/html,*/*", "Accept-Encoding": "gzip"}
            if datos is not None:
                h["Content-Type"] = "application/json"
            h.update(cabeceras or {})
            req = urllib.request.Request(url, data=datos, headers=h, method="POST" if datos is not None else "GET")
            try:
                try:
                    with opener.open(req, timeout=self.timeout) as r:
                        raw = _leer_acotado(r, r.headers.get("Content-Encoding") == "gzip", url)
                        ctype = r.headers.get("Content-Type", "")
                except urllib.error.HTTPError as e:
                    code = e.code
                    retry_after = _retry_after((e.headers or {}).get("Retry-After", ""))
                    try:
                        try:
                            raw = _leer_acotado(e, (e.headers or {}).get("Content-Encoding") == "gzip", url)
                            detalle = str(_decodificar(raw))
                        except (OSError, EOFError, zlib.error, http.client.IncompleteRead, HttpError) as fallo:
                            detalle = f"cuerpo de error inválido o demasiado grande ({type(fallo).__name__})"
                    finally:
                        e.close()
                    if fuente == "you" and code == 402:
                        self._pausar_you()
                        detalle = "cuota You agotada; fuente en pausa hasta las próximas 00:00 UTC: " + detalle
                    raise HttpError(code, detalle, url, retry_after) from None
                texto = _decodificar(raw)
                if not json_resp:
                    return procesar(texto)
                if "json" not in ctype and not texto.lstrip().startswith(("{", "[")):
                    raise HttpError(502, f"respuesta no JSON ({ctype})", url)
                valor = json.loads(texto)
                if texto.texto_reparado:
                    _marcar_reparado(valor)
                return procesar(valor)
            except (json.JSONDecodeError, EOFError, gzip.BadGzipFile, zlib.error, http.client.IncompleteRead) as e:
                raise HttpError(502, f"respuesta de transporte inválida ({type(e).__name__})", url) from None

        return with_retry(llamada, max_retries=reintentos, circuit_breaker=self._breaker(fuente))

    def _crudo(self, carpeta: Path, tipo: str, clave_txt: str, peticion: Any, respuesta: Any) -> None:
        if not self.guardar_crudo:
            return
        d = carpeta / "crudo"
        d.mkdir(parents=True, exist_ok=True)
        nombre = f"{time.strftime('%H%M%S')}_{tipo}_{hashlib.sha1(clave_txt.encode()).hexdigest()[:8]}.json"
        _guardar_texto(d.joinpath(nombre), _json_seguro({"tipo": tipo, "peticion": peticion, "utc": datetime.now(timezone.utc).isoformat(),
                                                  "respuesta": respuesta}, indent=1))

    # ─── Descubrir: fuentes ───────────────────────────────────────────────

    def buscar_brave(self, tema: str, ventana: str, n: int = 20, sub: Optional[str] = None) -> Dict[str, Any]:
        """Brave Web Search: site:reddit.com + freshness + extra_snippets. Docs: api-dashboard.search.brave.com (7-oct-2026)."""
        _limite(n, "n")
        if n == 0:
            return {"peticion": None, "crudo": None, "resultados": [], "truncado": False}
        # Con sub: el nombre va como TÉRMINO (site:reddit.com/r/SUB dio 0 en varias pruebas del 7-oct-2026) y se filtra por URL.
        q = {"q": f"site:reddit.com {sub + ' ' if sub else ''}{tema}", "count": min(n, 20), "extra_snippets": "true",
             "result_filter": "web,discussions"}
        if ventana in BRAVE_FRESH:
            q["freshness"] = BRAVE_FRESH[ventana]
        url = "https://api.search.brave.com/res/v1/web/search?" + urllib.parse.urlencode(q)
        d = self._http("brave", url, cabeceras={"X-Subscription-Token": clave("BRAVE_SEARCH_API_KEY")})
        d = _obj(d, "Brave")
        res = []
        for r in _objetos(_obj(d.get("web", {}), "Brave web").get("results", []), "Brave results"):
            _cadena(r.get("url", ""), "Brave URL")
            _cadena(r.get("title", ""), "Brave title")
            _cadena(r.get("description", ""), "Brave description")
            snippets = _snippets(r.get("extra_snippets", []))
            qa = _obj(r.get("qa", {}), "Brave qa")
            partes = [r.get("description", "")] + snippets
            if (qa.get("question") or ""):
                partes.append("POST: " + html.unescape(re.sub(r"<[^>]+>", " ", _cadena(qa["question"], "Brave question"))))
            answer = _obj(qa.get("answer", {}), "Brave answer")
            if answer.get("text"):
                partes.append("RESPUESTA: " + html.unescape(re.sub(r"<[^>]+>", " ", _cadena(answer["text"], "Brave answer"))))
            res.append({"url": r.get("url", ""), "titulo": r.get("title", ""), "edad": r.get("age") or r.get("page_age"),
                        "texto": " … ".join(x for x in partes if x)})
        for r in _objetos(_obj(d.get("discussions", {}), "Brave discussions").get("results", [])):
            dd = _obj(r.get("data", {}))
            res.append({"url": r.get("url", ""), "titulo": dd.get("title", ""), "edad": r.get("age"),
                        "texto": " … ".join(_cadena(x, "Brave discussion") for x in (dd.get("question"), dd.get("top_comment")) if x is not None and x != "")})
        res = _validar_resultados(res, bool(d.get("texto_reparado")))
        if sub:
            res = [r for r in res if f"/r/{sub.lower()}/" in r["url"].lower()]
        return {"peticion": q, "crudo": d, "resultados": _validar_resultados(res, bool(d.get("texto_reparado"))), "truncado": n > q["count"] or _mas_resultados_brave(d)}

    def buscar_perplexity(self, tema: str, ventana: str, n: int = 20, sub: Optional[str] = None) -> Dict[str, Any]:
        """Perplexity Search API (POST /search), NO Sonar (sin soporte desde 27-sep-2026). Docs: docs.perplexity.ai/docs/search."""
        _limite(n, "n")
        if n == 0:
            return {"peticion": None, "crudo": None, "resultados": [], "truncado": False}
        b: Dict[str, Any] = {"query": tema + (f" r/{sub}" if sub else ""), "search_domain_filter": ["reddit.com"],
                             "max_results": min(n, 20), "max_tokens_per_page": 1024}
        if ventana in PPLX_RECENCY:
            b["search_recency_filter"] = PPLX_RECENCY[ventana]
        d = self._http("perplexity", "https://api.perplexity.ai/search", b,
                       {"Authorization": f"Bearer {clave('PERPLEXITY_API_KEY')}"})
        crudos = _objetos(_obj(d, "Perplexity").get("results", []))
        res = [{"url": r.get("url", ""), "titulo": r.get("title", ""), "edad": r.get("date"), "texto": _cadena(r["snippet"], "Perplexity snippet", no_vacia=True) if "snippet" in r else ""}
               for r in crudos]
        # Página llena (recuento crudo, antes de filtros): puede haber más resultados que no se pidieron.
        return {"peticion": b, "crudo": d, "resultados": _validar_resultados(res, bool(d.get("texto_reparado"))), "truncado": n > b["max_results"] or len(crudos) >= b["max_results"]}

    def buscar_firecrawl(self, tema: str, ventana: str, n: int = 20, sub: Optional[str] = None) -> Dict[str, Any]:
        """Firecrawl /v2/search con site: y tbs (qdr:d|w|m|y; aplica solo a sources=web). 2 créditos por cada 10 resultados."""
        _limite(n, "n")
        if n == 0:
            return {"peticion": None, "crudo": None, "resultados": [], "truncado": False}
        b: Dict[str, Any] = {"query": f"site:reddit.com{'/r/' + sub if sub else ''} {tema}", "limit": min(n, 20), "sources": ["web"]}
        if ventana in FIRE_TBS:
            b["tbs"] = FIRE_TBS[ventana]
        d = self._http("firecrawl", "https://api.firecrawl.dev/v2/search", b,
                       {"Authorization": f"Bearer {clave('FIRECRAWL_API_KEY')}"}, reintentos=3)
        web = _objetos(_obj(_obj(d, "Firecrawl").get("data", {})).get("web", []))
        res = [{"url": r.get("url", ""), "titulo": r.get("title", ""), "edad": None, "texto": r.get("description", "")} for r in web]
        return {"peticion": b, "crudo": d, "resultados": _validar_resultados(res, bool(d.get("texto_reparado"))), "truncado": n > b["limit"] or len(web) >= b["limit"]}

    def _pausar_you(self):
        siguiente = (math.floor(time.time() / 86400) + 1) * 86400
        self._breaker("you").pause(siguiente)

    def _carga_you(self, sse: Any, id_peticion: int) -> Dict[str, Any]:
        """Respuesta JSON o SSE de You.com MCP → carga de resultados. Un error JSON-RPC lanza HttpError (402 cuota, 502 resto)."""
        mensajes = []
        if isinstance(sse, dict):
            mensajes = [sse]
        elif isinstance(sse, str) and sse.lstrip().startswith("{"):
            mensajes = [json.loads(sse)]
        elif isinstance(sse, str):
            # SSE permite varios campos data por evento.
            datos = []
            for linea in sse.splitlines() + [""]:
                if linea.startswith("data:"):
                    datos.append(linea[5:].lstrip())
                elif not linea and datos:
                    mensajes.append(json.loads("\n".join(datos)))
                    datos = []
        else:
            raise ValueError("You: se esperaba JSON o SSE")
        d = None
        for msg in mensajes:
            msg = _obj(msg, "You JSON-RPC")
            if "error" in msg or "result" in msg:
                if msg.get("jsonrpc") != "2.0" or type(msg.get("id")) is not type(id_peticion) or msg.get("id") != id_peticion:
                    raise ValueError("You: id JSON-RPC no coincide con la petición")
            if msg.get("error"):
                detalle = json.dumps(msg["error"], ensure_ascii=False)
                prefijo = "cuota You agotada: " if re.search(r"quota|cuota|rate.?limit|429|402", detalle, re.I) else "error You: "
                if prefijo.startswith("cuota"):
                    self._pausar_you()
                    raise HttpError(402, prefijo + detalle + "; pausa hasta las próximas 00:00 UTC", "you.com")
                raise HttpError(502, prefijo + detalle, "you.com")
            if "result" not in msg:
                continue  # notificaciones SSE
            resultado = _obj(msg["result"], "You result")
            if resultado.get("isError"):
                detalle = json.dumps(resultado, ensure_ascii=False)
                prefijo = "cuota You agotada: " if re.search(r"quota|cuota|rate.?limit|429|402", detalle, re.I) else "error You: "
                if prefijo.startswith("cuota"):
                    self._pausar_you()
                    raise HttpError(402, prefijo + detalle + "; pausa hasta las próximas 00:00 UTC", "you.com")
                raise HttpError(502, prefijo + detalle, "you.com")
            for c in _objetos(resultado.get("content", []), "You content"):
                if c.get("type") == "text":
                    d = _obj(json.loads(c.get("text", "")), "You payload")
        if d is not None and getattr(sse, "texto_reparado", False):
            _marcar_reparado(d)
        if d is None or "results" not in d:
            raise ValueError("You: respuesta sin resultados de búsqueda")
        return d

    def buscar_you(self, tema: str, ventana: str, n: int = 10, sub: Optional[str] = None, reintentos: int = 2) -> Dict[str, Any]:
        """You.com MCP gratuito (sin clave, 100 consultas/día; probado 7-oct-2026): you-search con highlights literales."""
        _limite(n, "n")
        if n == 0:
            return {"peticion": None, "crudo": None, "resultados": [], "truncado": False}
        args: Dict[str, Any] = {"query": f"site:reddit.com {sub + ' ' if sub else ''}{tema}", "count": min(n, 20),
                                "extraction": "highlights"}
        if ventana in PPLX_RECENCY:
            args["freshness"] = PPLX_RECENCY[ventana]
        cuerpo = {"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "you-search", "arguments": args}}
        # El JSON-RPC se interpreta DENTRO de la operación reintentable: un 200 con error es un fallo, no un éxito.
        d = self._http("you", "https://api.you.com/mcp?profile=free", cuerpo, {"Accept": "application/json, text/event-stream"},
                       json_resp=False, reintentos=reintentos, procesar=lambda sse: self._carga_you(sse, cuerpo["id"]))
        if not (isinstance(d, dict) and "results" in d):  # transporte sustituto que no aplica `procesar`
            d = self._carga_you(d, cuerpo["id"])
        res = []
        crudos = _objetos(_obj(d["results"], "You results").get("web", []))
        for r in crudos:
            _cadena(r.get("url", ""), "You URL")
            _cadena(r.get("title", ""), "You title")
            hl = _snippets(_obj(r.get("contents", {})).get("highlights", []))
            _cadena(r.get("description", ""), "You description")
            res.append({"url": r.get("url", ""), "titulo": r.get("title", ""), "edad": r.get("page_age"),
                        "texto": " … ".join([r.get("description", "")] + hl)})
        res = _validar_resultados(res, bool(d.get("texto_reparado")))
        if sub:
            res = [r for r in res if f"/r/{sub.lower()}/" in r["url"].lower()]
        return {"peticion": args, "crudo": d, "resultados": _validar_resultados(res, bool(d.get("texto_reparado"))), "truncado": n > args["count"] or len(crudos) >= args["count"]}

    def buscar_arctic(self, tema: str, ventana: str, n: int = 25, sub: Optional[str] = None) -> Dict[str, Any]:
        """Arctic Shift /posts/search por subreddit (sin subreddit `query` da 400). Fechas exactas; índice casi en tiempo real."""
        _limite(n, "n")
        if n == 0:
            return {"peticion": None, "crudo": None, "resultados": [], "truncado": False}
        if not sub:
            return {"peticion": None, "crudo": None, "resultados": []}
        q: Dict[str, Any] = {"subreddit": sub, "query": tema, "limit": min(n, 100), "sort": "desc"}
        dias = VENTANAS.get(ventana)
        if dias:
            q["after"] = datetime.fromtimestamp(ahora() - dias * 86400, timezone.utc).strftime("%Y-%m-%d")
        muestra_limitada = False
        try:
            d = self._http("arctic", f"{ARCTIC}/posts/search?" + urllib.parse.urlencode(q), reintentos=3)
            datos = _lista(_obj(d, "Arctic").get("data", []))
        except HttpError as e:
            # La búsqueda de texto con varias palabras satura (422 «Timeout»): se listan los posts recientes del subreddit
            # (consulta barata) y se filtran aquí por los términos. Cubre la pasada «New» del subreddit.
            if e.code != 422:
                raise
            q = {k: v for k, v in q.items() if k != "query"}
            q["limit"] = 100
            d = self._http("arctic", f"{ARCTIC}/posts/search?" + urllib.parse.urlencode(q), reintentos=3)
            datos = _lista(_obj(d, "Arctic").get("data", []))
            q["filtro_local"] = tema
            muestra_limitada = True
        res = []
        descartados_datos = 0
        validos = []
        for p in datos:
            try:
                p = _admitir_submission(_obj(p, "Arctic post de búsqueda"))
                _epoch(p.get("created_utc"))
                validos.append(p)
            except (ValueError, TypeError, OverflowError) as e:
                descartados_datos += 1
                self.avisos.append(redactar(f"Arctic: registro inválido de búsqueda omitido: {e}"))
        for p in _fundir_submissions(validos, self.avisos).values():  # una por post; incompatibles fuera
            try:
                if muestra_limitada and relevancia(tema, f"{p.get('title', '')} {p.get('selftext', '')}") < UMBRAL_FILTRO_LOCAL:
                    continue
                retirado = bool(_campo_submission(p, "retirado"))
                # Post retirado (tombstone o removed_by_category): su texto vivo no llega a fragmentos.
                texto = (p.get("selftext") if es_retirado(p.get("selftext")) else "") if retirado else (p.get("selftext") or "")
                seguro = redactar(texto)
                res.append({"url": url_canonica(p.get("subreddit") or _campo_submission(p, "comunidad") or sub or "", p["id"]),
                            "titulo": p.get("title", ""),
                            "edad": iso_local(p.get("created_utc")), "texto": seguro[:600],
                            "redactado": seguro != texto, "retirado": retirado, "_post": p})
            except (ValueError, TypeError, OverflowError) as e:
                descartados_datos += 1
                self.avisos.append(redactar(f"Arctic: registro inválido de búsqueda omitido: {e}"))
        return {"peticion": q, "crudo": d, "resultados": _validar_resultados(res[:n], bool(d.get("texto_reparado"))), "descartados_datos": descartados_datos, "muestra_limitada": muestra_limitada, "truncado": muestra_limitada or len(res) > n or n > q["limit"] or len(datos) >= q["limit"]}

    # ─── Descubrir: orquestación ──────────────────────────────────────────

    def descubrir(self, tema: str, ventanas: Iterable[str] = ("w", "m"), fuentes: Optional[Iterable[str]] = None,
                  subs: Iterable[str] = (), n: int = 20, mas_urls: Iterable[str] = (), carpeta: Optional[Path] = None,
                  orden: str = "fecha") -> Dict[str, Any]:
        """Lanza todas las fuentes × ventanas × subreddits en paralelo, deduplica por ID de post e hidrata en Arctic Shift.

        Devuelve el índice (también en <carpeta>/indice.json): hilos ordenados por en_ventana, fecha y votos.
        """
        _limite(n, "n")
        ventanas = list(ventanas)
        if not ventanas or any(v not in VENTANAS for v in ventanas):
            raise ValueError("ventana inválida: use d,w,m,y,todo")
        modo = modo_busqueda()
        fuentes = list(fuentes) if fuentes is not None else ["you", "arctic"] + [
            f for f, nombre in PROVEEDORES_EXPERTOS.items() if nombre in modo["configuradas"]]
        subs = [s.removeprefix("r/") for s in subs if s]
        carpeta = carpeta or self.salida / f"{datetime.now(_zona()).strftime('%Y%m%d-%H%M')}_{slug(tema)}"
        carpeta.mkdir(parents=True, exist_ok=True)
        tareas: List[Tuple[str, str, Optional[str]]] = []
        for f in fuentes:
            for v in ventanas:
                if f == "arctic":
                    tareas += [(f, v, s) for s in subs]
                else:
                    tareas.append((f, v, None))
                    tareas += [(f, v, s) for s in subs]
        funcs = {"brave": self.buscar_brave, "perplexity": self.buscar_perplexity, "firecrawl": self.buscar_firecrawl,
                 "you": self.buscar_you, "arctic": self.buscar_arctic}
        estado: Dict[str, Dict[str, Any]] = {}
        hilos: Dict[str, Hilo] = {}

        def correr(t: Tuple[str, str, Optional[str]]) -> Tuple[Tuple[str, str, Optional[str]], Any]:
            f, v, s = t
            try:
                return t, funcs[f](tema, v, n, s)
            except Exception as e:  # noqa: BLE001 — una fuente caída no tumba el resto
                return t, e

        with ThreadPoolExecutor(max_workers=6) as ex:
            for (f, v, s), r in ex.map(correr, tareas):
                etiqueta = f"{f}:{v}{'/r/' + s if s else ''}"
                if isinstance(r, Exception):
                    estado[etiqueta] = {"ok": False, "error": redactar(str(r))[:300]}
                    continue
                self._crudo(carpeta, f, etiqueta + tema, r["peticion"], r["crudo"])
                nuevos = 0
                for x in r["resultados"]:
                    p = extraer_post(x["url"])
                    if not p:
                        continue
                    sub, pid = p
                    h = hilos.get(pid)
                    if h is None:
                        h = hilos[pid] = Hilo(id=pid, url=url_canonica(sub, pid), subreddit=sub, titulo=x.get("titulo", ""))
                        nuevos += 1
                    if etiqueta not in h.fuentes:
                        h.fuentes.append(etiqueta)
                    if x.get("texto"):
                        x = _sanear(x)
                        # Solo para triage: Perplexity reformula sus snippets y ningún fragmento trae autor ni fecha fiables.
                        h.fragmentos.append({"fuente": etiqueta, "edad_reportada": str(x.get("edad") or ""), "citable": False,
                                             "texto": x["texto"][:1500], "texto_reparado": bool(x.get("texto_reparado")),
                                             "redactado": bool(x.get("redactado"))})
                estado[etiqueta] = {"ok": True, "resultados": len(r["resultados"]), "hilos_nuevos": nuevos,
                                    "truncado": r.get("truncado", False), "muestra_limitada": r.get("muestra_limitada", False),
                                    "descartados_datos": r.get("descartados_datos", 0)}
        for u in mas_urls:
            p = extraer_post(u)
            if p and p[1] not in hilos:
                hilos[p[1]] = Hilo(id=p[1], url=url_canonica(*p), subreddit=p[0], fuentes=["agente"])
            elif p:
                hilos[p[1]].fuentes.append("agente")
        self._hidratar(list(hilos.values()), carpeta)
        dias = max((VENTANAS[v] or 10 ** 6) for v in ventanas)
        fin = ahora()
        corte = fin - dias * 86400
        for h in hilos.values():
            h.relevancia = relevancia(tema, " ".join([h.titulo] + [f["texto"] for f in h.fragmentos]))
            h.created_utc = _epoch(h.created_utc)
            h.en_ventana = (corte <= h.created_utc <= fin) if h.created_utc is not None else None
        claves_orden = {"fecha": lambda h: (h.en_ventana is not True, -(h.created_utc or 0), -(h.votos or 0)),
                        "relevancia": lambda h: (h.en_ventana is not True, -h.relevancia, -(h.created_utc or 0)),
                        "votos": lambda h: (h.en_ventana is not True, -(h.votos or 0), -(h.created_utc or 0))}
        orden = sorted(hilos.values(), key=claves_orden.get(orden, claves_orden["fecha"]))
        indice = {"tema": tema, "ventanas": ventanas, "subs": subs, "generado": datetime.now(_zona()).isoformat(),
                  "fuentes": estado, "total_hilos": len(orden),
                  "en_ventana": sum(1 for h in orden if h.en_ventana), "fecha_sin_verificar": sum(1 for h in orden if not h.fecha_verificada),
                  "avisos": self.avisos, "hilos": [asdict(h) for h in orden], "carpeta": str(carpeta)}
        indice["modo"] = modo["modo"]
        indice["fuentes_no_configuradas"] = [f for f, nombre in PROVEEDORES_EXPERTOS.items() if nombre in modo["faltan"]]
        if modo["modo"] != "experto":
            indice["aviso_modo_experto"] = AVISO_MODO_EXPERTO
        if "arctic" in fuentes and not subs:
            indice["avisos"] = list(self.avisos) + ["Arctic Shift no busca por texto sin subreddit: pasa 2-5 --sub"]
        indice = _sanear(indice)
        _guardar_texto(carpeta / "indice.json", _json_seguro(indice, indent=1))
        return indice

    def _hidratar(self, hilos: List[Hilo], carpeta: Path) -> None:
        """Fecha, autor, votos y nº de comentarios desde Arctic Shift /posts/ids (lotes de 100)."""
        ids = [h.id for h in hilos]
        por_id = {h.id: h for h in hilos}
        for i in range(0, len(ids), 100):
            trozo = ids[i:i + 100]
            try:
                d = self._http("arctic", f"{ARCTIC}/posts/ids?ids=" + ",".join(trozo))
            except Exception as e:  # noqa: BLE001
                self.avisos.append(f"Arctic Shift no hidrató {len(trozo)} hilos: {redactar(str(e))[:160]} — fechas SIN verificar")
                continue
            self._crudo(carpeta, "hidratar", ",".join(trozo), {"ids": trozo}, d)
            try:
                registros = _lista(_obj(d, "Arctic").get("data", []))
            except ValueError as e:
                self.avisos.append(f"Arctic: lote de hidratación inválido: {e}")
                continue
            validos = []
            for registro in registros:
                try:
                    admitido = _admitir_submission(registro)
                    _epoch(admitido.get("created_utc"))
                    validos.append(admitido)
                except (ValueError, TypeError, OverflowError) as e:
                    self.avisos.append(redactar(f"Arctic: registro inválido de hidratación omitido: {e}"))
            for p in _fundir_submissions(validos, self.avisos).values():
                try:
                    h = por_id.get(p.get("id"))
                    if not h:
                        continue
                    t = _epoch(p.get("created_utc"))
                    fecha = iso_local(t)
                    meta = _obj(p.get("_meta") if p.get("_meta") is not None else {}, "Arctic meta")
                    sub = p.get("subreddit") or _campo_submission(p, "comunidad") or h.subreddit
                    cambios = dict(subreddit=sub, url=url_canonica(sub, h.id), titulo=p.get("title") or h.titulo,
                                   autor=p.get("author") or "", created_utc=t, fecha=fecha, votos=p.get("score"),
                                   num_comentarios=p.get("num_comments"), fecha_verificada=t is not None,
                                   votos_provisionales="retrieved_2nd_on" not in meta)
                except (ValueError, TypeError, OverflowError) as e:
                    self.avisos.append(redactar(f"Arctic: registro inválido de hidratación omitido: {e}"))
                    continue
                for campo, valor in cambios.items():
                    setattr(h, campo, valor)

    # ─── Leer ─────────────────────────────────────────────────────────────

    def leer(self, ref: str, carpeta: Optional[Path] = None, votos_actuales: bool = True) -> Dict[str, Any]:
        """Lee un hilo completo. Orden: Arctic Shift (post + árbol) [+ votos actuales de Redlib] → Redlib → Brave LLM → Wayback.

        Devuelve dict con post, comentarios (texto literal), fuentes usadas y cobertura (completa|parcial|fragmentos|sin_texto).
        """
        pid = ref_a_id(ref)
        carpeta = carpeta or self.salida / "hilos"
        carpeta.mkdir(parents=True, exist_ok=True)
        inicio_avisos = len(self.avisos)
        intentos: List[str] = []
        post: Dict[str, Any] = {}
        comentarios: List[Comentario] = []
        fuentes: List[str] = []
        # 1) Arctic Shift
        try:
            post, comentarios = self._leer_arctic(pid, carpeta)
            fuentes.append("arctic-shift")
        except Exception as e:  # noqa: BLE001
            intentos.append(f"arctic-shift: {redactar(str(e))[:160]}")
        # 2) Redlib: votos actuales o texto completo si Arctic falló
        red = None
        if votos_actuales or not post or post.get("arbol_fallido"):
            red, host, err = self._leer_redlib(pid, post.get("subreddit", ""), carpeta)
            if red is None:
                intentos.append(f"redlib: {err}")
            elif not post:
                post, comentarios = self._de_redlib(pid, red, host)
                fuentes.append(f"redlib:{host}")
            else:
                self._fusionar_votos(post, comentarios, red, host)
                fuentes.append(f"redlib:{host} (votos actuales)")
        cobertura = "completa"
        fragmentos: List[Dict[str, str]] = []
        # 3) Brave LLM Context y 4) Wayback: solo si no hay texto
        if not post:
            # Brave LLM es respaldo del modo experto: sin clave no se intenta ni se anota como fallo.
            fragmentos = self._leer_brave_llm(pid, ref, carpeta, intentos) if clave("BRAVE_SEARCH_API_KEY", obligatoria=False) else []
            if fragmentos:
                fuentes.append("brave-llm-context")
                cobertura = "fragmentos"
            else:
                wb = self._leer_wayback(pid, ref, carpeta, intentos)
                if wb:
                    fragmentos = [wb]
                    fuentes.append("wayback")
                    cobertura = "fragmentos"
                else:
                    cobertura = "sin_texto"
        if post:  # pendientes y «more» con el conjunto FINAL de comentarios (Redlib puede traer los que Arctic no expandió)
            ids_finales = {c.id for c in comentarios}
            avisos_more = []
            for nodo in post.pop("_more_nodos", []):
                obtenidos = len(set(nodo["ids"]) & ids_finales)
                if nodo["count"] > obtenidos:
                    avisos_more.append(f"more: count={nodo['count']}, obtenidos={obtenidos}; resto no comprobado")
            post["avisos_more"] = avisos_more
            self.avisos.extend(avisos_more)
            post["comentarios_pendientes"] = [x for x in post.get("comentarios_pendientes", []) if x not in ids_finales]
        _ocultar_retirados(post, comentarios)
        recuentos = [_entero(post.get(k)) for k in ("num_comentarios_actual", "num_comentarios")]
        declarados = max((x for x in recuentos if x is not None), default=None)
        leidos = len(comentarios)
        con_texto = sum(1 for c in comentarios if c.cuerpo and not es_retirado(c.cuerpo))
        pendientes = post.get("comentarios_pendientes", [])
        sin_identidad = sum(not c.identidad_verificada for c in comentarios)
        motivos = []
        if "arctic-shift" not in fuentes:
            motivos.append("sin árbol archivado verificable")
        elif post.get("arbol_fallido"):
            motivos.append("árbol de comentarios de Arctic no disponible")
        if declarados is None:
            motivos.append("recuento de comentarios desconocido")
        elif leidos < declarados:
            motivos.append("menos comentarios leídos que declarados")
        if pendientes:
            motivos.append("comentarios pendientes de expansión")
        for campo, cuenta in (("huérfanos", post.get("huerfanos", 0)), ("sin identidad", sin_identidad),
                              ("descartados por identidad", post.get("descartados_identidad", 0)),
                              ("more sin IDs expandibles", post.get("more_sin_ids", 0)),
                              ("more IDs inválidos", post.get("more_ids_invalidos", 0)),
                              ("more con recuento no comprobado", len(post.get("avisos_more") or [])),
                              ("more con recuento inválido", post.get("more_count_invalido", 0)),
                              ("duplicados incompatibles", post.get("duplicados_incompatibles", 0)),
                              ("votos no verificados", post.get("votos_no_verificados", 0)),
                              ("descartados por datos inválidos", post.get("descartados_datos", 0)),
                              ("conflictos", post.get("conflictos", 0))):
            if cuenta:
                motivos.append(f"{cuenta} {campo}")
        verificada = not motivos
        if post and not verificada:
            cobertura = "parcial"
        res = {"id": pid, "url": post.get("url") or url_canonica(post.get("subreddit", ""), pid), "post": post,
               "comentarios": [asdict(c) for c in comentarios], "fragmentos": fragmentos, "fuentes": fuentes,
               "cobertura": {"estado": cobertura, "comentarios_leidos": leidos, "con_texto": con_texto,
                             "declarados": declarados, "intentos_fallidos": intentos,
                             "pendientes": pendientes, "completitud_verificada": verificada,
                             "sin_identidad": sin_identidad, "motivos_parcial": motivos,
                             "descartados_identidad": post.get("descartados_identidad", 0),
                             "more_sin_ids": post.get("more_sin_ids", 0), "descartados_datos": post.get("descartados_datos", 0),
                             "more_ids_invalidos": post.get("more_ids_invalidos", 0),
                             "avisos_more": post.get("avisos_more", []),
                             "duplicados_incompatibles": post.get("duplicados_incompatibles", 0),
                             "more_count_invalido": post.get("more_count_invalido", 0),
                             "votos_no_verificados": post.get("votos_no_verificados", 0),
                             "huerfanos": post.get("huerfanos", 0), "conflictos": post.get("conflictos", 0)},
               "avisos": [redactar(x) for x in self.avisos[inicio_avisos:]],
               "leido": datetime.now(_zona()).isoformat()}
        res["representaciones"] = {"markdown": "texto Markdown de Arctic Shift", "texto_renderizado": "texto renderizado de HTML Redlib/Wayback; no es el Markdown original"}
        res = _sanear(res)
        _guardar_texto(carpeta / f"{pid}.json", _json_seguro(res, indent=1))
        return res

    def _leer_arctic(self, pid: str, carpeta: Path) -> Tuple[Dict[str, Any], List[Comentario]]:
        d = self._http("arctic", f"{ARCTIC}/posts/ids?ids={pid}")
        datos = _lista(_obj(d, "Arctic").get("data", []))
        if not datos:
            raise RuntimeError(f"Arctic Shift no tiene el post {pid}")
        estadisticas = {"descartados_identidad": 0}
        copias = []
        for dato in datos:
            try:
                dato = _obj(dato, "Arctic post")
                if dato.get("id") == pid:
                    admitido = _admitir_submission(dato)
                    _epoch(admitido.get("created_utc"))
                    copias.append(admitido)
                    if admitido.get("_comunidad_descartada"):  # retirada con comunidad contradictoria
                        estadisticas["conflictos"] = estadisticas.get("conflictos", 0) + 1
                        self.avisos.append("Arctic: copia retirada del post con comunidad contradictoria; "
                                           "se respeta la retirada, no su comunidad")
            except (ValueError, TypeError, OverflowError) as e:
                estadisticas["descartados_datos"] = estadisticas.get("descartados_datos", 0) + 1
                self.avisos.append(redactar(f"Arctic: post inválido omitido: {e}"))
        p = _fundir_submissions(copias, self.avisos).get(pid)
        if p is None:
            raise ValueError("respuesta Arctic no corresponde al post solicitado")
        _validar_submission(p, comunidad=False)  # cada copia ya pasó la de comunidad; aquí solo los IDs
        self._crudo(carpeta, "arctic_post", pid, {"id": pid}, d)
        meta = _obj(p.get("_meta") if p.get("_meta") is not None else {}, "Arctic meta")
        comunidad_post = p.get("subreddit") or _campo_submission(p, "comunidad")  # o la del permalink
        retirado = bool(_campo_submission(p, "retirado"))  # selftext tombstone o removed_by_category
        cuerpo = p.get("selftext") or ""
        if retirado and not es_retirado(cuerpo):
            cuerpo = "[removed]"  # el texto archivado de lo que hoy está retirado no se guarda ni se entrega
        post = {"id": pid, "subreddit": comunidad_post, "titulo": p.get("title", ""), "autor": p.get("author", ""),
                "created_utc": _epoch(p.get("created_utc")), "fecha": iso_local(p.get("created_utc")), "votos": p.get("score"),
                "votos_fuente": "arctic-shift", "votos_capturados": iso_local(meta.get("retrieved_2nd_on") or p.get("retrieved_on")),
                "upvote_ratio": p.get("upvote_ratio"), "num_comentarios": p.get("num_comments"), "flair": p.get("link_flair_text"),
                "cuerpo": cuerpo, "enlace_externo": None if p.get("is_self") else p.get("url"),
                "url": url_canonica(comunidad_post, pid), "editado": bool(p.get("edited")) or bool(meta.get("is_edited")),
                "cuerpo_fuente": "arctic-shift", "representacion": "markdown", "texto_reparado": bool(p.get("texto_reparado")),
                "identidad_verificada": True, "cuerpo_capturado": None,
                "retirado": retirado}
        try:
            arbol = self._http("arctic", f"{ARCTIC}/comments/tree?" + urllib.parse.urlencode({"link_id": pid, "limit": 9999}))
        except Exception as e:  # noqa: BLE001 — el post ya descargado se conserva; la cobertura queda parcial
            self.avisos.append(redactar(f"{pid}: árbol de comentarios de Arctic no disponible ({redactar(str(e))[:100]})"))
            post.update(estadisticas, arbol_fallido=True, huerfanos=0, avisos_more=[], comentarios_pendientes=[])
            return post, []
        self._crudo(carpeta, "arctic_arbol", pid, {"link_id": pid}, arbol)
        comentarios, pendientes = aplanar_arbol(_obj(arbol, "Arctic árbol").get("data", []), post["subreddit"], pid,
                                               estadisticas=estadisticas)
        pendientes = list(dict.fromkeys(pendientes))
        vistos = {c.id for c in comentarios}
        devueltos: set = set()
        for i in range(0, len(pendientes), 100):
            lote = [x for x in pendientes[i:i + 100] if x not in vistos]
            if not lote:
                continue
            try:
                extra = self._http("arctic", f"{ARCTIC}/comments/ids?ids=" + ",".join(lote))
                for c in _lista(_obj(extra, "Arctic more").get("data", [])):
                    try:
                        c = _obj(c, "Arctic comentario more")
                        if c.get("id") not in lote:
                            continue
                        devueltos.add(c["id"])  # devuelto: ya no está pendiente aunque se descarte después
                        if not _identidad_comentario(c, pid, post["subreddit"]):
                            estadisticas["descartados_identidad"] += 1
                            if _retirada_de_otra_comunidad(c, pid, post["subreddit"]):
                                estadisticas.setdefault("retiradas_por_id", {})[c["id"]] = c["body"]
                            continue
                        comentario = comentario_arctic(c, post["subreddit"], pid, None)
                    except (ValueError, TypeError, OverflowError) as e:
                        estadisticas["descartados_datos"] = estadisticas.get("descartados_datos", 0) + 1
                        self.avisos.append(redactar(f"Arctic: comentario inválido omitido: {e}"))
                        continue
                    comentarios.append(comentario)
                    vistos.add(c["id"])
            except Exception as e:  # Una expansión fallida conserva el árbol parcial.
                self.avisos.append(redactar(f"{pid}: {len(lote)} comentarios 'more' sin expandir ({redactar(str(e))[:100]})"))
        comentarios, estadisticas["duplicados_incompatibles"] = _fundir_comentarios(comentarios)
        for c in comentarios:  # retiradas conocidas por ID en copias descartadas por comunidad
            if c.id in estadisticas.get("retiradas_por_id", {}):
                c.cuerpo, c.cuerpo_capturado, c.retirado = estadisticas["retiradas_por_id"][c.id], None, True
        estadisticas.pop("retiradas_por_id", None)
        comentarios = self._comunidad_del_hilo(post, comentarios, estadisticas)
        comentarios, huerfanos = _ordenar_comentarios(comentarios, pid)
        post["_more_nodos"] = estadisticas.pop("more_nodos", [])  # avisos de «more»: en leer, tras la fusión con Redlib
        post.update(estadisticas)
        if estadisticas.get("descartados_datos"):
            self.avisos.append(f"Arctic: {estadisticas['descartados_datos']} comentarios con datos inválidos omitidos")
        post["huerfanos"] = huerfanos
        post["comentarios_pendientes"] = sorted(set(pendientes) - vistos - devueltos)
        return post, comentarios

    def _comunidad_del_hilo(self, post: Dict[str, Any], comentarios: List[Comentario], estadisticas: dict) -> List[Comentario]:
        """Un hilo vive en UNA comunidad. Si el post no la declara, la de sus comentarios es una señal recibida:
        una sola → pasa a ser la del post; varias → ningún comentario que declare comunidad es evidencia fiable y
        todos ellos se excluyen (descartados por identidad, parcialidad). Los que no declaran ninguna se conservan."""
        if _comunidad(post.get("subreddit")):
            return comentarios
        conocidas = {c.comunidad for c in comentarios} - {""}
        if len(conocidas) == 1:
            _fijar_comunidad(post, comentarios, next(iter(conocidas)))
            return comentarios
        if len(conocidas) > 1:
            fuera = [c for c in comentarios if c.comunidad]
            estadisticas["descartados_identidad"] = estadisticas.get("descartados_identidad", 0) + len(fuera)
            self.avisos.append(f"Arctic: {len(fuera)} comentarios declaran comunidades distintas para el hilo "
                               f"{post['id']}; excluidos")
            return [c for c in comentarios if not c.comunidad]
        return comentarios

    def _leer_redlib(self, pid: str, sub: str, carpeta: Path) -> Tuple[Optional[Dict[str, Any]], str, str]:
        errores = []
        for host in REDLIB:
            ruta = f"/r/{sub}/comments/{pid}/" if sub else f"/comments/{pid}/"
            url = f"https://{host}{ruta}"
            try:
                texto = self._http(f"redlib:{host}", url, json_resp=False, reintentos=2)
            except Exception as e:  # noqa: BLE001
                errores.append(f"{host} {redactar(str(e))[:80]}")
                continue
            try:
                red = _validar_redlib(parse_redlib(texto), pid)
            except ValueError as e:
                errores.append(f"{host} {redactar(str(e))}")
                continue
            self._crudo(carpeta, "redlib", pid + host, {"url": url}, {"bytes": len(texto), "post": red["post"],
                                                                      "n_comentarios": len(red["comentarios"])})
            return red, host, ""
        return None, "", "; ".join(errores) or "sin instancias"

    def _de_redlib(self, pid: str, red: Dict[str, Any], host: str) -> Tuple[Dict[str, Any], List[Comentario]]:
        _validar_redlib(red, pid)
        p = red["post"]
        # Comunidad ya validada (a lo sumo una): metadato, og/canonical o, sin ellos, la de los enlaces propios.
        conocidas = _comunidad_pagina(red)
        sub = p.get("subreddit") or next(iter(conocidas), "")
        post = {"id": pid, "subreddit": sub, "titulo": p.get("titulo", ""), "autor": p.get("autor", ""),
                "created_utc": _epoch(p.get("created_utc")), "fecha": iso_local(p.get("created_utc")), "votos": p.get("votos"),
                "votos_fuente": f"redlib:{host}", "votos_capturados": datetime.now(_zona()).isoformat(), "num_comentarios": p.get("num_comentarios"), "completitud_verificada": False,
                "cuerpo": p.get("cuerpo", ""), "url": url_canonica(sub, pid), "editado": bool(p.get("editado")),
                "cuerpo_fuente": f"redlib:{host}", "representacion": "texto_renderizado", "texto_reparado": bool(p.get("texto_reparado")),
                "descartados_identidad": red.get("descartados_identidad", 0), "identidad_verificada": True, "cuerpo_capturado": None,
                "duplicados_incompatibles": red.get("duplicados_incompatibles", 0),
                "votos_no_verificados": sum(not c.get("identidad_verificada", False) for c in red["comentarios"]),
                "retirado": es_retirado(p.get("cuerpo"))}
        cs = [Comentario(id=c["id"], padre=c["padre"] or pid, padre_tipo="t1" if c["padre"] else "t3", autor=c["autor"], created_utc=c["created_utc"],
                         fecha=iso_local(c["created_utc"]), votos=c["votos"], votos_fuente=f"redlib:{host}", cuerpo=c["cuerpo"],
                         representacion="texto_renderizado", texto_reparado=bool(c.get("texto_reparado")),
                         identidad_verificada=c.get("identidad_verificada", False),
                         cuerpo_fuente=f"redlib:{host}", retirado=es_retirado(c["cuerpo"]),
                         profundidad=c["profundidad"], url=url_canonica(sub, pid) + f"_/{c['id']}/", editado=c["editado"],
                         es_op=(c["autor"] == p.get("autor")) if p.get("autor") else None, es_bot=es_bot(c["autor"]),
                         comunidad=_comunidad_enlace(c) or _comunidad(sub))
              for c in red["comentarios"]]
        cs, post["huerfanos"] = _ordenar_comentarios(cs, pid)
        return post, cs

    @staticmethod
    def _aplicar_retiradas(comentarios: List[Comentario], red: Dict[str, Any], fuente: str) -> None:
        """Retiradas por ID de la página Redlib (también de contenedores descartados): lo retirado nunca se entrega."""
        retiradas = dict(red.get("retiradas_ids") or {})
        retiradas.update({c["id"]: c["cuerpo"] for c in red.get("comentarios", [])
                          if isinstance(c, dict) and es_retirado(c.get("cuerpo"))})
        for c in comentarios:
            if c.id in retiradas and not c.retirado:
                c.cuerpo, c.cuerpo_capturado, c.retirado, c.cuerpo_fuente = retiradas[c.id], None, True, fuente
                c.representacion = "texto_renderizado"

    @staticmethod
    def _fusionar_votos(post: Dict[str, Any], comentarios: List[Comentario], red: Dict[str, Any], host: str) -> None:
        """Arctic guarda votos (~36 h) y TEXTO de su captura (segundos tras publicarse); Redlib muestra los de ahora.

        Se cruzan por ID. Si el comentario se editó y Redlib trae texto, manda el texto actual y el de Arctic queda en
        cuerpo_capturado (caso real: pd1pln5 era un gif al capturarlo y el autor lo cambió por texto 19 min después).
        """
        fuente = f"redlib:{host}"
        momento = datetime.now(_zona()).isoformat()
        rp = _obj(red["post"], "Redlib post")
        post["descartados_identidad"] = post.get("descartados_identidad", 0) + red.get("descartados_identidad", 0)
        post["duplicados_incompatibles"] = post.get("duplicados_incompatibles", 0) + red.get("duplicados_incompatibles", 0)
        post.setdefault("conflictos", 0)
        comunidades = _comunidad_pagina(red)
        if comunidades and _comunidad(post.get("subreddit")) and _comunidad(post.get("subreddit")) not in comunidades:
            # Otra comunidad para el mismo ID: la página no aporta texto, votos, recuentos ni comentarios.
            # Solo se respetan sus retiradas por ID (lo retirado nunca se entrega).
            post["conflictos"] += 1
            if es_retirado(rp.get("cuerpo")):
                post.update(cuerpo=rp["cuerpo"], cuerpo_capturado=None, retirado=True, cuerpo_fuente=fuente,
                            representacion="texto_renderizado")
            RedditHelper._aplicar_retiradas(comentarios, red, fuente)
            return
        if len(comunidades) == 1 and not _comunidad(post.get("subreddit")) and post.get("id"):
            _fijar_comunidad(post, comentarios, next(iter(comunidades)))  # la página la declara y Arctic no
        # Misma pieza solo si autor y creación son compatibles; si no, Redlib no aporta texto ni votos.
        autor_compatible = rp.get("autor") in (None, "", post.get("autor")) and \
            _creacion_compatible(rp.get("created_utc"), post.get("created_utc"))
        if not autor_compatible and (not es_retirado(rp.get("cuerpo")) or
                                     not _creacion_compatible(rp.get("created_utc"), post.get("created_utc"))):
            post["conflictos"] = post.get("conflictos", 0) + 1
        if autor_compatible and rp.get("votos") is not None:
            post["votos_arctic"] = post.get("votos")
            post.update(votos=rp["votos"], votos_fuente=fuente, votos_capturados=momento)
        nuevo = rp.get("cuerpo")
        if es_retirado(nuevo):
            post.update(cuerpo=nuevo, cuerpo_capturado=None, retirado=True, cuerpo_fuente=fuente, representacion="texto_renderizado", texto_reparado=bool(rp.get("texto_reparado")))
        elif post.get("retirado") and nuevo and rp.get("autor") and rp.get("autor") == post.get("autor") and \
                rp.get("created_utc") is not None and post.get("created_utc") is not None and \
                int(rp["created_utc"]) == int(post["created_utc"]):
            # Retirado en la captura del archivo (p. ej. automod_filtered y aprobado después) y visible HOY en Redlib,
            # misma pieza CONFIRMADA (autor declarado igual y ambas fechas presentes e iguales; sin fecha no basta):
            # manda el estado de hoy. Se entrega el texto actual,
            # nunca el archivado (cuerpo_capturado queda vacío).
            post.update(cuerpo=nuevo, cuerpo_capturado=None, retirado=False, retirado_en_archivo=True, cuerpo_fuente=fuente,
                        representacion="texto_renderizado", texto_reparado=bool(rp.get("texto_reparado")))
        elif autor_compatible and not post.get("retirado") and (post.get("editado") or rp.get("editado")) and \
                nuevo is not None and nuevo != post.get("cuerpo"):
            post.update(cuerpo_capturado=post.get("cuerpo"), cuerpo=nuevo, cuerpo_fuente=fuente, editado=True, representacion="texto_renderizado", texto_reparado=bool(rp.get("texto_reparado")))
        actuales = _objetos(red["comentarios"], "Redlib comentarios")
        por_id = {c["id"]: c for c in reversed(actuales)}
        post["votos_no_verificados"] = post.get("votos_no_verificados", 0) + sum(
            not r.get("identidad_verificada", False) for r in por_id.values())
        if rp.get("num_comentarios") is not None:
            post["num_comentarios_actual"] = rp["num_comentarios"]
        post.setdefault("conflictos", 0)
        for c in comentarios:
            r = por_id.get(c.id)
            if not r:
                continue
            verificado = r.get("identidad_verificada", False)
            nuevo = r.get("cuerpo") or ""
            padre_red = ("t1", r["padre"]) if r.get("padre") else ("t3", post.get("id", ""))
            # Misma pieza: creación y padre tipado compatibles. El padre sin prefijo de Arctic («?») no contradice.
            # Sin prefijo («?») se desconoce el tipo, no el ID: si consta, debe coincidir.
            # Comunidad de la pieza Arctic (propia o del post) frente a toda señal de la pieza Redlib.
            comunidad_c = c.comunidad or _comunidad(post.get("subreddit"))
            señales_red = (_comunidad_pagina(red) | {_comunidad_enlace(r)}) - {""}
            enlace_ajeno = bool(comunidad_c and any(x != comunidad_c for x in señales_red))
            misma_pieza = not enlace_ajeno and _creacion_compatible(r.get("created_utc"), c.created_utc) and (
                (not c.padre or c.padre == padre_red[1]) if c.padre_tipo == "?" else padre_red == (c.padre_tipo, c.padre))
            # Una retirada tiene prioridad: jamás entregar la captura eliminada (si además contradice, cuenta conflicto).
            if es_retirado(nuevo):
                if not misma_pieza:
                    post["conflictos"] += 1
                c.cuerpo, c.cuerpo_capturado, c.retirado = nuevo, None, True
                c.cuerpo_fuente = fuente
                c.representacion = "texto_renderizado"
                c.texto_reparado = bool(r.get("texto_reparado"))
                c.identidad_verificada = r.get("identidad_verificada", False)
                if verificado:
                    c.autor = r.get("autor") or c.autor
                    c.votos, c.votos_fuente = r.get("votos"), fuente
                    c.editado = c.editado or bool(r.get("editado"))
                continue
            if r.get("autor") not in (None, "", c.autor) or not misma_pieza:
                post["conflictos"] += 1
                continue
            if verificado and r.get("votos") is not None:
                c.votos, c.votos_fuente = r["votos"], fuente
            if not c.retirado and (c.editado or r.get("editado")) and nuevo and nuevo != c.cuerpo:
                c.cuerpo_capturado, c.cuerpo, c.cuerpo_fuente = c.cuerpo, nuevo, fuente
                if verificado:
                    c.editado = True
                c.representacion = "texto_renderizado"
                c.texto_reparado = bool(r.get("texto_reparado"))
                c.identidad_verificada = r.get("identidad_verificada", False)
        RedditHelper._aplicar_retiradas(comentarios, red, fuente)
        vistos = {c.id for c in comentarios}
        pid = post.get("id", "")
        for cid, r in por_id.items():
            if cid in vistos:
                continue
            if _comunidad_enlace(r) and _comunidad(post.get("subreddit")) and \
                    _comunidad_enlace(r) != _comunidad(post.get("subreddit")):
                post["conflictos"] = post.get("conflictos", 0) + 1  # comentario solo-Redlib de otra comunidad
                continue
            t = _epoch(r.get("created_utc"))
            comentarios.append(Comentario(id=cid, padre=r.get("padre") or pid, padre_tipo="t1" if r.get("padre") else "t3",
                autor=r.get("autor", ""),
                created_utc=t, fecha=iso_local(t), votos=r.get("votos"), votos_fuente=fuente,
                representacion="texto_renderizado", texto_reparado=bool(r.get("texto_reparado")),
                identidad_verificada=r.get("identidad_verificada", False),
                cuerpo=r.get("cuerpo", ""), cuerpo_fuente=fuente, profundidad=r.get("profundidad"),
                url=url_canonica(post.get("subreddit", ""), pid) + f"_/{cid}/", editado=bool(r.get("editado")),
                retirado=es_retirado(r.get("cuerpo")), es_bot=es_bot(r.get("autor", "")),
                comunidad=_comunidad_enlace(r) or _comunidad(post.get("subreddit"))))
        if pid:
            comentarios[:], post["huerfanos"] = _ordenar_comentarios(comentarios, pid)

    def _leer_brave_llm(self, pid: str, ref: str, carpeta: Path, intentos: List[str]) -> List[Dict[str, str]]:
        """Brave LLM Context: fragmentos literales, SOLO de la fuente cuyo ID coincide (buscar una URL es una búsqueda)."""
        try:
            q = {"q": f"site:reddit.com {pid} {ref if not RE_ID.match(ref.strip()) else ''}".strip(), "count": 10,
                 "maximum_number_of_tokens": 8192}
            d = self._http("brave", "https://api.search.brave.com/res/v1/llm/context?" + urllib.parse.urlencode(q),
                           cabeceras={"X-Subscription-Token": clave("BRAVE_SEARCH_API_KEY")})
        except Exception as e:  # noqa: BLE001
            intentos.append(f"brave-llm: {redactar(str(e))[:120]}")
            return []
        try:
            fuentes = _objetos(_obj(_obj(d, "Brave LLM").get("grounding", {})).get("generic", []))
            for fuente in fuentes:
                _snippets(fuente.get("snippets", []))
                _cadena(fuente.get("url", ""), "Brave LLM URL")
                _cadena(fuente.get("title", ""), "Brave LLM title")
        except ValueError as e:
            intentos.append("brave-llm: " + redactar(str(e)))
            return []
        self._crudo(carpeta, "brave_llm", pid, q, d)
        out = []
        for s in fuentes:
            p = extraer_post(s.get("url", ""))
            if p and p[1] == pid:
                out += [{"fuente": "brave-llm-context", "url": s["url"], "texto": t, "texto_reparado": bool(s.get("texto_reparado"))} for t in s.get("snippets") or []]
        if not out:
            intentos.append("brave-llm: ningún fragmento con este ID")
        return out

    def _leer_wayback(self, pid: str, ref: str, carpeta: Path, intentos: List[str]) -> Optional[Dict[str, str]]:
        """CDX exacto (la consulta con comodín expira) → última captura 200 → texto. Validar título: puede ser un login."""
        base = ref if ref.startswith("http") else f"https://www.reddit.com/comments/{pid}/"
        try:
            cdx = self._http("wayback", "https://web.archive.org/cdx/search/cdx?" + urllib.parse.urlencode(
                {"url": base.split("?")[0], "output": "json", "filter": "statuscode:200", "limit": "-3"}), reintentos=2)
        except Exception as e:  # noqa: BLE001
            intentos.append(f"wayback-cdx: {redactar(str(e))[:120]}")
            return None
        if not isinstance(cdx, list) or any(not isinstance(f, list) for f in cdx):
            intentos.append("wayback: contrato CDX inválido")
            return None
        filas = cdx[1:]
        if not filas:
            intentos.append("wayback: sin capturas")
            return None
        if len(filas[-1]) < 3:
            intentos.append("wayback: fila CDX inválida")
            return None
        ts, original = filas[-1][1], filas[-1][2]
        if not isinstance(ts, str) or not re.fullmatch(r"\d{14}", ts) or not isinstance(original, str):
            intentos.append("wayback: fila CDX inválida")
            return None
        ref_original = extraer_post(original)
        if not ref_original or ref_original[1] != pid:
            intentos.append("wayback: captura de otro hilo")
            return None
        try:
            h = self._http("wayback", f"https://web.archive.org/web/{ts}id_/{original}", json_resp=False, reintentos=2)
        except Exception as e:  # noqa: BLE001
            intentos.append(f"wayback-captura: {redactar(str(e))[:120]}")
            return None
        if not isinstance(h, str):
            intentos.append("wayback: se esperaba HTML de texto")
            return None
        señales = _IdentidadHTML()
        señales.feed(h)
        refs = [_ref_relativa(x) for x in señales.urls]
        if any(not x or x[1] != pid for x in refs):
            intentos.append("wayback: identidad HTML contradice el hilo solicitado")
            return None
        texto_original = html_a_texto(h)
        texto = redactar(texto_original)
        if "log in" in texto.lower()[:400] and len(texto) < 3000:
            intentos.append("wayback: la captura es una pantalla de login")
            return None
        return {"fuente": "wayback", "url": f"https://web.archive.org/web/{ts}/{original}", "captura": ts, "texto": texto[:60000], "identidad_verificada": bool(refs),
                "redactado": texto != texto_original,
                "texto_reparado": getattr(h, "texto_reparado", False), "representacion": "texto_renderizado"}

    # ─── Lote, citas, salud ───────────────────────────────────────────────

    def lote(self, refs: List[str], carpeta: Path, pausa: float = 1.0, votos_actuales: bool = True,
             fuentes_busqueda: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Lee los hilos en serie (cortesía con Arctic Shift y Redlib) y escribe corpus.json + corpus.md."""
        _limite(pausa, "pausa")
        carpeta.mkdir(parents=True, exist_ok=True)
        hilos, fallos = [], []
        for i, r in enumerate(refs):
            try:
                hilos.append(self.leer(r, carpeta / "hilos", votos_actuales=votos_actuales))
            except Exception as e:  # noqa: BLE001
                fallos.append({"ref": r, "error": redactar(str(e))[:200]})
            if i < len(refs) - 1:
                time.sleep(pausa)
        corpus = {"generado": datetime.now(_zona()).isoformat(), "hilos": hilos, "fallos": fallos, "avisos": self.avisos,
                  "modo": modo_busqueda()["modo"]}
        corpus["motivos_cobertura_pobre"] = motivos_cobertura_pobre(hilos, fallos, fuentes_busqueda)
        corpus["cobertura_pobre"] = bool(corpus["motivos_cobertura_pobre"])
        _guardar_texto(carpeta / "corpus.json", _json_seguro(corpus, indent=1))
        _guardar_texto(carpeta / "corpus.md", corpus_md(corpus))
        return corpus

    def salud(self, en_vivo: bool = False) -> List[Dict[str, Any]]:
        """Sondeo mínimo de cada fuente. Correr al empezar: la disponibilidad de Reddit cambia por semanas.

        Las fuentes gratuitas se prueban en vivo. Las de pago (Brave, Perplexity, Firecrawl) solo con en_vivo=True:
        sin él se informa si la clave está configurada, sin consultas facturables."""
        filas: List[Dict[str, Any]] = []

        def probar(nombre: str, fn: Callable[[], str]) -> None:
            t = time.time()
            try:
                det = fn()
                filas.append({"fuente": nombre, "ok": True, "seg": round(time.time() - t, 1), "detalle": det})
            except Exception as e:  # noqa: BLE001
                filas.append({"fuente": nombre, "ok": False, "seg": round(time.time() - t, 1), "detalle": redactar(str(e))[:160]})

        def arctic() -> str:
            d = self._http("arctic", f"{ARCTIC}/posts/search?sort=desc&limit=1", reintentos=2)
            datos = _objetos(_obj(d, "Arctic salud").get("data", []))
            if not datos:
                raise ValueError("Arctic: sin posts")
            edad = ahora() - _epoch(datos[0]["created_utc"])
            return f"último post archivado hace {edad:.0f} s"

        probar("arctic-shift", arctic)
        def probar_experto(nombre, proveedor, fn):
            if clave(PROVEEDORES_EXPERTOS[proveedor], obligatoria=False):
                if en_vivo:
                    probar(nombre, fn)
                else:
                    filas.append({"fuente": nombre, "ok": None, "seg": 0.0, "estado": "CFG",
                                  "detalle": "clave configurada, NO verificada (salud --en-vivo la prueba y gasta créditos)"})
            else:
                filas.append({"fuente": nombre, "ok": False, "seg": 0.0,
                              "estado": "--",
                              "detalle": "NO CONFIGURADO (modo experto)"})

        probar_experto("brave", "brave", lambda: f"{len(self.buscar_brave('reddit', 'w', 3)['resultados'])} resultados")
        probar_experto("perplexity-search", "perplexity", lambda: f"{len(self.buscar_perplexity('reddit', 'w', 3)['resultados'])} resultados")
        probar_experto("firecrawl-search", "firecrawl", lambda: f"{len(self.buscar_firecrawl('reddit', 'w', 3)['resultados'])} resultados (2 créditos)")
        def espejo(host):
            t = self._http(f"redlib:{host}", f"https://{host}/r/redditdev/comments/1wubcvf/", json_resp=False, reintentos=1)
            _validar_redlib(parse_redlib(t), "1wubcvf")
            return "HTML con hilo e identidad verificada"

        for host in REDLIB:
            probar(f"redlib:{host}", lambda h=host: espejo(h))
        probar("you.com", lambda: f"{len(self.buscar_you('reddit', 'w', 1, reintentos=1)['resultados'])} resultados")

        def wayback():
            d = self._http("wayback", "https://web.archive.org/cdx/search/cdx?" + urllib.parse.urlencode(
                {"url": url_canonica("redditdev", "1wubcvf"), "output": "json", "filter": "statuscode:200", "limit": "1"}), reintentos=1)
            filas = _lista(d, "Wayback CDX")
            if len(filas) < 2 or not isinstance(filas[-1], list) or len(filas[-1]) < 3:
                raise ValueError("Wayback: sin captura verificable")
            ref = extraer_post(filas[-1][2])
            if not ref or ref[1] != "1wubcvf":
                raise ValueError("Wayback: captura de otro hilo")
            return "CDX con captura del hilo"

        probar("wayback", wayback)

        def rss() -> str:
            if datetime.now(timezone.utc) >= datetime(2026, 11, 13, tzinfo=timezone.utc):
                return "retirado por Reddit el 13-nov-2026 (no usar)"
            t = self._http("rss", "https://www.reddit.com/r/redditdev/new/.rss?limit=1", json_resp=False, reintentos=1)
            try:
                feed = ET.fromstring(t)
            except ET.ParseError:
                raise ValueError("RSS: sin entradas Atom/XML válidas") from None
            if feed.tag != "{http://www.w3.org/2005/Atom}feed" or feed.find("{http://www.w3.org/2005/Atom}entry") is None:
                raise ValueError("RSS: sin entradas Atom")
            return "200 (temporal: Reddit lo retira el 13-nov-2026)"

        probar("reddit-rss", rss)
        return filas


UMBRAL_HILOS_CON_TEXTO = 5
FUENTES_BASE = ("you", "arctic")


def _tiene_texto_entregable(h: Dict[str, Any]) -> bool:
    """Post o algún comentario con cuerpo no vacío y no retirado (lo que `citas` podría entregar), no solo el estado."""
    if h.get("cobertura", {}).get("estado") not in ("completa", "parcial"):
        return False
    piezas = [h.get("post") or {}] + list(h.get("comentarios") or [])
    return any((p.get("cuerpo") or "").strip() and not p.get("retirado") and not es_retirado(p.get("cuerpo"))
               for p in piezas)


def motivos_cobertura_pobre(hilos: List[Dict[str, Any]], fallos: List[Dict[str, Any]],
                            fuentes_busqueda: Optional[Dict[str, Any]] = None) -> List[str]:
    """Cobertura pobre, de forma determinista (decide si se ofrece el modo experto): pocos hilos con texto, mayoría
    sin texto completo o un buscador del modo base caído. Sin motivos = no es pobre."""
    motivos = []
    con_texto = sum(_tiene_texto_entregable(h) for h in hilos)
    if con_texto < UMBRAL_HILOS_CON_TEXTO:
        motivos.append(f"solo {con_texto} hilos leídos con texto (mínimo {UMBRAL_HILOS_CON_TEXTO})")
    total = len(hilos) + len(fallos)
    sin_completo = total - con_texto
    if total and sin_completo * 2 > total:
        motivos.append(f"{sin_completo} de {total} hilos sin texto completo (fragmentos, sin texto o fallo)")
    caidos = sorted(k for k, v in (fuentes_busqueda or {}).items()
                    if isinstance(v, dict) and v.get("ok") is False and k.split(":", 1)[0] in FUENTES_BASE)
    if caidos:
        motivos.append("buscador del modo base caído: " + ", ".join(caidos))
    return motivos


def leer_portapapeles() -> str:
    """Texto del portapapeles (macOS pbpaste, Windows Get-Clipboard, Linux wl-paste/xclip/xsel). Nunca lo imprime."""
    candidatos = [["pbpaste"], ["powershell", "-NoProfile", "-Command", "Get-Clipboard -Raw"],
                  ["powershell.exe", "-NoProfile", "-Command", "Get-Clipboard -Raw"],
                  ["wl-paste", "-n"], ["xclip", "-selection", "clipboard", "-o"], ["xsel", "-b", "-o"]]
    for cmd in candidatos:
        if not shutil.which(cmd[0]):
            continue
        try:
            r = subprocess.run(cmd, capture_output=True, timeout=10, check=False)
        except (OSError, subprocess.SubprocessError):
            continue
        if r.returncode == 0:
            return r.stdout.decode("utf-8", errors="replace")
    raise RuntimeError("portapapeles no disponible: usa «conectar <servicio> --preparar-fichero» y pega la clave en el fichero")


_RE_CLAVE_VALIDA = re.compile(r"[A-Za-z0-9._\-]{8,512}")


def _escribir_claves(ruta: Path, lineas: List[str]) -> None:
    ruta.parent.mkdir(parents=True, exist_ok=True)
    tmp = ruta.with_name(ruta.name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lineas) + "\n")
    os.replace(tmp, ruta)
    if os.name == "posix":
        os.chmod(ruta, 0o600)


def _lineas_sin(ruta: Path, nombre: str) -> List[str]:
    if not ruta.is_file():
        return []
    patron = re.compile(r"\s*(?:export\s+)?" + re.escape(nombre) + r"\s*=.*")
    return [l for l in ruta.read_text(encoding="utf-8").splitlines() if not patron.fullmatch(l)]


def conectar_clave(nombre: str, texto: str) -> str:
    """Guarda la clave en el fichero de claves (permisos 600) sin perder las demás. Devuelve un mensaje con solo los
    4 últimos caracteres; los errores nunca incluyen el texto recibido."""
    valor = (texto or "").strip()
    if not _RE_CLAVE_VALIDA.fullmatch(valor):
        raise ValueError("el portapapeles no contiene una clave válida (una sola línea de 8-512 caracteres, sin espacios); "
                         "cópiala de nuevo desde el panel del servicio")
    ruta = fichero_claves()
    if ruta is None:
        raise RuntimeError("no hay carpeta de usuario: define REDDIT_SEARCH_ENV con la ruta del fichero de claves")
    _escribir_claves(ruta, _lineas_sin(ruta, nombre) + [f"{nombre}={valor}"])
    if valor not in _CLAVES_CARGADAS:
        _CLAVES_CARGADAS.append(valor)
    msg = f"{nombre} guardada en {ruta} (…{valor[-4:]})."
    entorno = os.environ.get(nombre, "").strip()
    if entorno and entorno != valor:
        msg += (f" OJO: la variable de entorno {nombre} tiene prioridad sobre el fichero; se usará la que termina en "
                f"…{entorno[-4:]} hasta que la quites.")
    return msg


def preparar_fichero_claves(nombre: str) -> Path:
    """Crea (o completa) el fichero de claves con una línea «NOMBRE=» vacía para que el usuario pegue la clave."""
    ruta = fichero_claves()
    if ruta is None:
        raise RuntimeError("no hay carpeta de usuario: define REDDIT_SEARCH_ENV con la ruta del fichero de claves")
    lineas = ruta.read_text(encoding="utf-8").splitlines() if ruta.is_file() else []
    patron = re.compile(r"\s*(?:export\s+)?" + re.escape(nombre) + r"\s*=.*")
    if not any(patron.fullmatch(l) for l in lineas):
        lineas.append(f"{nombre}=")
    _escribir_claves(ruta, lineas)
    return ruta


def es_bot(autor: str) -> bool:
    a = (autor or "").lower()
    return a == "automoderator" or a.endswith("bot") or a.endswith("-bot") or a.endswith("_bot")


def comentario_arctic(c: Dict[str, Any], sub: str, pid: str, profundidad: Optional[int]) -> Comentario:
    _validar_post(c)
    if not _identidad_comentario(c, pid, sub):
        raise ValueError("comentario de otro hilo")
    padre_completo = c.get("parent_id") or ""
    prefijo = padre_completo[:3] if padre_completo[:3] in ("t1_", "t3_") else ""
    comunidades = _comunidades_comentario(c, sub)  # a lo sumo una: _identidad_comentario rechaza la contradicción
    return Comentario(id=c.get("id", ""), padre=padre_completo[len(prefijo):], comunidad=next(iter(comunidades), ""),
                      padre_tipo=prefijo[:2] if prefijo else "?", autor=c.get("author", ""),
                      created_utc=_epoch(c.get("created_utc")), fecha=iso_local(c.get("created_utc")),
                      votos=None if c.get("score_hidden") else c.get("score"),  # oculto ≠ 0 votos
                      es_op=c.get("is_submitter"), es_bot=es_bot(c.get("author", "")), distinguido=c.get("distinguished"),
                      votos_fuente="arctic-shift", cuerpo=c.get("body") or "",
                      identidad_verificada=bool(c.get("link_id") or c.get("permalink")),
                      texto_reparado=bool(c.get("texto_reparado")),
                      profundidad=profundidad, retirado=es_retirado(c.get("body")),
                      url=urllib.parse.urljoin("https://www.reddit.com", c["permalink"]) if c.get("permalink") else url_canonica(sub, pid) + f"_/{c.get('id')}/",
                      editado=bool(c.get("edited")) or bool(_obj(c.get("_meta") if c.get("_meta") is not None else {}, "Arctic meta").get("is_edited")))


def _comunidades_comentario(c, sub="") -> set:
    """Comunidades conocidas de un comentario Arctic: la del post, su `subreddit` y la de su permalink (minúsculas)."""
    ref = _ref_relativa(c["permalink"]) if isinstance(c.get("permalink"), str) else None
    return {_comunidad(sub), _comunidad(c.get("subreddit")), _comunidad(ref[0] if ref else "")} - {""}


def _identidad_comentario(c, pid, sub="", comunidad=True):
    for campo in ("parent_id", "link_id", "permalink"):
        if c.get(campo) is not None:
            _cadena(c[campo], "comentario " + campo)
    if not isinstance(c.get("id"), str) or not re.fullmatch(r"[a-z0-9]{4,13}", c["id"]):
        return False
    if c.get("name") is not None and c["name"] != "t1_" + c["id"]:  # fullname propio contradictorio
        return False
    if c.get("link_id") and c["link_id"] not in (pid, "t3_" + pid):
        return False
    padre = c.get("parent_id") or ""
    if padre.startswith("t3_") and padre != "t3_" + pid:
        return False
    if c.get("permalink"):
        ref = _ref_relativa(c["permalink"])
        if not ref or ref[1] != pid or _id_enlace_comentario(c["permalink"]) != c.get("id"):
            return False
    if comunidad and len(_comunidades_comentario(c, sub)) > 1:  # comunidad contradictoria
        return False
    return True


def _retirada_de_otra_comunidad(c, pid, sub) -> bool:
    """El registro solo falla por comunidad y está retirado: su retirada por ID se respeta (nunca entregar lo retirado)."""
    # IDs (post, comentario, fullname, namespaces) coherentes; la comunidad, aunque se contradiga, no anula la retirada.
    return es_retirado(c.get("body")) and _identidad_comentario(c, pid, comunidad=False) and \
        not _identidad_comentario(c, pid, sub)


RETIRADOS = ("[deleted]", "[removed]")
# Variantes de Reddit: «[deleted by user]», «[ Removed by Reddit ]», «[ Removed by Reddit on account of …]», «[removed by moderator]».
_RE_RETIRADO = re.compile(r"\[\s*(?:deleted|removed)\b[^\n]{0,300}\]", re.I)


def es_retirado(texto: Any) -> bool:
    """Marca de retirada de Reddit (tombstone), en cualquiera de sus variantes. Conservador: ante la duda, retirado."""
    return isinstance(texto, str) and bool(_RE_RETIRADO.fullmatch(texto.strip()))


def _ocultar_retirados(post: Dict[str, Any], comentarios: List["Comentario"]) -> None:
    """Punto único antes de persistir: ninguna pieza retirada conserva texto, venga de la fuente o de la fusión que venga."""
    if post.get("retirado") or es_retirado(post.get("cuerpo")):
        if not es_retirado(post.get("cuerpo")):
            post["cuerpo"] = "[removed]"
        post.update(retirado=True, cuerpo_capturado=None)
    for c in comentarios:
        if c.retirado or es_retirado(c.cuerpo):
            if not es_retirado(c.cuerpo):
                c.cuerpo = "[removed]"
            c.retirado, c.cuerpo_capturado = True, None


def _fijar_comunidad(post, comentarios, sub) -> None:
    """El post sin comunidad recibe la única conocida del hilo; las URL construidas sin ella la incorporan."""
    anterior, nueva = url_canonica("", post["id"]), url_canonica(sub, post["id"])
    post.update(subreddit=sub, url=nueva)
    for c in comentarios:
        if c.url.startswith(anterior):
            c.url = nueva + c.url[len(anterior):]


def _fundir_instancias(instancias, campo, completar=None):
    """Política común de duplicados (Arctic árbol/expansión y Redlib). Devuelve (instancia elegida | None, n descartadas).

    Varias instancias del mismo ID se funden solo si son la MISMA pieza: autor (salvo borrado), padre tipado y fecha de
    creación (cuando consta) compatibles. Si no, el ID entero se descarta y cuenta como «duplicados incompatibles»
    (parcialidad). Una instancia retirada manda sobre una viva (no se cita lo que hoy está borrado). Entre instancias
    vivas compatibles con cuerpos distintos (capturas de la misma pieza) se conserva la primera recibida, con su
    procedencia (`cuerpo_fuente`).
    """
    if len(instancias) == 1:
        return instancias[0], 0
    autores = {(campo(c, "autor") or "").lower() for c in instancias} - {"", "[deleted]", "[removed]"}
    padres = {(campo(c, "padre_tipo"), campo(c, "padre")) for c in instancias}
    fechas = {campo(c, "created_utc") for c in instancias} - {None}
    comunidades = {campo(c, "comunidad") for c in instancias} - {None, ""}
    if len(autores) > 1 or len(padres) > 1 or len(fechas) > 1 or len(comunidades) > 1:
        return None, len(instancias)
    retiradas = [c for c in instancias if campo(c, "retirado") or es_retirado(campo(c, "cuerpo"))]
    elegida = (retiradas or instancias)[0]
    # Señales conocidas en otra copia compatible y ausentes en la elegida: se conservan en una COPIA de la
    # elegida (`completar`), sin cambiar su texto, autor, procedencia ni retirada; así se contrastan después.
    faltan = {k: next(iter(v)) for k, v in (("comunidad", comunidades), ("created_utc", fechas))
              if v and campo(elegida, k) in (None, "")}
    if faltan and completar is not None:
        elegida = completar(elegida, faltan)
    return elegida, len(instancias) - 1


def _creacion_compatible(a, b) -> bool:
    """Misma creación al segundo (Redlib solo da segundos); si falta en una fuente, no hay contradicción."""
    return a is None or b is None or int(a) == int(b)


def _campo_submission(p, nombre):
    """Adaptador de un post de Arctic a `_fundir_instancias` (los posts no tienen padre)."""
    if nombre == "autor":
        return p.get("author")
    if nombre == "comunidad":
        if p.get("_comunidad_descartada"):
            return ""
        ref = _ref_relativa(p["permalink"]) if isinstance(p.get("permalink"), str) else None
        return _comunidad(p.get("subreddit")) or _comunidad(ref[0] if ref else "")
    if nombre == "created_utc":
        return _epoch(p.get("created_utc"))
    if nombre in ("retirado", "cuerpo"):
        retirado = es_retirado(p.get("selftext")) or p.get("removed_by_category") not in (None, "")
        return retirado if nombre == "retirado" else p.get("selftext")
    return None


def _fundir_submissions(posts, avisos=None):
    """Posts de Arctic ya validados → {id: post elegido}, en orden de primera aparición. Misma política que los
    comentarios: copias con autor, creación o comunidad incompatibles descartan el ID (con aviso); una copia
    retirada manda sobre la viva. Si la elegida no declara comunidad y otra copia compatible sí, se conserva esa
    comunidad en una copia del registro, sin cambiar su texto, autor ni retirada."""
    grupos: Dict[str, List[Dict[str, Any]]] = {}
    for p in posts:
        grupos.setdefault(p["id"], []).append(p)
    elegidos = {}
    for pid, g in grupos.items():
        elegido, _ = _fundir_instancias(g, _campo_submission, _completar_submission)
        if elegido is None:
            if avisos is not None:
                avisos.append(f"Arctic: {len(g)} copias incompatibles del post {pid} (autor o creación); descartado")
        else:
            elegidos[pid] = elegido
    return elegidos


def _completar_submission(p, faltan):
    """Copia del post elegido con la comunidad o la creación que solo declaraba otra copia compatible."""
    p = dict(p)
    if "comunidad" in faltan:
        p["subreddit"] = faltan["comunidad"]
        p.pop("_comunidad_descartada", None)
    if "created_utc" in faltan:
        p["created_utc"] = faltan["created_utc"]
    return p


def _completar_comentario(c, faltan):
    """Copia del Comentario elegido con la comunidad o la creación que solo declaraba otra copia compatible."""
    cambios = {}
    if "comunidad" in faltan:
        cambios["comunidad"] = faltan["comunidad"]
    if "created_utc" in faltan:
        cambios.update(created_utc=faltan["created_utc"], fecha=iso_local(faltan["created_utc"]))
    return dataclasses.replace(c, **cambios)


def _fundir_comentarios(comentarios):
    """Aplica `_fundir_instancias` a una lista de Comentario; conserva el orden de la primera aparición."""
    grupos: Dict[str, List[Comentario]] = {}
    for c in comentarios:
        grupos.setdefault(c.id, []).append(c)
    out, incompatibles = [], 0
    for cid, g in grupos.items():
        elegida, n = _fundir_instancias(g, lambda c, nombre: getattr(c, nombre, None), _completar_comentario)
        if elegida is None:
            incompatibles += n
        else:
            out.append(elegida)
    return out, incompatibles


def _ordenar_comentarios(comentarios, pid):
    unicos = {c.id: c for c in reversed(comentarios)}
    hijos = {}
    for c in comentarios:
        if unicos[c.id] is c:
            # Claves tipadas: la raíz es SOLO «t3_<pid>»; un padre «t1_» o sin prefijo se busca entre los comentarios.
            hijos.setdefault((c.padre_tipo == "t3", c.padre), []).append(c)
    pila = [(c, 0) for c in reversed(hijos.get((True, pid), []))]
    orden, vistos = [], set()
    while pila:
        c, profundidad = pila.pop()
        if c.id in vistos:
            continue
        vistos.add(c.id)
        c.profundidad = profundidad
        orden.append(c)
        pila.extend((h, profundidad + 1) for h in reversed(hijos.get((False, c.id), [])))
    # Padres ausentes, ciclos y descendientes desconectados se conservan sin profundidad inventada.
    huerfanos = 0
    for c in comentarios:
        if c.id not in vistos:
            vistos.add(c.id)
            c.profundidad = None
            orden.append(c)
            huerfanos += 1
    return orden, huerfanos


def aplanar_arbol(nodos: List[Dict[str, Any]], sub: str, pid: str, prof: int = 0,
                  estadisticas: Optional[dict] = None) -> Tuple[List[Comentario], List[str]]:
    """Recorrido iterativo, identidad por comentario y deduplicación de IDs y more."""
    out, pendientes, vistos = [], [], set()
    pila = [(n, prof) for n in reversed(_lista(nodos, "Arctic árbol"))]
    while pila:
        n, profundidad = pila.pop()
        try:
            n = _obj(n, "Arctic nodo")
            c = _obj(n.get("data", {}), "Arctic nodo data")
            if n.get("kind") not in ("t1", "more"):
                raise ValueError("Arctic: tipo de nodo desconocido")
        except (ValueError, TypeError, OverflowError) as e:
            logger.warning("Arctic: nodo inválido omitido: %s", e)
            if estadisticas is not None:
                estadisticas["descartados_datos"] = estadisticas.get("descartados_datos", 0) + 1
            continue
        if n.get("kind") == "more":
            children = c.get("children") or []
            ids = [x.split("_", 1)[-1] for x in children if isinstance(x, str) and
                   re.fullmatch(r"(?:t1_)?[a-z0-9]{4,13}", x)] if isinstance(children, list) else []
            if not ids and type(c.get("count")) is int and c["count"] > 0 and estadisticas is not None:
                estadisticas["more_sin_ids"] = estadisticas.get("more_sin_ids", 0) + 1
            if estadisticas is not None:
                invalidos = len(children) - len(ids) if isinstance(children, list) else 0
                estadisticas["more_ids_invalidos"] = estadisticas.get("more_ids_invalidos", 0) + invalidos
                if type(c.get("count")) is int and c["count"] > 0:
                    estadisticas.setdefault("more_nodos", []).append({"count": c["count"], "ids": ids})
                elif not (type(c.get("count")) is int and c["count"] == 0):
                    # count ausente, de otro tipo o negativo: el recuento no se puede comprobar (nunca vale 0 implícito)
                    estadisticas["more_count_invalido"] = estadisticas.get("more_count_invalido", 0) + 1
            pendientes.extend(ids)
            continue
        try:
            if not _identidad_comentario(c, pid, sub):
                if estadisticas is not None:
                    estadisticas["descartados_identidad"] = estadisticas.get("descartados_identidad", 0) + 1
                    if _retirada_de_otra_comunidad(c, pid, sub):
                        estadisticas.setdefault("retiradas_por_id", {})[c["id"]] = c["body"]
            else:  # los duplicados también se validan y se contrastan después (_fundir_comentarios)
                out.append(comentario_arctic(c, sub, pid, profundidad))
                vistos.add(c.get("id"))
        except (ValueError, TypeError, OverflowError) as e:
            logger.warning("Arctic: comentario inválido omitido: %s", e)
            if estadisticas is not None:
                estadisticas["descartados_datos"] = estadisticas.get("descartados_datos", 0) + 1
        rep = c.get("replies")
        if rep not in (None, ""):
            try:
                hijos = _lista(_obj(_obj(rep, "Arctic replies").get("data", {})).get("children", []))
            except (ValueError, TypeError, OverflowError) as e:
                logger.warning("Arctic: rama replies inválida omitida: %s", e)
                if estadisticas is not None:
                    estadisticas["descartados_datos"] = estadisticas.get("descartados_datos", 0) + 1
                continue
            pila.extend((h, profundidad + 1) for h in reversed(hijos))
    return out, list(dict.fromkeys(pendientes))


# ============================================================================
# Formato de salida (data original: texto literal + metadatos completos)
# ============================================================================


def _etiquetas_no_literal(pieza):
    etiquetas = [k for k in ("redactado", "retirado", "texto_reparado") if pieza.get(k)]
    if es_retirado(pieza.get("cuerpo")) and "retirado" not in etiquetas:
        etiquetas.append("retirado")
    if pieza.get("identidad_verificada") is False:
        etiquetas.append("identidad no verificada")
    return etiquetas


def _procedencia(pieza):
    cuerpo = (pieza.get("cuerpo_fuente") or "s/d").split(":", 1)[0]
    votos = (pieza.get("votos_fuente") or "s/d").split(":", 1)[0]
    editado = " (editado)" if pieza.get("editado") else ""
    etiquetas = _etiquetas_no_literal(pieza)
    marcas = (" [" + ", ".join(etiquetas) + "]") if etiquetas else ""
    return f" · texto: {cuerpo}{editado} · votos: {votos}" + marcas


def cita_md(texto: str, url: str, sub: str, autor: str, fecha: Optional[str], votos: Optional[int], marcas: str = "", procedencia: str = "") -> str:
    cuerpo = "\n".join("> " + l if l else ">" for l in texto.strip("\n").split("\n"))
    v = "votos ocultos/s.d." if votos is None else f"{votos} votos"
    return f"{cuerpo}\n\n— u/{autor or '[desconocido]'}{marcas} · r/{sub} · {fecha or 'fecha s/d'} · {v}{procedencia} · {url}\n"


def hilo_md(h: Dict[str, Any], orden: str = "arbol", maximo: Optional[int] = None) -> str:
    h = _sanear(h)
    p = h.get("post") or {}
    cob = h["cobertura"]
    lineas = [f"## {p.get('titulo') or h['id']}", "",
              f"- URL: {h['url']}", f"- r/{p.get('subreddit', '')} · u/{p.get('autor', '')} · {p.get('fecha')} · "
              f"{p.get('votos')} votos ({p.get('votos_fuente', '')}) · {p.get('num_comentarios_actual') or p.get('num_comentarios')} comentarios declarados",
              f"- Fuentes: {', '.join(h['fuentes']) or 'ninguna'} · Cobertura: **{cob['estado']}** "
              f"({cob['comentarios_leidos']} leídos, {cob['con_texto']} con texto)", ""]
    if cob.get("intentos_fallidos"):
        lineas += [f"- Intentos fallidos: {'; '.join(cob['intentos_fallidos'])}", ""]
    if p.get("retirado") or es_retirado(p.get("cuerpo")):
        lineas += ["### Post", "", "_(post retirado: su texto no se entrega)_" + _procedencia(p), ""]
    elif p.get("cuerpo"):
        lineas += ["### Post", "", cita_md(p["cuerpo"], h["url"], p.get("subreddit", ""), p.get("autor", ""),
                                                     p.get("fecha"), p.get("votos"), procedencia=_procedencia(p))]
    cs = [c for c in h["comentarios"] if c["cuerpo"] and not es_retirado(c["cuerpo"]) and not c.get("retirado")]
    if orden == "votos":
        cs.sort(key=lambda c: -(c["votos"] or 0))
    elif orden == "fecha":
        cs.sort(key=lambda c: -(c["created_utc"] or 0))
    _limite(maximo, "max")
    if maximo is not None:
        cs = cs[:maximo]
    if cs:
        lineas += [f"### Comentarios (orden: {orden})", ""]
    for c in cs:
        sangria = "  " * min(c["profundidad"] or 0, 6) if orden == "arbol" else ""
        marcas = (" [OP]" if c.get("es_op") else "") + (" [bot]" if c.get("es_bot") else "") + \
                 (f" [{c['distinguido']}]" if c.get("distinguido") else "") + (" [editado]" if c.get("editado") else "")
        bloque = cita_md(c["cuerpo"], c["url"], p.get("subreddit", ""), c["autor"], c["fecha"], c["votos"], marcas, _procedencia(c))
        lineas.append("\n".join(sangria + l for l in bloque.split("\n")))
    for f in h.get("fragmentos") or []:
        etiquetas = _etiquetas_no_literal(f)
        marcas = (" [" + ", ".join(etiquetas) + "]") if etiquetas else ""
        lineas += [f"### Fragmento ({f['fuente']}, NO es el hilo completo){marcas}", "", "> " + redactar(f["texto"])[:4000].replace("\n", "\n> "),
                   "", f"— {f['url']}", ""]
    return "\n".join(lineas)


def indice_md(ix: Dict[str, Any], max_filas: int = 60) -> str:
    _limite(max_filas, "filas")
    out = [f"# Índice de hilos: {ix['tema']}", "",
           f"Generado {ix['generado']} · ventanas {','.join(ix['ventanas'])} · {ix['total_hilos']} hilos únicos · "
           f"{ix['en_ventana']} en ventana · {ix['fecha_sin_verificar']} con fecha sin verificar", "", "## Fuentes", ""]
    if ix.get("aviso_modo_experto"):
        out += [ix["aviso_modo_experto"], ""]
    for k, v in ix["fuentes"].items():
        out.append(f"- {k}: " + (f"{v['resultados']} resultados, {v['hilos_nuevos']} hilos nuevos" if v["ok"] else f"FALLO — {v['error']}"))
        if v.get("muestra_limitada"):
            out.append(f"  {k}: muestra limitada de posts recientes con filtro local.")
        if v.get("truncado"):
            out.append(f"  Búsqueda {k} truncada al límite del proveedor; sin paginación verificada.")
    for a in ix.get("avisos") or []:
        out.append(f"- AVISO: {a}")
    out += ["", "| # | Fecha (hora local) | Sub | Votos | Coms | Relev. | Ventana | Fuentes | Título | ID |", "|---|---|---|---|---|---|---|---|---|---|"]
    for i, h in enumerate(ix["hilos"][:max_filas], 1):
        fecha = (h["fecha"] or "s/v")[:16] + ("" if h["fecha_verificada"] else " (s/v)")
        titulo = redactar(h["titulo"] or "").replace("|", "/")[:70]
        vent = {True: "sí", False: "antiguo", None: "?"}[h["en_ventana"]]
        votos = "-" if h["votos"] is None else f"{h['votos']}{'?' if h.get('votos_provisionales') else ''}"
        out.append(f"| {i} | {fecha} | {h['subreddit']} | {votos} | "
                   f"{h['num_comentarios'] if h['num_comentarios'] is not None else '-'} | {h['relevancia']} | {vent} | "
                   f"{len(h['fuentes'])} | {titulo} | {h['id']} |")
    out += ["", "«?» = votos y comentarios de la primera captura (provisionales); `leer` trae los actuales.",
            f"Índice completo: {ix['carpeta']}/indice.json"]
    return "\n".join(out)


def corpus_md(corpus: Dict[str, Any]) -> str:
    partes = [f"# Corpus de Reddit ({corpus['generado']})", "",
              f"{len(corpus['hilos'])} hilos leídos · {len(corpus['fallos'])} fallos", ""]
    if "cobertura_pobre" in corpus:
        partes.append("Cobertura pobre: " + ("sí — " + "; ".join(corpus["motivos_cobertura_pobre"])
                                             if corpus["cobertura_pobre"] else "no"))
    for f in corpus["fallos"]:
        partes.append(f"- FALLO {f['ref']}: {f['error']}")
    for h in corpus["hilos"]:
        partes += ["", hilo_md(h, orden="votos")]
    return "\n".join(partes)


def citas(corpus: Dict[str, Any], patron: str, min_votos: Optional[int] = None, maximo: int = 50,
          excluir_bots: bool = True, incluir_no_literales: bool = False) -> List[Dict[str, Any]]:
    """Párrafos del post/comentarios con identidad y procedencia; excluye piezas transformadas por defecto."""
    _limite(maximo, "max")
    _rango_entero(min_votos, "min-votos")
    corpus = _sanear(corpus)
    rx = re.compile(patron, re.I)
    out = []
    for h in _objetos(_obj(corpus, "corpus").get("hilos", [])):
        p = _obj(h.get("post", {}), "post")
        piezas = [("post", p, h["url"])]
        piezas += [("comentario", c, c["url"]) for c in _objetos(h.get("comentarios", []))
                   if not (excluir_bots and c.get("es_bot"))]
        for tipo, pieza, url in piezas:
            texto, votos = pieza.get("cuerpo", ""), pieza.get("votos")
            etiquetas = _etiquetas_no_literal(pieza)
            if etiquetas and not incluir_no_literales:
                continue
            if not texto:
                continue
            if min_votos is not None and (votos or 0) < min_votos:
                continue
            for parrafo in [x for x in texto.split("\n\n") if x.strip()]:
                if rx.search(parrafo):
                    out.append({"tipo": tipo, "texto": parrafo.strip("\n"), "url": url, "subreddit": p.get("subreddit", ""),
                                "autor": pieza.get("autor"), "fecha": pieza.get("fecha"), "votos": votos,
                                "hilo": p.get("titulo", ""), "cuerpo_fuente": pieza.get("cuerpo_fuente"),
                                "votos_fuente": pieza.get("votos_fuente"), "editado": bool(pieza.get("editado")),
                                "hilo_id": h.get("id", p.get("id")), "comentario_id": pieza.get("id") if tipo == "comentario" else None,
                                "representacion": pieza.get("representacion"), "literal": not etiquetas,
                                "etiquetas": etiquetas, "redactado": bool(pieza.get("redactado")),
                                "texto_reparado": bool(pieza.get("texto_reparado")),
                                "retirado": bool(pieza.get("retirado")), "identidad_verificada": pieza.get("identidad_verificada", True)})
    out.sort(key=lambda c: -(c["votos"] or 0))
    return out[:maximo]


# ============================================================================
# CLI Commands
# ============================================================================


def _leer_lista(ruta: str, top: Optional[int], solo_ventana: bool, min_relevancia: float) -> List[str]:
    _limite(top, "top")
    _ratio(min_relevancia)
    texto = sys.stdin.read() if ruta == "-" else Path(ruta).read_text(encoding="utf-8")
    if texto.lstrip().startswith("{"):
        ix = _obj(json.loads(texto), "índice")
        hs = []
        for h in _objetos(ix.get("hilos", []), "índice hilos"):
            ventana = h.get("en_ventana")
            if ventana is not None and not isinstance(ventana, bool):
                raise ValueError("en_ventana debe ser booleano o null")
            rel = _ratio(float(h.get("relevancia", 0)))
            if (not solo_ventana or ventana is True) and rel >= min_relevancia:
                hs.append(h)
        refs = [ref_a_id(h["id"]) for h in hs]
    else:
        refs = []
        for l in texto.splitlines():
            l = l.strip()
            if l and not l.startswith("#"):
                try:
                    refs.append(ref_a_id(l.split()[0]))
                except ValueError:
                    pass
    vistos: List[str] = []
    for r in refs:
        if r not in vistos:
            vistos.append(r)
    return vistos[:top] if top is not None else vistos


def cmd_descubrir(a: argparse.Namespace) -> int:
    h = RedditHelper(salida=a.salida, guardar_crudo=getattr(a, "guardar_crudo", False))
    mas: List[str] = []
    for f in a.mas_urls or []:
        mas += re.findall(r"https?://\S+", Path(f).read_text(encoding="utf-8"))
    carpeta = Path(a.carpeta) if a.carpeta else None
    ix = h.descubrir(a.tema, ventanas=a.ventana.split(","), fuentes=a.fuentes.split(",") if a.fuentes is not None else None, subs=a.sub or [], n=a.n,
                     mas_urls=mas, carpeta=carpeta, orden=a.orden)
    _imprimir(_json_seguro(ix, indent=1) if a.json else indice_md(ix, a.filas))
    return 0 if ix["total_hilos"] else 3


def cmd_leer(a: argparse.Namespace) -> int:
    h = RedditHelper(salida=a.salida, guardar_crudo=getattr(a, "guardar_crudo", False))
    r = h.leer(a.ref, carpeta=Path(a.carpeta) if a.carpeta else None, votos_actuales=not a.sin_votos_actuales)
    _imprimir(_json_seguro(r, indent=1) if a.json else hilo_md(r, a.orden, a.max))
    _imprimir(f"\n(JSON completo: {(Path(a.carpeta) if a.carpeta else h.salida / 'hilos') / (r['id'] + '.json')})", file=sys.stderr)
    return 0 if r["cobertura"]["estado"] in ("completa", "parcial") else 4


def cmd_lote(a: argparse.Namespace) -> int:
    refs = _leer_lista(a.lista, a.top, a.solo_ventana, a.min_relevancia)
    if not refs:
        _imprimir("lista vacía: nada que leer", file=sys.stderr)
        return 3
    carpeta = Path(a.carpeta) if a.carpeta else (Path(a.lista).parent if a.lista.endswith(".json") else
                                                  RedditHelper(salida=a.salida, guardar_crudo=getattr(a, "guardar_crudo", False)).salida / f"lote-{datetime.now(_zona()).strftime('%Y%m%d-%H%M')}")
    carpeta.mkdir(parents=True, exist_ok=True)
    fuentes_busqueda = None
    if a.lista != "-" and a.lista.endswith(".json"):
        ix = json.loads(Path(a.lista).read_text(encoding="utf-8"))
        if isinstance(ix, dict) and isinstance(ix.get("fuentes"), dict):
            fuentes_busqueda = ix["fuentes"]
    c = RedditHelper(salida=a.salida, guardar_crudo=getattr(a, "guardar_crudo", False)).lote(
        refs, carpeta, pausa=a.pausa, votos_actuales=not a.sin_votos_actuales, fuentes_busqueda=fuentes_busqueda)
    for hh in c["hilos"]:
        cob = hh["cobertura"]
        _imprimir(f"- {hh['id']} {cob['estado']:10} {cob['comentarios_leidos']:4} coms · {redactar((hh['post'] or {}).get('titulo', ''))[:70]}")
    for f in c["fallos"]:
        _imprimir(f"- FALLO {f['ref']}: {f['error']}")
    _imprimir(f"\ncorpus: {carpeta / 'corpus.md'} y {carpeta / 'corpus.json'}")
    estados = ("completa", "parcial", "fragmentos", "sin_texto")
    contadores = {e: sum(h["cobertura"]["estado"] == e for h in c["hilos"]) for e in estados}
    _imprimir("Estados: " + ", ".join(f"{e}={n}" for e, n in contadores.items()) + f", fallos={len(c['fallos'])}")
    _imprimir("Cobertura pobre: " + ("sí — " + "; ".join(c["motivos_cobertura_pobre"]) if c["cobertura_pobre"] else "no"))
    return 0 if contadores["completa"] + contadores["parcial"] else 4


def cmd_citas(a: argparse.Namespace) -> int:
    corpus = json.loads(Path(a.corpus).read_text(encoding="utf-8"))
    if "hilos" not in corpus and "comentarios" in corpus:
        corpus = {"hilos": [corpus]}
    cs = citas(corpus, a.buscar, a.min_votos, a.max, incluir_no_literales=a.incluir_no_literales)
    if a.json:
        _imprimir(_json_seguro(cs, indent=1))
    else:
        for c in cs:
            _imprimir(cita_md(c["texto"], c["url"], c["subreddit"], c["autor"], c["fecha"], c["votos"], procedencia=_procedencia(c)))
        _imprimir(f"({len(cs)} " + ("extractos etiquetados" if a.incluir_no_literales else "citas literales") + ")")
    return 0 if cs else 3


def cmd_conectar(a: argparse.Namespace) -> int:
    nombre = PROVEEDORES_EXPERTOS[a.servicio]
    if a.preparar_fichero:
        ruta = preparar_fichero_claves(nombre)
        _imprimir(f"Fichero listo: {ruta}\nÁbrelo, pega la clave tras «{nombre}=» en esa línea, guarda y corre «salud».")
        return 0
    _imprimir(conectar_clave(nombre, leer_portapapeles()))
    return 0


def cmd_salud(a: argparse.Namespace) -> int:
    modo = modo_busqueda()
    _imprimir(f"Modo {modo['modo']} · falta para experto: {', '.join(modo['faltan']) or 'nada'}")
    _imprimir(f"Python {sys.version.split()[0]}")
    filas = RedditHelper(salida=a.salida, guardar_crudo=False).salud(en_vivo=getattr(a, "en_vivo", False))
    for f in filas:
        estado = f.get("estado") or ("OK" if f["ok"] else "MAL")
        _imprimir(f"{estado:3} {f['fuente']:28} {f['seg']:5}s  {f['detalle']}")
    return 0 if any(f["ok"] and f["fuente"] == "arctic-shift" for f in filas) else 5


# ─── Subcomandos auxiliares ────────────────────────────────────────────────


def cmd_exa(a: argparse.Namespace) -> int:
    if a.n == 0:
        return 0
    h = RedditHelper(salida=a.salida, guardar_crudo=getattr(a, "guardar_crudo", False))
    d = h._http("exa", "https://api.exa.ai/search", {"query": a.consulta, "numResults": a.n, "type": "auto",
                "contents": {"text": {"maxCharacters": 4000}}}, {"x-api-key": clave("EXA_API_KEY")})
    for r in _objetos(_obj(d, "Exa").get("results", [])):
        _cadena(r.get("url", ""), "Exa URL")
        _cadena(r.get("title", ""), "Exa title")
        _cadena(r.get("text", ""), "Exa text")
        _imprimir(f"- {redactar(r.get('publishedDate') or 's/f')[:10]} | {r['url']}\n  {redactar(r.get('text') or '')[:400].replace(chr(10), ' ')}")
    _imprimir("(Exa no devuelve reddit.com: úsalo para docs, blogs y espejos)", file=sys.stderr)
    return 0


def cmd_web(a: argparse.Namespace) -> int:
    h = RedditHelper(salida=a.salida, guardar_crudo=getattr(a, "guardar_crudo", False))
    d = h._http("exa", "https://api.exa.ai/contents", {"urls": a.urls, "text": True, "maxAgeHours": 0},
                {"x-api-key": clave("EXA_API_KEY")})
    for r in _objetos(_obj(d, "Exa").get("results", [])):
        _cadena(r.get("url", ""), "Exa URL")
        _cadena(r.get("title", ""), "Exa title")
        _cadena(r.get("text", ""), "Exa text")
        _imprimir(f"=== {r['url']} ({len(r.get('text') or '')} caracteres)\n{redactar(r.get('text') or '')[:12000]}\n")
    for s in _objetos(_obj(d).get("statuses", [])):
        if s.get("status") != "success":
            _imprimir(f"(sin contenido: {s.get('id')} → {s.get('status')} {s.get('error') or ''})", file=sys.stderr)
    return 0


def cmd_brave(a: argparse.Namespace) -> int:
    r = RedditHelper(salida=a.salida, guardar_crudo=getattr(a, "guardar_crudo", False)).buscar_brave(a.consulta.replace("site:reddit.com", "").strip(), a.ventana, a.n)
    if r.get("truncado"):
        _imprimir("búsqueda truncada al límite del proveedor; sin paginación verificada", file=sys.stderr)
    for x in r["resultados"]:
        _imprimir(f"- {x['edad'] or 's/f'} | {x['url']}\n  {redactar(x['texto'])[:600]}")
    return 0


def cmd_firecrawl(a: argparse.Namespace) -> int:
    h = RedditHelper(salida=a.salida, guardar_crudo=getattr(a, "guardar_crudo", False))
    d = h._http("firecrawl", "https://api.firecrawl.dev/v2/scrape", {"url": a.url, "formats": ["markdown"]},
                {"Authorization": f"Bearer {clave('FIRECRAWL_API_KEY')}"}, reintentos=2)
    _imprimir(redactar(_cadena(_obj(_obj(d, "Firecrawl scrape").get("data", {})).get("markdown", ""), "Firecrawl markdown"))[:12000])
    return 0


# ============================================================================
# Main
# ============================================================================


def construir_parser() -> argparse.ArgumentParser:
    p = ParserSeguro(prog="reddit_helper.py", description="reddit-search")
    p.add_argument("--salida", default=None, help="carpeta de salida (default ./reddit-salida o $REDDIT_SEARCH_SALIDA)")
    p.add_argument("--version", action="version", version=VERSION)
    p.add_argument("-v", "--verbose", action="store_true", help="registro de reintentos y circuitos")
    p.add_argument("--guardar-crudo", action="store_true",
                   help="solo para depurar: guarda la respuesta íntegra de cada fuente (puede contener texto hoy retirado)")
    s = p.add_subparsers(dest="cmd")

    d = s.add_parser("descubrir", help="buscar hilos en paralelo, deduplicar y fechar")
    d.add_argument("tema", help="consulta en el idioma de la comunidad (sin site:)")
    d.add_argument("--ventana", default="w,m", help="d,w,m,y,todo separadas por coma (default w,m)")
    d.add_argument("--fuentes", default=None,
                   help="automático según claves; subconjunto de brave,perplexity,firecrawl,you,arctic (you = You.com MCP gratuito, 100/día)")
    d.add_argument("--sub", action="append", help="subreddit a cubrir además de la búsqueda global (repetible)")
    d.add_argument("--n", type=int, default=20, help="resultados por fuente y ventana (máx. 20)")
    d.add_argument("--mas-urls", action="append", help="fichero con URLs halladas por el buscador propio del agente")
    d.add_argument("--carpeta", help="carpeta concreta para esta búsqueda")
    d.add_argument("--filas", type=int, default=60, help="filas del índice impreso")
    d.add_argument("--orden", choices=["fecha", "relevancia", "votos"], default="fecha", help="orden dentro de la ventana")
    d.add_argument("--json", action="store_true", help="imprimir el índice JSON")
    d.set_defaults(func=cmd_descubrir)

    l = s.add_parser("leer", aliases=["hilo"], help="leer un hilo completo por ID o URL")
    l.add_argument("ref", help="ID (1wubcvf), t3_ID o URL de reddit.com / redd.it / espejo")
    l.add_argument("--orden", choices=["arbol", "votos", "fecha"], default="arbol")
    l.add_argument("--max", type=int, default=None, help="máximo de comentarios impresos (el JSON guarda todos)")
    l.add_argument("--sin-votos-actuales", action="store_true", help="no consultar Redlib para votos actuales")
    l.add_argument("--carpeta", help="carpeta donde guardar <id>.json")
    l.add_argument("--json", action="store_true")
    l.set_defaults(func=cmd_leer)

    b = s.add_parser("lote", help="leer varios hilos (fichero de IDs/URLs, indice.json o - para stdin)")
    b.add_argument("lista")
    b.add_argument("--top", type=int, default=None, help="solo los N primeros")
    b.add_argument("--solo-ventana", action="store_true", help="del índice, solo hilos con fecha verificada dentro de la ventana")
    b.add_argument("--min-relevancia", type=float, default=0.0, help="del índice, relevancia mínima (0-1)")
    b.add_argument("--pausa", type=float, default=1.0, help="segundos entre hilos")
    b.add_argument("--sin-votos-actuales", action="store_true")
    b.add_argument("--carpeta")
    b.set_defaults(func=cmd_lote)

    c = s.add_parser("citas", help="párrafos literales que casan con un patrón, con metadatos")
    c.add_argument("corpus", help="corpus.json de lote o <id>.json de leer")
    c.add_argument("--buscar", required=True, help="expresión regular (sin distinguir mayúsculas)")
    c.add_argument("--min-votos", type=int, default=None)
    c.add_argument("--max", type=int, default=50)
    c.add_argument("--json", action="store_true")
    c.add_argument("--incluir-no-literales", action="store_true", help="incluir extractos redactados, retirados, reparados o sin identidad, etiquetados")
    c.set_defaults(func=cmd_citas)

    sa = s.add_parser("salud", help="qué fuentes funcionan hoy (las de pago, sin gastar: solo si hay clave)")
    sa.add_argument("--en-vivo", action="store_true", help="prueba también Brave, Perplexity y Firecrawl (gasta créditos)")
    sa.set_defaults(func=cmd_salud)

    cn = s.add_parser("conectar", help="guarda la clave de un servicio del modo experto desde el portapapeles")
    cn.add_argument("servicio", choices=sorted(PROVEEDORES_EXPERTOS))
    cn.add_argument("--preparar-fichero", action="store_true",
                    help="sin portapapeles: crea el fichero de claves con el hueco para que el usuario pegue la clave")
    cn.set_defaults(func=cmd_conectar)

    e = s.add_parser("exa", help="[heredado] Exa search (no devuelve reddit.com)")
    e.add_argument("consulta")
    e.add_argument("n", nargs="?", type=int, default=8)
    e.set_defaults(func=cmd_exa)
    w = s.add_parser("web", help="[heredado, antes «leer»] texto de páginas que NO son Reddit (Exa contents)")
    w.add_argument("urls", nargs="+")
    w.set_defaults(func=cmd_web)
    br = s.add_parser("brave", help="[heredado] Brave web site:reddit.com")
    br.add_argument("consulta")
    br.add_argument("n", nargs="?", type=int, default=10)
    br.add_argument("--ventana", default="w")
    br.set_defaults(func=cmd_brave)
    fc = s.add_parser("firecrawl", help="[heredado] markdown de una página que NO es Reddit (Reddit da 403)")
    fc.add_argument("url")
    fc.set_defaults(func=cmd_firecrawl)
    return p


def main(argv: Optional[List[str]] = None) -> int:
    try:
        _registrar_claves()
    except (ValueError, OSError) as e:
        _imprimir(f"ERROR: {e}", file=sys.stderr)
        return 2
    p = construir_parser()
    a = p.parse_args(argv)
    if a.verbose:
        logger.setLevel(logging.INFO)
    if not a.cmd:
        p.print_help()
        return 1
    try:
        _zona()
        for nombre in ("n", "max", "top", "filas", "pausa"):
            if hasattr(a, nombre):
                _limite(getattr(a, nombre), nombre)
        if hasattr(a, "min_votos"):
            _rango_entero(a.min_votos, "min-votos")
        if hasattr(a, "min_relevancia"):
            _ratio(a.min_relevancia)
        if hasattr(a, "ventana"):
            ventanas = a.ventana.split(",") if a.cmd == "descubrir" else [a.ventana]
            if any(v not in VENTANAS for v in ventanas):
                raise ValueError("ventana inválida: use d,w,m,y,todo")
        return a.func(a)
    except (RuntimeError, ValueError, HttpError, OSError, re.error, TypeError, AttributeError, KeyError, IndexError, EOFError, OverflowError) as e:
        _imprimir(f"ERROR: {redactar(str(e))}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
