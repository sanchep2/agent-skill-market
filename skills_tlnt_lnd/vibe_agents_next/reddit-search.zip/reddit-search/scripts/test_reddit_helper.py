#!/usr/bin/env python3
"""Tests offline de reddit_helper.py con respuestas reales capturadas el 7-oct-2026 (scripts/fixtures/). Sin red.

    python3 -m unittest discover -s "<ruta>/scripts"
"""

from __future__ import annotations

import contextlib
import io
import json
import os
import re
import socket
from datetime import timedelta, timezone
import sys
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).parent))
import reddit_helper as rh  # noqa: E402

FX = Path(__file__).parent / "fixtures"
PID = "1wubcvf"


def fx(nombre: str):
    texto = (FX / nombre).read_text(encoding="utf-8")
    return texto if nombre.endswith(".html") else json.loads(texto)


class FakeHttp:
    """Sustituye RedditHelper._http: enruta por URL a fixtures o a errores programados."""

    def __init__(self, rutas):
        self.rutas = rutas  # lista de (subcadena_url, resultado | Exception | callable)
        self.llamadas = []

    def __call__(self, fuente, url, cuerpo=None, cabeceras=None, json_resp=True, reintentos=4, procesar=None):
        self.llamadas.append((fuente, url, cuerpo))
        for sub, res in self.rutas:
            if sub in url:
                if isinstance(res, Exception):
                    raise res
                out = res(url, cuerpo) if callable(res) else res
                return procesar(out) if procesar else out
        raise rh.HttpError(404, "ruta no simulada", url)


def helper(tmp: str, rutas) -> rh.RedditHelper:
    h = rh.RedditHelper(salida=Path(tmp))
    h._http = FakeHttp(rutas)  # type: ignore[method-assign]
    return h


class OfflineTestCase(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        patches = (
            mock.patch.object(rh, "ZONA_FORZADA", timezone(timedelta(hours=-6))),
            mock.patch.dict(os.environ, {}, clear=True),
            mock.patch.object(rh, "fichero_claves", return_value=Path(tmp.name) / "sin-claves.env"),
            mock.patch.object(rh, "_CLAVES_CARGADAS", []),
            mock.patch.object(socket.socket, "connect", side_effect=AssertionError("RED PROHIBIDA")),
            mock.patch.object(rh.urllib.request.OpenerDirector, "open", side_effect=AssertionError("RED PROHIBIDA")),
        )
        for patch in patches:
            patch.start()
            self.addCleanup(patch.stop)


class TestIdsYFechas(OfflineTestCase):
    def test_ref_a_id_variantes(self):
        for ref in (PID, "t3_1wubcvf", "https://www.reddit.com/r/redditdev/comments/1wubcvf/moving_data/",
                    "https://old.reddit.com/r/redditdev/comments/1wubcvf", "https://redd.it/1wubcvf",
                    "https://safereddit.com/r/redditdev/comments/1wubcvf/x/", "  1WUBCVF "):
            self.assertEqual(rh.ref_a_id(ref), PID, ref)

    def test_ref_invalida(self):
        with self.assertRaises(ValueError):
            rh.ref_a_id("https://www.reddit.com/user/alguien/")

    def test_extraer_post_descarta_indices_y_perfiles(self):
        self.assertIsNone(rh.extraer_post("https://www.reddit.com/r/apple/"))
        self.assertIsNone(rh.extraer_post("https://www.reddit.com/user/x/comments/"))
        self.assertEqual(rh.extraer_post("https://www.reddit.com/r/rss/comments/1wubxkn/titulo/"), ("rss", "1wubxkn"))

    def test_iso_local(self):
        self.assertEqual(rh.iso_local(1790789831), "2026-09-30T11:37:11-06:00")
        self.assertIsNone(rh.iso_local(None))

    def test_relevancia(self):
        self.assertEqual(rh.relevancia("robot vacuum recommendation", "Best robot vacuum?"), 0.67)
        self.assertEqual(rh.relevancia("site:reddit.com", "x"), 0.0)


class TestParsers(OfflineTestCase):
    def test_arbol_arctic_completo(self):
        cs, pend = rh.aplanar_arbol(fx("arctic_tree_1wubcvf.json")["data"], "redditdev", PID)
        self.assertEqual(len(cs), 126)
        self.assertEqual(pend, [])
        primero = next(c for c in cs if c.id == "pd1pln5")
        self.assertEqual((primero.autor, primero.padre, primero.profundidad), ("shiruken", PID, 0))
        self.assertEqual(primero.fecha, "2026-09-30T11:46:40-06:00")
        self.assertTrue(any(c.profundidad >= 2 for c in cs))
        self.assertTrue(all(c.url.startswith("https://www.reddit.com/r/redditdev/comments/1wubcvf/") for c in cs))

    def test_arbol_con_more(self):
        nodos = [{"kind": "t1", "data": {"id": "aaaa1", "parent_id": "t3_p", "author": "x", "body": "hola", "created_utc": 1,
                                         "replies": {"data": {"children": [{"kind": "more", "data": {"children": ["t1_bbbb2", "cccc3"]}}]}}}}]
        cs, pend = rh.aplanar_arbol(nodos, "s", "p")
        self.assertEqual([c.id for c in cs], ["aaaa1"])
        self.assertEqual(pend, ["bbbb2", "cccc3"])

    def test_redlib_post_y_comentarios(self):
        red = rh.parse_redlib(fx("redlib_1wubcvf.html"))
        p = red["post"]
        self.assertEqual(p["titulo"], "Moving Data API Apps to the Developer Platform: migration dates and next steps")
        self.assertEqual((p["autor"], p["subreddit"], p["votos"]), ("boat-botany", "redditdev", 11))
        self.assertEqual(rh.iso_local(p["created_utc"]), "2026-09-30T11:37:11-06:00")
        self.assertIn("New requests for public API access will no longer be accepted", p["cuerpo"])
        cs = {c["id"]: c for c in red["comentarios"]}
        self.assertGreaterEqual(len(cs), 100)
        self.assertEqual((cs["pd1pln5"]["autor"], cs["pd1pln5"]["votos"], cs["pd1pln5"]["padre"]), ("shiruken", 33, None))
        self.assertEqual(cs["pd1yg6t"]["padre"], "pd1pln5")
        self.assertTrue(cs["pd1pln5"]["editado"])
        self.assertTrue(cs["pd1pln5"]["cuerpo"].startswith("Disappointed to see this finally happen but I can't say I'm surprised."))
        self.assertIn("\n\nI've already been contacted", cs["pd1pln5"]["cuerpo"])  # párrafos conservados

    def test_redlib_cuerpo_literal_igual_que_arctic(self):
        """Igualdad exacta de prosa cuyo Markdown no requiere transformar espacios ni sintaxis."""
        red = {c["id"]: c for c in rh.parse_redlib(fx("redlib_1wubcvf.html"))["comentarios"]}
        arc, _ = rh.aplanar_arbol(fx("arctic_tree_1wubcvf.json")["data"], "redditdev", PID)
        iguales, con_parrafos = 0, 0
        for c in arc:
            r = red.get(c.id)
            # Elegibilidad según el original, nunca según la igualdad observada con el parser.
            if (r and not c.editado and not r["editado"] and c.cuerpo
                    and not any(x in c.cuerpo for x in ("![", "http", "*", "`", "\\", ">", "#", "\r"))
                    and c.cuerpo == c.cuerpo.strip()
                    and not re.search(r"[ \t]{2}|[ \t]\n", c.cuerpo)):
                self.assertEqual(r["cuerpo"], c.cuerpo, c.id)
                iguales += 1
                con_parrafos += "\n\n" in c.cuerpo
        self.assertGreater(iguales, 40)
        self.assertGreater(con_parrafos, 0)

    def test_html_a_texto(self):
        self.assertEqual(rh.html_a_texto("<p>Hola &amp; adiós</p><script>x()</script><p>dos</p>"), "Hola & adiós\ndos")


class TestResiliencia(OfflineTestCase):
    def test_circuit_breaker_estados(self):
        cb = rh.CircuitBreaker(nombre="t", failure_threshold=2, recovery_timeout=0.05)
        self.assertTrue(cb.can_execute())
        cb.record_failure()
        cb.record_failure()
        self.assertEqual(cb.state, "open")
        self.assertFalse(cb.can_execute())
        import time
        time.sleep(0.06)
        self.assertTrue(cb.can_execute())
        self.assertEqual(cb.state, "half_open")
        cb.record_failure()
        self.assertEqual(cb.state, "open")
        time.sleep(0.06)
        cb.can_execute()
        cb.record_success()
        self.assertEqual(cb.state, "closed")

    def test_retry_reintenta_429_y_422_timeout(self):
        esperas = []
        for err in (rh.HttpError(429, "slow", "u"), rh.HttpError(422, "Timeout. Maybe slow down a bit", "u"),
                    urllib.error.URLError("dns")):
            n = {"i": 0}

            def fn(e=err):
                n["i"] += 1
                if n["i"] < 3:
                    raise e
                return "ok"

            self.assertEqual(rh.with_retry(fn, sleep=esperas.append), "ok")
            self.assertEqual(n["i"], 3)
        self.assertTrue(all(e > 0 for e in esperas))

    def test_retry_no_reintenta_403_ni_422_validacion(self):
        for err in (rh.HttpError(403, "blocked", "u"), rh.HttpError(422, "invalid parameter", "u")):
            n = {"i": 0}

            def fn(e=err):
                n["i"] += 1
                raise e

            cb = rh.CircuitBreaker(nombre="x", failure_threshold=1)
            with self.assertRaises(rh.HttpError):
                rh.with_retry(fn, circuit_breaker=cb, sleep=lambda s: None)
            self.assertEqual(n["i"], 1)
            self.assertEqual(cb.state, "open")
            with self.assertRaises(RuntimeError):
                rh.with_retry(lambda: "ok", circuit_breaker=cb)


class TestDescubrir(OfflineTestCase):
    def test_une_deduplica_e_hidrata(self):
        posts = fx("arctic_posts_ids.json")
        brave = {"web": {"results": [
            {"url": "https://www.reddit.com/r/redditdev/comments/1wubcvf/moving/", "title": "Moving", "description": "Data API",
             "extra_snippets": ["October 31"]},
            {"url": "https://www.reddit.com/r/apple/", "title": "índice", "description": ""},
            {"url": "https://en.wikipedia.org/wiki/Reddit", "title": "wiki", "description": ""},
            {"url": "https://redlib.example/r/x/comments/zzzzzz/", "title": "espejo sin reddit", "description": ""}]}}
        ppx = {"results": [{"url": "https://www.reddit.com/r/modnews/comments/1wubgvt/x/", "title": "infra", "date": "2026-09-30",
                            "snippet": "RSS feeds are retired on November 13"},
                           {"url": "https://www.reddit.com/r/redditdev/comments/1wubcvf/", "title": "Moving", "snippet": "dup"}]}
        fire = {"data": {"web": [{"url": "https://www.reddit.com/r/redditdev/comments/1whal6a/x/", "title": "ids",
                                  "description": "3 weeks ago"}]}}
        with tempfile.TemporaryDirectory() as t, mock.patch.object(rh, "ahora", return_value=1791400000), \
                mock.patch.object(rh, "clave", return_value="k"):
            h = helper(t, [("search.brave.com", brave), ("perplexity.ai", ppx), ("firecrawl.dev", fire),
                           ("/posts/ids", posts)])
            ix = h.descubrir("reddit data api", ventanas=["m"], fuentes=["brave", "perplexity", "firecrawl"],
                             mas_urls=["https://redd.it/1wubcvf", "https://www.reddit.com/r/xyz/comments/abc123/"])
            ids = [x["id"] for x in ix["hilos"]]
            self.assertEqual(sorted(ids), sorted(["1wubcvf", "1wubgvt", "1whal6a", "abc123"]))  # sin índice, wiki ni espejo
            moving = next(x for x in ix["hilos"] if x["id"] == PID)
            self.assertEqual(len([f for f in moving["fuentes"] if f != "agente"]), 2)
            self.assertIn("agente", moving["fuentes"])
            self.assertTrue(moving["fecha_verificada"])
            self.assertEqual(moving["fecha"], "2026-09-30T11:37:11-06:00")
            self.assertTrue(moving["en_ventana"])
            self.assertFalse(moving["votos_provisionales"])
            self.assertFalse(next(x for x in ix["hilos"] if x["id"] == "abc123")["fecha_verificada"])
            self.assertTrue((Path(ix["carpeta"]) / "indice.json").is_file())
            self.assertFalse((Path(ix["carpeta"]) / "crudo").exists())  # crudo apagado por defecto (1.3.0)
            md = rh.indice_md(ix)
            self.assertIn("| 1wubcvf |", md)

    def test_fuente_caida_no_tumba_el_resto(self):
        with tempfile.TemporaryDirectory() as t, mock.patch.object(rh, "clave", return_value="k"):
            h = helper(t, [("search.brave.com", rh.HttpError(401, "bad key", "u")), ("perplexity.ai", {"results": []}),
                           ("firecrawl.dev", {"data": {"web": []}}), ("/posts/ids", {"data": []})])
            ix = h.descubrir("x", ventanas=["w"], fuentes=["brave", "perplexity", "firecrawl"])
            self.assertFalse(ix["fuentes"]["brave:w"]["ok"])
            self.assertTrue(ix["fuentes"]["perplexity:w"]["ok"])

    def test_arctic_solo_con_subreddit_y_brave_con_sub_como_termino(self):
        with tempfile.TemporaryDirectory() as t, mock.patch.object(rh, "clave", return_value="k"):
            h = helper(t, [("search.brave.com", {"web": {"results": []}}), ("/posts/search", {"data": []}),
                           ("/posts/ids", {"data": []})])
            h.descubrir("x", ventanas=["w"], fuentes=["brave", "arctic"], subs=["r/Python"])
            urls = [u for _, u, _ in h._http.llamadas]
            brave = [u for u in urls if "search.brave.com" in u]
            self.assertEqual(len(brave), 2)  # global + subreddit
            self.assertTrue(any("q=site%3Areddit.com+Python+x" in u for u in brave))  # nombre como término, no ruta
            self.assertFalse(any("reddit.com%2Fr%2F" in u for u in brave))
            self.assertTrue(any("subreddit=Python" in u for u in urls))


class TestLeer(OfflineTestCase):
    def rutas_ok(self):
        return [("/posts/ids", fx("arctic_posts_ids.json")), ("/comments/tree", fx("arctic_tree_1wubcvf.json")),
                ("safereddit.com", fx("redlib_1wubcvf.html"))]

    def test_arctic_con_votos_actuales_de_redlib(self):
        with tempfile.TemporaryDirectory() as t:
            r = helper(t, self.rutas_ok()).leer("https://www.reddit.com/r/redditdev/comments/1wubcvf/x/")
            self.assertEqual(r["cobertura"]["estado"], "completa")
            self.assertEqual(r["cobertura"]["comentarios_leidos"], 127)  # 126 de Arctic Shift + pd2v83h, que solo está en Redlib
            self.assertTrue(any(c["id"] == "pd2v83h" for c in r["comentarios"]))
            self.assertEqual(r["post"]["votos"], 11)
            self.assertEqual(r["post"]["votos_arctic"], 6)
            c = next(c for c in r["comentarios"] if c["id"] == "pd1pln5")
            self.assertEqual((c["votos"], c["votos_fuente"]), (33, "redlib:safereddit.com"))
            # editado tras la captura: manda el texto actual y el capturado queda aparte
            self.assertTrue(c["cuerpo"].startswith("Disappointed to see this finally happen"))
            self.assertEqual(c["cuerpo_capturado"], "![gif](giphy|lD76yTC5zxZPG)")
            self.assertEqual(c["cuerpo_fuente"], "redlib:safereddit.com")
            self.assertTrue((Path(t) / "hilos" / f"{PID}.json").is_file())
            md = rh.hilo_md(r, "votos", 2)
            self.assertIn("— u/shiruken [editado] · r/redditdev · 2026-09-30T11:46:40-06:00 · 33 votos", md)

    def test_sin_arctic_cae_a_redlib(self):
        with tempfile.TemporaryDirectory() as t:
            r = helper(t, [("arctic-shift", rh.HttpError(503, "down", "u")), ("safereddit.com", fx("redlib_1wubcvf.html"))]).leer(PID)
            self.assertEqual(r["fuentes"], ["redlib:safereddit.com"])
            self.assertGreaterEqual(r["cobertura"]["comentarios_leidos"], 100)
            self.assertEqual(r["post"]["autor"], "boat-botany")

    def test_desafio_antibot_no_cuenta_como_hilo(self):
        with tempfile.TemporaryDirectory() as t, mock.patch.object(rh, "clave", return_value="k"):
            anubis = "<html><title>Making sure you're not a bot!</title> anubis </html>"
            r = helper(t, [("arctic-shift", rh.HttpError(503, "down", "u")), ("safereddit.com", anubis),
                           ("artemislena", anubis), ("synth.download", anubis),
                           ("llm/context", fx("brave_llm_context.json")), ("web.archive.org", [])]).leer("1wubgvt")
            self.assertEqual(r["cobertura"]["estado"], "fragmentos")
            self.assertEqual(r["fuentes"], ["brave-llm-context"])
            self.assertTrue(all("1wubgvt" in f["url"] for f in r["fragmentos"]))  # nunca fragmentos de OTRO hilo

    def test_brave_llm_descarta_otros_ids(self):
        with tempfile.TemporaryDirectory() as t, mock.patch.object(rh, "clave", return_value="k"):
            r = helper(t, [("arctic-shift", rh.HttpError(503, "down", "u")), ("safereddit.com", rh.HttpError(403, "cf", "u")),
                           ("artemislena", rh.HttpError(403, "cf", "u")), ("synth.download", rh.HttpError(403, "cf", "u")),
                           ("llm/context", fx("brave_llm_context.json")), ("web.archive.org", [])]).leer("zzzzzz9")
            self.assertEqual(r["cobertura"]["estado"], "sin_texto")
            self.assertEqual(r["fragmentos"], [])
            self.assertTrue(any("ningún fragmento" in x for x in r["cobertura"]["intentos_fallidos"]))


class TestCitasYCli(OfflineTestCase):
    def test_citas_literales_con_metadatos(self):
        with tempfile.TemporaryDirectory() as t:
            r = helper(t, TestLeer().rutas_ok()).leer(PID)
        cs = rh.citas({"hilos": [r]}, r"devvit", min_votos=10)
        # Expectativas independientes: originales de la fixture Arctic, y los dos cuerpos editados
        # conocidos del HTML real. Ninguna atribución se toma del hilo producido por leer().
        originales = {None: fx("arctic_posts_ids.json")["data"][0]}
        pila = list(fx("arctic_tree_1wubcvf.json")["data"])
        while pila:
            dato = pila.pop()["data"]
            originales[dato["id"]] = dato
            if isinstance(dato.get("replies"), dict):
                pila.extend(dato["replies"]["data"]["children"])
        editados = {
            "pd1pln5": ("shiruken", ["I've already been contacted about migrating the bots and scripts used by r/science to Devvit. I don't have the time nor the energy to undertake such a task. Neither do my co-mods. So everything will just break come March."]),
            "pd2cbu4": ("emily_in_boots", [
                "Previously, you had said that API access would continue until Devvit could support existing uses.",
                "Devvit still cannot support the features required to implement my bots.",
                "I have 300,000 lines of python code. I cannot rewrite that in 6 months even if I were to work on it full time and even if Devvit could do what I need it to for my subreddits to continue to function."]),
        }
        ids = ("pd1pln5", "pd2iwcg", "pd2cbu4", "pd2bexs", "pd339dk", "pd2ic7e", "pd45g9m", None, "pd1yg6t", "pd39ctg")
        # Valores escritos desde las fixtures, independientes de leer() y citas().
        # Todos estos votos actuales proceden de Redlib, incluso con cuerpo Arctic.
        metadatos = {
            "pd1pln5": ("redditdev", "2026-09-30T11:46:40-06:00", 33, "redlib:safereddit.com"),
            "pd2iwcg": ("redditdev", "2026-09-30T13:49:27-06:00", 27, "redlib:safereddit.com"),
            "pd2cbu4": ("redditdev", "2026-09-30T13:21:06-06:00", 25, "redlib:safereddit.com"),
            "pd2bexs": ("redditdev", "2026-09-30T13:17:13-06:00", 15, "redlib:safereddit.com"),
            "pd339dk": ("redditdev", "2026-09-30T15:16:04-06:00", 15, "redlib:safereddit.com"),
            "pd2ic7e": ("redditdev", "2026-09-30T13:47:05-06:00", 14, "redlib:safereddit.com"),
            "pd45g9m": ("redditdev", "2026-09-30T18:33:24-06:00", 12, "redlib:safereddit.com"),
            None: ("redditdev", "2026-09-30T11:37:11-06:00", 11, "redlib:safereddit.com"),
            "pd1yg6t": ("redditdev", "2026-09-30T12:22:49-06:00", 11, "redlib:safereddit.com"),
            "pd39ctg": ("redditdev", "2026-09-30T15:43:39-06:00", 11, "redlib:safereddit.com"),
        }
        esperadas = []
        for cid in ids:
            if cid in editados:
                autor, parrafos = editados[cid]
                fuente = "redlib:safereddit.com"
            else:
                dato = originales[cid]
                autor, fuente = dato["author"], "arctic-shift"
                parrafos = [p for p in dato.get("body", dato.get("selftext", "")).split("\n\n") if re.search("devvit", p, re.I)]
            esperadas.extend((PID, cid, autor, fuente, texto, *metadatos[cid]) for texto in parrafos)
        obtenidas = [(q["hilo_id"], q["comentario_id"], q["autor"], q["cuerpo_fuente"], q["texto"],
                      q["subreddit"], q["fecha"], q["votos"], q["votos_fuente"]) for q in cs]
        self.assertEqual(len(cs), 17)
        self.assertCountEqual(obtenidas, esperadas)
        for q in cs:
            self.assertEqual((q["literal"], q["identidad_verificada"]), (True, True))
            url = rh.url_canonica("redditdev", PID)
            if q["comentario_id"]:
                dato = originales[q["comentario_id"]]
                url = (rh.urllib.parse.urljoin("https://www.reddit.com", dato["permalink"]) if dato.get("permalink")
                       else url + "_/" + q["comentario_id"] + "/")
            self.assertEqual(q["url"], url)
            self.assertGreaterEqual(q["votos"], 10)
            self.assertTrue(q["fecha"].endswith("-06:00"))

    def test_help_de_cada_subcomando(self):
        for sub in ([], ["descubrir"], ["leer"], ["lote"], ["citas"], ["salud"], ["exa"], ["web"], ["brave"], ["firecrawl"]):
            with contextlib.redirect_stdout(io.StringIO()), self.assertRaises(SystemExit) as cm:
                rh.main(sub + ["--help"])
            self.assertEqual(cm.exception.code, 0, sub)

    def test_no_imprime_claves(self):
        secreto = "sk-PRUEBA-1234567890abcdef"
        err = io.StringIO()
        with mock.patch.dict(os.environ, {"BRAVE_SEARCH_API_KEY": secreto}), contextlib.redirect_stderr(err), \
                contextlib.redirect_stdout(io.StringIO()), \
                mock.patch.object(rh.RedditHelper, "buscar_brave",
                                  side_effect=lambda *a, **k: (_ for _ in ()).throw(
                                      rh.HttpError(401, rh.redactar(f"bad token {rh.clave('BRAVE_SEARCH_API_KEY')}"), "u"))):
            codigo = rh.main(["brave", "x"])
        self.assertEqual(codigo, 2)
        self.assertNotIn(secreto, err.getvalue())
        self.assertIn("[CLAVE]", err.getvalue())

    def test_falta_clave_mensaje_sin_valor(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            os.environ.pop("PERPLEXITY_API_KEY", None)
            with self.assertRaises(RuntimeError) as cm:
                rh.clave("PERPLEXITY_API_KEY")
            self.assertIn("falta PERPLEXITY_API_KEY", str(cm.exception))

    def test_lote_desde_lista(self):
        with tempfile.TemporaryDirectory() as t:
            lista = Path(t) / "l.txt"
            lista.write_text("# hilos\nhttps://www.reddit.com/r/redditdev/comments/1wubcvf/\n1wubcvf\nhttps://example.com/no-hilo\n")
            self.assertEqual(rh._leer_lista(str(lista), None, False, 0.0), [PID])


class TestNuevasFuentes(OfflineTestCase):
    def test_brave_qa_y_filtro_de_sub(self):
        d = {"web": {"results": [
            {"url": "https://www.reddit.com/r/ClaudeAI/comments/1wz0n3w/x/", "title": "t", "description": "d",
             "qa": {"question": "<p>Post &amp; original</p>", "answer": {"text": "If you want specific variable names, just tell it."}}},
            {"url": "https://www.reddit.com/r/Otro/comments/1aaaaaa/y/", "title": "t2", "description": "d2"}]}}
        with tempfile.TemporaryDirectory() as t, mock.patch.object(rh, "clave", return_value="k"):
            r = helper(t, [("search.brave.com", d)]).buscar_brave("x", "w", 10, "ClaudeAI")
        self.assertEqual(len(r["resultados"]), 1)
        self.assertIn("POST:  Post & original", r["resultados"][0]["texto"])
        self.assertIn("RESPUESTA: If you want specific variable names", r["resultados"][0]["texto"])

    def test_you_mcp_sse(self):
        payload = {"results": {"web": [{"url": "https://www.reddit.com/r/homeautomation/comments/1rbqj2j/x/", "title": "Which robot",
                                        "description": "508 votes", "page_age": "2026-02-22T16:41:14",
                                        "contents": {"highlights": ["### Flanko67\nI love our Roborock."]}}]}}
        sse = ('event: message\ndata: {"jsonrpc":"2.0","method":"notifications/message","params":{}}\n\n'
               'event: message\ndata: ' + json.dumps({"jsonrpc": "2.0", "id": 1, "result": {"content": [{"type": "text", "text": json.dumps(payload)}]}}) + "\n")
        with tempfile.TemporaryDirectory() as t:
            r = helper(t, [("api.you.com", sse)]).buscar_you("robot vacuum", "w")
        self.assertEqual(r["resultados"][0]["url"], "https://www.reddit.com/r/homeautomation/comments/1rbqj2j/x/")
        self.assertIn("I love our Roborock.", r["resultados"][0]["texto"])
        self.assertEqual(r["peticion"]["freshness"], "week")

    def test_arctic_respaldo_listado_si_query_satura(self):
        def busqueda(url, cuerpo):
            if "query=" in url:
                raise rh.HttpError(422, "Timeout. Maybe slow down a bit", url)
            return {"data": [{"id": "aaaa1", "subreddit": "s", "title": "comisiones del banco", "selftext": "", "created_utc": 1},
                             {"id": "bbbb2", "subreddit": "s", "title": "otra cosa", "selftext": "", "created_utc": 2}]}
        with tempfile.TemporaryDirectory() as t:
            h = helper(t, [("/posts/search", busqueda)])
            r = h.buscar_arctic("comisiones banco", "m", 20, "s")
        self.assertEqual([x["url"] for x in r["resultados"]], ["https://www.reddit.com/r/s/comments/aaaa1/"])
        self.assertEqual(r["peticion"]["filtro_local"], "comisiones banco")

    def test_marcas_op_bot_y_votos_ocultos(self):
        c = rh.comentario_arctic({"id": "aaaa", "parent_id": "t3_p", "author": "AutoModerator", "score": 1, "score_hidden": True,
                                  "is_submitter": False, "distinguished": "moderator", "body": "x"}, "s", "p", 0)
        self.assertEqual((c.votos, c.es_bot, c.es_op, c.distinguido), (None, True, False, "moderator"))
        self.assertFalse(rh.es_bot("robotics_fan"))
        self.assertTrue(rh.es_bot("RemindMeBot"))

    def test_citas_excluye_bots_por_defecto(self):
        h = {"url": "u", "post": {"cuerpo": "", "subreddit": "s"}, "comentarios": [
            {"cuerpo": "devvit bot text", "autor": "AutoModerator", "fecha": "f", "votos": 9, "url": "u1", "es_bot": True},
            {"cuerpo": "devvit human text", "autor": "ana", "fecha": "f", "votos": 2, "url": "u2", "es_bot": False}]}
        self.assertEqual([c["autor"] for c in rh.citas({"hilos": [h]}, "devvit")], ["ana"])
        self.assertEqual(len(rh.citas({"hilos": [h]}, "devvit", excluir_bots=False)), 2)


if __name__ == "__main__":
    unittest.main()
