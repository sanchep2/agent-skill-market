"""Regresiones de seguridad y portabilidad (redacción de claves, identidad, literalidad, cobertura y zona horaria). Sin red."""
import contextlib
import gzip
import http.client
import io
import json
import logging
import os
import socket
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys
from concurrent.futures import ThreadPoolExecutor
import threading
import time
import unittest
import urllib.error
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import reddit_helper as rh

PID = "aaaa1"
OTHER = "bbbb2"
SECRET = 'TEST-FAKE-KEY-1234567890'


def comment(cid="cccc3", **extra):
    result = dict(id=cid, author="alice", body="texto original", score=10,
                  created_utc=1790789831, parent_id="t3_" + PID, link_id="t3_" + PID)
    result.update(extra)
    return result


def post(pid=PID, **extra):
    result = dict(id=pid, title="post " + pid, selftext="cuerpo " + pid,
                author="autor-" + pid, subreddit="pruebas", num_comments=1,
                created_utc=1790789831)
    result.update(extra)
    return result


def node(c):
    return {"kind": "t1", "data": c}


def html_comment(cid, body, author="alice", cls="comment"):
    return (f'<div class="{cls}" id="{cid}"><a class="comment_author">u/{author}</a>'
            f'<div class="comment_body"><div class="md">{body}</div></div></div>')


class Response:
    def __init__(self, raw, headers=None):
        self.raw = raw
        self.headers = headers or {"Content-Type": "application/json"}

    def read(self, n=-1):
        return self.raw

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass



import tempfile

class Endurecimiento(unittest.TestCase):
    def setUp(self):
        self.patch(rh, "ZONA_FORZADA", timezone(timedelta(hours=-6)))
        self.patch(socket.socket, "connect", side_effect=AssertionError("RED PROHIBIDA"))
        entorno = mock.patch.dict(os.environ, {}, clear=True)
        entorno.start()
        self.addCleanup(entorno.stop)
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.out = Path(tmp.name)
        # Aislar las claves ANTES de crear el helper: su constructor lee el fichero de claves.
        self.patch(rh, "_CLAVES_CARGADAS", [])
        self.patch(rh, "fichero_claves", return_value=self.out / "sin-env")
        self.helper = rh.RedditHelper(self.out, guardar_crudo=True)
        self.patch(rh.urllib.request.OpenerDirector, "open", side_effect=AssertionError("RED PROHIBIDA"))

    def patch(self, obj, name, *args, **kwargs):
        p = mock.patch.object(obj, name, *args, **kwargs)
        self.addCleanup(p.stop)
        return p.start()

    def fake_arctic(self, p=None, nodes=None, extra=None):
        def http(source, url, *args, **kwargs):
            if "/posts/ids" in url:
                return {"data": [p or post()]}
            if "/comments/tree" in url:
                return {"data": nodes or []}
            if "/comments/ids" in url:
                return {"data": extra or []}
            raise AssertionError(url)
        self.helper._http = mock.Mock(side_effect=http)

    def red(self, body="uno"):
        return f'<meta property="og:url" content="/comments/{PID}/"><div class="post"><h1 class="post_title">Título</h1><div class="post_body">Post</div></div>' + html_comment("cccc3", body)

    def test_01_secret_in_raw_and_stdout(self):
        rh._CLAVES_CARGADAS.append(SECRET)
        data = {"web": {"results": [{"url": "https://redd.it/" + PID, "description": SECRET}]}}
        self.helper._crudo(self.out, "brave", PID, {}, data)
        raw = next((self.out / "crudo").glob("*.json")).read_text()
        self.assertNotIn(SECRET, raw)
        self.assertIn("[CLAVE]", raw)
        with mock.patch.dict(os.environ, {"BRAVE_SEARCH_API_KEY": SECRET}), mock.patch.object(rh.urllib.request.OpenerDirector, "open", return_value=Response(json.dumps(data).encode())), contextlib.redirect_stdout(io.StringIO()) as stdout:
            self.assertEqual(rh.main(["brave", "tema"]), 0)
        self.assertNotIn(SECRET, stdout.getvalue())

    def test_02_secret_in_exception_url_and_short_key(self):
        rh._CLAVES_CARGADAS.extend([SECRET, "key123", 'a"\nñb'])
        url = "https://example.invalid/?token=" + SECRET
        error = urllib.error.HTTPError(url, 401, "bad", {}, io.BytesIO(SECRET.encode()))
        with mock.patch.object(rh.urllib.request.OpenerDirector, "open", side_effect=error), self.assertRaises(rh.HttpError) as caught:
            self.helper._http("demo", url)
        for value in (str(caught.exception), caught.exception.url, caught.exception.cuerpo):
            self.assertNotIn(SECRET, value)
        self.assertEqual(rh.redactar("key123"), "[CLAVE]")
        for ascii in (True, False):
            self.assertEqual(json.loads(rh.redactar(json.dumps('a"\nñb', ensure_ascii=ascii))), "[CLAVE]")

    def test_03_wrong_arctic_post_and_foreign_comment_become_citations(self):
        self.fake_arctic(p=post(OTHER), nodes=[node(comment())])
        with self.assertRaisesRegex(ValueError, "post solicitado"):
            self.helper._leer_arctic(PID, self.out)
        foreign = comment()
        foreign["link_id"] = "t3_" + OTHER
        bad_url = comment(cid="dddd4", permalink=f"/comments/{OTHER}/_/dddd4/")
        self.fake_arctic(nodes=[node(foreign), node(bad_url), node(comment(cid="eeee5"))])
        r = self.helper.leer(PID, votos_actuales=False)
        self.assertEqual([c["id"] for c in r["comentarios"]], ["eeee5"])
        self.assertEqual(r["cobertura"]["descartados_identidad"], 2)

    def test_04_wrong_redlib_page_accepted_as_requested_thread(self):
        self.helper._http = mock.Mock(return_value=self.red().replace(PID, OTHER))
        red, _, err = self.helper._leer_redlib(PID, "pruebas", self.out)
        self.assertIsNone(red)
        self.assertIn("identidad", err)

    def test_05_code_indentation_and_string_changed(self):
        code = 'if True:\n    print("a  b")\n\n\n    pass'
        r = rh.parse_redlib(html_comment("cccc3", "<pre><code>" + code + "</code></pre>"))
        self.assertEqual(r["comentarios"][0]["cuerpo"], code)

    def test_06_table_cells_join_words_nested_quotes_flattened(self):
        r = rh.parse_redlib(html_comment("cccc3", '<table><tr><td>sin</td><td>permiso</td></tr></table>'))
        self.assertEqual(r["comentarios"][0]["cuerpo"], "sin permiso")
        r = rh.parse_redlib(html_comment("cccc3", '<blockquote><p>uno</p><blockquote><p>dos</p></blockquote></blockquote>'))
        self.assertIn(">> dos", r["comentarios"][0]["cuerpo"])

    def test_07_extra_comment_class_overwrites_parent_attribution(self):
        for cls in ("comment collapsed", "comment deleted", " deleted  comment "):
            parent = html_comment("cccc3", "<p>padre</p>", "alice")[:-6]
            child = html_comment("dddd4", "<p>hijo</p>", "bob", cls)
            cs = rh.parse_redlib(parent + child + "</div>")["comentarios"]
            self.assertEqual([(c["id"], c["autor"], c["cuerpo"]) for c in cs], [("cccc3", "alice", "padre"), ("dddd4", "bob", "hijo")])
            self.assertEqual(cs[1]["padre"], "cccc3")

    def test_08_merge_retains_deleted_text_old_post_and_hidden_score(self):
        for tombstone in ("[deleted]", "[removed]"):
            c = rh.comentario_arctic(comment(edited=True), "pruebas", PID, 0)
            p = {"cuerpo": "post antes", "editado": True}
            red = {"post": {"cuerpo": "post después"}, "comentarios": [dict(id=c.id, autor="[deleted]", votos=None, cuerpo=tombstone, editado=True, identidad_verificada=True)]}
            rh.RedditHelper._fusionar_votos(p, [c], red, "mirror")
            self.assertEqual(c.cuerpo, tombstone)
            self.assertTrue(c.retirado)
            self.assertIsNone(c.cuerpo_capturado)
            self.assertIsNone(c.votos)
            self.assertEqual(c.votos_fuente, "redlib:mirror")
            self.assertEqual((p["cuerpo"], p["cuerpo_capturado"]), ("post después", "post antes"))
            self.assertEqual(rh.citas({"hilos": [{"url": "u", "post": {}, "comentarios": [rh.asdict(c)]}]}, "."), [])

    def test_09_more_duplicates_falsely_complete(self):
        more = {"kind": "more", "data": {"children": ["cccc3"] * 101 + ["dddd4"]}}
        self.fake_arctic(p=post(num_comments=0), nodes=[more], extra=[comment(), comment(cid="eeee5")])
        r = self.helper.leer(PID, votos_actuales=False)
        self.assertEqual([c["id"] for c in r["comentarios"]], ["cccc3"])
        self.assertEqual(r["cobertura"]["estado"], "parcial")
        self.assertEqual(r["cobertura"]["pendientes"], ["dddd4"])
        self.assertEqual(len(rh.citas({"hilos": [r]}, "original")), 1)

    def test_10_more_failure_not_reported_in_thread_coverage(self):
        self.fake_arctic(nodes=[node(comment()), {"kind": "more", "data": {"children": ["dddd4"]}}])
        http = self.helper._http.side_effect
        def fail(source, url, *args, **kwargs):
            if "/comments/ids" in url:
                raise rh.HttpError(503, "indisponible", url)
            return http(source, url)
        self.helper._http.side_effect = fail
        r = self.helper.leer(PID, votos_actuales=False)
        self.assertEqual(r["cobertura"]["estado"], "parcial")
        self.assertEqual(r["cobertura"]["pendientes"], ["dddd4"])
        self.assertTrue(r["avisos"])
        self.assertEqual(json.loads((self.out / "hilos" / (PID + ".json")).read_text())["avisos"], r["avisos"])

    def test_11_redlib_unpaginated_claims_complete(self):
        def http(source, url, *args, **kwargs):
            if source == "arctic":
                raise rh.HttpError(404, "no post", url)
            return self.red() + '<a class="more" href="?after=cccc3">Load more comments</a>'
        self.helper._http = mock.Mock(side_effect=http)
        r = self.helper.leer(PID)
        self.assertEqual(r["cobertura"]["estado"], "parcial")
        self.assertFalse(r["cobertura"]["completitud_verificada"])

    def test_12_urls_false_positives_and_canonical_false_negative(self):
        for url in ("https://evil.invalid/?next=/r/pruebas/comments/aaaa1/", "https://notredd.it/aaaa1", "https://redd.it/aaaa1-too-long", "https://www.reddit.com/comments/aaaa1/?next=%2Fcomments%2Fbbbb2", "https://www.reddit.com/comments/aaaa1/#/comments/bbbb2"):
            self.assertIsNone(rh.extraer_post(url), url)
            with self.assertRaises(ValueError):
                rh.ref_a_id(url)
        self.assertEqual(rh.ref_a_id(rh.url_canonica("", PID)), PID)
        self.assertEqual(rh.extraer_post("https://www.reddit.com/r/R/comments/aaaa1/"), ("R", PID))

    def test_13_future_timestamp_and_numeric_string_window(self):
        self.helper._hidratar = lambda hs, folder: [setattr(h, "created_utc", 2000000001) for h in hs]
        with mock.patch.object(rh, "ahora", return_value=2000000000):
            ix = self.helper.descubrir("tema", fuentes=[], ventanas=["w"], mas_urls=["https://redd.it/" + PID])
        self.assertFalse(ix["hilos"][0]["en_ventana"])
        del self.helper._hidratar
        self.helper._http = mock.Mock(return_value={"data": [post(created_utc="1790789831")]})
        ix = self.helper.descubrir("tema", fuentes=[], mas_urls=["https://redd.it/" + PID])
        self.assertIsInstance(ix["hilos"][0]["created_utc"], float)
        self.assertIsNotNone(rh.iso_local(0))
        for bad in ("nan", "inf", "-inf", "no fecha"):
            with self.assertRaises(ValueError):
                rh.iso_local(bad)

    def test_14_half_open_allows_all_threads(self):
        cb = rh.CircuitBreaker(failure_threshold=1, recovery_timeout=0)
        cb.record_failure()
        gate = threading.Barrier(8)
        def probe(_):
            gate.wait(timeout=3)
            return cb.can_execute()
        with ThreadPoolExecutor(max_workers=8) as executor:
            accepted = list(executor.map(probe, range(8)))
        self.assertEqual(sum(accepted), 1)
        cb.record_success()
        self.assertTrue(cb.can_execute())

    def test_15_retry_after_ignored(self):
        for value in ("120", "Thu, 01 Jan 1970 00:18:40 GMT"):
            url = "https://example.invalid/"
            error = urllib.error.HTTPError(url, 429, "limited", {"Retry-After": value}, io.BytesIO(b"limit"))
            waits = []
            reloj = [1000.0]
            def dormir(segundos):
                waits.append(segundos)
                reloj[0] += segundos
            original = rh.with_retry
            def retry(*args, **kwargs):
                return original(*args, **kwargs, sleep=dormir)
            with mock.patch.object(rh.time, "time", side_effect=lambda: reloj[0]), mock.patch.object(rh, "with_retry", side_effect=retry), mock.patch.object(rh.urllib.request.OpenerDirector, "open", side_effect=[error, Response(b'{}')]):
                self.assertEqual(self.helper._http("demo", url), {})
            self.assertEqual(waits, [120.0])

    def test_16_invalid_json_corrupt_gzip_and_incomplete_read_not_retried(self):
        url = "https://example.invalid/"
        for bad in (Response(b'{broken'), Response(b'\x1f\x8bgarbage'), http.client.IncompleteRead(b"part", 10)):
            original = rh.with_retry
            def retry(*args, **kwargs):
                return original(*args, **kwargs, sleep=lambda _: None)
            effects = [bad, Response(b'{"ok": true}')]
            with mock.patch.object(rh, "with_retry", side_effect=retry), mock.patch.object(rh.urllib.request.OpenerDirector, "open", side_effect=effects) as mocked:
                self.assertEqual(self.helper._http("demo", url), {"ok": True})
            self.assertEqual(mocked.call_count, 2)
        self.assertTrue(rh.es_reintentable(http.client.IncompleteRead(b"part", 10)))

    def test_17_cli_regex_type_shape_and_eof_escape(self):
        empty = self.out / "corpus con espacios.json"
        empty.write_text('{"hilos": []}')
        with contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(rh.main(["citas", str(empty), "--buscar", "["]), 2)
            for error in (AttributeError("JSON lista"), EOFError("gzip"), TypeError("contrato")):
                with mock.patch.object(rh.RedditHelper, "buscar_brave", side_effect=error):
                    self.assertEqual(rh.main(["brave", "tema"]), 2)
        self.assertEqual(rh.main(["citas", str(empty), "--buscar", "ok"]), 3)

    def test_18_you_error_and_json_silently_empty(self):
        for msg in ({"error": {"code": -32000, "message": "quota"}}, {"result": {"isError": True, "content": [{"type": "text", "text": "quota"}]}}):
            msg.update(jsonrpc="2.0", id=1)
            for payload in (json.dumps(msg), "data: " + json.dumps(msg) + "\n"):
                self.helper._http = mock.Mock(return_value=payload)
                with self.assertRaisesRegex(rh.HttpError, "cuota You"):
                    self.helper.buscar_you("tema", "w")
        msg = {"jsonrpc": "2.0", "id": 1, "result": {"content": [{"type": "text", "text": json.dumps({"results": {"web": [{"url": "https://redd.it/" + PID}]}})}]}}
        self.helper._http = mock.Mock(return_value=json.dumps(msg))
        self.assertEqual(len(self.helper.buscar_you("tema", "w")["resultados"]), 1)
        self.helper._http = mock.Mock(return_value='{"result":{"content":[{"type":"text","text":"{}"}]}}')
        with self.assertRaises(ValueError):
            self.helper.buscar_you("tema", "w")

    def test_19_lote_returns_success_without_any_content(self):
        lista = self.out / "lista con espacios.txt"
        lista.write_text(PID + "\n")
        for estado, code in (("sin_texto", 4), ("fragmentos", 4), ("parcial", 0), ("completa", 0)):
            empty = {"id": PID, "url": "u", "post": {}, "comentarios": [], "fuentes": [], "cobertura": {"estado": estado, "comentarios_leidos": 0, "con_texto": 0}}
            with mock.patch.object(rh.RedditHelper, "leer", return_value=empty), contextlib.redirect_stdout(io.StringIO()) as out:
                self.assertEqual(rh.main(["lote", str(lista), "--carpeta", str(self.out)]), code)
            self.assertIn(estado + "=1", out.getvalue())

    def test_20_zero_negative_limits_and_index_validation(self):
        lista = self.out / "lista.txt"
        lista.write_text(PID + "\n" + OTHER + "\n")
        self.assertEqual(rh._leer_lista(str(lista), 0, False, 0), [])
        with self.assertRaises(ValueError):
            rh._leer_lista(str(lista), -1, False, 0)
        lista.write_text(json.dumps({"hilos": [{"id": PID, "en_ventana": "false", "relevancia": 1}]}))
        with self.assertRaises(ValueError):
            rh._leer_lista(str(lista), None, True, 0)
        with self.assertRaises(ValueError):
            rh.citas({"hilos": []}, ".", maximo=-1)
        self.assertEqual(rh.citas({"hilos": []}, ".", maximo=0), [])

    def test_21_search_silently_caps_n_and_does_not_paginate(self):
        self.helper._http = mock.Mock(return_value={"web": {"results": []}})
        with mock.patch.object(rh, "clave", return_value="fake"):
            r = self.helper.buscar_brave("tema", "w", n=40)
        self.assertEqual(r["peticion"]["count"], 20)
        self.assertTrue(r["truncado"])
        self.assertEqual(self.helper._http.call_count, 1)
        # Contrato real de Brave (fixture): query.more_results_available, no un `has_more` inventado.
        fixture = json.loads((ROOT / "scripts" / "fixtures" / "brave_web.json").read_text(encoding="utf-8"))
        self.assertTrue(fixture["query"]["more_results_available"])
        self.helper._http = mock.Mock(return_value=fixture)
        with mock.patch.object(rh, "clave", return_value="fake"):
            r = self.helper.buscar_brave("tema", "w", n=10)
        self.assertTrue(r["truncado"])

    def test_22_wayback_wrong_thread_and_short_row(self):
        header = ["urlkey", "timestamp", "original"]
        for fila in (["key", "20260101000000", "https://redd.it/" + OTHER], ["key"]):
            self.helper._http = mock.Mock(return_value=[header, fila])
            fallos = []
            self.assertIsNone(self.helper._leer_wayback(PID, PID, self.out, fallos))
            self.assertTrue(fallos)
            self.assertEqual(self.helper._http.call_count, 1)

    def test_23_llm_url_query_false_identity(self):
        url = f"https://www.reddit.com/user/bob/?next=/r/pruebas/comments/{PID}/"
        self.helper._http = mock.Mock(return_value={"grounding": {"generic": [{"url": url, "snippets": ["otro contenido"]}]}})
        with mock.patch.object(rh, "clave", return_value="fake"):
            self.assertEqual(self.helper._leer_brave_llm(PID, PID, self.out, []), [])

    def test_24_controls_valid_gzip_and_fixed_timezone(self):
        with mock.patch.object(rh.urllib.request.OpenerDirector, "open", return_value=Response(gzip.compress(b'{"ok":true}'))):
            self.assertEqual(self.helper._http("demo", "https://example.invalid"), {"ok": True})
        self.assertTrue(rh.iso_local(0).endswith("-06:00"))
        self.assertTrue(rh.iso_local(1790789831).endswith("-06:00"))

    def test_25_timezone_without_database_uses_system_offset(self):
        with mock.patch.object(rh, "ZONA_FORZADA", None), \
                mock.patch.object(rh.Path, "is_symlink", return_value=True), \
                mock.patch.object(rh.Path, "resolve", return_value=Path("/usr/share/zoneinfo/Europe/Madrid")), \
                mock.patch.object(rh, "ZoneInfo", side_effect=rh.ZoneInfoNotFoundError("sin base")):
            self.assertIs(rh._zona(), rh._ZONA_SISTEMA)
            self.assertEqual(rh.iso_local(0), datetime.fromtimestamp(0).astimezone().isoformat())
            self.assertIsNotNone(datetime.now(rh._zona()).utcoffset())  # «ahora» sigue siendo una hora con desfase

    @unittest.skipUnless(hasattr(time, "tzset"), "time.tzset solo existe en sistemas POSIX")
    def test_25b_zona_del_sistema_aplica_el_horario_de_cada_instante(self):
        # Regla POSIX (no necesita base de zonas): hora de Europa central, verano del último domingo de marzo al de octubre.
        anterior = os.environ.get("TZ")
        os.environ["TZ"] = "CET-1CEST,M3.5.0,M10.5.0/3"
        time.tzset()
        try:
            with mock.patch.object(rh, "ZONA_FORZADA", rh._ZONA_SISTEMA):
                self.assertEqual(rh.iso_local(1767268800), "2026-01-01T13:00:00+01:00")  # invierno
                self.assertEqual(rh.iso_local(1783252800), "2026-07-05T14:00:00+02:00")  # verano
        finally:
            if anterior is None:
                os.environ.pop("TZ", None)
            else:
                os.environ["TZ"] = anterior
            time.tzset()

    def test_26_health_reports_empty_redlib_as_ok(self):
        self.helper._http = mock.Mock(return_value="<html>página vacía</html>")
        for name in ("buscar_brave", "buscar_perplexity", "buscar_firecrawl"):
            self.patch(self.helper, name, return_value={"resultados": []})
        result = self.helper.salud()
        mirrors = [r for r in result if r["fuente"].startswith("redlib:")]
        self.assertEqual(len(mirrors), 3)
        self.assertTrue(all(not r["ok"] for r in mirrors))
        for source in ("you", "wayback"):
            calls = [c for c in self.helper._http.call_args_list if c.args[0] == source]
            self.assertEqual(len(calls), 1)
            self.assertEqual(calls[0].kwargs["reintentos"], 1)

    def test_27_merge_new_text_keeps_conflicting_old_author(self):
        c = rh.comentario_arctic(comment(edited=True), "pruebas", PID, 0)
        red = {"post": {}, "comentarios": [dict(id=c.id, autor="bob", votos=20, cuerpo="texto de bob", editado=True)]}
        p = {}
        rh.RedditHelper._fusionar_votos(p, [c], red, "mirror")
        self.assertEqual((c.autor, c.cuerpo, c.votos, c.votos_fuente), ("alice", "texto original", 10, "arctic-shift"))
        self.assertEqual(p["conflictos"], 1)

    def test_28_merge_ignores_new_redlib_comment_and_current_post(self):
        c = rh.comentario_arctic(comment(), "pruebas", PID, 0)
        red = {"post": {"cuerpo": "post actual"}, "comentarios": [dict(id="dddd4", autor="bob", votos=2, cuerpo="nuevo comentario", editado=False)]}
        cs, p = [c], {"id": PID, "cuerpo": "post archivado"}
        rh.RedditHelper._fusionar_votos(p, cs, red, "mirror")
        self.assertEqual([x.id for x in cs], [c.id, "dddd4"])
        self.assertEqual(p["cuerpo"], "post archivado")  # ninguna fuente lo marcó editado
        self.assertEqual(cs[1].cuerpo_fuente, "redlib:mirror")
        self.assertEqual(cs[1].votos_fuente, "redlib:mirror")
        red["post"]["editado"] = True
        rh.RedditHelper._fusionar_votos(p, cs, red, "mirror")
        self.assertEqual(p["cuerpo"], "post actual")
        for q in rh.citas({"hilos": [{"url": "u", "post": p, "comentarios": [rh.asdict(x) for x in cs]}]}, "."):
            self.assertIn("cuerpo_fuente", q)
            self.assertIn("votos_fuente", q)
            self.assertIn("editado", q)

    def test_29_deep_tree_recursion_error(self):
        root = node(comment())
        current = root
        for i in range(sys.getrecursionlimit() + 5):
            child = node(comment(cid="depth" + str(i)))
            current["data"]["replies"] = {"data": {"children": [child]}}
            current = child
        cs, _ = rh.aplanar_arbol([root], "pruebas", PID)
        self.assertGreater(len(cs), sys.getrecursionlimit())
        self.assertEqual(cs[-1].profundidad, len(cs) - 1)

    def test_30_ten_percent_missing_still_complete(self):
        self.fake_arctic(p=post(num_comments=10), nodes=[node(comment(cid="id" + str(i).zfill(4))) for i in range(9)])
        r = self.helper.leer(PID, votos_actuales=False)
        self.assertEqual(r["cobertura"]["comentarios_leidos"], 9)
        self.assertEqual(r["cobertura"]["estado"], "parcial")

    def test_31_documented_hilo_alias_is_missing(self):
        r = {"id": PID, "cobertura": {"estado": "parcial"}}
        with mock.patch.object(rh.RedditHelper, "leer", return_value=r), contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(rh.main(["hilo", PID, "--json"]), 0)

    def test_32_json_index_does_not_normalize_ids(self):
        lista = self.out / "indice.json"
        lista.write_text(json.dumps({"hilos": [{"id": PID}, {"id": "t3_" + PID}, {"id": PID.upper()}]}))
        self.assertEqual(rh._leer_lista(str(lista), None, False, 0), [PID])

    def test_33_more_cannot_reconstruct_depth(self):
        more = {"kind": "more", "data": {"children": ["dddd4", "eeee5"]}}
        parent = comment()
        parent["replies"] = {"data": {"children": [more]}}
        child = comment(cid="dddd4")
        child["parent_id"] = "t1_cccc3"
        orphan = comment(cid="eeee5")
        orphan["parent_id"] = "t1_missing"
        self.fake_arctic(nodes=[node(parent)], extra=[orphan, child])
        r = self.helper.leer(PID, votos_actuales=False)
        cs = {c["id"]: c for c in r["comentarios"]}
        self.assertEqual(cs["dddd4"]["profundidad"], 1)
        self.assertIsNone(cs["eeee5"]["profundidad"])
        self.assertEqual(r["cobertura"]["huerfanos"], 1)

    def test_34_secret_all_sinks_and_messages(self):
        secret = 'key"\nñ\\tail'
        rh._CLAVES_CARGADAS.extend([secret, "abcd"])
        self.fake_arctic(p=post(selftext=secret, title=secret), nodes=[node(comment(body=secret))])
        ix = self.helper.descubrir(secret, fuentes=[], mas_urls=["https://redd.it/" + PID], carpeta=self.out)
        r = self.helper.leer(PID, votos_actuales=False)
        self.helper.lote([PID], self.out, votos_actuales=False)
        files = list(self.out.rglob("*.json")) + list(self.out.rglob("*.md"))
        self.assertTrue(any(f.name == "indice.json" for f in files))
        self.assertTrue(any(f.name == "corpus.json" for f in files))
        self.assertTrue(any(f.name == "corpus.md" for f in files))
        self.assertTrue(any(f.name == PID + ".json" for f in files))
        for f in files:
            contenido = f.read_text()
            for variante in (secret, json.dumps(secret, ensure_ascii=True)[1:-1], json.dumps(secret, ensure_ascii=False)[1:-1]):
                self.assertNotIn(variante, contenido, str(f))
            if f.suffix == ".json":
                json.loads(contenido)  # la redacción mantiene JSON válido
        with contextlib.redirect_stdout(io.StringIO()) as out, contextlib.redirect_stderr(io.StringIO()) as err:
            rh._imprimir(secret)
            with mock.patch.object(rh.RedditHelper, "leer", return_value=r):
                self.assertEqual(rh.main(["leer", PID, "--json"]), 0)
            with mock.patch.object(rh.RedditHelper, "buscar_brave", side_effect=ValueError(secret)):
                self.assertEqual(rh.main(["brave", "x"]), 2)
            rh._imprimir("abcd", file=sys.stderr)
        self.assertNotIn(secret, out.getvalue() + err.getvalue())
        self.assertNotIn("abcd", err.getvalue())
        with self.assertLogs(rh.logger, level="WARNING") as logs:
            rh.CircuitBreaker(nombre=secret, failure_threshold=1).record_failure()
        self.assertNotIn(secret, "".join(logs.output))

    def test_35_retry_after_long_pause_shared_and_expiry(self):
        url = "https://example.invalid/"
        error = urllib.error.HTTPError(url, 429, "limited", {"Retry-After": "180"}, io.BytesIO(b"limit"))
        original = rh.with_retry
        waits = []
        def retry(*args, **kwargs):
            return original(*args, **kwargs, sleep=waits.append)
        with mock.patch.object(rh, "with_retry", side_effect=retry), mock.patch.object(rh.time, "time", return_value=1000), mock.patch.object(rh.urllib.request.OpenerDirector, "open", side_effect=error) as mocked:
            for _ in range(2):
                with self.assertRaisesRegex(RuntimeError, "fuente en pausa hasta"):
                    self.helper._http("demo", url)
            self.assertEqual(mocked.call_count, 1)
            self.assertEqual(self.helper._breaker("demo").state, "open")
            # Un éxito de una llamada anterior tampoco borra la pausa.
            self.helper._breaker("demo").record_success()
            self.assertFalse(self.helper._breaker("demo").can_execute())
        self.assertEqual(waits, [])
        with mock.patch.object(rh.time, "time", return_value=1180), mock.patch.object(rh.urllib.request.OpenerDirector, "open", return_value=Response(b'{}')):
            self.assertEqual(self.helper._http("demo", url), {})
            self.assertEqual(self.helper._breaker("demo").state, "closed")

    def test_36_redlib_identity_from_comment_permalink(self):
        html = self.red().split('>', 1)[1]
        # Sin og:url se exige canonical, además del permalink propio del comentario.
        self.helper._http = mock.Mock(return_value=html)
        self.assertIsNone(self.helper._leer_redlib(PID, "pruebas", self.out)[0])
        html = f'<link rel="canonical" href="/comments/{PID}/">' + html
        html = html.replace('<a class="comment_author">', f'<a class="created" href="/comments/{PID}/_/cccc3/">fecha</a><a class="comment_author">')
        self.helper._http = mock.Mock(return_value=html)
        red, host, err = self.helper._leer_redlib(PID, "pruebas", self.out)
        self.assertIsNotNone(red)
        p, cs = self.helper._de_redlib(PID, red, host)
        self.assertFalse(p["completitud_verificada"])
        self.assertEqual(cs[0].cuerpo_fuente, "redlib:" + host)
        self.helper._http.return_value = html.replace(PID, OTHER)
        self.assertIsNone(self.helper._leer_redlib(PID, "pruebas", self.out)[0])
        # Un og:url contrario contradice el canonical y el permalink correcto.
        self.helper._http.return_value = f'<meta property="og:url" content="/comments/{OTHER}/">' + html
        self.assertIsNone(self.helper._leer_redlib(PID, "pruebas", self.out)[0])

    def test_37_coverage_maximum_and_zero(self):
        for declared, count, red_count, estado in ((0, 0, 0, "completa"), (1, 1, 2, "parcial"), (2, 2, 1, "completa")):
            self.fake_arctic(p=post(num_comments=declared), nodes=[node(comment(cid="id" + str(i).zfill(4))) for i in range(count)])
            h = self.helper._http.side_effect
            def http(source, url, *args, **kwargs):
                if source.startswith("redlib"):
                    return f'<meta property="og:url" content="/comments/{PID}/"><div class="post"><h1 class="post_title">P</h1><div class="post_body">Post</div></div><p id="comment_count">{red_count} comments</p>'
                return h(source, url)
            self.helper._http.side_effect = http
            r = self.helper.leer(PID)
            self.assertEqual(r["cobertura"]["estado"], estado)
            self.assertEqual(r["cobertura"]["declarados"], max(declared, red_count))

    def test_38_api_shapes_and_fallback_contracts(self):
        cases = [("buscar_brave", [], ("tema", "w")), ("buscar_brave", {"web": []}, ("tema", "w")),
                 ("buscar_brave", {"web": {"results": [1]}}, ("tema", "w")),
                 ("buscar_brave", {"web": {"results": [{"qa": {"answer": []}}]}}, ("tema", "w")),
                 ("buscar_perplexity", {"results": {}}, ("tema", "w")),
                 ("buscar_firecrawl", {"data": []}, ("tema", "w")),
                 ("buscar_arctic", {"data": {}}, ("tema", "w", 1, "pruebas")),
                 ("_leer_arctic", {"data": [1]}, (PID, self.out))]
        with mock.patch.object(rh, "clave", return_value="fake"):
            for method, response, args in cases:
                self.helper._http = mock.Mock(return_value=response)
                with self.subTest(method=method, response=response), self.assertRaises(ValueError):
                    getattr(self.helper, method)(*args)
            self.helper._http = mock.Mock(return_value={"grounding": []})
            fallos = []
            self.assertEqual(self.helper._leer_brave_llm(PID, PID, self.out, fallos), [])
            self.assertTrue(fallos)
        self.helper._http = mock.Mock(return_value={"data": []})
        fallos = []
        self.assertIsNone(self.helper._leer_wayback(PID, PID, self.out, fallos))
        self.assertTrue(fallos)

    def test_39_cli_zero_limits_and_validation(self):
        self.helper._http = mock.Mock(side_effect=AssertionError("no llamada para cero"))
        for name in ("brave", "perplexity", "firecrawl", "you", "arctic"):
            method = getattr(self.helper, "buscar_" + name)
            self.assertEqual(method("x", "w", n=0, sub="pruebas")["resultados"], [])
            with self.assertRaises(ValueError):
                method("x", "w", n=-1, sub="pruebas")
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(rh.main(["brave", "x", "0"]), 0)
            self.assertEqual(rh.main(["exa", "x", "0"]), 0)
            for args in (["brave", "x", "-1"], ["descubrir", "x", "--filas", "-1"], ["leer", PID, "--max", "-1"], ["lote", "lista", "--pausa", "-1"], ["lote", "lista", "--min-relevancia", "1.1"], ["lote", "lista", "--min-relevancia", "nan"]):
                self.assertEqual(rh.main(args), 2)
        self.fake_arctic(nodes=[node(comment())])
        r = self.helper.leer(PID, votos_actuales=False)
        self.assertNotIn("texto original", rh.hilo_md(r, maximo=0))
        self.assertEqual(rh.citas({"hilos": [r]}, ".", maximo=0), [])

    def test_40_epoch_zero_and_inclusive_window(self):
        for timestamp, en_ventana in ((0, True), (-1, False), (7 * 86400, True), (7 * 86400 + 1, False)):
            self.helper._http = mock.Mock(return_value={"data": [post(created_utc=str(timestamp))]})
            with mock.patch.object(rh, "ahora", return_value=7 * 86400):
                ix = self.helper.descubrir("x", fuentes=[], ventanas=["w"], mas_urls=["https://redd.it/" + PID])
            self.assertIs(ix["hilos"][0]["en_ventana"], en_ventana)
            self.assertTrue(ix["hilos"][0]["fecha_verificada"])

    def test_41_pre_whitespace_and_nested_quote_code(self):
        code = '\n  x = "a  b"\n\n\n\tpass\n  '
        body = '<p>antes</p><pre>' + code + '</pre><p>después</p><blockquote><pre>  otro  código</pre></blockquote>'
        r = rh.parse_redlib(html_comment("cccc3", body))["comentarios"][0]["cuerpo"]
        self.assertIn(code, r)
        self.assertIn('  otro  código', r)
        self.assertIn('antes', r)
        self.assertIn('después', r)

    def test_42_real_fixtures_union(self):
        from test_reddit_helper import fx, helper, TestLeer, PID as real_pid
        h = helper(str(self.out), TestLeer().rutas_ok())
        r = h.leer(real_pid)
        self.assertEqual(r["cobertura"]["estado"], "completa")
        self.assertEqual(len(r["comentarios"]), 127)
        ids_arctic = {c.id for c in rh.aplanar_arbol(fx("arctic_tree_1wubcvf.json")["data"], "redditdev", real_pid)[0]}
        self.assertEqual(len(ids_arctic), 126)
        self.assertEqual({c["id"] for c in r["comentarios"]} - ids_arctic, {"pd2v83h"})
        c = next(c for c in r["comentarios"] if c["id"] == "pd1pln5")
        self.assertEqual((c["votos"], c["votos_fuente"]), (33, "redlib:safereddit.com"))
        self.assertTrue(c["cuerpo"].startswith("Disappointed to see this finally happen"))
        self.assertEqual(r["post"]["votos"], 11)

    def test_43_secret_nested_json_and_long_truncated_output(self):
        secret = 'k"\nñ\\tail'
        rh._CLAVES_CARGADAS.append(secret)
        texto = secret
        for capas in range(1, 5):
            texto = json.dumps({"content": texto})
            limpio = rh.redactar(texto)
            decodificado = limpio
            for paso in range(capas):
                decodificado = json.loads(decodificado)["content"]
            self.assertEqual(decodificado, "[CLAVE]")
        largo = "secret-" + "X" * 700
        rh._CLAVES_CARGADAS.append(largo)
        with mock.patch.object(rh.RedditHelper, "buscar_brave", return_value={"resultados": [{"url": "u", "edad": None, "texto": largo}]}), contextlib.redirect_stdout(io.StringIO()) as out:
            rh.main(["brave", "tema"])
        self.assertIn("[CLAVE]", out.getvalue())
        self.assertNotIn("X" * 20, out.getvalue())

    def test_44_shared_pause_stops_retry_already_in_progress(self):
        cb = rh.CircuitBreaker()
        fn = mock.Mock(side_effect=[rh.HttpError(503, "down", "u"), "unexpected"])
        def sleep(_):
            cb.pause(rh.time.time() + 180)
        with self.assertRaisesRegex(RuntimeError, "fuente en pausa hasta"):
            rh.with_retry(fn, circuit_breaker=cb, sleep=sleep)
        self.assertEqual(fn.call_count, 1)

    def test_45_render_and_citations_keep_code_indentation(self):
        code = '    print("a  b")'
        c = rh.comentario_arctic(comment(body=code), "pruebas", PID, 0)
        h = {"url": "u", "post": {}, "comentarios": [rh.asdict(c)]}
        q = rh.citas({"hilos": [h]}, "print")[0]
        self.assertEqual(q["texto"], code)
        self.assertIn("> " + code, rh.cita_md(code, "u", "s", "alice", None, None))
        body = '<blockquote>uno<blockquote>dos</blockquote></blockquote>'
        r = rh.parse_redlib(html_comment("cccc3", body))["comentarios"][0]["cuerpo"]
        self.assertIn("> uno", r)
        self.assertIn(">> dos", r)


try:
    rh.ZoneInfo("Europe/Madrid")
    HAY_ZONAS = True
except rh.ZoneInfoNotFoundError:
    HAY_ZONAS = False


class Portabilidad(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory(prefix="reddit search ")
        self.addCleanup(tmp.cleanup)
        self.out = Path(tmp.name)
        for patch in (
            mock.patch.dict(os.environ, {}, clear=True),
            mock.patch.object(Path, "home", return_value=self.out),
            mock.patch.object(rh, "ZONA_FORZADA", timezone(timedelta(hours=-6))),
            mock.patch.object(rh, "_CLAVES_CARGADAS", []),
            mock.patch.object(socket.socket, "connect", side_effect=AssertionError("RED PROHIBIDA")),
            mock.patch.object(rh.urllib.request.OpenerDirector, "open", side_effect=AssertionError("RED PROHIBIDA")),
        ):
            patch.start()
            self.addCleanup(patch.stop)
        self.helper = rh.RedditHelper(self.out)
        self.helper._http = mock.Mock(side_effect=AssertionError("TRANSPORTE NO SIMULADO"))

    def test_sin_carpeta_de_usuario_no_rompe_y_queda_en_modo_base(self):
        # Windows sin USERPROFILE (servicios, entornos vacíos): Path.home() lanza RuntimeError.
        with mock.patch.object(Path, "home", side_effect=RuntimeError("Could not determine home directory.")):
            self.assertIsNone(rh.fichero_claves())
            self.assertEqual(rh.clave("BRAVE_SEARCH_API_KEY", obligatoria=False), "")
            self.assertEqual(rh.modo_busqueda()["modo"], "base")
            rh.RedditHelper(self.out)  # no lanza
            os.environ["BRAVE_SEARCH_API_KEY"] = "test-key-1234567890"
            self.assertEqual(rh.modo_busqueda()["modo"], "parcial")  # el entorno sigue contando

    def test_leer_sin_clave_no_intenta_brave_llm_ni_lo_anota(self):
        self.helper._leer_arctic = mock.Mock(side_effect=RuntimeError("sin archivo"))
        self.helper._leer_redlib = mock.Mock(return_value=(None, "", "sin instancias"))
        self.helper._leer_wayback = mock.Mock(return_value=None)
        self.helper._leer_brave_llm = mock.Mock(return_value=[])
        r = self.helper.leer("abc123")
        self.helper._leer_brave_llm.assert_not_called()
        self.assertFalse(any("brave" in x for x in r["cobertura"]["intentos_fallidos"]), r["cobertura"]["intentos_fallidos"])
        os.environ["BRAVE_SEARCH_API_KEY"] = "test-key-1234567890"
        self.helper.leer("abc123")
        self.helper._leer_brave_llm.assert_called_once()

    def configurar(self, n):
        for nombre in list(rh.PROVEEDORES_EXPERTOS.values())[:n]:
            os.environ[nombre] = "test-key-1234567890"

    def descubrimiento(self):
        respuesta = {"resultados": [], "peticion": {}, "crudo": {}}
        metodos = {}
        for fuente in ("brave", "perplexity", "firecrawl", "you", "arctic"):
            metodos[fuente] = mock.Mock(return_value=respuesta)
            setattr(self.helper, "buscar_" + fuente, metodos[fuente])
        self.helper._hidratar = mock.Mock()
        return metodos

    def cli(self, args):
        with mock.patch.object(rh, "RedditHelper", return_value=self.helper), \
                contextlib.redirect_stdout(io.StringIO()) as out, \
                contextlib.redirect_stderr(io.StringIO()) as err:
            code = rh.main(args)
        return code, out.getvalue(), err.getvalue()

    def test_claves_home_temporal(self):
        with mock.patch.dict(os.environ, {"HOME": str(self.out), "USERPROFILE": str(self.out)}):
            fichero = self.out / ".reddit-search" / "claves.env"
            self.assertEqual(rh.fichero_claves(), fichero)
            fichero.parent.mkdir()
            fichero.write_text("BRAVE_SEARCH_API_KEY=test-key-home-123\n", encoding="utf-8")
            self.assertEqual(rh.clave("BRAVE_SEARCH_API_KEY"), "test-key-home-123")
            self.assertEqual(rh.redactar("test-key-home-123"), "[CLAVE]")

    def test_claves_export_comillas_espacios_y_prioridad(self):
        fichero = self.out / "claves.env"
        fichero.write_text(' export BRAVE_SEARCH_API_KEY = "test-key-double-123" \n'
                           "PERPLEXITY_API_KEY = 'test-key-single-123'\n"
                           " FIRECRAWL_API_KEY = test-key-plain-123 \n", encoding="utf-8")
        with mock.patch.dict(os.environ, {"REDDIT_SEARCH_ENV": str(fichero)}):
            self.assertEqual(rh.fichero_claves(), fichero)
            for nombre, valor in zip(rh.PROVEEDORES_EXPERTOS.values(),
                                     ("test-key-double-123", "test-key-single-123", "test-key-plain-123")):
                self.assertEqual(rh.clave(nombre), valor)
                self.assertIn(valor, rh._CLAVES_CARGADAS)
            with mock.patch.dict(os.environ, {"BRAVE_SEARCH_API_KEY": "test-key-environ-123"}):
                self.assertEqual(rh.clave("BRAVE_SEARCH_API_KEY"), "test-key-environ-123")

    def test_clave_corta_sigue_rechazada(self):
        with mock.patch.dict(os.environ, {"BRAVE_SEARCH_API_KEY": "corta"}):
            with self.assertRaisesRegex(ValueError, "clave demasiado corta"):
                rh.clave("BRAVE_SEARCH_API_KEY", obligatoria=False)
        fichero = self.out / "claves.env"
        fichero.write_text("export BRAVE_SEARCH_API_KEY = 'corta'\n", encoding="utf-8")
        with mock.patch.dict(os.environ, {"REDDIT_SEARCH_ENV": str(fichero)}), \
                self.assertRaisesRegex(ValueError, "clave demasiado corta"):
            rh.clave("BRAVE_SEARCH_API_KEY")

    def test_clave_ausente_accionable_sin_rutas(self):
        with self.assertRaises(RuntimeError) as cm:
            rh.clave("BRAVE_SEARCH_API_KEY")
        self.assertEqual(str(cm.exception), 'falta BRAVE_SEARCH_API_KEY (modo experto): pide a tu agente "conecta Brave Search para reddit-search"')
        self.assertNotIn(str(self.out), str(cm.exception))
        self.assertNotIn("claves.env", str(cm.exception))
        self.assertEqual(rh.clave("BRAVE_SEARCH_API_KEY", obligatoria=False), "")

    def test_modo_cero_claves(self):
        self.assertEqual(rh.modo_busqueda(), {"modo": "base", "configuradas": [],
                                           "faltan": list(rh.PROVEEDORES_EXPERTOS.values())})

    def test_modo_una_clave(self):
        self.configurar(1)
        self.assertEqual(rh.modo_busqueda(), {"modo": "parcial", "configuradas": ["BRAVE_SEARCH_API_KEY"],
                                           "faltan": ["PERPLEXITY_API_KEY", "FIRECRAWL_API_KEY"]})

    def test_modo_tres_claves(self):
        self.configurar(3)
        self.assertEqual(rh.modo_busqueda(), {"modo": "experto", "configuradas": list(rh.PROVEEDORES_EXPERTOS.values()),
                                           "faltan": []})

    def test_descubrir_base_sin_llamadas_expertas(self):
        metodos = self.descubrimiento()
        ix = self.helper.descubrir("tema", ventanas=["w"], subs=["pruebas"])
        for nombre in rh.PROVEEDORES_EXPERTOS:
            metodos[nombre].assert_not_called()
        metodos["you"].assert_called()
        metodos["arctic"].assert_called_once()
        self.assertTrue(all(f["ok"] for f in ix["fuentes"].values()))
        self.assertEqual(ix["modo"], "base")
        self.assertEqual(ix["fuentes_no_configuradas"], list(rh.PROVEEDORES_EXPERTOS))
        self.assertEqual(ix["aviso_modo_experto"], rh.AVISO_MODO_EXPERTO)
        guardado = json.loads((Path(ix["carpeta"]) / "indice.json").read_text(encoding="utf-8"))
        self.assertEqual(guardado, ix)
        self.assertNotIn("FALLO", rh.indice_md(ix))

    def test_descubrir_parcial_solo_proveedor_configurado(self):
        self.configurar(1)
        metodos = self.descubrimiento()
        ix = self.helper.descubrir("tema", ventanas=["w"], subs=["pruebas"])
        metodos["brave"].assert_called()
        metodos["perplexity"].assert_not_called()
        metodos["firecrawl"].assert_not_called()
        self.assertEqual(ix["modo"], "parcial")
        self.assertEqual(ix["aviso_modo_experto"], rh.AVISO_MODO_EXPERTO)

    def test_descubrir_experto_sin_aviso(self):
        self.configurar(3)
        metodos = self.descubrimiento()
        ix = self.helper.descubrir("tema", ventanas=["w"], subs=["pruebas"])
        for metodo in metodos.values():
            metodo.assert_called()
        self.assertEqual(ix["modo"], "experto")
        self.assertEqual(ix["fuentes_no_configuradas"], [])
        self.assertNotIn("aviso_modo_experto", ix)
        self.assertNotIn(rh.AVISO_MODO_EXPERTO, rh.indice_md(ix))

    def test_fuente_explicita_sin_clave_fallo_visible_cli(self):
        self.helper._hidratar = mock.Mock()
        code, out, err = self.cli(["descubrir", "tema", "--ventana", "w", "--fuentes", "brave"])
        self.assertEqual(code, 3)
        self.assertIn("brave:w: FALLO", out)
        self.assertIn("falta BRAVE_SEARCH_API_KEY", out)
        self.helper._http.assert_not_called()
        self.assertEqual(err, "")

    def test_proveedor_configurado_error_http_visible(self):
        self.configurar(1)
        self.descubrimiento()
        # Real provider method with simulated transport exercises authentication and HTTP propagation.
        self.helper.buscar_brave = rh.RedditHelper.buscar_brave.__get__(self.helper)
        self.helper._http.side_effect = rh.HttpError(503, "no disponible", "https://example.invalid")
        ix = self.helper.descubrir("tema", ventanas=["w"])
        self.assertFalse(ix["fuentes"]["brave:w"]["ok"])
        self.assertIn("HTTP 503", ix["fuentes"]["brave:w"]["error"])
        self.assertIn("brave:w: FALLO", rh.indice_md(ix))
        self.helper._http.assert_called_once()

    def test_aviso_cli_una_vez_markdown_y_json(self):
        self.descubrimiento()
        for formato in ([], ["--json"]):
            code, out, err = self.cli(["descubrir", "tema", "--ventana", "w"] + formato)
            self.assertEqual(code, 3)
            self.assertEqual(out.count(rh.AVISO_MODO_EXPERTO), 1)
            self.assertEqual(err, "")
            if formato:
                self.assertEqual(json.loads(out)["modo"], "base")

    def test_arctic_sin_sub_nota_en_indice(self):
        metodos = self.descubrimiento()
        ix = self.helper.descubrir("tema", ventanas=["w"])
        self.assertIn("Arctic Shift no busca por texto sin subreddit: pasa 2-5 --sub", ix["avisos"])
        metodos["arctic"].assert_not_called()
        ix = self.helper.descubrir("tema", fuentes=["you"], ventanas=["w"])
        self.assertFalse(any("2-5 --sub" in aviso for aviso in ix["avisos"]))

    def test_salud_no_configurado_frente_a_mal(self):
        self.configurar(1)
        for nombre in rh.PROVEEDORES_EXPERTOS:
            setattr(self.helper, "buscar_" + nombre, mock.Mock(side_effect=rh.HttpError(503, "caído", "u")))
        self.helper.buscar_you = mock.Mock(return_value={"resultados": []})
        self.helper._http.side_effect = lambda fuente, *args, **kwargs: {"data": [{"created_utc": rh.ahora()}]} if fuente == "arctic" else {}
        code, out, err = self.cli(["salud", "--en-vivo"])
        self.assertEqual(code, 0)
        self.assertTrue(out.startswith("Modo parcial · falta para experto: PERPLEXITY_API_KEY, FIRECRAWL_API_KEY\n"))
        self.assertIn("Python " + sys.version.split()[0], out)
        self.assertRegex(out, r"MAL brave\s")
        self.assertRegex(out, r"-- +perplexity-search\s.*NO CONFIGURADO \(modo experto\)")
        self.assertRegex(out, r"-- +firecrawl-search\s.*NO CONFIGURADO \(modo experto\)")
        self.assertNotRegex(out, r"MAL (perplexity|firecrawl)")
        self.helper.buscar_brave.assert_called_once()
        self.helper.buscar_perplexity.assert_not_called()
        self.helper.buscar_firecrawl.assert_not_called()
        self.assertEqual(err, "")

    def test_salud_exit_cinco_solo_arctic(self):
        code, out, _ = self.cli(["salud"])
        self.assertEqual(code, 5)
        self.assertTrue(out.startswith("Modo base"))
        self.assertRegex(out, r"MAL arctic-shift\s")

    def test_ua_version_y_parser_agnosticos(self):
        self.assertEqual(rh.VERSION, "1.3.0")
        self.assertEqual(rh.UA, "reddit-search/1.3.0 (investigacion de foros; sin afiliacion con Reddit)")
        self.assertEqual(rh.construir_parser().description, "reddit-search")
        self.assertIsNone(rh.construir_parser().parse_args(["descubrir", "tema"]).fuentes)

    @unittest.skipUnless(HAY_ZONAS, "Europe/Madrid requiere la base de zonas IANA del sistema; el resto no necesita tzdata")
    def test_zona_iana_configurada_verano_e_invierno(self):
        with mock.patch.object(rh, "ZONA_FORZADA", None), \
                mock.patch.dict(os.environ, {"REDDIT_SEARCH_TZ": "Europe/Madrid"}):
            verano = datetime(2021, 7, 1, tzinfo=timezone.utc).timestamp()
            invierno = datetime(2021, 1, 1, tzinfo=timezone.utc).timestamp()
            self.assertTrue(rh.iso_local(verano).endswith("+02:00"))
            self.assertTrue(rh.iso_local(invierno).endswith("+01:00"))

    def test_zona_iana_invalida_error_cli_al_arrancar(self):
        for nombre in ("zona/invalida", "", "../no-valida"):
            with mock.patch.object(rh, "ZONA_FORZADA", None), \
                    mock.patch.dict(os.environ, {"REDDIT_SEARCH_TZ": nombre}):
                with self.assertRaisesRegex(ValueError, "REDDIT_SEARCH_TZ.*zona IANA"):
                    rh._zona()
                code, out, err = self.cli(["salud"])
                self.assertEqual(code, 2)
                self.assertEqual(out, "")
                self.assertIn("REDDIT_SEARCH_TZ", err)
        self.helper._http.assert_not_called()

    def test_zona_iana_explicita_sin_base_error_claro(self):
        with mock.patch.object(rh, "ZONA_FORZADA", None), \
                mock.patch.dict(os.environ, {"REDDIT_SEARCH_TZ": "Europe/Madrid"}), \
                mock.patch.object(rh, "ZoneInfo", side_effect=rh.ZoneInfoNotFoundError("sin base")):
            with self.assertRaisesRegex(ValueError, "base de zonas no disponible"):
                rh._zona()
            code, _, err = self.cli(["salud"])
            self.assertEqual(code, 2)
            self.assertIn("elimina REDDIT_SEARCH_TZ", err)
        self.helper._http.assert_not_called()

    def test_zona_local_sin_enlace_fallback_y_prioridad_inyeccion(self):
        with mock.patch.object(rh, "ZONA_FORZADA", None), \
                mock.patch.object(rh.Path, "is_symlink", return_value=False), \
                mock.patch.object(rh, "ZoneInfo") as zona:
            # Reglas del instante histórico (no el desfase de hoy): en Madrid 1970 era +01:00 aunque hoy sea +02:00.
            self.assertEqual(rh.iso_local(0), datetime.fromtimestamp(0).astimezone().isoformat())
            zona.assert_not_called()
        with mock.patch.dict(os.environ, {"REDDIT_SEARCH_TZ": "zona/invalida"}):
            self.assertTrue(rh.iso_local(0).endswith("-06:00"))

    def test_zona_local_enlace_iana_fiable(self):
        inyectada = timezone(timedelta(hours=2))
        with mock.patch.object(rh, "ZONA_FORZADA", None), \
                mock.patch.object(rh.Path, "is_symlink", return_value=True), \
                mock.patch.object(rh.Path, "resolve", return_value=Path("/usr/share/zoneinfo/Europe/Madrid")), \
                mock.patch.object(rh, "ZoneInfo", return_value=inyectada) as zona:
            self.assertIs(rh._zona(), inyectada)
            zona.assert_called_once_with("Europe/Madrid")

    def test_guarda_version_python_antes_de_zoneinfo(self):
        import builtins
        import runpy
        importar = builtins.__import__
        def vigilado(nombre, *args, **kwargs):
            if nombre == "zoneinfo":
                raise AssertionError("zoneinfo importado antes de la guarda")
            return importar(nombre, *args, **kwargs)
        with mock.patch.object(sys, "version_info", (3, 8, 20)), \
                mock.patch.object(builtins, "__import__", side_effect=vigilado), \
                contextlib.redirect_stderr(io.StringIO()) as err, \
                self.assertRaises(SystemExit) as cm:
            runpy.run_path(str(ROOT / "scripts" / "reddit_helper.py"), run_name="__guard_test__")
        self.assertEqual(cm.exception.code, 2)
        for texto in ("Python >= 3.9", "winget install Python.Python.3.12", "brew install python@3.12", "python.org", "Linux"):
            self.assertIn(texto, err.getvalue())

    def test_salida_variable_agnostica(self):
        with mock.patch.dict(os.environ, {"REDDIT_SEARCH_SALIDA": str(self.out / "salida")}):
            self.assertEqual(rh.RedditHelper().salida, self.out / "salida")


class Regresiones130(unittest.TestCase):
    """1.3.0: regresiones de una revisión externa (cinco reproducciones sin red) y de la unión con Redlib."""

    setUp = Endurecimiento.setUp
    patch = Endurecimiento.patch
    fake_arctic = Endurecimiento.fake_arctic

    MARCA = "SYNTHETIC_REMOVED_MARKER"

    def sin_reintento_lento(self):
        original = rh.with_retry
        self.patch(rh, "with_retry", lambda fn, **kw: original(fn, sleep=lambda s: None, **kw))

    def con_redlib(self, cuerpo_post="Post", comentarios="", autor="", creado=None):
        firma = f'<a class="post_author">u/{autor}</a>' if autor else ""
        if creado is not None:
            firma += f'<span class="created" title="{datetime.fromtimestamp(creado, timezone.utc).strftime("%b %d %Y, %H:%M:%S UTC")}">x</span>'

        html = (f'<meta property="og:url" content="/comments/{PID}/"><div class="post"><h1 class="post_title">Título</h1>'
                f'{firma}<div class="post_body">{cuerpo_post}</div></div>' + comentarios)
        arctic = self.helper._http.side_effect
        def http(source, url, *args, **kwargs):
            return html if source.startswith("redlib") else arctic(source, url)
        self.helper._http.side_effect = http

    def salidas(self, r):
        return (self.out / "hilos" / (PID + ".json")).read_text(encoding="utf-8") + rh.hilo_md(r) + \
            json.dumps(rh.citas({"hilos": [r]}, ".", incluir_no_literales=True))

    # 1. Post retirado: su cuerpo no llega al JSON, al Markdown ni al crudo (reproducción 1).
    def test_post_retirado_no_se_persiste_ni_se_imprime(self):
        self.helper = rh.RedditHelper(self.out)  # por defecto: sin crudo
        self.fake_arctic(p=post(selftext=self.MARCA, removed_by_category="moderator"))
        r = self.helper.leer(PID, votos_actuales=False)
        self.assertTrue(r["post"]["retirado"])
        self.assertNotIn(self.MARCA, self.salidas(r))
        self.assertIn("post retirado", rh.hilo_md(r))
        self.assertFalse((self.out / "hilos" / "crudo").exists())
        self.assertEqual(rh.citas({"hilos": [r]}, "."), [])

    # La unión con Redlib no repone el texto de un post o comentario retirado y editado.
    def test_union_redlib_no_repone_texto_retirado(self):
        self.fake_arctic(p=post(selftext=self.MARCA, removed_by_category="moderator", edited=True),
                         nodes=[node(comment(body="[removed]", edited=True))])
        self.con_redlib("TEXTO_VIVO_POST", html_comment("cccc3", "TEXTO_VIVO_COMENTARIO"))
        r = self.helper.leer(PID)
        salidas = self.salidas(r)
        for texto in (self.MARCA, "TEXTO_VIVO_POST", "TEXTO_VIVO_COMENTARIO"):
            self.assertNotIn(texto, salidas)
        self.assertTrue(r["post"]["retirado"])
        self.assertIsNone(r["post"]["cuerpo_capturado"])
        self.assertTrue(r["comentarios"][0]["retirado"])

    def test_retirado_en_archivo_y_visible_hoy_se_entrega_el_texto_actual(self):
        # automod_filtered al capturarse y aprobado después: Redlib (mismo autor) lo muestra hoy.
        self.fake_arctic(p=post(selftext=self.MARCA, removed_by_category="automod_filtered"))
        self.con_redlib("TEXTO_DE_HOY", autor="autor-" + PID, creado=1790789831)
        r = self.helper.leer(PID)
        self.assertFalse(r["post"]["retirado"])
        self.assertTrue(r["post"]["retirado_en_archivo"])
        self.assertEqual((r["post"]["cuerpo"], r["post"]["cuerpo_capturado"]), ("TEXTO_DE_HOY", None))
        self.assertNotIn(self.MARCA, self.salidas(r))
        self.assertEqual(rh.citas({"hilos": [r]}, "TEXTO_DE_HOY")[0]["texto"], "TEXTO_DE_HOY")
        # Hoy retirado también en Redlib, otro autor, fecha ausente o fecha distinta: sigue oculto.
        for cuerpo, autor, creado in (("[removed]", "autor-" + PID, 1790789831), ("TEXTO_DE_OTRO", "otro", 1790789831),
                                      ("TEXTO_DE_OTRO", "autor-" + PID, None), ("TEXTO_DE_OTRO", "autor-" + PID, 1790789832)):
            self.fake_arctic(p=post(selftext=self.MARCA, removed_by_category="automod_filtered"))
            self.con_redlib(cuerpo, autor=autor, creado=creado)
            r = self.helper.leer(PID)
            self.assertTrue(r["post"]["retirado"])
            self.assertNotIn(self.MARCA, self.salidas(r))
            self.assertNotIn("TEXTO_DE_OTRO", self.salidas(r))

    def test_variantes_de_retirada_de_reddit(self):
        for t in ("[deleted]", "[removed]", "[ Removed by Reddit ]", "[deleted by user]", "[removed by moderator]",
                  " [ Removed by Reddit on account of violating the [content policy](/help). ] "):
            self.assertTrue(rh.es_retirado(t), t)
        for t in ("texto [removed]", "[removido]", "", None, 3, "[deletedx]"):
            self.assertFalse(rh.es_retirado(t), t)
        self.fake_arctic(nodes=[node(comment(body="[ Removed by Reddit ]"))])
        r = self.helper.leer(PID, votos_actuales=False)
        self.assertTrue(r["comentarios"][0]["retirado"])
        self.assertEqual(r["cobertura"]["con_texto"], 0)
        self.assertNotIn("Removed by Reddit", rh.hilo_md(r))

    def test_crudo_apagado_por_defecto(self):
        self.assertFalse(rh.RedditHelper(self.out).guardar_crudo)
        self.assertTrue(rh.construir_parser().parse_args(["--guardar-crudo", "salud"]).guardar_crudo)

    # 2. Un fallo del árbol conserva el post ya descargado (reproducción 2).
    def test_post_se_conserva_si_falla_el_arbol(self):
        self.fake_arctic()
        arctic = self.helper._http.side_effect
        def http(source, url, *args, **kwargs):
            if "/comments/tree" in url:
                raise rh.HttpError(503, "árbol caído", url)
            return arctic(source, url)
        self.helper._http.side_effect = http
        self.patch(self.helper, "_leer_redlib", return_value=(None, "", "sin instancias"))
        self.patch(self.helper, "_leer_wayback", return_value=None)
        r = self.helper.leer(PID, votos_actuales=False)
        self.assertEqual(r["post"]["cuerpo"], "cuerpo " + PID)
        self.assertEqual(r["cobertura"]["estado"], "parcial")
        self.assertIn("árbol de comentarios de Arctic no disponible", r["cobertura"]["motivos_parcial"])

    # 3. Cobertura: página llena y pendientes reconciliados tras la fusión.
    def test_pagina_llena_es_truncado(self):
        with mock.patch.object(rh, "clave", return_value="fake-key-123"):
            for n, total in ((2, 2), (2, 1)):
                self.helper._http = mock.Mock(return_value={"results": [{"url": f"https://redd.it/{PID}", "snippet": "x"}] * total})
                self.assertEqual(self.helper.buscar_perplexity("tema", "w", n)["truncado"], total >= n)
                self.helper._http = mock.Mock(return_value={"data": {"web": [{"url": f"https://redd.it/{PID}"}] * total}})
                self.assertEqual(self.helper.buscar_firecrawl("tema", "w", n)["truncado"], total >= n)
                self.helper._http = mock.Mock(return_value={"data": [post(pid) for pid in ("aaaa1", "bbbb2")[:total]]})
                self.assertEqual(self.helper.buscar_arctic("post", "todo", n, sub="pruebas")["truncado"], total >= n)
                carga = {"results": {"web": [{"url": f"https://www.reddit.com/r/otra/comments/{PID}/"}] * total}}
                msg = {"jsonrpc": "2.0", "id": 1, "result": {"content": [{"type": "text", "text": json.dumps(carga)}]}}
                self.helper._http = mock.Mock(return_value=json.dumps(msg))
                r = self.helper.buscar_you("tema", "w", n, sub="pruebas")  # el filtro local no oculta la página llena
                self.assertEqual((r["resultados"], r["truncado"]), ([], total >= n))

    def test_pendientes_que_trae_redlib_no_cuentan(self):
        self.fake_arctic(nodes=[node(comment()), {"kind": "more", "data": {"children": ["dddd4"], "count": 1}}])
        self.con_redlib(comentarios=html_comment("cccc3", "texto original") + html_comment("dddd4", "desde redlib", "bob"))
        r = self.helper.leer(PID)
        self.assertIn("dddd4", [c["id"] for c in r["comentarios"]])
        self.assertEqual(r["cobertura"]["pendientes"], [])
        self.assertEqual(r["cobertura"]["avisos_more"], [])
        self.assertNotIn("comentarios pendientes de expansión", r["cobertura"]["motivos_parcial"])

    # 4. Cuerpos de error con 200 y 52x: se reintentan y cuentan como fallo (reproducción 4).
    def test_jsonrpc_de_you_se_reintenta(self):
        self.sin_reintento_lento()
        cuerpo = json.dumps({"jsonrpc": "2.0", "id": 1, "error": {"code": -32603, "message": "Synthetic internal failure"}}).encode()
        abrir = self.patch(rh.urllib.request.OpenerDirector, "open", return_value=Response(cuerpo))
        with self.assertRaises(rh.HttpError) as caught:
            self.helper.buscar_you("test", "w", reintentos=3)
        self.assertEqual(caught.exception.code, 502)
        self.assertEqual(abrir.call_count, 3)
        self.assertGreater(self.helper._breaker("you")._failure_count, 0)

    def test_cuerpos_de_error_con_200(self):
        self.sin_reintento_lento()
        for fuente, cuerpo in (("firecrawl", {"success": False, "error": "fallo temporal"}),
                               ("arctic", {"error": "Timeout", "data": None})):
            abrir = self.patch(rh.urllib.request.OpenerDirector, "open", return_value=Response(json.dumps(cuerpo).encode()))
            with self.assertRaises(rh.HttpError) as caught:
                self.helper._http(fuente, "https://example.invalid/", reintentos=2)
            self.assertEqual((caught.exception.code, abrir.call_count), (502, 2))
        for code in (520, 521, 522, 523, 524):
            self.assertTrue(rh.es_reintentable(rh.HttpError(code, "", "u")))

    # 5. Nunca https → http, aunque no haya claves (reproducción 5).
    def test_redireccion_https_a_http_sin_claves(self):
        req = rh.urllib.request.Request(f"https://safereddit.com/r/pruebas/comments/{PID}/")
        with self.assertRaises(urllib.error.HTTPError):
            rh._RedirectSeguro().redirect_request(req, None, 302, "Found", {}, f"http://safereddit.com/r/pruebas/comments/{PID}/")
        self.assertIsNotNone(rh._RedirectSeguro().redirect_request(req, None, 302, "Found", {},
                                                                    f"https://safereddit.com/r/pruebas/comments/{PID}/?x=1"))

    # Tamaño: respuesta y gzip acotados; superarlo da error, nunca un éxito truncado.
    def test_respuestas_y_gzip_acotados(self):
        self.patch(rh, "MAX_RESPUESTA", 100)
        for raw, cabeceras in ((b'{"a":"' + b"x" * 200 + b'"}', None),
                               (gzip.compress(b'{"a":"' + b"0" * 5000 + b'"}'), {"Content-Type": "application/json", "Content-Encoding": "gzip"})):
            abrir = self.patch(rh.urllib.request.OpenerDirector, "open", return_value=Response(raw, cabeceras))
            with self.assertRaises(rh.HttpError) as caught:
                self.helper._http("demo", "https://example.invalid/", reintentos=3)
            self.assertEqual((caught.exception.code, abrir.call_count), (413, 1))
        self.patch(rh.urllib.request.OpenerDirector, "open", return_value=Response(gzip.compress(b'{"ok":1}')))
        self.assertEqual(self.helper._http("demo", "https://example.invalid/"), {"ok": 1})
        self.patch(rh.urllib.request.OpenerDirector, "open", return_value=Response(gzip.compress(b'{"ok":1}')[:-6]))
        with self.assertRaises(rh.HttpError) as caught:
            self.helper._http("demo2", "https://example.invalid/", reintentos=1)
        self.assertEqual(caught.exception.code, 502)
        error = urllib.error.HTTPError("https://example.invalid/", 503, "caído", {}, io.BytesIO(b"x" * 500))
        self.patch(rh.urllib.request.OpenerDirector, "open", side_effect=error)
        with self.assertRaises(rh.HttpError) as caught:
            self.helper._http("demo3", "https://example.invalid/", reintentos=1)
        self.assertEqual(caught.exception.code, 503)
        self.assertIn("demasiado grande", caught.exception.cuerpo)

    # salud: sin --en-vivo no hay consultas de pago.
    def test_salud_no_gasta_creditos_por_defecto(self):
        os.environ["BRAVE_SEARCH_API_KEY"] = "test-key-1234567890"
        self.helper._http = mock.Mock(side_effect=rh.HttpError(503, "sin red", "u"))
        for nombre in ("buscar_brave", "buscar_perplexity", "buscar_firecrawl", "buscar_you"):
            self.patch(self.helper, nombre, return_value={"resultados": []})
        fila = next(f for f in self.helper.salud() if f["fuente"] == "brave")
        self.assertEqual((fila["estado"], fila["ok"]), ("CFG", None))
        self.helper.buscar_brave.assert_not_called()
        fila = next(f for f in self.helper.salud(en_vivo=True) if f["fuente"] == "brave")
        self.assertTrue(fila["ok"])
        self.helper.buscar_brave.assert_called_once()

    # D2: conectar desde el portapapeles, nunca por el chat.
    def test_conectar_guarda_sin_mostrar_ni_perder_otras_claves(self):
        ruta = self.out / "claves" / "claves.env"
        rh.fichero_claves.return_value = ruta
        ruta.parent.mkdir()
        ruta.write_text("PERPLEXITY_API_KEY=pplx-otra-12345678\nBRAVE_SEARCH_API_KEY=vieja-123456789\n")
        msg = rh.conectar_clave("BRAVE_SEARCH_API_KEY", "  BSAnueva-abcdefgh9876\n")
        self.assertNotIn("BSAnueva-abcdefgh9876", msg)
        self.assertIn("…9876", msg)
        lineas = ruta.read_text().splitlines()
        self.assertEqual(sorted(lineas), ["BRAVE_SEARCH_API_KEY=BSAnueva-abcdefgh9876", "PERPLEXITY_API_KEY=pplx-otra-12345678"])
        if os.name == "posix":
            self.assertEqual(ruta.stat().st_mode & 0o777, 0o600)
        self.assertEqual(rh.clave("BRAVE_SEARCH_API_KEY"), "BSAnueva-abcdefgh9876")
        for malo in ("dos\nlineas-12345678", "con espacio 12345678", "corta", ""):
            with self.assertRaises(ValueError) as caught:
                rh.conectar_clave("FIRECRAWL_API_KEY", malo)
            if malo:
                self.assertNotIn(malo, str(caught.exception))
        os.environ["BRAVE_SEARCH_API_KEY"] = "entorno-key-0000aaaa"
        self.assertIn("tiene prioridad", rh.conectar_clave("BRAVE_SEARCH_API_KEY", "BSAnueva-abcdefgh9876"))
        del os.environ["BRAVE_SEARCH_API_KEY"]
        with mock.patch.object(rh, "leer_portapapeles", return_value="fc-portapapeles-55554444"), \
                contextlib.redirect_stdout(io.StringIO()) as salida:
            self.assertEqual(rh.main(["conectar", "firecrawl"]), 0)
        self.assertNotIn("fc-portapapeles-55554444", salida.getvalue())
        self.assertIn("FIRECRAWL_API_KEY=fc-portapapeles-55554444", ruta.read_text())

    def test_preparar_fichero_sin_portapapeles(self):
        ruta = self.out / "nuevo" / "claves.env"
        rh.fichero_claves.return_value = ruta
        with mock.patch.object(rh.shutil, "which", return_value=None), \
                contextlib.redirect_stderr(io.StringIO()) as err:
            self.assertEqual(rh.main(["conectar", "brave"]), 2)
        self.assertIn("--preparar-fichero", err.getvalue())
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(rh.main(["conectar", "brave", "--preparar-fichero"]), 0)
            self.assertEqual(rh.main(["conectar", "brave", "--preparar-fichero"]), 0)
        self.assertEqual(ruta.read_text(), "BRAVE_SEARCH_API_KEY=\n")
        self.assertEqual(rh.clave("BRAVE_SEARCH_API_KEY", obligatoria=False), "")

    # D3: cobertura pobre determinista.
    def test_cobertura_pobre_cuenta_texto_entregable(self):
        # Cinco posts retirados sin comentarios: estado «completa», cero citas → pobre.
        self.fake_arctic(p=post(selftext=self.MARCA, removed_by_category="moderator", num_comments=0))
        hilos = [self.helper.leer(PID, votos_actuales=False) for _ in range(5)]
        self.assertTrue(all(h["cobertura"]["estado"] == "completa" for h in hilos))
        self.assertEqual(rh.citas({"hilos": hilos}, "."), [])
        self.assertIn("solo 0 hilos leídos con texto", rh.motivos_cobertura_pobre(hilos, [])[0])
        # Con un comentario vivo cada uno ya cuentan.
        self.fake_arctic(p=post(selftext=self.MARCA, removed_by_category="moderator"), nodes=[node(comment())])
        hilos = [self.helper.leer(PID, votos_actuales=False) for _ in range(5)]
        self.assertEqual(rh.motivos_cobertura_pobre(hilos, []), [])

    def test_cobertura_pobre(self):
        def hilo(estado):
            return {"cobertura": {"estado": estado}, "post": {"cuerpo": "texto"}}
        self.assertEqual(rh.motivos_cobertura_pobre([hilo("completa")] * 3 + [hilo("parcial")] * 2, []), [])
        self.assertEqual(len(rh.motivos_cobertura_pobre([hilo("completa")] * 4, [])), 1)
        motivos = rh.motivos_cobertura_pobre([hilo("completa")] * 5 + [hilo("sin_texto")] * 4, [{"ref": "x"}] * 2)
        self.assertEqual(len(motivos), 1)
        self.assertIn("6 de 11", motivos[0])
        fuentes = {"you:w": {"ok": False}, "arctic:w/r/x": {"ok": True}, "brave:w": {"ok": False}}
        motivos = rh.motivos_cobertura_pobre([hilo("completa")] * 5, [], fuentes)
        self.assertEqual(motivos, ["buscador del modo base caído: you:w"])

    # 6. Zona horaria: reglas del instante histórico (falla con el desfase de hoy en zonas con horario de verano).
    @unittest.skipUnless(hasattr(time, "tzset"), "tzset solo en POSIX")
    def test_epoca_cero_con_reglas_historicas(self):
        anterior = os.environ.get("TZ")
        os.environ["TZ"] = "America/Chicago"
        time.tzset()
        try:
            with mock.patch.object(rh, "ZONA_FORZADA", None), \
                    mock.patch.object(rh.Path, "is_symlink", return_value=False), \
                    mock.patch.object(rh, "ZoneInfo"):
                self.assertEqual(rh.iso_local(0), "1969-12-31T18:00:00-06:00")
        finally:
            if anterior is None:
                os.environ.pop("TZ", None)
            else:
                os.environ["TZ"] = anterior
            time.tzset()
