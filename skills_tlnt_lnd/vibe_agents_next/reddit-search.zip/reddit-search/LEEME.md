# reddit-search

Skill para que tu agente investigue en Reddit cualquier tema y te entregue **citas literales** con su enlace, subreddit,
autor, fecha y votos. No hace resúmenes inventados.

## Instalar

Descarga `reddit-search.zip` y dile a tu agente (Claude Code, Codex o Hermes):

> «Instala el skill reddit-search de este zip y comprueba que funciona.»

Lo descomprime en su carpeta de skills, comprueba que tenga Python 3.9 o superior (si falta, lo instala) y ejecuta una
comprobación. Debe responder «modo base».

| Agente | Carpeta de skills |
|---|---|
| Claude Code | `~/.claude/skills/reddit-search` |
| Codex | `~/.codex/skills/reddit-search` |
| Hermes | la carpeta de skills del perfil que uses (por defecto `~/.hermes/skills/reddit-search`) |

## Usar

> «Investiga en Reddit qué opina la gente de [tu tema] en el último mes.»

## Dos modos

- **Modo base (sin claves):** funciona nada más instalarlo. Descubre hilos con You.com (gratuito), Arctic Shift y el
  buscador web de tu agente cuando este llega a Reddit (en las pruebas del 8-oct-2026, el buscador de Codex aportó
  enlaces de Reddit y el de Claude Code no). Intenta leerlos completos
  con Arctic Shift y Redlib y te dice la cobertura de cada uno.
- **Modo experto (con claves):** añade Brave Search, Perplexity y Firecrawl para poder descubrir más hilos, sobre todo en temas de
  nicho. Copia la clave en el panel del servicio y dile a tu agente:

  > «Conecta Brave Search para reddit-search; ya copié la clave.» (y lo mismo con Perplexity y Firecrawl)

  Tu agente la toma del portapapeles y la guarda en tu equipo sin mostrarla. **No pegues nunca una clave en el chat.** Precios y dónde sacar cada clave: `references/fuentes-y-endpoints.md` §13.

## Requisitos

- Un agente con acceso a internet que pueda ejecutar programas.
- Python 3.9 o superior. Tu agente lo instala si falta.

En Hermes se han comprobado la instalación y la carga del skill; la investigación completa todavía no se ha probado.

## Aviso

Sin afiliación con Reddit ni con los servicios citados. Solo lee contenido público y no entrega lo que hoy está borrado.
