---
name: nowpayments-skill
description: >
  Use this skill whenever the user needs to work with NOWPayments — the non-custodial
  cryptocurrency payment gateway supporting 350+ coins. This includes: writing TypeScript/Python
  code that calls the NOWPayments REST API, creating crypto payments or invoices, setting up
  IPN (Instant Payment Notification) webhook handlers with HMAC-SHA512 verification,
  implementing recurring crypto subscriptions (email-based or custodial auto-charge),
  building mass payout systems with JWT authentication and IP whitelisting, managing
  custody/sub-partner accounts for platform architectures (exchanges, casinos, gaming),
  performing off-chain crypto-to-crypto conversions via ChangeNOW, integrating payment
  widgets, donation buttons, or Point of Sale QR codes, working with sandbox testing
  and the `case` parameter for simulating payment flows, or choosing between direct
  payment flow vs invoice-based flow vs custodial platform flow.
  ALSO trigger for crypto payment architecture decisions: choosing between NOWPayments
  and Stripe for dual fiat+crypto gateways, fixed-rate vs floating-rate pricing,
  non-custodial vs custodial mode, handling partial payments with purchase_id linking,
  SDK selection (official abandoned vs community vs direct fetch), fee optimization
  (0.5% same-currency vs 1% conversion), or multi-chain payment acceptance strategy.
  Trigger keywords: "NOWPayments", "crypto payment gateway", "crypto payment",
  "IPN callback", "ipn_callback_url", "x-nowpayments-sig", "HMAC-SHA512",
  "pay_address", "pay_amount", "payment_status", "invoice_url", "crypto invoice",
  "crypto subscription", "crypto payout", "mass payout", "crypto custody",
  "sub-partner", "ChangeNOW", "crypto donation", "crypto widget",
  "nowpayments-api", "api-sandbox.nowpayments.io", "350+ cryptocurrencies",
  "non-custodial gateway", "purchase_id", "partially_paid", "fixed_rate",
  "is_fee_paid_by_user", "pay_currency", "price_currency", "outcome_amount",
  "accept crypto", "accept bitcoin", "BTC payment", "ETH payment", "USDT payment".
  Even if the user just asks "accept crypto payments", "add bitcoin payments",
  "crypto checkout", "crypto webhook", "crypto payout", or "crypto billing",
  use this skill.
---

# NOWPayments API — State of the Art (February 2026)

## Quick Orientation

NOWPayments is a **non-custodial cryptocurrency payment gateway** by the team behind
ChangeNOW exchange (est. 2019). It supports **350+ cryptocurrencies** through a REST API
with the industry's lowest fees at **0.5% per transaction** (1% with conversion).

| Property | Value |
|----------|-------|
| **API Base (Prod)** | `https://api.nowpayments.io/v1` |
| **API Base (Sandbox)** | `https://api-sandbox.nowpayments.io/v1` |
| **Dashboard (Prod)** | `https://account.nowpayments.io` |
| **Dashboard (Sandbox)** | `https://account-sandbox.nowpayments.io` |
| **Currencies** | 350+ crypto, 20+ fiat for pricing |
| **Base Fee** | 0.5% (same-currency), 1% (with conversion) |
| **Payment Statuses** | 9: waiting, confirming, confirmed, sending, finished, partially_paid, failed, refunded, expired |
| **Custody Model** | Non-custodial default, optional custody for platforms |
| **Exchange Backend** | ChangeNOW (crypto-to-crypto conversions) |

**Three-layer authentication**:
1. **API Key** (`x-api-key` header) — required for all requests
2. **JWT Bearer Token** (`Authorization: Bearer <jwt>`) — required for payouts, custody, balance, listing payments
3. **IPN Secret Key** — used server-side for HMAC-SHA512 webhook signature verification (never sent as header)

**Rate limits**: Not published. API returns HTTP 429 when exceeded — implement exponential backoff.

**For deeper topics, read the appropriate reference file before writing code:**

| Topic | Reference File | When to Read |
|-------|---------------|--------------|
| POST /payment, POST /invoice, payment statuses, partial payments, utility endpoints | `references/payments-and-invoices.md` | Creating payments, invoices, checking status |
| IPN payload, HMAC-SHA512 verification, framework handlers, webhook retry | `references/webhooks-and-ipn.md` | Setting up webhook handlers |
| Subscription plans, email subscriptions, mass payouts, JWT auth, payout statuses | `references/subscriptions-and-payouts.md` | Recurring billing, sending crypto payouts |
| Custody accounts, sub-partners, off-chain conversions, platform architecture | `references/custody-and-conversions.md` | Building exchanges, casinos, custodial platforms |
| Official/community SDKs, widgets, donation buttons, PoS, e-commerce plugins | `references/sdks-and-plugins.md` | Choosing an SDK, embedding widgets |
| Sandbox setup, `case` parameter, local dev (ngrok), integration tests, CI/CD | `references/sandbox-and-testing.md` | Testing payments without real funds |
| HTTP errors, retryable errors, IPN debugging, production hardening, alternatives | `references/error-handling-and-gotchas.md` | Troubleshooting, production readiness |

## TypeScript Quick Start

Since the official JS SDK is abandoned, use **direct `fetch` calls** (Node 18+, zero dependencies):

```typescript
// --- Create a NOWPayments client ---
const API_KEY = process.env.NOWPAYMENTS_API_KEY!;
const BASE_URL = 'https://api.nowpayments.io/v1';

async function nowpay(method: string, path: string, body?: Record<string, unknown>) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: res.statusText }));
    throw new Error(`NOWPayments ${res.status}: ${JSON.stringify(err)}`);
  }
  return res.json();
}

// --- Check API status ---
const status = await nowpay('GET', '/status');
// { "message": "OK" }

// --- Get minimum amount for BTC→ETH ---
const min = await nowpay('GET', '/min-amount?currency_from=btc&currency_to=eth');
// { "currency_from": "btc", "currency_to": "eth", "min_amount": 0.00055872 }

// --- Create a payment ---
const payment = await nowpay('POST', '/payment', {
  price_amount: 100,
  price_currency: 'usd',
  pay_currency: 'btc',
  ipn_callback_url: 'https://example.com/api/nowpayments/ipn',
  order_id: 'ORDER-001',
});
// payment.pay_address → display to customer
// payment.pay_amount → exact BTC amount to send
// payment.payment_id → save for status checks

// --- Get payment status ---
const paymentStatus = await nowpay('GET', `/payment/${payment.payment_id}`);
// paymentStatus.payment_status → "waiting" | "confirming" | ... | "finished"

// --- Create an invoice (hosted payment page) ---
const invoice = await nowpay('POST', '/invoice', {
  price_amount: 50,
  price_currency: 'usd',
  success_url: 'https://example.com/success',
  cancel_url: 'https://example.com/cancel',
  ipn_callback_url: 'https://example.com/api/nowpayments/ipn',
  order_id: 'INV-001',
});
// invoice.invoice_url → redirect customer here

// --- Verify IPN webhook signature ---
import { createHmac, timingSafeEqual } from 'node:crypto';

function verifyIPN(body: Record<string, unknown>, signature: string, ipnSecret: string): boolean {
  function sortObj(obj: unknown): unknown {
    if (typeof obj !== 'object' || obj === null || Array.isArray(obj)) return obj;
    return Object.keys(obj as Record<string, unknown>).sort().reduce((acc, key) => {
      acc[key] = sortObj((obj as Record<string, unknown>)[key]);
      return acc;
    }, {} as Record<string, unknown>);
  }
  const hmac = createHmac('sha512', ipnSecret);
  hmac.update(JSON.stringify(sortObj(body)));
  const calculated = hmac.digest('hex');
  return timingSafeEqual(Buffer.from(calculated), Buffer.from(signature));
}
```

## Python Quick Start

```python
# Option 1: Community SDK (recommended for simple integrations)
# pip install nowpayments
from nowpayments import NOWPayments
# or for sandbox: from nowpayments import NOWPaymentsSandbox

client = NOWPayments("YOUR_API_KEY")

# Check status
status = client.get_api_status()

# Create payment
payment = client.create_payment(
    price_amount=100,
    price_currency="usd",
    pay_currency="btc",
    ipn_callback_url="https://example.com/ipn",
    order_id="ORDER-001",
)
# payment["pay_address"], payment["pay_amount"]

# Create invoice
invoice = client.create_invoice(
    price_amount=50,
    price_currency="usd",
    success_url="https://example.com/success",
    cancel_url="https://example.com/cancel",
)
# invoice["invoice_url"]
```

```python
# Option 2: Direct requests (full control, no SDK dependency)
import requests, json, hmac, hashlib

API_KEY = "YOUR_API_KEY"
BASE = "https://api.nowpayments.io/v1"
HEADERS = {"x-api-key": API_KEY, "Content-Type": "application/json"}

# Create payment
resp = requests.post(f"{BASE}/payment", json={
    "price_amount": 100, "price_currency": "usd", "pay_currency": "btc",
    "ipn_callback_url": "https://example.com/ipn", "order_id": "ORDER-001",
}, headers=HEADERS)
payment = resp.json()

# Verify IPN signature
def verify_ipn(body: dict, signature: str, ipn_secret: str) -> bool:
    sorted_json = json.dumps(body, separators=(",", ":"), sort_keys=True)
    calculated = hmac.new(
        ipn_secret.encode(), sorted_json.encode(), hashlib.sha512
    ).hexdigest()
    return hmac.compare_digest(calculated, signature)
```

## Payment Status Lifecycle

```
                          ┌─────────────┐
                          │   waiting    │ ← Payment created
                          └──────┬──────┘
                                 │ tx detected on blockchain
                          ┌──────▼──────┐
                          │  confirming  │
                          └──────┬──────┘
                                 │ enough confirmations
                          ┌──────▼──────┐
                          │  confirmed   │
                          └──────┬──────┘
                                 │ exchanging/sending
                          ┌──────▼──────┐
                          │   sending    │
                          └──────┬──────┘
                                 │ funds reached merchant wallet
                          ┌──────▼──────┐
                          │  finished ✓  │ ← FULFILL ORDER
                          └─────────────┘

Alternative outcomes:
  waiting ──(24h no funds)──→ expired
  waiting ──(underpayment)──→ partially_paid ──(top-up via purchase_id)──→ confirming → ...
  any ──(error)──→ failed
  finished ──(manual via support)──→ refunded
```

### IPN Verification Flow

```
  Incoming POST /ipn
       │
       ▼
  ┌─────────────────┐
  │ Extract header   │
  │ x-nowpayments-sig│
  └────────┬────────┘
           │
           ▼
  ┌─────────────────┐
  │ Parse JSON body  │
  └────────┬────────┘
           │
           ▼
  ┌─────────────────┐
  │ Sort ALL keys    │◄── Recursive! Nested objects too
  │ alphabetically   │
  └────────┬────────┘
           │
           ▼
  ┌─────────────────┐
  │ JSON.stringify   │◄── No spaces: separators=(',',':')
  │ (sorted object)  │
  └────────┬────────┘
           │
           ▼
  ┌─────────────────┐
  │ HMAC-SHA512      │◄── Key = IPN Secret (from dashboard)
  │ (sorted JSON)    │
  └────────┬────────┘
           │
           ▼
  ┌─────────────────┐     ┌──────────┐
  │ timingSafeEqual  │─NO─→│ 401 FAIL │
  │ (calc vs header) │     └──────────┘
  └────────┬────────┘
           │ YES
           ▼
  ┌─────────────────┐
  │ Process payment  │
  │ status update    │
  └─────────────────┘
```

## Fee Structure Quick Reference

| Operation | Fee |
|-----------|-----|
| Same-currency (BTC→BTC) | **0.5%** |
| With conversion (ETH→BTC) | **1.0%** (0.5% service + 0.5% exchange) |
| Fixed-rate (locked price) | **1.0%** flat |
| `is_fee_paid_by_user: true` | **1.0%** (always fixed rate) |
| Custody deposit | **0.5%** |
| Payout / withdrawal service | **0%** (network fee only) |
| Off-chain custody conversion | **0.5%** |
| Fiat settlement (off-ramp) | **1.5–2.3%** |
| Volume discount | 0.45% at 50+ BTC/mo, 0.4% at 100+ BTC/mo |

## Critical Gotchas

1. **IPN signature requires sorted keys** — The #1 failure point. You must sort all JSON keys alphabetically (recursively for nested objects) before computing HMAC-SHA512. In Python use `sort_keys=True` with `separators=(',', ':')`. In Node.js sort the object manually. In PHP use `ksort()` recursively with `JSON_UNESCAPED_SLASHES`.

2. **Official JS SDK is abandoned** — `@nowpaymentsio/nowpayments-api-js` has outdated dependencies (axios 0.21.1), Webpack v5 incompatibility, and lacks JWT auth methods. Use direct `fetch` calls, the `nowpayments_helper.ts` script in this skill, or the community `nowpayments-api` package by MrCerber.

3. **Validate min-amount BEFORE creating payments** — Call `GET /v1/min-amount` first. Payments below the minimum fail. Minimums vary by currency pair and change with market conditions.

4. **`/currencies` is not `/merchant/coins`** — `GET /v1/currencies` returns all 350+ platform currencies. `GET /v1/merchant/coins` returns only currencies you have enabled in dashboard Coin Settings. Use `merchant/coins` for customer-facing currency selectors.

5. **Fixed-rate vs floating-rate** — Without `fixed_rate: true`, exchange rates can shift between payment creation and customer payment. Fixed rate locks the price for ~20 minutes at 1% fee. For price-sensitive transactions, always use fixed rate.

6. **Payments expire in 24 hours** — `expiration_estimate_date` in the response is the price estimate expiry (~20 minutes), NOT the payment expiry. The 24-hour payment expiry is not an explicit field.

7. **No idempotency keys** — The API does not support idempotency keys. Implement your own deduplication using `order_id` → `payment_id` mapping on your side.

8. **Cloudflare/WAFs block webhooks** — If using Cloudflare or any WAF, whitelist NOWPayments' server IPs or IPN callbacks will silently fail. Cannot use localhost for `ipn_callback_url`.

9. **Mass payouts require full security stack** — You need all of: custody enabled + funds pre-deposited + 2FA active + IPs whitelisted + wallet addresses whitelisted + JWT authentication. Missing any results in 403.

10. **Overpayments require manual support** — Significant overpayments may not process automatically. Contact support@nowpayments.io. There is no self-service refund API endpoint.

11. **No iframe for invoice pages** — The invoice experience requires redirecting customers to `invoice_url`. There is no embeddable iframe option.

12. **Crypto subscriptions are NOT automatic** — Email-based subscriptions (`POST /v1/subscriptions`) send a payment link to the customer at each interval. The customer must manually complete each payment. For true auto-charge, use custody accounts with programmatic balance deductions.

## Cross-Skill Integration

### convex-skill
NOWPayments API calls MUST run in Convex **actions** (not queries or mutations) because
they make external HTTP calls. Store payment IDs and statuses in Convex tables.
Use IPN webhooks to sync payment state back to Convex via HTTP actions.

```typescript
// convex/nowpayments.ts — Convex action
"use node";
import { action } from "./_generated/server";
import { v } from "convex/values";

export const createCryptoPayment = action({
  args: { amount: v.number(), currency: v.string(), orderId: v.string() },
  handler: async (ctx, args) => {
    const res = await fetch("https://api.nowpayments.io/v1/payment", {
      method: "POST",
      headers: {
        "x-api-key": process.env.NOWPAYMENTS_API_KEY!,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        price_amount: args.amount,
        price_currency: args.currency,
        pay_currency: "btc",
        ipn_callback_url: `${process.env.CONVEX_SITE_URL}/nowpayments-ipn`,
        order_id: args.orderId,
      }),
    });
    return res.json();
  },
});
```

### nextjs-web
IPN webhook handler in `app/api/webhooks/nowpayments/route.ts` using `req.text()` for
raw body access. Use Server Actions for creating payments and invoices. Redirect
customers to `invoice_url` for the hosted payment page.

```typescript
// app/api/webhooks/nowpayments/route.ts
import { createHmac, timingSafeEqual } from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get('x-nowpayments-sig');
  if (!signature) return NextResponse.json({ error: 'Missing signature' }, { status: 401 });

  const body = JSON.parse(rawBody);
  // Verify HMAC-SHA512 with sorted keys (see webhooks-and-ipn.md)
  // Process payment status update...
  return NextResponse.json({ status: 'ok' });
}
```

### supabase-skill
NOWPayments IPN webhooks can target Supabase Edge Functions. Use `Deno.serve()` with
`request.text()` for raw body verification. Store payment state in Supabase tables with
RLS policies.

### stripe-skill (Dual Gateway)
For dual fiat+crypto checkout: use **Stripe** for credit card and traditional payments,
and **NOWPayments** for cryptocurrency payments. Present both options on your checkout
page. Use the same `order_id` across both gateways for reconciliation. Handle webhooks
from both services to a unified order fulfillment system.

## Next Steps

Read the reference files based on your task:
- **Creating payments or invoices?** → `references/payments-and-invoices.md`
- **Setting up IPN webhook handlers?** → `references/webhooks-and-ipn.md`
- **Building subscriptions or payouts?** → `references/subscriptions-and-payouts.md`
- **Building a custodial platform?** → `references/custody-and-conversions.md`
- **Choosing an SDK or embedding widgets?** → `references/sdks-and-plugins.md`
- **Testing in sandbox?** → `references/sandbox-and-testing.md`
- **Troubleshooting or production hardening?** → `references/error-handling-and-gotchas.md`
