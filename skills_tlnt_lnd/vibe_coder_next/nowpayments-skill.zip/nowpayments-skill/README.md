# nowpayments-skill — Skill de Claude Code

Skill instalable para **Claude Code**: integración con **NOWPayments**, el gateway
de pagos en criptomonedas no custodial (350+ monedas). Crea pagos e invoices,
webhooks IPN con verificación HMAC-SHA512, suscripciones cripto recurrentes,
payouts masivos con JWT, cuentas custodia/sub-partner, conversiones off-chain,
widgets y QR de Point of Sale, y sandbox de pruebas. Autocontenida.

## Cómo instalar
1. Descomprime este ZIP. Obtendrás una carpeta `nowpayments-skill/`.
2. Cópiala a tu directorio de skills de Claude Code:
   - **Personal:** `~/.claude/skills/nowpayments-skill/`
   - **Solo un proyecto:** `<tu-proyecto>/.claude/skills/nowpayments-skill/`
3. Reinicia Claude Code. Se activará sola al trabajar con NOWPayments.

## Contenido
- `SKILL.md` — guía principal.
- `references/` — payments-and-invoices, webhooks-and-ipn, subscriptions-and-payouts,
  custody-and-conversions, sandbox-and-testing, sdks-and-plugins, error-handling-and-gotchas.

Cortesía de **Talent Academy · Vibe Coder**.
