#!/usr/bin/env npx tsx
/**
 * nowpayments_helper.ts — Reusable helper for NOWPayments API operations.
 *
 * ZERO npm dependencies: uses native `fetch` (Node 18+) + `node:crypto`.
 * The official NOWPayments JS SDK is abandoned — this helper IS the recommended SDK.
 *
 * Usage as module:
 *   import { NOWPaymentsHelper, verifyIPNSignature } from './nowpayments_helper';
 *   const nph = new NOWPaymentsHelper({ apiKey: process.env.NP_API_KEY! });
 *   const payment = await nph.createPayment({ price_amount: 100, price_currency: 'usd', pay_currency: 'btc' });
 *
 * Usage as CLI:
 *   npx tsx nowpayments_helper.ts --action status --api-key $NP_API_KEY
 *   npx tsx nowpayments_helper.ts --action create-payment --api-key $NP_API_KEY --amount 100 --price-currency usd --pay-currency btc
 *   npx tsx nowpayments_helper.ts --action verify-ipn --ipn-secret $NP_IPN_SECRET --payload '{"...":...}'
 *   npx tsx nowpayments_helper.ts --action balance --api-key $NP_API_KEY --email me@x.com --password s3cr3t
 *
 * API prod:    https://api.nowpayments.io/v1
 * API sandbox: https://api-sandbox.nowpayments.io/v1
 */

import { createHmac, timingSafeEqual } from 'node:crypto';


// =============================================================================
// Types & Interfaces
// =============================================================================

/** Posibles estados de un pago en NOWPayments. */
type PaymentStatus =
  | 'waiting'
  | 'confirming'
  | 'confirmed'
  | 'sending'
  | 'finished'
  | 'partially_paid'
  | 'failed'
  | 'refunded'
  | 'expired';

interface NOWPaymentsConfig {
  apiKey: string;
  ipnSecret?: string;
  sandbox?: boolean;
  email?: string;
  password?: string;
}

interface PaymentParams {
  price_amount: number;
  price_currency: string;
  pay_currency: string;
  ipn_callback_url?: string;
  order_id?: string;
  order_description?: string;
  payout_address?: string;
  payout_currency?: string;
  payout_extra_id?: string;
  fixed_rate?: boolean;
  is_fee_paid_by_user?: boolean;
}

interface InvoiceParams {
  price_amount: number;
  price_currency: string;
  order_id?: string;
  order_description?: string;
  ipn_callback_url?: string;
  success_url?: string;
  cancel_url?: string;
  partially_paid_url?: string;
  is_fee_paid_by_user?: boolean;
}

interface PayoutParams {
  address: string;
  currency: string;
  amount: number;
  extra_id?: string;
  fiat_amount?: number;
  fiat_currency?: string;
}

interface WithdrawalItem {
  address: string;
  currency: string;
  amount: number;
  extra_id?: string;
  ipn_callback_url?: string;
  fiat_amount?: number;
  fiat_currency?: string;
}

interface SubscriptionPlanParams {
  title: string;
  interval_day: number;
  amount: number;
  currency: string;
  ipn_callback_url?: string;
}


// =============================================================================
// CircuitBreaker Pattern
// =============================================================================


/** Estados del circuit breaker. */
enum CircuitBreakerState {
  CLOSED = 'closed',       // Normal: llamadas pasan
  OPEN = 'open',           // Fallando: llamadas rechazadas
  HALF_OPEN = 'half_open', // Probando recuperacion
}

interface CircuitBreakerOptions {
  failureThreshold: number;
  resetTimeoutMs: number;
  halfOpenMax: number;
}

interface CircuitBreakerStats {
  state: CircuitBreakerState;
  failureCount: number;
  successCount: number;
  halfOpenCalls: number;
  lastFailureTime: number;
  timeUntilRecoveryMs: number;
}

/** Se lanza cuando el circuit breaker esta abierto y rechaza llamadas. */
class CircuitBreakerOpenError extends Error {
  public readonly state: CircuitBreakerState;
  public readonly failureCount: number;
  public readonly timeUntilRecoveryMs: number;

  constructor(message: string, state: CircuitBreakerState, failureCount: number, timeUntilRecoveryMs: number) {
    super(message);
    this.name = 'CircuitBreakerOpenError';
    this.state = state;
    this.failureCount = failureCount;
    this.timeUntilRecoveryMs = timeUntilRecoveryMs;
  }
}


/**
 * Implementacion del patron Circuit Breaker para proteger contra fallos en cascada.
 *
 * Flujo: CLOSED -> (fallos >= threshold) -> OPEN -> (timeout) -> HALF_OPEN -> (exito) -> CLOSED
 *                                                                            -> (fallo) -> OPEN
 *
 * Uso:
 *   const cb = new CircuitBreaker({ failureThreshold: 5, resetTimeoutMs: 30000, halfOpenMax: 3 });
 *   const result = await cb.execute(() => apiCall());
 */
class CircuitBreaker {
  private state: CircuitBreakerState = CircuitBreakerState.CLOSED;
  private failureCount = 0;
  private successCount = 0;
  private halfOpenCalls = 0;
  private lastFailureTime = 0;
  private lastStateChange: number = Date.now();

  private readonly failureThreshold: number;
  private readonly resetTimeoutMs: number;
  private readonly halfOpenMax: number;

  constructor(options: CircuitBreakerOptions = { failureThreshold: 5, resetTimeoutMs: 30000, halfOpenMax: 3 }) {
    this.failureThreshold = options.failureThreshold;
    this.resetTimeoutMs = options.resetTimeoutMs;
    this.halfOpenMax = options.halfOpenMax;
  }

  /**
   * Ejecuta la funcion a traves del circuit breaker.
   * Lanza CircuitBreakerOpenError si el circuito esta abierto.
   */
  async execute<T>(fn: () => Promise<T>): Promise<T> {
    const currentState = this.getCurrentState();

    if (currentState === CircuitBreakerState.OPEN) {
      const remaining = this.timeUntilRecovery();
      throw new CircuitBreakerOpenError(
        `Circuit breaker OPEN. ${this.failureCount} fallos consecutivos. ` +
        `Reintento en ${Math.ceil(remaining / 1000)}s`,
        currentState,
        this.failureCount,
        remaining,
      );
    }

    if (currentState === CircuitBreakerState.HALF_OPEN) {
      if (this.halfOpenCalls >= this.halfOpenMax) {
        this.transitionToOpen();
        throw new CircuitBreakerOpenError(
          `Circuit breaker re-opened: maximo de pruebas half-open alcanzado`,
          CircuitBreakerState.OPEN,
          this.failureCount,
          this.resetTimeoutMs,
        );
      }
      this.halfOpenCalls++;
    }

    try {
      const result = await fn();
      this.recordSuccess();
      return result;
    } catch (error) {
      if (this.isRetryable(error)) {
        this.recordFailure();
      }
      throw error;
    }
  }

  /** Registra un exito. En HALF_OPEN, cierra el circuito tras suficientes exitos. */
  private recordSuccess(): void {
    this.failureCount = 0;
    this.successCount++;
    if (this.state === CircuitBreakerState.HALF_OPEN) {
      if (this.successCount >= this.halfOpenMax) {
        this.transitionToClosed();
      }
    }
  }

  /** Registra un fallo. Abre el circuito si se supera el threshold. */
  private recordFailure(): void {
    this.failureCount++;
    this.successCount = 0;
    this.lastFailureTime = Date.now();
    if (this.failureCount >= this.failureThreshold) {
      this.transitionToOpen();
    }
    if (this.state === CircuitBreakerState.HALF_OPEN) {
      this.transitionToOpen();
    }
  }

  /**
   * Clasifica si un error HTTP es retryable (transitorio).
   * HTTP 429 (rate limit) y 5xx (server error) son transitorios.
   */
  isRetryable(error: unknown): boolean {
    if (error && typeof error === 'object' && 'status' in error) {
      const status = (error as { status: number }).status;
      if (status === 429) return true;
      if (status >= 500) return true;
    }
    return false;
  }

  /** Estado actual, con transicion automatica de OPEN -> HALF_OPEN si paso el timeout. */
  private getCurrentState(): CircuitBreakerState {
    if (this.state === CircuitBreakerState.OPEN) {
      if (Date.now() - this.lastFailureTime >= this.resetTimeoutMs) {
        this.tryRecovery();
      }
    }
    return this.state;
  }

  private transitionToOpen(): void {
    this.state = CircuitBreakerState.OPEN;
    this.lastStateChange = Date.now();
    process.stderr.write(`[CircuitBreaker] OPEN (fallos=${this.failureCount})\n`);
  }

  private transitionToClosed(): void {
    this.state = CircuitBreakerState.CLOSED;
    this.failureCount = 0;
    this.successCount = 0;
    this.halfOpenCalls = 0;
    this.lastStateChange = Date.now();
    process.stderr.write(`[CircuitBreaker] CLOSED (recuperado)\n`);
  }

  /** Transicion de OPEN -> HALF_OPEN para probar si el servicio se recupero. */
  private tryRecovery(): void {
    this.state = CircuitBreakerState.HALF_OPEN;
    this.halfOpenCalls = 0;
    this.successCount = 0;
    this.lastStateChange = Date.now();
    process.stderr.write(`[CircuitBreaker] HALF_OPEN (probando recuperacion)\n`);
  }

  /** Tiempo restante hasta que el circuit breaker intente recuperarse. */
  private timeUntilRecovery(): number {
    const elapsed = Date.now() - this.lastFailureTime;
    return Math.max(0, this.resetTimeoutMs - elapsed);
  }

  /** Retorna el estado publico del circuit breaker. */
  getState(): CircuitBreakerState {
    return this.getCurrentState();
  }

  /** Retorna estadisticas completas del circuit breaker. */
  getStats(): CircuitBreakerStats {
    return {
      state: this.getCurrentState(),
      failureCount: this.failureCount,
      successCount: this.successCount,
      halfOpenCalls: this.halfOpenCalls,
      lastFailureTime: this.lastFailureTime,
      timeUntilRecoveryMs: this.state === CircuitBreakerState.OPEN ? this.timeUntilRecovery() : 0,
    };
  }
}


// =============================================================================
// Retry with Exponential Backoff + Jitter
// =============================================================================


interface RetryOptions {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
}

/**
 * Ejecuta una funcion con reintentos y backoff exponencial con full jitter.
 *
 * Full jitter: delay = random(0, min(maxDelay, baseDelay * 2^attempt))
 * Esto distribuye reintentos para evitar thundering herd.
 *
 * @param fn - Funcion asincrona a ejecutar
 * @param options - Configuracion de reintentos
 * @param isRetryable - Funcion para determinar si un error es transitorio
 */
async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  options: RetryOptions = { maxRetries: 3, baseDelayMs: 500, maxDelayMs: 30000 },
  isRetryable: (error: unknown) => boolean = () => true,
): Promise<T> {
  let lastError: Error | undefined;

  for (let attempt = 0; attempt <= options.maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;

      // Si el error no es retryable, lanzar inmediatamente
      if (!isRetryable(error)) {
        throw error;
      }

      // Si ya agotamos todos los reintentos, lanzar
      if (attempt >= options.maxRetries) {
        break;
      }

      // Calcular delay con full jitter: random(0, min(maxDelay, baseDelay * 2^attempt))
      const exponentialCap = Math.min(options.maxDelayMs, options.baseDelayMs * Math.pow(2, attempt));
      const delay = Math.random() * exponentialCap;

      const errorMsg = lastError?.message ?? 'UnknownError';
      process.stderr.write(
        `[nowpayments_helper] Retry ${attempt + 1}/${options.maxRetries} ` +
        `en ${Math.round(delay)}ms (${errorMsg})\n`
      );

      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  throw lastError!;
}


// =============================================================================
// IPN Verification Functions
// =============================================================================


/**
 * Ordena recursivamente las claves de un objeto de forma alfabetica.
 * Necesario para generar el hash IPN consistente con el servidor de NOWPayments.
 */
function sortObject(obj: Record<string, unknown>): Record<string, unknown> {
  const sorted: Record<string, unknown> = {};
  const keys = Object.keys(obj).sort();
  for (const key of keys) {
    const value = obj[key];
    if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
      sorted[key] = sortObject(value as Record<string, unknown>);
    } else {
      sorted[key] = value;
    }
  }
  return sorted;
}

/**
 * Verifies the IPN callback signature from NOWPayments.
 *
 * NOWPayments signs IPN callbacks with HMAC-SHA512 using the IPN secret.
 * The payload must be sorted alphabetically by key before hashing.
 *
 * @param ipnSecret - Your IPN secret from the NOWPayments dashboard
 * @param requestBody - The parsed JSON body from the IPN callback
 * @param receivedSignature - The value of the `x-nowpayments-sig` header
 * @returns true if the signature is valid, false otherwise
 */
function verifyIPNSignature(
  ipnSecret: string,
  requestBody: Record<string, unknown>,
  receivedSignature: string,
): boolean {
  const sorted = sortObject(requestBody);
  const jsonString = JSON.stringify(sorted);
  const expectedSignature = createHmac('sha512', ipnSecret)
    .update(jsonString)
    .digest('hex');
  try {
    return timingSafeEqual(
      Buffer.from(expectedSignature, 'hex'),
      Buffer.from(receivedSignature, 'hex'),
    );
  } catch {
    // Si los buffers tienen distinto tamanio, timingSafeEqual lanza un error
    return false;
  }
}


// =============================================================================
// NOWPayments API Error
// =============================================================================


/** Error de la API de NOWPayments con status code y body. */
class NOWPaymentsAPIError extends Error {
  public readonly status: number;
  public readonly body: unknown;

  constructor(status: number, body: unknown) {
    const msg = typeof body === 'object' && body !== null && 'message' in body
      ? (body as { message: string }).message
      : JSON.stringify(body);
    super(`NOWPayments API error ${status}: ${msg}`);
    this.name = 'NOWPaymentsAPIError';
    this.status = status;
    this.body = body;
  }
}


// =============================================================================
// NOWPaymentsHelper Class
// =============================================================================


/**
 * Clase principal: wrapper de alto nivel sobre la API REST de NOWPayments.
 *
 * Todas las operaciones pasan por CircuitBreaker + retry automatico.
 * Soporta Payments, Invoices, Subscriptions, Payouts, Custody y Auth.
 * ZERO dependencias npm — usa fetch nativo + node:crypto.
 */
class NOWPaymentsHelper {
  private readonly apiKey: string;
  private readonly ipnSecret?: string;
  private readonly baseUrl: string;
  private readonly email?: string;
  private readonly password?: string;
  private jwtToken?: string;
  private readonly circuitBreaker: CircuitBreaker;

  constructor(config: NOWPaymentsConfig) {
    this.apiKey = config.apiKey;
    this.ipnSecret = config.ipnSecret;
    this.email = config.email;
    this.password = config.password;
    this.baseUrl = config.sandbox
      ? 'https://api-sandbox.nowpayments.io/v1'
      : 'https://api.nowpayments.io/v1';
    this.circuitBreaker = new CircuitBreaker({
      failureThreshold: 5,
      resetTimeoutMs: 30000,
      halfOpenMax: 3,
    });
  }

  // ---------------------------------------------------------------------------
  // Metodo privado de peticion HTTP
  // ---------------------------------------------------------------------------

  /**
   * Ejecuta una peticion HTTP a la API de NOWPayments con circuit breaker y retry.
   * Incluye x-api-key en todos los requests y Bearer token si requiresAuth es true.
   */
  private async request<T>(
    method: string,
    path: string,
    body?: Record<string, unknown>,
    requiresAuth: boolean = false,
  ): Promise<T> {
    return retryWithBackoff(
      () => this.circuitBreaker.execute(async () => {
        const headers: Record<string, string> = {
          'x-api-key': this.apiKey,
          'Content-Type': 'application/json',
        };

        if (requiresAuth) {
          if (!this.jwtToken) {
            throw new Error('JWT token requerido. Llama a authenticate() primero.');
          }
          headers['Authorization'] = `Bearer ${this.jwtToken}`;
        }

        const url = `${this.baseUrl}${path}`;
        const fetchOptions: RequestInit = {
          method,
          headers,
        };

        if (body && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
          fetchOptions.body = JSON.stringify(body);
        }

        const response = await fetch(url, fetchOptions);

        if (!response.ok) {
          let errorBody: unknown;
          try {
            errorBody = await response.json();
          } catch {
            errorBody = await response.text();
          }
          throw new NOWPaymentsAPIError(response.status, errorBody);
        }

        // Algunos endpoints retornan 204 sin body
        const text = await response.text();
        if (!text) return {} as T;
        return JSON.parse(text) as T;
      }),
      { maxRetries: 3, baseDelayMs: 500, maxDelayMs: 30000 },
      (error) => this.circuitBreaker.isRetryable(error),
    );
  }

  // ---------------------------------------------------------------------------
  // Utilidades generales
  // ---------------------------------------------------------------------------

  /**
   * Returns the API status. Useful as a health check.
   * @returns Object with `message` field, e.g. `{ message: "OK" }`
   */
  async getStatus(): Promise<{ message: string }> {
    return this.request<{ message: string }>('GET', '/status');
  }

  /**
   * Returns the list of available cryptocurrencies for payments.
   * @returns Object with `currencies` array of ticker strings
   */
  async getCurrencies(): Promise<{ currencies: string[] }> {
    return this.request<{ currencies: string[] }>('GET', '/currencies');
  }

  /**
   * Returns the list of coins available for the authenticated merchant.
   * @returns Object with `selectedCurrencies` array
   */
  async getMerchantCoins(): Promise<{ selectedCurrencies: string[] }> {
    return this.request<{ selectedCurrencies: string[] }>('GET', '/merchant/coins');
  }

  /**
   * Returns the minimum payment amount for a currency pair.
   * @param currencyFrom - Source currency (e.g. 'btc')
   * @param currencyTo - Target currency (e.g. 'usd')
   */
  async getMinAmount(currencyFrom: string, currencyTo: string): Promise<{ min_amount: number; currency_from: string; currency_to: string; fiat_equivalent: number }> {
    return this.request('GET', `/min-amount?currency_from=${encodeURIComponent(currencyFrom)}&currency_to=${encodeURIComponent(currencyTo)}`);
  }

  /**
   * Returns an estimated price for a given amount and currency pair.
   * @param amount - Amount to convert
   * @param currencyFrom - Source currency
   * @param currencyTo - Target currency
   */
  async getEstimate(amount: number, currencyFrom: string, currencyTo: string): Promise<{ estimated_amount: number; currency_from: string; currency_to: string }> {
    return this.request('GET', `/estimate?amount=${amount}&currency_from=${encodeURIComponent(currencyFrom)}&currency_to=${encodeURIComponent(currencyTo)}`);
  }

  // ---------------------------------------------------------------------------
  // Pagos (Payments)
  // ---------------------------------------------------------------------------

  /**
   * Creates a new payment.
   * @param params - Payment parameters (price_amount, price_currency, pay_currency required)
   * @returns Payment object with payment_id, pay_address, pay_amount, etc.
   */
  async createPayment(params: PaymentParams): Promise<Record<string, unknown>> {
    return this.request('POST', '/payment', params as unknown as Record<string, unknown>);
  }

  /**
   * Gets the current status of a payment.
   * @param paymentId - The payment ID to query
   */
  async getPaymentStatus(paymentId: number | string): Promise<Record<string, unknown> & { payment_status: PaymentStatus }> {
    return this.request('GET', `/payment/${paymentId}`);
  }

  /**
   * Lists all payments for the authenticated merchant. Requires JWT authentication.
   * @param limit - Number of results per page (default 10)
   * @param page - Page number (default 0)
   */
  async listPayments(limit: number = 10, page: number = 0): Promise<{ data: Record<string, unknown>[]; total: number; limit: number; page: number }> {
    return this.request('GET', `/payment/?limit=${limit}&page=${page}`, undefined, true);
  }

  /**
   * Refreshes the estimated amount for an existing payment.
   * @param paymentId - The payment ID to refresh
   */
  async refreshEstimate(paymentId: number | string): Promise<Record<string, unknown>> {
    return this.request('POST', `/payment/estimate-refresh/${paymentId}`);
  }

  // ---------------------------------------------------------------------------
  // Facturas (Invoices)
  // ---------------------------------------------------------------------------

  /**
   * Creates a new invoice. Invoices provide a hosted payment page.
   * @param params - Invoice parameters (price_amount, price_currency required)
   */
  async createInvoice(params: InvoiceParams): Promise<Record<string, unknown>> {
    return this.request('POST', '/invoice', params as unknown as Record<string, unknown>);
  }

  /**
   * Creates a payment from an existing invoice.
   * @param invoiceId - The invoice ID
   * @param payCurrency - The cryptocurrency to pay with
   * @param opts - Optional additional parameters (payout_address, payout_currency, etc.)
   */
  async createInvoicePayment(
    invoiceId: number | string,
    payCurrency: string,
    opts?: Record<string, unknown>,
  ): Promise<Record<string, unknown>> {
    return this.request('POST', '/invoice-payment', {
      iid: invoiceId,
      pay_currency: payCurrency,
      ...opts,
    });
  }

  // ---------------------------------------------------------------------------
  // Autenticacion (Auth)
  // ---------------------------------------------------------------------------

  /**
   * Authenticates with email and password to obtain a JWT token.
   * Required for endpoints that need Bearer authorization (list payments, payouts, balance).
   * @returns Object with `token` field
   */
  async authenticate(): Promise<{ token: string }> {
    if (!this.email || !this.password) {
      throw new Error('email y password son requeridos para autenticacion JWT.');
    }

    const url = `${this.baseUrl}/auth`;
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: this.email, password: this.password }),
    });

    if (!response.ok) {
      let errorBody: unknown;
      try {
        errorBody = await response.json();
      } catch {
        errorBody = await response.text();
      }
      throw new NOWPaymentsAPIError(response.status, errorBody);
    }

    const data = await response.json() as { token: string };
    this.jwtToken = data.token;
    process.stderr.write(`[nowpayments_helper] Autenticacion exitosa. Token almacenado.\n`);
    return data;
  }

  // ---------------------------------------------------------------------------
  // Planes de Suscripcion (Subscription Plans)
  // ---------------------------------------------------------------------------

  /**
   * Creates a recurring subscription plan.
   * @param params - Plan parameters (title, interval_day, amount, currency required)
   */
  async createPlan(params: SubscriptionPlanParams): Promise<Record<string, unknown>> {
    return this.request('POST', '/subscriptions/plans', params as unknown as Record<string, unknown>, true);
  }

  /**
   * Updates an existing subscription plan.
   * @param planId - The plan ID to update
   * @param params - Fields to update
   */
  async updatePlan(planId: number | string, params: Partial<SubscriptionPlanParams>): Promise<Record<string, unknown>> {
    return this.request('PATCH', `/subscriptions/plans/${planId}`, params as unknown as Record<string, unknown>, true);
  }

  /**
   * Gets details of a subscription plan.
   * @param planId - The plan ID to retrieve
   */
  async getPlan(planId: number | string): Promise<Record<string, unknown>> {
    return this.request('GET', `/subscriptions/plans/${planId}`, undefined, true);
  }

  /**
   * Lists subscription plans.
   * @param limit - Number of results (default 10)
   * @param offset - Offset for pagination (default 0)
   */
  async listPlans(limit: number = 10, offset: number = 0): Promise<{ data: Record<string, unknown>[]; total: number }> {
    return this.request('GET', `/subscriptions/plans?limit=${limit}&offset=${offset}`, undefined, true);
  }

  /**
   * Creates a subscription for a customer email on a given plan.
   * @param planId - The subscription plan ID
   * @param email - Customer email address
   */
  async createSubscription(planId: number | string, email: string): Promise<Record<string, unknown>> {
    return this.request('POST', '/subscriptions', { plan_id: planId, email }, true);
  }

  /**
   * Lists subscriptions with optional filters.
   * @param filters - Optional query filters (limit, offset, plan_id, status, etc.)
   */
  async listSubscriptions(filters?: Record<string, string | number>): Promise<{ data: Record<string, unknown>[]; total: number }> {
    const params = new URLSearchParams();
    if (filters) {
      for (const [key, value] of Object.entries(filters)) {
        params.append(key, String(value));
      }
    }
    const qs = params.toString();
    return this.request('GET', `/subscriptions${qs ? '?' + qs : ''}`, undefined, true);
  }

  // ---------------------------------------------------------------------------
  // Payouts
  // ---------------------------------------------------------------------------

  /**
   * Creates a mass payout (one or more withdrawals). Requires JWT authentication.
   * @param withdrawals - Array of withdrawal items
   * @param ipnCallbackUrl - Optional IPN callback URL for payout notifications
   */
  async createPayout(withdrawals: WithdrawalItem[], ipnCallbackUrl?: string): Promise<Record<string, unknown>> {
    const body: Record<string, unknown> = { withdrawals };
    if (ipnCallbackUrl) {
      body.ipn_callback_url = ipnCallbackUrl;
    }
    return this.request('POST', '/payout', body, true);
  }

  /**
   * Validates a cryptocurrency address.
   * @param address - The wallet address to validate
   * @param currency - The currency ticker (e.g. 'btc', 'eth')
   */
  async validateAddress(address: string, currency: string): Promise<{ isValid: boolean }> {
    return this.request('POST', '/payout/validate-address', { address, currency });
  }

  /**
   * Gets the status of a payout. Requires JWT authentication.
   * @param payoutId - The payout ID to query
   */
  async getPayoutStatus(payoutId: number | string): Promise<Record<string, unknown>> {
    return this.request('GET', `/payout/${payoutId}`, undefined, true);
  }

  /**
   * Lists payouts with optional filters. Requires JWT authentication.
   * @param filters - Optional query filters (limit, offset, status, etc.)
   */
  async listPayouts(filters?: Record<string, string | number>): Promise<{ data: Record<string, unknown>[]; total: number }> {
    const params = new URLSearchParams();
    if (filters) {
      for (const [key, value] of Object.entries(filters)) {
        params.append(key, String(value));
      }
    }
    const qs = params.toString();
    return this.request('GET', `/payout${qs ? '?' + qs : ''}`, undefined, true);
  }

  // ---------------------------------------------------------------------------
  // Custodia (Custody)
  // ---------------------------------------------------------------------------

  /**
   * Gets the balance of all currencies in the merchant account. Requires JWT.
   */
  async getBalance(): Promise<Record<string, unknown>> {
    return this.request('GET', '/balance', undefined, true);
  }

  /**
   * Creates a sub-partner account for custody operations.
   * @param name - Name of the sub-partner
   */
  async createSubPartner(name: string): Promise<Record<string, unknown>> {
    return this.request('POST', '/sub-partner', { name }, true);
  }

  /**
   * Gets the balance of a sub-partner account.
   * @param subPartnerId - The sub-partner ID
   */
  async getSubPartnerBalance(subPartnerId: number | string): Promise<Record<string, unknown>> {
    return this.request('GET', `/sub-partner/balance/${subPartnerId}`, undefined, true);
  }

  /**
   * Creates a deposit address for a sub-partner.
   * @param params - Deposit parameters (sub_partner_id, currency, etc.)
   */
  async createSubPartnerDeposit(params: Record<string, unknown>): Promise<Record<string, unknown>> {
    return this.request('POST', '/sub-partner/deposit', params, true);
  }

  /**
   * Transfers funds between two sub-partner accounts.
   * @param fromId - Source sub-partner ID
   * @param toId - Target sub-partner ID
   * @param currency - Currency ticker
   * @param amount - Amount to transfer
   */
  async transferBetweenSubPartners(
    fromId: number | string,
    toId: number | string,
    currency: string,
    amount: number,
  ): Promise<Record<string, unknown>> {
    return this.request('POST', '/sub-partner/transfer', {
      from: fromId,
      to: toId,
      currency,
      amount,
    }, true);
  }

  /**
   * Withdraws funds from a sub-partner account.
   * @param params - Withdrawal parameters (sub_partner_id, address, currency, amount, etc.)
   */
  async withdrawFromSubPartner(params: Record<string, unknown>): Promise<Record<string, unknown>> {
    return this.request('POST', '/sub-partner/withdraw', params, true);
  }

  /**
   * Lists sub-partner users.
   * @param limit - Number of results (default 10)
   * @param offset - Offset for pagination (default 0)
   */
  async listSubPartnerUsers(limit: number = 10, offset: number = 0): Promise<{ data: Record<string, unknown>[]; total: number }> {
    return this.request('GET', `/sub-partner?limit=${limit}&offset=${offset}`, undefined, true);
  }

  // ---------------------------------------------------------------------------
  // Diagnostico
  // ---------------------------------------------------------------------------

  /**
   * Returns the current circuit breaker statistics.
   */
  getCircuitBreakerStats(): CircuitBreakerStats {
    return this.circuitBreaker.getStats();
  }
}


// =============================================================================
// CLI Handler
// =============================================================================


/** Parsea los argumentos de linea de comandos en un mapa clave-valor. */
function parseArgs(argv: string[]): Record<string, string> {
  const args: Record<string, string> = {};
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg.startsWith('--')) {
      const key = arg.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) {
        args[key] = next;
        i++;
      } else {
        args[key] = 'true';
      }
    }
  }
  return args;
}


/** Imprime el resultado en formato JSON o tabla segun --format. */
function printResult(data: unknown, format: string = 'json'): void {
  if (format === 'table' && typeof data === 'object' && data !== null) {
    // Formato tabla: para objetos simples, imprimir clave=valor
    if (Array.isArray(data)) {
      for (const item of data) {
        if (typeof item === 'object' && item !== null) {
          const cols = Object.entries(item).map(([k, v]) => `${k}=${JSON.stringify(v)}`).join('\t');
          process.stdout.write(cols + '\n');
        } else {
          process.stdout.write(JSON.stringify(item) + '\n');
        }
      }
    } else {
      for (const [key, value] of Object.entries(data)) {
        process.stdout.write(`${key}\t${JSON.stringify(value)}\n`);
      }
    }
  } else {
    process.stdout.write(JSON.stringify(data, null, 2) + '\n');
  }
}


/** Imprime la ayuda del CLI. */
function printHelp(): void {
  const help = `
nowpayments_helper.ts — CLI for NOWPayments API

Global flags:
  --api-key <key>         NOWPayments API key (required for most actions)
  --ipn-secret <secret>   IPN secret (required for verify-ipn)
  --sandbox               Use sandbox API (default: production)
  --email <email>         Email for JWT auth
  --password <password>   Password for JWT auth
  --format <json|table>   Output format (default: json)

Actions:
  status                  Check API status
  currencies              List available cryptocurrencies
  merchant-coins          List merchant's enabled coins
  min-amount              Get minimum amount (--from, --to)
  estimate                Get price estimate (--amount, --from, --to)
  create-payment          Create a payment (--amount, --price-currency, --pay-currency, [--order-id], [--ipn-callback-url])
  payment-status          Get payment status (--payment-id)
  list-payments           List payments (--limit, --page) [requires --email, --password]
  create-invoice          Create an invoice (--amount, --price-currency, [--order-id], [--success-url], [--cancel-url])
  authenticate            Authenticate and obtain JWT (--email, --password)
  create-plan             Create subscription plan (--title, --interval-day, --amount, --currency)
  create-payout           Create a payout (--address, --currency, --amount, [--ipn-callback-url])
  validate-address        Validate a crypto address (--address, --currency)
  verify-ipn              Verify IPN signature (--payload, --signature, --ipn-secret)
  balance                 Get account balance [requires --email, --password]
  diagnostics             Show circuit breaker stats

Examples:
  npx tsx nowpayments_helper.ts --action status --api-key $NP_API_KEY
  npx tsx nowpayments_helper.ts --action create-payment --api-key $NP_API_KEY --amount 100 --price-currency usd --pay-currency btc
  npx tsx nowpayments_helper.ts --action estimate --api-key $NP_API_KEY --amount 50 --from usd --to btc
  npx tsx nowpayments_helper.ts --action verify-ipn --ipn-secret $NP_IPN_SECRET --payload '{"...":"..."}' --signature abc123
  npx tsx nowpayments_helper.ts --action balance --api-key $NP_API_KEY --email me@x.com --password s3cr3t
`.trim();
  process.stdout.write(help + '\n');
}


/** Funcion principal del CLI. Despacha segun --action. */
async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));

  if (args['help'] || !args['action']) {
    printHelp();
    process.exit(args['help'] ? 0 : 1);
  }

  const action = args['action'];
  const format = args['format'] || 'json';

  // Acciones que no requieren api-key
  if (action === 'verify-ipn') {
    const ipnSecret = args['ipn-secret'];
    const payload = args['payload'];
    const signature = args['signature'];
    if (!ipnSecret || !payload || !signature) {
      process.stderr.write('Error: --ipn-secret, --payload, y --signature son requeridos para verify-ipn\n');
      process.exit(1);
    }
    let body: Record<string, unknown>;
    try {
      body = JSON.parse(payload);
    } catch {
      process.stderr.write('Error: --payload debe ser JSON valido\n');
      process.exit(1);
      return;
    }
    const valid = verifyIPNSignature(ipnSecret, body, signature);
    printResult({ valid, signature }, format);
    return;
  }

  // Todas las demas acciones requieren api-key
  const apiKey = args['api-key'];
  if (!apiKey) {
    process.stderr.write('Error: --api-key es requerido\n');
    process.exit(1);
  }

  const helper = new NOWPaymentsHelper({
    apiKey,
    ipnSecret: args['ipn-secret'],
    sandbox: args['sandbox'] === 'true' || args['sandbox'] === undefined && 'sandbox' in args,
    email: args['email'],
    password: args['password'],
  });

  // Autenticar automaticamente si se proporcionan email y password para acciones que lo requieren
  const authRequiredActions = new Set([
    'list-payments', 'create-plan', 'create-payout', 'balance',
  ]);
  if (authRequiredActions.has(action) && args['email'] && args['password']) {
    await helper.authenticate();
  }

  switch (action) {
    case 'status': {
      const result = await helper.getStatus();
      printResult(result, format);
      break;
    }

    case 'currencies': {
      const result = await helper.getCurrencies();
      printResult(result, format);
      break;
    }

    case 'merchant-coins': {
      const result = await helper.getMerchantCoins();
      printResult(result, format);
      break;
    }

    case 'min-amount': {
      const from = args['from'];
      const to = args['to'];
      if (!from || !to) {
        process.stderr.write('Error: --from y --to son requeridos para min-amount\n');
        process.exit(1);
      }
      const result = await helper.getMinAmount(from, to);
      printResult(result, format);
      break;
    }

    case 'estimate': {
      const amount = parseFloat(args['amount']);
      const from = args['from'];
      const to = args['to'];
      if (isNaN(amount) || !from || !to) {
        process.stderr.write('Error: --amount, --from, y --to son requeridos para estimate\n');
        process.exit(1);
      }
      const result = await helper.getEstimate(amount, from, to);
      printResult(result, format);
      break;
    }

    case 'create-payment': {
      const amount = parseFloat(args['amount']);
      const priceCurrency = args['price-currency'];
      const payCurrency = args['pay-currency'];
      if (isNaN(amount) || !priceCurrency || !payCurrency) {
        process.stderr.write('Error: --amount, --price-currency, y --pay-currency son requeridos para create-payment\n');
        process.exit(1);
      }
      const params: PaymentParams = {
        price_amount: amount,
        price_currency: priceCurrency,
        pay_currency: payCurrency,
      };
      if (args['order-id']) params.order_id = args['order-id'];
      if (args['order-description']) params.order_description = args['order-description'];
      if (args['ipn-callback-url']) params.ipn_callback_url = args['ipn-callback-url'];
      if (args['payout-address']) params.payout_address = args['payout-address'];
      if (args['payout-currency']) params.payout_currency = args['payout-currency'];
      if (args['fixed-rate'] === 'true') params.fixed_rate = true;
      if (args['fee-paid-by-user'] === 'true') params.is_fee_paid_by_user = true;
      const result = await helper.createPayment(params);
      printResult(result, format);
      break;
    }

    case 'payment-status': {
      const paymentId = args['payment-id'];
      if (!paymentId) {
        process.stderr.write('Error: --payment-id es requerido para payment-status\n');
        process.exit(1);
      }
      const result = await helper.getPaymentStatus(paymentId);
      printResult(result, format);
      break;
    }

    case 'list-payments': {
      const limit = args['limit'] ? parseInt(args['limit'], 10) : 10;
      const page = args['page'] ? parseInt(args['page'], 10) : 0;
      const result = await helper.listPayments(limit, page);
      printResult(result, format);
      break;
    }

    case 'create-invoice': {
      const amount = parseFloat(args['amount']);
      const priceCurrency = args['price-currency'];
      if (isNaN(amount) || !priceCurrency) {
        process.stderr.write('Error: --amount y --price-currency son requeridos para create-invoice\n');
        process.exit(1);
      }
      const params: InvoiceParams = {
        price_amount: amount,
        price_currency: priceCurrency,
      };
      if (args['order-id']) params.order_id = args['order-id'];
      if (args['order-description']) params.order_description = args['order-description'];
      if (args['ipn-callback-url']) params.ipn_callback_url = args['ipn-callback-url'];
      if (args['success-url']) params.success_url = args['success-url'];
      if (args['cancel-url']) params.cancel_url = args['cancel-url'];
      if (args['partially-paid-url']) params.partially_paid_url = args['partially-paid-url'];
      if (args['fee-paid-by-user'] === 'true') params.is_fee_paid_by_user = true;
      const result = await helper.createInvoice(params);
      printResult(result, format);
      break;
    }

    case 'authenticate': {
      if (!args['email'] || !args['password']) {
        process.stderr.write('Error: --email y --password son requeridos para authenticate\n');
        process.exit(1);
      }
      const result = await helper.authenticate();
      printResult({ authenticated: true, token_preview: result.token.slice(0, 20) + '...' }, format);
      break;
    }

    case 'create-plan': {
      const title = args['title'];
      const intervalDay = parseInt(args['interval-day'], 10);
      const amount = parseFloat(args['amount']);
      const currency = args['currency'];
      if (!title || isNaN(intervalDay) || isNaN(amount) || !currency) {
        process.stderr.write('Error: --title, --interval-day, --amount, y --currency son requeridos para create-plan\n');
        process.exit(1);
      }
      const params: SubscriptionPlanParams = {
        title,
        interval_day: intervalDay,
        amount,
        currency,
      };
      if (args['ipn-callback-url']) params.ipn_callback_url = args['ipn-callback-url'];
      const result = await helper.createPlan(params);
      printResult(result, format);
      break;
    }

    case 'create-payout': {
      const address = args['address'];
      const currency = args['currency'];
      const amount = parseFloat(args['amount']);
      if (!address || !currency || isNaN(amount)) {
        process.stderr.write('Error: --address, --currency, y --amount son requeridos para create-payout\n');
        process.exit(1);
      }
      const withdrawal: WithdrawalItem = { address, currency, amount };
      if (args['extra-id']) withdrawal.extra_id = args['extra-id'];
      const result = await helper.createPayout([withdrawal], args['ipn-callback-url']);
      printResult(result, format);
      break;
    }

    case 'validate-address': {
      const address = args['address'];
      const currency = args['currency'];
      if (!address || !currency) {
        process.stderr.write('Error: --address y --currency son requeridos para validate-address\n');
        process.exit(1);
      }
      const result = await helper.validateAddress(address, currency);
      printResult(result, format);
      break;
    }

    case 'balance': {
      const result = await helper.getBalance();
      printResult(result, format);
      break;
    }

    case 'diagnostics': {
      const stats = helper.getCircuitBreakerStats();
      printResult({
        circuit_breaker: stats,
        config: {
          base_url: apiKey ? '(configured)' : '(missing)',
          sandbox: args['sandbox'] === 'true' || 'sandbox' in args,
          has_ipn_secret: !!args['ipn-secret'],
          has_credentials: !!(args['email'] && args['password']),
        },
      }, format);
      break;
    }

    default: {
      process.stderr.write(`Error: accion desconocida '${action}'. Usa --help para ver acciones disponibles.\n`);
      process.exit(1);
    }
  }
}


// =============================================================================
// Exports + Main Guard
// =============================================================================

export {
  NOWPaymentsHelper,
  CircuitBreaker,
  CircuitBreakerOpenError,
  CircuitBreakerState,
  NOWPaymentsAPIError,
  verifyIPNSignature,
  sortObject,
  retryWithBackoff,
};

export type {
  NOWPaymentsConfig,
  PaymentParams,
  InvoiceParams,
  PayoutParams,
  WithdrawalItem,
  SubscriptionPlanParams,
  PaymentStatus,
  CircuitBreakerOptions,
  CircuitBreakerStats,
  RetryOptions,
};

// Ejecucion CLI: solo si se invoca directamente (no como import)
const isDirectExecution = process.argv[1] &&
  (process.argv[1].endsWith('nowpayments_helper.ts') ||
   process.argv[1].endsWith('nowpayments_helper'));

if (isDirectExecution) {
  main().catch((err: Error) => {
    process.stderr.write(`Error fatal: ${err.message}\n`);
    if (err instanceof NOWPaymentsAPIError) {
      process.stderr.write(`Status: ${err.status}\nBody: ${JSON.stringify(err.body, null, 2)}\n`);
    }
    process.exit(1);
  });
}
