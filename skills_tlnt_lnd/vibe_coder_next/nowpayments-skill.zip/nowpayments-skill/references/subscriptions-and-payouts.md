# Subscriptions & Payouts — Complete Reference

This document covers NOWPayments subscription plans, email-based recurring billing, custodial
auto-charge patterns, JWT authentication, mass payouts, address validation, payout tracking,
and the security requirements that tie everything together.

## Table of Contents

1. [Subscription Plans CRUD](#1-subscription-plans-crud)
2. [Email-Based Subscriptions (Non-Custodial)](#2-email-based-subscriptions-non-custodial)
3. [Custodial Auto-Charge Pattern](#3-custodial-auto-charge-pattern)
4. [JWT Authentication Flow](#4-jwt-authentication-flow)
5. [POST /v1/payout — Mass Payouts](#5-post-v1payout--mass-payouts)
6. [POST /v1/payout/validate-address](#6-post-v1payoutvalidate-address)
7. [Payout Status & Tracking](#7-payout-status--tracking)
8. [Security Requirements for Payouts](#8-security-requirements-for-payouts)
9. [Complete Payout Flow Examples](#9-complete-payout-flow-examples)
10. [Gotchas & Cross-References](#10-gotchas--cross-references)

---

## 1. Subscription Plans CRUD

Plans define the billing template. Every subscription is attached to exactly one plan.

### POST /v1/subscriptions/plans — Create Plan

**Auth:** `x-api-key` header.

| Parameter           | Type   | Required | Description                              |
|---------------------|--------|----------|------------------------------------------|
| `title`             | string | yes      | Human-readable plan name                 |
| `interval_day`      | number | yes      | Billing cycle in days (e.g., 30)         |
| `amount`            | number | yes      | Amount to charge each cycle              |
| `currency`          | string | yes      | Fiat or crypto ticker (`"usd"`, `"btc"`) |
| `ipn_callback_url`  | string | no       | IPN webhook URL                          |
| `success_url`       | string | no       | Redirect after payment                   |
| `cancel_url`        | string | no       | Redirect on cancel                       |
| `partially_paid_url`| string | no       | Redirect on partial payment              |

**Response (201):**

```json
{
  "id": "5638901274", "title": "Pro Monthly", "interval_day": 30,
  "amount": 29.99, "currency": "usd",
  "ipn_callback_url": "https://example.com/ipn/sub",
  "success_url": "https://example.com/success",
  "cancel_url": "https://example.com/cancel",
  "partially_paid_url": "https://example.com/partial",
  "created_at": "2025-06-10T14:22:00.000Z",
  "updated_at": "2025-06-10T14:22:00.000Z"
}
```

### PATCH /v1/subscriptions/plans/:plan-id — Update Plan

Send only changed fields. Updates apply **only to new subscriptions**; existing subscribers
keep original terms.

### GET /v1/subscriptions/plans/:plan-id — Get Plan Details

Returns the full plan object.

### GET /v1/subscriptions/plans — List Plans

Params: `limit` (default 10), `offset` (default 0).

### TypeScript — Plan CRUD

```typescript
import axios from "axios";
const np = axios.create({
  baseURL: "https://api.nowpayments.io/v1",
  headers: { "x-api-key": process.env.NP_API_KEY!, "Content-Type": "application/json" },
});

const create = async () => {
  const { data } = await np.post("/subscriptions/plans", {
    title: "Pro Monthly", interval_day: 30, amount: 29.99, currency: "usd",
    ipn_callback_url: "https://example.com/ipn/sub",
    success_url: "https://example.com/ok", cancel_url: "https://example.com/no",
    partially_paid_url: "https://example.com/partial",
  });
  return data.id as string;
};
const update = (id: string) => np.patch(`/subscriptions/plans/${id}`, { amount: 39.99 });
const get = async (id: string) => console.log((await np.get(`/subscriptions/plans/${id}`)).data);
const list = async () => {
  const { data } = await np.get("/subscriptions/plans", { params: { limit: 50 } });
  data.forEach((p: any) => console.log(`${p.id}: ${p.title} $${p.amount}/${p.interval_day}d`));
};
(async () => { const id = await create(); await get(id); await update(id); await list(); })();
```

---

## 2. Email-Based Subscriptions (Non-Custodial)

The built-in system is **email-driven and non-custodial**. Each cycle, the customer gets an
email with a payment link and must manually pay.

### POST /v1/subscriptions — Create Subscription

| Parameter              | Type   | Required | Description                      |
|------------------------|--------|----------|----------------------------------|
| `subscription_plan_id` | string | yes      | Plan ID to subscribe to          |
| `email`                | string | yes      | Customer email for payment links |

**Response (201):**

```json
{ "id": "sub_8827461032", "subscription_plan_id": "5638901274",
  "email": "customer@example.com", "status": "ACTIVE", "is_active": true }
```

### GET /v1/subscriptions — List Subscriptions

Params: `status` (e.g., `"PAID"`), `subscription_plan_id`, `is_active`, `limit`, `offset`.

### How It Works

At each `interval_day`, NOWPayments emails the customer a payment link. Customer opens it,
chooses crypto, pays. On confirmation, IPN fires to `ipn_callback_url`.

**CRITICAL:** Customer must manually complete each payment. No automatic deduction. If the
customer ignores the email, no funds move.

### Flow

```
Create Plan ──> Create Subscription (plan_id + email)
  ──> Email sent ──> Customer pays ──> IPN fires
  ──> Wait interval_day ──> Email sent again (repeats)
```

### Limitations

- **Churn risk:** Missed emails = missed payments. No retry.
- **Not for must-charge:** Use custodial auto-charge instead.
- **No proration:** Cancel and recreate on plan changes.

---

## 3. Custodial Auto-Charge Pattern

For automated billing without customer action, combine **custody** with scheduled charges.
Customer deposits to custody; your server charges at each interval.

- Custody mode must be enabled (contact support).
- Customer needs a custody sub-partner account with sufficient balance.
- Valid JWT required.

```
Customer deposits ──> Cron triggers ──> Transfer from custody ──> IPN confirms ──> Repeats
```

> See `custody-and-conversions.md` for custody endpoints and sub-partner management.

### TypeScript — Auto-Charge Cron

```typescript
import cron from "node-cron";
import axios from "axios";
const BASE = "https://api.nowpayments.io/v1";

interface Sub { custodyId: string; amount: number; currency: string; }

const getJwt = async () => {
  const { data } = await axios.post(`${BASE}/auth`,
    { email: process.env.NP_EMAIL!, password: process.env.NP_PASSWORD! });
  return data.token as string;
};

const charge = async (jwt: string, s: Sub) =>
  axios.post(`${BASE}/payout`, {
    ipn_callback_url: "https://example.com/ipn/charge",
    withdrawals: [{ address: s.custodyId, currency: s.currency, amount: s.amount,
      fiat_amount: s.amount, fiat_currency: "usd" }],
  }, { headers: { "x-api-key": process.env.NP_API_KEY!, Authorization: `Bearer ${jwt}` } });

cron.schedule("0 0 * * *", async () => {
  const jwt = await getJwt();
  for (const s of await fetchDue()) {
    try { await charge(jwt, s); } catch (e) { console.error(`Failed: ${s.custodyId}`, e); }
  }
});
async function fetchDue(): Promise<Sub[]> { return []; } // your DB query
```

---

## 4. JWT Authentication Flow

Payouts, custody, balances, and payment listing require JWT + API key.

### POST /v1/auth

**Request:** `{"email": "you@domain.com", "password": "your_password"}`
**Response:** `{"token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."}`

| Endpoint Group       | API Key | JWT     |
|----------------------|---------|---------|
| Create payment       | yes     | no      |
| Subscription plans   | yes     | no      |
| Subscriptions        | yes     | no      |
| Payouts              | yes     | **yes** |
| Custody/sub-partners | yes     | **yes** |
| Balance queries      | yes     | **yes** |
| List payments        | yes     | **yes** |

Tokens expire (undocumented). Cache the token; on `401`, re-authenticate and retry.

### TypeScript — Auth Wrapper

```typescript
import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse, AxiosError } from "axios";

class NowPaymentsClient {
  private jwt: string | null = null;
  private http: AxiosInstance;
  constructor(private apiKey: string, private email: string, private password: string) {
    this.http = axios.create({ baseURL: "https://api.nowpayments.io/v1",
      headers: { "x-api-key": apiKey, "Content-Type": "application/json" } });
  }
  async authenticate(): Promise<string> {
    const { data } = await this.http.post("/auth", { email: this.email, password: this.password });
    this.jwt = data.token; return this.jwt;
  }
  async request<T>(cfg: AxiosRequestConfig): Promise<AxiosResponse<T>> {
    if (!this.jwt) await this.authenticate();
    cfg.headers = { ...cfg.headers, Authorization: `Bearer ${this.jwt}` };
    try { return await this.http.request<T>(cfg); } catch (err) {
      if ((err as AxiosError).response?.status === 401) {
        await this.authenticate();
        cfg.headers = { ...cfg.headers, Authorization: `Bearer ${this.jwt}` };
        return await this.http.request<T>(cfg);
      } throw err;
    }
  }
}
const client = new NowPaymentsClient(process.env.NP_API_KEY!, process.env.NP_EMAIL!, process.env.NP_PASSWORD!);
```

### Python — Auth Wrapper

```python
import os, requests
from typing import Any

BASE = "https://api.nowpayments.io/v1"

class NowPaymentsAuth:
    def __init__(self, api_key: str, email: str, password: str) -> None:
        self.api_key, self.email, self.password = api_key, email, password
        self.jwt: str | None = None
    def authenticate(self) -> str:
        r = requests.post(f"{BASE}/auth", json={"email": self.email, "password": self.password},
            headers={"x-api-key": self.api_key})
        r.raise_for_status(); self.jwt = r.json()["token"]; return self.jwt
    def headers(self) -> dict[str, str]:
        if not self.jwt: self.authenticate()
        return {"x-api-key": self.api_key, "Authorization": f"Bearer {self.jwt}",
                "Content-Type": "application/json"}
    def request(self, method: str, path: str, **kw: Any) -> requests.Response:
        r = requests.request(method, f"{BASE}{path}", headers=self.headers(), **kw)
        if r.status_code == 401:
            self.authenticate()
            r = requests.request(method, f"{BASE}{path}", headers=self.headers(), **kw)
        r.raise_for_status(); return r

auth = NowPaymentsAuth(os.environ["NP_API_KEY"], os.environ["NP_EMAIL"], os.environ["NP_PASSWORD"])
```

---

## 5. POST /v1/payout — Mass Payouts

Send crypto to multiple recipients in one call. Auth: `x-api-key` + JWT.

### Request Body

```json
{
  "ipn_callback_url": "https://example.com/payout-ipn",
  "withdrawals": [
    { "address": "TEmGwPeRTPiLFLVfBxXkSP91yc5GMNQhfS", "currency": "trx", "amount": 200 },
    { "address": "0x1EBAE3A2a6E8a0E4e7fC2F703E2f1B2bC460e5D8", "currency": "usdc",
      "amount": 1, "fiat_amount": 100, "fiat_currency": "usd" },
    { "address": "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh", "currency": "btc",
      "amount": 0.005, "extra_id": "payroll-2025-06" }
  ]
}
```

### Withdrawal Item Fields

| Field              | Type   | Required | Description                          |
|--------------------|--------|----------|--------------------------------------|
| `address`          | string | yes      | Destination wallet address           |
| `currency`         | string | yes      | Crypto ticker                        |
| `amount`           | number | yes      | Amount in specified currency         |
| `fiat_amount`      | number | no       | Fiat equivalent for conversion       |
| `fiat_currency`    | string | no       | Fiat ticker (e.g., `"usd"`)         |
| `ipn_callback_url` | string | no       | Per-withdrawal IPN override          |
| `extra_id`         | string | no       | Internal reference (memo, tag, etc.) |

### Response (200)

```json
{
  "id": "payout_batch_90281374",
  "withdrawals": [
    { "id": "w_001", "currency": "trx", "amount": 200, "status": "creating" },
    { "id": "w_002", "currency": "usdc", "amount": 1, "status": "creating" },
    { "id": "w_003", "currency": "btc", "amount": 0.005, "status": "creating" }
  ]
}
```

### Service Fee

**0%** service fee. Only blockchain network fees apply.

### Use Cases

- **Payroll:** Pay contractors in crypto on a schedule.
- **Affiliate payouts:** Distribute commissions to wallets.
- **Airdrops:** Send tokens to community members at scale.
- **Prizes:** Pay contest winners.

---

## 6. POST /v1/payout/validate-address

Auth: `x-api-key` + JWT. Always validate before sending.

**Request:** `{"address": "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh", "currency": "btc"}`
**Response:** `{"isValid": true}`

```typescript
const validate = async (addr: string, cur: string) => {
  const r = await client.request<{ isValid: boolean }>({
    method: "POST", url: "/payout/validate-address", data: { address: addr, currency: cur } });
  if (!r.data.isValid) throw new Error(`Invalid ${cur} address: ${addr}`);
};
```

---

## 7. Payout Status & Tracking

### GET /v1/payout/{payout_id}

Auth: `x-api-key` + JWT. Returns withdrawal statuses and tx hashes.

```json
{ "id": "payout_batch_90281374", "withdrawals": [
    { "id": "w_001", "status": "sending", "hash": "abc123..." },
    { "id": "w_002", "status": "finished", "hash": "def456..." },
    { "id": "w_003", "status": "processing", "hash": null }
] }
```

### GET /v1/payout/ — List Payouts

Params: `status`, `batch_withdrawal_id`, `limit` (default 10), `offset`.

### Status Lifecycle

```
creating ──> processing ──> sending ──> finished
                  │             └──> failed
                  └──> rejected
```

| Status       | Description                            | Action                                    |
|--------------|----------------------------------------|-------------------------------------------|
| `creating`   | Building transactions                  | Wait.                                     |
| `processing` | Preparing and signing                  | Wait.                                     |
| `sending`    | Broadcast, awaiting confirmation       | Check block explorer with `hash`.         |
| `finished`   | Funds delivered. Terminal.             | None.                                     |
| `failed`     | On-chain failure or timeout            | Check address/balance, retry.             |
| `rejected`   | Rejected by NOWPayments               | Check 2FA, whitelist, IP.                 |

---

## 8. Security Requirements for Payouts

All four layers must be active.

1. **API Key** — `x-api-key` header. Dashboard > API Keys.
2. **JWT Token** — `Authorization: Bearer <token>`. From `POST /v1/auth`.
3. **IP Whitelisting** — Server IP in Dashboard > Payouts > IP Whitelist.
4. **2FA Enabled** — Account must have 2FA active. 10 attempts max.

### Withdrawal Address Whitelisting

Every destination must be pre-whitelisted: Dashboard > Payouts > Withdrawal Addresses.
Add address with currency, confirm via email.

### IP Whitelist Changes

Requires email from the registered account address. Not available via API.

### Custody Balance

Payouts draw from custody balance, not incoming payments. Ensure funds first.

### Common 403 Causes

| Cause                    | Fix                                              |
|--------------------------|--------------------------------------------------|
| IP not whitelisted       | Dashboard > Payouts > IP Whitelist               |
| 2FA not enabled          | Dashboard > Security                             |
| JWT expired              | Re-authenticate via `POST /v1/auth`              |
| Address not whitelisted  | Dashboard > Payouts > Withdrawal Addrs           |
| Insufficient balance     | Deposit to custody wallet                        |
| API key invalid          | Regenerate in Dashboard > API Keys               |
| Account under review     | Contact support                                  |

---

## 9. Complete Payout Flow Examples

### TypeScript — Validate, Payout, Poll

Uses `NowPaymentsClient` from [Section 4](#4-jwt-authentication-flow).

```typescript
interface Withdrawal { address: string; currency: string; amount: number; extra_id?: string; }
interface PayoutRes {
  id: string;
  withdrawals: { id: string; status: string; currency: string; amount: number; hash?: string }[];
}

async function runPayout(c: NowPaymentsClient): Promise<void> {
  const ws: Withdrawal[] = [
    { address: "TEmGwPeRTPiLFLVfBxXkSP91yc5GMNQhfS", currency: "trx", amount: 200, extra_id: "emp-001" },
    { address: "0x1EBAE3A2a6E8a0E4e7fC2F703E2f1B2bC460e5D8", currency: "usdc", amount: 50, extra_id: "emp-002" },
  ];
  // Validate
  for (const w of ws) {
    const r = await c.request<{ isValid: boolean }>({
      method: "POST", url: "/payout/validate-address",
      data: { address: w.address, currency: w.currency } });
    if (!r.data.isValid) throw new Error(`Invalid ${w.currency}: ${w.address}`);
  }
  // Create payout
  const { data: p } = await c.request<PayoutRes>({ method: "POST", url: "/payout",
    data: { ipn_callback_url: "https://example.com/payout-ipn", withdrawals: ws } });
  console.log(`Payout ${p.id}: ${p.withdrawals.length} withdrawals`);
  // Poll
  const done = new Set(["finished", "failed", "rejected"]);
  for (let i = 0; i < 60; i++) {
    const { data } = await c.request<PayoutRes>({ method: "GET", url: `/payout/${p.id}` });
    if (data.withdrawals.every((w) => done.has(w.status))) {
      data.withdrawals.forEach((w) => console.log(`  ${w.id}: ${w.status}`));
      return;
    }
    await new Promise((r) => setTimeout(r, 10_000));
  }
  throw new Error("Payout timeout");
}
runPayout(client);
```

### Python — Validate, Payout, Poll

Uses `NowPaymentsAuth` from [Section 4](#4-jwt-authentication-flow).

```python
import time
from dataclasses import dataclass

@dataclass
class Withdrawal:
    address: str; currency: str; amount: float; extra_id: str = ""

def run_payout(a: NowPaymentsAuth) -> None:
    ws = [Withdrawal("TEmGwPeRTPiLFLVfBxXkSP91yc5GMNQhfS", "trx", 200, "emp-001"),
          Withdrawal("0x1EBAE3A2a6E8a0E4e7fC2F703E2f1B2bC460e5D8", "usdc", 50, "emp-002")]
    # Validate
    for w in ws:
        r = a.request("POST", "/payout/validate-address",
            json={"address": w.address, "currency": w.currency})
        if not r.json().get("isValid"): raise ValueError(f"Invalid {w.currency}: {w.address}")
    # Create
    payload = {"ipn_callback_url": "https://example.com/payout-ipn",
        "withdrawals": [{"address": w.address, "currency": w.currency, "amount": w.amount,
                         **({"extra_id": w.extra_id} if w.extra_id else {})} for w in ws]}
    p = a.request("POST", "/payout", json=payload).json()
    print(f"Payout {p['id']}: {len(p['withdrawals'])} withdrawals")
    # Poll
    terminal = {"finished", "failed", "rejected"}
    for i in range(60):
        data = a.request("GET", f"/payout/{p['id']}").json()
        if all(w["status"] in terminal for w in data["withdrawals"]):
            for w in data["withdrawals"]: print(f"  {w['id']}: {w['status']}")
            return
        time.sleep(10)
    raise TimeoutError("Payout timeout")

run_payout(auth)
```

---

## 10. Gotchas & Cross-References

### Key Gotchas

- **Plan changes only affect new subscribers.** Cancel and recreate for existing ones.
- **Email subscriptions have churn risk.** Customer must act each cycle. No retry.
- **Payout funds must be pre-deposited in custody.** Not drawn from incoming payments.
- **All four security layers required.** Missing any one yields `403`.
- **Address validation is free.** Always validate before payouts.

### Cross-References

- **Custody, sub-partners, balances, conversions:** `custody-and-conversions.md`
- **IPN webhooks, payloads, retries:** `webhooks-and-ipn.md`
