# Error Handling & Gotchas — Complete Reference

This document covers every class of error you will encounter when integrating with the NOWPayments API, along with retry strategies, IPN debugging procedures, production hardening checklists, and a comparative analysis of competing crypto payment gateways.

## Table of Contents

1. [HTTP Error Codes](#1-http-error-codes)
2. [Error Response Structure](#2-error-response-structure)
3. [Retryable vs Non-Retryable Errors](#3-retryable-vs-non-retryable-errors)
4. [Exponential Backoff Implementation](#4-exponential-backoff-implementation)
5. [Rate Limiting](#5-rate-limiting)
6. [IPN Debugging Guide](#6-ipn-debugging-guide)
7. [Common Parameter Errors](#7-common-parameter-errors)
8. [Currency-Related Errors](#8-currency-related-errors)
9. [Payout-Specific Errors](#9-payout-specific-errors)
10. [Production Hardening Checklist](#10-production-hardening-checklist)
11. [Monitoring & Alerting](#11-monitoring--alerting)
12. [Comparison with Alternatives](#12-comparison-with-alternatives)

---

## 1. HTTP Error Codes

Every response from the NOWPayments API uses standard HTTP status codes. The table below lists the six codes you will encounter most frequently, their root causes, and the correct remediation.

| Code | Meaning              | Common Causes                                                         | Action                                    |
|------|----------------------|-----------------------------------------------------------------------|-------------------------------------------|
| 400  | Bad Request          | Missing or invalid parameters; payment amount below the minimum       | Fix request parameters before resending   |
| 401  | Unauthorized         | Invalid API key; missing `x-api-key` header; expired JWT token        | Verify the `x-api-key` header value or re-authenticate for a fresh JWT |
| 403  | Forbidden            | IP address not whitelisted; insufficient permissions; 2FA not enabled | Check payout security requirements in the NOWPayments dashboard       |
| 404  | Not Found            | Invalid `payment_id`; incorrect endpoint path                         | Verify the resource ID and the endpoint URL                            |
| 429  | Too Many Requests    | Rate limited by NOWPayments                                          | Back off exponentially and retry                                       |
| 500  | Internal Server Error| NOWPayments infrastructure issue                                     | Retry with exponential backoff; open a support ticket if persistent    |

**Notes:**

- A `401` during payout operations usually means the JWT has expired. Re-authenticate via `POST /v1/auth` and retry once.
- A `403` on payout endpoints has multiple possible causes. Check the payout-specific errors section below for a full breakdown.
- The `429` response does not include a `Retry-After` header. You must implement your own backoff logic.

---

## 2. Error Response Structure

NOWPayments does not use a single, consistent error schema across all endpoints. You must handle at least three distinct response formats.

**Format A — Structured error with code:**

```json
{
  "statusCode": 400,
  "code": "INVALID_PARAM",
  "message": "amount must be a positive number"
}
```

**Format B — Simple message only:**

```json
{
  "message": "Unauthorized"
}
```

**Format C — Array of errors:**

```json
{
  "errors": [
    { "code": "AMOUNT_TOO_LOW", "message": "Amount is less than minimal" },
    { "code": "INVALID_CURRENCY", "message": "Currency is not valid" }
  ]
}
```

**Defensive parsing strategy:** Always check for the presence of `errors` (array), then `code` and `message` (object), then `message` alone (string). Never assume a particular shape. A safe extraction function looks like this:

```typescript
function extractErrorMessage(body: unknown): string {
  if (typeof body === "object" && body !== null) {
    if ("errors" in body && Array.isArray((body as any).errors)) {
      return (body as any).errors.map((e: any) => e.message).join("; ");
    }
    if ("message" in body) return String((body as any).message);
  }
  return "Unknown error";
}
```

---

## 3. Retryable vs Non-Retryable Errors

Not every failed request should be retried. Retrying a `400 Bad Request` wastes time and API quota. The decision tree below classifies every status code.

| Status Code | Retryable | Strategy                                                                 |
|-------------|-----------|--------------------------------------------------------------------------|
| 429         | Yes       | Exponential backoff with full jitter. Start at 1 second, cap at 60 seconds. |
| 500         | Yes       | Exponential backoff. Up to 3 retries.                                    |
| 502         | Yes       | Exponential backoff. Up to 3 retries.                                    |
| 503         | Yes       | Exponential backoff. Up to 3 retries.                                    |
| 504         | Yes       | Exponential backoff. Up to 3 retries.                                    |
| 400         | No        | Fix the request payload. Do not retry.                                   |
| 401         | Conditional | If using JWT: re-authenticate via `POST /v1/auth`, then retry once. If using API key only: do not retry — the key is wrong. |
| 403         | No        | Check security requirements (IP whitelist, 2FA, address whitelist). Do not retry. |
| 404         | No        | Verify the resource ID and endpoint path. Do not retry.                  |

**Decision flow:**

```
Is status 429 or 5xx?
  YES → Retry with exponential backoff (max 3 attempts)
  NO  → Is status 401 AND using JWT auth?
          YES → Re-authenticate, retry once
          NO  → Do NOT retry. Surface the error to the caller.
```

---

## 4. Exponential Backoff Implementation

### TypeScript — With Circuit Breaker

The implementation below combines full-jitter exponential backoff with a three-state circuit breaker. This is the pattern used in `nowpayments_helper.ts`.

```typescript
interface CircuitBreakerState {
  status: "CLOSED" | "OPEN" | "HALF_OPEN";
  failureCount: number;
  lastFailureTime: number;
}

const FAILURE_THRESHOLD = 5;
const RECOVERY_TIMEOUT_MS = 30_000;

const circuitBreaker: CircuitBreakerState = {
  status: "CLOSED",
  failureCount: 0,
  lastFailureTime: 0,
};

function shouldAllowRequest(): boolean {
  if (circuitBreaker.status === "CLOSED") return true;
  if (circuitBreaker.status === "OPEN") {
    const elapsed = Date.now() - circuitBreaker.lastFailureTime;
    if (elapsed >= RECOVERY_TIMEOUT_MS) {
      circuitBreaker.status = "HALF_OPEN";
      return true;
    }
    return false;
  }
  // HALF_OPEN: allow one test request
  return true;
}

function recordSuccess(): void {
  circuitBreaker.status = "CLOSED";
  circuitBreaker.failureCount = 0;
}

function recordFailure(): void {
  circuitBreaker.failureCount += 1;
  circuitBreaker.lastFailureTime = Date.now();
  if (circuitBreaker.failureCount >= FAILURE_THRESHOLD) {
    circuitBreaker.status = "OPEN";
  }
}

async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries = 3,
  baseDelayMs = 1000,
  maxDelayMs = 60_000
): Promise<T> {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    if (!shouldAllowRequest()) {
      throw new Error("Circuit breaker is OPEN — requests blocked");
    }
    try {
      const result = await fn();
      recordSuccess();
      return result;
    } catch (err: any) {
      const status = err?.response?.status;
      if (status && ![429, 500, 502, 503, 504].includes(status)) {
        throw err; // Non-retryable
      }
      recordFailure();
      if (attempt === maxRetries) throw err;
      const cap = Math.min(maxDelayMs, baseDelayMs * Math.pow(2, attempt));
      const delay = Math.random() * cap; // Full jitter
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  throw new Error("Unreachable");
}
```

### Python — Manual Implementation

```python
import random
import time
from typing import Callable, TypeVar

T = TypeVar("T")

def retry_with_backoff(
    fn: Callable[[], T],
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
) -> T:
    for attempt in range(max_retries + 1):
        try:
            return fn()
        except Exception as exc:
            status = getattr(getattr(exc, "response", None), "status_code", None)
            if status and status not in (429, 500, 502, 503, 504):
                raise
            if attempt == max_retries:
                raise
            cap = min(max_delay, base_delay * (2 ** attempt))
            delay = random.uniform(0, cap)
            time.sleep(delay)
    raise RuntimeError("Unreachable")
```

---

## 5. Rate Limiting

NOWPayments does **not** publish explicit rate limit numbers (no documented requests-per-second or requests-per-minute ceiling). The only signal you receive is an HTTP `429 Too Many Requests` response.

**Best practices for staying within limits:**

- **Implement exponential backoff on every 429.** This is mandatory, not optional. See the implementation in Section 4.
- **Cache GET responses that change infrequently.** The `/currencies` and `/merchant/coins` endpoints return data that changes at most once per day. Cache these for at least 15 minutes.
- **Use the estimated price endpoint sparingly.** `/estimate` is the most commonly over-called endpoint. Cache results for 30-60 seconds when displaying prices to users.
- **Batch payout operations.** Use `POST /v1/payout` with multiple payouts in a single mass-payout request rather than issuing individual calls.
- **Never poll payment status faster than every 30 seconds.** The blockchain confirmation cycle makes faster polling pointless. For most chains, 60-second intervals are sufficient.
- **Prefer webhooks over polling.** IPN callbacks eliminate the need for status polling entirely. Reserve polling as a fallback for missed webhooks only.

---

## 6. IPN Debugging Guide

When your IPN (Instant Payment Notification) webhook is not firing or is rejecting valid payloads, walk through this checklist in order.

### Diagnostic Flowchart

```
Step 1: Is the callback URL publicly accessible?
  - Must NOT be localhost, 127.0.0.1, or a private IP
  - Use ngrok or a similar tunnel for local development
  - Verify with: curl -X POST https://your-url.com/webhook

Step 2: Is your firewall or WAF blocking NOWPayments?
  - NOWPayments sends from dynamic IPs
  - Temporarily disable WAF rules to test, then whitelist

Step 3: Does your IPN secret match the dashboard?
  - Dashboard: Store Settings -> Payment Settings -> IPN Secret Key
  - The secret in your code must match exactly (case-sensitive, no trailing spaces)

Step 4: Are you sorting JSON keys alphabetically before HMAC?
  >>> THIS IS THE #1 CAUSE OF SIGNATURE FAILURES <<<
  - NOWPayments signs the payload with keys sorted alphabetically
  - You must sort keys the same way before computing HMAC-SHA512
  - JSON.stringify does NOT guarantee key order — use sorted keys explicitly

Step 5: Does your endpoint return HTTP 200?
  - Any non-200 response triggers NOWPayments to retry delivery
  - Return 200 immediately, then process asynchronously

Step 6: Check IPN logs in the NOWPayments dashboard
  - Dashboard: Payment History -> click payment -> IPN Logs
  - Shows delivery attempts, response codes, and timestamps

Step 7: Test with sandbox
  - Use case: "success" in sandbox to trigger a successful payment flow
  - Use ngrok to expose your local endpoint for testing
```

### Common IPN Errors

| Symptom                           | Cause                                         | Solution                                                              |
|-----------------------------------|-----------------------------------------------|-----------------------------------------------------------------------|
| Webhook never fires               | URL not set or not publicly reachable          | Set the IPN callback URL in dashboard or in the API request           |
| Signature mismatch every time     | JSON keys not sorted before HMAC computation   | Sort keys alphabetically: `JSON.stringify(sortKeys(body))`            |
| Signature mismatch intermittently | Floating-point serialization differences       | Parse and re-serialize numbers consistently before hashing            |
| Webhook fires but returns 500     | Unhandled exception in your handler            | Wrap handler in try/catch; return 200 before processing               |
| Duplicate webhook deliveries      | Your endpoint returned non-200 on first attempt| Implement idempotent processing keyed on `payment_id` + `payment_status` |
| Webhook delayed by minutes        | NOWPayments retry queue backlog                | This is normal during high-traffic periods; ensure idempotent handling |

---

## 7. Common Parameter Errors

Each entry below includes the exact error message returned by the API, the root cause, and the fix.

### "Amount is less than minimal"

- **Cause:** The `price_amount` or `amount` you submitted is below the minimum for that currency pair.
- **Fix:** Call `GET /v1/min-amount?currency_from={fiat}&currency_to={crypto}&fiat_equivalent={amount}` before creating the payment. Use the returned `min_amount` as your floor.

### "Currency is not valid"

- **Cause:** You are passing a currency ticker that is not enabled for your merchant account.
- **Fix:** Use `GET /v1/merchant/coins` (your enabled currencies), not `GET /v1/currencies` (all supported currencies). If the currency is missing from `/merchant/coins`, enable it in the NOWPayments dashboard under Store Settings.

### "Invalid pair"

- **Cause:** NOWPayments cannot convert between the two currencies you specified. Not every combination is supported.
- **Fix:** Call `GET /v1/merchant/coins?currency={from_currency}` to see which target currencies are available for the source currency. Choose a supported pair.

### "This payment was created with another API key"

- **Cause:** You are attempting to query or modify a payment using a different API key than the one that created it.
- **Fix:** Ensure you use the same API key (same `x-api-key` header value) for all operations on a given payment. If you have multiple stores, each store has its own API key.

### "Forbidden" on payout endpoints

- **Cause:** One or more payout security requirements are not met. This is the most common payout error.
- **Fix:** Check all of the following:
  - JWT token is present in the `Authorization: Bearer <token>` header
  - The IP address making the request is whitelisted in dashboard settings
  - Two-factor authentication (2FA) is enabled on your NOWPayments account
  - The destination wallet address is whitelisted in the dashboard
  - Custody is enabled for the payout currency

### "Invalid token"

- **Cause:** The JWT obtained from `POST /v1/auth` has expired or was malformed.
- **Fix:** Re-authenticate by calling `POST /v1/auth` with your email and password. JWT tokens have a limited lifespan. Store the new token and retry the request.

---

## 8. Currency-Related Errors

Currency handling is one of the most frequent sources of confusion in the NOWPayments API because two endpoints return different currency lists.

### /currencies vs /merchant/coins

| Endpoint             | Returns                          | Use Case                                    |
|----------------------|----------------------------------|---------------------------------------------|
| `GET /v1/currencies` | All 350+ currencies NOWPayments supports | Reference only; do not use for payment creation |
| `GET /v1/merchant/coins` | Only currencies enabled for YOUR account | Use this to populate currency selectors in your UI |

If a customer reports "currency not available," the most likely cause is that the currency is not enabled in your merchant dashboard. Navigate to Store Settings and enable it.

### Currencies Requiring extra_id

Some blockchain networks use a shared deposit address with a memo, tag, or destination tag to distinguish recipients. If you omit the `extra_id` for these currencies, **funds may be permanently lost**.

| Currency | extra_id Field | Notes                              |
|----------|----------------|------------------------------------|
| XRP      | Destination Tag | Numeric tag required by most exchanges |
| XLM      | Memo           | Text or numeric memo               |
| EOS      | Memo           | Required for exchange deposits     |
| BNB      | Memo           | Mainnet (BEP2) only; BEP20 does not require memo |

Always display a clear warning to users when they select one of these currencies. Include the `extra_id` value prominently in the payment instructions.

---

## 9. Payout-Specific Errors

Payout operations (`POST /v1/payout`) have stricter security requirements than payment creation. A `403 Forbidden` on payout endpoints can have any of the following causes:

| Cause                          | How to Verify                                              | Fix                                                |
|--------------------------------|------------------------------------------------------------|----------------------------------------------------|
| IP not whitelisted             | Check Dashboard -> Security -> IP Whitelist                | Add your server's public IP to the whitelist       |
| 2FA not enabled                | Check Dashboard -> Security -> Two-Factor Authentication   | Enable 2FA on your NOWPayments account             |
| Address not whitelisted        | Check Dashboard -> Security -> Address Whitelist           | Add the destination address to the whitelist       |
| Custody not enabled            | Check Dashboard -> Custody settings                        | Enable custody for the payout currency             |
| Insufficient balance           | Call `GET /v1/balance` to check available funds            | Deposit funds or reduce the payout amount          |

### Pre-Payout Validation

Always perform these checks before creating a payout to avoid unnecessary errors:

1. **Validate the address:** Call `POST /v1/payout/validate-address` with the destination address and currency. This catches malformed addresses before they cause failures.
2. **Check the balance:** Call `GET /v1/balance` and confirm the available amount exceeds the payout amount plus any network fees.
3. **Verify JWT freshness:** If your JWT is older than 30 minutes, re-authenticate proactively rather than waiting for a `401`.

### JWT Expiration During Payouts

If a JWT expires mid-payout (between creating and verifying a payout), re-authenticate via `POST /v1/auth` and use the new token for subsequent requests. The payout itself is not affected by the token expiration — it continues processing on NOWPayments' side.

---

## 10. Production Hardening Checklist

Use this checklist before going live. Every item is a requirement, not a suggestion.

### Security

- [ ] IPN signature verification is enforced on all webhook endpoints (HMAC-SHA512 with sorted keys)
- [ ] JWT tokens are stored securely in memory or encrypted storage, never logged or exposed in client-side code
- [ ] API keys are loaded from environment variables (`NOWPAYMENTS_API_KEY`), never hardcoded in source files
- [ ] IP whitelisting is configured for all payout operations in the NOWPayments dashboard
- [ ] Two-factor authentication (2FA) is enabled on the NOWPayments account
- [ ] Webhook endpoints validate the request origin and reject unsigned payloads
- [ ] All API communication uses HTTPS exclusively (the SDK enforces this, but verify proxy configurations)

### Reliability

- [ ] Exponential backoff with full jitter is implemented on all API calls (see Section 4)
- [ ] Circuit breaker pattern protects against cascade failures when NOWPayments is down
- [ ] Webhook processing is idempotent — duplicate deliveries are detected and ignored using `payment_id` + `payment_status` as a deduplication key
- [ ] Fallback polling job runs every 5 minutes to catch webhooks that were never delivered or were lost in transit
- [ ] Minimum amount validation is performed via `GET /v1/min-amount` before every payment creation
- [ ] Payment expiration is handled gracefully — expired payments are closed in your system and the user is prompted to create a new one
- [ ] Database transactions wrap payment state updates to prevent partial writes

### Observability

- [ ] All API calls are logged with request method, endpoint, status code, and response time (but not API keys or JWT tokens)
- [ ] Payment status distribution is tracked over time (waiting, confirming, confirmed, sending, partially_paid, finished, failed, refunded, expired)
- [ ] Failed webhook deliveries trigger alerts within 5 minutes
- [ ] Conversion rates and network fees are tracked per currency pair for cost analysis
- [ ] A dashboard displays the payment funnel: created -> waiting -> confirming -> finished, with drop-off rates at each stage

---

## 11. Monitoring & Alerting

### Key Metrics to Track

| Metric                                | Source                         | Granularity     |
|---------------------------------------|--------------------------------|-----------------|
| Payment creation success rate         | API response codes on `POST /v1/payment` | Per minute      |
| Payment completion rate               | Ratio of `finished` to `waiting` payments | Per hour        |
| Average time from `waiting` to `confirmed` | Timestamps on status transitions | Per currency    |
| Webhook delivery success rate         | HTTP 200 responses from your endpoint | Per minute      |
| Partial payment frequency             | Count of `partially_paid` statuses | Per day         |
| Expired payment frequency             | Count of `expired` statuses    | Per day         |
| API response latency (p50, p95, p99)  | Timer on each API call         | Per minute      |
| Circuit breaker state changes         | Circuit breaker event log      | Per occurrence  |

### Alert Thresholds

| Condition                                      | Threshold   | Severity | Action                                              |
|------------------------------------------------|-------------|----------|-----------------------------------------------------|
| Payment creation failure rate                  | > 5%        | High     | Check API key validity; review error logs           |
| Webhook delivery failure rate                  | > 1%        | High     | Verify endpoint health; check IPN secret            |
| API error rate (all endpoints)                 | > 2%        | Medium   | Review error distribution by endpoint and code      |
| Circuit breaker opens                          | Any         | Critical | NOWPayments may be down; activate fallback polling  |
| Expired payment rate                           | > 20%       | Medium   | Payment timeout may be too short; review UX flow    |
| Partial payment rate                           | > 10%       | Low      | Review payment instructions clarity for users       |
| Average confirmation time exceeds 2x baseline  | Per currency| Medium   | Blockchain congestion; inform users of expected delays |

### Tooling Recommendations

- **Grafana + Prometheus:** Best for teams already running Kubernetes. Export metrics via a `/metrics` endpoint and build dashboards for the payment funnel.
- **Datadog:** Best for teams wanting managed infrastructure monitoring. Use custom metrics for payment events and set up monitors for the alert thresholds above.
- **Simple logging + cron:** For smaller deployments, log structured JSON events and run a cron job every 5 minutes that queries the log, computes rates, and sends alerts via email or Slack webhook.

---

## 12. Comparison with Alternatives

### Feature Comparison

| Feature              | NOWPayments         | BitPay             | CoinGate           | BTCPay Server       | Coinbase Commerce    |
|----------------------|---------------------|--------------------|--------------------|---------------------|----------------------|
| Supported coins      | 350+                | 100+               | 70+                | BTC + few alts      | Major coins only     |
| Base fee             | 0.5%                | 1%                 | 1%                 | 0% (self-hosted)    | ~1%                  |
| Custody model        | Non-custodial default | Custodial         | Custodial          | Non-custodial       | Custodial            |
| KYC required         | Minimal             | Strict             | Required           | None                | Varies               |
| Fiat settlement      | Via partners (1.5-2.3%) | Direct bank     | SEPA/PayPal        | No                  | Yes                  |
| Mass payouts         | Yes (0% fee)        | Yes                | Limited            | No                  | No                   |
| Subscriptions        | Email + custodial   | Yes                | Limited            | No                  | No                   |
| White label          | Yes                 | No                 | No                 | Yes (self-hosted)   | No                   |
| Setup complexity     | Low (SaaS)          | Low                | Low                | High (server admin) | Low                  |
| API quality          | Good (REST)         | Good (REST)        | Good (REST)        | Good (REST/GreenField)| Simple (REST)      |
| Sandbox environment  | Yes                 | Yes                | Yes                | Testnet             | No                   |
| Webhook support      | IPN (HMAC-SHA512)   | Yes (signature)    | Yes (token)        | Yes (signature)     | Yes (signature)      |

### When to Choose Each

**Choose NOWPayments when:**
- You need the widest cryptocurrency selection (350+ coins)
- Low transaction fees are a priority (0.5% base)
- You prefer a non-custodial model where funds go directly to your wallet
- You need mass payout capabilities with zero additional fees
- You want white-label payment pages for a branded experience
- KYC requirements need to be minimal for fast onboarding

**Choose BitPay when:**
- Your business requires strict regulatory compliance and KYC
- You need direct fiat settlement to a bank account
- You operate in a jurisdiction where custodial services are preferred or required
- You primarily accept BTC and major altcoins and do not need 350+ options

**Choose BTCPay Server when:**
- You want zero transaction fees and full self-sovereignty
- You are comfortable administering your own server infrastructure
- Your focus is Bitcoin (and a small number of altcoins via plugins)
- You need maximum privacy and do not want any third-party involvement
- You want a fully open-source solution with no vendor lock-in

**Choose CoinGate when:**
- Your customer base is primarily European and SEPA settlement is important
- You need PayPal as an alternative settlement method
- You want a straightforward managed service with moderate coin support

**Choose Coinbase Commerce when:**
- Your users are already in the Coinbase ecosystem
- You want the simplest possible integration with minimal configuration
- You only need to accept major cryptocurrencies (BTC, ETH, LTC, USDC, and a few others)
- Brand recognition and trust from the Coinbase name matters for your audience
