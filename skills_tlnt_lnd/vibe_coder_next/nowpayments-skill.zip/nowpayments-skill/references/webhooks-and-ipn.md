# Webhooks & IPN — Complete Reference

NOWPayments uses an Instant Payment Notification (IPN) system to push real-time
payment status updates to your server via HTTP POST webhooks. This document
covers payload structure, cryptographic signature verification in every major
language, retry behavior, processing patterns, and debugging.

---

## Table of Contents

1. [IPN Payload Structure](#1-ipn-payload-structure)
2. [HMAC-SHA512 Signature Verification](#2-hmac-sha512-signature-verification)
3. [Node.js / TypeScript Verification](#3-nodejs--typescript-verification)
4. [Next.js App Router Handler](#4-nextjs-app-router-handler)
5. [Python Verification](#5-python-verification)
6. [PHP Verification](#6-php-verification)
7. [Cloudflare Workers Handler](#7-cloudflare-workers-handler)
8. [Status Transition Event Map](#8-status-transition-event-map)
9. [Webhook Retry Configuration](#9-webhook-retry-configuration)
10. [Server Requirements](#10-server-requirements)
11. [Queue-Based Processing Pattern](#11-queue-based-processing-pattern)
12. [Local Development](#12-local-development)
13. [IPN Debugging Checklist](#13-ipn-debugging-checklist)

---

## 1. IPN Payload Structure

NOWPayments delivers a JSON body to your `ipn_callback_url` on every payment
status change. The following is a complete real-world example:

```json
{
  "payment_id": 5077125051,
  "payment_status": "finished",
  "pay_address": "0xd1cDE08A07cD25adEbEd35c3867a59228C09B606",
  "price_amount": 170,
  "price_currency": "usd",
  "pay_amount": 155.38559757,
  "actually_paid": 155.38559757,
  "pay_currency": "mana",
  "order_id": "2",
  "order_description": "Apple Macbook Pro 2019 x 1",
  "purchase_id": "6084744717",
  "created_at": "2021-04-12T14:22:54.942Z",
  "updated_at": "2021-04-12T14:23:06.244Z",
  "outcome_amount": 1131.7812095,
  "outcome_currency": "trx"
}
```

### Field Descriptions

| Field | Type | Description |
|---|---|---|
| `payment_id` | `number` | Unique identifier for the payment on NOWPayments. |
| `payment_status` | `string` | Current status. One of: `waiting`, `confirming`, `confirmed`, `sending`, `partially_paid`, `finished`, `failed`, `refunded`, `expired`. |
| `pay_address` | `string` | Blockchain address the customer sends funds to. |
| `price_amount` | `number` | Original price you specified when creating the payment (fiat or crypto). |
| `price_currency` | `string` | Currency of `price_amount` (e.g., `usd`, `eur`, `btc`). |
| `pay_amount` | `number` | Amount the customer is expected to pay in `pay_currency`. |
| `actually_paid` | `number` | Amount the customer actually sent on-chain. Compare with `pay_amount` to detect underpayment. |
| `pay_currency` | `string` | Cryptocurrency the customer pays with (e.g., `btc`, `eth`, `mana`). |
| `order_id` | `string` | Your internal order reference, passed at payment creation. |
| `order_description` | `string` | Human-readable description, passed at payment creation. |
| `purchase_id` | `string` | NOWPayments purchase group ID (for multi-payment invoices). |
| `created_at` | `string` | ISO 8601 timestamp when the payment was created. |
| `updated_at` | `string` | ISO 8601 timestamp of the most recent status change. |
| `outcome_amount` | `number` | Amount you receive after conversion, in `outcome_currency`. |
| `outcome_currency` | `string` | Currency you receive payouts in (configured in your account). |

---

## 2. HMAC-SHA512 Signature Verification

Every IPN request includes the header `x-nowpayments-sig` containing an
HMAC-SHA512 hex digest. You **must** verify this signature to confirm the
request genuinely originated from NOWPayments and was not tampered with.

### Algorithm (Step-by-Step)

1. **Parse the JSON body** into a native object/dictionary.
2. **Sort all keys alphabetically**, recursing into any nested objects so that
   every level is sorted.
3. **Re-serialize** the sorted object back to a compact JSON string (no extra
   whitespace).
4. **Compute HMAC-SHA512** over that JSON string using your **IPN Secret Key**
   (found in the NOWPayments dashboard under Store Settings).
5. **Compare** the resulting hex digest with the value of `x-nowpayments-sig`.

### Why Sorted Keys?

JSON does not guarantee key ordering. Different languages, serializers, and
even different versions of the same serializer may output keys in different
orders. By sorting keys before computing the HMAC, both NOWPayments and your
server arrive at the same canonical string regardless of how the JSON was
originally serialized over the wire.

### Timing-Safe Comparison

Always use a constant-time comparison function when checking the signature
against the header value. A naive `===` or `==` comparison leaks information
about which bytes match via response timing, enabling a timing attack where an
adversary iteratively discovers the correct signature one character at a time.

Language-specific constant-time functions:

| Language | Function |
|---|---|
| Node.js | `crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b))` |
| Python | `hmac.compare_digest(a, b)` |
| PHP | `hash_equals($a, $b)` |
| Go | `subtle.ConstantTimeCompare([]byte(a), []byte(b))` |
| Ruby | `ActiveSupport::SecurityUtils.secure_compare(a, b)` |

---

## 3. Node.js / TypeScript Verification

### Standalone Verification Function

```typescript
import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Sort all keys in an object recursively and return a new object.
 */
function sortObject(obj: Record<string, unknown>): Record<string, unknown> {
  return Object.keys(obj)
    .sort()
    .reduce<Record<string, unknown>>((sorted, key) => {
      const value = obj[key];
      if (value !== null && typeof value === "object" && !Array.isArray(value)) {
        sorted[key] = sortObject(value as Record<string, unknown>);
      } else {
        sorted[key] = value;
      }
      return sorted;
    }, {});
}

/**
 * Verify a NOWPayments IPN signature.
 *
 * @param body     - Parsed JSON body from the webhook request.
 * @param sigHeader - Value of the `x-nowpayments-sig` header.
 * @param secret   - Your IPN Secret Key from the NOWPayments dashboard.
 * @returns `true` if the signature is valid.
 */
export function verifyNowPaymentsSignature(
  body: Record<string, unknown>,
  sigHeader: string,
  secret: string,
): boolean {
  const sorted = sortObject(body);
  const jsonString = JSON.stringify(sorted);
  const digest = createHmac("sha512", secret).update(jsonString).digest("hex");

  const sigBuffer = Buffer.from(sigHeader, "hex");
  const digestBuffer = Buffer.from(digest, "hex");

  if (sigBuffer.length !== digestBuffer.length) {
    return false;
  }

  return timingSafeEqual(sigBuffer, digestBuffer);
}
```

### Express.js Production Handler

```typescript
import express, { Request, Response } from "express";
import { verifyNowPaymentsSignature } from "./verify";

const app = express();

// express.json() is fine here — unlike Stripe, NOWPayments computes the
// signature on sorted-key JSON, not on the raw bytes. Parsing and
// re-serializing with sorted keys produces the same canonical form.
app.use(express.json());

const IPN_SECRET = process.env.NOWPAYMENTS_IPN_SECRET!;

app.post("/api/webhooks/nowpayments", (req: Request, res: Response) => {
  const signature = req.headers["x-nowpayments-sig"] as string | undefined;

  if (!signature) {
    res.status(401).json({ error: "Missing signature header" });
    return;
  }

  if (!verifyNowPaymentsSignature(req.body, signature, IPN_SECRET)) {
    res.status(401).json({ error: "Invalid signature" });
    return;
  }

  const { payment_id, payment_status, order_id, actually_paid, pay_amount } =
    req.body;

  switch (payment_status) {
    case "finished":
      console.log(`Payment ${payment_id} for order ${order_id} completed.`);
      // Fulfill the order in your database.
      break;
    case "partially_paid":
      console.log(
        `Payment ${payment_id} underpaid: ${actually_paid} / ${pay_amount}`,
      );
      // Notify customer of underpayment.
      break;
    case "failed":
      console.log(`Payment ${payment_id} failed.`);
      // Mark order as failed; prompt customer to retry.
      break;
    case "expired":
      console.log(`Payment ${payment_id} expired.`);
      // Release reserved inventory.
      break;
    default:
      console.log(`Payment ${payment_id} status: ${payment_status}`);
  }

  // Always return 200 to acknowledge receipt.
  res.status(200).json({ received: true });
});

app.listen(3000, () => console.log("Webhook server listening on :3000"));
```

---

## 4. Next.js App Router Handler

Create the file `app/api/webhooks/nowpayments/route.ts`:

```typescript
import { createHmac, timingSafeEqual } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";

const IPN_SECRET = process.env.NOWPAYMENTS_IPN_SECRET!;

function sortObject(obj: Record<string, unknown>): Record<string, unknown> {
  return Object.keys(obj)
    .sort()
    .reduce<Record<string, unknown>>((sorted, key) => {
      const value = obj[key];
      if (value !== null && typeof value === "object" && !Array.isArray(value)) {
        sorted[key] = sortObject(value as Record<string, unknown>);
      } else {
        sorted[key] = value;
      }
      return sorted;
    }, {});
}

function verifySignature(
  body: Record<string, unknown>,
  sigHeader: string,
  secret: string,
): boolean {
  const sorted = sortObject(body);
  const jsonString = JSON.stringify(sorted);
  const digest = createHmac("sha512", secret).update(jsonString).digest("hex");

  const sigBuf = Buffer.from(sigHeader, "hex");
  const digestBuf = Buffer.from(digest, "hex");

  if (sigBuf.length !== digestBuf.length) return false;
  return timingSafeEqual(sigBuf, digestBuf);
}

export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  let body: Record<string, unknown>;

  try {
    body = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const signature = req.headers.get("x-nowpayments-sig");
  if (!signature || !verifySignature(body, signature, IPN_SECRET)) {
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  const status = body.payment_status as string;
  const paymentId = body.payment_id;
  const orderId = body.order_id;

  switch (status) {
    case "finished":
      // Fulfill the order.
      console.log(`Order ${orderId}: payment ${paymentId} finished.`);
      break;
    case "partially_paid":
      console.log(`Order ${orderId}: payment ${paymentId} partially paid.`);
      break;
    case "failed":
    case "expired":
      console.log(`Order ${orderId}: payment ${paymentId} ${status}.`);
      break;
    default:
      console.log(`Order ${orderId}: payment ${paymentId} -> ${status}`);
  }

  // Return 200 immediately so NOWPayments does not retry.
  return NextResponse.json({ received: true }, { status: 200 });
}
```

---

## 5. Python Verification

### Flask Handler

```python
import hashlib
import hmac
import json
import os
from collections import OrderedDict

from flask import Flask, abort, jsonify, request

app = Flask(__name__)

IPN_SECRET = os.environ["NOWPAYMENTS_IPN_SECRET"]


def sort_object(obj):
    """Recursively sort dictionary keys."""
    if isinstance(obj, dict):
        return OrderedDict(
            (k, sort_object(v)) for k, v in sorted(obj.items())
        )
    return obj


def verify_signature(body: dict, sig_header: str, secret: str) -> bool:
    """Verify the HMAC-SHA512 signature from NOWPayments."""
    sorted_body = sort_object(body)
    json_string = json.dumps(sorted_body, separators=(",", ":"))
    digest = hmac.new(
        secret.encode("utf-8"),
        json_string.encode("utf-8"),
        hashlib.sha512,
    ).hexdigest()
    return hmac.compare_digest(digest, sig_header)


@app.route("/api/webhooks/nowpayments", methods=["POST"])
def nowpayments_webhook():
    body = request.get_json(force=True)
    sig_header = request.headers.get("x-nowpayments-sig", "")

    if not verify_signature(body, sig_header, IPN_SECRET):
        abort(401, description="Invalid signature")

    payment_status = body.get("payment_status")
    payment_id = body.get("payment_id")
    order_id = body.get("order_id")

    if payment_status == "finished":
        app.logger.info("Payment %s for order %s completed.", payment_id, order_id)
        # Fulfill the order.
    elif payment_status == "partially_paid":
        app.logger.warning("Payment %s underpaid.", payment_id)
    elif payment_status in ("failed", "expired"):
        app.logger.error("Payment %s %s.", payment_id, payment_status)

    return jsonify(received=True), 200


if __name__ == "__main__":
    app.run(port=3000)
```

### FastAPI Handler with Pydantic Model

```python
import hashlib
import hmac
import json
import os
from collections import OrderedDict
from typing import Optional

from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel

app = FastAPI()

IPN_SECRET = os.environ["NOWPAYMENTS_IPN_SECRET"]


class NowPaymentsIPN(BaseModel):
    payment_id: int
    payment_status: str
    pay_address: str
    price_amount: float
    price_currency: str
    pay_amount: float
    actually_paid: float
    pay_currency: str
    order_id: Optional[str] = None
    order_description: Optional[str] = None
    purchase_id: Optional[str] = None
    created_at: str
    updated_at: str
    outcome_amount: float
    outcome_currency: str


def sort_object(obj):
    if isinstance(obj, dict):
        return OrderedDict(
            (k, sort_object(v)) for k, v in sorted(obj.items())
        )
    return obj


def verify_signature(body: dict, sig_header: str, secret: str) -> bool:
    sorted_body = sort_object(body)
    # separators=(",", ":") produces compact JSON with no spaces.
    json_string = json.dumps(sorted_body, separators=(",", ":"))
    digest = hmac.new(
        secret.encode("utf-8"),
        json_string.encode("utf-8"),
        hashlib.sha512,
    ).hexdigest()
    return hmac.compare_digest(digest, sig_header)


@app.post("/api/webhooks/nowpayments")
async def nowpayments_webhook(
    request: Request,
    x_nowpayments_sig: Optional[str] = Header(None),
):
    raw_body = await request.body()
    body = json.loads(raw_body)

    if not x_nowpayments_sig or not verify_signature(body, x_nowpayments_sig, IPN_SECRET):
        raise HTTPException(status_code=401, detail="Invalid signature")

    ipn = NowPaymentsIPN(**body)

    if ipn.payment_status == "finished":
        # Fulfill the order.
        pass
    elif ipn.payment_status == "partially_paid":
        # Notify customer.
        pass
    elif ipn.payment_status in ("failed", "expired"):
        # Handle failure.
        pass

    return {"received": True}
```

---

## 6. PHP Verification

```php
<?php

declare(strict_types=1);

$ipnSecret = getenv('NOWPAYMENTS_IPN_SECRET');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$rawBody = file_get_contents('php://input');
$body = json_decode($rawBody, true);

if ($body === null) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

$sigHeader = $_SERVER['HTTP_X_NOWPAYMENTS_SIG'] ?? '';

/**
 * Recursively sort an associative array by key.
 */
function sortRecursive(array &$array): void
{
    ksort($array);
    foreach ($array as &$value) {
        if (is_array($value)) {
            sortRecursive($value);
        }
    }
}

sortRecursive($body);

$jsonString = json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
$digest = hash_hmac('sha512', $jsonString, $ipnSecret);

if (!hash_equals($digest, $sigHeader)) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid signature']);
    exit;
}

// Signature is valid — process the payment.
$paymentStatus = $body['payment_status'];
$paymentId = $body['payment_id'];
$orderId = $body['order_id'] ?? null;

switch ($paymentStatus) {
    case 'finished':
        // Fulfill the order.
        error_log("Payment {$paymentId} for order {$orderId} completed.");
        break;
    case 'partially_paid':
        error_log("Payment {$paymentId} underpaid.");
        break;
    case 'failed':
    case 'expired':
        error_log("Payment {$paymentId} {$paymentStatus}.");
        break;
}

http_response_code(200);
echo json_encode(['received' => true]);
```

---

## 7. Cloudflare Workers Handler

```typescript
interface Env {
  NOWPAYMENTS_IPN_SECRET: string;
}

function sortObject(obj: Record<string, unknown>): Record<string, unknown> {
  return Object.keys(obj)
    .sort()
    .reduce<Record<string, unknown>>((sorted, key) => {
      const value = obj[key];
      if (value !== null && typeof value === "object" && !Array.isArray(value)) {
        sorted[key] = sortObject(value as Record<string, unknown>);
      } else {
        sorted[key] = value;
      }
      return sorted;
    }, {});
}

async function verifySignature(
  body: Record<string, unknown>,
  sigHeader: string,
  secret: string,
): Promise<boolean> {
  const encoder = new TextEncoder();

  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-512" },
    false,
    ["sign"],
  );

  const sorted = sortObject(body);
  const jsonString = JSON.stringify(sorted);

  const signatureArrayBuffer = await crypto.subtle.sign(
    "HMAC",
    key,
    encoder.encode(jsonString),
  );

  const digest = Array.from(new Uint8Array(signatureArrayBuffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  // Cloudflare Workers do not expose timingSafeEqual, so compare via
  // a second HMAC to achieve constant-time equality.
  const compareKey = await crypto.subtle.importKey(
    "raw",
    crypto.getRandomValues(new Uint8Array(32)),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );

  const mac1 = await crypto.subtle.sign("HMAC", compareKey, encoder.encode(digest));
  const mac2 = await crypto.subtle.sign("HMAC", compareKey, encoder.encode(sigHeader));

  const arr1 = new Uint8Array(mac1);
  const arr2 = new Uint8Array(mac2);
  if (arr1.length !== arr2.length) return false;

  let result = 0;
  for (let i = 0; i < arr1.length; i++) {
    result |= arr1[i] ^ arr2[i];
  }
  return result === 0;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method !== "POST") {
      return new Response("Method Not Allowed", { status: 405 });
    }

    const rawBody = await request.text();
    let body: Record<string, unknown>;
    try {
      body = JSON.parse(rawBody);
    } catch {
      return Response.json({ error: "Invalid JSON" }, { status: 400 });
    }

    const signature = request.headers.get("x-nowpayments-sig") ?? "";
    const valid = await verifySignature(body, signature, env.NOWPAYMENTS_IPN_SECRET);

    if (!valid) {
      return Response.json({ error: "Invalid signature" }, { status: 401 });
    }

    const status = body.payment_status as string;
    const paymentId = body.payment_id;

    console.log(`NOWPayments IPN: payment ${paymentId} -> ${status}`);

    // Delegate processing to a Durable Object, Queue, or external service
    // to avoid blocking the response.

    return Response.json({ received: true }, { status: 200 });
  },
};
```

---

## 8. Status Transition Event Map

The following transitions trigger IPN callbacks to your endpoint:

| From | To | Meaning |
|---|---|---|
| `waiting` | `confirming` | Transaction detected on the blockchain. Awaiting confirmations. |
| `confirming` | `confirmed` | Required number of blockchain confirmations reached. |
| `confirmed` | `sending` | NOWPayments is converting/exchanging funds to your payout currency. |
| `sending` | `finished` | Conversion complete. Funds credited to your NOWPayments balance. |
| `waiting` | `partially_paid` | Customer sent less than the required amount (underpayment). |
| `waiting` | `expired` | No transaction detected within the 24-hour payment window. |
| *(any)* | `failed` | An error occurred during processing (e.g., exchange failure). |
| `finished` | `refunded` | Payment was refunded via the NOWPayments refund flow. |

### Important Notes

- **Not all transitions are guaranteed.** Network issues, temporary outages, or
  edge cases in blockchain processing can cause intermediate callbacks to be
  skipped. For example, you might receive `waiting` followed directly by
  `finished` without seeing `confirming`, `confirmed`, or `sending`.
- **Design your handler to be idempotent.** You may receive the same status
  callback more than once due to retries. Use `payment_id` plus
  `payment_status` as a deduplication key.
- **The `finished` status is the only reliable indicator of successful
  payment.** Do not fulfill orders on `confirmed` — the exchange step can
  still fail.
- **`partially_paid` does not automatically resolve.** The customer must send
  the remaining amount or you must handle refunds manually.

---

## 9. Webhook Retry Configuration

Configure retries in the NOWPayments dashboard:

**Dashboard path:** Store Settings → Instant Payment Notifications

| Setting | Description | Example |
|---|---|---|
| **IPN Callback URL** | Your publicly accessible endpoint. | `https://api.example.com/webhooks/nowpayments` |
| **IPN Secret** | Shared secret for HMAC-SHA512 signing. | *(auto-generated or custom)* |
| **Timeout** | Interval between retry attempts. | `1` (minute) |
| **Number of recurrent notifications** | How many additional attempts after the first delivery fails. | `3` |

### Retry Behavior Example

With Timeout = 1 minute and Recurrent = 3:

1. **T+0s** — First delivery attempt.
2. **T+1m** — First retry (if first attempt failed).
3. **T+2m** — Second retry.
4. **T+3m** — Third and final retry.

A delivery attempt is considered **failed** if:
- Your server does not respond within the timeout window.
- Your server responds with any HTTP status code other than `200`.
- The connection is refused or times out at the TCP level.

After all retry attempts are exhausted, NOWPayments stops trying. There is no
manual re-delivery button in the dashboard. Use the
`GET /v1/payment/{payment_id}` API endpoint to poll for missed updates.

---

## 10. Server Requirements

Your webhook endpoint must meet the following requirements for reliable IPN
delivery:

### Network Accessibility

- **Must be publicly accessible.** `localhost`, `127.0.0.1`, and private IP
  ranges (`10.x.x.x`, `192.168.x.x`, `172.16-31.x.x`) will not work.
- **URL must start with `http://` or `https://`.** HTTPS is strongly
  recommended and should be considered mandatory for production.
- **Firewall rules** must allow inbound HTTPS connections from NOWPayments
  server IPs. If you use Cloudflare, AWS WAF, or similar services, add
  NOWPayments IPs to your allowlist. Contact NOWPayments support for the
  current IP ranges if your firewall requires explicit whitelisting.

### Request Format

- Must accept **HTTP POST** requests.
- Must parse a **JSON body** (`Content-Type: application/json`).
- Must return **HTTP 200** on successful receipt. Any other status code
  triggers a retry.

### Hosting Considerations

- **Shared hosting** (e.g., budget cPanel hosts) is unreliable for webhooks
  because cold-start times, `.htaccess` redirects, and PHP-FPM pool limits
  frequently cause timeouts or 5xx responses.
- **Serverless functions** (AWS Lambda, Vercel, Cloudflare Workers) are
  well-suited because they scale automatically and cold starts are typically
  under the timeout window.
- **Dedicated servers and VPS** work well when properly configured with a
  reverse proxy (nginx, Caddy) that keeps connections alive.

---

## 11. Queue-Based Processing Pattern

For production systems, decouple webhook receipt from business logic processing.
This prevents timeout failures when your processing involves database writes,
third-party API calls, or email sends.

### Pattern Overview

```
NOWPayments → Your Endpoint → Validate Signature → Enqueue Job → Return 200
                                                         ↓
                                                   Worker Process
                                                         ↓
                                              Fulfill Order / Send Email
```

### TypeScript Example (In-Memory Queue)

```typescript
import express, { Request, Response } from "express";
import { verifyNowPaymentsSignature } from "./verify";

interface WebhookJob {
  id: string;
  payload: Record<string, unknown>;
  receivedAt: Date;
}

const jobQueue: WebhookJob[] = [];
const IPN_SECRET = process.env.NOWPAYMENTS_IPN_SECRET!;

const app = express();
app.use(express.json());

app.post("/api/webhooks/nowpayments", (req: Request, res: Response) => {
  const signature = req.headers["x-nowpayments-sig"] as string | undefined;

  if (!signature || !verifyNowPaymentsSignature(req.body, signature, IPN_SECRET)) {
    res.status(401).json({ error: "Invalid signature" });
    return;
  }

  // Enqueue and return immediately.
  jobQueue.push({
    id: `${req.body.payment_id}-${req.body.payment_status}`,
    payload: req.body,
    receivedAt: new Date(),
  });

  res.status(200).json({ received: true });
});

// Worker: process jobs sequentially.
async function processQueue(): Promise<void> {
  while (true) {
    const job = jobQueue.shift();
    if (!job) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      continue;
    }

    try {
      const { payment_id, payment_status, order_id } = job.payload as {
        payment_id: number;
        payment_status: string;
        order_id: string;
      };

      console.log(`Processing: payment ${payment_id}, status ${payment_status}`);

      if (payment_status === "finished") {
        // Database update, email notification, inventory adjustment, etc.
        console.log(`Fulfilling order ${order_id}`);
      }
    } catch (err) {
      console.error(`Failed to process job ${job.id}:`, err);
      // Re-enqueue for retry or move to dead-letter queue.
      jobQueue.push(job);
    }
  }
}

app.listen(3000, () => {
  console.log("Webhook server listening on :3000");
  processQueue();
});
```

### Production Recommendations

The in-memory queue above is suitable for development and demonstration only.
For production, use a dedicated job queue:

| Solution | Best For |
|---|---|
| **BullMQ** (Redis-backed) | Node.js applications with existing Redis infrastructure. |
| **Celery** (Redis or RabbitMQ) | Python applications. |
| **AWS SQS + Lambda** | Serverless architectures on AWS. |
| **Google Cloud Tasks** | Serverless architectures on GCP. |
| **pg-boss** (PostgreSQL-backed) | Applications already using PostgreSQL that want to avoid adding Redis. |

---

## 12. Local Development

Testing webhooks locally requires exposing your local server to the public
internet so NOWPayments can reach it.

### ngrok

The most common approach is to use ngrok to create a secure tunnel:

```bash
# Start your local server.
npm run dev   # Listening on http://localhost:3000

# In a separate terminal, create a tunnel.
ngrok http 3000
```

ngrok outputs a public URL like `https://a1b2c3d4.ngrok-free.app`. Use this as
your `ipn_callback_url` when creating payments:

```bash
curl -X POST "https://api-sandbox.nowpayments.io/v1/payment" \
  -H "x-api-key: YOUR_SANDBOX_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "price_amount": 100,
    "price_currency": "usd",
    "pay_currency": "btc",
    "ipn_callback_url": "https://a1b2c3d4.ngrok-free.app/api/webhooks/nowpayments",
    "order_id": "test-001",
    "case": "success"
  }'
```

### Sandbox `case` Parameter

The NOWPayments sandbox API accepts a `case` parameter that forces a specific
payment outcome, letting you test every status transition without real funds:

| Case Value | Simulated Result |
|---|---|
| `success` | Payment proceeds through all statuses to `finished`. |
| `partially_paid` | Payment ends with `partially_paid` status. |
| `failed` | Payment transitions to `failed`. |
| `expired` | Payment transitions to `expired` after timeout. |

### API Mocking Tools

For fully offline development or CI pipelines where external calls are
undesirable:

- **Mockoon** — Desktop and CLI tool for mocking REST APIs. Pre-built
  NOWPayments API mocks are available in the Mockoon templates at
  `mockoon.com/mock-samples/`. Import the template and run locally.
- **WireMock** — Java-based mock server with a cloud offering. Search the
  WireMock mock API catalog for NOWPayments to get a ready-made stub.

### End-to-End Testing Flow

Combine all three tools for a complete local testing workflow:

1. Start your application locally.
2. Run `ngrok http 3000` to get a public URL.
3. Create a sandbox payment with `ipn_callback_url` set to your ngrok URL and
   `case` set to the scenario you want to test.
4. Watch your local logs as NOWPayments sends IPN callbacks through ngrok to
   your local server.

---

## 13. IPN Debugging Checklist

When your webhook is not receiving callbacks or signature verification is
failing, work through this checklist in order:

### Step 1: Is the URL Publicly Accessible?

```bash
# From an external machine (not your local network):
curl -X POST https://your-domain.com/api/webhooks/nowpayments \
  -H "Content-Type: application/json" \
  -d '{"test": true}'
```

If this times out or returns a connection error, the URL is not reachable.
Common causes: DNS not propagated, server not running, wrong port.

### Step 2: Is a Firewall or WAF Blocking Requests?

Check your firewall rules, Cloudflare settings, AWS Security Groups, or hosting
provider's built-in firewall. NOWPayments servers may be blocked by:

- Rate limiting rules that flag rapid POST requests.
- Bot protection or challenge pages (Cloudflare "Under Attack Mode").
- Geographic IP blocking if NOWPayments servers are in a blocked region.

### Step 3: Is the IPN Secret Correct?

Go to the NOWPayments dashboard → Store Settings → Instant Payment
Notifications. Copy the IPN Secret and compare it byte-for-byte with the value
in your environment variables. Watch for:

- Trailing whitespace or newlines (common when pasting into `.env` files).
- Using the API key instead of the IPN secret (they are different values).
- Using the production secret against the sandbox API or vice versa.

### Step 4: Are Keys Sorted Before HMAC Computation?

This is the **number one cause of signature verification failures**. Verify
that your code:

- Recursively sorts nested objects, not just top-level keys.
- Uses a stable sort (alphabetical by key name).
- Re-serializes to compact JSON with no extra whitespace.

Test by logging both the expected digest and the received `x-nowpayments-sig`
header. If they differ, log the sorted JSON string and compare it against the
canonical form.

### Step 5: Is the Response HTTP 200?

NOWPayments treats any non-200 response as a failure and schedules a retry.
Check your server logs for:

- Uncaught exceptions that result in 500 responses.
- Authentication middleware that rejects the request before it reaches your
  handler (e.g., JWT validation on all routes).
- Redirects (301, 302) — NOWPayments does not follow redirects.

### Step 6: Check Dashboard IPN Logs

The NOWPayments dashboard provides an IPN delivery log under Store Settings →
Instant Payment Notifications. This log shows:

- Each delivery attempt with timestamp.
- The HTTP response code your server returned.
- Whether the delivery was marked as successful.

If the log shows no delivery attempts for a payment, the issue is with payment
creation (the `ipn_callback_url` was not set or was invalid).

### Quick-Reference Diagnostic Commands

```bash
# Verify DNS resolution.
dig +short your-domain.com

# Test TCP connectivity to your server.
nc -zv your-domain.com 443

# Send a simulated IPN payload to your endpoint.
curl -X POST https://your-domain.com/api/webhooks/nowpayments \
  -H "Content-Type: application/json" \
  -H "x-nowpayments-sig: test-signature" \
  -d '{"payment_id":123,"payment_status":"finished"}'

# Check your server logs for the request.
# Expected: 401 (signature mismatch) — confirms the endpoint is reachable
# and processing requests.
```
