# SDKs & Plugins — Complete Reference

This document covers every official SDK, community SDK, embeddable widget, payment button, Point of Sale tool, and e-commerce platform plugin available for the NOWPayments crypto payment gateway.

## Table of Contents

1. [Official JS SDK — Status & Limitations](#1-official-js-sdk--status--limitations)
2. [Official PHP SDK](#2-official-php-sdk)
3. [Community SDK: nowpayments-api (Node.js/TS)](#3-community-sdk-nowpayments-api-nodejsts)
4. [Community SDK: nowpayments (Python)](#4-community-sdk-nowpayments-python)
5. [Community SDK: nowpay (Python)](#5-community-sdk-nowpay-python)
6. [Community SDK: Laravel (PHP)](#6-community-sdk-laravel-php)
7. [Community SDK: Go](#7-community-sdk-go)
8. [Community SDK: Vendure Plugin](#8-community-sdk-vendure-plugin)
9. [SDK Selection Decision Tree](#9-sdk-selection-decision-tree)
10. [Payment Widget](#10-payment-widget)
11. [Donation Widget](#11-donation-widget)
12. [Payment & Donation Buttons](#12-payment--donation-buttons)
13. [Point of Sale (PoS)](#13-point-of-sale-pos)
14. [E-Commerce Platform Plugins](#14-e-commerce-platform-plugins)

---

## 1. Official JS SDK — Status & Limitations

**Package:** `@nowpaymentsio/nowpayments-api-js` (npm) | **Version:** v1.0.5

### Known Problems

- **Outdated dependencies:** Pins `axios@0.21.1` (SSRF vulnerability CVE-2021-3749) and `typescript@4.2` (three major versions behind).
- **Missing auth/JWT methods:** No `auth()` or JWT token management. Authenticated endpoints (mass payments, balance, custody) are unreachable.
- **Webpack v5 incompatibility:** CommonJS build breaks tree-shaking and produces polyfill errors in Webpack 5+ / Vite without manual aliasing.
- **Appears abandoned:** Open GitHub issues with no maintainer response since mid-2023. No releases since v1.0.5.

### Mass Payments SDK

**Package:** `@nowpaymentsio/nowpayments-mass-payments-api-js` v1.0.6 — the only official JS package with JWT support (includes `auth()` and `getBalance()`). Same dependency staleness issues.

### Recommendation

Do **not** use either official JS SDK for new projects. Use direct `fetch` calls or the community SDK by MrCerber (Section 3).

If forced to use the official SDK in a legacy codebase, wrap every call with timeout and fallback logic:

```typescript
import NowPaymentsApi from "@nowpaymentsio/nowpayments-api-js";

const api = new NowPaymentsApi({ apiKey: process.env.NOWPAYMENTS_API_KEY! });

async function safeGetCurrencies(): Promise<string[]> {
  try {
    const response = await Promise.race([
      api.getCurrencies(),
      new Promise((_, reject) => setTimeout(() => reject(new Error("Timeout")), 10_000)),
    ]);
    return response.currencies;
  } catch {
    const res = await fetch("https://api.nowpayments.io/v1/currencies", {
      headers: { "x-api-key": process.env.NOWPAYMENTS_API_KEY! },
    });
    return (await res.json()).currencies;
  }
}
```

---

## 2. Official PHP SDK

**Package:** `nowpayments-api-php` | **Repo:** `github.com/NowPaymentsIO/nowpayments-api-php` | **Stars:** ~17

Basic PHP wrapper covering status checks, currency listing, minimum amounts, payment creation, and status retrieval. No Composer package — install via Git clone:

```bash
git clone https://github.com/NowPaymentsIO/nowpayments-api-php.git
```

Provides a single `NOWPaymentsAPI` class. Does not include JWT auth, IPN signature verification, or mass payments. For Laravel projects, use the community package by prevailexcel (Section 6) instead.

---

## 3. Community SDK: nowpayments-api (Node.js/TS)

**Author:** MrCerber | **Package:** `nowpayments-api` (npm)

```bash
npm i nowpayments-api
```

**Key advantages:** WebSocket support for real-time payment updates without polling, full TypeScript types, ESM + CJS dual output compatible with Webpack 5/Vite/Node 18+, complete API coverage.

```typescript
import { NowPaymentsApi } from "nowpayments-api";

const client = new NowPaymentsApi({ apiKey: process.env.NOWPAYMENTS_API_KEY! });

const payment = await client.createPayment({
  price_amount: 49.99,
  price_currency: "usd",
  pay_currency: "btc",
  order_id: "order-7821",
  ipn_callback_url: "https://your-api.com/webhooks/nowpayments",
});
console.log(`Pay ${payment.pay_amount} BTC to ${payment.pay_address}`);

// Real-time updates via WebSocket
client.on("payment_update", (update) => {
  if (update.payment_status === "finished") {
    console.log("Payment confirmed — fulfilling order");
  }
});
await client.connect();
```

**When to use:** You need real-time payment updates without implementing your own polling loop or IPN webhook endpoint. The WebSocket connection eliminates repeated `GET /v1/payment/{id}` calls and reduces fulfillment latency.

---

## 4. Community SDK: nowpayments (Python)

**Author:** Ventura94 | **Package:** `nowpayments` (PyPI)

```bash
pip install nowpayments
```

**Key advantages:** Clean Pythonic wrapper with methods mapping directly to API endpoints, separate `NOWPaymentsSandbox` class for testing, full type hints.

```python
from nowpayments import NOWPayments

client = NOWPayments(api_key="your-api-key")
# For sandbox: from nowpayments import NOWPaymentsSandbox

payment = client.create_payment(
    price_amount=100.00,
    price_currency="usd",
    pay_currency="eth",
    order_id="order-9931",
    ipn_callback_url="https://your-api.com/webhooks/nowpayments",
)
print(f"Send {payment['pay_amount']} ETH to {payment['pay_address']}")

invoice = client.create_invoice(
    price_amount=250.00, price_currency="usd", order_id="inv-4412",
)
print(f"Invoice URL: {invoice['invoice_url']}")

status = client.get_payment_status(payment_id=payment["payment_id"])
```

**When to use:** Python projects needing a clean, well-typed integration covering the full payment and invoice lifecycle. The sandbox class makes testing straightforward.

---

## 5. Community SDK: nowpay (Python)

**Author:** NikolaiSch | **Package:** `nowpay` (PyPI)

```bash
pip install nowpay
```

**Key advantage:** Built-in IPN handler with a Flask-based webhook server. Instead of building your own endpoint, the SDK provides a decorator-based system for receiving and verifying IPN callbacks.

```python
from nowpay import NOWPayments
from nowpay.ipn import IPNHandler

client = NOWPayments(api_key="your-api-key")

payment = client.create_payment(
    price_amount=50.00, price_currency="usd",
    pay_currency="ltc", order_id="order-2244",
    ipn_callback_url="https://your-server.com/ipn",
)

handler = IPNHandler(ipn_secret="your-ipn-secret", port=8080)

@handler.on_payment
def handle_payment(data):
    if data["payment_status"] == "finished":
        activate_subscription(data["order_id"])

handler.run()  # Starts Flask server, blocking
```

**When to use:** You need built-in webhook handling without setting up a separate web framework. Ideal for scripts, bots, and lightweight services.

---

## 6. Community SDK: Laravel (PHP)

**Author:** prevailexcel | **Package:** `prevailexcel/laravel-nowpayments` (Packagist) | **Installs:** 5,596

```bash
composer require prevailexcel/laravel-nowpayments
```

**Features:** Laravel service provider with auto-discovery, built-in dashboard route for payment history, payment logging with configurable migration, IPN signature verification middleware, support for payments/invoices/mass payouts.

**Config:**

```bash
php artisan vendor:publish --provider="PrevailExcel\NowPayments\NowPaymentsServiceProvider"
```

```env
NOWPAYMENTS_API_KEY=your-api-key
NOWPAYMENTS_IPN_SECRET=your-ipn-secret
NOWPAYMENTS_SANDBOX=false
```

**Usage:**

```php
use PrevailExcel\NowPayments\Facades\NowPayments;

$payment = NowPayments::createPayment([
    'price_amount' => 99.99,
    'price_currency' => 'usd',
    'pay_currency' => 'btc',
    'order_id' => 'order-3371',
    'ipn_callback_url' => route('nowpayments.ipn'),
]);

$status = NowPayments::getPaymentStatus($payment['payment_id']);
```

---

## 7. Community SDK: Go

**Author:** matm | **Package:** `github.com/matm/go-nowpayments`

```bash
go get github.com/matm/go-nowpayments
```

Typed Go client covering payments, invoices, currencies, and status queries. CLI tool included (`go install github.com/matm/go-nowpayments/cmd/nowpayments@latest`). Sandbox support via environment variable or client option.

```go
package main

import (
    "context"
    "fmt"
    np "github.com/matm/go-nowpayments/pkg"
)

func main() {
    client := np.NewClient("your-api-key")
    payment, _ := client.CreatePayment(context.Background(), &np.PaymentRequest{
        PriceAmount: 75.00, PriceCurrency: "usd",
        PayCurrency: "btc", OrderID: "order-5519",
    })
    fmt.Printf("Send %s %s to %s\n", payment.PayAmount, payment.PayCurrency, payment.PayAddress)
}
```

---

## 8. Community SDK: Vendure Plugin

**Package:** `vendure-plugin-nowpayments` (npm)

```bash
npm i vendure-plugin-nowpayments
```

Full Vendure e-commerce integration: payment creation, status sync, webhook processing, and order state transitions.

```typescript
import { NowPaymentsPlugin } from "vendure-plugin-nowpayments";

export const config: VendureConfig = {
  plugins: [
    NowPaymentsPlugin.init({
      apiKey: process.env.NOWPAYMENTS_API_KEY!,
      ipnSecret: process.env.NOWPAYMENTS_IPN_SECRET!,
      sandboxMode: process.env.NODE_ENV !== "production",
    }),
  ],
};
```

Once configured, NOWPayments appears as a payment method in the Vendure Admin UI. The plugin manages the full lifecycle through Vendure's order state machine.

---

## 9. SDK Selection Decision Tree

**TypeScript / Node.js**
- **Recommended:** Direct `fetch` calls against the REST API — full control, no dependency risk, complete coverage.
- **Need real-time updates?** `nowpayments-api` by MrCerber (Section 3) for WebSocket support.
- **Legacy codebase on official SDK?** Keep it, add timeout wrappers and direct-fetch fallback (Section 1).

**Python**
- **Clean API wrapper:** `nowpayments` by Ventura94 (Section 4) — well-typed, sandbox class, full surface.
- **Built-in IPN handling:** `nowpay` by NikolaiSch (Section 5) — Flask-based webhook server included.

**PHP / Laravel**
- **Laravel:** `prevailexcel/laravel-nowpayments` (Section 6) — dashboard, logging, middleware, 5,500+ installs.
- **Plain PHP:** Official PHP SDK (Section 2) or direct cURL.

**Go**
- `matm/go-nowpayments` (Section 7) — includes CLI tool for quick testing.

**E-Commerce Platform**
- Official plugin for your platform (Section 14): WooCommerce, Shopify, PrestaShop, Magento 2, WHMCS, OpenCart, Zen Cart, Ecwid, Shopware.
- Vendure: `vendure-plugin-nowpayments` (Section 8).

**Any Language / Custom Stack**
- REST API directly with your HTTP client (`fetch`, `requests`, `curl`, `http.Client`). See payments-and-invoices and webhooks-and-ipn references.

---

## 10. Payment Widget

Embeddable iframe for completing crypto payments directly on your website without redirecting to an external page.

**Capabilities:**
- 350+ cryptocurrencies supported.
- Customizable fields: customer name, email, phone, shipping address.
- Real-time fiat-to-crypto conversion display.
- No redirections — entire payment flow within the widget.
- Responsive design adapting to container width.

**Setup:** Dashboard → **Payment Tools** → **Create Payment Link** → configure amount/currency → select **Widget** → copy embed code.

```html
<iframe
  src="https://nowpayments.io/embeds/payment-widget?amount=49.99&currency=usd&apiKey=YOUR_API_KEY"
  style="width: 100%; min-height: 500px; border: none; overflow: hidden;"
  scrolling="no"
  allow="payment"
  title="NOWPayments Crypto Payment Widget">
</iframe>
```

The widget posts status updates via `postMessage` for parent-page integration.

---

## 11. Donation Widget

Purpose-built widget for accepting crypto donations from content creators, open-source projects, and nonprofits.

**Capabilities:**
- Multi-currency — donors choose their preferred cryptocurrency.
- Customizable branding: logo, colors, donation message.
- Preset amounts with custom amount option.
- Embeddable via iframe or shareable direct link.

**Demo:** `https://nowpayments.io/demo/donation`

**Popular use cases:** Twitch streamers, open-source projects (alongside GitHub Sponsors), nonprofits and charities, independent journalists.

**Setup:** Dashboard → **Payment Tools** → **Donation Widget** → configure branding and accepted currencies → copy embed code or shareable link.

---

## 12. Payment & Donation Buttons

Simple HTML buttons triggering the NOWPayments checkout flow — the lowest-effort integration option.

- One-click setup from the dashboard, generates standalone HTML snippet.
- No JavaScript SDK required.
- Customizable text, amount, and currency.
- Redirects to hosted checkout on click.
- Works on any HTML-capable site (static, WordPress, Squarespace).

```html
<a href="https://nowpayments.io/payment/?api_key=YOUR_API_KEY&price_amount=29.99&price_currency=usd"
   target="_blank" rel="noopener noreferrer"
   style="display:inline-block;padding:12px 24px;background:#1A1A2E;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;">
  Pay with Crypto
</a>

<a href="https://nowpayments.io/donation/?api_key=YOUR_API_KEY"
   target="_blank" rel="noopener noreferrer"
   style="display:inline-block;padding:12px 24px;background:#0F3460;color:#fff;text-decoration:none;border-radius:6px;font-weight:600;">
  Donate with Crypto
</a>
```

For advanced customization, generate buttons via **Payment Tools** → **Payment Button** or **Donation Button**.

---

## 13. Point of Sale (PoS)

Web-based POS interface generating QR codes for in-person crypto payments.

- Runs in any modern browser — tablets, phones, laptops.
- Unique QR code per transaction with exact amount and destination address.
- 350+ cryptocurrencies, real-time confirmation display.
- No dedicated POS hardware required.
- Transaction history in the dashboard.

**Use cases:** Retail counters (tablet), restaurants (table QR), events and conferences (registration/merch), pop-up shops (phone only).

**Setup:** Dashboard → **Payment Tools** → **Point of Sale** → enter amount → select fiat currency → present QR to customer. The screen updates in real time as blockchain confirmations arrive.

---

## 14. E-Commerce Platform Plugins

### Official Plugins

| Platform | Install Method | Notes |
|----------|---------------|-------|
| **WooCommerce** | WordPress plugin directory or ZIP upload | Most popular integration. Crypto gateway in checkout with automatic IPN order updates. |
| **Shopify** | Shopify App Store | Payment provider with checkout redirect and fulfillment callbacks. |
| **PrestaShop** | Addons marketplace or module upload | Back-office config panel. Supports 1.7+ and 8.x. |
| **Magento 2** | Composer or upload | Admin config, order status mapping, multi-store support. |
| **WHMCS** | Upload to `/modules/gateways/` | Hosting/domain billing. Maps WHMCS invoice states to payment statuses. |
| **OpenCart** | Extension upload | Payment extension for 3.x and 4.x. |
| **Zen Cart** | Module upload | Payment module for 1.5.7+. |
| **Ecwid** | Ecwid App Market | No-code setup through Ecwid control panel. |
| **Shopware** | Shopware Store or plugin upload | Shopware 6 payment handler integration. |

### Community Plugins

| Platform | Package / Repository | Notes |
|----------|---------------------|-------|
| **Vendure** | `vendure-plugin-nowpayments` (npm) | Full payment method integration (see Section 8). |
| **Pretix** | `github.com/luvnft/pretix-nowpayments` | Event ticketing — crypto checkout for conferences, concerts, workshops. |
| **Paymenter** | Built-in support | Hosting billing panel with native NOWPayments gateway for VPS/hosting provisioning. |

### Plugin Selection

- **WordPress/WooCommerce:** Official WooCommerce plugin — most mature and widely deployed.
- **Shopify:** Official app — no custom code required.
- **Custom e-commerce (Node.js):** Vendure plugin, or REST API directly.
- **Event ticketing:** Pretix community plugin.
- **Hosting billing:** Paymenter built-in support or WHMCS official plugin.
