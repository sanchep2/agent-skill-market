# Sandbox & Testing — Complete Reference

This document covers the NOWPayments sandbox environment, simulated payment
flows using the `case` parameter, local development tooling, integration test
patterns, and CI/CD pipeline configuration for automated testing against the
sandbox API.

---

## Table of Contents

1. [Sandbox Environment Setup](#1-sandbox-environment-setup)
2. [Sandbox vs Production Differences](#2-sandbox-vs-production-differences)
3. [The `case` Parameter](#3-the-case-parameter)
4. [Testing Success Flow](#4-testing-success-flow)
5. [Testing Partial Payment Flow](#5-testing-partial-payment-flow)
6. [Testing Failure Flow](#6-testing-failure-flow)
7. [IPN Testing in Sandbox](#7-ipn-testing-in-sandbox)
8. [Local Development with ngrok](#8-local-development-with-ngrok)
9. [Local Development with Mockoon](#9-local-development-with-mockoon)
10. [Integration Test Patterns](#10-integration-test-patterns)
11. [CI/CD Pipeline](#11-cicd-pipeline)

---

## 1. Sandbox Environment Setup

NOWPayments provides a fully isolated sandbox environment that mirrors the
production API without requiring real cryptocurrency or fiat funds. The sandbox
uses NOWPayments' own payment simulation engine rather than blockchain testnets,
so there is no need to acquire testnet tokens or configure wallet software.

### Getting Started

1. Create a **separate** sandbox account at
   `https://account-sandbox.nowpayments.io`. This is not the same as your
   production account — credentials, API keys, and IPN secrets are completely
   independent.

2. Generate a sandbox API key from the sandbox dashboard under
   **Store Settings → API Keys**.

3. Set the sandbox base URL in your application configuration:

```
https://api-sandbox.nowpayments.io/v1
```

4. Configure a sandbox IPN secret under **Store Settings → IPN** in the sandbox
   dashboard. This secret is used to verify webhook signatures and is separate
   from your production IPN secret.

### Environment Variables

```bash
NOWPAYMENTS_API_KEY=your-sandbox-api-key
NOWPAYMENTS_API_URL=https://api-sandbox.nowpayments.io/v1
NOWPAYMENTS_IPN_SECRET=your-sandbox-ipn-secret
```

Never hard-code these values. Load them from environment variables or a secrets
manager so you can switch between sandbox and production without code changes.

---

## 2. Sandbox vs Production Differences

The sandbox mirrors the production API surface — same endpoints, same request
and response schemas, same currency list. The key differences are in how
payments are processed and how IPN callbacks are delivered.

| Feature | Sandbox | Production |
|---------|---------|------------|
| API URL | `api-sandbox.nowpayments.io/v1` | `api.nowpayments.io/v1` |
| Account portal | `account-sandbox.nowpayments.io` | `account.nowpayments.io` |
| Real funds required | No | Yes |
| `case` parameter | Supported (controls simulation) | Ignored |
| IPN callbacks | Simulated (fire automatically) | Real (triggered by blockchain) |
| Blockchain transactions | Simulated | Real on-chain |
| Supported currencies | Same list as production | Same list |
| Rate limits | Relaxed (higher thresholds) | Standard (see API docs) |
| API key | Sandbox-specific | Production-specific |
| IPN secret | Sandbox-specific | Production-specific |

### Important Notes

- The sandbox IPN secret is **not** the same as your production IPN secret.
  If you copy your production IPN secret into sandbox configuration, signature
  verification will fail silently.
- Sandbox payments never touch a real blockchain. The `pay_address` field in
  sandbox responses is a simulated address — do not send real funds to it.
- Exchange rate estimates in sandbox may differ slightly from production since
  sandbox does not query live market data in real time.

---

## 3. The `case` Parameter

The `case` parameter is a sandbox-only field that controls the simulated outcome
of a payment. It is accepted on the `POST /v1/payment` endpoint and tells the
sandbox which status transition sequence to simulate.

### Supported Values

| Value | Simulation |
|-------|------------|
| `"success"` | `waiting` → `confirming` → `confirmed` → `sending` → `finished` |
| `"partially_paid"` | `waiting` → `partially_paid` |
| `"failure"` | `waiting` → `failed` |

When a payment is created with a `case` value, the sandbox automatically fires
IPN callbacks for **each** status transition in the sequence. This allows you to
test your webhook handler against the full lifecycle without waiting for real
blockchain confirmations.

If you omit the `case` parameter in sandbox, the payment stays in `waiting`
status indefinitely and no IPN callbacks fire.

In production, the `case` parameter is silently ignored — it has no effect on
real payment processing.

### TypeScript Example

```typescript
const SANDBOX_URL = "https://api-sandbox.nowpayments.io/v1";
const API_KEY = process.env.NOWPAYMENTS_API_KEY!;

type PaymentCase = "success" | "partially_paid" | "failure";

async function createSandboxPayment(case_value: PaymentCase) {
  const response = await fetch(`${SANDBOX_URL}/payment`, {
    method: "POST",
    headers: {
      "x-api-key": API_KEY,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      price_amount: 100,
      price_currency: "usd",
      pay_currency: "btc",
      order_id: `test-${Date.now()}`,
      order_description: "Sandbox test payment",
      ipn_callback_url: process.env.IPN_CALLBACK_URL,
      case: case_value,
    }),
  });

  if (!response.ok) {
    throw new Error(`Payment creation failed: ${response.status}`);
  }

  return response.json();
}

// Create one payment for each case to exercise all handlers
await createSandboxPayment("success");
await createSandboxPayment("partially_paid");
await createSandboxPayment("failure");
```

### Verifying Webhook Handler Coverage

After creating payments with each `case` value, confirm that your webhook
handler correctly processes every status it receives. Your handler should log
or record each status transition and take the appropriate action:

- `waiting` — payment created, awaiting customer deposit
- `confirming` — deposit detected, awaiting blockchain confirmations
- `confirmed` — sufficient confirmations received
- `sending` — funds being converted and sent to your payout address
- `finished` — payment complete, order should be fulfilled
- `partially_paid` — customer sent less than the required amount
- `failed` — payment failed (timeout, network error, or other issue)

---

## 4. Testing Success Flow

The success flow is the most common path. Creating a payment with
`case: "success"` triggers the full happy-path sequence and fires IPN callbacks
for each transition.

### Step-by-Step

1. Create a payment with `case: "success"`.
2. The sandbox fires IPN callbacks in order:
   `waiting` → `confirming` → `confirmed` → `sending` → `finished`.
3. Your webhook handler should process each callback and update the order status.
4. On the `finished` callback, verify that `actually_paid >= pay_amount` and
   mark the order as paid.

### Complete Test Example

```typescript
import { describe, it, expect, vi, beforeEach } from "vitest";
import crypto from "node:crypto";

const SANDBOX_URL = "https://api-sandbox.nowpayments.io/v1";
const API_KEY = process.env.NOWPAYMENTS_API_KEY!;
const IPN_SECRET = process.env.NOWPAYMENTS_IPN_SECRET!;

interface PaymentStatus {
  payment_id: number;
  payment_status: string;
  pay_amount: number;
  actually_paid: number;
  order_id: string;
  purchase_id: string;
}

function verifyIpnSignature(body: Record<string, unknown>, signature: string): boolean {
  const sorted = Object.keys(body)
    .sort()
    .reduce<Record<string, unknown>>((acc, key) => {
      acc[key] = body[key];
      return acc;
    }, {});
  const hmac = crypto.createHmac("sha512", IPN_SECRET);
  hmac.update(JSON.stringify(sorted));
  return hmac.digest("hex") === signature;
}

describe("NOWPayments Success Flow", () => {
  const statusLog: string[] = [];

  function handleIpn(payload: PaymentStatus, signature: string) {
    expect(verifyIpnSignature(payload as unknown as Record<string, unknown>, signature)).toBe(true);
    statusLog.push(payload.payment_status);

    if (payload.payment_status === "finished") {
      expect(payload.actually_paid).toBeGreaterThanOrEqual(payload.pay_amount);
    }
  }

  beforeEach(() => {
    statusLog.length = 0;
  });

  it("should process the full success lifecycle", async () => {
    const response = await fetch(`${SANDBOX_URL}/payment`, {
      method: "POST",
      headers: {
        "x-api-key": API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        price_amount: 50,
        price_currency: "usd",
        pay_currency: "btc",
        order_id: `success-${Date.now()}`,
        ipn_callback_url: process.env.IPN_CALLBACK_URL,
        case: "success",
      }),
    });

    expect(response.ok).toBe(true);

    const payment = await response.json();
    expect(payment.payment_id).toBeDefined();
    expect(payment.payment_status).toBe("waiting");
    expect(payment.pay_amount).toBeGreaterThan(0);
    expect(payment.pay_address).toBeDefined();
  });
});
```

---

## 5. Testing Partial Payment Flow

Partial payments occur when a customer sends less than the required amount. The
sandbox simulates this with `case: "partially_paid"` and supports the top-up
flow through the `purchase_id` mechanism.

### Step-by-Step

1. Create a payment with `case: "partially_paid"`.
2. The sandbox fires IPN callbacks: `waiting` → `partially_paid`.
3. Your handler detects the partial payment and stores the `purchase_id`.
4. Create a new top-up payment using the same `purchase_id` and
   `case: "success"` to simulate the customer completing the remaining amount.
5. The sandbox fires the full success sequence for the top-up payment.
6. Verify that both payments are linked via `purchase_id` and that the combined
   `actually_paid` amounts cover the original `price_amount`.

### Complete Test Example

```typescript
import { describe, it, expect } from "vitest";

const SANDBOX_URL = "https://api-sandbox.nowpayments.io/v1";
const API_KEY = process.env.NOWPAYMENTS_API_KEY!;

describe("NOWPayments Partial Payment Flow", () => {
  it("should handle partial payment and top-up", async () => {
    // Step 1: Create the initial partial payment
    const partialResponse = await fetch(`${SANDBOX_URL}/payment`, {
      method: "POST",
      headers: {
        "x-api-key": API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        price_amount: 200,
        price_currency: "usd",
        pay_currency: "eth",
        order_id: `partial-${Date.now()}`,
        ipn_callback_url: process.env.IPN_CALLBACK_URL,
        case: "partially_paid",
      }),
    });

    expect(partialResponse.ok).toBe(true);
    const partialPayment = await partialResponse.json();
    expect(partialPayment.payment_id).toBeDefined();

    // Step 2: Retrieve the payment to get the purchase_id
    const statusResponse = await fetch(
      `${SANDBOX_URL}/payment/${partialPayment.payment_id}`,
      {
        headers: { "x-api-key": API_KEY },
      }
    );

    expect(statusResponse.ok).toBe(true);
    const paymentStatus = await statusResponse.json();
    const purchaseId = paymentStatus.purchase_id;
    expect(purchaseId).toBeDefined();

    // Step 3: Create a top-up payment with the same purchase_id
    const topUpResponse = await fetch(`${SANDBOX_URL}/payment`, {
      method: "POST",
      headers: {
        "x-api-key": API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        price_amount: 200,
        price_currency: "usd",
        pay_currency: "eth",
        order_id: `topup-${Date.now()}`,
        purchase_id: purchaseId,
        ipn_callback_url: process.env.IPN_CALLBACK_URL,
        case: "success",
      }),
    });

    expect(topUpResponse.ok).toBe(true);
    const topUpPayment = await topUpResponse.json();
    expect(topUpPayment.payment_id).toBeDefined();
    expect(topUpPayment.purchase_id).toBe(purchaseId);
  });
});
```

---

## 6. Testing Failure Flow

Failure testing ensures your application handles payment failures gracefully —
updating order status, notifying the customer, and logging the failure for
operational review.

### Step-by-Step

1. Create a payment with `case: "failure"`.
2. The sandbox fires IPN callbacks: `waiting` → `failed`.
3. Your handler marks the order as failed and triggers customer notification
   (email, in-app message, or push notification).

### TypeScript Test Example

```typescript
import { describe, it, expect } from "vitest";

const SANDBOX_URL = "https://api-sandbox.nowpayments.io/v1";
const API_KEY = process.env.NOWPAYMENTS_API_KEY!;

describe("NOWPayments Failure Flow", () => {
  it("should create a failed payment and verify status", async () => {
    const response = await fetch(`${SANDBOX_URL}/payment`, {
      method: "POST",
      headers: {
        "x-api-key": API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        price_amount: 75,
        price_currency: "usd",
        pay_currency: "ltc",
        order_id: `failure-${Date.now()}`,
        ipn_callback_url: process.env.IPN_CALLBACK_URL,
        case: "failure",
      }),
    });

    expect(response.ok).toBe(true);
    const payment = await response.json();
    expect(payment.payment_id).toBeDefined();
    expect(payment.payment_status).toBe("waiting");

    // After IPN fires, poll to confirm the final status
    const poll = async (paymentId: number, maxAttempts = 10): Promise<string> => {
      for (let i = 0; i < maxAttempts; i++) {
        const res = await fetch(`${SANDBOX_URL}/payment/${paymentId}`, {
          headers: { "x-api-key": API_KEY },
        });
        const data = await res.json();
        if (data.payment_status === "failed") return data.payment_status;
        await new Promise((r) => setTimeout(r, 2000));
      }
      throw new Error("Payment did not reach failed status within timeout");
    };

    const finalStatus = await poll(payment.payment_id);
    expect(finalStatus).toBe("failed");
  });
});
```

---

## 7. IPN Testing in Sandbox

When you create a sandbox payment with a `case` parameter, NOWPayments
automatically fires IPN (Instant Payment Notification) callbacks to your
`ipn_callback_url` for each status transition in the simulated sequence.

### Key Behaviors

- Callbacks fire within seconds of payment creation — no blockchain delay.
- Each callback contains the same payload structure as production IPN
  (see the Webhooks & IPN reference).
- The `x-nowpayments-sig` header is present and signed with your **sandbox**
  IPN secret.
- Callbacks arrive in order, but your handler should be idempotent in case
  of retries or out-of-order delivery.

### Verification Checklist

1. Confirm your handler returns `200 OK` for each callback. Non-200 responses
   trigger retries.
2. Verify HMAC-SHA512 signature on every callback using your sandbox IPN secret.
3. Confirm each status transition is logged and the correct business logic fires
   (e.g., `finished` triggers order fulfillment).
4. Test idempotency by sending the same callback payload twice and confirming
   no duplicate side effects.

### Common Pitfall

The most frequent sandbox testing error is using the **production** IPN secret
to verify sandbox callbacks. Sandbox and production IPN secrets are completely
independent. If signature verification fails in sandbox but works in production
(or vice versa), check that you are loading the correct secret for the current
environment.

---

## 8. Local Development with ngrok

Since the sandbox sends real HTTP requests to your `ipn_callback_url`, your
local development server must be reachable from the internet. ngrok creates a
secure tunnel from a public HTTPS URL to your local machine.

### Setup

```bash
# Install ngrok (macOS)
brew install ngrok

# Install ngrok (Linux)
snap install ngrok

# Authenticate (one-time setup)
ngrok config add-authtoken YOUR_NGROK_AUTH_TOKEN

# Start tunnel to your local server on port 3000
ngrok http 3000
```

ngrok outputs a forwarding URL like `https://a1b2c3d4.ngrok-free.app`. Use this
as your `ipn_callback_url` when creating sandbox payments.

### Inspecting Requests

Open the ngrok inspection dashboard at `http://localhost:4040` to view all
incoming requests in real time. You can see the full request headers and body
for each IPN callback, replay requests for debugging, and inspect response
codes from your handler.

### Environment Variables for Local Development

```bash
# .env.local
NOWPAYMENTS_API_KEY=sandbox-api-key-here
NOWPAYMENTS_API_URL=https://api-sandbox.nowpayments.io/v1
NOWPAYMENTS_IPN_SECRET=sandbox-ipn-secret-here
IPN_CALLBACK_URL=https://a1b2c3d4.ngrok-free.app/api/webhooks/nowpayments
```

### Security

- Never commit your ngrok URL to version control.
- Do not use ngrok tunnels in production deployments.
- ngrok free-tier URLs change on every restart. For persistent URLs, use a
  paid ngrok plan or configure a stable subdomain.
- Add ngrok's `ngrok-skip-browser-warning` header handling if your server
  serves HTML responses on the same port.

---

## 9. Local Development with Mockoon

For fully offline development without any dependency on the NOWPayments sandbox,
use Mockoon to run a local API mock server that simulates NOWPayments responses.

### Setup with Mockoon

1. Download Mockoon from [mockoon.com](https://mockoon.com) (available for
   macOS, Linux, and Windows) or install the CLI:

```bash
npm install -g @mockoon/cli
```

2. Import a NOWPayments API mock environment. Mockoon provides a catalog of
   pre-built API mocks. Search for "NOWPayments" in the Mockoon mock catalog
   or create your own environment with the following routes:

```
GET  /v1/status          → { "message": "OK" }
GET  /v1/currencies      → { "currencies": ["btc","eth","ltc","usdt","sol"] }
GET  /v1/min-amount      → { "min_amount": 0.001, "currency_from": "usd", "currency_to": "btc" }
POST /v1/payment         → { "payment_id": 1001, "payment_status": "waiting", "pay_address": "mock-addr", ... }
GET  /v1/payment/:id     → { "payment_id": 1001, "payment_status": "finished", ... }
```

3. Start the mock server:

```bash
mockoon-cli start --data ./nowpayments-mock.json --port 3001
```

4. Point your application at the local mock:

```bash
NOWPAYMENTS_API_URL=http://localhost:3001/v1
```

### Alternative: WireMock

WireMock also supports NOWPayments API mocking through its mock catalog.
Install WireMock, import the NOWPayments stub mappings, and run:

```bash
wiremock --port 3001 --root-dir ./wiremock-nowpayments
```

Both Mockoon and WireMock let you develop and test payment flows without any
network connectivity.

---

## 10. Integration Test Patterns

### TypeScript with Vitest

#### Payment Creation Test

```typescript
import { describe, it, expect, vi, beforeAll } from "vitest";

const SANDBOX_URL = "https://api-sandbox.nowpayments.io/v1";
const API_KEY = process.env.NOWPAYMENTS_API_KEY!;

describe("Payment Creation", () => {
  it("should create a payment and return valid fields", async () => {
    const response = await fetch(`${SANDBOX_URL}/payment`, {
      method: "POST",
      headers: {
        "x-api-key": API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        price_amount: 25,
        price_currency: "usd",
        pay_currency: "btc",
        order_id: `integration-${Date.now()}`,
        case: "success",
      }),
    });

    expect(response.ok).toBe(true);
    const data = await response.json();

    expect(data).toMatchObject({
      payment_status: "waiting",
      price_amount: 25,
      price_currency: "usd",
      pay_currency: "btc",
    });
    expect(data.payment_id).toBeTypeOf("number");
    expect(data.pay_address).toBeTypeOf("string");
    expect(data.pay_amount).toBeGreaterThan(0);
  });
});
```

#### IPN Signature Verification Test

```typescript
import { describe, it, expect } from "vitest";
import crypto from "node:crypto";

const IPN_SECRET = process.env.NOWPAYMENTS_IPN_SECRET!;

function computeSignature(payload: Record<string, unknown>, secret: string): string {
  const sorted = Object.keys(payload)
    .sort()
    .reduce<Record<string, unknown>>((acc, key) => {
      acc[key] = payload[key];
      return acc;
    }, {});
  return crypto.createHmac("sha512", secret).update(JSON.stringify(sorted)).digest("hex");
}

describe("IPN Signature Verification", () => {
  it("should accept a correctly signed payload", () => {
    const payload = {
      payment_id: 12345,
      payment_status: "finished",
      pay_amount: 0.005,
      actually_paid: 0.005,
      order_id: "order-001",
    };
    const signature = computeSignature(payload, IPN_SECRET);
    const recomputed = computeSignature(payload, IPN_SECRET);
    expect(signature).toBe(recomputed);
  });

  it("should reject a tampered payload", () => {
    const payload = {
      payment_id: 12345,
      payment_status: "finished",
      pay_amount: 0.005,
      actually_paid: 0.005,
      order_id: "order-001",
    };
    const signature = computeSignature(payload, IPN_SECRET);

    const tampered = { ...payload, actually_paid: 999 };
    const tamperedSignature = computeSignature(tampered, IPN_SECRET);
    expect(signature).not.toBe(tamperedSignature);
  });
});
```

#### Status Polling Test

```typescript
import { describe, it, expect } from "vitest";

const SANDBOX_URL = "https://api-sandbox.nowpayments.io/v1";
const API_KEY = process.env.NOWPAYMENTS_API_KEY!;

describe("Payment Status Polling", () => {
  it("should poll until payment reaches finished status", async () => {
    // Create a success payment
    const createRes = await fetch(`${SANDBOX_URL}/payment`, {
      method: "POST",
      headers: {
        "x-api-key": API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        price_amount: 10,
        price_currency: "usd",
        pay_currency: "btc",
        order_id: `poll-${Date.now()}`,
        case: "success",
      }),
    });

    const payment = await createRes.json();

    const poll = async (id: number, target: string, maxAttempts = 15): Promise<string> => {
      for (let i = 0; i < maxAttempts; i++) {
        const res = await fetch(`${SANDBOX_URL}/payment/${id}`, {
          headers: { "x-api-key": API_KEY },
        });
        const data = await res.json();
        if (data.payment_status === target) return data.payment_status;
        await new Promise((r) => setTimeout(r, 3000));
      }
      throw new Error(`Payment ${id} did not reach ${target} within timeout`);
    };

    const status = await poll(payment.payment_id, "finished");
    expect(status).toBe("finished");
  }, 60_000);
});
```

#### Unit Test with Mocked Fetch

```typescript
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

describe("Payment Service (unit, mocked)", () => {
  const originalFetch = globalThis.fetch;

  beforeEach(() => {
    globalThis.fetch = vi.fn();
  });

  afterEach(() => {
    globalThis.fetch = originalFetch;
  });

  it("should return payment data on success", async () => {
    const mockResponse = {
      payment_id: 99999,
      payment_status: "waiting",
      pay_address: "0xmockaddress",
      price_amount: 50,
      price_currency: "usd",
      pay_amount: 0.0025,
      pay_currency: "btc",
      order_id: "mock-order",
    };

    vi.mocked(globalThis.fetch).mockResolvedValueOnce(
      new Response(JSON.stringify(mockResponse), { status: 200 })
    );

    const response = await fetch("https://api-sandbox.nowpayments.io/v1/payment", {
      method: "POST",
      headers: {
        "x-api-key": "mock-key",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        price_amount: 50,
        price_currency: "usd",
        pay_currency: "btc",
        order_id: "mock-order",
      }),
    });

    const data = await response.json();
    expect(data.payment_id).toBe(99999);
    expect(data.payment_status).toBe("waiting");
    expect(fetch).toHaveBeenCalledOnce();
  });
});
```

### Python with pytest

#### Payment Flow Test

```python
import os
import time
import requests
import pytest

SANDBOX_URL = os.environ["NOWPAYMENTS_API_URL"]
API_KEY = os.environ["NOWPAYMENTS_API_KEY"]

HEADERS = {
    "x-api-key": API_KEY,
    "Content-Type": "application/json",
}


def test_create_success_payment():
    response = requests.post(
        f"{SANDBOX_URL}/payment",
        headers=HEADERS,
        json={
            "price_amount": 30,
            "price_currency": "usd",
            "pay_currency": "btc",
            "order_id": f"pytest-{int(time.time())}",
            "case": "success",
        },
    )

    assert response.status_code == 201
    data = response.json()
    assert data["payment_status"] == "waiting"
    assert data["payment_id"] > 0
    assert data["pay_amount"] > 0
```

#### IPN Verification Test

```python
import hashlib
import hmac
import json
import os

IPN_SECRET = os.environ["NOWPAYMENTS_IPN_SECRET"]


def compute_signature(payload: dict, secret: str) -> str:
    sorted_payload = dict(sorted(payload.items()))
    payload_str = json.dumps(sorted_payload, separators=(",", ":"))
    return hmac.new(
        secret.encode("utf-8"),
        payload_str.encode("utf-8"),
        hashlib.sha512,
    ).hexdigest()


def test_ipn_signature_valid():
    payload = {
        "payment_id": 12345,
        "payment_status": "finished",
        "pay_amount": 0.005,
        "actually_paid": 0.005,
        "order_id": "pytest-order",
    }
    sig = compute_signature(payload, IPN_SECRET)
    assert compute_signature(payload, IPN_SECRET) == sig


def test_ipn_signature_rejects_tampered():
    payload = {
        "payment_id": 12345,
        "payment_status": "finished",
        "pay_amount": 0.005,
        "actually_paid": 0.005,
        "order_id": "pytest-order",
    }
    sig = compute_signature(payload, IPN_SECRET)

    tampered = {**payload, "actually_paid": 999}
    tampered_sig = compute_signature(tampered, IPN_SECRET)
    assert sig != tampered_sig
```

#### Fixture for NOWPayments Client

```python
import os
import pytest
import requests


class NOWPaymentsClient:
    def __init__(self, api_url: str, api_key: str):
        self.api_url = api_url
        self.session = requests.Session()
        self.session.headers.update({
            "x-api-key": api_key,
            "Content-Type": "application/json",
        })

    def create_payment(self, amount: float, currency: str, pay_currency: str, **kwargs):
        payload = {
            "price_amount": amount,
            "price_currency": currency,
            "pay_currency": pay_currency,
            **kwargs,
        }
        response = self.session.post(f"{self.api_url}/payment", json=payload)
        response.raise_for_status()
        return response.json()

    def get_payment(self, payment_id: int):
        response = self.session.get(f"{self.api_url}/payment/{payment_id}")
        response.raise_for_status()
        return response.json()

    def get_status(self):
        response = self.session.get(f"{self.api_url}/status")
        response.raise_for_status()
        return response.json()


@pytest.fixture
def nowpayments_client():
    return NOWPaymentsClient(
        api_url=os.environ["NOWPAYMENTS_API_URL"],
        api_key=os.environ["NOWPAYMENTS_API_KEY"],
    )


def test_api_health(nowpayments_client):
    status = nowpayments_client.get_status()
    assert status["message"] == "OK"


def test_create_and_poll(nowpayments_client):
    payment = nowpayments_client.create_payment(
        amount=15,
        currency="usd",
        pay_currency="eth",
        order_id="fixture-test",
        case="success",
    )
    assert payment["payment_id"] > 0

    fetched = nowpayments_client.get_payment(payment["payment_id"])
    assert fetched["payment_id"] == payment["payment_id"]
```

---

## 11. CI/CD Pipeline

Running automated tests against the NOWPayments sandbox in your CI/CD pipeline
ensures that payment integration remains functional across deployments.

### GitHub Actions Workflow

The following workflow runs unit tests first, then integration tests against the
sandbox, and finally deploys on success.

```yaml
# .github/workflows/nowpayments-test.yml
name: NOWPayments Integration Tests

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

env:
  NODE_VERSION: "20"

jobs:
  unit-tests:
    name: Unit Tests
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: "pnpm"

      - run: pnpm install --frozen-lockfile
      - run: pnpm vitest run --project unit

  integration-tests:
    name: Integration Tests (Sandbox)
    needs: unit-tests
    runs-on: ubuntu-latest
    env:
      NOWPAYMENTS_API_KEY: ${{ secrets.NOWPAYMENTS_SANDBOX_API_KEY }}
      NOWPAYMENTS_API_URL: https://api-sandbox.nowpayments.io/v1
      NOWPAYMENTS_IPN_SECRET: ${{ secrets.NOWPAYMENTS_SANDBOX_IPN_SECRET }}
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: "pnpm"

      - run: pnpm install --frozen-lockfile

      - name: Verify sandbox API is reachable
        run: |
          STATUS=$(curl -s -o /dev/null -w "%{http_code}" https://api-sandbox.nowpayments.io/v1/status)
          if [ "$STATUS" != "200" ]; then
            echo "Sandbox API returned $STATUS — retrying in 30s"
            sleep 30
            STATUS=$(curl -s -o /dev/null -w "%{http_code}" https://api-sandbox.nowpayments.io/v1/status)
            if [ "$STATUS" != "200" ]; then
              echo "Sandbox API unreachable after retry. Skipping integration tests."
              exit 0
            fi
          fi

      - name: Run integration tests
        run: pnpm vitest run --project integration
        timeout-minutes: 5

  deploy:
    name: Deploy
    needs: integration-tests
    if: github.ref == 'refs/heads/main' && github.event_name == 'push'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: ${{ env.NODE_VERSION }}
          cache: "pnpm"

      - run: pnpm install --frozen-lockfile
      - run: pnpm build
      - name: Deploy to production
        run: pnpm deploy:production
        env:
          NOWPAYMENTS_API_KEY: ${{ secrets.NOWPAYMENTS_PRODUCTION_API_KEY }}
          NOWPAYMENTS_API_URL: https://api.nowpayments.io/v1
          NOWPAYMENTS_IPN_SECRET: ${{ secrets.NOWPAYMENTS_PRODUCTION_IPN_SECRET }}
```

### Required Repository Secrets

Configure the following secrets in your GitHub repository settings under
**Settings → Secrets and variables → Actions**:

| Secret | Description |
|--------|-------------|
| `NOWPAYMENTS_SANDBOX_API_KEY` | API key from your sandbox account |
| `NOWPAYMENTS_SANDBOX_IPN_SECRET` | IPN secret from your sandbox account |
| `NOWPAYMENTS_PRODUCTION_API_KEY` | API key from your production account |
| `NOWPAYMENTS_PRODUCTION_IPN_SECRET` | IPN secret from your production account |

### Sandbox Reliability in CI

The NOWPayments sandbox may experience occasional downtime or elevated latency.
To prevent false CI failures:

- Add a health check step before running integration tests (shown in the
  workflow above). If the sandbox is unreachable, the step exits cleanly
  rather than failing the entire pipeline.
- Set a reasonable `timeout-minutes` on the integration test step to prevent
  jobs from hanging if the sandbox stalls.
- Separate unit tests (which use mocks) from integration tests (which hit
  sandbox) so that unit tests always run regardless of sandbox availability.
- Consider running integration tests on a nightly schedule rather than on
  every push to reduce sandbox load and avoid blocking PRs during sandbox
  outages.
