# Custody & Conversions — Complete Reference

This document covers the custody/sub-partner system for platform architectures (exchanges, casinos, gaming, multi-tenant SaaS) and off-chain crypto-to-crypto conversions powered by ChangeNOW, as exposed by the NOWPayments API (v1).

## Table of Contents

1. [Custody System Overview](#1-custody-system-overview)
2. [POST /v1/sub-partner/balance — Create Sub-Partner](#2-post-v1sub-partnerbalance--create-sub-partner)
3. [GET /v1/balance — Get Custody Balance](#3-get-v1balance--get-custody-balance)
4. [GET /v1/sub-partner/balance — Sub-Partner Balance](#4-get-v1sub-partnerbalance--sub-partner-balance)
5. [POST /v1/sub-partner/deposit — Create Deposit](#5-post-v1sub-partnerdeposit--create-deposit)
6. [POST /v1/sub-partner/transfer — Transfer Between Accounts](#6-post-v1sub-partnertransfer--transfer-between-accounts)
7. [POST /v1/sub-partner/withdrawal — Withdraw from Sub-Partner](#7-post-v1sub-partnerwithdrawal--withdraw-from-sub-partner)
8. [GET /v1/sub-partner/users — List Sub-Partner Users](#8-get-v1sub-partnerusers--list-sub-partner-users)
9. [Off-Chain Custody Conversions](#9-off-chain-custody-conversions)
10. [Custodial Recurring Billing Pattern](#10-custodial-recurring-billing-pattern)
11. [Platform Architecture Examples](#11-platform-architecture-examples)
12. [Security Hardening Checklist](#12-security-hardening-checklist)

---

## 1. Custody System Overview

In the default NOWPayments flow, funds pass through to the merchant's external wallet after each payment confirmation. Custody mode changes this: NOWPayments holds funds on behalf of the merchant (or the merchant's end-users) in internal wallets managed by the platform. Funds remain within the NOWPayments infrastructure until explicitly withdrawn or transferred.

### Non-Custodial (Default) vs Custodial

| Aspect | Non-Custodial | Custodial |
|---|---|---|
| Fund destination | Merchant's external wallet | NOWPayments custody balance |
| Sub-partner accounts | Not available | Create unlimited sub-accounts |
| Off-chain transfers | Not available | Instant, zero network fees |
| Off-chain conversions | Not available | Swap between 350+ currencies |
| Withdrawal | Automatic after confirmation | Manual via API or dashboard |
| Security requirements | API key only | API key + JWT + IP whitelist + 2FA |

### When to Use Custody

- **Crypto exchanges**: Users deposit and trade; balances tracked off-chain until withdrawal.
- **Casinos and gaming platforms**: Player deposits fund a virtual balance; game outcomes settle as internal transfers.
- **Multi-tenant SaaS**: Tenant payments accumulate in custody; automated payouts distribute to service providers.
- **Automated recurring billing**: Customer pre-deposits; your server charges from the balance at intervals.
- **Marketplace escrow**: Hold funds until delivery confirmed, then transfer to seller's sub-partner.

### Enabling Custody

Enable custody mode in the NOWPayments dashboard under Settings > Custody. Activation requires the full security stack:

1. API key generated (Dashboard > API Keys)
2. JWT authentication configured (email + password for `POST /v1/auth`)
3. Server IPs whitelisted (Dashboard > Payouts > IP Whitelist)
4. Two-factor authentication enabled on the account (Dashboard > Security)

All custody endpoints require both `x-api-key` and `Authorization: Bearer <jwt>` headers.

---

## 2. POST /v1/sub-partner/balance — Create Sub-Partner

Creates a sub-partner user account within the custody system. Each sub-partner gets its own isolated balance and deposit addresses.

```
POST https://api.nowpayments.io/v1/sub-partner/balance
Headers: x-api-key: <API_KEY>, Authorization: Bearer <JWT>
Content-Type: application/json
```

### Request Body

| Field | Type | Required | Description |
|---|---|---|---|
| `name` | string | yes | Unique identifier for the sub-partner (user ID, email, or internal reference) |

### Response (201)

```json
{
  "id": "sp_93827461",
  "name": "user-0042",
  "created_at": "2026-02-25T10:15:00.000Z",
  "balances": {}
}
```

The `id` field is the sub-partner ID used in all subsequent operations (deposits, transfers, withdrawals, balance queries).

### TypeScript Example

```typescript
const BASE = "https://api.nowpayments.io/v1";

async function getJwt(): Promise<string> {
  const res = await fetch(`${BASE}/auth`, {
    method: "POST",
    headers: { "x-api-key": process.env.NP_API_KEY!, "Content-Type": "application/json" },
    body: JSON.stringify({ email: process.env.NP_EMAIL!, password: process.env.NP_PASSWORD! }),
  });
  if (!res.ok) throw new Error(`Auth failed: ${res.status}`);
  const data = await res.json();
  return data.token as string;
}

async function createSubPartner(jwt: string, name: string): Promise<{ id: string; name: string }> {
  const res = await fetch(`${BASE}/sub-partner/balance`, {
    method: "POST",
    headers: {
      "x-api-key": process.env.NP_API_KEY!,
      Authorization: `Bearer ${jwt}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name }),
  });
  if (!res.ok) throw new Error(`Create sub-partner failed: ${res.status} ${await res.text()}`);
  return res.json();
}

const jwt = await getJwt();
const partner = await createSubPartner(jwt, "user-0042");
console.log(`Created sub-partner: ${partner.id}`);
```

---

## 3. GET /v1/balance — Get Custody Balance

Returns the aggregate custody balance across all cryptocurrencies held in the merchant's custody account.

```
GET https://api.nowpayments.io/v1/balance
Headers: x-api-key: <API_KEY>, Authorization: Bearer <JWT>
```

**Auth:** API key + JWT. No request body or query parameters.

### Response (200)

```json
{
  "balances": [
    { "currency": "btc", "amount": "0.25431000", "pending_amount": "0.01000000" },
    { "currency": "eth", "amount": "4.81200000", "pending_amount": "0.00000000" },
    { "currency": "usdt", "amount": "12840.50000000", "pending_amount": "500.00000000" }
  ]
}
```

| Field | Type | Description |
|---|---|---|
| `currency` | string | Cryptocurrency ticker |
| `amount` | string | Confirmed available balance |
| `pending_amount` | string | Deposits awaiting blockchain confirmation |

### TypeScript Example

```typescript
async function getCustodyBalance(jwt: string): Promise<void> {
  const res = await fetch(`${BASE}/balance`, {
    headers: { "x-api-key": process.env.NP_API_KEY!, Authorization: `Bearer ${jwt}` },
  });
  if (!res.ok) throw new Error(`Balance fetch failed: ${res.status}`);
  const data = await res.json();
  for (const b of data.balances) {
    console.log(`${b.currency.toUpperCase()}: ${b.amount} (pending: ${b.pending_amount})`);
  }
}
```

---

## 4. GET /v1/sub-partner/balance — Sub-Partner Balance

Returns the balance for a specific sub-partner account.

```
GET https://api.nowpayments.io/v1/sub-partner/balance?id=<SUB_PARTNER_ID>
Headers: x-api-key: <API_KEY>, Authorization: Bearer <JWT>
```

**Auth:** API key + JWT.

### Request Parameters

| Parameter | Type | Required | Description |
|---|---|---|---|
| `id` | string | yes | Sub-partner ID returned from creation |

### Response (200)

```json
{
  "id": "sp_93827461",
  "balances": [
    { "currency": "btc", "amount": "0.05200000", "pending_amount": "0.00000000" },
    { "currency": "usdt", "amount": "1500.00000000", "pending_amount": "200.00000000" }
  ]
}
```

### TypeScript Example

```typescript
async function getSubPartnerBalance(jwt: string, subPartnerId: string): Promise<void> {
  const url = `${BASE}/sub-partner/balance?id=${encodeURIComponent(subPartnerId)}`;
  const res = await fetch(url, {
    headers: { "x-api-key": process.env.NP_API_KEY!, Authorization: `Bearer ${jwt}` },
  });
  if (!res.ok) throw new Error(`Sub-partner balance failed: ${res.status}`);
  const data = await res.json();
  console.log(`Balance for ${data.id}:`);
  for (const b of data.balances) {
    console.log(`  ${b.currency.toUpperCase()}: ${b.amount}`);
  }
}
```

---

## 5. POST /v1/sub-partner/deposit — Create Deposit

Generates a deposit address for a sub-partner to receive funds. Each call returns a unique address tied to the sub-partner and currency pair.

```
POST https://api.nowpayments.io/v1/sub-partner/deposit
Headers: x-api-key: <API_KEY>, Authorization: Bearer <JWT>
Content-Type: application/json
```

### Request Body

| Field | Type | Required | Description |
|---|---|---|---|
| `sub_partner_id` | string | yes | Target sub-partner account |
| `currency` | string | yes | Cryptocurrency ticker (e.g., `"btc"`, `"usdt"`) |

### Response (201)

```json
{
  "id": "dep_7729103846",
  "sub_partner_id": "sp_93827461",
  "currency": "usdt",
  "address": "TEmGwPeRTPiLFLVfBxXkSP91yc5GMNQhfS",
  "created_at": "2026-02-25T10:30:00.000Z"
}
```

### Deposit Fee

A **0.5% deposit fee** is deducted from each incoming deposit. If a user sends 1000 USDT, the sub-partner balance receives 995 USDT.

### TypeScript Example

```typescript
interface DepositAddress {
  id: string;
  sub_partner_id: string;
  currency: string;
  address: string;
  created_at: string;
}

async function createDeposit(jwt: string, subPartnerId: string, currency: string): Promise<DepositAddress> {
  const res = await fetch(`${BASE}/sub-partner/deposit`, {
    method: "POST",
    headers: {
      "x-api-key": process.env.NP_API_KEY!,
      Authorization: `Bearer ${jwt}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ sub_partner_id: subPartnerId, currency }),
  });
  if (!res.ok) throw new Error(`Create deposit failed: ${res.status} ${await res.text()}`);
  return res.json();
}

const deposit = await createDeposit(jwt, "sp_93827461", "usdt");
console.log(`Send USDT to: ${deposit.address}`);
```

---

## 6. POST /v1/sub-partner/transfer — Transfer Between Accounts

Performs an off-chain transfer between two sub-partner accounts. Because the transfer happens within the NOWPayments custody infrastructure, there are no blockchain network fees and settlement is instant.

```
POST https://api.nowpayments.io/v1/sub-partner/transfer
Headers: x-api-key: <API_KEY>, Authorization: Bearer <JWT>
Content-Type: application/json
```

### Request Body

| Field | Type | Required | Description |
|---|---|---|---|
| `from` | string | yes | Source sub-partner ID |
| `to` | string | yes | Destination sub-partner ID |
| `currency` | string | yes | Cryptocurrency ticker |
| `amount` | number | yes | Amount to transfer |

### Response (200)

```json
{
  "id": "txfr_55019283",
  "from": "sp_93827461",
  "to": "sp_10284756",
  "currency": "usdt",
  "amount": 500,
  "status": "completed",
  "created_at": "2026-02-25T11:00:00.000Z"
}
```

### TypeScript Example

```typescript
interface TransferResult {
  id: string;
  from: string;
  to: string;
  currency: string;
  amount: number;
  status: string;
}

async function transferBetweenSubPartners(
  jwt: string,
  from: string,
  to: string,
  currency: string,
  amount: number,
): Promise<TransferResult> {
  const res = await fetch(`${BASE}/sub-partner/transfer`, {
    method: "POST",
    headers: {
      "x-api-key": process.env.NP_API_KEY!,
      Authorization: `Bearer ${jwt}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ from, to, currency, amount }),
  });
  if (!res.ok) throw new Error(`Transfer failed: ${res.status} ${await res.text()}`);
  return res.json();
}

const transfer = await transferBetweenSubPartners(jwt, "sp_93827461", "sp_10284756", "usdt", 500);
console.log(`Transfer ${transfer.id}: ${transfer.status}`);
```

---

## 7. POST /v1/sub-partner/withdrawal — Withdraw from Sub-Partner

Withdraws funds from a sub-partner account to an external blockchain wallet. Subject to the same security requirements as mass payouts: API key + JWT + IP whitelist + 2FA + whitelisted withdrawal address.

```
POST https://api.nowpayments.io/v1/sub-partner/withdrawal
Headers: x-api-key: <API_KEY>, Authorization: Bearer <JWT>
Content-Type: application/json
```

### Request Body

| Field | Type | Required | Description |
|---|---|---|---|
| `sub_partner_id` | string | yes | Source sub-partner account |
| `address` | string | yes | External wallet address (must be whitelisted) |
| `currency` | string | yes | Cryptocurrency ticker |
| `amount` | number | yes | Amount to withdraw |
| `ipn_callback_url` | string | no | Webhook URL for withdrawal status updates |

### Response (200)

```json
{
  "id": "wd_88102934",
  "sub_partner_id": "sp_93827461",
  "address": "0x1EBAE3A2a6E8a0E4e7fC2F703E2f1B2bC460e5D8",
  "currency": "usdt",
  "amount": 1000,
  "status": "creating",
  "created_at": "2026-02-25T11:30:00.000Z"
}
```

Withdrawal status follows the same lifecycle as payouts: `creating` > `processing` > `sending` > `finished` (or `failed`/`rejected`).

### TypeScript Example

```typescript
interface WithdrawalResult {
  id: string;
  sub_partner_id: string;
  address: string;
  currency: string;
  amount: number;
  status: string;
}

async function withdrawFromSubPartner(
  jwt: string,
  subPartnerId: string,
  address: string,
  currency: string,
  amount: number,
): Promise<WithdrawalResult> {
  const res = await fetch(`${BASE}/sub-partner/withdrawal`, {
    method: "POST",
    headers: {
      "x-api-key": process.env.NP_API_KEY!,
      Authorization: `Bearer ${jwt}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      sub_partner_id: subPartnerId,
      address,
      currency,
      amount,
      ipn_callback_url: "https://example.com/ipn/withdrawal",
    }),
  });
  if (!res.ok) throw new Error(`Withdrawal failed: ${res.status} ${await res.text()}`);
  return res.json();
}

const wd = await withdrawFromSubPartner(jwt, "sp_93827461", "0x1EBAE3A2a6E8a0E4e7fC2F703E2f1B2bC460e5D8", "usdt", 1000);
console.log(`Withdrawal ${wd.id}: ${wd.status}`);
```

---

## 8. GET /v1/sub-partner/users — List Sub-Partner Users

Returns a paginated list of all sub-partner accounts under the custody merchant.

```
GET https://api.nowpayments.io/v1/sub-partner/users?limit=50&offset=0
Headers: x-api-key: <API_KEY>, Authorization: Bearer <JWT>
```

### Request Parameters

| Parameter | Type | Default | Description |
|---|---|---|---|
| `limit` | number | 10 | Results per page (max 100) |
| `offset` | number | 0 | Number of results to skip |

### Response (200)

```json
{
  "users": [
    { "id": "sp_93827461", "name": "user-0042", "created_at": "2026-02-25T10:15:00.000Z" },
    { "id": "sp_10284756", "name": "user-0043", "created_at": "2026-02-25T10:20:00.000Z" }
  ],
  "total": 128
}
```

### TypeScript Example

```typescript
interface SubPartnerList {
  users: { id: string; name: string; created_at: string }[];
  total: number;
}

async function listSubPartners(jwt: string, limit = 50, offset = 0): Promise<SubPartnerList> {
  const url = `${BASE}/sub-partner/users?limit=${limit}&offset=${offset}`;
  const res = await fetch(url, {
    headers: { "x-api-key": process.env.NP_API_KEY!, Authorization: `Bearer ${jwt}` },
  });
  if (!res.ok) throw new Error(`List sub-partners failed: ${res.status}`);
  return res.json();
}

const list = await listSubPartners(jwt, 50, 0);
console.log(`Total sub-partners: ${list.total}`);
for (const u of list.users) console.log(`  ${u.id}: ${u.name}`);
```

---

## 9. Off-Chain Custody Conversions

Custody mode enables crypto-to-crypto swaps directly within your custody balance, powered by the ChangeNOW exchange engine. Because the conversion happens entirely off-chain within the NOWPayments/ChangeNOW infrastructure, no blockchain transactions are created and no network fees apply.

### How It Works

1. You hold a balance in currency A within custody.
2. You call the conversion endpoint specifying the source currency, target currency, and amount.
3. ChangeNOW's exchange engine executes the swap at the current market rate.
4. Your custody balance in currency A decreases; your balance in currency B increases.
5. The conversion is instant and irreversible.

### Fee Structure

A fixed **0.5% conversion fee** is included in the displayed exchange rate. No additional fees. No blockchain network fees since no on-chain transaction occurs.

### Supported Pairs

All 350+ cryptocurrencies supported by NOWPayments are available for conversion. Any-to-any swaps with no minimum or maximum amount limits.

### When to Use Off-Chain Conversions

- **Portfolio rebalancing**: Shift custody holdings between cryptocurrencies without withdrawal/deposit cycles.
- **Currency consolidation**: Convert dust amounts across many tokens into a single currency for cleaner accounting.
- **Reducing withdrawal fees**: Convert to a low-fee network currency (e.g., TRX, XLM) before withdrawing to reduce blockchain fees.
- **Locking to stablecoins**: Convert volatile assets to USDT/USDC to preserve value during downturns.
- **Preparing payouts**: Convert received currencies into the currency your vendors or employees expect.

### TypeScript Example

```typescript
interface ConversionResult {
  id: string;
  from_currency: string;
  to_currency: string;
  from_amount: number;
  to_amount: number;
  rate: number;
  status: string;
}

async function convertCustodyBalance(
  jwt: string,
  fromCurrency: string,
  toCurrency: string,
  amount: number,
): Promise<ConversionResult> {
  const res = await fetch(`${BASE}/custody/conversion`, {
    method: "POST",
    headers: {
      "x-api-key": process.env.NP_API_KEY!,
      Authorization: `Bearer ${jwt}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from_currency: fromCurrency,
      to_currency: toCurrency,
      amount,
    }),
  });
  if (!res.ok) throw new Error(`Conversion failed: ${res.status} ${await res.text()}`);
  return res.json();
}

const conversion = await convertCustodyBalance(jwt, "eth", "usdt", 2.5);
console.log(`Converted ${conversion.from_amount} ETH → ${conversion.to_amount} USDT at rate ${conversion.rate}`);
```

---

## 10. Custodial Recurring Billing Pattern

The custodial billing pattern enables automated recurring charges without requiring customer action each cycle. The customer deposits funds into their custody sub-partner account once (or tops up as needed), and your server transfers the billing amount from the customer's balance to the merchant's account at each interval.

### Step-by-Step Flow

```
1. Create sub-partner for customer
2. Generate deposit address → customer sends funds
3. Funds arrive in sub-partner balance (minus 0.5% deposit fee)
4. At billing interval, transfer from customer sub-partner to merchant sub-partner
5. If insufficient balance, notify customer to top up
6. Repeat from step 4 at each interval
```

### Advantages Over Email Subscriptions

| Aspect | Email Subscription | Custodial Billing |
|---|---|---|
| Customer action each cycle | Required (manual payment) | None (automatic) |
| Churn from missed payments | High | None (while balance exists) |
| Partial payment handling | Per-cycle | Balance-based (always exact) |
| Revenue predictability | Low | High (can check balances ahead) |

### TypeScript Example — Interval Billing Check

```typescript
import { createHmac } from "node:crypto";

const BASE = "https://api.nowpayments.io/v1";

interface BillingRecord {
  customerSubPartnerId: string;
  merchantSubPartnerId: string;
  currency: string;
  amount: number;
  intervalMs: number;
  lastChargedAt: number;
  customerEmail: string;
}

async function getJwt(): Promise<string> {
  const res = await fetch(`${BASE}/auth`, {
    method: "POST",
    headers: { "x-api-key": process.env.NP_API_KEY!, "Content-Type": "application/json" },
    body: JSON.stringify({ email: process.env.NP_EMAIL!, password: process.env.NP_PASSWORD! }),
  });
  if (!res.ok) throw new Error(`Auth failed: ${res.status}`);
  return (await res.json()).token;
}

async function checkAndCharge(jwt: string, record: BillingRecord): Promise<"charged" | "insufficient" | "not_due"> {
  const now = Date.now();
  if (now - record.lastChargedAt < record.intervalMs) return "not_due";

  const balRes = await fetch(`${BASE}/sub-partner/balance?id=${encodeURIComponent(record.customerSubPartnerId)}`, {
    headers: { "x-api-key": process.env.NP_API_KEY!, Authorization: `Bearer ${jwt}` },
  });
  if (!balRes.ok) throw new Error(`Balance check failed: ${balRes.status}`);
  const balData = await balRes.json();
  const balance = balData.balances.find((b: { currency: string; amount: string }) => b.currency === record.currency);
  const available = balance ? parseFloat(balance.amount) : 0;

  if (available < record.amount) return "insufficient";

  const txRes = await fetch(`${BASE}/sub-partner/transfer`, {
    method: "POST",
    headers: {
      "x-api-key": process.env.NP_API_KEY!,
      Authorization: `Bearer ${jwt}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: record.customerSubPartnerId,
      to: record.merchantSubPartnerId,
      currency: record.currency,
      amount: record.amount,
    }),
  });
  if (!txRes.ok) throw new Error(`Transfer failed: ${txRes.status} ${await txRes.text()}`);

  record.lastChargedAt = now;
  return "charged";
}

async function runBillingCycle(records: BillingRecord[]): Promise<void> {
  const jwt = await getJwt();
  for (const record of records) {
    const result = await checkAndCharge(jwt, record);
    switch (result) {
      case "charged":
        console.log(`Charged ${record.amount} ${record.currency} from ${record.customerSubPartnerId}`);
        break;
      case "insufficient":
        console.log(`Insufficient balance for ${record.customerSubPartnerId} — notifying ${record.customerEmail}`);
        break;
      case "not_due":
        break;
    }
  }
}
```

> **Cross-reference:** For the email-based (non-custodial) subscription alternative, see `subscriptions-and-payouts.md` Section 2.

---

## 11. Platform Architecture Examples

### Crypto Exchange

Users deposit to the exchange, trade off-chain, and withdraw to external wallets.

```
┌─────────────────────────────────────────────────────┐
│                   Your Exchange                      │
│                                                      │
│  User signs up                                       │
│       │                                              │
│       ▼                                              │
│  POST /sub-partner/balance  ──► Sub-partner created  │
│       │                                              │
│       ▼                                              │
│  POST /sub-partner/deposit  ──► Deposit address      │
│       │                                              │
│       ▼                                              │
│  User sends crypto on-chain ──► Balance credited     │
│       │                           (−0.5% fee)        │
│       ▼                                              │
│  User places trade                                   │
│       │                                              │
│       ▼                                              │
│  POST /sub-partner/transfer ──► Buyer↔Seller         │
│       │                         (instant, free)      │
│       ▼                                              │
│  User requests withdrawal                            │
│       │                                              │
│       ▼                                              │
│  POST /sub-partner/withdrawal ──► On-chain tx        │
└─────────────────────────────────────────────────────┘
```

Key advantage: all trading activity is off-chain transfers between sub-partners, so trades are instant and free. Only deposits and withdrawals touch the blockchain.

### Gaming / Casino Platform

Player deposits fund a virtual balance. Game outcomes settle as internal transfers between the player and the house.

```
┌─────────────────────────────────────────────────────┐
│                  Your Gaming Platform                │
│                                                      │
│  Player registers                                    │
│       │                                              │
│       ▼                                              │
│  Create sub-partner (player) + sub-partner (house)   │
│       │                                              │
│       ▼                                              │
│  POST /sub-partner/deposit  ──► Player deposit addr  │
│       │                                              │
│       ▼                                              │
│  Player deposits crypto     ──► Player balance       │
│       │                                              │
│       ▼                                              │
│  Game round: player bets 10 USDT                     │
│       │                                              │
│       ├── Player wins ──► transfer house → player    │
│       └── Player loses ──► transfer player → house   │
│       │                                              │
│       ▼                                              │
│  Player cashes out                                   │
│       │                                              │
│       ▼                                              │
│  POST /sub-partner/withdrawal ──► Player wallet      │
└─────────────────────────────────────────────────────┘
```

Key advantage: every bet, win, and loss is an instant off-chain transfer. The house sub-partner accumulates revenue. Withdraw house profits to a cold wallet on a schedule.

### Multi-Tenant SaaS

Tenants pay subscription fees into custody. The platform distributes payouts to service providers, contractors, or affiliate partners.

```
┌─────────────────────────────────────────────────────┐
│               Your Multi-Tenant SaaS                 │
│                                                      │
│  Tenant onboards                                     │
│       │                                              │
│       ▼                                              │
│  Create sub-partner (tenant)                         │
│  Create sub-partner (platform-revenue)               │
│  Create sub-partner (provider-A)                     │
│       │                                              │
│       ▼                                              │
│  Generate deposit address for tenant                 │
│       │                                              │
│       ▼                                              │
│  Tenant deposits monthly fee                         │
│       │                                              │
│       ▼                                              │
│  Billing cron fires:                                 │
│    transfer tenant → platform-revenue (your cut)     │
│    transfer tenant → provider-A (service fee)        │
│       │                                              │
│       ▼                                              │
│  Provider-A withdraws to external wallet             │
│  Platform converts revenue to USDT (off-chain)       │
└─────────────────────────────────────────────────────┘
```

Key advantage: all fund routing is programmable and instant. Convert between currencies off-chain to normalize accounting. Providers withdraw on their own schedule.

---

## 12. Security Hardening Checklist

Every item in this checklist applies to production custody deployments. Address all items before going live.

### Authentication and Access

- **Enable 2FA on the NOWPayments account.** Required for all custody and payout operations. Use an authenticator app, not SMS.
- **Whitelist server IPs.** Add every production server IP in Dashboard > Payouts > IP Whitelist. Changes to the whitelist require email confirmation from the registered account address and cannot be done via API.
- **Whitelist withdrawal addresses.** Pre-register every destination address in Dashboard > Payouts > Withdrawal Addresses. Confirm each via email. Transactions to non-whitelisted addresses are rejected.
- **Use JWT for all sensitive operations.** Cache the JWT token and refresh on 401. Never embed the email/password in client-side code.
- **Separate API keys for different services.** Use one key for payment creation (public-facing) and a separate key for custody/payout operations (server-only). Rotate keys quarterly.

### Monitoring and Operations

- **Monitor balances with automated alerts.** Set thresholds on custody balances and sub-partner balances. Alert when a sub-partner falls below the next billing amount or when aggregate custody drops below a safety margin.
- **Implement rate limiting on your side.** Even though NOWPayments has its own rate limits, add application-level throttling on custody operations to prevent abuse from compromised internal services.
- **Log all custody operations.** Record every sub-partner creation, deposit address generation, transfer, withdrawal, and conversion with timestamps, amounts, and initiating user/service. Store logs in an append-only system.

### Operational Security

- **Validate IPN signatures on withdrawal callbacks.** Use HMAC-SHA512 with your IPN secret to verify that webhook payloads originate from NOWPayments. See `webhooks-and-ipn.md` for signature verification.
- **Implement withdrawal approval workflows.** For withdrawals above a threshold, require manual approval or multi-signature authorization before calling the withdrawal endpoint.
- **Conduct regular security audits.** Review API key usage, IP whitelist entries, withdrawal address lists, and custody operation logs quarterly. Remove stale entries.
- **Keep withdrawal hot wallet exposure low.** Periodically sweep large custody balances to cold storage via manual withdrawals. Only keep operational liquidity in custody.
