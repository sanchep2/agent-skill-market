# Payments & Invoices — Complete Reference

This document covers every payment and invoice operation exposed by the NOWPayments crypto payment gateway API (v1), including utility lookups, payment creation and lifecycle, invoice flows, partial payment handling, and end-to-end integration examples.

## Table of Contents

1. [Utility Endpoints](#1-utility-endpoints)
2. [POST /v1/payment — Create Payment](#2-post-v1payment--create-payment)
3. [GET /v1/payment/{id} — Payment Status](#3-get-v1paymentid--payment-status)
4. [GET /v1/payment/ — List Payments](#4-get-v1payment--list-payments)
5. [POST /v1/payment/{id}/update-merchant-estimate — Refresh Estimate](#5-post-v1paymentidupdate-merchant-estimate--refresh-estimate)
6. [POST /v1/invoice — Create Invoice](#6-post-v1invoice--create-invoice)
7. [POST /v1/invoice-payment — Create Payment from Invoice](#7-post-v1invoice-payment--create-payment-from-invoice)
8. [Payment Status Lifecycle Deep Dive](#8-payment-status-lifecycle-deep-dive)
9. [Partial Payments](#9-partial-payments)
10. [Overpayments](#10-overpayments)
11. [Direct vs Invoice Flow Decision Tree](#11-direct-vs-invoice-flow-decision-tree)
12. [Complete Payment Flow Examples](#12-complete-payment-flow-examples)

## 1. Utility Endpoints

These endpoints provide prerequisite data you need before creating any payment or invoice.

### GET /v1/status

Health check. No authentication required.

```
GET https://api.nowpayments.io/v1/status
```

Response: `{"message":"OK"}`. If the API is under maintenance, returns a non-200 status. Always check before initiating payment flows in automated pipelines.

### GET /v1/currencies

Returns all 350+ cryptocurrencies supported by NOWPayments, regardless of merchant enablement.

```
GET https://api.nowpayments.io/v1/currencies
Headers: x-api-key: <YOUR_API_KEY>
```

Response: `{"currencies":["btc","eth","ltc","xrp","doge","usdt","bnb","sol","trx","matic",...]}`

### GET /v1/merchant/coins

Returns only the currencies enabled in your merchant dashboard — the list your customers should choose from.

```
GET https://api.nowpayments.io/v1/merchant/coins
Headers: x-api-key: <YOUR_API_KEY>
```

Response: `{"selectedCurrencies":["btc","eth","usdt","ltc"]}`

### GET /v1/min-amount

Returns the minimum payment amount for a given currency pair.

```
GET https://api.nowpayments.io/v1/min-amount?currency_from=usd&currency_to=btc
Headers: x-api-key: <YOUR_API_KEY>
```

| Parameter | Required | Description |
|---|---|---|
| currency_from | Yes | Source currency (fiat or crypto) |
| currency_to | Yes | Target cryptocurrency |
| fiat_equivalent | No | If set, returns min amount in the fiat currency |
| is_fixed_rate | No | Whether to use fixed-rate conversion |
| is_fee_paid_by_user | No | Whether the network fee is deducted from the amount |

### GET /v1/estimate

Returns the estimated amount the customer will receive after conversion.

```
GET https://api.nowpayments.io/v1/estimate?amount=100&currency_from=usd&currency_to=btc
Headers: x-api-key: <YOUR_API_KEY>
```

| Parameter | Required | Description |
|---|---|---|
| amount | Yes | Amount in currency_from |
| currency_from | Yes | Source currency |
| currency_to | Yes | Target cryptocurrency |

### Decision Tree: Which Utility to Call

- **Building a currency selector for your UI?** Use `GET /v1/merchant/coins` — only what you have enabled.
- **Validating whether a currency exists at all?** Use `GET /v1/currencies` — the full list.
- **Checking if the user's amount is too small?** Use `GET /v1/min-amount` before creating the payment.
- **Showing an estimated crypto amount before commitment?** Use `GET /v1/estimate` — note the estimate is not locked until you call `POST /v1/payment` with `fixed_rate: true`.

## 2. POST /v1/payment — Create Payment

Creates a one-time payment and returns a deposit address.

```
POST https://api.nowpayments.io/v1/payment
Headers: x-api-key: <YOUR_API_KEY>, Content-Type: application/json
```

### Request Parameters

| Parameter | Required | Type | Description |
|---|---|---|---|
| price_amount | Yes | number | Amount the merchant wants to receive (in price_currency) |
| price_currency | Yes | string | Fiat or crypto currency of the price (e.g., "usd", "eur", "btc") |
| pay_currency | Yes | string | Cryptocurrency the customer will pay in (e.g., "btc", "eth") |
| pay_amount | No | number | Exact crypto amount; if omitted, calculated from price_amount |
| ipn_callback_url | No | string | URL to receive IPN (Instant Payment Notification) webhooks |
| order_id | No | string | Your internal order identifier (max 256 chars) |
| order_description | No | string | Description shown to the customer (max 512 chars) |
| purchase_id | No | string | Groups related payments (used for partial payment flows) |
| payout_address | No | string | Override default payout wallet address |
| payout_currency | No | string | Override default payout currency |
| payout_extra_id | No | string | Extra ID for payout (e.g., memo for XRP, destination tag for XLM) |
| fixed_rate | No | boolean | Lock the exchange rate at creation time (default: false) |
| is_fee_paid_by_user | No | boolean | If true, network fees are added on top of pay_amount (default: false) |
| case | No | string | Use case identifier for advanced routing |

### Example Request

```json
{
  "price_amount": 100, "price_currency": "usd", "pay_currency": "btc",
  "ipn_callback_url": "https://yourapp.com/api/nowpayments/ipn",
  "order_id": "ORD-2026-00417",
  "order_description": "Pro Plan — Annual Subscription",
  "fixed_rate": true, "is_fee_paid_by_user": true
}
```

### Response Schema

```json
{
  "payment_id": 5746832190,
  "payment_status": "waiting",
  "pay_address": "3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy",
  "price_amount": 100, "price_currency": "usd",
  "pay_amount": 0.001534, "pay_currency": "btc",
  "amount_received": 0,
  "order_id": "ORD-2026-00417",
  "order_description": "Pro Plan — Annual Subscription",
  "ipn_callback_url": "https://yourapp.com/api/nowpayments/ipn",
  "created_at": "2026-02-25T14:30:00.000Z",
  "updated_at": "2026-02-25T14:30:00.000Z",
  "purchase_id": null, "payment_extra_ids": null,
  "smart_contract": null, "network": "btc", "network_precision": 8,
  "time_limit": null, "burning_percent": null,
  "expiration_estimate_date": "2026-02-25T14:50:00.000Z"
}
```

### Key Behaviors

- **pay_address** is single-use. Each payment gets a unique deposit address. Never reuse addresses across payments.
- **expiration_estimate_date** is ~20 minutes after creation. After this, the exchange rate estimate expires and the customer may need to pay a different amount. Use the refresh endpoint (Section 5) for updated rates.
- **Payment expiry**: the entire payment expires after 24 hours. Funds sent after expiry may be lost. Your UI must communicate this deadline clearly.
- When `fixed_rate` is `true`, the rate is locked until `expiration_estimate_date`. After expiry, the rate floats.

See `nowpayments_helper.ts` for the `createPayment()` wrapper that handles parameter validation and error formatting.

## 3. GET /v1/payment/{id} — Payment Status

Retrieves the current status and details of a specific payment.

```
GET https://api.nowpayments.io/v1/payment/5746832190
Headers: x-api-key: <YOUR_API_KEY>
```

**Important**: You must use the same API key that created the payment. Querying a payment created under a different key returns a 404.

The response includes all fields from the creation response, plus these once the customer has sent funds:

| Field | Type | Description |
|---|---|---|
| actually_paid | number | Actual crypto amount received at the pay_address |
| outcome_amount | number | Amount sent (or being sent) to your payout address |
| outcome_currency | string | Currency of the payout |

### Detecting Under/Overpayments

Compare `actually_paid` against `pay_amount`:

| Condition | Meaning | Next Step |
|---|---|---|
| `actually_paid == 0` | Not yet paid | Continue polling or wait for IPN |
| `actually_paid >= pay_amount` | Fully paid | Await `confirmed` or `finished` status |
| `0 < actually_paid < pay_amount` | Underpayment | Status becomes `partially_paid` — see Section 9 |
| `actually_paid > pay_amount * 1.1` | Significant overpay | Contact support — see Section 10 |

Minor overpayments (within network fee variance) are processed normally.

## 4. GET /v1/payment/ — List Payments

Lists all payments associated with your account. Requires both API key and JWT authentication.

```
GET https://api.nowpayments.io/v1/payment/?limit=25&page=0&sortBy=created_at&orderBy=desc
Headers: x-api-key: <YOUR_API_KEY>, Authorization: Bearer <JWT_TOKEN>
```

| Parameter | Default | Description |
|---|---|---|
| limit | 10 | Results per page (max 500) |
| page | 0 | Zero-indexed page number |
| sortBy | "created_at" | Field to sort by |
| orderBy | "asc" | Sort direction: "asc" or "desc" |
| dateFrom | — | Payments created on or after this date |
| dateTo | — | Payments created on or before this date |

Response: `{ "data": [...], "limit": 25, "page": 0, "pagesCount": 4, "total": 87 }`

Each item in `data` follows the same schema as the single-payment response. See `nowpayments_helper.ts` for JWT token acquisition via `POST /v1/auth`.

## 5. POST /v1/payment/{id}/update-merchant-estimate — Refresh Estimate

Refreshes the exchange rate estimate for an existing payment.

```
POST https://api.nowpayments.io/v1/payment/5746832190/update-merchant-estimate
Headers: x-api-key: <YOUR_API_KEY>
```

| Timing | Result |
|---|---|
| Before `expiration_estimate_date` | Returns the current estimate unchanged |
| After `expiration_estimate_date` | Recalculates `pay_amount` using current market rates |

**When to use**: Customer has not paid within the ~20-minute estimate window. Typical flow:

1. Create payment at 14:30 — `expiration_estimate_date` is 14:50.
2. Customer opens the payment page at 15:05.
3. Your frontend detects the estimate has expired.
4. Call `update-merchant-estimate` to get a fresh `pay_amount`.
5. Display the updated amount to the customer.

The payment itself remains valid for 24 hours. Only the rate estimate expires at the 20-minute mark. If `fixed_rate` was `true`, the refreshed estimate uses the new current rate — the original locked rate is gone after expiry.

## 6. POST /v1/invoice — Create Invoice

Creates a hosted invoice page that the customer visits to complete payment.

```
POST https://api.nowpayments.io/v1/invoice
Headers: x-api-key: <YOUR_API_KEY>, Content-Type: application/json
```

### Request Parameters

| Parameter | Required | Type | Description |
|---|---|---|---|
| price_amount | Yes | number | Amount the merchant wants to receive |
| price_currency | Yes | string | Fiat or crypto currency of the price |
| pay_currency | No | string | Pre-select a crypto; if omitted, customer chooses on the page |
| ipn_callback_url | No | string | URL to receive IPN webhooks |
| order_id | No | string | Your internal order identifier |
| order_description | No | string | Description displayed on the invoice page |
| success_url | No | string | Redirect URL after successful payment |
| cancel_url | No | string | Redirect URL if customer cancels |
| partially_paid_url | No | string | Redirect URL if payment is only partially completed |
| is_fee_paid_by_user | No | boolean | Network fees added on top (default: false) |
| is_fixed_rate | No | boolean | Lock the exchange rate (default: false) |

### Example Request

```json
{
  "price_amount": 49.99, "price_currency": "usd",
  "order_id": "INV-2026-00218", "order_description": "Starter Plan — Monthly",
  "success_url": "https://yourapp.com/payment/success",
  "cancel_url": "https://yourapp.com/payment/cancel",
  "ipn_callback_url": "https://yourapp.com/api/nowpayments/ipn"
}
```

### Response

```json
{
  "id": "6142908753",
  "order_id": "INV-2026-00218", "order_description": "Starter Plan — Monthly",
  "price_amount": 49.99, "price_currency": "usd", "pay_currency": null,
  "ipn_callback_url": "https://yourapp.com/api/nowpayments/ipn",
  "invoice_url": "https://nowpayments.io/payment/?iid=6142908753",
  "success_url": "https://yourapp.com/payment/success",
  "cancel_url": "https://yourapp.com/payment/cancel",
  "partially_paid_url": null,
  "created_at": "2026-02-25T15:00:00.000Z",
  "updated_at": "2026-02-25T15:00:00.000Z"
}
```

### Key Behavior

- When `pay_currency` is omitted, the hosted page presents a currency selector. This is the simplest integration path.
- **Redirect the customer to `invoice_url`**. NOWPayments does not support iframe embedding.
- The `success_url` redirect is triggered client-side at `confirmed`/`finished`. It is not a guarantee of finality — always verify via IPN or polling.

## 7. POST /v1/invoice-payment — Create Payment from Invoice

Converts an existing invoice into a concrete payment for a specific cryptocurrency.

```
POST https://api.nowpayments.io/v1/invoice-payment
Headers: x-api-key: <YOUR_API_KEY>, Content-Type: application/json
```

| Parameter | Required | Type | Description |
|---|---|---|---|
| iid | Yes | string | Invoice ID from `POST /v1/invoice` |
| pay_currency | Yes | string | Cryptocurrency the customer will pay in |
| purchase_id | No | string | Groups this payment with others (partial payment flow) |
| order_description | No | string | Override the invoice's order_description |
| customer_email | No | string | Customer email for payment receipt |
| payout_address | No | string | Override default payout wallet |
| payout_currency | No | string | Override default payout currency |
| payout_extra_id | No | string | Extra ID for payout (memo, tag, etc.) |

**When to use**: An invoice exists but you need to programmatically create the payment rather than using the hosted page. Common cases: customer wants to switch currencies, you want full UI control, or you need a `purchase_id` for partial payment tracking. Response follows the same schema as `POST /v1/payment`.

## 8. Payment Status Lifecycle Deep Dive

Every payment moves through a defined set of statuses.

### Status Reference Table

| Status | Description |
|---|---|
| `waiting` | Payment created, waiting for customer to send crypto |
| `confirming` | Transaction detected on-chain, waiting for required confirmations |
| `confirmed` | Required confirmations reached; funds are secure |
| `sending` | NOWPayments is sending the converted amount to your payout address |
| `partially_paid` | Customer sent less than the required amount |
| `finished` | Payout complete — funds sent to your wallet |
| `failed` | Payment failed (timeout, blockchain error, or processing issue) |
| `refunded` | Payment was refunded to the customer |
| `expired` | 24-hour payment window elapsed with no transaction detected |

### Typical Success Flow

```
waiting → confirming → confirmed → sending → finished
```

Time from `waiting` to `confirming` depends on when the customer sends. `confirming` to `confirmed` depends on the blockchain's confirmation count (1 for LTC, 2 for BTC, 12 for ETH). `sending` to `finished` is typically under 5 minutes.

### Status-Specific Fields

| Field | Available From | Description |
|---|---|---|
| actually_paid | `confirming` | Crypto amount detected in the incoming tx |
| outcome_amount | `sending` | Converted amount being sent to your wallet |
| outcome_currency | `sending` | Currency of the payout |

### Actions by Status

| Status | Show to Customer | Server-Side Action |
|---|---|---|
| `waiting` | Pay address, QR code, countdown timer | Poll every 30s or await IPN |
| `confirming` | "Payment detected, awaiting confirmation" | Continue polling |
| `confirmed` | "Payment confirmed, processing payout" | Safe to mark order as paid |
| `sending` | "Sending to your wallet" | No action needed |
| `partially_paid` | "Partial payment received" | Create follow-up payment with same `purchase_id` (Sec. 9) |
| `finished` | "Payment complete" | Finalize order, send receipt |
| `failed` | "Payment failed — contact support" | Log failure, alert ops team |
| `refunded` | "Refund processed" | Reverse the order |
| `expired` | "Payment expired" | Offer to create a new payment |

### Important Notes

- **Do not treat `confirmed` as final for payouts.** Incoming funds are secure, but payout has not been sent yet. Wait for `finished` before considering the payout complete.
- **Treat `confirmed` as safe for order fulfillment.** Blockchain confirmation makes reversal negligible. Ship goods or activate services at `confirmed`.
- The `failed` status is rare and typically indicates a blockchain-level issue. Customer funds are not lost — contact NOWPayments support for resolution.

## 9. Partial Payments

When a customer sends less than `pay_amount`, the payment enters `partially_paid`. NOWPayments supports collecting the remainder through linked follow-up payments.

### How purchase_id Linking Works

The `purchase_id` groups multiple payments. When all payments sharing the same `purchase_id` collectively reach `price_amount`, the purchase is fulfilled.

1. Create the initial payment with a `purchase_id`.
2. If status becomes `partially_paid`, read `actually_paid` to determine the shortfall.
3. Create a new payment with the same `purchase_id` for the remaining amount.
4. Repeat until the total received meets or exceeds the required amount.

### Step-by-Step Flow

1. **Save the purchase_id** at creation. If you did not provide one, NOWPayments assigns one automatically — retrieve it from the status response.
2. **Detect `partially_paid`** via IPN webhook or polling.
3. **Calculate remaining**: `remaining = price_amount - (actually_paid * current_exchange_rate)`. Use the estimate endpoint to convert `actually_paid` back to the price currency.
4. **Create a new payment** with the same `purchase_id` and the remaining `price_amount`.
5. **Present the new pay_address** to the customer for the second installment.

### TypeScript Example

```typescript
import { createPayment, getPaymentStatus, getEstimate } from "./nowpayments_helper";

async function handlePartialPayment(paymentId: number, purchaseId: string): Promise<void> {
  const s = await getPaymentStatus(paymentId);
  if (s.payment_status !== "partially_paid") return;
  const est = await getEstimate(s.actually_paid, s.pay_currency, s.price_currency);
  const remaining = s.price_amount - est.estimated_amount;
  if (remaining <= 0) return;
  const followUp = await createPayment({
    price_amount: remaining, price_currency: s.price_currency, pay_currency: s.pay_currency,
    purchase_id: purchaseId, order_id: s.order_id,
    order_description: `Remainder for ${s.order_id}`, ipn_callback_url: s.ipn_callback_url,
  });
  console.log(`Follow-up ${followUp.payment_id}: ${followUp.pay_amount} ${followUp.pay_currency} → ${followUp.pay_address}`);
}
```

### Python Example

```python
import requests
API_KEY, BASE = "YOUR_API_KEY", "https://api.nowpayments.io/v1"
HEADERS = {"x-api-key": API_KEY, "Content-Type": "application/json"}

def handle_partial_payment(payment_id: int, purchase_id: str) -> dict | None:
    s = requests.get(f"{BASE}/payment/{payment_id}", headers=HEADERS).json()
    if s["payment_status"] != "partially_paid": return None
    est = requests.get(f"{BASE}/estimate", headers=HEADERS, params={
        "amount": s["actually_paid"], "currency_from": s["pay_currency"], "currency_to": s["price_currency"]
    }).json()["estimated_amount"]
    remaining = s["price_amount"] - est
    if remaining <= 0: return None
    return requests.post(f"{BASE}/payment", headers=HEADERS, json={
        "price_amount": remaining, "price_currency": s["price_currency"], "pay_currency": s["pay_currency"],
        "purchase_id": purchase_id, "order_id": s["order_id"],
        "order_description": f"Remainder for {s['order_id']}", "ipn_callback_url": s["ipn_callback_url"],
    }).json()
```

## 10. Overpayments

When a customer sends significantly more than `pay_amount`, NOWPayments may not process the excess automatically.

- **Minor overpayments** (within network fee variance, roughly up to 5%) are processed normally. `actually_paid` reflects the true amount, and `outcome_amount` may be slightly higher.
- **Significant overpayments** may stall or require manual intervention.

**Resolution**: There is no self-service refund API endpoint. Contact **support@nowpayments.io** with the `payment_id`, `actually_paid` amount, and the customer's refund address. Support processes corrections manually.

**Prevention**: Display the exact `pay_amount` prominently and warn against sending more. In automated systems, enforce exact-amount sends.

## 11. Direct vs Invoice Flow Decision Tree

### Direct Payment Flow (`POST /v1/payment`)

**Use when:** You want full UI control, display `pay_address` and QR code in your own interface, know the cryptocurrency upfront, or need `purchase_id` at creation time for partial payment support.

**Trade-offs:** You manage countdown timers, status polling, and expired-estimate UX (`update-merchant-estimate`). More engineering effort but complete branding control.

### Invoice Flow (`POST /v1/invoice`)

**Use when:** You want the simplest integration, are fine with a NOWPayments-hosted page, want the customer to choose their cryptocurrency, or do not need granular payment UI control.

**Trade-offs:** Redirect to `invoice_url` — NOWPayments handles everything. `success_url`, `cancel_url`, and `partially_paid_url` control returns. Less engineering effort but limited branding.

### Fixed-Rate vs Floating-Rate

| Aspect | Fixed Rate (`fixed_rate: true`) | Floating Rate (default) |
|---|---|---|
| Rate lock | Locked for ~20 min (until estimate expiry) | Fluctuates with market until payment |
| Customer UX | Exact amount known upfront | Amount may change if customer delays |
| Merchant risk | NOWPayments absorbs rate volatility | Customer absorbs rate changes |
| Availability | Slightly higher minimum amounts | Lower minimums |

### Fee Implications

When `is_fee_paid_by_user` is `false` (default), network fee is deducted from the payment — you receive slightly less than `price_amount`. When `true`, the fee is added on top — customer pays more but you receive the full amount.

- **Inclusive pricing** (you absorb fees): `is_fee_paid_by_user: false`
- **Exclusive pricing** (customer pays fees): `is_fee_paid_by_user: true`

## 12. Complete Payment Flow Examples

### TypeScript — End-to-End Direct Payment

```typescript
import { getMinAmount, createPayment, getPaymentStatus } from "./nowpayments_helper";

async function processDirectPayment(amountUsd: number, payCurrency: string, orderId: string, ipnUrl: string) {
  // Step 1: Validate minimum
  const min = await getMinAmount("usd", payCurrency);
  if (amountUsd < min.min_amount) throw new Error(`$${amountUsd} below min $${min.min_amount}`);

  // Step 2: Create payment
  const p = await createPayment({
    price_amount: amountUsd, price_currency: "usd", pay_currency: payCurrency,
    order_id: orderId, ipn_callback_url: ipnUrl, fixed_rate: true, is_fee_paid_by_user: true,
  });
  console.log(`Payment ${p.payment_id}: ${p.pay_amount} ${p.pay_currency} → ${p.pay_address}`);

  // Step 3: Poll (in production, prefer IPN webhooks)
  const terminal = ["finished", "failed", "refunded", "expired"];
  let status = p.payment_status, data: any = p;
  while (!terminal.includes(status)) {
    await new Promise((r) => setTimeout(r, 30_000));
    data = await getPaymentStatus(p.payment_id);
    status = data.payment_status;
    if (status === "partially_paid") break;
  }
  return { success: status === "finished", paymentId: p.payment_id, status,
    outcomeAmount: data.outcome_amount, outcomeCurrency: data.outcome_currency };
}

processDirectPayment(100, "btc", "ORD-2026-00417", "https://yourapp.com/api/nowpayments/ipn")
  .then((r) => console.log(r.success ? `Done: ${r.outcomeAmount} ${r.outcomeCurrency}` : r.status))
  .catch(console.error);
```

### Python — End-to-End Direct Payment

```python
import time, requests

API_KEY, BASE = "YOUR_API_KEY", "https://api.nowpayments.io/v1"
HEADERS = {"x-api-key": API_KEY, "Content-Type": "application/json"}

def process_direct_payment(amount_usd: float, pay_currency: str, order_id: str, ipn_url: str) -> dict:
    # Step 1: Validate minimum
    min_amt = requests.get(f"{BASE}/min-amount", headers=HEADERS,
        params={"currency_from": "usd", "currency_to": pay_currency}).json()["min_amount"]
    if amount_usd < min_amt: raise ValueError(f"${amount_usd} below min ${min_amt}")

    # Step 2: Create payment
    p = requests.post(f"{BASE}/payment", headers=HEADERS, json={
        "price_amount": amount_usd, "price_currency": "usd", "pay_currency": pay_currency,
        "order_id": order_id, "ipn_callback_url": ipn_url, "fixed_rate": True, "is_fee_paid_by_user": True,
    }).json()
    pid = p["payment_id"]
    print(f"Payment {pid}: {p['pay_amount']} {p['pay_currency']} → {p['pay_address']}")

    # Step 3: Poll (in production, prefer IPN webhooks)
    terminal, status, data = {"finished", "failed", "refunded", "expired"}, p["payment_status"], p
    while status not in terminal:
        time.sleep(30)
        data = requests.get(f"{BASE}/payment/{pid}", headers=HEADERS).json()
        status = data["payment_status"]
        if status == "partially_paid": break

    return {"success": status == "finished", "payment_id": pid, "status": status,
            "outcome_amount": data.get("outcome_amount"), "outcome_currency": data.get("outcome_currency")}

if __name__ == "__main__":
    r = process_direct_payment(100, "btc", "ORD-2026-00417", "https://yourapp.com/api/nowpayments/ipn")
    print(f"{'Complete' if r['success'] else 'Ended'}: {r['status']}")
```
