---
name: tech-debt-audit
description: "Auditoria de deuda tecnica, mantenibilidad y revision estructural de repositorios. Usar cuando el usuario pida auditoria, deuda tecnica, saneamiento de repo, revision de arquitectura, hotspots, mantenibilidad, refactor amplio, plan de remediacion o priorizacion de riesgos tecnicos. Por defecto opera en solo lectura, sin modificar archivos, instalar paquetes, usar red ni ejecutar acciones costosas sin permiso explicito."
---

# Auditoría de Deuda Técnica

## Proposito

Esta skill guia auditorias tecnicas de repositorios con evidencia concreta, priorizacion accionable y respeto estricto del flujo operativo del repo. El objetivo es separar deuda real, deuda aceptada y mejoras opcionales sin convertir la auditoria en remediacion automatica.

Aplica patrones publicos de auditoria de deuda tecnica y criterios de mantenibilidad del equipo.

## Principios operativos

- Encontrar lo que esta realmente mal, no producir una lista generica de buenas practicas.
- Leer codigo, docs y churn antes de juzgar; una forma rara puede ser una garantia operativa.
- No rellenar categorias. Si no hay hallazgos materiales, decirlo.
- No recomendar reescrituras completas. Proponer cambios especificos, acotados y revisables en PRs pequenos.
- Si no se puede distinguir deuda de decision intencional, ponerlo en preguntas abiertas.
- Si el modelo mental contradice README, docs o reglas operativas, tratarlo como senal auditable.

## Reglas de seguridad

- Operar en solo lectura por defecto.
- No editar archivos, no aplicar parches, no crear commits, no hacer push, no abrir PRs y no desplegar.
- No instalar paquetes, no descargar herramientas con `npx`, no usar red ni correr comandos costosos sin permiso explicito.
- Priorizar herramientas ya presentes en el repo: `rg`, `git`, manifests, scripts existentes y comandos de validacion declarados.
- Cargar skills de dominio si la auditoria entra en tecnologia con skill obligatorio.
- Cargar tu skill de documentacion (p. ej. `docs-as-code`) antes de escribir un reporte formal dentro de `docs/`.
- Cargar tu skill de revision de PRs antes de cualquier operacion GitHub, PR, push, merge o revision de comentarios.

## Flujo de auditoria

1. Confirmar alcance: repo completo, subsistema, PR, carpeta o tecnologia.
2. Leer instrucciones locales: `AGENTS.md`, `CLAUDE.md`, docs de arquitectura, manifests y scripts relevantes.
3. Recopilar senales de solo lectura y escribir un modelo mental breve antes de auditar. Ver `references/repo-signals.md`.
4. En primera auditoria de un repo o alcance grande, hacer checkpoint breve: que sorprendio, que contradice docs y que investigar fuera de las dimensiones base.
5. Auditar dimensiones generales de deuda. Ver `references/audit-dimensions.md`.
6. Cargar checks por stack solo para los subsistemas auditados. Ver `references/stack-checks.md`.
7. Clasificar hallazgos con severidad, esfuerzo, confianza y evidencia. Ver `references/severity-rubric.md`.
8. Entregar reporte en conversacion por defecto o Markdown formal si se pidio. Ver `references/output-template.md`.

## Requisitos de evidencia

- Citar `archivo:linea` para cada hallazgo verificable en codigo o documentacion.
- Marcar como inferencia cualquier conclusion que combine varias senales.
- No inflar la auditoria: no hay minimo de hallazgos.
- Separar hallazgos, observaciones y mejoras opcionales.
- Incluir siempre una seccion "Parece deuda pero esta justificado".
- Incluir preguntas abiertas cuando falte contexto de intencion.

## Exclusiones por defecto

- Archivos generados, lockfiles, build artifacts, caches, snapshots, vendored code y migraciones historicas.
- Revisarlos solo si el usuario lo pide o si hay evidencia concreta de riesgo.

## Salidas

- Conversacion: resumen ejecutivo, hallazgos priorizados, justificados, plan de remediacion y riesgos residuales.
- Markdown formal versionado: `docs/explanation/audits/` y con tu skill de documentacion cargada antes de escribir.
- Artefacto operativo no versionado: `.claude/audits/` solo si el usuario lo aprueba explicitamente.
- Si ya existe una auditoria previa en el destino acordado, leerla primero y marcar hallazgos como nuevos, vigentes, resueltos o desactualizados.

## Referencias

- `references/repo-signals.md`: senales base y comandos de inspeccion.
- `references/audit-dimensions.md`: dimensiones generales de deuda tecnica.
- `references/stack-checks.md`: criterios por stack y riesgos especificos.
- `references/severity-rubric.md`: clasificacion de severidad, esfuerzo y confianza.
- `references/output-template.md`: formatos de salida conversacional y formal.
