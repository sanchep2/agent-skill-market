# tech-debt-audit — Skill de Claude Code

Auditoría de **deuda técnica**, mantenibilidad y revisión estructural de repositorios, con evidencia
concreta (`archivo:línea`), priorización accionable y respeto estricto del flujo operativo del repo.
Por defecto opera en **solo lectura**: no edita archivos, no instala paquetes, no usa red ni ejecuta
comandos costosos sin permiso explícito. Separa deuda real, deuda aceptada y mejoras opcionales sin
convertir la auditoría en remediación automática.

## Contenido

- `SKILL.md` — punto de entrada: principios, reglas de seguridad, flujo de auditoría de 8 pasos y
  requisitos de evidencia.
- `references/repo-signals.md` — señales base y comandos de inspección de solo lectura.
- `references/audit-dimensions.md` — dimensiones generales de deuda técnica.
- `references/stack-checks.md` — criterios y riesgos específicos por stack.
- `references/severity-rubric.md` — clasificación de severidad, esfuerzo y confianza.
- `references/output-template.md` — formatos de salida (conversacional y Markdown formal versionado).

Se integra con tu skill de documentación (para escribir reportes formales en `docs/`) y con tu skill
de revisión de PRs (antes de cualquier operación GitHub).

## Instalación

1. Descomprime el ZIP.
2. Copia la carpeta `tech-debt-audit/` a una de estas ubicaciones:
   - **Global (todos tus proyectos)**: `~/.claude/skills/tech-debt-audit/`
   - **Solo este proyecto**: `<tu-proyecto>/.claude/skills/tech-debt-audit/`
3. Reinicia Claude Code para que detecte el skill.

Verifica que quede así (ejemplo global):

```
~/.claude/skills/tech-debt-audit/
├── SKILL.md
└── references/
    ├── repo-signals.md
    ├── audit-dimensions.md
    ├── stack-checks.md
    ├── severity-rubric.md
    └── output-template.md
```

## Uso

Claude Code carga el skill automáticamente cuando pides una auditoría, revisión de deuda técnica,
saneamiento de repo, revisión de arquitectura, hotspots o un plan de remediación. También puedes
invocarlo de forma explícita mencionándolo por su nombre.

---

Cortesía de Talent Academy · Vibe Coder.
