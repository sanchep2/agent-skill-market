# Dimensiones de Auditoria

Auditar estas dimensiones despues de la orientacion inicial. No forzar hallazgos en todas; si una dimension no tiene material relevante, indicarlo.

## 1. Decaimiento arquitectonico

- Dependencias circulares.
- Violaciones de capas.
- Archivos o funciones que concentran demasiadas responsabilidades.
- Logica duplicada en 3+ lugares donde una abstraccion reduciria riesgo.
- Abstracciones existentes que nadie usa.
- Codigo muerto, ramas inalcanzables o bloques comentados obsoletos.

## 2. Deriva de consistencia

- Multiples formas de hacer lo mismo: HTTP, errores, logging, configuracion, validacion, fechas.
- Naming drift entre modulos.
- Estructura de carpetas que contradice el comportamiento real.
- Convenciones locales aplicadas solo en parte del repo.

## 3. Deuda de tipos y contratos

- `any`, `unknown`, casts laxos, `type: ignore` o diccionarios sin forma.
- Limites externos sin validacion.
- Contratos API no documentados o no versionados.
- Datos opcionales tratados como obligatorios.

## 4. Deuda de pruebas

- Rutas criticas sin tests ni verificacion equivalente.
- Tests que verifican implementacion en vez de comportamiento.
- Tests saltados, flaky o demasiado acoplados al orden interno.
- Archivos de alto churn sin cobertura cercana.

## 5. Dependencias y configuracion

- Dependencias duplicadas para la misma funcion.
- Dependencias aparentemente no usadas, solo si hay evidencia o tooling local.
- Variables de entorno referenciadas pero no documentadas.
- Defaults inconsistentes entre entornos, scripts y docs.
- Configuracion repetida entre workflows, scripts y runtime.

## 6. Rendimiento y recursos

- N+1 queries o llamadas repetidas en hot paths.
- Trabajo sincrono en rutas asincronas.
- I/O bloqueante en endpoints o jobs criticos.
- Listeners, handles o timers sin limpieza.
- Serializacion o transformaciones innecesarias en bucles frecuentes.

## 7. Errores y observabilidad

- Excepciones tragadas o catches demasiado amplios.
- Errores registrados pero no tratados.
- Shapes de error inconsistentes.
- Falta de logs estructurados en flujos criticos.
- Mensajes sin contexto operativo para diagnostico.

## 8. Higiene de seguridad

- Secretos hardcoded.
- Validacion insuficiente en limites de confianza.
- CORS, auth o permisos demasiado permisivos.
- Criptografia debil o API incorrecta para el runtime.
- Construccion insegura de queries, comandos o URLs.

## 9. Deriva de documentacion

- README, docs o comentarios que contradicen el codigo.
- APIs publicas sin referencia suficiente.
- Checklists que no reflejan CI, deploy o operacion real.
- Contadores, diagramas o tablas desactualizadas.
