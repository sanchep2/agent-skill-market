# Senales de Repositorio

Usar estas senales para orientar la auditoria antes de juzgar deuda. Ejecutar solo comandos de lectura y adaptar al repo.

## Orientacion inicial

- Leer `AGENTS.md`, `CLAUDE.md`, `README.md`, docs de arquitectura, manifests y workflows.
- Identificar stacks por archivos: `package.json`, `pyproject.toml`, `requirements*.txt`, `convex/`, `portal/`, `apps/`, `.github/workflows/`.
- Detectar scripts declarados antes de proponer herramientas externas.
- Verificar rama y base con `git status --short --branch` y `git log --oneline -n 5`.
- Revisar historia reciente con `git log --oneline -200` y `git log --stat --since="6 months ago"`.
- Mapear entrypoints, hot paths, cold corners y limites entre capas.
- Escribir un modelo mental de 1-2 parrafos antes de emitir hallazgos.
- Si el modelo mental contradice README, docs o reglas operativas, registrarlo como hallazgo o pregunta abierta.

## Hotspots

- Churn: `git log --name-only --format= --since="6 months ago" | sort | uniq -c | sort -nr | head -20`.
- Archivos grandes: `rg --files -0 | xargs -0 wc -l | sort -nr | head -20`.
- Archivos muy tocados y grandes: cruzar churn con conteo de lineas.
- Cambios recientes en rutas criticas: `git log --oneline -- <path>`.
- En repos grandes, auditar por modulo y sintetizar; no leer serialmente hasta agotar contexto.

## Mantenibilidad

- Duplicacion de patrones manuales.
- Funciones o modulos que mezclan UI, reglas de negocio, red y persistencia.
- Helpers con nombres genericos que esconden side effects.
- Configuracion duplicada entre docs, scripts, workflows y runtime.
- Comentarios o docs que contradicen codigo actual.
- Abstracciones que existen pero no se usan.
- Carpetas cuyo nombre ya no describe lo que contienen.

## Calidad y tests

- Mapear comandos disponibles en manifests antes de recomendar nuevos.
- Identificar ausencia de tests solo como riesgo contextual, no como hallazgo automatico.
- Comparar checks documentados contra workflows reales.
- Revisar si hay tests orientados a contratos externos, errores historicos o rutas criticas.
- Detectar archivos de alto churn sin pruebas cercanas o sin validacion equivalente.

## Tooling por stack

Usar tooling nativo solo si ya esta declarado, instalado o autorizado por el usuario. Si falta una herramienta, anotarlo como limitacion y seguir.

- TypeScript/JavaScript: scripts de `package.json`, `tsc --noEmit`, linters locales, analizadores de dependencias ya presentes.
- Python: `ruff`, `mypy`, `pip-audit`, `vulture` o equivalentes solo si estan disponibles en el entorno/proyecto.
- Rust: `cargo check`, `cargo clippy`, auditoria de dependencias solo si la herramienta ya existe.
- Go: `go test`, `go vet`, `staticcheck` o `golangci-lint` solo si estan disponibles.
- Seguridad: escaneo de secretos o vulnerabilidades solo con tooling local existente o permiso explicito.

## Dependencias

- Revisar manifests y lockfiles solo para detectar senales de riesgo; no auditar lockfiles linea por linea.
- Buscar dependencias no usadas solo con herramientas ya presentes o evidencia directa.
- No recomendar downgrades.
- Separar riesgo de version obsoleta de riesgo explotable.

## Exclusiones

Excluir salvo peticion explicita:

- Archivos generados.
- Lockfiles.
- Build artifacts.
- Caches.
- Snapshots.
- Vendored code.
- Migraciones historicas.
