# Rubrica de Severidad

Cada hallazgo debe incluir severidad, esfuerzo, confianza y evidencia. No usar severidad alta sin impacto concreto.

## Severidad

| Nivel | Criterio |
|---|---|
| Critica | Puede causar perdida de dinero, caida de produccion, fuga de secretos, corrupcion de datos o bloqueo de deploy. |
| Alta | Riesgo probable en flujo critico, deuda que impide cambios seguros o bug latente con impacto claro. |
| Media | Mantenibilidad degradada, duplicacion peligrosa, contratos ambiguos o cobertura insuficiente en zona importante. |
| Baja | Limpieza localizada, mejora de claridad, inconsistencia menor o deuda con bajo impacto operativo. |

## Esfuerzo

| Nivel | Criterio |
|---|---|
| Bajo | Cambio acotado a 1-2 archivos, sin migracion ni coordinacion. |
| Medio | Requiere varios archivos, tests nuevos o coordinacion entre capas. |
| Alto | Requiere diseno, migracion, rollout, cambios de contratos o multiples PRs. |

## Confianza

| Nivel | Criterio |
|---|---|
| Alta | Evidencia directa con `archivo:linea`, comando o contrato verificable. |
| Media | Varias senales consistentes, pero falta una prueba directa. |
| Baja | Sospecha razonable; presentar como pregunta o investigacion recomendada. |

## Reglas de clasificacion

- No mezclar preferencia de estilo con riesgo tecnico.
- No duplicar hallazgos: agrupar sintomas con una causa raiz comun.
- No reportar ausencia de abstraccion como deuda si el codigo es simple y estable.
- No penalizar duplicacion intencional cuando reduce acoplamiento o riesgo de cambio.
- Si falta contexto de negocio, marcar la incertidumbre.
