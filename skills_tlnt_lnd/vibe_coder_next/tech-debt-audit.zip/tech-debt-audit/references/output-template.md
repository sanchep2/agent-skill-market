# Plantillas de Salida

## Salida conversacional

Usar este formato por defecto cuando el usuario pide opinion, revision o auditoria sin pedir archivo.

```markdown
**Resumen**
Audite <alcance>. Los riesgos principales son <1-3 temas>. No modifique archivos.

**Modelo mental**
1-2 parrafos sobre como esta organizado realmente el sistema y donde se concentran los riesgos.

**Hallazgos**
1. [Severidad / esfuerzo / confianza] Titulo
   Evidencia: `archivo:linea`
   Impacto: ...
   Remediacion: ...

**Top 5**
1. Hallazgo que mas conviene resolver si solo se arregla una cosa.

**Quick wins**
- [ ] Hallazgo de esfuerzo bajo e impacto medio o superior.

**Parece deuda pero esta justificado**
- `archivo:linea`: explicar por que no conviene cambiarlo ahora.

**Preguntas abiertas**
- Pregunta que distingue deuda real de decision intencional.

**Siguiente paso recomendado**
Proponer 1-3 PRs pequenos o investigaciones concretas.
```

## Markdown formal versionado

Usar solo si el usuario pide auditoria formal o artefacto versionado. Ruta por defecto:

`docs/explanation/audits/YYYY-MM-DD-alcance.md`

Antes de escribir en `docs/`, cargar tu skill de documentacion (p. ej. `docs-as-code`) y respetar Diataxis.

```markdown
---
title: "Auditoria tecnica: <alcance>"
created: YYYY-MM-DD
updated: YYYY-MM-DD
author: github-username
status: active
---

# Auditoria tecnica: <alcance>

## Resumen

- Alcance:
- Rama/commit:
- Fecha:
- Modo: solo lectura

## Comandos de inspeccion

- `comando`

## Modelo mental

Describir como esta organizado realmente el sistema y senalar contradicciones con docs si existen.

## Hallazgos priorizados

| ID | Categoria | Evidencia | Severidad | Esfuerzo | Confianza | Hallazgo | Recomendacion |
|---|---|---|---|---|---|---|---|
| F001 | Arquitectura | `archivo:linea` | Alta | Medio | Alta | ... | ... |

## Top 5

1. F001 - ...

## Quick wins

- [ ] F042 - ...

## Detalle

### F001 - <titulo>

Evidencia: `archivo:linea`

Impacto:

Remediacion:

## Parece deuda pero esta justificado

- `archivo:linea`: ...

## Preguntas abiertas

- ...

## Plan de remediacion

1. PR pequeno:
2. PR pequeno:
3. Investigacion:

## Riesgos residuales

- ...
```

## Artefacto operativo no versionado

Usar `.claude/audits/` solo con aprobacion explicita del usuario. No usarlo como sustituto de documentacion formal.

## Modo repeticion

Si existe una auditoria previa en la ruta acordada, leerla antes de auditar y clasificar:

- `NEW`: hallazgo nuevo.
- `VIGENTE`: hallazgo previo que sigue aplicando.
- `RESUELTO`: hallazgo previo ya no observable.
- `DESACTUALIZADO`: hallazgo previo que requiere reformularse por cambios del repo.
