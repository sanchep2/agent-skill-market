# Checks por Stack

Este archivo define que auditar por stack. No duplica la arquitectura del repo; para ubicaciones y fuente de verdad, leer `CLAUDE.md`.

## Convex

- Rutas HTTP estaticas, sin parametros dinamicos tipo `/:id`.
- Handlers HTTP registrados con metodo principal y `OPTIONS`.
- CORS centralizado en `convex/cors.ts`.
- Validadores sin `null`; usar opcionales y omitir campos vacios.
- Web Crypto API en lugar de `crypto` de Node.js.
- Queries/mutations con validadores de entrada y salida.
- Uso de indices frente a filtros post-scan en rutas criticas.
- Separacion entre acciones externas y mutaciones transaccionales.

## Frontend HTML/CSS/JS

- Cache-busters actualizados al modificar JS compartido.
- Duplicacion de llamadas API, auth, manejo de errores y estado.
- Dependencia de globals sin contrato claro.
- Formularios sin estados de carga, error o idempotencia.
- Rutas o endpoints hardcoded que contradicen configuracion central.

## Portal React/Vite

- Componentes con demasiada responsabilidad.
- Estado remoto duplicado entre hooks, stores y componentes.
- Tipos `any` o casts que oculten contratos de backend.
- Falta de estados loading/error/empty en flujos de alumno.
- Dependencias de entorno no documentadas.

## Python services

- Endpoints sin autenticacion esperada.
- Timeouts, retries e idempotencia ausentes en integraciones externas.
- Configuracion por entorno duplicada o hardcoded.
- Logs sin contexto operativo o con datos sensibles.
- Scripts que mezclan auditoria, mutacion y reporte sin modo dry-run.

## Pagos y crypto

- Reconciliacion entre proveedores y fuente de verdad local.
- Idempotencia de webhooks.
- Manejo de refunds, estados parciales y reintentos.
- Conversiones de moneda, precision decimal y timestamps.
- Separar hallazgos de alto riesgo de simples mejoras de limpieza.

## WhatsApp y email

- Rate limits, retries y backoff.
- Idempotencia para envios y webhooks.
- Plantillas, consentimientos y opt-out.
- Evitar duplicacion de contactos o participantes.
- Separar deliverability de bugs de negocio.

## Campanas y analytics

- UTM, deduplicacion y consistencia de naming.
- Eventos duplicados entre frontend, server-side y webhooks.
- Secretos o IDs hardcoded.
- Diferenciar tracking roto de cobertura analitica incompleta.

## Documentacion y reglas operativas

- Contradicciones entre `AGENTS.md`, `CLAUDE.md`, docs y scripts.
- Contadores o listas de rutas que se desactualizan con cambios de codigo.
- Reglas absolutas que no tienen excepciones operativas claras.
- Checklists que no reflejan CI o deploy real.
