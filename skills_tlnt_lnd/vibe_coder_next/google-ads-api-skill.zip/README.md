# Skill: google-ads-api

Skill de Claude Code para trabajar con la **Google Ads API v24**: GAQL, OAuth/developer tokens, campañas (Search, PMax, Demand Gen, Shopping, Video, App), reporting, Enhanced Conversions, Customer Match, Data Manager API, Consent Mode V2, smart bidding y creatividades (RSAs, asset groups de PMax, Ad Strength, framework ABCD).

## Instalación en tu repositorio

1. Copia la carpeta `google-ads-api/` dentro de `.claude/skills/` en la raíz de tu repositorio:

   ```
   tu-repo/
   └── .claude/
       └── skills/
           └── google-ads-api/
               ├── SKILL.md
               ├── references/
               └── scripts/
   ```

2. Ya está. Claude Code detecta automáticamente los skills en `.claude/skills/` al iniciar sesión en el repo.

## Uso

Claude carga el skill automáticamente cuando la tarea trata de Google Ads (menciones de "Google Ads", "GAQL", "PMax", "RSA", "Customer Match", etc.). También puedes pedírselo explícitamente: *"carga el skill google-ads-api"*.

## Contenido

- `SKILL.md` — guía principal y punto de entrada del skill
- `references/` — 12 documentos de referencia (auth, GAQL, campañas, audiencias, bidding, reporting, creatividades, rate limits…)
- `scripts/google_ads_helper.py` — helper Python para llamadas comunes a la API

## Requisitos para usar la API

- Cuenta de Google Ads y developer token ([guía oficial](https://developers.google.com/google-ads/api/docs/get-started/introduction))
- Credenciales OAuth 2.0 (ver `references/auth-and-setup.md`)
- Python: `pip install google-ads` (para el helper script)

> **Nota**: este skill no incluye credenciales. Cada uno debe configurar las suyas — nunca las subas al repositorio.
