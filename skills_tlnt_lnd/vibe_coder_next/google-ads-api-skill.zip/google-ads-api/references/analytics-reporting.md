# Analytics & Reporting Reference

## Table of Contents
1. [Metrics by Campaign Type](#metrics-by-campaign-type)
2. [Attribution Models](#attribution-models)
3. [Attribution Windows](#attribution-windows)
4. [Data Freshness](#data-freshness)
5. [Conversion Tracking Architecture](#conversion-tracking-architecture)
6. [Cross-Channel (GA4)](#cross-channel-ga4)
7. [Segmentation Deep Dive](#segmentation-deep-dive)
8. [PMax Reporting](#pmax-reporting)
9. [Shopping Reporting](#shopping-reporting)
10. [Demand Gen Reporting](#demand-gen-reporting)
11. [Video / YouTube Reporting](#video--youtube-reporting)
12. [Search Reporting](#search-reporting)
13. [Change Tracking](#change-tracking)
14. [Scheduled Reports](#scheduled-reports)
15. [Common Reporting Mistakes](#common-reporting-mistakes)

---

## Metrics by Campaign Type

Not all metrics are available for all campaign types. This matrix shows what you can
report on:

| Metric | Search | PMax | Demand Gen | Shopping | Video | App | Display |
|--------|--------|------|-----------|----------|-------|-----|---------|
| `metrics.impressions` | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| `metrics.clicks` | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| `metrics.cost_micros` | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| `metrics.conversions` | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| `metrics.conversions_value` | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| `metrics.ctr` | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| `metrics.average_cpc` | Yes | Yes | Yes | Yes | — | Yes | Yes |
| `metrics.average_cpm` | — | Yes | Yes | — | Yes | — | Yes |
| `metrics.average_cpv` | — | — | — | — | Yes | — | — |
| `metrics.video_views` | — | Partial | Yes | — | Yes | — | — |
| `metrics.video_view_rate` | — | — | Yes | — | Yes | — | — |
| `metrics.video_quartile_p25_rate` | — | — | Yes | — | Yes | — | — |
| `metrics.video_quartile_p50_rate` | — | — | Yes | — | Yes | — | — |
| `metrics.video_quartile_p75_rate` | — | — | Yes | — | Yes | — | — |
| `metrics.video_quartile_p100_rate` | — | — | Yes | — | Yes | — | — |
| `metrics.search_impression_share` | Yes | — | — | Yes | — | — | — |
| `metrics.search_top_impression_share` | Yes | — | — | Yes | — | — | — |
| `metrics.content_impression_share` | — | — | — | — | — | — | Yes |
| `metrics.all_conversions` | Yes | Yes | Yes | Yes | Yes | Yes | Yes |
| `metrics.view_through_conversions` | — | Yes | Yes | — | Yes | — | Yes |
| `metrics.interaction_rate` | Yes | Yes | Yes | Yes | Yes | Yes | Yes |

**Key note**: PMax has limited granular metric access. Many PMax metrics are only
available at the asset group level, not the campaign level. See §8 (PMax Reporting).

---

## Attribution Models

### Available Models (February 2026)

| Model | Description | Status |
|-------|------------|--------|
| **Data-driven** | ML distributes credit across touchpoints | Default since April 2023 |
| **Last click** | 100% credit to last-clicked ad | Fallback for low data |
| **External** | Third-party attribution system | Via conversion import |

Google deprecated first-click, linear, time-decay, and position-based models in 2023.
All accounts were migrated to data-driven attribution.

### Data-Driven Attribution (DDA)

- Uses ML to analyze all touchpoints and assign fractional credit
- Requires minimum ~300 conversions and ~3,000 interactions in 30 days
- Falls back to last-click if insufficient data
- Can assign fractional conversions (e.g., 0.4 conversions to one click)
- Cross-device attribution included (for logged-in users)

### Modeled Conversions

Google models conversions when direct observation isn't possible:
- Users who don't consent to tracking (Consent Mode)
- Cross-device journeys where devices can't be linked
- Safari ITP / Firefox ETP limitations

**Important**: `metrics.conversions` includes modeled conversions by default.
`metrics.all_conversions` includes these plus micro-conversions and view-through.

---

## Attribution Windows

### Click-Through Windows

| Window | Use Case |
|--------|----------|
| 1 day | Impulse purchases, app installs |
| 7 days | E-commerce, short consideration |
| **30 days** | **Default** — most businesses |
| 60 days | B2B, high-consideration |
| 90 days | Enterprise sales, real estate |

### View-Through Windows

| Window | Use Case |
|--------|----------|
| **1 day** | **Default** — conservative |
| 3 days | Display/Video campaigns |
| 7 days | Brand awareness campaigns |
| 14 days | Complex purchase paths |
| 30 days | Maximum view attribution |

### Engaged-View (YouTube)

- **Engaged-view**: User watches ≥10 seconds of a skippable ad, then converts
- **Window**: Same as click-through window (default 30 days)
- **Not the same as view-through**: Engaged-view requires active watching

### Setting via API

```python
# Set attribution window on conversion action
conversion_action_op = client.get_type("ConversionActionOperation")
ca = conversion_action_op.update
ca.resource_name = f"customers/{cid}/conversionActions/{action_id}"
ca.click_through_lookback_window_days = 30
ca.view_through_lookback_window_days = 1
```

---

## Data Freshness

Understanding data delays is critical for accurate reporting:

| Data Type | Delay | Notes |
|-----------|-------|-------|
| **Clicks / Impressions** | ~3 hours | Near real-time |
| **Cost** | ~3 hours | May adjust slightly over 24h |
| **Conversions (tag)** | 24-48 hours | Depends on attribution window |
| **Enhanced Conversions** | 24-72 hours | Additional matching time |
| **Offline conversions** | 24-48 hours after upload | Upload → processing → reporting |
| **Brand lift** | 5-7 days | Survey-based, needs sample |
| **Store visits** | 24-72 hours | Modeled from location data |
| **PMax asset performance** | 24 hours | Asset-level metrics delayed |
| **Data-driven attribution** | 24-48 hours | Model recalculates retroactively |

### Retroactive Data Changes

Google may retroactively update data for up to **7 days** after the fact:
- Invalid traffic removal (click fraud filtering)
- Attribution model recalculation
- Conversion window closures
- Cross-device attribution updates

**Best practice**: Don't make decisions on data less than 3 days old. For conversion
data, wait 7+ days for stability (especially with offline conversions or long
attribution windows).

---

## Conversion Tracking Architecture

### The Conversion Stack (from least to most resilient)

```
Layer 1: Google Tag (gtag.js / GTM)
    ↓ Browser-side, affected by ad blockers + cookie restrictions
Layer 2: Enhanced Conversions (Web)
    ↓ Hashed PII sent alongside tag, improves matching
Layer 3: Enhanced Conversions (Leads)
    ↓ Server-side GCLID → offline conversion, decoupled from cookies
Layer 4: Data Manager API
    ↓ Automated CRM-to-Google pipeline, scheduled syncs
Layer 5: Server-Side Tagging (sGTM)
    ↓ First-party domain, first-party cookies, maximum resilience
```

**Recommendation for 2026**: Implement at least through Layer 3 (Enhanced Conversions
for Leads). Layer 4 (Data Manager API) for automated pipelines. Layer 5 (sGTM) for
maximum tracking resilience.

See `first-party-data-strategy.md` for implementation details on each layer.

---

## Cross-Channel (GA4)

### Why GA4 Numbers Differ from Google Ads

| Dimension | Google Ads | GA4 |
|-----------|-----------|-----|
| **Attribution model** | Data-driven (Google Ads clicks) | Data-driven (all channels) |
| **Scope** | Google Ads touchpoints only | All touchpoints (organic, social, email, etc.) |
| **Conversion counting** | Per-click or per-impression | Per-session or per-user |
| **Cross-device** | Google account matching | Google Signals + User-ID |
| **View-through** | Included (if enabled) | Not included by default |

### Importing GA4 Conversions

```sql
-- View GA4-imported conversions
SELECT conversion_action.name, conversion_action.type,
       conversion_action.origin, metrics.conversions
FROM conversion_action
WHERE conversion_action.origin = 'FIREBASE'
  OR conversion_action.origin = 'ANALYTICS_LINKED'
```

**When to use GA4 conversions in Google Ads**: When you want cross-channel
attribution context and are willing to accept GA4's broader attribution model.
Most advertisers use Google Ads native conversion tracking for bidding optimization
and GA4 for holistic analysis.

---

## Segmentation Deep Dive

GAQL supports rich segmentation. All segments split metrics by the specified dimension.

### Key Segments

```sql
-- By date (required when segments.date is in SELECT)
SELECT segments.date, campaign.name, metrics.clicks
FROM campaign
WHERE segments.date DURING LAST_30_DAYS

-- By device
SELECT segments.device, campaign.name, metrics.impressions, metrics.clicks
FROM campaign
WHERE segments.date DURING LAST_7_DAYS

-- By ad network type (NEW in v23 for PMax!)
SELECT segments.ad_network_type, campaign.name, metrics.impressions
FROM campaign
WHERE campaign.advertising_channel_type = 'PERFORMANCE_MAX'
  AND segments.date DURING LAST_30_DAYS

-- By hour of day
SELECT segments.hour, metrics.impressions, metrics.clicks, metrics.conversions
FROM campaign
WHERE segments.date DURING LAST_7_DAYS

-- By day of week
SELECT segments.day_of_week, metrics.impressions, metrics.clicks
FROM campaign
WHERE segments.date DURING LAST_30_DAYS

-- By geographic (country)
SELECT geographic_view.country_criterion_id, metrics.impressions, metrics.clicks
FROM geographic_view
WHERE segments.date DURING LAST_30_DAYS

-- By demographic (age)
SELECT ad_group_criterion.age_range.type, metrics.impressions, metrics.clicks
FROM age_range_view
WHERE segments.date DURING LAST_30_DAYS

-- By audience
SELECT ad_group_criterion.user_list.user_list, metrics.impressions, metrics.conversions
FROM ad_group_audience_view
WHERE segments.date DURING LAST_30_DAYS
```

### Segment Compatibility Rules

Not all segments work with all resources. Key incompatibilities:

| Segment | Works With | Does NOT Work With |
|---------|-----------|-------------------|
| `segments.date` | All resources | N/A |
| `segments.device` | Most resources | Some extension views |
| `segments.ad_network_type` | Campaign, ad_group | keyword_view (already filtered) |
| `segments.hour` | Campaign, ad_group | asset views |
| `segments.conversion_action` | Campaign, ad_group | Some report types |
| `segments.slot` | Search only | Display, Video |

Use the GAQL Query Builder to validate segment compatibility:
`developers.google.com/google-ads/api/fields/v23/campaign_query_builder`

---

## PMax Reporting

Performance Max has limited reporting granularity compared to other campaign types.

### What You CAN Report On

```sql
-- Asset group performance
SELECT asset_group.name, asset_group.status,
       metrics.impressions, metrics.clicks, metrics.conversions, metrics.cost_micros
FROM asset_group
WHERE campaign.advertising_channel_type = 'PERFORMANCE_MAX'
  AND segments.date DURING LAST_30_DAYS

-- Asset group per-asset performance
SELECT asset_group_asset.asset, asset_group_asset.performance_label,
       asset_group_asset.field_type
FROM asset_group_asset
WHERE campaign.advertising_channel_type = 'PERFORMANCE_MAX'

-- Network breakdown (NEW in v23)
SELECT segments.ad_network_type, metrics.impressions, metrics.clicks, metrics.cost_micros
FROM campaign
WHERE campaign.advertising_channel_type = 'PERFORMANCE_MAX'
  AND segments.date DURING LAST_30_DAYS

-- Listing group (Shopping) performance
SELECT asset_group_listing_group_filter.type,
       metrics.impressions, metrics.clicks, metrics.conversions
FROM asset_group_listing_group_filter
WHERE segments.date DURING LAST_30_DAYS

-- Search themes (v21+)
SELECT campaign_search_term_insight.category_label,
       metrics.impressions, metrics.clicks
FROM campaign_search_term_insight
WHERE segments.date DURING LAST_30_DAYS
```

### Performance Labels

Asset performance labels: `PENDING`, `LEARNING`, `LOW`, `GOOD`, `BEST`, `UNKNOWN`

```sql
SELECT asset_group_asset.asset, asset_group_asset.performance_label,
       asset_group_asset.field_type
FROM asset_group_asset
WHERE asset_group_asset.performance_label IN ('LOW', 'GOOD', 'BEST')
```

### What You CANNOT Report On (PMax Limitations)

- Individual keyword-level performance (no keywords in PMax)
- Placement-level reporting (which sites/apps showed your ads)
- Individual audience segment performance
- Creative-level A/B test results
- Bid-level data

### v23 Network Transparency

Before v23, PMax lumped all networks together. v23 added `segments.ad_network_type`
for PMax, revealing the split between Search, Display, YouTube, Gmail, Discover, and Maps.

---

## Shopping Reporting

### Product-Level Performance

```sql
-- Product performance
SELECT shopping_performance_view.resource_name,
       segments.product_item_id, segments.product_title,
       segments.product_brand, segments.product_category_level1,
       metrics.impressions, metrics.clicks, metrics.cost_micros, metrics.conversions
FROM shopping_performance_view
WHERE segments.date DURING LAST_30_DAYS
ORDER BY metrics.conversions DESC
LIMIT 100
```

### Competitive Metrics (v23+)

```sql
-- Price competitiveness
SELECT segments.product_item_id,
       metrics.impressions, metrics.clicks,
       metrics.search_impression_share,
       metrics.search_click_share
FROM shopping_performance_view
WHERE segments.date DURING LAST_30_DAYS
  AND metrics.impressions > 100
```

### Feed Diagnostics

```sql
-- Product status and issues
SELECT product_group_view.resource_name,
       metrics.impressions, metrics.clicks
FROM product_group_view
WHERE segments.date DURING LAST_7_DAYS
```

---

## Demand Gen Reporting

### Surface Breakdown

Demand Gen campaigns serve across Gmail, YouTube, Shorts, and Discover:

```sql
-- Performance by placement type
SELECT segments.ad_network_type, segments.device,
       metrics.impressions, metrics.clicks, metrics.conversions, metrics.cost_micros
FROM campaign
WHERE campaign.advertising_channel_type = 'DEMAND_GEN'
  AND segments.date DURING LAST_30_DAYS
```

### CTV Metrics (January 2026)

Connected TV campaigns (Shoppable CTV) added new metrics:

```sql
-- CTV-specific metrics
SELECT campaign.name, metrics.impressions, metrics.video_views,
       metrics.conversions, metrics.cost_micros
FROM campaign
WHERE campaign.advertising_channel_type = 'DEMAND_GEN'
  AND segments.date DURING LAST_30_DAYS
```

### Conversion Forecasting (v23)

New in v23: Demand Gen campaigns support conversion forecasting for campaign planning.

### Asset Performance

```sql
-- Ad-level performance for Demand Gen
SELECT ad_group_ad.ad.name, ad_group_ad.ad.type,
       ad_group_ad.ad_strength,
       metrics.impressions, metrics.clicks, metrics.conversions
FROM ad_group_ad
WHERE campaign.advertising_channel_type = 'DEMAND_GEN'
  AND segments.date DURING LAST_30_DAYS
```

---

## Video / YouTube Reporting

### Video Engagement Metrics

```sql
-- Video quartile metrics
SELECT campaign.name, ad_group_ad.ad.name,
       metrics.video_views, metrics.video_view_rate,
       metrics.video_quartile_p25_rate,
       metrics.video_quartile_p50_rate,
       metrics.video_quartile_p75_rate,
       metrics.video_quartile_p100_rate,
       metrics.average_cpv
FROM video
WHERE segments.date DURING LAST_30_DAYS
```

### Earned Actions

```sql
-- Earned metrics (free engagement from paid ads)
SELECT campaign.name,
       metrics.earned_impressions, metrics.earned_views,
       metrics.earned_subscriptions
FROM campaign
WHERE campaign.advertising_channel_type = 'VIDEO'
  AND segments.date DURING LAST_30_DAYS
```

### Brand Lift

Brand Lift studies require UI setup and take 5-7 days for results. No direct API for
creating Brand Lift studies, but results can be queried:

```sql
-- Brand lift results (if study is active)
SELECT campaign.name, metrics.absolute_top_impression_percentage
FROM campaign
WHERE campaign.advertising_channel_type = 'VIDEO'
```

---

## Search Reporting

### Quality Score

```sql
-- Current Quality Score breakdown
SELECT ad_group_criterion.keyword.text,
       ad_group_criterion.quality_info.quality_score,
       ad_group_criterion.quality_info.creative_quality_score,
       ad_group_criterion.quality_info.post_click_quality_score,
       ad_group_criterion.quality_info.search_predicted_ctr,
       metrics.impressions, metrics.clicks
FROM keyword_view
WHERE ad_group_criterion.quality_info.quality_score IS NOT NULL
  AND segments.date DURING LAST_30_DAYS
ORDER BY metrics.impressions DESC
```

**Note**: Quality Score is a snapshot — only current values are available via API.
To track history, log daily via scheduled queries (gaarf).

### Ad Strength

```sql
-- RSA Ad Strength
SELECT ad_group_ad.ad.responsive_search_ad.headlines,
       ad_group_ad.ad_strength,
       metrics.impressions, metrics.clicks, metrics.conversions
FROM ad_group_ad
WHERE ad_group_ad.ad.type = 'RESPONSIVE_SEARCH_AD'
  AND segments.date DURING LAST_30_DAYS
```

Ad Strength values: `UNSPECIFIED`, `UNKNOWN`, `PENDING`, `NO_ADS`, `POOR`,
`AVERAGE`, `GOOD`, `EXCELLENT`

### Search Terms Report

```sql
-- Search terms that triggered your ads
SELECT search_term_view.search_term, search_term_view.status,
       campaign.name, ad_group.name,
       metrics.impressions, metrics.clicks, metrics.conversions, metrics.cost_micros
FROM search_term_view
WHERE segments.date DURING LAST_30_DAYS
  AND metrics.impressions > 0
ORDER BY metrics.clicks DESC
LIMIT 500
```

### Auction Insights

**Not available via API**. Auction Insights are UI-only. No programmatic access to
competitor impression share, overlap rate, or position above rate.

---

## Change Tracking

Two services for tracking account changes:

### ChangeEventService (Audit Trail)

Records WHO changed WHAT and WHEN. For compliance and auditing.

```sql
SELECT change_event.change_date_time,
       change_event.change_resource_type,
       change_event.change_resource_name,
       change_event.client_type,
       change_event.user_email,
       change_event.old_resource,
       change_event.new_resource
FROM change_event
WHERE change_event.change_date_time DURING LAST_7_DAYS
  AND change_event.change_resource_type IN (
    'CAMPAIGN', 'AD_GROUP', 'AD_GROUP_AD', 'AD_GROUP_CRITERION')
ORDER BY change_event.change_date_time DESC
```

### ChangeStatusService (Sync)

Lightweight polling to detect resource changes since last check:

```sql
SELECT change_status.resource_type,
       change_status.resource_name,
       change_status.resource_status,
       change_status.last_change_date_time
FROM change_status
WHERE change_status.last_change_date_time >= '2026-02-22T00:00:00-05:00'
ORDER BY change_status.last_change_date_time DESC
```

For automation patterns using change tracking, see `webhooks-automation.md`.

---

## Scheduled Reports

Google Ads API has no built-in report scheduling. Use external tools:

### gaarf Scheduled Reports

```bash
# Cron job: daily report at 6 AM
0 6 * * * gaarf /path/to/queries/*.sql --account=MCC_ID \
  --customer-ids-query-file=/path/to/accounts.sql \
  --output=bq --bq.project=my-project --bq.dataset=daily_reports
```

### Airflow Integration

```python
from airflow import DAG
from airflow_google_ads_api_report_fetcher.operators import GaarfOperator
from datetime import datetime, timedelta

with DAG("google_ads_daily", schedule_interval="0 6 * * *",
         start_date=datetime(2026, 1, 1), catchup=False) as dag:

    fetch = GaarfOperator(
        task_id="fetch_campaigns",
        query_file="queries/campaigns.sql",
        account="MCC_ID",
        output="bq",
        bq_project="my-project",
        bq_dataset="ads_data",
    )
```

### Python Script Pattern

```python
import schedule
import time

def daily_report():
    client = GoogleAdsClient.load_from_storage()
    # Run queries, export to CSV/BigQuery/database
    pass

schedule.every().day.at("06:00").do(daily_report)
while True:
    schedule.run_pending()
    time.sleep(60)
```

See `ecosystem-tools.md` for full tool options.

---

## Common Reporting Mistakes

### 1. Ignoring Modeled Conversions

**Wrong**: Treating `metrics.conversions` as exact observed conversions.

**Reality**: Includes modeled conversions from consent gaps and cross-device. This is
by design — excluding modeled data would undercount by 20-40% in EU markets.

### 2. Reporting on Data Less Than 3 Days Old

**Wrong**: Making optimization decisions based on yesterday's data.

**Reality**: Conversions have 24-72h reporting delay. Data-driven attribution may
retroactively adjust numbers for up to 7 days. Wait at least 3 days.

### 3. PMax Mixed Network Pre-v23

**Wrong**: (Before v23) Treating PMax as a "Search" campaign because it generates
search impressions.

**Reality**: PMax serves across Search, Display, YouTube, Gmail, Discover, and Maps.
In v23+, use `segments.ad_network_type` to see the breakdown.

### 4. View-Through Overcounting

**Wrong**: Including view-through conversions in performance reporting without context.

**Reality**: View-through conversions credit an ad impression even if the user converted
through another channel. Review `metrics.view_through_conversions` separately from
`metrics.conversions`.

### 5. Not Accounting for Attribution Windows

**Wrong**: Comparing today's data with 30 days ago and concluding performance dropped.

**Reality**: Recent days have incomplete conversion data (conversions still accruing
within the attribution window). Compare same-maturity periods.

### 6. Auction Insights Unavailable

**Wrong**: Trying to pull Auction Insights via the API.

**Reality**: Auction Insights are UI-only. No API access. Log competitive data manually
or use third-party tools.

### 7. Using Wrong Conversion Columns

| Column | Includes |
|--------|---------|
| `metrics.conversions` | Primary conversions (included in bidding) |
| `metrics.all_conversions` | Primary + secondary + micro-conversions |
| `metrics.conversions_value` | Value of primary conversions |
| `metrics.all_conversions_value` | Value of all conversions |
| `metrics.view_through_conversions` | Impression-attributed conversions |

Use `metrics.conversions` for performance optimization. Use `metrics.all_conversions`
for holistic analysis.

---

## Cross-References

- **GAQL query syntax** → `gaql-reference.md`
- **Automation and batch reporting** → `automation-and-reporting.md`
- **Smart Bidding metrics** → `smart-bidding.md`
- **Conversion tracking setup** → `first-party-data-strategy.md`
- **CLI reporting tools** → `ecosystem-tools.md`
- **Change detection automation** → `webhooks-automation.md`
- **Audience segment reporting** → `audiences-targeting.md`
