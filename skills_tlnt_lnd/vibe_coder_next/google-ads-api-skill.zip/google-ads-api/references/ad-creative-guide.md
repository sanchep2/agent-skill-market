# Winning Ad Creative Guide — All Google Ads Formats (July 2026)

<!-- last_verified: 2026-07-17 — creative landscape reviewed; AI Max/PMax "Power Pack" still current. -->

## The 2026 Landscape

The Google Ads creative ecosystem in 2026 is shaped by three defining trends:

1. **Format consolidation toward RSAs and Performance Max**: ETAs were sunset in 2022,
   Video Action Campaigns were auto-migrated to Demand Gen in July 2025, and Call Ads
   are being deprecated (no new creation from Feb 2026, full sunset Feb 2027). RSAs
   are the sole standard text ad format for Search; PMax is the full-funnel workhorse.

2. **Massive generative AI integration**: Gemini generated nearly **70 million creative
   assets** in Q4 2025 alone. Asset Studio (free for all advertisers, Sept 2025)
   combines Imagen 4, Nano Banana Pro, and Veo 3 for text-to-image, natural-language
   editing, and video generation. The new AssetGenerationService (API v22+) provides
   programmatic access to AI asset generation.

3. **Surface expansion**: Ads now reach YouTube Shorts, AI Overviews, Connected TV
   (Shoppable CTV since Jan 2026), and an ever-growing Display Network (3M+ sites
   via Demand Gen since April 2025). The "Power Pack" (Demand Gen + AI Max + PMax)
   is Google's officially recommended three-campaign structure for 2026.

**Advertisers who master exact technical specifications and apply proven copywriting
frameworks achieve 15-35% more conversions** than those using generic configurations.

---

## Table of Contents

1. [Responsive Search Ads (RSA)](#1-responsive-search-ads)
2. [Performance Max Asset Groups](#2-performance-max-asset-groups)
3. [Demand Gen Ads](#3-demand-gen-ads)
4. [Shopping Ads](#4-shopping-ads)
5. [Video Ads (YouTube)](#5-video-ads-youtube)
6. [App Campaign Ads](#6-app-campaign-ads)
7. [Responsive Display Ads](#7-responsive-display-ads)
8. [Call Ads (Deprecated) & Call Assets](#8-call-ads-and-call-assets)
9. [Hotel Ads & Travel Ads](#9-hotel-ads-and-travel-ads)
10. [Local Services Ads](#10-local-services-ads)
11. [Copywriting Frameworks & Psychological Triggers](#11-copywriting-frameworks)
12. [Quality Score & Ad Relevance](#12-quality-score)
13. [AI-Powered Creative Workflows](#13-ai-powered-creative)
14. [Compliance & Policy Pitfalls](#14-compliance-and-policy)
15. [Cross-Format Strategy: The Power Pack](#15-cross-format-strategy)

---

## 1. Responsive Search Ads

RSAs are the **only** standard text ad format for Search campaigns (ETAs were sunset
in June 2022). Google's AI tests combinations of your headlines and descriptions to
find the best-performing assembly for each auction.

### Character Limits & Specs

| Field | Max Count | Max Characters |
|-------|-----------|---------------|
| Headlines | 15 | 30 chars each |
| Descriptions | 4 | 90 chars each |
| Display Path | 2 fields | 15 chars each |
| Final URL | 1 | 2,048 chars |
| RSAs per ad group | 3 enabled | — |
| Headlines shown per impression | 2-3 | — |
| Descriptions shown per impression | 1-2 | — |

**Minimums**: 3 headlines + 2 descriptions to create an RSA.
**Recommended**: 8-10 unique headlines + all 4 descriptions.
**Double-width languages** (Korean, Japanese, Chinese): each character counts as 2.
**Emojis**: Prohibited in Search Ads.

### The 10 Headline Categories Every RSA Needs

Every headline must communicate a **different** message and work independently in any
combination. A winning RSA covers these 10 angles:

1. **Keyword-focused**: "Best Running Shoes 2026" — mirrors user's search query
2. **Benefit**: "Boost Your Web Speed Instantly" — what the user gains
3. **Problem**: "Tired of Slow Websites?" — pain point they recognize
4. **Solution**: "Fast & Reliable Hosting" — your answer to their problem
5. **CTA**: "Get Your Free Quote Today" — direct action
6. **Social proof**: "Rated 4.9★ by 10,000+ Users" — others trust you
7. **USP/differentiator**: "Free Shipping on All Orders" — why you, not competitors
8. **Urgency/scarcity**: "Limited Offer — 50% Off" — act now
9. **Location**: "Expert CPAs in {LOCATION(City)}" — local relevance
10. **Question**: "Need Affordable Insurance?" — engages curiosity

### Pinning Strategy: Data-Backed Approach

Google penalizes Ad Strength for pinning, but performance data tells a different story.
Research by PPC Mania across 3,660 campaigns found:

- **Partial pinning: highest ROAS (224%)**
- Full pinning: 200% ROAS
- No pinning: **lowest ROAS (177%)**

**Optimal tactic — partial pinning:**
- Pin 3-4 keyword-relevant headlines to **Position 1** (Google rotates among them)
- Pin CTAs to **Position 2**
- Leave Position 3 and all descriptions **unpinned**
- Never pin every position (turns RSA into a static ETA)
- Target Ad Strength of **"Good"**, not "Excellent" — chasing Excellent at the cost
  of relevance reduces actual performance

### Dynamic Functions: Syntax Reference

**Keyword Insertion (DKI):**
```
{KeyWord:Default Text}
```
Capitalization variants:
- `{keyword:...}` → all lowercase
- `{Keyword:...}` → First letter capitalized
- `{KeyWord:...}` → Title Case (recommended)
- `{KEYWORD:...}` → ALL CAPS

Inserts the **ad group keyword**, NOT the search term. Falls back to default text if
keyword exceeds character limit. Does NOT work in DSAs, Display, Video, PMax, or Demand Gen.

**Countdown Timers:**
```
{COUNTDOWN(yyyy/MM/dd HH:mm:ss,language,days_before)}
```
Examples:
- English: `{COUNTDOWN(2026/03/31 23:59:59,en,7)}`
- Spanish: `{COUNTDOWN(2026/03/31 23:59:59,es,7)}`

Google reports countdown ads **increase CTR by 32% on average**. Always keep at least
3 headlines WITHOUT countdowns as fallback (ads stop serving after the deadline).

**Location Insertion:**
```
{LOCATION(City):Default Text}
```
Options: `City`, `State`, `Country`. Requires geo targeting to be configured.
Reserve enough character space for the longest possible location name.

**Ad Customizers (v2 — business data feeds deprecated):**
```
{CUSTOMIZER.attribute_name:default_value}
```
Up to 40 enabled customizer attributes per account.
Types: text, number, price, percent.
Can be scoped to account, campaign, ad group, or keyword level.

**IF Functions:**
```
{=IF(device=mobile,Mobile Text):Default Text}
{=IF(audience IN(remarketing_list),Returning Text):New Visitor Text}
```

### Ad Strength: What Moves the Needle (and What Doesn't)

Google measures four factors:
1. Quantity of headlines (more = better, up to 15)
2. Uniqueness of headlines (different themes, not variations of same message)
3. Keyword relevance (headlines include keywords from the ad group)
4. Uniqueness of descriptions (different angles)

Moving from "Poor" to "Excellent" generates **~15% more conversions** on average
(Google's published data).

**Critical nuance**: Ad Strength is a **best-practice indicator, NOT a performance
factor**. It does NOT directly impact Ad Rank or Quality Score. Ads with "Poor" Ad
Strength can outperform "Excellent" ads if they are more relevant to user intent.
Multiple industry experts (Search Engine Land, PPC Mania, GlowMetrics) confirm this
with data. **Prioritize relevance and conversion performance over Ad Strength score.**

### RSA Testing Framework

**Method 1 — Ad Variations (recommended):**
Experiments > Ad Variations > Find & Replace headlines across campaigns. 50/50 split
for up to 84 days. Shows statistical significance indicators. Need minimum **100
conversions per variant** for reliable results.

**Method 2 — Multiple RSAs per ad group:**
Run 2-3 RSAs with distinct messaging themes. Each RSA must be genuinely different
(not just swapping one headline). Google serves all RSAs and picks winner. Monitor
via "Asset Details" column. Replace low-performing RSAs quarterly.

**Testing priority order:**
1. Message themes (value prop A vs B)
2. CTAs (action-oriented vs benefit-oriented)
3. Emotional angles (problem vs solution vs benefit)
4. Headlines with numbers vs without
5. Social proof vs no social proof
6. Pinning strategies

### AI Max for Search & Text Customization (2025-2026)

Automatically Created Assets are now called **"Text Customization"** under AI Max
(since May 2025). Google uses generative AI to create additional headlines and
descriptions based on landing pages, existing ads, and keywords.

Key facts:
- Do NOT count toward the 15 headline / 4 description limit
- Refresh every 48 hours
- Google reports **+2% conversions** in early adopters
- New **Text Guidelines** feature (expanding Q1 2026) allows excluding specific
  terms and defining tone of voice for AI-generated copy
- Can be enabled/disabled at campaign level
- Via API: `TextCustomizationSettings` on the campaign resource

---

## 2. Performance Max Asset Groups

PMax campaigns serve across ALL Google surfaces: Search, Shopping, Display, YouTube,
Gmail, Discover, Maps, and AI Overviews. Asset groups are the creative building blocks.

### Text Asset Specs

| Asset Type | Max Chars | Min Required | Recommended | Maximum |
|------------|-----------|-------------|-------------|---------|
| Headlines | 30 chars (≥1 must be ≤15) | 3 | 11+ | 15 |
| Long Headlines | 90 chars | 1 | 2+ | 5 |
| Descriptions | 90 chars (≥1 must be <60) | 2 | 4+ | 5 |
| Business Name | 25 chars | 1 | 1 | 1 |
| Display URL Path | 15 chars each | 0 | 2 | 2 |
| Call to Action | Auto-selected or manual | 0 | 1 | 1 |

### Image Specs

| Type | Aspect Ratio | Recommended Size | Minimum Size | Max Weight | Required? |
|------|-------------|-----------------|-------------|-----------|-----------|
| Landscape | 1.91:1 | 1200×628 px | 600×314 px | 5 MB | ✓ Yes |
| Square | 1:1 | 1200×1200 px | 300×300 px | 5 MB | ✓ Yes |
| Portrait | 4:5 | 960×1200 px | 480×600 px | 5 MB | Optional |
| Square Logo | 1:1 | 1200×1200 px | 128×128 px | 5 MB | ✓ Yes |
| Landscape Logo | 4:1 | 1200×300 px | 512×128 px | 5 MB | Optional |

**Caps**: Max 20 images total (landscape + square + portrait share the cap).
Max 5 logos total. JPG or PNG only. Keep main subject in the **central 80%** of frame
(auto-cropping applies for different placements).

### Image Best Practices

- Avoid text overlays on images
- No fake buttons (play, download, close) — policy violation
- Product/service must be the focus
- Use images in physical settings with organic shadows (not digital composites on white)
- Images may be cropped up to **5%** to fit placements

### Video Specs

| Orientation | Aspect Ratio | Duration | Max Count |
|-------------|-------------|----------|-----------|
| Horizontal | 16:9 | 10-60 seconds | 15 total |
| Vertical | 9:16 | 10-60 seconds | (combined |
| Square | 1:1 | 10-60 seconds | across all 3) |

**Critical**: If you don't upload video, Google auto-generates it from your other assets.
Auto-generated videos perform **25-40% worse** than custom videos. There is NO opt-out.
**Always upload at least 1 custom video per asset group** (10-15 seconds minimum).

Google recommends providing **at least 1 video in each orientation** (horizontal,
vertical, square) for maximum surface coverage.

### Reaching "Excellent" Ad Strength in PMax

Fill all slots: 11+ headlines, 2+ long headlines, 4+ descriptions, all 3 image
orientations, at least 1 custom video per orientation, landscape logo, 6+ sitelinks,
call/lead assets as applicable.

Diversify text: avoid repetition across headlines. Include at least 1 headline ≤15
characters and 1 description <60 characters (these are mandatory for certain placements).

Advertisers reaching "Excellent" see **~6% more conversions** on average (Google data).

### Asset Group Theming Strategy

Each asset group should focus on a **single product category, audience, or theme**.
All assets within a group must be visually and thematically coherent. Examples:

- **E-commerce**: one asset group per product category (shoes, shirts, accessories)
- **Lead gen**: one asset group per service (consulting, training, audits)
- **Multi-audience**: one asset group per persona (enterprise, SMB, startup)

Maximum 100 asset groups per PMax campaign.

### Audience Signals: Advanced Strategy

Audience signals are **suggestions, not hard restrictions** — Google will show ads
beyond your signals to find conversions. The strategy recommended by top agencies
(Solutions 8, PPC Mastery) is **NOT to put all audiences in a single asset group**.

Instead, create separate asset groups by signal category for visibility:

1. **Non-converters**: site visitors, cart abandoners (remarketing lists)
2. **Converters/customer lists**: past buyers, high-LTV customers
3. **Custom segments**: competitor keywords, high-intent search terms (25-50 best terms)
4. **In-market & demographics**: interest categories, life events

Lists need minimum **1,000 active users** and must be refreshed every **540 days**.
Start with first-party data (highest-value customers), then add custom segments.

### Final URL Expansion: Control It

Enabled by default, allows Google to replace your final URL with a more relevant
landing page from your domain. Always exclude non-commercial pages: blog, About Us,
FAQs, privacy policies, careers. Use Page Feeds for more granular control. Monitor
the Insights tab to see which URLs Google is using.

### Negative Keywords in PMax (v20+)

Now available: up to **10,000 negative keywords per PMax campaign**. Use to:
- Exclude brand terms (if running separate Brand campaigns)
- Block irrelevant queries surfacing in Insights
- Prevent overlap with dedicated Search campaigns

### 10 Expert Tips for PMax (2025-2026)

1. **Feed optimization is #1 factor** for PMax e-commerce success
2. Always upload custom videos — never rely on auto-generated
3. Refresh static creatives every **4-6 weeks**, video every **8-12 weeks**
4. Run campaigns minimum **6 weeks** before evaluating performance
5. Replace assets rated "Low" quarterly (check via asset performance columns)
6. Use **Brand Guidelines** (new 2025 feature) for AI-generated asset consistency
7. Start with modest budgets and scale after 2-4 weeks of data
8. Need **30+ conversions/month** for PMax to optimize effectively
9. Use **campaign-level URL exclusions** to control where traffic goes
10. Monitor **Placement reports** (new in v23) for network-level transparency

---

## 3. Demand Gen Ads

Demand Gen (successor to Discovery Ads) serves on YouTube (including Shorts),
Discover feed, Gmail, Google Display Network (since April 2025), and now Connected
TV (since January 2026). Three ad formats available.

### Format 1: Single Image Ads

**Images**: Up to 20 per ad. Aspect ratios:
- Landscape 1.91:1 (rec: 1200×628)
- Square 1:1 (rec: 1200×1200)
- Portrait 4:5 (rec: 960×1200)
- **Vertical 9:16** (rec: 1080×1920) — new, for YouTube Shorts

**Text specs:**
| Field | Max Count | Max Characters |
|-------|-----------|---------------|
| Headlines | 5 | 40 chars each |
| Descriptions | 5 | 90 chars each |
| Business Name | 1 | 25 chars |
| CTA | 1 | Auto or from list (max 10 chars for custom) |
| Logo (square) | 1 | 1200×1200 rec, 128×128 min |

### Format 2: Carousel Ads

- **2 to 10 cards** per carousel
- Ad-level headline: 40 chars
- Ad-level description: 90 chars
- Each card: own image + headline (40 chars)
- Card headlines **do NOT show in Discover** (only the ad-level headline shows)
- Each card can have a different URL (on YouTube and Gmail)
- Aspect ratio **must be consistent across ALL cards** in a single carousel

**Carousel strategy — two proven approaches:**

**Sequential storytelling:**
Card 1 = hook/problem → Cards 2-4 = solution/features → Final card = CTA/offer.
Works for brand stories, product journeys, before/after. Images display in upload order.

**Product showcase:**
Different products, colors, or styles per card. Each card with different URL.
Ideal for e-commerce. Use **5-7 cards** for optimal engagement.
Maintain consistent visual style across all cards.

### Format 3: Video Ads

- 1-5 videos per ad
- Minimum 5 seconds (videos <10s won't serve in-stream)
- Headline: 40 chars
- Long headline: 90 chars
- Description: 90 chars
- CTA: max 10 characters
- Orientations: horizontal 16:9, square 1:1, portrait 4:5, vertical 9:16

### Copywriting for Feed Environments

In 40 characters you must be concise and spark curiosity:
- Lead with benefit or intrigue
- Use action-oriented language
- Treat content as "native" — blend with organic feed content
- Keep text in images under **20%** of the image area
- Lifestyle imagery outperforms flat product photos
- UGC-style (user-generated content) works especially well on YouTube Shorts

### Demand Gen Updates 2025-2026

- **Channel Controls** (March 2025): choose specific placements (YouTube, Discover,
  Gmail, GDN, YouTube Shorts individually)
- **GDN Expansion** (April 2025): Demand Gen now includes image ads across 3M+ sites
- **Video Action Campaigns auto-migrated** to Demand Gen (July 2025)
- **Shoppable CTV** (January 2026): Connected TV ads with direct purchase, **+7%
  additional conversions**
- **Creative A/B Experiments**: head-to-head testing in isolated groups
- **TargetCPC bidding** (v22+): available alongside Maximize Clicks, Max Conversions,
  Target CPA, Target ROAS
- **Asset Automation** (v22+): Google generates additional text and video variations

---

## 4. Shopping Ads

Shopping ads are driven by your **Merchant Center feed**, not traditional ad copy.
Your "creative" is the product title, image, price, and merchant name.

### Product Title Optimization

Character limit: **150 characters**, but Google shows approximately **70 characters**
on desktop (even less on mobile). Optimal length: 75-100 chars with critical info
in the first 70.

**Title formulas by vertical:**

| Vertical | Formula | Example |
|----------|---------|---------|
| Apparel | Brand + Gender + Product Type + Attributes (Color, Size, Material) | "Nike Women's Air Max 270 Running Shoes – Black/White – Size 8" |
| Electronics | Brand + Product Type + Model + Key Specs | "Samsung Galaxy S25 Ultra 256GB Titanium Black" |
| Home/Garden | Brand + Product Type + Feature + Attribute | "Dyson V15 Cordless Vacuum – Gold Edition" |
| Beauty | Brand + Product Line + Type + Size | "CeraVe Moisturizing Cream – 16 oz Jar" |
| Food/Beverage | Brand + Flavor/Type + Size + Count | "Nespresso Vertuo Pods Dark Roast – 30 Pack" |

**Title rules:**
- Use digits (don't spell out numbers): "256GB" not "Two Hundred Fifty Six GB"
- Title Case formatting
- Include differentiators: "Waterproof", "Eco-Friendly", "Organic"
- NEVER use ALL CAPS or promotional text in titles ("SALE", "FREE SHIPPING")
- Google now supports **structured_title** attribute for AI-generated titles (new 2025)
- Front-load the most important attributes (brand, product type, key differentiator)

### Product Image Requirements

| Spec | Requirement |
|------|------------|
| Min resolution (apparel) | 250×250 px |
| Min resolution (non-apparel) | 100×100 px |
| Recommended | 1500×1500 px (enables mobile zoom) |
| Max file size | 16 MB |
| Max resolution | 64 megapixels |
| Background | White (#FFFFFF) or transparent for main image |
| Product coverage | 75-90% of frame |
| Prohibited | Watermarks, promotional text, logos, borders |

**Product Studio in Merchant Center** (AI-powered, 2025-2026):
- Generate product images from text descriptions
- Remove backgrounds automatically
- Animate static images
- Increase resolution (upscaling)
- Generate lifestyle/contextual imagery
- Virtual try-on for apparel

### Custom Labels Strategy

5 labels available (custom_label_0 through custom_label_4), up to 1,000 unique values each:

| Label | Recommended Use | Example Values |
|-------|----------------|---------------|
| Label 0 | Margin tier | "High", "Medium", "Low" |
| Label 1 | Seasonality | "Winter", "Summer", "Holiday", "Evergreen" |
| Label 2 | Performance tier | "Bestseller", "New", "Clearance", "Underperformer" |
| Label 3 | Price range | "$0-25", "$26-50", "$51-100", "$100+" |
| Label 4 | Promo/inventory | "On Sale", "Low Stock", "Dropship", "Exclusive" |

Use custom labels to create product groups in campaigns → adjust bids by profitability,
season, or performance tier.

### Standard Shopping vs PMax Shopping (2025-2026)

**Key change**: Google modified auction priority. **Ad Rank now determines** which
campaign wins the auction when the same product is in both (previously PMax always won).
This means Standard Shopping with higher bids/quality CAN now beat PMax.

**Recommended strategy**: Run both simultaneously.
- **Standard Shopping** as primary: higher budget, lower Target ROAS (= higher bids
  → wins auctions). Full search terms report, impression share data, manual bid control.
- **PMax** as discovery/remarketing: smaller budget, exploring new audiences on
  YouTube/Display. Needs **30+ conversions/month** to optimize effectively.

### Feed Optimization Best Practices

- Include **GTINs** for all branded products (improves matching)
- Use **supplemental feeds** for A/B testing titles and descriptions
- Add **product_highlight** attributes (up to 10, max 150 chars each)
- Populate **product_detail** for technical specs
- Use **additional_image_link** for up to 10 extra lifestyle images
- Set **sale_price** and **sale_price_effective_date** for promotions
- Configure **shipping** and **tax** at feed level for accuracy
- Enable **automatic item updates** to prevent disapprovals from price/availability mismatches

---

## 5. Video Ads (YouTube)

### Universal Video Specs

| Spec | Requirement |
|------|------------|
| Recommended resolution | 1080p Full HD |
| Accepted formats | MP4, MOV, AVI, WebM, MPEG4, 3GPP, FLV |
| Max file size | 256 GB |
| Thumbnail | 1280×720 px, 16:9 |
| Companion banner (desktop only) | 300×60 px, max 150 KB |

### Format 1: Skippable In-Stream

No max duration (recommended 15-60s for action, up to 3 min for consideration).
Skip button appears after 5 seconds. CTA button: max 10 chars. Headline: max 15 chars.
Charged on CPV (30 seconds or completion) or Target CPA/ROAS.

**The 5 most important seconds of your ad budget:**

1. Start mid-action — no slow intros, no logo animations
2. Use close-ups — minimum **2 shots in the first 5 seconds** (Google Research data)
3. Open with people on screen — faces capture attention
4. Bold/surprising visuals — high contrast, bright colors
5. Audio from frame 1 — music, SFX, or voiceover (audio drives more attention than
   visuals per Nielsen Neuro research)
6. Show product/brand within 5 seconds — critical for recall even if viewer skips

**Narrative structure by duration:**

| Duration | Structure |
|----------|----------|
| 15s | Hook+brand (0-3s) → Core message (3-10s) → CTA+brand (10-15s) |
| 30s | Hook (0-5s) → Problem setup (5-15s) → Solution/product (15-25s) → CTA+brand (25-30s) |
| 60s | Hook (0-5s) → Emotional engagement (5-15s) → Product demo (15-35s) → Social proof (35-50s) → Strong CTA (50-60s) |

### Format 2: Non-Skippable In-Stream

15 or 20 seconds exactly (varies by market). No skip button. Charged on CPM.
Ideal for brand awareness. Must deliver complete message within the time limit.
Structure: brand in first 3 seconds, key message by second 10, CTA at the end.

### Format 3: Bumper Ads (6 seconds)

Maximum 6 seconds strict. Non-skippable. Bidding: CPM.
Google found **70% of bumper ads generated significant brand awareness lift,
with an average lift of 9%**.

**Rules of thumb:**
- ONE single message per ad — don't try to cram multiple points
- Give 2 full seconds to the closing so the thought can land
- Don't cut down longer ads — build specifically for 6 seconds
- Logo/brand colors visible throughout the entire ad
- Use **sequential bumpers** (3-5 bumpers telling facets of a campaign) for complex stories
- Focus on ONE emotion, ONE product feature, or ONE CTA
- Text supers: max 6-8 words on screen at any time

### Format 4: In-Feed Video Ads (ex-Discovery)

Appear in YouTube search results, "Watch Next" feed, and Discover. Users choose to watch
(opt-in format). Thumbnail is critical — treat it like a YouTube organic thumbnail.
Custom thumbnail recommended (auto-selected frames often perform poorly).
Title: max 100 chars (but first 25-30 are visible). Description: max 2 lines visible.

### Format 5: YouTube Shorts Ads

Vertical 9:16 mandatory. Min resolution 720×1280, recommended 1080×1920.
Recommended duration: **10-30 seconds** for action campaigns, 30-60 for video views.

**Sound is ON by default** (unlike other social platforms). Using sound (music + voice)
increases conversions by **20%+** (Google data).

Key differences from standard video:
- Hook must happen in **1-2 seconds** (faster than in-stream)
- UGC/creator style outperforms polished "TV commercial" style
- CTV screens generated nearly half of Shorts ad spend (Tinuiti benchmark)
- Include at least **3 Shorts ads per campaign** for optimal Brand Lift
- Swipe-up CTA is the primary interaction (not click)
- Safe zone: keep critical content away from edges (UI elements overlay)

### Format 6: Video Reach Campaigns

Mix of skippable in-stream, non-skippable, and bumpers in a single campaign.
Google's AI optimizes the mix for maximum unique reach at lowest CPM.
Provide videos in all three formats (6s, 15s, 30s+) for best results.

### Google's ABCD Framework for Video Ads

Validated by Google/Kantar on 11,000+ ads: **30% more likely to drive short-term sales
and 17% more long-term brand contribution**.

**A — Attract:**
- Close-up shots, 2+ shots in first 5 seconds
- People visible, especially faces
- Audio from frame 1
- Bold, surprising visuals
- Tight framing (avoid wide establishing shots)

**B — Brand:**
- Show brand in first 5 seconds
- Maintain brand presence throughout (not just end card)
- Audio mentions of brand name
- Use all brand assets: logo, colors, characters, sonic branding
- Product as hero, not just backdrop

**C — Connect:**
- Humanize the story with real people
- Keep message focused and simple (ONE key takeaway)
- Use humor, surprise, or intrigue
- Reflect audience diversity
- Tell stories, don't just list features
- Speak TO the viewer, not AT them

**D — Direct:**
- Explicit CTA in both text and audio
- Create urgency: time-limited offers, specific deadlines
- Present CTA after establishing context (not cold)
- Make the next step crystal clear
- Use end screens and cards for reinforcement

**ABCDs Detector**: Google's open-source tool (`github.com/google-marketing-solutions/abcds-detector`)
uses AI (Gemini) to automatically evaluate videos against the ABCD framework.

### AI Video Tools (2025-2026)

**Asset Studio** (free for all advertisers since September 2025):
- **Imagen 4**: text-to-image in 2K resolution
- **Nano Banana Pro**: editing with natural language prompts
- **Veo 3**: video generation from static images

Brands using Veo 3-generated videos for Shorts saw **22% lower CPA** (late 2025 data).

External tools gaining traction: OpenAI Sora, Runway, HeyGen Pro, Synthesia, Creatify.
IAB reports **86% of advertisers** use or plan to use generative AI for video ads.

### Video for PMax: Minimum Viable Set

Provide at least:
- 1 horizontal (16:9) video, 15-30 seconds
- 1 vertical (9:16) video, 15-30 seconds
- 1 square (1:1) video, 15-30 seconds

This covers YouTube in-stream, Shorts, Display, and Discover placements.

---

## 6. App Campaign Ads

App campaigns (formerly Universal App Campaigns / UAC) run across Search, Play Store,
YouTube, Display, and Discover. Google's AI combines your assets to create ads
automatically — you don't design individual ads.

### Text Specs

| Field | Max Count | Max Characters | Min Required |
|-------|-----------|---------------|-------------|
| Headlines | 5 | 30 chars each | 1 (Install), 2 (Engagement) |
| Descriptions | 5 | 90 chars each | 1 (Install), 1 (Engagement) |

Each text asset must function independently. Avoid repetition between headlines and
descriptions. Include CTAs in descriptions, not headlines (headlines may display alone).

### Image Specs

| Aspect Ratio | Recommended Size | Min Size | Max Count | Max Weight |
|-------------|-----------------|---------|-----------|-----------|
| Landscape 1.91:1 | 1200×628 px | 600×314 px | 20 total | 5 MB |
| Square 1:1 | 1200×1200 px | 200×200 px | (across all | |
| Portrait 4:5 | 1200×1500 px | 480×600 px | orientations) | |

JPG or PNG only. No text overlays covering >20% of image area.

### Video Specs

| Orientation | Aspect Ratio | Duration | Max Count |
|-------------|-------------|----------|-----------|
| Horizontal | 16:9 | 10-60 seconds | 20 total |
| Vertical | 9:16 | 10-60 seconds | (combined) |
| Square | 1:1 | 10-60 seconds | |

Google recommends **7 vertical videos** as priority for Shorts/mobile placements.

### HTML5 / Playable Ads

- Format: ZIP file, max 5 MB, max 512 files
- Available ONLY for App Install campaigns
- Gameplay: 30-60 seconds interactive experience
- Playable ads show a mini-game or demo of the app
- Playtika reported **1.8× increase in ROAS** using playables
- Must include a clear CTA at the end of the playable experience

### App Campaign Optimization Rules

- Minimum daily budget: **10× your target CPI/CPA**
- Don't change target CPI/CPA more than 20% in 24 hours
- Scale budgets max 20% every 48-72 hours
- Wait 5-7 days of consistent CPAs before scaling
- Need **20-30+ target events daily** before making changes
- App campaigns need **2-3 weeks** of learning period
- Provide maximum asset variety: 5 headlines, 5 descriptions, 20 images, 20 videos

### Creative Tips for App Campaigns

- **Show the app in use** — screen recordings outperform generic lifestyle images
- **Highlight key features** — one feature per headline/description
- **App Store rating** — include "4.8★ on App Store" in descriptions if applicable
- **Size/speed** — "Lightweight App — Only 25 MB" or "Setup in 30 Seconds"
- **Social proof** — "10M+ Downloads" or "Trusted by X Users"
- **Video**: show actual UI, demonstrate core value prop in first 3 seconds
- **Vertical video is king** — 80%+ of app installs happen on mobile

---

## 7. Responsive Display Ads

RDAs are the default ad type for Display campaigns. They automatically adapt to
fit any Display Network placement: native ads, banners, text ads, full-width cards.

### Text Specs

| Field | Max Characters | Max Count | Recommended |
|-------|---------------|-----------|-------------|
| Short Headlines | 30 chars | 5 | 5 |
| Long Headline | 90 chars | 1 | 1 |
| Descriptions | 90 chars | 5 | 5 |
| Business Name | 25 chars | 1 | 1 |

**Key rule**: Short headline and long headline may show WITHOUT description. Each must
work as a standalone message. Short headlines are NOT truncated — stay within 30 chars.

### Image Specs

| Type | Aspect Ratio | Recommended Size | Min Size | Required? |
|------|-------------|-----------------|---------|-----------|
| Landscape | 1.91:1 | 1200×628 px | 600×314 px | ✓ Yes |
| Square | 1:1 | 600×600 px | 300×300 px | ✓ Yes |
| Logo (square) | 1:1 | 1200×1200 px | 128×128 px | ✓ Yes |
| Logo (landscape) | 4:1 | 1200×300 px | 512×128 px | Optional |

Up to **15 images + 5 logos**. JPG or PNG only, max 5 MB. Animated GIFs NOT allowed.
Images may be cropped up to **5%** to fit placements.

### Image Best Practices for Display

- Avoid text overlays on images (Google may reject or perform poorly)
- No fake buttons (play, download, close) — policy violation
- Product/service must be the focus
- Use images in physical settings with organic shadows (not digital composites on white)
- People using the product outperform product-only shots
- Bright, high-contrast images outperform muted/dark images
- Do NOT include borders or frames

### Display Ad Creative Tips

- Google reports **~10% more conversions** with similar CPA when using multiple asset variations
- RDAs adapt to: native ads, display banners (300×250, 728×90, 320×50), text-only, full-width cards
- **Top-performing banner sizes**: 300×250 (Medium Rectangle), 336×280 (Large Rectangle),
  728×90 (Leaderboard), 160×600 (Wide Skyscraper), 320×50 (Mobile Leaderboard)
- For uploaded display ads (non-responsive): max 150 KB per file, HTML5 ads supported
- Long headline is most commonly displayed — invest most effort here
- Write descriptions assuming headline may not be shown
- Use "Enhance CPC" or "Target CPA" bidding for best automation results

---

## 8. Call Ads and Call Assets

### Call Ads: Officially Deprecated

Google announced call ad deprecation on **October 3, 2025**:
- **February 2026**: no new call ads can be created
- **February 2027**: all existing call ads stop serving

**API note**: `CallAd` and `CallAdInfo` were removed entirely in API v23.

### Replacement: RSAs with Call Assets

The replacement strategy is **RSAs + call assets**. Transition steps:
1. Add business name to account settings
2. Add phone numbers as call assets (at campaign or ad group level)
3. Create RSAs with call extensions attached
4. Call assets show a phone icon/number alongside the RSA

### Call Asset Best Practices

- Landing pages must include a **tappable phone number**
- Include a **"Call Now" button** with high contrast
- Page load must be **<2 seconds** on mobile
- Include a **backup form** for users who prefer not to call
- Use **call reporting** to track which ads drive calls
- Set **call scheduling** to match business hours (avoid missed calls)
- Minimum call duration for conversion tracking: recommended **60 seconds**
- Write RSA copy that reinforces calling: "Speak to an Expert", "Call for Free Consultation"

---

## 9. Hotel Ads and Travel Ads

### Hotel Booking Links

Show prices and availability with direct booking links. Appear in Search and Maps
when travelers search for a specific hotel (high intent). Require Hotel Center with
a rates/availability feed.

### Travel Promotion Ads

Appear in immersive listings and Maps during destination discovery (awareness phase).
Broader reach than booking links. Target travelers researching destinations.

### Bidding Options

- Maximize Conversion Value
- Max CPC (manual)
- Enhanced CPC
- Commission per conversion (pay only for actual bookings)

### Travel Feeds in Search Ads (New)

Enrich standard Search ads with prices and images from Hotel Center.
Up to **20% higher CTR** compared to standard Search ads.

### PMax for Travel Goals

Creates automatic ads across Maps, Search, YouTube, and Hotel Ads for up to 100
properties per campaign. Case study: Corissia Hotels saw **32% more revenue and
26% more direct bookings** using PMax Travel Goals.

### Hotel Feed Optimization

- **Accurate pricing**: update rates at least daily (hourly is better)
- **Landing page parity**: rates on landing page MUST match feed
- **Room details**: include room type, amenities, cancellation policy
- **High-quality photos**: minimum 4 per property (exterior, room, bathroom, amenity)
- **Reviews**: properties with Google reviews >4.0★ see higher conversion rates
- **Tax/fee transparency**: include all taxes in displayed price when possible

---

## 10. Local Services Ads

### How They Work

Pay-per-lead model: you pay ONLY when a customer contacts you (call or message).
Appear in the highest position of search results.
Google handles keyword targeting automatically (no keywords to manage).

### Eligibility

- **70+ business categories**: HVAC, plumbers, electricians, lawyers, accountants,
  dentists, cleaners, pest control, movers, locksmiths, and many more
- Available in North America and select European countries
- Requires: Google Business Profile verification (mandatory since November 2024),
  background checks, proof of licenses and insurance

### Google Verified Badge

In October 2025, Google simplified all badges to a single **"Google Verified"** badge.
The LSA app was retired in January 2025 — all management now via Google Ads interface.

### LSA Optimization Tips

- Response speed matters: businesses responding within **5 minutes** convert 4× better
- Maintain 4.5★+ average review rating
- Request reviews after every completed job
- Set accurate service areas and hours
- Budget at least **$500/month** for meaningful lead volume
- Dispute invalid leads within 30 days

---

## 11. Copywriting Frameworks and Psychological Triggers

### AIDA (Attention → Interest → Desire → Action)

Applied to Google Ads:
- **Attention** (Headline 1): "Stop Wasting Money on Ads"
- **Interest** (Headline 2): "AI Writes Your Copy in Minutes"
- **Desire** (Headline 3 / Description 1): "Join 10,000+ Marketers Saving Hours"
- **Action** (Description 2): "Free 14-Day Trial — No Credit Card Required"

### PAS (Problem → Agitate → Solve)

- **Problem** (Headline 1): "Is Your Site Loading Slow?"
- **Agitate** (Description 1): "Every second of load time costs you 7% in conversions
  and frustrated customers."
- **Solve** (Headline 2 / Description 2): "Ultra-Fast Hosting" / "Improve speed in
  24 hours. Free migration included."

### BAB (Before → After → Bridge)

- **Before** (Headline 1): "Struggling with Lead Gen?"
- **After** (Headline 2): "Get 50+ Qualified Leads Monthly"
- **Bridge** (Description): "Our proven system delivers predictable pipeline. Start
  your free trial today."

### Psychological Triggers with Highest Impact

**Urgency** (up to **332% more conversions** per CXL data):
- Countdown timers + urgent copy = most effective combination
- "Offer Ends Tonight" + `{COUNTDOWN(...)}` in headline
- Time-specific urgency ("Offer Ends March 31") outperforms vague ("Limited Time")

**Scarcity based on quantity** outperforms time-based scarcity:
- "Only 5 Spots Left This Month" > "Offer Ends Soon"
- "3 Items Remaining" > "Sale This Weekend"

**Social proof with specific numbers:**
- "Rated 4.9★ on Google Reviews" (specific beats vague)
- "Trusted by 50,000+ Businesses" (large numbers = authority)
- "500+ 5-Star Reviews" (quantified social proof)

**Authority:**
- "Recommended by Dermatologists"
- "Award-Winning — Best CRM 2025"
- "As Featured in Forbes, TechCrunch"
- Certifications, partnerships, industry awards

**Reciprocity** — offer something free first:
- "Download Your Free Guide"
- "Free Audit of Your Website"
- "No-Obligation Consultation"

**Loss aversion** — frame what they'll miss:
- "Don't Miss Out on 50% Savings"
- "Stop Losing Customers to Slow Websites"
- "Every Day Without [Product] Costs You $X"

### Features vs Benefits: The Translation Rule

Never sell the feature; sell the outcome:

| Feature | Benefit Translation |
|---------|-------------------|
| 256-bit SSL Encryption | Your Data Is Bank-Level Secure |
| 24/7 Live Chat Support | Expert Help When You Need It |
| 60+ Ad Templates | Create Ads in Minutes, Not Hours |
| AI-Powered Analysis | Insights That Save You 10 Hours/Week |
| 99.99% Uptime SLA | Your Site Never Goes Down |
| Free Returns Within 30 Days | Shop Risk-Free |

### Numbers in Ad Copy: Why They Work

- Ads with numbers have **36% higher CTR** (WordStream data)
- Odd numbers outperform even numbers in headlines
- Specific numbers outperform rounded: "247% ROI" > "200% ROI"
- Prices in headlines increase qualified clicks and reduce wasted spend
- Stats/data create credibility: "Reduce Costs by 37%"

---

## 12. Quality Score and Ad Relevance

### The Three Components

Quality Score is rated **1-10** per keyword, based on three subcomponents
with estimated weights:

| Component | Estimated Weight | What It Measures |
|-----------|-----------------|-----------------|
| Expected CTR | ~39% | Likelihood your ad gets clicked |
| Ad Relevance | ~22% | How closely ad matches search intent |
| Landing Page Experience | ~39% | Post-click relevance and usability |

### How Copy Affects Each Component

**Expected CTR:**
- Specific headlines with benefits, numbers, and CTAs outperform generic copy
- DKI can improve CTR by making ads match queries more closely
- Strong emotional triggers (urgency, social proof) boost click rates
- Including price in ad can lower CTR but increase conversion rate (qualified clicks)

**Ad Relevance:**
- Include primary keyword in at least 2-3 headlines
- Use single-theme ad groups (STAGs) for maximum keyword-ad alignment
- Match ad language to search intent (informational vs transactional)
- Avoid generic headlines that could apply to any business

**Landing Page Experience:**
- **Message match**: landing page headline must reflect ad headline
- Mobile speed: 1 second of delay = **up to 20% fewer conversions**
- Trust signals: reviews, certifications, security badges
- Above-fold CTA matching the ad's promise
- Original, useful content (not thin affiliate pages)

### Impact on CPC

Ads with "Above Average" in landing page experience and ad relevance had **CPCs 36%
below average** (industry benchmark data). One medical case study improved conversions
from 11.8% to 26.7% and Quality Score from 7.2 to 9.3 by aligning landing pages with ads.

---

## 13. AI-Powered Creative Workflows

### Google's Asset Studio (Free, September 2025)

Centralized platform with:
- **Imagen 4**: text-to-image generation in 2K resolution
- **Nano Banana Pro**: editing with natural language prompts
- **Veo 3**: video generation from static images
- Batch processing up to 100 images
- Style references for brand consistency
- Shareable links for team review

Google reported that Gemini generated nearly **70 million creative assets** in Q4 2025
alone. Brands using Veo 3-generated videos for Shorts saw **22% lower CPA**.

### AI + Human Workflow: The Winning Combination

A 30-day study (PPC Hero) found:
- **ChatGPT + human editing: highest CTR (10.87%)**, most leads (169), lowest CPL ($5.36)
- Pure human copy: CTR 10.92% but higher CPL ($5.75)
- Pure AI (unedited): lower quality, policy compliance issues
- **Important**: Google's AI sometimes doesn't respect character limits; Claude and
  ChatGPT consistently produce headlines of the correct size

**Recommended workflow:**
1. **Prompt engineering**: specific product, audience, USP, and character limits
2. **Generate 10-20+ variations** per ad group
3. **Human review**: brand voice, accuracy, compliance
4. **Let RSA/PMax system test** combinations
5. **Monitor asset performance reports** (asset-level metrics)
6. **Refresh every 4-6 weeks** (creative fatigue is real)

### AssetGenerationService (API, v22+)

Programmatic access to Google's generative AI for ad assets:
```python
# Generate text and image assets for PMax
asset_generation_service = client.get_service("AssetGenerationService")
request = client.get_type("GenerateAssetsRequest")
# ... configure with product info, brand guidelines, etc.
```
See `references/campaign-management.md` for full API usage.

### External AI Tools for Ad Creative (2025-2026)

- **OpenAI (ChatGPT/Sora)**: text copy generation, video generation
- **Anthropic (Claude)**: ad copy, strategy analysis, bulk generation
- **Runway**: video editing and generation
- **HeyGen Pro**: AI avatars for video ads
- **Synthesia**: AI presenter videos
- **Creatify**: AI video ads from product URLs
- **AdCreative.ai**: automated display/social ad generation

IAB reports **86% of advertisers** use or plan to use generative AI for video ads.

---

## 14. Compliance and Policy Pitfalls

### Most Common Editorial Errors

**Capitalization:**
- Prohibited: excessive or tricky caps (FLOWERS, FlOwErS, F.L.O.W.E.R.S.)
- Allowed: Title Case, sentence case, standard acronyms (USA, IBM)

**Punctuation:**
- Prohibited: repeated punctuation (flowers!!, ???, ...)
- Prohibited: non-standard symbol use (fl@wers, f1owers)
- Allowed: one exclamation mark per ad, standard punctuation

**Emojis:**
- Prohibited in Search Ads
- Allowed in Display and Demand Gen (but use sparingly)

**Phone numbers:**
- Prohibited in ad text (use call assets instead)

**Repetition:**
- Prohibited: repeating same words/phrases within an asset or across assets
  in the same ad group ("Best deals best deals best deals")

### Superlative Claims and Pricing Policies

Claims like "best", "top", "#1", "guaranteed" require **third-party verification**.
Must include links to verifiable endorsements.

Since October 2025: **Dishonest Pricing Practices** policy:
- Disclose all costs upfront
- No hidden fees
- No bait-and-switch tactics
- No exploitative pricing targeting vulnerable users

### Industry-Specific Restrictions

**Healthcare:**
- Online pharmacies require LegitScript certification
- Telemedicine requires certification
- Prohibited: unapproved pharmaceuticals, unsafe weight loss practices,
  before/after images making unrealistic claims

**Financial services:**
- Enhanced certification for credit, loans, and investments
- Loans with APR >36% prohibited
- Binary options completely prohibited
- Cryptocurrency advertising requires certification

**Alcohol, gambling, political ads:**
- Age-gating requirements
- Geographic restrictions
- Special certifications required

### Policy Enforcement Stats

Google suspended **39.2 million advertiser accounts** in 2024 and blocked/removed
**5.1 billion ads**. Policy violations can result in:

- Ad disapproval (can be appealed)
- Account warning (7-day notice typically)
- Account suspension (immediate for severe violations)

**Appeals process**: Policy Manager (Tools > Troubleshooting > Policy Manager).
Maximum 2 appeals per ad. Response typically within 1-3 business days.

---

## 15. Cross-Format Strategy: The Power Pack (2026)

Google now officially promotes the **"Power Pack"** campaign structure:

| Campaign Type | Role | Key Metric |
|--------------|------|-----------|
| Demand Gen | Create awareness and interest | CPM, Engaged Views, Brand Lift |
| AI Max (Search) | Capture intent at search moment | CPA, Conversions, ROAS |
| Performance Max | Orchestrate full-funnel performance | Conversion Value, ROAS |

This three-campaign strategy covers the entire funnel:
1. **Demand Gen** introduces your brand through visually rich, feed-native ads
   on YouTube, Discover, Gmail, GDN, and Connected TV
2. **AI Max** captures the search intent when users actively look for solutions,
   with AI-generated text customization extending reach into AI Overviews
3. **PMax** retargets, cross-sells, and maximizes conversion value across all
   surfaces including Maps, Shopping, and Display

### Universal Principles That Never Change

Regardless of format, the principles separating winning advertisers from mediocre ones:

1. **Specificity beats generality**: concrete numbers, tangible benefits, direct CTAs
2. **Relevance beats volume**: an RSA with "Good" Ad Strength and relevant copy beats
   "Excellent" with generic copy every time
3. **The complete system matters**: best headline fails if landing page doesn't deliver
4. **Test continuously**: at least one active experiment at all times
5. **Refresh creatives**: static assets every 4-6 weeks, video every 8-12 weeks
6. **AI as co-pilot, not replacement**: human review catches brand misalignment and
   policy violations that pure AI misses
7. **Mobile-first creative**: 70%+ of Google ad clicks happen on mobile devices
8. **Message match**: ad → landing page → conversion action must tell ONE coherent story
