# Smart Bidding Reference

## Table of Contents
1. [Overview](#overview)
2. [Decision Framework](#decision-framework)
3. [Target CPA](#target-cpa)
4. [Target ROAS](#target-roas)
5. [Maximize Conversions](#maximize-conversions)
6. [Maximize Conversion Value](#maximize-conversion-value)
7. [Enhanced CPC (Legacy)](#enhanced-cpc)
8. [Target Impression Share](#target-impression-share)
9. [Portfolio Bid Strategies](#portfolio-bid-strategies)
10. [Bid Strategy Experiments](#bid-strategy-experiments)
11. [Conversion Value Rules](#conversion-value-rules)
12. [Customer Lifecycle Goals](#customer-lifecycle-goals)
13. [Attribution Model Impact](#attribution-model-impact)
14. [Precision Scheduling (v23)](#precision-scheduling)
15. [Learning Period](#learning-period)
16. [Migration Path](#migration-path)
17. [Troubleshooting](#troubleshooting)

---

## Overview

Smart Bidding uses Google's ML to set bids at **auction time** for every single search.
Unlike manual bidding, it considers signals that aren't available to humans:

### Auction-Time Signals

| Signal | Description |
|--------|------------|
| **Device** | Mobile, desktop, tablet |
| **Location** | Country, region, city, ZIP |
| **Time of day** | Hour and day of week |
| **Remarketing list** | User's audience membership |
| **Browser / OS** | Chrome, Safari, iOS, Android |
| **Query** | Actual search term (beyond keyword) |
| **Ad creative** | Which ad variant is shown |
| **Language** | User's browser/interface language |
| **Competitive landscape** | Other advertisers in auction |
| **Conversion probability** | Google's ML prediction per user |

Smart Bidding requires conversion tracking. Without it, only Manual CPC and
Target Impression Share are available.

---

## Decision Framework

| Your Goal | Strategy | Requirements | Best For |
|-----------|----------|-------------|----------|
| Max leads at target cost | **Target CPA** | 50+ conv/30d | Lead gen, fixed cost per acquisition |
| Max revenue at target return | **Target ROAS** | 50+ conv/30d + value tracking | E-commerce, revenue optimization |
| Max leads within budget | **Maximize Conversions** | 15+ conv/30d | New campaigns, scaling |
| Max revenue within budget | **Max Conversion Value** | 15+ conv/30d + value tracking | E-commerce, revenue focus |
| Visibility / brand | **Target Impression Share** | N/A | Brand terms, competitor conquesting |
| Testing / low volume | **Enhanced CPC** | N/A | < 30 conv/month, gradual automation |
| Manual control | **Manual CPC** | N/A | Micro-niche, very low volume |

### Minimum Data Requirements

| Strategy | Minimum Conversions | Ideal Conversions | Time Window |
|----------|-------------------|-------------------|-------------|
| Target CPA | 30 (functional) | 50+ | Last 30 days |
| Target ROAS | 30 (functional) | 50+ | Last 30 days |
| Maximize Conversions | 15 | 30+ | Last 30 days |
| Max Conversion Value | 15 | 30+ | Last 30 days |

Below these thresholds, Smart Bidding lacks sufficient data for reliable optimization.
Use Manual CPC or Enhanced CPC until you accumulate enough conversions.

---

## Target CPA

Automatically sets bids to get as many conversions as possible at or below your target
cost per acquisition.

### Setting Target CPA via API

```python
# On campaign
camp.target_cpa.target_cpa_micros = 5_000_000  # $5.00 target CPA

# With Maximize Conversions + CPA cap
camp.maximize_conversions.target_cpa_micros = 5_000_000
```

### Best Practices

1. **Start at actual CPA**: Set target at your current average CPA, then adjust
2. **Don't set too aggressive**: If current CPA is $10, don't start at $3
3. **Adjust in 10-20% increments**: Gradual changes prevent disrupting learning
4. **Wait 2 weeks minimum** before evaluating performance
5. **Consider conversion delay**: Some conversions take days to report

### Seasonal Adjustments

```python
# Seasonality adjustment: expect 30% more conversions next 7 days
from google.ads.googleads.v23.services.types import BiddingSeasonalityAdjustmentOperation

adjustment_op = client.get_type("BiddingSeasonalityAdjustmentOperation")
adj = adjustment_op.create
adj.name = "Holiday Sale Expected Lift"
adj.scope = client.enums.SeasonalityEventScopeEnum.CAMPAIGN
adj.campaigns.append(f"customers/{cid}/campaigns/{campaign_id}")
adj.start_date_time = "2026-02-14T00:00:00-05:00"
adj.end_date_time = "2026-02-21T23:59:59-05:00"
adj.conversion_rate_modifier = 1.3  # 30% more conversions expected
```

### Constraints

- Works with Search, Display, Shopping, App, Demand Gen campaigns
- NOT available for Video (use Max Conversions instead)
- `target_cpa_micros = 0` means "no target CPA cap" (equivalent to Max Conversions)

---

## Target ROAS

Optimizes bids to maximize conversion value at your target return on ad spend.

### Setting Target ROAS via API

```python
# On campaign
camp.target_roas.target_roas = 3.5  # 350% ROAS (return $3.50 per $1 spent)

# With Maximize Conversion Value + ROAS cap
camp.maximize_conversion_value.target_roas = 3.5
```

### Prerequisites

- **Conversion value tracking** must be configured (not just conversion counts)
- Values can come from: tag-based tracking, enhanced conversions, offline imports,
  Data Manager API, or conversion value rules

### Calculating Target ROAS

```
Target ROAS = (Desired Revenue / Ad Spend) × 100%

Example:
- You want $3.50 revenue for every $1 spent
- Target ROAS = 350% = 3.5 in the API
```

### Interaction with Conversion Value Rules

Conversion Value Rules adjust values BEFORE they reach Smart Bidding:

```
Actual conversion: $50
Value Rule: +20% for returning customers
Value seen by Smart Bidding: $60
```

This means Smart Bidding bids more aggressively for returning customers without
changing your target ROAS. See §11 (Conversion Value Rules) for API details.

---

## Maximize Conversions

Gets the most conversions possible within your budget. No target — spends entire daily
budget.

### Setting via API

```python
# Pure Maximize Conversions (no cap)
camp.maximize_conversions.target_cpa_micros = 0

# Maximize Conversions with CPA cap (= functionally Target CPA)
camp.maximize_conversions.target_cpa_micros = 5_000_000
```

### Budget Relationship

**Critical**: Maximize Conversions will spend your ENTIRE daily budget. If you set a
$100/day budget, expect close to $100/day spend — it optimizes for volume, not efficiency.

### When to Use

- New campaigns with limited conversion data (15+ conv/30d)
- Budget-constrained accounts where spending the full budget is desired
- Transitioning from Manual CPC (step before adding a CPA target)
- Campaigns where cost per conversion varies and you want maximum volume

---

## Maximize Conversion Value

Gets the most conversion VALUE within your budget. Prioritizes high-value conversions.

### Setting via API

```python
# Pure Maximize Conversion Value (no ROAS target)
camp.maximize_conversion_value.target_roas = 0

# With ROAS target (= functionally Target ROAS)
camp.maximize_conversion_value.target_roas = 3.5
```

### Prerequisites

- Conversion value tracking (tag, enhanced conversions, or offline imports)
- Multiple conversion values (if all conversions have the same value, this is identical
  to Maximize Conversions)

### LTV Signal Integration

Feed lifetime value signals to make this strategy much more powerful:

1. Upload customer LTV via Enhanced Conversions for Leads
2. Apply Conversion Value Rules (audience × value multiplier)
3. Set Customer Lifecycle Goals for new vs existing customer differentiation

See `first-party-data-strategy.md` for implementation details.

---

## Enhanced CPC

**Legacy strategy** that adjusts your manual bids up or down based on conversion likelihood.

### Setting via API

```python
camp.manual_cpc.enhanced_cpc_enabled = True
```

### When It Still Makes Sense

- Less than 30 conversions per month
- You want manual control with slight automation
- Very niche campaigns with limited data
- Gradual transition from pure Manual CPC

### Limitations

- Less effective than full Smart Bidding strategies
- Google recommends migrating to Maximize Conversions once you have 15+ conv/30d
- May be deprecated in future API versions

---

## Target Impression Share

Bids to achieve a target percentage of available impressions. **Search campaigns only.**

### Setting via API

```python
camp.target_impression_share.location = (
    client.enums.TargetImpressionShareLocationEnum.ANYWHERE_ON_PAGE)
camp.target_impression_share.location_fraction_micros = 650_000  # 65% target
camp.target_impression_share.cpc_bid_ceiling_micros = 3_000_000  # $3 max CPC
```

### Location Options

| Location | Enum | Use Case |
|----------|------|----------|
| Top of page | `TOP_OF_PAGE` | Premium visibility |
| Absolute top | `ABSOLUTE_TOP_OF_PAGE` | Maximum visibility (position 1) |
| Anywhere | `ANYWHERE_ON_PAGE` | General presence |

### Best For

- **Brand terms**: Ensure competitors don't outbid you on your own brand
- **Competitor conquesting**: Maintain visibility on competitor searches
- **Awareness**: Maximize impressions regardless of conversion efficiency

### Important

- Always set `cpc_bid_ceiling_micros` to prevent runaway costs
- This strategy optimizes for visibility, NOT conversions
- Don't use for performance/conversion campaigns

---

## Portfolio Bid Strategies

Share a single bid strategy across multiple campaigns for unified learning and pacing.

### Creating via API

```python
# Create shared strategy
strategy_op = client.get_type("BiddingStrategyOperation")
strategy = strategy_op.create
strategy.name = "Shared tCPA Strategy — Lead Gen"
strategy.maximize_conversions.target_cpa_micros = 5_000_000

response = bidding_strategy_service.mutate_bidding_strategies(
    customer_id=cid, operations=[strategy_op])
strategy_rn = response.results[0].resource_name

# Assign to campaign
camp_op = client.get_type("CampaignOperation")
camp = camp_op.update
camp.resource_name = f"customers/{cid}/campaigns/{campaign_id}"
camp.bidding_strategy = strategy_rn
```

### Benefits

- **Unified learning**: More data across campaigns accelerates optimization
- **Budget pacing**: Strategy considers total portfolio spend
- **Consistency**: Same logic applied across related campaigns

### When to Use

- Multiple campaigns targeting similar audiences with same conversion goal
- Low-volume campaigns that individually lack sufficient data
- Agency managing many campaigns of the same type

---

## Bid Strategy Experiments

A/B test bid strategies before committing:

```python
# Create experiment
experiment_op = client.get_type("ExperimentOperation")
exp = experiment_op.create
exp.name = "tCPA vs Max Conv Test"
exp.type_ = client.enums.ExperimentTypeEnum.SEARCH_CUSTOM
exp.status = client.enums.ExperimentStatusEnum.SETUP
exp.start_date = "2026-03-01"
exp.end_date = "2026-04-15"
exp.suffix = " [Experiment]"

# Create experiment arm
arm_op = client.get_type("ExperimentArmOperation")
arm = arm_op.create
arm.experiment = experiment_resource_name
arm.name = "Target CPA Arm"
arm.campaigns.append(f"customers/{cid}/campaigns/{variant_campaign_id}")
arm.traffic_split = 50  # 50% of traffic
```

### Best Practices

- Run for **4-6 weeks minimum** (2+ learning periods)
- Use **50/50 traffic split** for statistical significance
- Don't change other variables during the experiment
- Monitor both conversion volume AND CPA/ROAS

---

## Conversion Value Rules

Adjust conversion values dynamically based on audience, location, or device signals.
These adjustments happen BEFORE Smart Bidding sees the value.

### Setting via API

```python
# Create value rule: +25% value for returning customers
rule_op = client.get_type("ConversionValueRuleOperation")
rule = rule_op.create
rule.action.operation = client.enums.ValueRuleOperationEnum.ADD
rule.action.value = 25.0  # Add $25 to conversion value
# OR: rule.action.operation = MULTIPLY, rule.action.value = 1.25 (multiply by 1.25)

# Condition: audience is "Returning Customers" list
audience_condition = rule.audience_condition
audience_condition.user_lists.append(f"customers/{cid}/userLists/{list_id}")

# Apply at campaign or account level
rule_set_op = client.get_type("ConversionValueRuleSetOperation")
rule_set = rule_set_op.create
rule_set.conversion_value_rules.append(rule_resource_name)
rule_set.dimensions.append(client.enums.ValueRuleSetDimensionEnum.GEO_LOCATION)
rule_set.attachment_type = client.enums.ValueRuleSetAttachmentTypeEnum.CAMPAIGN
rule_set.campaign = f"customers/{cid}/campaigns/{campaign_id}"
```

### Use Cases

| Rule | Effect | Strategy |
|------|--------|----------|
| +20% for returning customers | Smart Bidding bids higher for known users | Retention optimization |
| +30% for high-income ZIP codes | Higher bids in affluent areas | Geographic value targeting |
| -10% for mobile | Lower bids for lower-converting device | Device value adjustment |
| +50% for cart abandoners | Aggressive bids for high-intent users | Recovery optimization |

---

## Customer Lifecycle Goals

Tell Smart Bidding to differentiate between new and existing customers.

### Setting via API

```python
# Set customer acquisition goal
camp.customer_acquisition_goal_settings.optimization_mode = (
    client.enums.CustomerAcquisitionOptimizationModeEnum.TARGET_ALL_EQUALLY)
# Options: TARGET_ALL_EQUALLY, BID_HIGHER_FOR_NEW_CUSTOMERS, TARGET_NEW_CUSTOMERS_ONLY

# Upload customer list for "existing customer" identification
# Uses UserListCustomerType with type PURCHASERS
```

### Modes

| Mode | Behavior | Use Case |
|------|----------|----------|
| `TARGET_ALL_EQUALLY` | No differentiation | Default, balanced approach |
| `BID_HIGHER_FOR_NEW_CUSTOMERS` | Bonus bid for new customers | Acquisition focus + retention |
| `TARGET_NEW_CUSTOMERS_ONLY` | Only bid on new customers | Pure acquisition (PMax) |

### PMax Integration

Customer Lifecycle Goals are particularly powerful with PMax:
- Upload Customer Match list of all purchasers
- Set "Bid higher for new customers" with a new customer value
- PMax will prioritize acquiring users NOT on your list

See `first-party-data-strategy.md` §6 for complete implementation.

---

## Attribution Model Impact

Smart Bidding optimizes based on your chosen attribution model.

### Models (February 2026)

| Model | Description | Status |
|-------|------------|--------|
| **Data-driven** | ML-distributed credit | Default since Apr 2023 |
| **Last click** | 100% to last-clicked ad | Fallback for low data |
| **External** | Third-party attribution | Via import |

**Data-driven attribution** became the default in April 2023. Google deprecated
first-click, linear, time-decay, and position-based models.

### Impact on Smart Bidding

- Data-driven: Most signals, best optimization (recommended)
- Last-click: Conservative, may undervalue upper-funnel
- Changing attribution model triggers a learning period

### Cross-Network Attribution

In v23, PMax now reports `segments.ad_network_type`, enabling cross-network attribution
visibility. Smart Bidding already used cross-network signals internally, but now you
can see the breakdown.

---

## Precision Scheduling

v23 introduced datetime fields replacing date-only scheduling:

```python
# Schedule campaign to run Feb 14 noon to midnight EST
camp.start_date_time = "2026-02-14T12:00:00-05:00"
camp.end_date_time = "2026-02-14T23:59:59-05:00"
```

### Interaction with Bidding

- Smart Bidding adjusts for time-of-day automatically
- Precision scheduling lets you hard-stop campaigns at specific times
- Useful for flash sales, time-limited offers, event-based campaigns
- The bid strategy continues optimizing within the scheduled window

---

## Learning Period

When a Smart Bidding strategy is new or significantly changed, it enters a
**learning period** of approximately 7 days.

### What Triggers Learning

| Change | Triggers Learning? | Severity |
|--------|-------------------|----------|
| New bid strategy | Yes | Full 7 days |
| Change target CPA/ROAS by > 20% | Yes | Full 7 days |
| Change target CPA/ROAS by < 20% | Usually not | Minor adjustment |
| Add/remove conversion action | Yes | Full 7 days |
| Significant budget change (> 30%) | Sometimes | Partial |
| Pause/enable campaign | Sometimes | Partial |

### How to Minimize Disruption

1. **Make changes < 20%** at a time (avoid large jumps)
2. **Don't stack changes** — one change at a time, wait for learning to complete
3. **Avoid pausing** during learning — it resets the clock
4. **Monitor "Status" column** in Google Ads UI — shows "Learning" status
5. **Wait at least 14 days** before evaluating (7 days learning + 7 days stable)

### Checking Learning Status via API

```sql
SELECT campaign.bidding_strategy_type,
       campaign.bidding_strategy_system_status
FROM campaign
WHERE campaign.status = 'ENABLED'
```

`bidding_strategy_system_status` values include `LEARNING`, `LIMITED`, `ENABLED`.

---

## Migration Path

Recommended progression from manual to fully automated bidding:

```
Manual CPC → Enhanced CPC → Maximize Conversions → Target CPA
                                                  ↓
                                            (add value tracking)
                                                  ↓
                          Maximize Conversion Value → Target ROAS
```

### Step-by-Step

1. **Manual CPC**: Start here when you have < 15 conversions/month
2. **Enhanced CPC**: Enable when you have some conversion data but < 30/month
3. **Maximize Conversions**: Switch when you have 15+ conversions/30 days
4. **Target CPA**: Add a CPA target once you have 50+ conversions/30 days and
   understand your acceptable CPA
5. **Maximize Conversion Value**: Switch when you have value tracking enabled
6. **Target ROAS**: Add a ROAS target once you have 50+ conversions/30 days with
   varied values and understand your target ROAS

Each step should be stable for **at least 2-4 weeks** before progressing.

---

## Troubleshooting

### Insufficient Data

**Symptom**: Strategy stuck in "Learning" for > 14 days
**Causes**: Not enough conversions, conversion action changed, too many changes
**Fix**: Consider lowering conversion bar (micro-conversions), or switch to Max Conversions
without a target

### Over-Constraining

**Symptom**: Very low spend, strategy can't find auctions at target CPA/ROAS
**Causes**: Target too aggressive, budget too low, audience too narrow
**Fix**: Increase target CPA by 20-30%, or increase budget, or broaden targeting

### Budget-Limited

**Symptom**: "Limited by budget" status, CPA below target but low volume
**Causes**: Budget capped before Smart Bidding can fully optimize
**Fix**: Increase budget (if profitable at current CPA), or raise CPA target slightly

### Conversion Lag

**Symptom**: CPA appears to spike after changes, then normalizes after 5-7 days
**Causes**: Conversions take time to be reported (especially B2B, offline)
**Fix**: Wait 7+ days before evaluating. Check "All conversions" vs "Conversions" columns.
Use attribution window settings appropriate for your sales cycle.

### Learning Stuck

**Symptom**: "Learning" status persists after 14 days
**Causes**: Too many concurrent changes, very low volume, frequent pausing
**Fix**: Stabilize the campaign — stop making changes. If volume is too low, consider
consolidating campaigns or using a portfolio strategy.

### CPA/ROAS Drift

**Symptom**: Actual CPA/ROAS gradually drifting from target over weeks
**Causes**: Market changes, competitive shifts, audience fatigue
**Fix**: Adjust target in 10-15% increments. Review audience health. Refresh creatives.

---

## Cross-References

- **Bidding code patterns** → `campaign-management.md` §7 (Smart Bidding Strategies)
- **Value-based bidding with CRM data** → `first-party-data-strategy.md` §5
- **Customer Lifecycle Goals setup** → `first-party-data-strategy.md` §6
- **Conversion tracking setup** → `automation-and-reporting.md` §12
- **Audience signals for bidding** → `audiences-targeting.md`
- **Analytics for bid evaluation** → `analytics-reporting.md`
