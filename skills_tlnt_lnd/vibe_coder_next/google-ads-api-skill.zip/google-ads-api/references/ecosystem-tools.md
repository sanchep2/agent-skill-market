# Ecosystem & Tools Reference

## Table of Contents
1. [Official SDKs](#official-sdks)
2. [Community SDKs](#community-sdks)
3. [CLI: gaarf & gaql-cli](#cli-gaarf--gaql-cli)
4. [MCP Servers (Model Context Protocol)](#mcp-servers)
5. [Developer Assistant (Gemini)](#developer-assistant)
6. [REST API via cURL](#rest-api-via-curl)
7. [ETL & Data Integration](#etl--data-integration)
8. [Reverse ETL & CDP](#reverse-etl--cdp)
9. [iPaaS (Integration Platforms)](#ipaas)
10. [Campaign Management Platforms](#campaign-management-platforms)
11. [Data & Analytics Platforms](#data--analytics-platforms)
12. [Agency Reporting Tools](#agency-reporting-tools)
13. [Testing & Development Tools](#testing--development-tools)
14. [API Maturity Comparison](#api-maturity-comparison)
15. [What Does NOT Exist](#what-does-not-exist)

---

## Official SDKs

Google maintains first-party client libraries for 6 languages, all updated within days
of each API version release. All use **gRPC** as primary transport except Perl.

| Language | Package | Version (Jul 2026) | Min Runtime | Transport |
|----------|---------|-------------------|-------------|-----------|
| Python | `google-ads` | 31.1.0 | Python 3.9–3.14 | gRPC |
| Java | `com.google.api-ads:google-ads` | 43.1.0 | Java 1.8+ | gRPC |
| PHP | `googleads/google-ads-php` | 33.5.0 | PHP 8.1+ | gRPC |
| Ruby | `google-ads-googleads` | 42.0.0 | Ruby 3.0+ | gRPC |
| .NET | `Google.Ads.GoogleAds` | 26.0.1 | .NET 4.7.2+ | gRPC |
| Perl | `Google::Ads::GoogleAds::Client` | 32.2.0 | Perl 5.28.1+ | REST/HTTP 1.1 |

<!-- Versions last_verified: 2026-07-17 against each language's official registry
     (PyPI, Maven Central, Packagist, RubyGems, NuGet, MetaCPAN). Same values as SKILL.md. -->

All libraries track the v24 API surface (major released April 22, 2026; latest minor v24.2,
June 24, 2026).

### Python SDK Deep Dive

The Python SDK is the most popular. Key features:

```bash
pip install google-ads  # Core
pip install google-ads[tests]  # With test utilities
```

**Configuration methods** (in priority order):
1. `GoogleAdsClient.load_from_dict({...})` — programmatic, ideal for containers/serverless
2. `GoogleAdsClient.load_from_env()` — env vars: `GOOGLE_ADS_DEVELOPER_TOKEN`, etc.
3. `GoogleAdsClient.load_from_storage("path/to/google-ads.yaml")` — file-based
4. `GoogleAdsClient.load_from_string(yaml_string)` — from secrets managers

**Performance tip**: Set `use_proto_plus: False` for high-volume scenarios. Default `True`
gives Pythonic objects; `False` uses raw protobuf (~2-3x faster marshaling). The library
supports **Application Default Credentials (ADC)** for GCP-native environments.

### Java SDK Notes

```xml
<dependency>
  <groupId>com.google.api-ads</groupId>
  <artifactId>google-ads</artifactId>
  <version>43.1.0</version>
</dependency>
```

- Uses `GoogleAdsClient.Builder` pattern for configuration
- Supports `google-ads.properties` file or programmatic setup
- Native gRPC streaming with backpressure support
- Thread-safe client instances — reuse across threads

### PHP SDK Notes

```bash
composer require googleads/google-ads-php
```

- Requires `grpc` and `protobuf` PHP extensions
- Configuration via `google_ads_php.ini` or programmatic
- Compatible with Laravel, Symfony through service container binding

### .NET SDK Notes

```bash
dotnet add package Google.Ads.GoogleAds
```

- Full async/await support
- Configuration via `appsettings.json`, `GoogleAdsConfig`, or environment variables
- Works with ASP.NET Core dependency injection

### Perl SDK — The Exception

Perl uses **JSON REST over HTTP 1.1** instead of gRPC (Perl lacks native gRPC support).
Functionally equivalent but slightly higher latency for streaming operations. All API
features are available.

---

## Community SDKs

### Opteo Node.js Client (Most Popular)

**GitHub**: `github.com/Opteo/google-ads-api` · **npm**: `google-ads-api`
**Latest**: `v24.1.0` (npm, last_verified: 2026-07-17) — tracks the v24 API surface.

The de facto Node.js/TypeScript client. Not official but widely used in production.

```bash
npm install google-ads-api   # v24.1.0 — tracks Google Ads API v24
```

#### Quick Start (runnable) — Node.js / TypeScript

A complete, self-contained script equivalent to the Python quick start in `SKILL.md`. Reads
credentials from the environment (never hardcode them — CLAUDE.md rule 18) and handles errors:

```javascript
// quick-start.mjs — node quick-start.mjs
import { GoogleAdsApi, enums } from "google-ads-api";

const client = new GoogleAdsApi({
  client_id: process.env.GOOGLE_ADS_CLIENT_ID,
  client_secret: process.env.GOOGLE_ADS_CLIENT_SECRET,
  developer_token: process.env.GOOGLE_ADS_DEVELOPER_TOKEN,
});

const customer = client.Customer({
  customer_id: process.env.GOOGLE_ADS_CUSTOMER_ID,       // no dashes
  login_customer_id: process.env.GOOGLE_ADS_LOGIN_CUSTOMER_ID, // MCC, no dashes
  refresh_token: process.env.GOOGLE_ADS_REFRESH_TOKEN,
});

async function main() {
  try {
    // 1. Read: last 7 days of campaign performance
    const rows = await customer.query(`
      SELECT campaign.id, campaign.name, metrics.clicks, metrics.cost_micros
      FROM campaign
      WHERE segments.date DURING LAST_7_DAYS
      ORDER BY metrics.clicks DESC
      LIMIT 10
    `);
    for (const r of rows) {
      console.log(`${r.campaign.name}: ${r.metrics.clicks} clicks, ` +
        `$${(Number(r.metrics.cost_micros) / 1e6).toFixed(2)}`);
    }

    // 2. Mutate: create a paused budget (safe to run)
    const [budget] = await customer.campaignBudgets.create([{
      name: `Quick Start Budget ${Date.now()}`,
      amount_micros: 10_000_000, // $10/day
      delivery_method: enums.BudgetDeliveryMethod.STANDARD,
    }]);
    console.log("Created budget:", budget.resource_name);
  } catch (err) {
    // Opteo surfaces API errors with .errors[]; log the failure reason and exit non-zero.
    console.error("Google Ads API call failed:", err?.errors ?? err);
    process.exitCode = 1;
  }
}

main();
```

Use for Node.js backends, serverless functions (Lambda, Cloud Functions), and TypeScript
applications. Tracks each new API version (v24 as of mid-2026) typically within 1-2 weeks of official
release.

### google-ads-pb (Go)

Community Go library using protobuf definitions. Suitable for Go microservices that need
direct Google Ads API access. Less mature than the official SDKs.

### Apps Script (Built-in)

Google Ads Scripts use a JavaScript-based environment with built-in API access:

```javascript
function main() {
  const campaigns = AdsApp.campaigns()
    .withCondition("Status = ENABLED")
    .get();
  while (campaigns.hasNext()) {
    const campaign = campaigns.next();
    Logger.log(campaign.getName());
  }
}
```

**Limitations**: 30-minute execution limit, 250 scripts per account, limited to subset
of API features, no gRPC/streaming. Best for lightweight automation, not heavy data
extraction. See `webhooks-automation.md` for Scripts vs API comparison.

---

## CLI: gaarf & gaql-cli

### gaarf — Google Ads API Report Fetcher

**The** CLI tool for Google Ads data extraction at scale. Maintained by Google's
gTech gPS CSE team. Available in Python and Node.js.

**GitHub**: `github.com/google/ads-api-report-fetcher`

#### Installation

```bash
# Python (recommended)
pip install google-ads-api-report-fetcher[full]

# Node.js
npm install -g google-ads-api-report-fetcher

# Verify
gaarf --help
```

#### Authentication

Uses standard `google-ads.yaml`:

```bash
gaarf queries/*.sql --ads-config=/path/to/google-ads.yaml
```

#### Basic Usage

```bash
# Inline query to console
gaarf "SELECT campaign.name, metrics.clicks FROM campaign WHERE segments.date DURING LAST_7_DAYS" \
  --input=console --output=console --account=1234567890

# From .sql files to CSV
gaarf queries/campaign_report.sql --account=1234567890 \
  --output=csv --csv.destination-folder=./reports

# Multiple query files
gaarf queries/*.sql --account=1234567890 --output=csv
```

#### Output Destinations

```bash
# CSV
gaarf queries/*.sql --account=123 --output=csv --csv.destination-folder=./output

# BigQuery
gaarf queries/*.sql --account=123 \
  --output=bq --bq.project=my-project --bq.dataset=google_ads_data \
  --bq.write-disposition=WRITE_TRUNCATE

# Google Sheets
gaarf queries/*.sql --account=123 \
  --output=sheet --sheet.spreadsheet-url="https://docs.google.com/spreadsheets/d/..."

# JSON
gaarf queries/*.sql --account=123 --output=json --json.destination-folder=./output

# SQLAlchemy database (PostgreSQL, MySQL, SQLite, etc.)
gaarf queries/*.sql --account=123 \
  --output=sqldb --sqldb.connection-string="postgresql://user:pass@localhost/db"
```

#### MCC Expansion (Multi-Account)

```bash
# Auto-discover child accounts
gaarf queries/*.sql --account=MCC_ID \
  --customer-ids-query="SELECT customer_client.client_customer FROM customer_client WHERE customer_client.level = 1"

# From file
gaarf queries/*.sql --account=MCC_ID --customer-ids-query-file=account_ids.sql

# Explicit list
gaarf queries/*.sql --customer-ids=111111,222222,333333
```

#### Macros and Parameters

```sql
-- report.sql: Use runtime macros
SELECT campaign.name, metrics.clicks
FROM campaign
WHERE segments.date BETWEEN '{start_date}' AND '{end_date}'
```

```bash
gaarf queries/report.sql --account=123 \
  --macro.start_date=2025-01-01 --macro.end_date=2025-06-30
```

#### Post-Processing

```bash
# BigQuery post-processing
pip install google-ads-api-report-fetcher[bq]
gaarf-bq scripts/*.sql --project=my-project --dataset=processed_data

# SQLAlchemy post-processing
pip install google-ads-api-report-fetcher[sql]
gaarf-sql scripts/*.sql --connection-string="postgresql://user:pass@host/db"
```

#### Airflow Integration

```bash
pip install airflow-google-ads-api-report-fetcher
```

```python
from airflow_google_ads_api_report_fetcher.operators import GaarfOperator

fetch_campaigns = GaarfOperator(
    task_id="fetch_campaigns",
    query_file="queries/campaigns.sql",
    account="1234567890",
    output="bq",
    bq_project="my-project",
    bq_dataset="ads_data",
    ads_config="/path/to/google-ads.yaml",
)
```

### gaql-cli — Interactive GAQL REPL

**GitHub**: `github.com/getyourguide/gaql-cli` (by GetYourGuide)

```bash
pip install gaql

# Interactive mode with tab-completion
gaql 1234567890

# One-shot queries
gaql -f csv 1234567890 'SELECT campaign.name, metrics.clicks FROM campaign'
gaql -f json 1234567890 'SELECT campaign.name FROM campaign'
gaql -f table 1234567890 'SELECT campaign.name FROM campaign'
```

### @gaql/cli — Node.js GAQL Validator

```bash
npx @gaql/cli validate query.ts
```

Validates GAQL syntax against the API schema. Useful in CI/CD to catch errors pre-deploy.

### When to Use Which

| Tool | Best For |
|------|----------|
| gaarf | Production pipelines, multi-account extraction, BigQuery/Sheets output |
| gaql-cli | Ad-hoc exploration, debugging queries, interactive development |
| @gaql/cli | CI/CD validation of GAQL queries |

---

## MCP Servers

### Official Google Ads MCP Server

**GitHub**: `github.com/google-marketing-solutions/google_ads_mcp`

Enables LLMs (Gemini, Claude) to query Google Ads via natural language. Declared **read-only** at
launch (October 2025) with write capabilities planned. This pass did **not** re-verify whether write
support has shipped — treat as read-only until confirmed against the repo
(last_verified: 2026-07-17; status as-of Oct 2025).

**Tools exposed**: `search` (execute GAQL), `list_accessible_customers`

#### Installation

```bash
pip install uv  # if not installed
git clone https://github.com/google-marketing-solutions/google_ads_mcp.git
cd google_ads_mcp && uv sync
```

#### Configuration for Gemini CLI

```json
{
  "mcpServers": {
    "GoogleAds": {
      "command": "pipx",
      "args": [
        "run", "--spec",
        "git+https://github.com/google-marketing-solutions/google_ads_mcp.git",
        "run-mcp-server"
      ],
      "env": {
        "GOOGLE_ADS_CREDENTIALS": "/path/to/google-ads.yaml"
      }
    }
  }
}
```

#### Configuration for Claude Code

```json
{
  "mcpServers": {
    "GoogleAds": {
      "command": "uv",
      "args": [
        "run", "--directory", "/path/to/google_ads_mcp",
        "-m", "ads_mcp.server"
      ],
      "cwd": "/path/to/google_ads_mcp",
      "timeout": 30000
    }
  }
}
```

#### Usage

Ask naturally: "How is my campaign performance this week?", "Top 10 keywords by
conversions?", "Cost breakdown by device last 30 days?" — the MCP server translates
to GAQL, executes, and returns structured data.

### Community MCP Servers

- **@samihalawa/google-ads-mcp-server** (Node.js): Adds write capabilities (pause
  campaigns, update budgets, export reports). `npx @samihalawa/google-ads-mcp-server`
- **PulseMCP directory**: Lists additional Google Ads MCP implementations

### Discord Support

`#ads-api-ai-tools` channel on Google Advertising Community Discord for MCP discussions.

---

## Developer Assistant

Google's official **Gemini-powered CLI extension** for natural language → GAQL + code.

**GitHub**: `github.com/googleads/google-ads-api-developer-assistant`

### Features

- Natural language → GAQL query generation
- Code generation in Python, Java, PHP, Ruby, .NET, Perl
- Direct API call execution from terminal
- Context-aware query suggestions

### Usage

```bash
"Show me my top 10 campaigns by conversions in the last 30 days"
# → Generates and optionally executes the GAQL query

"Generate Python code to create a PMax campaign with an asset group"
# → Produces working Python code using google-ads-python
```

---

## REST API via cURL

For quick testing/debugging without SDK setup:

### SearchStream via REST

```bash
curl -X POST \
  "https://googleads.googleapis.com/v24/customers/1234567890/googleAds:searchStream" \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "developer-token: YOUR_DEV_TOKEN" \
  -H "login-customer-id: MCC_ID" \
  -H "Content-Type: application/json" \
  -d '{"query": "SELECT campaign.id, campaign.name, metrics.clicks FROM campaign WHERE segments.date DURING LAST_7_DAYS"}'
```

### Mutate via REST

```bash
curl -X POST \
  "https://googleads.googleapis.com/v24/customers/1234567890/campaigns:mutate" \
  -H "Authorization: Bearer $(gcloud auth print-access-token)" \
  -H "developer-token: YOUR_DEV_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"operations": [{"update": {"resourceName": "customers/1234567890/campaigns/9876543210", "status": "PAUSED"}, "updateMask": "status"}]}'
```

### Get Access Token

```bash
# Via gcloud
gcloud auth print-access-token

# Via Python
python -c "
from google.ads.googleads.client import GoogleAdsClient
client = GoogleAdsClient.load_from_storage('google-ads.yaml')
print(client.credentials.token)
"
```

### API Explorer

Web-based REST explorer: `developers.google.com/google-ads/api/rest/examples`

---

## ETL & Data Integration

Tools for extracting Google Ads data into warehouses and databases.

### gaarf as ETL

gaarf doubles as a lightweight ETL tool for Google Ads → BigQuery/PostgreSQL:

```bash
# Daily ETL: Google Ads → BigQuery
gaarf queries/*.sql --account=MCC_ID \
  --customer-ids-query="SELECT customer_client.client_customer FROM customer_client WHERE customer_client.level = 1" \
  --output=bq --bq.project=my-project --bq.dataset=google_ads_raw \
  --bq.write-disposition=WRITE_TRUNCATE

# Post-process in BigQuery
gaarf-bq transforms/*.sql --project=my-project --dataset=google_ads_marts
```

### Airbyte

**Source**: `source-google-ads` (certified connector)
- Supports incremental sync with cursor fields
- Streams: campaigns, ad_groups, ads, keywords, search_terms, metrics by date
- Custom GAQL queries as additional streams
- OAuth or service account auth

### Fivetran

**Connector**: Google Ads (certified, pre-built)
- Schema auto-detection and evolution
- Incremental updates with configurable sync frequency
- Supports MCC-level extraction across all child accounts
- Pre-built transformations via dbt packages (`fivetran/google_ads`)

### Singer / Meltano

**Tap**: `tap-google-ads` (Singer spec)
- Lightweight, open-source alternative
- Works with any Singer target (PostgreSQL, Snowflake, S3, etc.)
- Meltano integration: `meltano add extractor tap-google-ads`

### dbt Packages

```yaml
# packages.yml
packages:
  - package: fivetran/google_ads
    version: ">=0.14.0"
  - package: fivetran/google_ads_source
    version: ">=0.14.0"
```

Pre-built models for campaign performance, keyword analysis, URL-level reporting.

---

## Reverse ETL & CDP

Push audience and conversion data FROM your warehouse TO Google Ads.

### Hightouch

- **Customer Match sync**: Warehouse query → hashed email/phone → Google Ads audience
- **Conversion upload**: Warehouse events → Enhanced Conversions
- **Scheduling**: Real-time, hourly, daily sync options
- Supports BigQuery, Snowflake, Redshift, PostgreSQL as sources

### Census

- **Live Syncs**: Stream warehouse changes to Google Ads audiences in real-time
- **Customer Match**: Segment users in warehouse, sync to Custom Audiences
- **Conversion import**: Push offline conversions from warehouse
- dbt model support as sync source

### Segment (Twilio)

- **Google Ads (Actions)** destination: server-side conversion tracking
- **Engage audiences** → Google Ads Customer Match
- Identity resolution across devices before audience sync

### RudderStack

- Open-source CDP alternative
- Google Ads destination for conversions and audiences
- Warehouse-first architecture aligns with Data Manager API patterns

### Why Reverse ETL Matters

With cookie deprecation, the warehouse becomes the source of truth for customer data.
Reverse ETL tools bridge the gap between your data warehouse and Google Ads:
- Fresher audiences than manual CSV uploads
- Automated Customer Match refresh (critical for list health)
- Consistent segmentation logic across all ad platforms
- Audit trail and versioning of audience definitions

---

## iPaaS

### Zapier

**Triggers**: New lead from Lead Form Extension, campaign status change (via polling)
**Actions**: Create/update offline conversion, add to Customer Match list, pause campaign

Common Zaps:
- CRM deal closed → Upload offline conversion
- Form submission → Add to Customer Match list
- Spreadsheet row → Create conversion

### Make (formerly Integromatic)

**Modules**: Google Ads (20+ modules)
- Search campaigns/ad groups/ads
- Create/update campaigns
- Upload conversions
- Manage audience lists
- Watch for changes (polling-based)

### n8n

**Nodes**: Google Ads node (community + built-in)
- Self-hosted option for data sovereignty
- GAQL query execution
- Campaign management operations
- Webhook triggers for external events → Google Ads actions

### Comparison

| Platform | Strengths | Limitations |
|----------|-----------|-------------|
| Zapier | Easiest setup, largest trigger library | Limited GAQL, per-task pricing |
| Make | Visual builder, complex scenarios | Learning curve for advanced flows |
| n8n | Self-hosted, no data limits, open source | Requires infrastructure management |

---

## Campaign Management Platforms

Third-party tools built on the Google Ads API for campaign management.

| Platform | Strengths | Best For |
|----------|-----------|----------|
| **Optmyzr** | Rule engine, PMax insights, script library | Agencies, power users |
| **WordStream** | Simplified UI, cross-platform | SMBs managing Google + Meta |
| **Adalysis** | A/B testing automation, quality score tracking | PPC specialists |
| **SA360** | Google's enterprise platform, cross-engine | Enterprise, multi-engine |
| **Marin Software** | Cross-channel bid management | Large-scale cross-platform |
| **Kenshoo/Skai** | AI bidding, retail media | Enterprise retail advertisers |

---

## Data & Analytics Platforms

| Platform | Integration Type | Key Feature |
|----------|-----------------|-------------|
| **Looker Studio** | Native (free) | Direct Google Ads connector, no API needed |
| **Supermetrics** | API connector | Pull to Sheets/Excel/Looker/warehouse |
| **Funnel.io** | API connector | Cross-platform data blending |
| **Power BI** | Via connector/API | Enterprise dashboards |
| **Tableau** | Via connector/API | Advanced visualization |

### Looker Studio (Free, Native)

The simplest option — no API setup required. Connect directly to Google Ads with
Google account auth. Supports blending with GA4, Search Console, BigQuery.

---

## Agency Reporting Tools

| Tool | Highlights |
|------|-----------|
| **Whatagraph** | Cross-channel reports, white-label, automated delivery |
| **AgencyAnalytics** | 80+ integrations, SEO + PPC combined |
| **DashThis** | Simple dashboard builder, preset widgets |
| **Porter Metrics** | Looker Studio connector marketplace |
| **Swydo** | Automated report scheduling, KPI monitoring |

---

## Testing & Development Tools

### Google Ads API Test Accounts

Create test accounts for development without spending real money:
1. Create a Manager Account at `ads.google.com/home/tools/manager-accounts/`
2. Under that MCC, create a **Test Account** (Settings → Sub-account settings)
3. Test accounts have a 15,000 daily operations limit
4. Test account data is fake — no real impressions or spend

### GAQL Query Builder

Interactive web tool: `developers.google.com/google-ads/api/fields/v24/campaign_query_builder`
- Visual field selector by resource type
- Auto-validates field compatibility
- Generates copyable GAQL queries
- Shows segment/metric incompatibilities

### google-ads.yaml Validator

Validate your config file before running code:

```python
from google.ads.googleads.client import GoogleAdsClient
try:
    client = GoogleAdsClient.load_from_storage("google-ads.yaml")
    # Test with a simple query
    customer_service = client.get_service("CustomerService")
    response = customer_service.list_accessible_customers()
    print(f"Auth OK. Accessible accounts: {len(response.resource_names)}")
except Exception as e:
    print(f"Config error: {e}")
```

### API Explorer

`developers.google.com/google-ads/api/rest/examples` — make authenticated REST calls
in-browser for testing without writing code.

---

## API Maturity Comparison

How Google Ads API compares to other major ad platform APIs (July 2026):

| Dimension | Google Ads | Meta Marketing | TikTok Marketing | X Ads | LinkedIn Marketing |
|-----------|-----------|---------------|-------------------|-------|-------------------|
| **API Version** | v24.2 | v25.0 | v1.3 | v12 | 202601 |
| **Official SDKs** | 6 languages | 4 (Python, PHP, Java, Ruby) | 3 (Python, Java, Node) | 1 (Python) | 0 (REST.li only) |
| **Community SDKs** | Node.js (Opteo), Go | Node.js (fbjs) | — | — | Node.js (community) |
| **CLI Tools** | gaarf, gaql-cli | — | — | twurl/xurl | — |
| **MCP Server** | Official (read-only) | Community | — | — | — |
| **Real-time Webhooks** | None | Lead Ads, CAPI | — | — | Lead Gen Forms |
| **Query Language** | GAQL (SQL-like) | — | — | — | REST.li finder |
| **Batch Operations** | BatchJobService | Batch API | — | — | — |
| **Rate Limits** | Token bucket, no fixed QPS | 200/hr per ad account | 10 QPS | Per-endpoint | Varies by endpoint |
| **Offline Conversions** | Yes (+ Data Manager API) | Yes (CAPI) | Yes (Events API) | Yes (CAPI) | Yes (CAPI) |
| **Audience Upload** | Customer Match | Custom Audiences | Custom Audiences | Tailored Audiences | Matched Audiences |

**Key advantage**: Google has the most mature ecosystem — 6 official SDKs, dedicated CLI
tools, MCP server, deepest third-party integration (ETL, reverse ETL, iPaaS, reporting).

**Key gap**: No real-time webhooks. All change detection requires polling (see
`webhooks-automation.md`).

---

## What Does NOT Exist

Common questions about features that Google Ads API does **not** provide:

| Expected Feature | Reality | Workaround |
|-----------------|---------|------------|
| Real-time webhooks | No webhook system | Poll via ChangeStatusService (see `webhooks-automation.md`) |
| Official Node.js SDK | Not planned | Opteo community client or REST API |
| Terraform provider | No official provider | Use API scripts or iPaaS for infra-as-code |
| GraphQL interface | gRPC + REST only | Use GAQL (SQL-like) for queries |
| Auction Insights API | UI-only feature | Screenshot/manual export; no programmatic access |
| Search Terms full report | Limited to triggered terms | GA4 provides broader query data |
| Quality Score history API | Only current snapshot | Log daily via scheduled gaarf queries |
| Real-time bidding control | Smart Bidding is fully automated | Conversion value rules for signal adjustment |
| Cross-account reporting API | Must query each account | gaarf MCC expansion automates iteration |

---

## Related Google APIs — sunsets to track

- **Content API for Shopping → Merchant API**: the legacy Content API for Shopping reaches
  **end-of-life on August 18, 2026**. Any Shopping/PMax feed integration that still calls the Content
  API must migrate to the new **Merchant API** before that date. This is separate from the Google Ads
  API itself but frequently sits in the same PMax/Shopping pipeline (last_verified: 2026-07-17).

---

## Cross-References

- **Authentication setup** → `auth-and-setup.md`
- **GAQL query syntax** → `gaql-reference.md`
- **Rate limits deep dive** → `rate-limits.md`
- **Automation patterns** → `webhooks-automation.md`
- **Campaign creation code** → `campaign-management.md`
