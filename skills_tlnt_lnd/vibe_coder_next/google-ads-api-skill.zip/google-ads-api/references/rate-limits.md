# Rate Limits & Error Handling Reference

## Table of Contents
1. [Rate Limit Architecture](#rate-limit-architecture)
2. [Access Level Quotas](#access-level-quotas)
3. [Mutate Operation Limits](#mutate-operation-limits)
4. [Request Rate Limits](#request-rate-limits)
5. [Service-Specific Limits](#service-specific-limits)
6. [GAQL Query Limits](#gaql-query-limits)
7. [Batch Job Limits](#batch-job-limits)
8. [Error Codes Reference](#error-codes-reference)
9. [Retry Patterns](#retry-patterns)
10. [Partial Failure Handling](#partial-failure-handling)
11. [Circuit Breaker Pattern](#circuit-breaker-pattern)
12. [Rate Limit Monitoring](#rate-limit-monitoring)
13. [MCC Cross-Account Strategies](#mcc-cross-account-strategies)
14. [Data Manager API Limits](#data-manager-api-limits)

---

## Rate Limit Architecture

Google Ads API uses a **token bucket** rate limiter. Key characteristics:

- **No fixed published QPS** — rate varies based on server load and account history
- **Metered independently** per `customer_id` AND per `developer_token`
- **Separate buckets** for read (Search/SearchStream) and write (Mutate) operations
- Rate-limited responses return `RESOURCE_EXHAUSTED` with `retryDelay` in trailing metadata
- The `request-id` response header is critical for debugging — always log it

### How Token Bucket Works

```
Token Bucket (per customer_id per developer_token):
┌──────────────────────────────────┐
│  Tokens refill continuously      │
│  Each request consumes 1+ tokens │
│  Bucket has a max capacity       │
│  When empty → RESOURCE_EXHAUSTED │
└──────────────────────────────────┘
```

- Tokens refill at a steady rate (not disclosed)
- Burst capacity allows short spikes
- Sustained high traffic drains the bucket
- Different services may have different bucket sizes

---

## Access Level Quotas

Daily operation quotas depend on your developer token access level:

| Access Level | Daily Ops Limit | Request Types | How to Get |
|-------------|----------------|---------------|------------|
| **Test Account** | 15,000 | All (test data only) | Auto-granted on MCC creation |
| **Explorer** | 2,880 | All (production) | Auto-granted on sign-up (updated Feb 2026) |
| **Basic** | 15,000 | All (production) | Compliance review (~2 business days) |
| **Standard** | Unlimited | All (production) | RMF compliance review |

### What Counts as an Operation

- Each `Search` or `SearchStream` call = 1 operation
- Each `Mutate` call = 1 operation (regardless of operations count within)
- Paginated `Search` follow-ups via `next_page_token` = **0** additional operations
- `BatchJob` creation = 1 operation; internal operations don't count individually
- `ListAccessibleCustomers` = 1 operation

### Upgrading Access Level

Apply in Google Ads UI → Tools & Settings → Setup → API Center. Google reviews for
**Required Minimum Functionality (RMF)** — your tool must provide meaningful user value
beyond raw API access. Basic approval typically takes 2 business days. Standard requires
demonstrating production usage patterns.

---

## Mutate Operation Limits

| Limit | Value | Error on Exceed |
|-------|-------|-----------------|
| Operations per Mutate request | **10,000** | `TOO_MANY_MUTATE_OPERATIONS` |
| Operations per BatchJob add | **10,000** per `AddBatchJobOperations` call | `TOO_MANY_MUTATE_OPERATIONS` |
| Total BatchJob operations | Multiple `AddBatchJobOperations` allowed | Practical limit ~1M |

### Batching Strategy

```python
def batch_mutate(client, customer_id, all_operations, batch_size=5000):
    """Split large mutation lists into API-safe batches."""
    ga_service = client.get_service("GoogleAdsService")
    results = []
    for i in range(0, len(all_operations), batch_size):
        batch = all_operations[i:i + batch_size]
        response = ga_service.mutate(
            customer_id=customer_id,
            mutate_operations=batch,
            partial_failure=True
        )
        results.append(response)
    return results
```

**Best practice**: Use 5,000 ops per batch (not 10,000) to leave headroom and reduce
timeout risk. For >50K operations, use BatchJobService instead.

---

## Request Rate Limits

### General API

No fixed QPS — token bucket algorithm. Typical observed behavior:

- Sustained: ~5-15 QPS per customer_id (varies)
- Burst: Up to ~50 QPS briefly
- After `RESOURCE_EXHAUSTED`: respect `retryDelay` metadata

### Service-Specific Hard Limits

| Service | Limit | Notes |
|---------|-------|-------|
| **KeywordPlanService** | 1 QPS | Hard limit, no burst |
| **ReachPlanService** | Low QPS | Planning tools are heavily throttled |
| **GenerateKeywordIdeasService** | Low QPS | Use caching for repeated queries |
| **AssetGenerationService** (v22+) | Rate limited | AI generation is expensive |
| **GenerateAudienceDefinition** (v23) | Rate limited | New audience generation |

### Extracting retryDelay

```python
from google.ads.googleads.errors import GoogleAdsException
import json

try:
    response = ga_service.search_stream(customer_id=cid, query=query)
except GoogleAdsException as ex:
    # Check trailing metadata for retry delay
    for metadata in ex.error.trailing_metadata():
        if metadata.key == "google.rpc.retryinfo-bin":
            # Parse retry delay
            from google.rpc import error_details_pb2
            retry_info = error_details_pb2.RetryInfo()
            retry_info.ParseFromString(metadata.value)
            delay_seconds = retry_info.retry_delay.seconds
            print(f"Retry after {delay_seconds}s")
```

---

## Service-Specific Limits

Detailed limits by service for operations that have specific constraints:

| Service / Operation | Limit | Details |
|--------------------|-------|---------|
| ConversionUploadService — click conversions | 2,000 per request | Use partial_failure=True |
| ConversionUploadService — call conversions | 2,000 per request | |
| ConversionAdjustmentUploadService | 2,000 per request | |
| OfflineUserDataJobService — user data | 10,000 identifiers per `AddOfflineUserDataJobOperations` | |
| CustomerMatchUserListService | 10,000 members per request | |
| BatchJobService — pending jobs | 5 per account | Wait for completion before creating more |
| BatchJobService — expiration | 7 days | Jobs expire if not run within 7 days |
| AssetService — images per account | 20,000 (approximate) | |
| AssetGroupService — asset groups per PMax | 100 | |
| Labels per account | 200,000 | Soft limit |
| Campaigns per account | 10,000 | Including removed |
| Ad groups per campaign | 20,000 | |
| Keywords per ad group | 5,000 | Approximate |
| Shared sets per account | 20 | Negative keyword lists |

---

## GAQL Query Limits

| Dimension | Limit |
|-----------|-------|
| Search page size | Fixed 10,000 rows (non-configurable since v17) |
| SearchStream batch size | Server-determined (~10,000 rows typical) |
| Query timeout | ~5 minutes for complex queries |
| SELECT fields | No hard limit, but more fields = slower |
| WHERE conditions | AND only (no OR), no hard limit on clauses |
| ORDER BY | Single field only |
| LIMIT | Max varies by resource (typically 50,000+) |

### Query Optimization

```sql
-- SLOW: Selecting too many fields
SELECT campaign.id, campaign.name, campaign.status, campaign.start_date,
       campaign.end_date, campaign.bidding_strategy_type, ... (20+ fields)
       metrics.impressions, metrics.clicks, metrics.cost_micros, ... (15+ metrics)
FROM campaign

-- FAST: Select only what you need
SELECT campaign.name, metrics.clicks, metrics.cost_micros
FROM campaign
WHERE campaign.status = 'ENABLED'
  AND segments.date DURING LAST_7_DAYS
```

**Tips**:
- Fewer fields = faster response, less memory
- Date filters dramatically reduce data volume
- Use `WHERE` to filter server-side, not client-side
- `SearchStream` avoids pagination overhead

---

## Batch Job Limits

| Dimension | Limit |
|-----------|-------|
| Pending jobs per account | 5 |
| Operations per `AddBatchJobOperations` call | 10,000 |
| Total operations per job | Practically unlimited (multiple add calls) |
| Job expiration | 7 days if not run |
| Result retrieval | Paginated, 5,000 results per page |
| Job metadata retention | 30 days after completion |

### When to Use BatchJobService

| Scenario | Use BatchJob? |
|----------|--------------|
| < 10,000 mutations | No — use direct Mutate |
| 10,000 - 100,000 mutations | Yes — primary use case |
| > 100,000 mutations | Yes — add operations in chunks of 10K |
| Fire-and-forget async | Yes — don't need immediate result |
| Atomic all-or-nothing | No — BatchJob has partial failure |

---

## Error Codes Reference

### Retryable Errors

| Error Domain | Error Code | Retry? | Strategy |
|-------------|-----------|--------|----------|
| `InternalError` | `INTERNAL_ERROR` | Yes | Exponential backoff |
| `InternalError` | `TRANSIENT_ERROR` | Yes | Exponential backoff |
| `QuotaError` | `RESOURCE_EXHAUSTED` | Yes | Respect retryDelay metadata |
| `RequestError` | `DEADLINE_EXCEEDED` | Yes | Increase timeout, then retry |
| `DatabaseError` | `DATABASE_ERROR` | Yes (cautiously) | May indicate temporary lock |

### Non-Retryable Errors

| Error Domain | Error Code | Action |
|-------------|-----------|--------|
| `AuthenticationError` | `AUTHENTICATION_ERROR` | Check credentials, refresh token |
| `AuthorizationError` | `USER_PERMISSION_DENIED` | Verify login_customer_id and access |
| `AuthorizationError` | `DEVELOPER_TOKEN_NOT_APPROVED` | Apply for higher access level |
| `RequestError` | `BAD_RESOURCE_ID` | Fix resource name format |
| `RequestError` | `INVALID_INPUT` | Fix request payload |
| `RequestError` | `RESOURCE_NOT_FOUND` | Verify resource exists |
| `PolicyViolationError` | `POLICY_VIOLATION` | Fix ad content, resubmit |
| `MutateError` | `RESOURCE_ALREADY_EXISTS` | Duplicate creation — check existing |
| `MutateError` | `RESOURCE_READ_ONLY` | Cannot modify this field |
| `QueryError` | `UNRECOGNIZED_FIELD` | Fix GAQL field name |
| `FieldError` | `IMMUTABLE_FIELD` | Cannot change after creation |

### Error Response Structure

```python
from google.ads.googleads.errors import GoogleAdsException

try:
    response = service.mutate_campaigns(customer_id=cid, operations=ops)
except GoogleAdsException as ex:
    print(f"Request ID: {ex.request_id}")  # Always log this!
    for error in ex.failure.errors:
        print(f"  Error code: {error.error_code}")
        print(f"  Message: {error.message}")
        if error.location:
            for element in error.location.field_path_elements:
                print(f"  Field: {element.field_name}, Index: {element.index}")
        if error.details:
            print(f"  Details: {error.details}")
```

---

## Retry Patterns

### Exponential Backoff with Jitter (Production Pattern)

```python
import time
import random
from google.ads.googleads.errors import GoogleAdsException

RETRYABLE_ERROR_FIELDS = {
    "internal_error", "transient_error", "database_error"
}

def retry_with_backoff(func, max_retries=5, base_delay=5.0, max_delay=300.0):
    """Production-grade retry with exponential backoff and jitter."""
    for attempt in range(max_retries):
        try:
            return func()
        except GoogleAdsException as ex:
            # Check if any error is retryable
            retryable = any(
                any(error.error_code.HasField(field) for field in RETRYABLE_ERROR_FIELDS)
                for error in ex.failure.errors
            )
            if not retryable or attempt == max_retries - 1:
                raise

            # Check for explicit retryDelay in metadata
            delay = base_delay * (2 ** attempt)
            for metadata in ex.error.trailing_metadata():
                if metadata.key == "google.rpc.retryinfo-bin":
                    from google.rpc import error_details_pb2
                    retry_info = error_details_pb2.RetryInfo()
                    retry_info.ParseFromString(metadata.value)
                    delay = max(delay, retry_info.retry_delay.seconds)

            # Add jitter (±25%)
            delay = min(delay, max_delay)
            delay *= 1 + random.uniform(-0.25, 0.25)
            print(f"Retry {attempt + 1}/{max_retries} in {delay:.1f}s (request_id={ex.request_id})")
            time.sleep(delay)
```

### Using tenacity

```python
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

@retry(
    stop=stop_after_attempt(5),
    wait=wait_exponential(multiplier=5, min=5, max=300),
    retry=retry_if_exception_type(GoogleAdsException),
    before_sleep=lambda retry_state: print(
        f"Retry {retry_state.attempt_number} after {retry_state.next_action.sleep:.1f}s"
    )
)
def fetch_campaigns(client, customer_id):
    ga_service = client.get_service("GoogleAdsService")
    return list(ga_service.search_stream(
        customer_id=customer_id,
        query="SELECT campaign.name FROM campaign WHERE campaign.status = 'ENABLED'"
    ))
```

---

## Partial Failure Handling

Always enable `partial_failure=True` for batch mutations:

```python
from google.ads.googleads import util as ads_util

response = service.mutate_campaigns(
    customer_id=cid,
    operations=ops,
    partial_failure=True
)

# Check for partial failures
if response.partial_failure_error:
    errors = ads_util.get_all_errors(response.partial_failure_error)
    failed_indices = set()
    for error in errors:
        idx = error.location.field_path_elements[0].index
        failed_indices.add(idx)
        print(f"Op {idx} failed: {error.message}")

    # Collect successful results
    for i, result in enumerate(response.results):
        if i not in failed_indices:
            print(f"Op {i} succeeded: {result.resource_name}")

    # Optionally retry only failed operations
    failed_ops = [ops[i] for i in failed_indices]
    if failed_ops:
        retry_response = service.mutate_campaigns(
            customer_id=cid, operations=failed_ops, partial_failure=True)
```

---

## Circuit Breaker Pattern

For services making many Google Ads API calls, implement a circuit breaker to avoid
cascading failures:

```python
import time
from enum import Enum

class CircuitState(Enum):
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Failing — reject all requests
    HALF_OPEN = "half_open"  # Testing recovery

class CircuitBreaker:
    def __init__(self, failure_threshold=5, recovery_timeout=60, half_open_max=3):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max = half_open_max
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.last_failure_time = 0
        self.half_open_successes = 0

    def can_execute(self):
        if self.state == CircuitState.CLOSED:
            return True
        if self.state == CircuitState.OPEN:
            if time.time() - self.last_failure_time > self.recovery_timeout:
                self.state = CircuitState.HALF_OPEN
                self.half_open_successes = 0
                return True
            return False
        return True  # HALF_OPEN

    def record_success(self):
        if self.state == CircuitState.HALF_OPEN:
            self.half_open_successes += 1
            if self.half_open_successes >= self.half_open_max:
                self.state = CircuitState.CLOSED
                self.failure_count = 0
        else:
            self.failure_count = 0

    def record_failure(self):
        self.failure_count += 1
        self.last_failure_time = time.time()
        if self.failure_count >= self.failure_threshold:
            self.state = CircuitState.OPEN
```

**Recommended parameters**: `failure_threshold=5`, `recovery_timeout=60s`, `half_open_max=3`.

---

## Rate Limit Monitoring

### Logging request-id

**Always** log the `request-id` header from responses — Google support requires it for
debugging:

```python
import logging

logger = logging.getLogger("google_ads")

# Enable request_id logging globally
logging.basicConfig(level=logging.INFO)

# The client library logs request_id at INFO level automatically
# For manual extraction:
try:
    stream = ga_service.search_stream(customer_id=cid, query=query)
    for batch in stream:
        pass  # process
except GoogleAdsException as ex:
    logger.error(f"Request failed. request_id={ex.request_id}")
```

### Metrics to Monitor

| Metric | Alert Threshold | Action |
|--------|----------------|--------|
| `RESOURCE_EXHAUSTED` rate | > 5% of requests | Reduce request rate, add backoff |
| Daily operations used | > 80% of quota | Optimize queries, upgrade access level |
| Average response latency | > 10s | Reduce query complexity, fewer fields |
| Partial failure rate | > 10% of mutations | Review data quality, fix common errors |
| Retry rate | > 20% of requests | Investigate root cause |

---

## MCC Cross-Account Strategies

When managing multiple accounts under an MCC:

### Sequential vs Parallel

```python
import concurrent.futures

def query_all_accounts(client, mcc_id, query, max_workers=5):
    """Query all child accounts under an MCC in parallel."""
    # Get child accounts
    children = get_child_account_ids(client, mcc_id)
    results = {}

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(run_query, client, child_id, query): child_id
            for child_id in children
        }
        for future in concurrent.futures.as_completed(futures):
            child_id = futures[future]
            try:
                results[child_id] = future.result()
            except GoogleAdsException as ex:
                results[child_id] = {"error": str(ex)}

    return results
```

### Cross-Account Rate Limiting

- Developer token quota is **shared** across all accounts accessed with it
- Each customer_id has its own rate limit bucket
- **max_workers=5** is a safe starting point for parallel queries
- Monitor `RESOURCE_EXHAUSTED` per account and globally
- Stagger requests across accounts rather than querying all simultaneously

### gaarf MCC Automation

```bash
# Most efficient: let gaarf handle MCC expansion
gaarf queries/*.sql --account=MCC_ID \
  --customer-ids-query="SELECT customer_client.client_customer FROM customer_client WHERE customer_client.level = 1" \
  --output=bq --bq.project=my-project --bq.dataset=ads_data
```

gaarf handles per-account rate limiting internally with configurable concurrency.

---

## Data Manager API Limits

The Data Manager API (GA October 2025, v1) has its own rate limits:

| Dimension | Limit |
|-----------|-------|
| Requests per day | 100,000 |
| Requests per minute | 300 |
| User identifiers per request | 10,000 |
| Data sources per account | 50 |
| Audience lists per account | Shared with Google Ads limit |
| File upload size | 150 MB per file |
| Scheduled sync frequency | Minimum 6 hours |

### Data Manager vs Google Ads API

| Operation | Google Ads API | Data Manager API |
|-----------|---------------|------------------|
| Customer Match upload | 10K members/request | 10K ids/request |
| Rate limit | Token bucket | 300/min |
| Scheduling | Manual (your cron) | Built-in scheduling |
| Monitoring | Custom logging | Dashboard in Google Ads UI |
| Best for | Programmatic control | Automated recurring syncs |

Since February 2, 2026, session attributes and IP data **must** be uploaded through
Data Manager API. See `first-party-data-strategy.md` for implementation details.

---

## Cross-References

- **Access levels and developer tokens** → `auth-and-setup.md`
- **Error handling code patterns** → `automation-and-reporting.md`
- **Batch job implementation** → `automation-and-reporting.md`
- **Data Manager API details** → `first-party-data-strategy.md`
- **MCC management** → `automation-and-reporting.md`
- **Ecosystem tools for monitoring** → `ecosystem-tools.md`
