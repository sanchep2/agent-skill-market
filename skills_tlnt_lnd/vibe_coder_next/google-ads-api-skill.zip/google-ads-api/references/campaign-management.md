# Campaign Management Reference

## Table of Contents
1. [Entity Hierarchy](#entity-hierarchy)
2. [Search Campaigns](#search-campaigns)
3. [Performance Max Campaigns](#performance-max-campaigns)
4. [Demand Gen Campaigns](#demand-gen-campaigns)
5. [Shopping Campaigns](#shopping-campaigns)
6. [AI Max for Search (v21+)](#ai-max-for-search)
6a. [v24 Breaking Changes & Migration Notes](#v24-breaking-changes--migration-notes)
7. [Smart Bidding Strategies](#smart-bidding-strategies)
8. [Conversion Value Rules](#conversion-value-rules)
9. [Customer Lifecycle Goals](#customer-lifecycle-goals)
10. [Ad Extensions via Assets](#ad-extensions-via-assets)
11. [Audience Targeting](#audience-targeting)
12. [Pausing, Updating, Removing](#pausing-updating-removing)

---

## Entity Hierarchy

All campaign types follow this dependency chain:

```
CampaignBudget → Campaign → Ad Group → { Ads + Keywords/Criteria }
                                    ↘ Ad Group Criterion (targeting)
```

Use `GoogleAdsService.Mutate` with **temporary resource names** (negative IDs) to
create the entire stack atomically. Each negative ID must be unique across ALL resource
types in a single request.

---

## Search Campaigns

### Full Creation Example (Python)

```python
def create_search_campaign(client, customer_id, budget_micros=10_000_000):
    ga_service = client.get_service("GoogleAdsService")
    ops = []

    # 1. Budget (temp ID: -1)
    budget_op = client.get_type("MutateOperation")
    budget = budget_op.campaign_budget_operation.create
    budget.resource_name = f"customers/{customer_id}/campaignBudgets/-1"
    budget.name = f"Search Budget {budget_micros // 1_000_000}"
    budget.amount_micros = budget_micros
    budget.delivery_method = client.enums.BudgetDeliveryMethodEnum.STANDARD
    ops.append(budget_op)

    # 2. Campaign (temp ID: -2)
    camp_op = client.get_type("MutateOperation")
    camp = camp_op.campaign_operation.create
    camp.resource_name = f"customers/{customer_id}/campaigns/-2"
    camp.name = "Search Campaign"
    camp.advertising_channel_type = client.enums.AdvertisingChannelTypeEnum.SEARCH
    camp.status = client.enums.CampaignStatusEnum.PAUSED  # Start paused!
    camp.campaign_budget = f"customers/{customer_id}/campaignBudgets/-1"
    # Bidding: Maximize Conversions
    camp.maximize_conversions.target_cpa_micros = 0
    # Network settings
    camp.network_settings.target_google_search = True
    camp.network_settings.target_search_network = False
    camp.network_settings.target_content_network = False
    ops.append(camp_op)

    # 3. Ad Group (temp ID: -3)
    ag_op = client.get_type("MutateOperation")
    ag = ag_op.ad_group_operation.create
    ag.resource_name = f"customers/{customer_id}/adGroups/-3"
    ag.campaign = f"customers/{customer_id}/campaigns/-2"
    ag.name = "Ad Group 1"
    ag.status = client.enums.AdGroupStatusEnum.ENABLED
    ag.type_ = client.enums.AdGroupTypeEnum.SEARCH_STANDARD
    ops.append(ag_op)

    # 4. Keywords
    for keyword_text, match_type in [
        ("buy running shoes", "PHRASE"),
        ("best running shoes 2026", "BROAD"),
        ("nike running shoes", "EXACT"),
    ]:
        kw_op = client.get_type("MutateOperation")
        kw = kw_op.ad_group_criterion_operation.create
        kw.ad_group = f"customers/{customer_id}/adGroups/-3"
        kw.status = client.enums.AdGroupCriterionStatusEnum.ENABLED
        kw.keyword.text = keyword_text
        kw.keyword.match_type = getattr(
            client.enums.KeywordMatchTypeEnum, match_type)
        ops.append(kw_op)

    # 5. Responsive Search Ad
    ad_op = client.get_type("MutateOperation")
    ad = ad_op.ad_group_ad_operation.create
    ad.ad_group = f"customers/{customer_id}/adGroups/-3"
    ad.status = client.enums.AdGroupAdStatusEnum.ENABLED
    rsa = ad.ad.responsive_search_ad
    # Headlines (min 3, max 15)
    for headline in ["Buy Running Shoes", "Free Shipping Today", "Top Brands Available"]:
        h = client.get_type("AdTextAsset")
        h.text = headline
        rsa.headlines.append(h)
    # Descriptions (min 2, max 4)
    for desc in ["Shop our wide selection of running shoes. Free returns.",
                  "Premium running shoes from Nike, Adidas, and more."]:
        d = client.get_type("AdTextAsset")
        d.text = desc
        rsa.descriptions.append(d)
    ad.ad.final_urls.append("https://example.com/running-shoes")
    ops.append(ad_op)

    # Execute atomically
    response = ga_service.mutate(customer_id=customer_id, mutate_operations=ops)
    for result in response.mutate_operation_responses:
        print(f"Created: {result}")
    return response
```

### Negative Keywords

```python
# Campaign-level negative keyword
neg_op = client.get_type("MutateOperation")
neg = neg_op.campaign_criterion_operation.create
neg.campaign = f"customers/{customer_id}/campaigns/{campaign_id}"
neg.negative = True
neg.keyword.text = "free"
neg.keyword.match_type = client.enums.KeywordMatchTypeEnum.BROAD
```

---

## Performance Max Campaigns

PMax requires AssetGroups (1-100 per campaign) containing text, image, video, and logo
assets. No ad groups or keywords are used.

### PMax Creation Pattern

```python
def create_pmax_campaign(client, customer_id, budget_micros=20_000_000):
    ga_service = client.get_service("GoogleAdsService")
    ops = []

    # 1. Budget (temp ID: -1)
    budget_op = client.get_type("MutateOperation")
    budget = budget_op.campaign_budget_operation.create
    budget.resource_name = f"customers/{customer_id}/campaignBudgets/-1"
    budget.name = "PMax Budget"
    budget.amount_micros = budget_micros
    ops.append(budget_op)

    # 2. Campaign (temp ID: -2)
    camp_op = client.get_type("MutateOperation")
    camp = camp_op.campaign_operation.create
    camp.resource_name = f"customers/{customer_id}/campaigns/-2"
    camp.name = "PMax Campaign"
    camp.advertising_channel_type = client.enums.AdvertisingChannelTypeEnum.PERFORMANCE_MAX
    camp.status = client.enums.CampaignStatusEnum.PAUSED
    camp.campaign_budget = f"customers/{customer_id}/campaignBudgets/-1"
    camp.maximize_conversion_value.target_roas = 3.0  # 300% target ROAS
    # For retail PMax, add:
    # camp.shopping_setting.merchant_id = YOUR_MERCHANT_CENTER_ID
    # camp.shopping_setting.feed_label = "US"
    ops.append(camp_op)

    # 3. Asset Group (temp ID: -3)
    ag_op = client.get_type("MutateOperation")
    ag = ag_op.asset_group_operation.create
    ag.resource_name = f"customers/{customer_id}/assetGroups/-3"
    ag.campaign = f"customers/{customer_id}/campaigns/-2"
    ag.name = "Main Asset Group"
    ag.status = client.enums.AssetGroupStatusEnum.ENABLED
    ag.final_urls.append("https://example.com")
    ops.append(ag_op)

    # 4. Text Assets → link to Asset Group
    # Create text assets first, then link with AssetGroupAsset
    headlines = ["Great Products", "Shop Now", "Free Shipping"]
    for i, text in enumerate(headlines):
        # Create the asset
        asset_op = client.get_type("MutateOperation")
        asset = asset_op.asset_operation.create
        asset.resource_name = f"customers/{customer_id}/assets/{-(10 + i)}"
        asset.text_asset.text = text
        ops.append(asset_op)

        # Link to asset group
        link_op = client.get_type("MutateOperation")
        link = link_op.asset_group_asset_operation.create
        link.asset_group = f"customers/{customer_id}/assetGroups/-3"
        link.asset = f"customers/{customer_id}/assets/{-(10 + i)}"
        link.field_type = client.enums.AssetFieldTypeEnum.HEADLINE
        ops.append(link_op)

    descriptions = ["Shop our collection today. Free returns on all orders.",
                     "Premium quality at great prices. Order now."]
    for i, text in enumerate(descriptions):
        asset_op = client.get_type("MutateOperation")
        asset = asset_op.asset_operation.create
        asset.resource_name = f"customers/{customer_id}/assets/{-(20 + i)}"
        asset.text_asset.text = text
        ops.append(asset_op)

        link_op = client.get_type("MutateOperation")
        link = link_op.asset_group_asset_operation.create
        link.asset_group = f"customers/{customer_id}/assetGroups/-3"
        link.asset = f"customers/{customer_id}/assets/{-(20 + i)}"
        link.field_type = client.enums.AssetFieldTypeEnum.DESCRIPTION
        ops.append(link_op)

    # 5. Listing group filter (required — at minimum, a root "all products" node)
    lgf_op = client.get_type("MutateOperation")
    lgf = lgf_op.asset_group_listing_group_filter_operation.create
    lgf.asset_group = f"customers/{customer_id}/assetGroups/-3"
    lgf.type_ = client.enums.ListingGroupFilterTypeEnum.UNIT_INCLUDED
    ops.append(lgf_op)

    response = ga_service.mutate(customer_id=customer_id, mutate_operations=ops)
    return response
```

### PMax Key Facts (v23)

- **Search themes**: Up to 50 per asset group (doubled from 25 in May 2025)
- **Network breakdown**: `segments.ad_network_type` now works on PMax (v23+)
- **Campaign-level negative keywords**: Supported since v20
- **Batch job support**: AssetGroupOperation supported in BatchJobService since v17
- **Brand guidelines**: Auto-enabled for new PMax campaigns since v21

---

## Demand Gen Campaigns

Demand Gen serves across YouTube, Discover, Gmail, and GDN.

### Key Constraints

- **Cannot use shared budgets**
- Support campaign total budgets (`campaign.campaign_budget` with `total_amount_micros`)
- Ad groups created **without specifying a type**
- Audience targeting requires `use_audience_grouped = true` on the ad group
- Available ad types: `DemandGenMultiAssetAd`, `DemandGenCarouselAd`, `DemandGenVideoAd`, `DemandGenProductAd`

```python
# Demand Gen campaign creation
camp.advertising_channel_type = client.enums.AdvertisingChannelTypeEnum.DEMAND_GEN
camp.maximize_conversions.target_cpa_micros = 5_000_000  # $5 tCPA

# Ad group — don't set type_
ag.campaign = f"customers/{customer_id}/campaigns/-2"
ag.name = "DemandGen Ad Group"
ag.status = client.enums.AdGroupStatusEnum.ENABLED
# Enable audience grouping for targeting
```

### Demand Gen: TargetCPC Bidding (v22+)

v22 added Target CPC as a bidding strategy for Demand Gen campaigns:

```python
camp.target_cpc.cpc_bid_ceiling_micros = 2_000_000  # $2 max CPC
```

### Demand Gen: Asset Automation (v22+)

v22 introduced asset automation for Demand Gen, allowing Google to generate design
variations and videos from existing assets:

```python
# Enable asset automation types on Demand Gen campaign
camp.asset_automation_settings.append(
    client.get_type("AssetAutomationSetting", {
        "asset_automation_type": client.enums.AssetAutomationTypeEnum.GENERATE_VERTICAL_VIDEOS,
        "asset_automation_status": client.enums.AssetAutomationStatusEnum.OPTED_IN,
    }))
```

### Demand Gen: Surface-Specific Conversion Forecasting (v23+)

`ReachPlanService.GenerateConversionRates` now returns conversion rate suggestions
segmented by surface (Gmail, Shorts, YouTube in-stream, Discover) for Demand Gen planning.

---

## Shopping Campaigns

Standard Shopping campaigns use `SHOPPING` channel type and require Merchant Center linkage.

### Link Merchant Center Account

```python
# Option 1: Accept MC invitation via ProductLinkInvitationService
invitation_service = client.get_service("ProductLinkInvitationService")
# approve_product_link_invitation(customer_id, resource_name)

# Option 2: Direct link if admin on both accounts
product_link_service = client.get_service("ProductLinkService")
op = client.get_type("ProductLinkOperation")
pl = op.create
pl.merchant_center.merchant_center_id = 123456789
response = product_link_service.mutate_product_link(
    customer_id=customer_id, operation=op)
```

### Shopping Campaign Setup

```python
camp.advertising_channel_type = client.enums.AdvertisingChannelTypeEnum.SHOPPING
camp.shopping_setting.merchant_id = 123456789  # Your MC ID
camp.shopping_setting.sales_country = "US"
camp.shopping_setting.campaign_priority = 1  # 0=Low, 1=Medium, 2=High
camp.shopping_setting.enable_local = True
```

Product groups use `ListingGroupInfo` on `AdGroupCriterion` to partition products
by brand, category, item ID, condition, etc.

---

## AI Max for Search

New in v21 (August 2025). AI Max is an optimization layer for Search campaigns that
provides ML-driven keyword expansion and creative generation.

```python
# Enable AI Max on an existing or new Search campaign
camp.ai_max_setting.enable_ai_max = True
# Optionally control specific features:
# camp.ai_max_setting.text_asset_automation_setting.enable = True
# camp.ai_max_setting.final_url_expansion_opt_out = False
```

AI Max consolidates Automatically Created Assets and brand lists into a single setting.
When enabled, Google may expand keyword matching and generate additional ad variations.

**DSA → AI Max auto-upgrade (February 2027)**: Google is auto-upgrading remaining Dynamic Search Ads
campaigns to AI Max for Search, starting February 2027 (delayed from an earlier September 2026
target — that date now applies to a separate migration, Automatically Created Assets / campaign-level
broad match, not the general DSA auto-upgrade). New campaigns should adopt AI Max directly. The v24.1
experiment type `ADOPT_AI_MAX` lets you A/B a controlled AI Max rollout against the current setup
before the forced upgrade lands (last_verified: 2026-07-18).

---

## v24 Breaking Changes & Migration Notes

v24 shipped as a **major** release (April 22, 2026; latest minor **v24.2**, June 24, 2026). Unlike the
mostly-additive v21–v23, v24 removed and reshaped several fields. Audit your code against this list
before pinning to v24 (last_verified: 2026-07-17 against the release notes at
`developers.google.com/google-ads/api/docs/release-notes`):

### Reshaped / moved

| Change | Was | Now |
|--------|-----|-----|
| **`VideoResponsiveAdInfo` now mutable** | Read-only; assets set implicitly | Mutable — you must supply `videos`, `business_name`, and `logo_images` on create |
| **Brand safety moved off Campaign** | `Campaign.video_brand_safety_suitability` | `Customer.video_brand_safety_suitability` (account-level) |
| **`CartDataSalesView`** | Prior shopping cart reporting shape | Reworked in v24 — re-validate any GAQL against `cart_data_sales_view` |

### Removals (queries/mutates referencing these break)

- `campaign_budget.ad_sub_network_type` — removed.
- `click_type` segment on asset-related views — removed.
- `is_brand_connect_creator` — removed.
- `LOYALTY_SIGN_UPS` conversion-action category — removed.

### Newer views worth adopting

- `matched_location_interest_view` (v23) — location-interest matching diagnostics.
- `targeting_expansion_view` (v22) — audience/keyword expansion visibility.

**Migration checklist**: (1) grep your codebase for the removed fields above; (2) update
`VideoResponsiveAd` creation to pass the now-required asset fields; (3) move any brand-safety reads
from `campaign` to `customer`; (4) re-run GAQL touching `CartDataSalesView`; (5) bump the client
library and the `use_proto_plus`/version pin to a v24-capable release.

---

## App Campaigns

App campaigns (`APP`) promote mobile apps across Search, Play, YouTube, and Display.

```python
camp.advertising_channel_type = client.enums.AdvertisingChannelTypeEnum.MULTI_CHANNEL
camp.advertising_channel_sub_type = client.enums.AdvertisingChannelSubTypeEnum.APP_CAMPAIGN
camp.app_campaign_setting.app_id = "com.example.myapp"
camp.app_campaign_setting.app_store = client.enums.AppCampaignAppStoreEnum.GOOGLE_APP_STORE
camp.app_campaign_setting.bidding_strategy_goal_type = (
    client.enums.AppCampaignBiddingStrategyGoalTypeEnum.OPTIMIZE_INSTALLS_TARGET_INSTALL_COST)
camp.maximize_conversions.target_cpa_micros = 3_000_000  # $3 target CPI
```

**v22 addition**: App campaigns gained targetless bidding goals (no CPA/ROAS target)
for maximizing installs or total value.

---

## Precision Scheduling (v23)

v23 replaced legacy date-only fields with datetime fields for minute-level precision:

```python
# Old way (deprecated, day-level only):
# camp.start_date = "2026-02-14"
# camp.end_date = "2026-02-14"

# New way (v23+, minute-level precision):
camp.start_date_time = "2026-02-14T12:00:00-05:00"  # Noon EST
camp.end_date_time = "2026-02-14T23:59:59-05:00"    # End of day EST
```

The datetime fields accept ISO 8601 format with timezone. This enables time-sensitive
promotions like flash sales that start and end at exact times.

---

## AssetGenerationService (v22+)

Generative AI for creating text and image assets from campaign context:

```python
# Generate text assets
asset_gen_service = client.get_service("AssetGenerationService")
request = client.get_type("GenerateTextRequest")
request.customer_id = customer_id
request.campaign = f"customers/{customer_id}/campaigns/{campaign_id}"
# The service generates headlines/descriptions based on campaign context,
# landing page content, and provided prompts.
response = asset_gen_service.generate_text(request=request)

# Generate image assets
image_request = client.get_type("GenerateImagesRequest")
image_request.customer_id = customer_id
# Provide context: URLs, text prompts, campaign settings
response = asset_gen_service.generate_images(request=image_request)
```

**Note**: AssetGenerationService is in controlled access — check eligibility in your account.

---

## GenerateAudienceDefinition (v23)

NLP-based audience building — describe your audience in natural language and get
structured targeting parameters:

```python
audience_insights_service = client.get_service("AudienceInsightsService")
request = client.get_type("GenerateAudienceDefinitionRequest")
request.customer_id = customer_id
request.audience_description = "Eco-conscious parents in urban areas looking for sustainable wooden toys"

response = audience_insights_service.generate_audience_definition(request=request)
# Returns structured audience definition with interests, demographics, behaviors
for dimension in response.audience_definition.dimensions:
    print(f"Dimension: {dimension}")
```

v23 also added `LIFE_EVENT_USER_INTEREST` as a new dimension for life-event-based
audience building through AudienceInsightsService and ContentCreatorInsightsService.

---

## Smart Bidding Strategies

Set directly on the campaign:

```python
# Maximize Conversions (no cap)
camp.maximize_conversions.target_cpa_micros = 0

# Maximize Conversions with Target CPA
camp.maximize_conversions.target_cpa_micros = 5_000_000  # $5.00

# Maximize Conversion Value (no ROAS target)
camp.maximize_conversion_value.target_roas = 0

# Maximize Conversion Value with Target ROAS
camp.maximize_conversion_value.target_roas = 3.5  # 350%

# Target CPA (standalone)
camp.target_cpa.target_cpa_micros = 5_000_000

# Target ROAS (standalone)
camp.target_roas.target_roas = 3.5

# Target Impression Share (Search only)
camp.target_impression_share.location = (
    client.enums.TargetImpressionShareLocationEnum.ANYWHERE_ON_PAGE)
camp.target_impression_share.location_fraction_micros = 650_000  # 65%
camp.target_impression_share.cpc_bid_ceiling_micros = 3_000_000  # $3 max CPC

# Manual CPC (legacy, still supported)
camp.manual_cpc.enhanced_cpc_enabled = True
```

### Shared Bidding Strategies (across campaigns)

```python
# Create shared strategy
strategy_op = client.get_type("BiddingStrategyOperation")
strategy = strategy_op.create
strategy.name = "Shared MaxConv Strategy"
strategy.maximize_conversions.target_cpa_micros = 5_000_000
response = bidding_strategy_service.mutate_bidding_strategies(
    customer_id=cid, operations=[strategy_op])

# Assign to campaign
camp.bidding_strategy = response.results[0].resource_name
```

---

## Conversion Value Rules

Conversion Value Rules dynamically adjust conversion values at auction time based on
audience, location, or device — without modifying your conversion uploads. They allow
Smart Bidding to optimize for profit, LTV, or segment-specific value.

```python
# Create a value rule: high-LTV audience worth 2x more
service = client.get_service("ConversionValueRuleService")
op = client.get_type("ConversionValueRuleOperation")
rule = op.create
rule.name = "High LTV 2x"
rule.status = client.enums.ConversionValueRuleStatusEnum.ENABLED
rule.action.operation = client.enums.ValueRuleOperationEnum.MULTIPLY
rule.action.value = 2.0  # Double the conversion value
rule.audience_condition.user_lists.append(high_ltv_user_list_rn)
rule.owner_customer = f"customers/{cid}"
response = service.mutate_conversion_value_rules(customer_id=cid, operations=[op])

# Create a rule set to apply rules to a campaign
rule_set_service = client.get_service("ConversionValueRuleSetService")
rs_op = client.get_type("ConversionValueRuleSetOperation")
rule_set = rs_op.create
rule_set.campaign = f"customers/{cid}/campaigns/{campaign_id}"
rule_set.status = client.enums.ConversionValueRuleSetStatusEnum.ENABLED
rule_set.attachment_type = client.enums.ValueRuleSetAttachmentTypeEnum.CAMPAIGN
rule_set.conversion_value_rules.append(response.results[0].resource_name)
rule_set.dimensions.append(client.enums.ValueRuleSetDimensionEnum.AUDIENCE)
rule_set_service.mutate_conversion_value_rule_sets(customer_id=cid, operations=[rs_op])
```

For complete value-based bidding strategy (profit-based bidding, LTV optimization,
strategic rule examples), see `references/first-party-data-strategy.md`.

---

## Customer Lifecycle Goals

### Customer Acquisition Goals

Tell Smart Bidding to bid higher for new customers. Configured at account level.

```python
# Step 1: Label existing customers
ulct_service = client.get_service("UserListCustomerTypeService")
ulct_op = client.get_type("UserListCustomerTypeOperation")
ulct = ulct_op.create
ulct.user_list = existing_customers_list_rn
ulct.customer_type_category = client.enums.UserListCustomerTypeCategoryEnum.PURCHASERS
ulct_service.mutate_user_list_customer_types(customer_id=cid, operations=[ulct_op])

# Step 2: Set acquisition goal values
lifecycle_service = client.get_service("CustomerLifecycleGoalService")
goal_op = client.get_type("CustomerLifecycleGoalOperation")
goal = goal_op.create
goal.customer_acquisition_goal_value_settings.value = 50.0  # +$50 per new customer
goal.customer_acquisition_goal_value_settings.high_lifetime_value = 100.0  # +$100 for high-LTV
lifecycle_service.mutate_customer_lifecycle_goals(customer_id=cid, operation=goal_op)

# Step 3: Set campaign-level acquisition mode
campaign = campaign_op.update
campaign.resource_name = f"customers/{cid}/campaigns/{campaign_id}"
acq = campaign.customer_acquisition_goal_settings
acq.optimization_mode = client.enums.CustomerAcquisitionOptimizationModeEnum.TARGET_AND_BID
# TARGET_AND_BID = only new customers; BID_HIGHER = prefer new but allow existing
```

### UserListCustomerType Categories

Label your Customer Match lists: `PURCHASERS`, `HIGH_VALUE_CUSTOMERS`,
`DISENGAGED_CUSTOMERS`, `QUALIFIED_LEADS`, `CONVERTED_LEADS`, `CART_ABANDONERS`,
`LOYALTY_SIGN_UPS`. These labels feed into both acquisition and retention goals.

### Retention Goals (PMax Only)

Performance Max campaigns can optimize for customer retention and re-engagement.
Configure alongside acquisition goals. See `references/first-party-data-strategy.md`
for complete lifecycle goal strategy.

---

## Ad Extensions via Assets

Since v19, all extensions use the Asset-based model. Feed entities are gone.

### Sitelink Extension

```python
# Create sitelink asset
asset_op = client.get_type("AssetOperation")
asset = asset_op.create
asset.sitelink_asset.link_text = "Shop Sale"
asset.sitelink_asset.description1 = "Up to 50% off"
asset.sitelink_asset.description2 = "Free shipping on orders over $50"
asset.final_urls.append("https://example.com/sale")
response = asset_service.mutate_assets(customer_id=cid, operations=[asset_op])

# Link to campaign
link_op = client.get_type("CampaignAssetOperation")
link = link_op.create
link.campaign = f"customers/{cid}/campaigns/{campaign_id}"
link.asset = response.results[0].resource_name
link.field_type = client.enums.AssetFieldTypeEnum.SITELINK
campaign_asset_service.mutate_campaign_assets(customer_id=cid, operations=[link_op])
```

### Callout Extension

```python
asset.callout_asset.callout_text = "Free Returns"
```

### Call Extension

```python
asset.call_asset.country_code = "US"
asset.call_asset.phone_number = "+18005551234"
asset.call_asset.call_conversion_reporting_state = (
    client.enums.CallConversionReportingStateEnum.USE_ACCOUNT_LEVEL_CALL_CONVERSION_ACTION)
```

### Structured Snippet

```python
asset.structured_snippet_asset.header = "Brands"
asset.structured_snippet_asset.values.extend(["Nike", "Adidas", "Puma"])
```

### Business Message Extension (v23+)

v23 added Facebook Messenger and Zalo as messaging providers:

```python
asset.business_message_asset.business_name = "My Store"
# Facebook Messenger
asset.business_message_asset.facebook_messenger_info.page_id = "YOUR_FB_PAGE_ID"
# Or Zalo
# asset.business_message_asset.zalo_info.zalo_oa_id = "YOUR_ZALO_OA_ID"
```

### Asset Orientation (v23+)

v23 added a read-only `orientation` field to image and video assets, reporting whether
the asset is landscape, portrait, or square. Useful for PMax asset group composition.

---

## Remarketing: Website Visitor Audiences (Pixel/Tag)

Rule-based user lists capture visitors who triggered the Google tag on your website.
These are the audiences generated by "the pixel" — visitors to specific pages,
converters, cart abandoners, etc.

### Step 1: Retrieve Your Google Tag

Every Google Ads account has one account-level Google tag, auto-created on account opening.

```python
# Retrieve remarketing tag snippet
query = """
    SELECT remarketing_action.id, remarketing_action.name,
           remarketing_action.tag_snippets
    FROM remarketing_action
"""
stream = ga_service.search_stream(customer_id=cid, query=query)
```

Install the Google tag on all website pages. For URL-based audiences, no tag edits needed.
For custom parameter audiences (e.g., cart value, product ID), add parameters to the tag.

### Step 2: Create Rule-Based User Lists

```python
def create_website_visitor_list(client, customer_id, url_contains="example.com",
                                 list_name="All Website Visitors", days=365):
    """Create a remarketing list of website visitors matching a URL rule."""
    user_list_service = client.get_service("UserListService")
    user_list_op = client.get_type("UserListOperation")
    ul = user_list_op.create

    ul.name = list_name
    ul.description = f"Visitors to pages containing '{url_contains}'"
    ul.membership_status = client.enums.UserListMembershipStatusEnum.OPEN
    ul.membership_life_span = days  # Max: 540 days

    # Rule: URL contains the target string
    rule_item = client.get_type("UserListRuleItemInfo")
    rule_item.name = "url__"  # Built-in parameter for page URL
    rule_item.string_rule_item.operator = (
        client.enums.UserListStringRuleItemOperatorEnum.CONTAINS)
    rule_item.string_rule_item.value = url_contains

    # Build rule item group (items within a group are ANDed)
    rule_group = client.get_type("UserListRuleItemGroupInfo")
    rule_group.rule_items.append(rule_item)

    # Build the rule
    rule = client.get_type("UserListRuleInfo")
    rule.rule_item_groups.append(rule_group)

    # Build flexible rule (inclusive operands ANDed, exclusive ORed)
    flexible_rule = ul.rule_based_user_list.flexible_rule_user_list
    operand = client.get_type("FlexibleRuleOperandInfo")
    operand.rule.CopyFrom(rule)
    operand.lookback_window_days = 30  # How far back to look
    flexible_rule.inclusive_operands.append(operand)
    flexible_rule.inclusive_rule_operator = (
        client.enums.UserListFlexibleRuleOperatorEnum.AND)

    # Prepopulate with past 30 days of visitors
    ul.rule_based_user_list.prepopulation_status = (
        client.enums.UserListPrepopulationStatusEnum.REQUESTED)

    response = user_list_service.mutate_user_lists(
        customer_id=customer_id, operations=[user_list_op])
    return response.results[0].resource_name
```

### Advanced: Visitors Who Did X but NOT Y (Cart Abandoners)

```python
def create_cart_abandoner_list(client, customer_id):
    """People who visited cart page but NOT thank-you page."""
    user_list_op = client.get_type("UserListOperation")
    ul = user_list_op.create
    ul.name = "Cart Abandoners"
    ul.membership_status = client.enums.UserListMembershipStatusEnum.OPEN
    ul.membership_life_span = 30

    # Inclusive: visited cart page
    cart_rule_item = client.get_type("UserListRuleItemInfo")
    cart_rule_item.name = "url__"
    cart_rule_item.string_rule_item.operator = (
        client.enums.UserListStringRuleItemOperatorEnum.CONTAINS)
    cart_rule_item.string_rule_item.value = "/cart"
    cart_rule_group = client.get_type("UserListRuleItemGroupInfo")
    cart_rule_group.rule_items.append(cart_rule_item)
    cart_rule = client.get_type("UserListRuleInfo")
    cart_rule.rule_item_groups.append(cart_rule_group)

    inclusive_operand = client.get_type("FlexibleRuleOperandInfo")
    inclusive_operand.rule.CopyFrom(cart_rule)
    inclusive_operand.lookback_window_days = 30

    # Exclusive: visited thank-you/confirmation page
    thankyou_rule_item = client.get_type("UserListRuleItemInfo")
    thankyou_rule_item.name = "url__"
    thankyou_rule_item.string_rule_item.operator = (
        client.enums.UserListStringRuleItemOperatorEnum.CONTAINS)
    thankyou_rule_item.string_rule_item.value = "/thank-you"
    thankyou_rule_group = client.get_type("UserListRuleItemGroupInfo")
    thankyou_rule_group.rule_items.append(thankyou_rule_item)
    thankyou_rule = client.get_type("UserListRuleInfo")
    thankyou_rule.rule_item_groups.append(thankyou_rule_group)

    exclusive_operand = client.get_type("FlexibleRuleOperandInfo")
    exclusive_operand.rule.CopyFrom(thankyou_rule)

    # Combine: visited cart AND NOT thank-you
    flexible_rule = ul.rule_based_user_list.flexible_rule_user_list
    flexible_rule.inclusive_operands.append(inclusive_operand)
    flexible_rule.exclusive_operands.append(exclusive_operand)
    flexible_rule.inclusive_rule_operator = (
        client.enums.UserListFlexibleRuleOperatorEnum.AND)

    ul.rule_based_user_list.prepopulation_status = (
        client.enums.UserListPrepopulationStatusEnum.REQUESTED)

    response = client.get_service("UserListService").mutate_user_lists(
        customer_id=customer_id, operations=[user_list_op])
    return response.results[0].resource_name
```

### Custom Parameter Rules (Dynamic Remarketing)

For rules based on custom tag parameters (product value, category, etc.):

```python
# Rule: visitors who viewed products over $100
rule_item = client.get_type("UserListRuleItemInfo")
rule_item.name = "ecomm_totalvalue"  # Custom parameter from your tag
rule_item.number_rule_item.operator = (
    client.enums.UserListNumberRuleItemOperatorEnum.GREATER_THAN)
rule_item.number_rule_item.value = 100.0
```

Built-in parameters: `url__` (page URL), `ref_url__` (referrer URL).
Predefined parameters for retail: `ecomm_prodid`, `ecomm_pagetype`,
`ecomm_totalvalue`, `ecomm_category`.

### Audience Size Requirements

As of December 2024, Google standardized the minimum to **100 active users** across
all networks (Search, Display, YouTube). Previously it was 1,000 for Search.
Membership duration max is **540 days**.

---

## YouTube Channel Audiences

YouTube audiences are created based on interactions with your linked YouTube channel.
The channel must be linked to your Google Ads account first.

### Link YouTube Channel via API

```python
# Link YouTube channel to Google Ads
product_link_service = client.get_service("ProductLinkService")
op = client.get_type("ProductLinkOperation")
pl = op.create
pl.youtube.channel_id = "UCxxxxxxxxxxxxxxxxxxxxxx"  # Your YT channel ID
response = product_link_service.mutate_product_link(
    customer_id=customer_id, operation=op)
```

### YouTube Interaction Types

Once linked, you can create user lists based on these viewer actions:

| Interaction Type | Description |
|-----------------|-------------|
| Viewed any video from channel | Organic + ad views |
| Viewed certain videos | Specific video IDs |
| Subscribed to channel | Channel subscribers |
| Visited channel page | Channel page visitors |
| Liked any video from channel | Video likers |
| Added any video to playlist | Playlist adders |

**Note**: Views under 10 seconds don't qualify for remarketing (important for Shorts).
Bumper ads (under 11 seconds) don't build remarketing lists.

### Query Existing YouTube User Lists

```sql
-- Find all YouTube-based user lists
SELECT user_list.id, user_list.name, user_list.type,
       user_list.membership_status, user_list.size_for_search,
       user_list.size_for_display, user_list.membership_life_span
FROM user_list
WHERE user_list.type IN ('RULE_BASED', 'YOUTUBE_USERS')
  AND user_list.membership_status = 'OPEN'
```

### Query GA4-Imported Audiences

GA4 audiences linked to Google Ads appear as `REMARKETING` or `RULE_BASED` type:

```sql
SELECT user_list.id, user_list.name, user_list.type,
       user_list.size_for_search, user_list.size_for_display
FROM user_list
WHERE user_list.type IN ('REMARKETING', 'RULE_BASED')
```

---

## Targeting Audiences in Campaigns

### Ad Group Level Targeting

```python
def target_user_list_in_ad_group(client, customer_id, ad_group_id, user_list_rn):
    """Add a user list as targeting criterion to an ad group."""
    ag_criterion_op = client.get_type("AdGroupCriterionOperation")
    criterion = ag_criterion_op.create
    criterion.ad_group = client.get_service("AdGroupService").ad_group_path(
        customer_id, ad_group_id)
    criterion.user_list.user_list = user_list_rn
    # Optional: Set bid modifier for this audience
    criterion.bid_modifier = 1.5  # 50% bid increase for this audience

    response = client.get_service("AdGroupCriterionService").mutate_ad_group_criteria(
        customer_id=customer_id, operations=[ag_criterion_op])
    return response.results[0].resource_name
```

### Campaign Level Targeting

```python
def target_user_list_in_campaign(client, customer_id, campaign_id, user_list_rn):
    """Add a user list as targeting criterion to a campaign."""
    campaign_criterion_op = client.get_type("CampaignCriterionOperation")
    criterion = campaign_criterion_op.create
    criterion.campaign = client.get_service("CampaignService").campaign_path(
        customer_id, campaign_id)
    criterion.user_list.user_list = user_list_rn

    response = client.get_service("CampaignCriterionService").mutate_campaign_criteria(
        customer_id=customer_id, operations=[campaign_criterion_op])
    return response.results[0].resource_name
```

### Exclude an Audience

```python
# Exclude converters from prospecting campaigns
criterion.negative = True
criterion.user_list.user_list = converters_user_list_rn
```

### For PMax and Demand Gen: Use Audiences

PMax and Demand Gen use the `AudienceService` (not AdGroupCriterion):

```python
# Create an Audience combining multiple signals
audience_op = client.get_type("AudienceOperation")
audience = audience_op.create
audience.name = "High-Value Remarketing Audience"
audience.description = "Website visitors + YouTube viewers"

# Add website visitors segment
segment1 = client.get_type("AudienceDimension")
user_list_segment = segment1.user_list_segment
user_list_segment.user_list = website_visitors_user_list_rn
audience.dimensions.append(segment1)

# Add YouTube viewers segment
segment2 = client.get_type("AudienceDimension")
user_list_segment2 = segment2.user_list_segment
user_list_segment2.user_list = youtube_viewers_user_list_rn
audience.dimensions.append(segment2)

response = client.get_service("AudienceService").mutate_audiences(
    customer_id=customer_id, operations=[audience_op])
```

---

## Audience Performance Reporting

### Ad Group Audience Performance

```sql
SELECT ad_group_criterion.criterion_id,
       ad_group_criterion.user_list.user_list,
       ad_group.name, campaign.name,
       metrics.impressions, metrics.clicks, metrics.ctr,
       metrics.cost_micros, metrics.conversions, metrics.cost_per_conversion
FROM ad_group_audience_view
WHERE segments.date DURING LAST_30_DAYS
  AND campaign.status = 'ENABLED'
ORDER BY metrics.conversions DESC
```

### Campaign Audience Performance

```sql
SELECT campaign_criterion.criterion_id,
       campaign_criterion.user_list.user_list,
       campaign.name,
       metrics.impressions, metrics.clicks, metrics.conversions
FROM campaign_audience_view
WHERE segments.date DURING LAST_30_DAYS
ORDER BY metrics.conversions DESC
```

### Lookalike (Similar) Audiences

Lookalike audiences extend reach to users similar to your seed lists:

```sql
-- Find lookalike user lists
SELECT user_list.id, user_list.name, user_list.type,
       user_list.lookalike_user_list.seed_user_list_ids,
       user_list.size_for_search, user_list.size_for_display
FROM user_list
WHERE user_list.type = 'LOOKALIKE'
```

Lookalike audiences require a seed list (Customer Match, website visitors, or YouTube
viewers) and are available for Demand Gen campaigns.

### ContentCreatorInsightsService (YouTube Creator Discovery)

Find YouTube creators relevant to your audience (private API, requires partner access):

```python
# Discover creators matching your target audience
insights_service = client.get_service("ContentCreatorInsightsService")
request = client.get_type("GenerateCreatorInsightsRequest")
request.customer_id = customer_id
# Specify audience attributes (age, gender, interests)
# Returns: channel subscriber count, view count, audience demographics, top videos
```

## Audience Targeting via AudienceService

Create audiences by combining dimensions. Available dimension types:

| Dimension | Use Case |
|-----------|----------|
| `UserListSegment` | Your data: website visitors, YouTube viewers, CRM lists |
| `UserInterestSegment` | Affinity and in-market audiences |
| `CustomAudienceSegment` | Custom audiences by keywords/URLs/apps |
| `DetailedDemographicSegment` | Parental status, education, homeowner status, etc. |
| `LifeEventSegment` | Recently moved, just married, new job, etc. |

### Custom Audiences

```python
custom_audience_op = client.get_type("CustomAudienceOperation")
ca = custom_audience_op.create
ca.name = "Tech Enthusiasts"
ca.type_ = client.enums.CustomAudienceTypeEnum.SEARCH
# Add members by keyword interests
for term in ["artificial intelligence", "machine learning", "cloud computing"]:
    member = client.get_type("CustomAudienceMember")
    member.keyword.value = term
    member.member_type = client.enums.CustomAudienceMemberTypeEnum.KEYWORD
    ca.members.append(member)
```

### Customer Match (CRM Upload)

```python
# 1. Create user list
user_list_op = client.get_type("UserListOperation")
ul = user_list_op.create
ul.name = "CRM Customers Q1 2026"
ul.membership_life_span = 365  # days
ul.crm_based_user_list.upload_key_type = (
    client.enums.CustomerMatchUploadKeyTypeEnum.CONTACT_INFO)
response = user_list_service.mutate_user_lists(customer_id=cid, operations=[user_list_op])
user_list_rn = response.results[0].resource_name

# 2. Create offline data job
job_op = client.get_type("OfflineUserDataJobOperation")
job_service = client.get_service("OfflineUserDataJobService")
job = job_service.create_offline_user_data_job(
    customer_id=cid,
    job={"type_": client.enums.OfflineUserDataJobTypeEnum.CUSTOMER_MATCH_USER_LIST,
         "customer_match_user_list_metadata": {"user_list": user_list_rn}})

# 3. Add hashed user data
import hashlib
def hash_email(email):
    return hashlib.sha256(email.strip().lower().encode()).hexdigest()

ops = []
for email in ["user1@example.com", "user2@example.com"]:
    op = client.get_type("OfflineUserDataJobOperation")
    ui = op.create.user_identifiers.add()
    ui.hashed_email = hash_email(email)
    # consent required for EU
    op.create.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
    op.create.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED
    ops.append(op)

job_service.add_offline_user_data_job_operations(
    resource_name=job.resource_name, operations=ops)

# 4. Run the job (within 5 days of creation)
job_service.run_offline_user_data_job(resource_name=job.resource_name)
```

Customer Match lists need **≥1,000 matched users** to serve (5,000+ recommended).

### Customer Match Strategy

The strategic value of Customer Match lies in **segmentation and use case design**, not
just the upload mechanics above. Key patterns:

- **Prospecting**: Exclude ALL customer lists → only target new users
- **Upsell**: Target Product-A buyers with Product-B campaigns
- **Win-back**: Target "At Risk" + "Hibernating" segments with incentives
- **Lookalike**: Seed with top 20% LTV customers → Google finds similar users
- **Value-tiered bidding**: Different Customer Match lists per LTV tier + Conversion Value Rules
- **Pipeline exclusion**: Exclude leads already in sales pipeline (update via API daily)

Segment by RFM (Recency, Frequency, Monetary), LTV tier, product category, and engagement.
Refresh lists every 24-48 hours. For the complete segmentation framework, automation
architecture, and 7 detailed strategic use cases, see
`references/first-party-data-strategy.md` → Customer Match Master Strategy.

---

## Pausing, Updating, Removing

### Update Pattern (field masks)

```python
from google.api_core import protobuf_helpers

def update_campaign_name(client, customer_id, campaign_id, new_name):
    campaign_service = client.get_service("CampaignService")
    campaign_op = client.get_type("CampaignOperation")
    campaign = campaign_op.update
    campaign.resource_name = campaign_service.campaign_path(customer_id, campaign_id)
    campaign.name = new_name
    # Field mask tells API which fields to update
    client.copy_from(
        campaign_op.update_mask,
        protobuf_helpers.field_mask(None, campaign._pb))
    campaign_service.mutate_campaigns(
        customer_id=customer_id, operations=[campaign_op])
```

### Remove Pattern

```python
campaign_op = client.get_type("CampaignOperation")
campaign_op.remove = campaign_service.campaign_path(customer_id, campaign_id)
campaign_service.mutate_campaigns(customer_id=customer_id, operations=[campaign_op])
# Note: this sets status to REMOVED, not a hard delete
```
