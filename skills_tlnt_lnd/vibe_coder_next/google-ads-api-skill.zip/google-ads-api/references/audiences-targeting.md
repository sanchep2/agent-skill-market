# Audiences & Targeting Reference

## Table of Contents
1. [Audience Type Taxonomy](#audience-type-taxonomy)
2. [Audience Source Comparison](#audience-source-comparison)
3. [Customer Match Strategy](#customer-match-strategy)
4. [Remarketing Lists (Tag-Based)](#remarketing-lists)
5. [YouTube Channel Audiences](#youtube-channel-audiences)
6. [GA4 Imported Audiences](#ga4-imported-audiences)
7. [In-Market & Affinity Audiences](#in-market--affinity-audiences)
8. [Custom Segments](#custom-segments)
9. [Detailed Demographics & Life Events](#detailed-demographics--life-events)
10. [Similar Segments → Optimized Targeting](#similar-segments--optimized-targeting)
11. [PMax Audience Signals](#pmax-audience-signals)
12. [Match Rate Optimization](#match-rate-optimization)
13. [Audience Lifecycle & Health](#audience-lifecycle--health)
14. [Audience Overlap & Exclusions](#audience-overlap--exclusions)
15. [Optimized Targeting](#optimized-targeting)
16. [Privacy Sandbox & Future](#privacy-sandbox--future)
17. [Retargeting Funnel Architecture](#retargeting-funnel-architecture)
18. [Common Mistakes](#common-mistakes)

---

## Audience Type Taxonomy

Complete taxonomy of all Google Ads audience types as of February 2026:

| Audience Type | Source | Min Size (Search) | Min Size (Display) | Max Retention | API Resource |
|--------------|--------|-------------------|-------------------|---------------|-------------|
| **Customer Match** | CRM upload / Data Manager API | 1,000 | 100 | Unlimited (manual refresh) | `UserList` (CRM_BASED) |
| **Website Visitors** (Remarketing) | Google Tag | 1,000 | 100 | 540 days | `UserList` (RULE_BASED) |
| **App Users** | Firebase / SDK | 1,000 | 100 | 540 days | `UserList` (RULE_BASED) |
| **YouTube Users** | YouTube channel | 1,000 | 100 | 540 days | `UserList` (RULE_BASED) |
| **GA4 Imported** | GA4 link | 1,000 | 100 | 540 days | `UserList` |
| **Customer List (Data Manager)** | Data Manager API | 1,000 | 100 | Auto-refreshed | `UserList` |
| **In-Market** | Google signals | N/A (predefined) | N/A | Dynamic | `UserInterest` |
| **Affinity** | Google signals | N/A (predefined) | N/A | Dynamic | `UserInterest` |
| **Custom Segments** | Keywords/URLs/Apps | N/A (auto) | N/A | Dynamic | `CustomAudience` |
| **Detailed Demographics** | Google signals | N/A (predefined) | N/A | Dynamic | `UserInterest` |
| **Life Events** | Google signals | N/A (predefined) | N/A | Dynamic | `UserInterest` |
| **Combined Segments** | Boolean logic | Varies | Varies | Varies | `CombinedAudience` |
| **Optimized Targeting** | Google ML | Auto | Auto | Dynamic | Campaign setting |

### Key Distinctions

- **First-party audiences** (Customer Match, Remarketing, YouTube, App, GA4): You own
  the data, audiences get stronger as you add more signals. Privacy-resilient.
- **Third-party audiences** (In-Market, Affinity, Demographics): Google-defined, no setup
  needed but decreasing reach due to privacy changes.
- **Custom Segments**: Hybrid — you define intent signals, Google finds the audience.

---

## Audience Source Comparison

| Source | Data Freshness | Match Quality | Privacy Resilience | Setup Effort |
|--------|---------------|---------------|-------------------|-------------|
| **CRM (Customer Match)** | Depends on refresh cadence | High (direct match) | Excellent | Medium |
| **Google Tag (Remarketing)** | Real-time | High (pixel-based) | Moderate (cookie-dependent) | Low |
| **YouTube** | Near real-time | High (logged-in users) | Excellent (Google accounts) | Low |
| **GA4** | 24-48h delay | High | Moderate | Medium |
| **App (Firebase)** | Near real-time | Excellent (device ID) | Good | Medium |
| **Data Manager API** | Scheduled (6h+) | High | Excellent | High |

**Recommendation for 2026**: Prioritize CRM-based (Customer Match) and logged-in
audiences (YouTube, App). These are least affected by cookie deprecation and browser
restrictions. Website remarketing still works but with shrinking windows.

---

## Customer Match Strategy

Customer Match uploads hashed customer data (email, phone, address, mobile ID) to
create audiences. This is the most privacy-resilient first-party audience type.

### RFM Segmentation for Customer Match

Segment your CRM data before uploading for smarter bidding signals:

| Segment | Definition | Google Ads Use |
|---------|-----------|---------------|
| **Champions** | Recent + Frequent + High Value | Exclude from acquisition, upsell campaigns |
| **Loyal** | Frequent buyers, any recency | Retention offers, value-based bidding signal |
| **At Risk** | Previously active, declining | Win-back campaigns, higher bids |
| **New Customers** | First purchase < 90 days | Onboarding sequences, cross-sell |
| **High LTV** | Top 20% by lifetime value | Seed for lookalike-like targeting via Smart Bidding |
| **Lapsed** | No activity > 180 days | Reactivation campaigns |

### Value-Tiered Upload Strategy

```python
# Upload separate lists with different strategic roles
segments = {
    "high_value_customers": {
        "query": "SELECT email, phone FROM customers WHERE ltv > 500",
        "purpose": "Exclusion from acquisition + seed for value optimization"
    },
    "recent_purchasers_30d": {
        "query": "SELECT email, phone FROM orders WHERE date > NOW() - 30d",
        "purpose": "Exclude from generic retargeting, upsell targeting"
    },
    "cart_abandoners_email": {
        "query": "SELECT email FROM carts WHERE status = 'abandoned' AND date > NOW() - 14d",
        "purpose": "Recovery campaigns with urgency messaging"
    },
    "all_customers": {
        "query": "SELECT email, phone FROM customers",
        "purpose": "Broad exclusion from cold prospecting"
    }
}
```

### Pipeline Exclusion Pattern

The most impactful Customer Match strategy is **excluding existing customers** from
acquisition campaigns:

1. Upload "All Customers" list → Apply as negative audience to prospecting campaigns
2. Upload "Recent Purchasers" → Exclude from retargeting (they already converted)
3. Upload "High LTV" → Use as positive audience for retention/upsell campaigns

This alone can reduce wasted acquisition spend by 15-30%.

For API code to create and upload Customer Match lists, see `campaign-management.md`
(Audience Targeting section) and `first-party-data-strategy.md` (Customer Match Master
Strategy).

---

## Remarketing Lists

Rule-based user lists created from Google Tag (pixel) events. These capture website
visitors based on URL patterns, custom parameters, or conversion events.

### Standard Remarketing Segments

| Segment | Rule | Recommended Window | Campaign Use |
|---------|------|-------------------|-------------|
| **All Visitors** | URL contains your domain | 30-90 days | Broad retargeting, exclusion base |
| **Category Viewers** | URL contains `/category/` | 14-30 days | Category-specific ads |
| **Product Viewers** | URL contains `/product/` | 7-14 days | Dynamic remarketing (Shopping) |
| **Cart Abandoners** | Visited cart, NOT converted | 7 days | High-intent recovery |
| **Converters** | Conversion event fired | 30-180 days | Exclusion, upsell, loyalty |
| **High-Intent Non-Converters** | 3+ pages, > 2min, no conversion | 14 days | Aggressive retargeting |

### Window Optimization

Optimal membership_life_span depends on your sales cycle:

| Business Type | Recommended Window | Rationale |
|--------------|-------------------|-----------|
| E-commerce impulse | 3-7 days | Short consideration, quick decay |
| E-commerce considered | 14-30 days | Comparison shopping period |
| SaaS / B2B | 30-90 days | Long sales cycle |
| Education / Bootcamp | 14-60 days | Research + decision period |
| Real estate | 60-180 days | Very long cycle |

### Sequential Remarketing (Cascading Windows)

Create overlapping lists with decreasing urgency:

```
Day 1-3:   "Just Visited" → Aggressive bid, specific messaging
Day 4-7:   "Recent Visitor" → Moderate bid, broader messaging
Day 8-14:  "Warm Visitor" → Lower bid, special offer
Day 15-30: "Cool Visitor" → Low bid, brand awareness
```

Each audience is the window MINUS the previous (use audience exclusions).

For API code to create remarketing lists, see `campaign-management.md` §11
(Remarketing: Website Visitor Audiences).

---

## YouTube Channel Audiences

YouTube audiences are based on interactions with your YouTube channel, and are among
the most privacy-resilient because they use Google account data (logged-in users).

### Interaction Types

| Interaction | Qualifies | Does NOT Qualify |
|------------|-----------|-----------------|
| Viewed a video | Watched ≥ 10 seconds | Watched < 10 seconds |
| Viewed as ad | Video ad impression | Skipped before 10s |
| Subscribed | Active subscriber | Unsubscribed |
| Visited channel | Channel page view | Embedded video only |
| Liked a video | Liked | Disliked (separate list if needed) |
| Added to playlist | Playlist add | Watch Later only |
| Shared a video | Shared | N/A |

### Requirements

- YouTube channel must be **linked** to the Google Ads account
- Linking: Google Ads → Tools → Linked accounts → YouTube
- Only interactions AFTER linking are captured
- Minimum 1,000 users for Search, 100 for Display/Video

### Strategic Use

- **Video viewers (non-converters)** → Retarget with Search/Display
- **Subscribers** → Loyalty/upsell campaigns
- **Video ad viewers** → Full-funnel: awareness → consideration → conversion

---

## GA4 Imported Audiences

Audiences defined in GA4 can be imported into Google Ads for targeting.

### How It Works

1. Link GA4 property to Google Ads account
2. GA4 audience definitions sync automatically to Google Ads
3. Appear as audience lists with ~24-48h population delay
4. Users tracked via Google signals (logged-in) and first-party cookies

### Limitations

- **24-48h sync delay** — not real-time
- **Audience definitions** limited to GA4 parameters (not arbitrary SQL)
- **Size depends on GA4 tracking** — if GA4 tracking is partial, audiences are small
- **No retroactive fill** — only users captured AFTER audience creation
- **GA4 audience limit**: 100 audiences per property

### When to Use GA4 vs Tag-Based Remarketing

| Scenario | GA4 Audiences | Tag-Based Remarketing |
|----------|--------------|----------------------|
| Complex behavioral sequences | Better (event sequences) | Limited (URL rules) |
| Simple page visit rules | Overkill | Better (simpler setup) |
| Cross-device tracking | Better (Google signals) | Limited (cookie-based) |
| Real-time population | Worse (24-48h delay) | Better (near real-time) |
| Already using GA4 | Easy add-on | Additional setup |

---

## In-Market & Affinity Audiences

Google-defined audiences based on browsing behavior and signals.

### In-Market Audiences (~500 categories)

Users actively researching or comparing products in a category. High purchase intent.

**Examples**: "Autos & Vehicles > Motor Vehicles > Motor Vehicles (New)", "Business
Services > Advertising & Marketing Services", "Education > Post-Secondary Education"

**Best for**: Mid-funnel targeting, layering on Search for bid adjustments, Display/Video
prospecting.

### Affinity Audiences (~300 categories)

Users with sustained interest in a topic. Lifestyle-level targeting.

**Examples**: "Technology > Technophiles", "Food & Dining > Coffee Shop Regulars",
"Sports & Fitness > Health & Fitness Buffs"

**Best for**: Top-of-funnel awareness, brand campaigns, broad reach.

### When to Use

| Goal | Use In-Market | Use Affinity |
|------|--------------|-------------|
| Drive immediate conversions | Yes | No |
| Build brand awareness | No | Yes |
| Layer on Search keywords | Yes (bid modifier) | Rarely |
| Display prospecting | Yes | Yes |
| Video campaigns | Yes | Yes |

### API Usage

```sql
-- Find available in-market and affinity audiences
SELECT user_interest.user_interest_category,
       user_interest.name,
       user_interest.taxonomy_type
FROM user_interest
WHERE user_interest.taxonomy_type IN ('IN_MARKET', 'AFFINITY')
ORDER BY user_interest.name
```

---

## Custom Segments

Define your own audience based on keywords, URLs, or apps that indicate intent.

### Three Types

| Type | Signal | Best For |
|------|--------|----------|
| **By keywords** | Search terms + browsing history | Competitor targeting, niche intent |
| **By URLs** | Visitors of specific websites | Competitor audience capture |
| **By apps** | Users of specific apps | App-category targeting |

### Strategy

```
Competitor Targeting:
- Keywords: competitor brand names, competitor product names
- URLs: competitor websites, competitor review pages
- Result: reach people actively considering competitors

Niche Intent:
- Keywords: long-tail terms too small for In-Market
- URLs: niche blogs, forums, communities
- Result: highly targeted custom audience
```

### When Custom Segments > In-Market

- Your niche has no matching In-Market category
- You want to target competitor audiences specifically
- You need more granular control than predefined categories
- Combining multiple intent signals for a specific persona

---

## Detailed Demographics & Life Events

### Detailed Demographics

Target by socioeconomic attributes:

| Category | Subcategories |
|----------|--------------|
| **Parental status** | Parents of infants, toddlers, preschoolers, grade-schoolers, teens |
| **Marital status** | Single, in a relationship, married |
| **Education** | Current students, high school, bachelor's, advanced degree |
| **Homeownership** | Homeowners, renters |
| **Employment** | Company size, industry |

### Life Events

Target users experiencing major life changes:

| Life Event | Window | Use Case |
|-----------|--------|----------|
| Getting married | ~6 months before/after | Wedding services, home furnishing |
| Moving | ~3 months around move | Home services, furniture, insurance |
| Graduating | ~6 months around | Career services, education, financial |
| Starting a business | ~6 months | Business services, SaaS, legal |
| Retiring | ~6 months | Financial, travel, leisure |
| New pet | ~3 months | Pet products, veterinary |
| Purchasing a home | ~6 months | Home improvement, insurance, furniture |

v23 added `LIFE_EVENT_USER_INTEREST` as a new dimension for life-event-based audience
building through `AudienceInsightsService` and `ContentCreatorInsightsService`.

---

## Similar Segments → Optimized Targeting

### Deprecation Timeline

- **May 2023**: Similar Segments stopped being generated for new campaigns
- **August 2023**: Similar Segments fully removed from all campaigns
- **Replacement**: Optimized Targeting (on by default for Display and Demand Gen)

### What Changed

| Before (Similar Segments) | After (Optimized Targeting) |
|--------------------------|---------------------------|
| Explicit lookalike audience | Implicit ML expansion |
| Visible in audience lists | No separate audience list |
| Manual control over source list | Uses all audience signals + conversion data |
| Could be added/removed | On/off toggle per ad group |

### Migration Impact

If you relied on Similar Segments:
1. Ensure your seed audiences (Customer Match, Remarketing) are healthy
2. Enable Optimized Targeting on relevant ad groups
3. Monitor performance — OT uses broader signals than Similar Segments
4. Consider PMax for the most automated audience expansion

---

## PMax Audience Signals

**Critical concept**: In Performance Max, audience signals are **hints**, not hard
targeting constraints. Google's ML can (and will) go beyond your signals.

### How Signals Work

```
Your Audience Signal: "Customer Match list of high-value buyers"
                              ↓
Google's ML: "I'll START with users similar to this list..."
                              ↓
Google's ML: "...but I'll also explore other users who show
              conversion propensity based on my broader signals"
```

### Signal Types for PMax

| Signal Type | What You Provide | Google's Interpretation |
|-------------|-----------------|----------------------|
| Customer Match lists | Hashed customer data | "Find users like these" |
| Website visitors | Remarketing lists | "Find users with similar browsing" |
| Custom segments | Keywords, URLs | "Find users with this intent" |
| In-Market / Affinity | Predefined categories | "Start in these interest areas" |
| Demographics | Age, gender, income | "Prioritize these segments" |

### Best Practices

1. **Add strong signals**: Your best Customer Match lists and remarketing audiences
2. **Don't over-constrain**: Too many narrow signals can confuse the ML
3. **Layer signal types**: Mix first-party (CRM) + intent (custom segments) + interests
4. **Monitor asset group reports**: See which audiences PMax actually targets
5. **Accept that PMax will go beyond signals**: This is by design, not a bug

### Common Misconception

> "I added my Customer Match list as a signal, but PMax is showing ads to people not
> on my list!"

This is expected behavior. Signals guide initial exploration. PMax's ML will expand to
any audience segment that shows conversion propensity. If you need hard targeting
constraints, use Search or Display campaigns instead.

---

## Match Rate Optimization

For Customer Match uploads, match rate determines audience size and quality.

### Multi-Key Strategy

Upload multiple identifiers per user to maximize match rates:

```python
user_data = {
    "email": "user@example.com",         # Primary identifier
    "phone": "+521234567890",             # Secondary (E.164 format)
    "first_name": "Juan",                 # Supplementary
    "last_name": "García",               # Supplementary
    "country_code": "MX",                # Supplementary
    "zip_code": "06600",                 # Supplementary
}
```

**Match rate impact by identifier count**:
- Email only: ~30-50% match rate
- Email + phone: ~50-70% match rate
- Email + phone + name + postal: ~70-85% match rate
- Target: **80%+ match rate**

### Phone Number Formatting (LATAM)

| Country | Format | Example |
|---------|--------|---------|
| Mexico | +52 + 10 digits | +525512345678 |
| Spain | +34 + 9 digits | +34612345678 |
| Colombia | +57 + 10 digits | +573001234567 |
| Argentina | +54 + area + number | +5491112345678 |
| Chile | +56 + 9 digits | +56912345678 |
| Peru | +51 + 9 digits | +51912345678 |

Always use **E.164 format** (+ country code, no spaces, no dashes).

### Hashing Requirements

All PII must be SHA-256 hashed before upload:

```python
import hashlib

def hash_value(value):
    """Normalize and hash a value for Customer Match."""
    if not value:
        return None
    normalized = value.strip().lower()
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()

# Email: normalize (lowercase, trim)
hashed_email = hash_value("User@Example.com")

# Phone: E.164, then hash
hashed_phone = hash_value("+525512345678")

# Name: lowercase, trim, then hash
hashed_first = hash_value("Juan")
hashed_last = hash_value("García")
```

---

## Audience Lifecycle & Health

### Lifecycle Stages

```
Creation → Population → Active → Stale → Expired
   │           │          │        │         │
   │      Tag/upload   In use   No new    Removed
   │      starts      in ads   members   from
   │      filling              added     campaigns
   │                           recently
```

### Health Indicators

| Metric | Healthy | Warning | Action |
|--------|---------|---------|--------|
| **Size** | > 1,000 (Search) | 100-1,000 | Add more sources, extend window |
| **Match rate** | > 60% | 30-60% | Add multi-key identifiers |
| **Freshness** | Updated < 7 days | 7-30 days | Automate refresh via Data Manager API |
| **Membership status** | OPEN | CLOSED | Reopen if still needed |

### size_for_search vs size_for_display

```sql
SELECT user_list.name, user_list.size_for_search, user_list.size_for_display,
       user_list.membership_status, user_list.membership_life_span
FROM user_list
WHERE user_list.membership_status = 'OPEN'
```

- `size_for_search`: Eligible for Search Network targeting (higher threshold)
- `size_for_display`: Eligible for Display/Video targeting (lower threshold)
- Sizes update with ~24-48h delay
- size = 0 typically means list is too new (< 24h)

### Refresh Cadences

| Audience Type | Recommended Refresh | Method |
|--------------|-------------------|--------|
| Customer Match (CRM) | Weekly | Data Manager API scheduled sync |
| Customer Match (transactional) | Daily | API automation |
| Remarketing lists | Auto (tag-based) | No action needed |
| YouTube audiences | Auto | No action needed |
| GA4 audiences | Auto (24-48h lag) | No action needed |

---

## Audience Overlap & Exclusions

### Checking Overlap

There is **no direct API** for audience overlap analysis. Workarounds:

1. **Google Ads UI**: Audience Manager → Audience Insights → overlap visualization
2. **Estimation via API**: Query audience sizes, compare with combined audience size
3. **GA4**: Use Exploration tool for audience overlap reports

### Negative Audiences (Exclusions)

Apply audiences as exclusions to prevent wasted spend:

```python
# Exclude an audience from a campaign
criterion_op = client.get_type("CampaignCriterionOperation")
criterion = criterion_op.create
criterion.campaign = f"customers/{cid}/campaigns/{campaign_id}"
criterion.user_list.user_list = f"customers/{cid}/userLists/{list_id}"
criterion.negative = True  # This makes it an exclusion

campaign_criterion_service.mutate_campaign_criteria(
    customer_id=cid, operations=[criterion_op])
```

### Essential Exclusion Patterns

| Campaign Type | Exclude | Reason |
|--------------|---------|--------|
| Prospecting/Acquisition | All Customers list | Don't pay to acquire existing customers |
| Retargeting | Recent Converters (30d) | They already converted |
| Upsell | Non-customers | Only target existing buyers |
| Brand campaigns | Competitors custom segment | Avoid irrelevant clicks |

---

## Optimized Targeting

Google's ML-driven audience expansion. **Not the same as Similar Segments** — it uses
a broader set of signals and is tightly integrated with campaign objectives.

### Where It Applies

| Campaign Type | Default State | Recommended |
|--------------|--------------|-------------|
| **Display** | ON | Keep ON unless strict audience control needed |
| **Demand Gen** | ON | Keep ON for prospecting, OFF for retargeting-only |
| **Video (TrueView)** | ON | Keep ON |
| **Search** | N/A (keywords control targeting) | N/A |
| **PMax** | Always ON (can't disable) | N/A |

### When to Turn OFF

- Pure retargeting campaigns where you ONLY want to reach your list
- Strict audience size control needed (e.g., limited budget, specific test)
- Account is learning and you want to validate base audiences first

### How It Differs from PMax Signals

- **Optimized Targeting** (Display/Demand Gen): Expands beyond your audience selections
  but stays within your ad group structure
- **PMax Signals**: Expands beyond signals AND across all Google properties simultaneously

---

## Privacy Sandbox & Future

### Chrome Privacy Sandbox (Rollout 2025-2026)

| API | What It Replaces | Status (Feb 2026) |
|-----|-----------------|-------------------|
| **Topics API** | Third-party cookie interest targeting | Active rollout (~60% Chrome users) |
| **Attribution Reporting** | Cross-site conversion tracking | Active rollout |
| **Protected Audiences** | Remarketing via third-party cookies | Active rollout |
| **Private Aggregation** | Detailed cross-site reporting | Active rollout |

### Impact on Google Ads Audiences

- **Customer Match**: No impact (first-party data, server-side)
- **Remarketing (tag-based)**: Partially affected (Chrome moving to Protected Audiences)
- **In-Market/Affinity**: Transitioning to Topics API signals
- **Conversion tracking**: Enhanced Conversions + sGTM become critical

### Strategic Response

1. **Maximize first-party data** collection and Customer Match usage
2. **Implement Enhanced Conversions** for resilient conversion tracking
3. **Deploy server-side tagging (sGTM)** for first-party cookie persistence
4. **Diversify audience sources**: YouTube, App, GA4 (all logged-in, less cookie-dependent)
5. **Adopt Consent Mode V2** for EU compliance (mandatory for remarketing)

---

## Retargeting Funnel Architecture

### Full-Funnel Audience Strategy

```
┌─────────────────────────────────────────────────┐
│  TOFU (Awareness) — 60% of audience budget      │
│  Audiences: In-Market, Affinity, Custom Segments │
│  Campaign: Display, Video, Demand Gen            │
│  Bidding: Max Impressions / tCPV                 │
├─────────────────────────────────────────────────┤
│  MOFU (Consideration) — 25% of audience budget  │
│  Audiences: Website visitors (7-30d), Video      │
│  viewers, Blog readers                           │
│  Campaign: Display, Search (RLSA), Demand Gen    │
│  Bidding: Max Clicks / tCPA                      │
├─────────────────────────────────────────────────┤
│  BOFU (Conversion) — 10% of audience budget     │
│  Audiences: Cart abandoners (1-7d), Product      │
│  viewers (1-14d), High-intent non-converters     │
│  Campaign: Search (RLSA), Display, Shopping      │
│  Bidding: tCPA / tROAS (aggressive)              │
├─────────────────────────────────────────────────┤
│  Loyalty — 5% of audience budget                │
│  Audiences: Customer Match (all), Recent buyers  │
│  Campaign: Display, Search, Demand Gen           │
│  Bidding: tROAS (value-based)                    │
│  Goal: Upsell, cross-sell, retention             │
└─────────────────────────────────────────────────┘
```

### RLSA (Remarketing Lists for Search Ads)

Apply remarketing audiences to Search campaigns for bid adjustments:

```python
# Add remarketing audience to Search campaign with bid modifier
criterion_op = client.get_type("AdGroupCriterionOperation")
criterion = criterion_op.create
criterion.ad_group = f"customers/{cid}/adGroups/{ag_id}"
criterion.user_list.user_list = f"customers/{cid}/userLists/{list_id}"
criterion.bid_modifier = 1.5  # +50% bid for returning visitors
# NOTE: bid_modifier only works with Manual CPC or eCPC, not Smart Bidding
```

**With Smart Bidding**: Audiences are used as signals automatically (no manual bid
modifier needed). Add them as "Observation" targeting mode.

---

## Common Mistakes

### 1. PMax Signals ≠ Hard Targeting

**Wrong assumption**: "Adding my Customer Match list as a PMax signal means only those
users will see my ads."

**Reality**: Signals are hints. PMax will expand to any user showing conversion propensity.

### 2. Using Deprecated Similar Segments

**Wrong**: Trying to create or reference Similar Segments (removed August 2023).

**Correct**: Use Optimized Targeting (Display/Demand Gen) or PMax audience signals.

### 3. Stale Customer Match Lists

**Wrong**: Uploading a Customer Match list once and never refreshing.

**Correct**: Automate weekly refresh via Data Manager API or scheduled API uploads.
Stale lists have declining match rates as users change email addresses.

### 4. No Exclusions

**Wrong**: Running acquisition and retargeting campaigns without audience exclusions.

**Correct**: Always exclude existing customers from acquisition campaigns and recent
converters from retargeting campaigns.

### 5. Wrong Remarketing Windows

**Wrong**: Using 540-day (maximum) windows for all remarketing lists.

**Correct**: Match window to your sales cycle. 540 days of "All Visitors" creates a
massive, low-intent audience that wastes budget.

### 6. Ignoring Match Rate

**Wrong**: Uploading email-only Customer Match lists and accepting 30% match rate.

**Correct**: Upload multi-key data (email + phone + name) to achieve 70%+ match rates.

### 7. Not Linking YouTube Channel

**Wrong**: Running YouTube ads without linking your channel to Google Ads.

**Correct**: Link FIRST, then run campaigns. Only post-linking interactions count for
audience building.

### 8. Mixing Observation and Targeting Modes

**Wrong**: Adding audiences in "Targeting" mode when you want bid adjustments only.

**Correct**:
- **Targeting** mode: Only show ads to this audience (restricts reach)
- **Observation** mode: Show ads to everyone, but observe this audience's performance
  (and optionally adjust bids)

For Smart Bidding campaigns, use Observation — the algorithm uses audiences as signals
automatically.

---

## Cross-References

- **Customer Match API code** → `campaign-management.md` §11 (Audience Targeting)
- **Customer Match strategy & Data Manager API** → `first-party-data-strategy.md` §7
- **Smart Bidding interaction with audiences** → `smart-bidding.md`
- **PMax asset group creation** → `campaign-management.md` §3
- **Consent Mode for EU audiences** → `first-party-data-strategy.md` §4
- **GAQL audience queries** → `gaql-reference.md`
