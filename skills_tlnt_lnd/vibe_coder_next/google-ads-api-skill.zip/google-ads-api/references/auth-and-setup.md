# Authentication & Setup Reference

## Table of Contents
1. [Developer Token & Access Levels](#developer-token--access-levels)
2. [OAuth 2.0 Setup (Recommended)](#oauth-20-setup)
3. [Service Account Setup](#service-account-setup)
4. [google-ads.yaml Full Reference](#google-adsyaml-full-reference)
5. [Environment Variable Configuration](#environment-variables)
6. [Cloud-Managed Access (New in 2025)](#cloud-managed-access)
7. [Common Auth Errors and Fixes](#common-auth-errors)

---

## Developer Token & Access Levels

Developer tokens live in **Manager Accounts (MCCs)** only. Find yours at:
**Tools & Settings → Setup → API Center** in the Google Ads UI.

| Access Level | Daily Ops Limit | Use Case | How to Get |
|-------------|----------------|----------|------------|
| Test Account | 15,000 | Dev/testing only (test accounts) | Auto-granted |
| Explorer | 2,880 | Production, limited scale | Auto-granted on sign-up |
| Basic | 15,000 | Production workloads | Compliance review (~2 business days) |
| Standard | Unlimited | Enterprise / high-volume | RMF compliance review |

To apply for Basic or Standard access, fill out the API Access form in API Center.
Google reviews for Required Minimum Functionality (RMF) compliance — your tool must
provide meaningful value beyond raw API access.

**Important**: Paginated `Search` requests using `next_page_token` do NOT count against
daily operation quotas. Only the initial request counts.

---

## OAuth 2.0 Setup

This is the recommended auth method for most use cases.

### Step 1: Create Google Cloud Project

1. Go to https://console.cloud.google.com/
2. Create a new project (or select existing)
3. Enable the **Google Ads API**: APIs & Services → Library → search "Google Ads API" → Enable

### Step 2: Configure OAuth Consent Screen

1. APIs & Services → OAuth consent screen
2. Choose **External** (or Internal for Workspace orgs)
3. Fill required fields: App name, support email, developer email
4. Add scope: `https://www.googleapis.com/auth/adwords`
5. **CRITICAL: Publish the app** — unpublished apps get 7-day refresh token expiry.
   For internal tools, "Internal" user type avoids the verification process entirely.

### Step 3: Create OAuth Credentials

1. APIs & Services → Credentials → Create Credentials → OAuth 2.0 Client ID
2. Application type: **Desktop app** (for scripts/CLIs) or **Web application** (for web apps)
3. Download the JSON file → save as `client_secret.json`

### Step 4: Generate Refresh Token

```bash
# Using the official helper script
pip install google-ads google-auth-oauthlib
curl -s https://raw.githubusercontent.com/googleads/google-ads-python/main/examples/authentication/generate_user_credentials.py \
  | python3 - --client_secrets_path=client_secret.json

# This opens a browser, you authenticate, and it prints the refresh token
```

Or manually with the Python library:

```python
from google_auth_oauthlib.flow import InstalledAppFlow

SCOPES = ["https://www.googleapis.com/auth/adwords"]
flow = InstalledAppFlow.from_client_secrets_file("client_secret.json", scopes=SCOPES)
credentials = flow.run_local_server(port=0)
print(f"Refresh token: {credentials.refresh_token}")
```

### Step 5: Create google-ads.yaml

```yaml
developer_token: "YOUR_22_CHAR_TOKEN"
client_id: "123456789.apps.googleusercontent.com"
client_secret: "GOCSPX-..."
refresh_token: "1//0abc..."
login_customer_id: "1234567890"  # MCC ID, no hyphens
use_proto_plus: True
```

### Step 6: Verify with First API Call

```python
from google.ads.googleads.client import GoogleAdsClient

client = GoogleAdsClient.load_from_storage("google-ads.yaml")
customer_service = client.get_service("CustomerService")
response = customer_service.list_accessible_customers()
print("Accessible customers:")
for resource_name in response.resource_names:
    print(f"  {resource_name}")
```

---

## Service Account Setup

Use when: running unattended server processes, especially within Google Workspace orgs.
Requires: Google Workspace with domain-wide delegation configured by a super admin.

### Step 1: Create Service Account

1. Google Cloud Console → IAM & Admin → Service Accounts → Create
2. Give it a descriptive name
3. Create a JSON key → download and secure it

### Step 2: Enable Domain-Wide Delegation

1. In the service account settings, check "Enable Google Workspace Domain-wide Delegation"
2. Note the Client ID (numeric) shown
3. Go to Google Workspace Admin → Security → API Controls → Domain-wide Delegation
4. Add new: Client ID = the numeric ID, Scopes = `https://www.googleapis.com/auth/adwords`

### Step 3: Configure google-ads.yaml for Service Account

```yaml
developer_token: "YOUR_DEV_TOKEN"
json_key_file_path: "/secure/path/to/service-account-key.json"
impersonated_email: "ads-admin@yourdomain.com"  # Workspace user with Ads access
login_customer_id: "1234567890"
use_proto_plus: True
```

### Step 4: Initialize Client

```python
client = GoogleAdsClient.load_from_storage("google-ads.yaml")
# Works identically to OAuth — the library handles token exchange internally
```

**Security best practice**: Store the JSON key in a secrets manager (GCP Secret Manager,
AWS Secrets Manager, HashiCorp Vault) and load into the client via `load_from_dict()`.

---

## google-ads.yaml Full Reference

```yaml
# === Required ===
developer_token: "ABCDEFGHIJKLMNOPQRSTUV"

# === OAuth 2.0 (choose this OR service account) ===
client_id: "123456789.apps.googleusercontent.com"
client_secret: "GOCSPX-..."
refresh_token: "1//0abc..."

# === Service Account (choose this OR OAuth) ===
# json_key_file_path: "/path/to/key.json"
# impersonated_email: "user@domain.com"

# === Optional ===
login_customer_id: "1234567890"     # MCC ID (no hyphens). Required when accessing
                                     # client accounts through a manager hierarchy.
linked_customer_id: ""               # For third-party data partners only.
use_proto_plus: True                 # True = Pythonic objects (default).
                                     # False = raw protobuf (better performance).
http_proxy: ""                       # HTTP proxy URL if needed.
use_cloud_org_for_api_access: False  # For cloud-managed access (no dev token).
```

---

## Environment Variables

Every YAML field has an env var equivalent prefixed with `GOOGLE_ADS_`:

```bash
export GOOGLE_ADS_DEVELOPER_TOKEN="ABCDEFGHIJKLMNOPQRSTUV"
export GOOGLE_ADS_CLIENT_ID="123456789.apps.googleusercontent.com"
export GOOGLE_ADS_CLIENT_SECRET="GOCSPX-..."
export GOOGLE_ADS_REFRESH_TOKEN="1//0abc..."
export GOOGLE_ADS_LOGIN_CUSTOMER_ID="1234567890"
export GOOGLE_ADS_USE_PROTO_PLUS="True"
# For service accounts:
export GOOGLE_ADS_JSON_KEY_FILE_PATH="/path/to/key.json"
export GOOGLE_ADS_IMPERSONATED_EMAIL="user@domain.com"
```

Then: `client = GoogleAdsClient.load_from_env()`

---

## Cloud-Managed Access

New in 2025, this model eliminates developer tokens entirely. API access is managed
through Google Cloud organization settings. To use it:

1. Set `use_cloud_org_for_api_access: True` in config
2. Omit the `developer_token` field
3. Your Google Cloud project must be part of an organization with API access configured

This is still rolling out and not yet available to all accounts.

---

## Application Default Credentials (ADC)

For workloads running on GCP (Cloud Run, GKE, Compute Engine, Cloud Functions), you can
use ADC instead of explicit OAuth credentials. The client library automatically detects
GCP environment credentials.

```python
# On GCP, if ADC is configured and Google Ads API scope is authorized:
client = GoogleAdsClient.load_from_dict({
    "developer_token": "YOUR_TOKEN",
    "login_customer_id": "1234567890",
    "use_proto_plus": True,
    # No client_id, client_secret, or refresh_token needed
})
```

ADC works with service accounts attached to GCP resources. Ensure the service account
has the `https://www.googleapis.com/auth/adwords` scope authorized.

---

## Explorer Access Update (February 2026)

As of February 2026, Google grants **Explorer Access** automatically when you obtain a
developer token. Combined with the MCP Server and Developer Assistant tools, this
provides a low-friction onboarding path. However, Explorer Access is limited to 2,880
operations/day — apply for Basic Access for anything beyond testing.

---

## Consent Mode V2 (Required for EU/EEA)

Consent Mode V2 controls how Google tags behave based on user consent. **Mandatory** for
EU/EEA traffic since March 2024. Without it, remarketing and Customer Match are blocked.

**The 4 consent signals:**
- `ad_storage` — advertising cookies
- `analytics_storage` — analytics cookies
- `ad_user_data` (V2 new) — sending user data to Google for advertising
- `ad_personalization` (V2 new) — personalized advertising / remarketing

**Basic vs Advanced Mode**: Basic only fires tags after consent. Advanced fires restricted
tags even when denied, allowing Google to **model** conversions (typically recovers 50-70%
of otherwise-lost EU conversions).

**Impact on API**: All conversion uploads and Customer Match operations must include consent:
```python
click_conversion.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
click_conversion.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED
```

Only set GRANTED when you have verified consent. Setting it without actual consent
violates both Google's policies and EU regulations.

**Data Manager API auth**: Uses the same Google Cloud project and OAuth credentials as
Google Ads API, with the additional scope `https://www.googleapis.com/auth/datamanager`.

For complete implementation (gtag defaults, CMP integration, region-specific config,
server-side tagging), see `references/first-party-data-strategy.md` → Consent Mode V2.

---

## Common Auth Errors

| Error | Cause | Fix |
|-------|-------|-----|
| `DEVELOPER_TOKEN_NOT_APPROVED` | Token not approved or test-only | Apply for Basic access in API Center |
| `USER_PERMISSION_DENIED` | Wrong login_customer_id or no account access | Verify MCC hierarchy, check login_customer_id |
| `OAUTH_TOKEN_REVOKED` | Refresh token expired or revoked | Regenerate refresh token; publish your OAuth app |
| `CUSTOMER_NOT_FOUND` | Invalid customer ID or no access through MCC | Verify customer ID format (10 digits, no hyphens) |
| `NOT_ADS_USER` | Authenticated user has no Google Ads access | Grant access in Google Ads UI → Admin → Access |
| `AUTHORIZATION_ERROR` | Multiple causes | Check all three required headers: Authorization, developer-token, login-customer-id |

### Debugging tip

Enable request/response logging to see exact headers and payloads:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
# Or just for the Google Ads library:
logging.getLogger("google.ads.googleads.client").setLevel(logging.DEBUG)
```
