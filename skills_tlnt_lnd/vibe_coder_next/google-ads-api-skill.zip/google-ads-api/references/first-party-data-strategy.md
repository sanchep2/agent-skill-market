# First-Party Data Strategy Reference — State of the Art (July 2026)

<!-- last_verified: 2026-07-17 — Data Manager API gating dates (Apr 1 / Jun 15 2026) confirmed against
     Google Ads Developer Blog + release notes. -->


## Table of Contents
1. [The First-Party Data Imperative](#the-first-party-data-imperative)
2. [Data Manager API](#data-manager-api)
3. [Enhanced Conversions](#enhanced-conversions)
4. [Consent Mode V2 & Privacy Infrastructure](#consent-mode-v2--privacy-infrastructure)
5. [Value-Based Bidding with Customer Data](#value-based-bidding-with-customer-data)
6. [Customer Lifecycle Goals](#customer-lifecycle-goals)
7. [Customer Match Master Strategy](#customer-match-master-strategy)
8. [Conversion Adjustments](#conversion-adjustments)
9. [Server-Side Tracking Infrastructure](#server-side-tracking-infrastructure)
10. [Implementation Roadmap](#implementation-roadmap)
11. [Cross-Skill Integration: Talent Academy backend → Data Manager API](#cross-skill-integration-talent-academy-backend--data-manager-api)

---

## The First-Party Data Imperative

In 2026, the quality of first-party data fed into Google's algorithms is the #1 differentiator
between advertisers who scale profitably and those who don't. Three forces make this critical:

1. **Cookie deprecation and browser restrictions**: Safari ITP limits JS-set cookies to 7 days
   (24 hours with link decoration). Firefox blocks third-party cookies. Chrome's Privacy Sandbox
   reduces cross-site tracking. Without first-party data, attribution degrades significantly.

2. **Smart Bidding depends on signal quality**: Google's ML bidding algorithms (tCPA, tROAS,
   Max Conversions) can only optimize for what they can see. Advertisers who feed richer signals
   (enhanced conversions, customer value data, lifecycle stages) get fundamentally better
   optimization than those who rely solely on pixel-based conversion tracking.

3. **Audience strategy requires CRM data**: Customer Match, lifecycle goals, value-based bidding,
   and exclusion strategies all require connecting your customer database to Google Ads.

**The data stack**: CRM/Database → (Data Manager API | Google Ads API) → Google Ads →
Smart Bidding + Audiences + Measurement.

---

## Data Manager API

### Overview

The **Data Manager API** (GA since October 2025, current version v1) is Google's unified
platform for ingesting first-party data into Google Ads. It replaces and supplements multiple
legacy data upload methods with a single, consistent interface.

**Why use Data Manager API vs Google Ads API for data uploads:**

| Capability | Google Ads API | Data Manager API |
|-----------|---------------|------------------|
| Offline conversion uploads | ⚠️ Gated (allowlist) since Jun 15, 2026 | ✅ Full support |
| Enhanced Conversions for Leads | ⚠️ Via ConversionUploadService — gated since Jun 15, 2026 | ✅ Recommended by Google |
| Customer Match | ⚠️ Via OfflineUserDataJobService — gated since Apr 1, 2026 | ✅ Required path forward |
| Direct CRM/warehouse connectors | ❌ Custom code needed | ✅ Native (Salesforce, HubSpot, BigQuery, etc.) |
| Session attributes / IP data | ❌ Restricted since Feb 2, 2026 | ✅ Required path |
| Mobile device IDs | ❌ Limited | ✅ Full support |
| PAIR data (Publisher Advertiser Identity Reconciliation) | ❌ | ✅ Supported |
| Scheduled/automated syncs | ❌ Custom code | ✅ Built-in scheduling |

**When to use which**: Use Data Manager API when you need direct CRM/warehouse integration,
scheduled syncs, or are uploading session-level data. Use Google Ads API when you need
fine-grained programmatic control, real-time uploads from your application, or integration
into existing API-based pipelines — **but note the gating below: for a brand-new integration on
a developer token without recent first-party-data activity, the Google Ads API upload path is no
longer viable and Data Manager API is the de-facto mandatory route.**

### First-party upload gating — the mandate is now enforced (last_verified: 2026-07-17)

Through 2026 Google progressively closed the direct Google Ads API upload services to developer
tokens without recent first-party-data activity, funnelling all new integrations to Data Manager API:

| Date | What changed |
|------|--------------|
| **Feb 2, 2026** | Session attributes / IP-address data restricted on the Google Ads API upload path (Data Manager API required for those signals). |
| **Apr 1, 2026** | **Customer Match** via `OfflineUserDataJobService` gated behind an allowlist — tokens without recent activity are blocked. |
| **Jun 15, 2026** | **Offline conversions & Enhanced Conversions** via `ConversionUploadService` gated the same way. |

A blocked call fails with **`CUSTOMER_NOT_ALLOWLISTED_FOR_THIS_FEATURE`**. This is not a soft
deprecation warning — the request is rejected. Existing integrations with continuous activity retain
access, but **any new integration must default to Data Manager API**. Treat the "optional migration"
language elsewhere in this reference as historical: for new work it is mandatory.

Sources: Google Ads Developer Blog announcements (Customer Match, Apr 2026; offline/Enhanced
Conversions, Jun 2026) — `ads-developers.googleblog.com`.

### Authentication & Setup

Data Manager API uses the same Google Cloud project as Google Ads API. Requirements:
- Google Cloud project with Data Manager API enabled
- OAuth 2.0 credentials (same as Google Ads API)
- Scope: `https://www.googleapis.com/auth/datamanager`
- The Google Ads account must be linked to the Google Cloud project

```python
# Install the client library
# pip install google-ads-data-manager  # or use REST directly

import requests
from google.oauth2.credentials import Credentials

# Reuse your existing OAuth credentials
credentials = Credentials(
    token=None,
    refresh_token="YOUR_REFRESH_TOKEN",
    client_id="YOUR_CLIENT_ID",
    client_secret="YOUR_CLIENT_SECRET",
    token_uri="https://oauth2.googleapis.com/token",
    scopes=["https://www.googleapis.com/auth/datamanager"]
)
credentials.refresh(google.auth.transport.requests.Request())

BASE_URL = "https://datamanager.googleapis.com/v1"
HEADERS = {
    "Authorization": f"Bearer {credentials.token}",
    "Content-Type": "application/json"
}
```

### Rate Limits

| Dimension | Limit |
|-----------|-------|
| Requests per day per project | 100,000 |
| Requests per minute | 300 |
| User identifiers per request | 10,000 |
| Conversion events per request | 2,000 |
| User identifiers per record | Up to 10 |
| Data sources per account | 50 |

### Core Concepts

- **Data Source**: Represents a connection to an external data system (CRM, warehouse, manual)
- **Audience**: A user list that receives data from a data source
- **Data Mapping**: Defines how source fields map to Google Ads fields
- **Data Transfer**: A single batch of data sent from source to Google Ads

### Supported Data Sources (Native Connectors)

Cloud/Warehouse: BigQuery, Snowflake, Amazon Redshift, Google Cloud Storage, Amazon S3
Database: MySQL, PostgreSQL
CRM: Salesforce, HubSpot
Other: Google Sheets, SFTP, HTTP/API endpoint

### Python: Upload Customer Match via Data Manager API

```python
import json

def upload_customer_match_data_manager(credentials, customer_id, user_list_id, records):
    """
    Upload hashed customer data to a Customer Match list via Data Manager API.
    
    records: list of dicts, each with keys like:
      hashed_email, hashed_phone, hashed_first_name, hashed_last_name,
      country_code, postal_code
    """
    headers = {
        "Authorization": f"Bearer {credentials.token}",
        "Content-Type": "application/json"
    }
    
    # Build the upload request
    payload = {
        "customerMatchUserListMetadata": {
            "userList": f"customers/{customer_id}/userLists/{user_list_id}",
            "consent": {
                "adUserData": "GRANTED",
                "adPersonalization": "GRANTED"
            }
        },
        "operations": []
    }
    
    for record in records:
        user_identifiers = []
        
        if "hashed_email" in record:
            user_identifiers.append({"hashedEmail": record["hashed_email"]})
        if "hashed_phone" in record:
            user_identifiers.append({"hashedPhoneNumber": record["hashed_phone"]})
        if "hashed_first_name" in record and "hashed_last_name" in record:
            address_info = {
                "hashedFirstName": record["hashed_first_name"],
                "hashedLastName": record["hashed_last_name"],
            }
            if "country_code" in record:
                address_info["countryCode"] = record["country_code"]
            if "postal_code" in record:
                address_info["postalCode"] = record["postal_code"]
            user_identifiers.append({"addressInfo": address_info})
        
        payload["operations"].append({
            "create": {"userIdentifiers": user_identifiers}
        })
    
    # Submit in chunks of 10,000
    CHUNK_SIZE = 10_000
    for i in range(0, len(payload["operations"]), CHUNK_SIZE):
        chunk_payload = {**payload, "operations": payload["operations"][i:i+CHUNK_SIZE]}
        response = requests.post(
            f"https://datamanager.googleapis.com/v1/customers/{customer_id}:uploadCustomerMatchUserListData",
            headers=headers,
            json=chunk_payload
        )
        if response.status_code != 200:
            print(f"Error chunk {i}: {response.text}")
        else:
            result = response.json()
            print(f"Chunk {i}: uploaded {len(chunk_payload['operations'])} records")
    
    return response.json()
```

### Python: Upload Enhanced Conversions via Data Manager API

```python
def upload_enhanced_conversions_data_manager(credentials, customer_id, conversions):
    """
    Upload enhanced conversions for leads via Data Manager API.
    
    conversions: list of dicts with keys:
      conversion_action_id, conversion_time, conversion_value, currency_code,
      hashed_email, (optional: hashed_phone, hashed_first_name, hashed_last_name,
      gclid, order_id)
    """
    headers = {
        "Authorization": f"Bearer {credentials.token}",
        "Content-Type": "application/json"
    }
    
    conversion_ops = []
    for conv in conversions:
        user_identifiers = []
        if "hashed_email" in conv:
            user_identifiers.append({"hashedEmail": conv["hashed_email"]})
        if "hashed_phone" in conv:
            user_identifiers.append({"hashedPhoneNumber": conv["hashed_phone"]})
        
        conversion_data = {
            "conversionAction": f"customers/{customer_id}/conversionActions/{conv['conversion_action_id']}",
            "conversionDateTime": conv["conversion_time"],
            "conversionValue": conv["conversion_value"],
            "currencyCode": conv.get("currency_code", "USD"),
            "userIdentifiers": user_identifiers,
            "consent": {
                "adUserData": "GRANTED",
                "adPersonalization": "GRANTED"
            }
        }
        if "gclid" in conv:
            conversion_data["gclid"] = conv["gclid"]
        if "order_id" in conv:
            conversion_data["orderId"] = conv["order_id"]
        
        conversion_ops.append(conversion_data)
    
    # Submit in chunks of 2,000
    CHUNK_SIZE = 2_000
    for i in range(0, len(conversion_ops), CHUNK_SIZE):
        chunk = conversion_ops[i:i+CHUNK_SIZE]
        payload = {"conversions": chunk, "partialFailure": True}
        response = requests.post(
            f"https://datamanager.googleapis.com/v1/customers/{customer_id}:uploadClickConversions",
            headers=headers,
            json=payload
        )
        if response.status_code != 200:
            print(f"Error chunk {i}: {response.text}")
    
    return response.json()
```

### BigQuery → Data Manager → Google Ads Pipeline

```python
def sync_bigquery_to_customer_match(credentials, project_id, dataset, table,
                                     customer_id, user_list_id):
    """
    Create a scheduled sync from BigQuery to Customer Match via Data Manager.
    This runs server-side — no need to extract data yourself.
    """
    payload = {
        "displayName": f"BQ Sync: {dataset}.{table}",
        "dataSource": {
            "bigQuerySource": {
                "projectId": project_id,
                "datasetId": dataset,
                "tableId": table
            }
        },
        "destination": {
            "customerMatchUserList": {
                "userList": f"customers/{customer_id}/userLists/{user_list_id}",
                "consent": {"adUserData": "GRANTED", "adPersonalization": "GRANTED"}
            }
        },
        "fieldMappings": [
            {"sourceField": "email_hash", "destinationField": "hashed_email"},
            {"sourceField": "phone_hash", "destinationField": "hashed_phone_number"},
            {"sourceField": "first_name_hash", "destinationField": "hashed_first_name"},
            {"sourceField": "last_name_hash", "destinationField": "hashed_last_name"},
        ],
        "schedule": {
            "frequency": "DAILY",
            "startTime": "02:00"  # Run at 2 AM
        }
    }
    
    response = requests.post(
        f"https://datamanager.googleapis.com/v1/customers/{customer_id}/dataTransferConfigs",
        headers={"Authorization": f"Bearer {credentials.token}", "Content-Type": "application/json"},
        json=payload
    )
    return response.json()
```

---

## Enhanced Conversions

### Overview

Enhanced Conversions improve conversion measurement by supplementing click data (GCLIDs,
cookies) with **hashed first-party data** (email, phone, name, address). Google matches
this data against its signed-in user base to recover conversions that would otherwise be lost
to cookie restrictions, cross-device journeys, or browser privacy features.

**Two flavors:**

| | Enhanced Conversions for Web | Enhanced Conversions for Leads |
|---|---|---|
| **Use case** | E-commerce, online conversions | Lead generation, offline conversions |
| **How it works** | Tag captures hashed user data at conversion time | Tag captures hashed data at form submit; you import conversion later |
| **GCLID required?** | No (but improves matching) | No — this is the key advantage |
| **Implementation** | gtag.js / GTM / API | gtag.js + API upload (or Data Manager) |
| **Typical lift** | 5-15% more attributed conversions | 15-30% more attributed conversions |
| **Best for** | Any online advertiser | B2B, SaaS, real estate, automotive, education |

### Supported User Identifiers

All identifiers must be **SHA-256 hashed** before sending (except country_code and postal_code):

| Field | API Field Name | Normalization Before Hashing |
|-------|---------------|------------------------------|
| Email | `hashed_email` | Lowercase, trim whitespace, remove dots before @ for gmail |
| Phone | `hashed_phone_number` | E.164 format (e.g., +14155551234) |
| First name | `hashed_first_name` | Lowercase, trim |
| Last name | `hashed_last_name` | Lowercase, trim |
| Street address | `hashed_street_address` | Lowercase, trim, remove apt/suite numbers |
| City | `city` | Lowercase, trim |
| Region/State | `region` | Lowercase, trim |
| Postal code | `postal_code` | First 5 digits (US), trim |
| Country | `country_code` | ISO 3166-1 alpha-2 (e.g., "US", "ES", "MX") |

**Match rate optimization**: Sending more identifiers dramatically improves match rates.
Email alone: ~50-60%. Email + phone: ~70-80%. Email + phone + name + address: ~85-95%.

### Enhanced Conversions for Web (API Implementation)

```python
import hashlib

def normalize_and_hash(value):
    """Normalize and SHA-256 hash a string value."""
    return hashlib.sha256(value.strip().lower().encode("utf-8")).hexdigest()

def normalize_and_hash_email(email):
    """Normalize email: lowercase, trim, remove dots from gmail local part."""
    email = email.strip().lower()
    parts = email.split("@")
    if len(parts) == 2 and parts[1] in ("gmail.com", "googlemail.com"):
        parts[0] = parts[0].replace(".", "")
    return hashlib.sha256("@".join(parts).encode("utf-8")).hexdigest()

def upload_enhanced_conversion_for_web(client, customer_id, conversion_action_id,
                                        order_id, conversion_time, conversion_value,
                                        user_data):
    """
    Upload an enhanced conversion for web.
    
    user_data: dict with optional keys:
      email, phone, first_name, last_name, street_address,
      city, region, postal_code, country_code
    """
    service = client.get_service("ConversionUploadService")
    cc = client.get_type("ClickConversion")
    
    # Conversion details
    cc.conversion_action = client.get_service(
        "ConversionActionService").conversion_action_path(
        customer_id, conversion_action_id)
    cc.conversion_date_time = conversion_time
    cc.conversion_value = conversion_value
    cc.currency_code = user_data.get("currency_code", "USD")
    cc.order_id = order_id  # Required for enhanced conversions for web
    
    # Add hashed user identifiers
    if "email" in user_data:
        ui = cc.user_identifiers.add()
        ui.hashed_email = normalize_and_hash_email(user_data["email"])
    
    if "phone" in user_data:
        ui = cc.user_identifiers.add()
        ui.hashed_phone_number = normalize_and_hash(user_data["phone"])
    
    if "first_name" in user_data or "last_name" in user_data:
        ui = cc.user_identifiers.add()
        addr = ui.address_info
        if "first_name" in user_data:
            addr.hashed_first_name = normalize_and_hash(user_data["first_name"])
        if "last_name" in user_data:
            addr.hashed_last_name = normalize_and_hash(user_data["last_name"])
        if "street_address" in user_data:
            addr.hashed_street_address = normalize_and_hash(user_data["street_address"])
        if "city" in user_data:
            addr.city = user_data["city"]
        if "region" in user_data:
            addr.region = user_data["region"]
        if "postal_code" in user_data:
            addr.postal_code = user_data["postal_code"]
        if "country_code" in user_data:
            addr.country_code = user_data["country_code"]
    
    # EU consent
    cc.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
    cc.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED
    
    response = service.upload_click_conversions(
        customer_id=customer_id,
        conversions=[cc],
        partial_failure=True)
    
    if response.partial_failure_error:
        print(f"Partial failure: {response.partial_failure_error.message}")
    return response
```

### Enhanced Conversions for Leads (API Implementation)

The two-step flow:
1. **Website tag** captures hashed user data at form submission (lead capture)
2. **API upload** sends the conversion event when the lead converts offline, matched by the
   same hashed identifiers — no GCLID needed

```python
def upload_enhanced_conversion_for_leads(client, customer_id, conversion_action_id,
                                          conversion_time, conversion_value,
                                          user_data, gclid=None, order_id=None):
    """
    Upload an enhanced conversion for leads (offline conversion with user data matching).
    
    This matches against the hashed data captured by the website tag at form submission.
    GCLID is optional — matching works via user identifiers alone.
    """
    service = client.get_service("ConversionUploadService")
    cc = client.get_type("ClickConversion")
    
    cc.conversion_action = client.get_service(
        "ConversionActionService").conversion_action_path(
        customer_id, conversion_action_id)
    cc.conversion_date_time = conversion_time
    cc.conversion_value = conversion_value
    cc.currency_code = user_data.get("currency_code", "USD")
    
    if gclid:
        cc.gclid = gclid
    if order_id:
        cc.order_id = order_id
    
    # User identifiers for matching (must match what the tag captured)
    if "email" in user_data:
        ui = cc.user_identifiers.add()
        ui.hashed_email = normalize_and_hash_email(user_data["email"])
    
    if "phone" in user_data:
        ui = cc.user_identifiers.add()
        ui.hashed_phone_number = normalize_and_hash(user_data["phone"])
    
    if "first_name" in user_data or "last_name" in user_data:
        ui = cc.user_identifiers.add()
        addr = ui.address_info
        if "first_name" in user_data:
            addr.hashed_first_name = normalize_and_hash(user_data["first_name"])
        if "last_name" in user_data:
            addr.hashed_last_name = normalize_and_hash(user_data["last_name"])
        if "country_code" in user_data:
            addr.country_code = user_data["country_code"]
    
    # EU consent
    cc.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
    cc.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED
    
    response = service.upload_click_conversions(
        customer_id=customer_id,
        conversions=[cc],
        partial_failure=True)
    
    if response.partial_failure_error:
        print(f"Partial failure: {response.partial_failure_error.message}")
    return response
```

### Batch Upload Pattern (Both Types)

```python
def batch_upload_enhanced_conversions(client, customer_id, conversion_action_id,
                                       conversions_data, batch_size=2000):
    """
    Upload enhanced conversions in batches.
    
    conversions_data: list of dicts with keys:
      conversion_time, conversion_value, email, (optional: phone, first_name,
      last_name, gclid, order_id, currency_code)
    """
    service = client.get_service("ConversionUploadService")
    total_success = 0
    total_failure = 0
    
    for i in range(0, len(conversions_data), batch_size):
        batch = conversions_data[i:i + batch_size]
        click_conversions = []
        
        for conv in batch:
            cc = client.get_type("ClickConversion")
            cc.conversion_action = client.get_service(
                "ConversionActionService").conversion_action_path(
                customer_id, conversion_action_id)
            cc.conversion_date_time = conv["conversion_time"]
            cc.conversion_value = conv["conversion_value"]
            cc.currency_code = conv.get("currency_code", "USD")
            
            if "gclid" in conv:
                cc.gclid = conv["gclid"]
            if "order_id" in conv:
                cc.order_id = conv["order_id"]
            
            # Hashed user identifiers
            if "email" in conv:
                ui = cc.user_identifiers.add()
                ui.hashed_email = normalize_and_hash_email(conv["email"])
            if "phone" in conv:
                ui = cc.user_identifiers.add()
                ui.hashed_phone_number = normalize_and_hash(conv["phone"])
            if "first_name" in conv or "last_name" in conv:
                ui = cc.user_identifiers.add()
                if "first_name" in conv:
                    ui.address_info.hashed_first_name = normalize_and_hash(conv["first_name"])
                if "last_name" in conv:
                    ui.address_info.hashed_last_name = normalize_and_hash(conv["last_name"])
            
            cc.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
            cc.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED
            click_conversions.append(cc)
        
        response = service.upload_click_conversions(
            customer_id=customer_id,
            conversions=click_conversions,
            partial_failure=True)
        
        batch_success = len(batch)
        if response.partial_failure_error:
            from google.ads.googleads import util as ads_util
            errors = ads_util.get_all_errors(response.partial_failure_error)
            batch_success -= len(errors)
            total_failure += len(errors)
        total_success += batch_success
        print(f"Batch {i//batch_size + 1}: {batch_success}/{len(batch)} succeeded")
    
    print(f"\nTotal: {total_success} succeeded, {total_failure} failed")
    return total_success, total_failure
```

### Conversion Action Setup for Enhanced Conversions

```python
def create_enhanced_conversion_action(client, customer_id, name, 
                                       conversion_type="UPLOAD_CLICKS",
                                       category="PURCHASE"):
    """
    Create a conversion action configured for enhanced conversions.
    
    conversion_type:
      - "UPLOAD_CLICKS" for enhanced conversions for leads
      - "WEBPAGE" for enhanced conversions for web (also needs tag setup)
    """
    service = client.get_service("ConversionActionService")
    op = client.get_type("ConversionActionOperation")
    ca = op.create
    ca.name = name
    ca.type_ = getattr(client.enums.ConversionActionTypeEnum, conversion_type)
    ca.category = getattr(client.enums.ConversionActionCategoryEnum, category)
    ca.status = client.enums.ConversionActionStatusEnum.ENABLED
    ca.value_settings.default_value = 0
    ca.value_settings.always_use_default_value = False
    ca.click_through_lookback_window_days = 90
    
    response = service.mutate_conversion_actions(
        customer_id=customer_id, operations=[op])
    
    resource_name = response.results[0].resource_name
    print(f"Created conversion action: {resource_name}")
    
    # Now enable enhanced conversions on this action
    enable_op = client.get_type("ConversionActionOperation")
    action = enable_op.update
    action.resource_name = resource_name
    # For UPLOAD_CLICKS: enhanced conversions for leads enabled automatically
    # For WEBPAGE: need to enable in tag settings
    
    return resource_name
```

### Diagnostics: Monitor Match Rates

```python
def check_enhanced_conversion_diagnostics(client, customer_id):
    """Query conversion upload diagnostics to monitor enhanced conversion match rates."""
    ga_service = client.get_service("GoogleAdsService")
    query = """
        SELECT conversion_action.name,
               conversion_action.type,
               metrics.all_conversions,
               metrics.conversions
        FROM conversion_action
        WHERE conversion_action.status = 'ENABLED'
          AND conversion_action.type IN ('UPLOAD_CLICKS', 'WEBPAGE')
    """
    stream = ga_service.search_stream(customer_id=customer_id, query=query)
    for batch in stream:
        for row in batch.results:
            ca = row.conversion_action
            print(f"{ca.name} ({ca.type_.name}): "
                  f"all_conversions={row.metrics.all_conversions}, "
                  f"counted={row.metrics.conversions}")
```

### Migration: Legacy Offline Imports → Enhanced Conversions for Leads

| Step | Action |
|------|--------|
| 1 | Implement enhanced conversion tag on your lead form (gtag or GTM) |
| 2 | Create new conversion action with type UPLOAD_CLICKS |
| 3 | Start uploading with user_identifiers (hashed email/phone/name) |
| 4 | Run both systems in parallel for 2-4 weeks to validate |
| 5 | Compare conversion counts — enhanced should show 15-30% more |
| 6 | Deprecate legacy GCLID-only uploads |
| 7 | Migrate to Data Manager API — **mandatory for new integrations / tokens without recent activity** (gated since Jun 15, 2026, see gating table above); optional only for legacy tokens with continuous activity |

---

## Consent Mode V2 & Privacy Infrastructure

### Overview

Consent Mode V2 is Google's framework for adjusting tag behavior based on user consent.
Mandatory for EU/EEA traffic since March 2024. Has 4 consent signals:

| Signal | Controls | Default (denied) Behavior |
|--------|----------|---------------------------|
| `ad_storage` | Advertising cookies | No ad cookies set |
| `analytics_storage` | Analytics cookies | No analytics cookies |
| `ad_user_data` (V2) | Sending user data to Google for advertising | Data not sent |
| `ad_personalization` (V2) | Personalized advertising (remarketing) | No remarketing |

### Basic vs Advanced Mode

**Basic Mode**: Tags only fire after user grants consent. Simple but you lose ALL data from
users who deny consent (typically 30-60% of EU traffic).

**Advanced Mode** (recommended): Tags fire in a restricted manner even when consent is denied.
Google uses the consented data to **model** conversions for denied-consent users, recovering
significant measurement signal. Typically recovers 50-70% of otherwise-lost conversions.

### Impact on Google Ads Features

| Feature | Without Consent Mode V2 | With Basic Mode | With Advanced Mode |
|---------|------------------------|----------------|--------------------|
| Remarketing (EU) | ❌ Blocked | ✅ Consented only | ✅ Consented only |
| Customer Match (EU) | ❌ Blocked | ✅ With ad_user_data | ✅ With ad_user_data |
| Smart Bidding signals | ⚠️ Degraded | ⚠️ Partial | ✅ Modeled recovery |
| Conversion measurement | ⚠️ Significant gaps | ⚠️ Consented only | ✅ Modeled + observed |
| Enhanced Conversions | ❌ Blocked | ✅ Consented only | ✅ Consented + modeled |

### Implementation: gtag.js Default State

```html
<!-- Set consent defaults BEFORE loading gtag.js -->
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}

// Default: denied for EU, granted for others
gtag('consent', 'default', {
  'ad_storage': 'denied',
  'analytics_storage': 'denied',
  'ad_user_data': 'denied',
  'ad_personalization': 'denied',
  'wait_for_update': 500,  // Wait 500ms for CMP to load
  'regions': ['EU', 'EEA', 'GB']  // Only apply restrictions in these regions
});

// Regions outside EU: grant by default
gtag('consent', 'default', {
  'ad_storage': 'granted',
  'analytics_storage': 'granted',
  'ad_user_data': 'granted',
  'ad_personalization': 'granted'
});

// Optional: enable URL passthrough for cross-page tracking without cookies
gtag('set', 'url_passthrough', true);

// Optional: redact ad click info when consent denied
gtag('set', 'ads_data_redaction', true);
</script>
```

### Update Consent After CMP Decision

```javascript
// When user accepts cookies via your CMP (Consent Management Platform):
function updateConsent(consentChoices) {
  gtag('consent', 'update', {
    'ad_storage': consentChoices.marketing ? 'granted' : 'denied',
    'analytics_storage': consentChoices.analytics ? 'granted' : 'denied',
    'ad_user_data': consentChoices.marketing ? 'granted' : 'denied',
    'ad_personalization': consentChoices.marketing ? 'granted' : 'denied'
  });
}
```

### Consent in API Uploads

All conversion uploads and Customer Match operations must include consent status.
The Google Ads API has required fields for this:

```python
# On every ClickConversion:
click_conversion.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
click_conversion.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED

# On every OfflineUserDataJob operation (Customer Match):
op.create.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
op.create.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED
```

**Important**: Only set to GRANTED when you have verified user consent. Setting GRANTED
without actual consent violates Google's policies and EU regulations. For users who have
not consented, either omit the upload or set to UNSPECIFIED.

### Recommended CMP Platforms

Google maintains a list of certified CMPs for integration with Consent Mode:
- Cookiebot, OneTrust, Didomi, Usercentrics, CookieYes, Quantcast
- Full list: `support.google.com/google-ads/answer/13554116`

---

## Value-Based Bidding with Customer Data

### Conversion Value Rules

Conversion Value Rules let you adjust conversion values dynamically at auction time
based on audience, location, or device — without modifying your conversion uploads.

**Use cases**: Different product margins by region, higher value for logged-in users,
LTV adjustments by customer segment, mobile vs desktop value differences.

```python
def create_conversion_value_rule(client, customer_id, name, audience_rn=None,
                                  geo_target_constant=None, device_type=None,
                                  value_multiplier=None, value_addition=None):
    """
    Create a conversion value rule that adjusts values at auction time.
    
    Exactly one of value_multiplier or value_addition should be set.
    At least one condition (audience, geo, device) must be set.
    """
    service = client.get_service("ConversionValueRuleService")
    op = client.get_type("ConversionValueRuleOperation")
    rule = op.create
    rule.name = name
    rule.status = client.enums.ConversionValueRuleStatusEnum.ENABLED
    
    # Action: multiply or add to conversion value
    if value_multiplier:
        rule.action.operation = client.enums.ValueRuleOperationEnum.MULTIPLY
        rule.action.value = value_multiplier  # e.g., 1.5 = 50% increase
    elif value_addition:
        rule.action.operation = client.enums.ValueRuleOperationEnum.ADD
        rule.action.value = value_addition  # e.g., 50.0 = add $50
    
    # Conditions (at least one required)
    if audience_rn:
        audience_condition = rule.audience_condition
        audience_condition.user_lists.append(audience_rn)
    
    if geo_target_constant:
        geo_condition = rule.geo_location_condition
        geo_condition.geo_target_constants.append(geo_target_constant)
    
    if device_type:
        rule.device_condition.device_types.append(
            getattr(client.enums.ValueRuleDeviceTypeEnum, device_type))
    
    # Which campaigns use this rule
    rule.owner_customer = f"customers/{customer_id}"
    
    response = service.mutate_conversion_value_rules(
        customer_id=customer_id, operations=[op])
    return response.results[0].resource_name
```

### Conversion Value Rule Sets (Apply Rules to Campaigns)

```python
def create_conversion_value_rule_set(client, customer_id, campaign_id,
                                      rule_resource_names, dimensions):
    """
    Create a rule set that applies value rules to a campaign.
    
    dimensions: list of dimensions the rules apply to, e.g.,
      ["GEO_LOCATION", "DEVICE", "AUDIENCE"]
    """
    service = client.get_service("ConversionValueRuleSetService")
    op = client.get_type("ConversionValueRuleSetOperation")
    rule_set = op.create
    rule_set.campaign = f"customers/{customer_id}/campaigns/{campaign_id}"
    rule_set.status = client.enums.ConversionValueRuleSetStatusEnum.ENABLED
    rule_set.attachment_type = (
        client.enums.ValueRuleSetAttachmentTypeEnum.CAMPAIGN)
    
    for rn in rule_resource_names:
        rule_set.conversion_value_rules.append(rn)
    
    for dim in dimensions:
        rule_set.dimensions.append(
            getattr(client.enums.ValueRuleSetDimensionEnum, dim))
    
    response = service.mutate_conversion_value_rule_sets(
        customer_id=customer_id, operations=[op])
    return response.results[0].resource_name
```

### Strategic Value Rule Examples

```python
# 1. High-LTV customers worth 2x more
create_conversion_value_rule(client, cid,
    name="High LTV 2x",
    audience_rn="customers/{cid}/userLists/{high_ltv_list_id}",
    value_multiplier=2.0)

# 2. Spanish market 30% lower margin
create_conversion_value_rule(client, cid,
    name="Spain Lower Margin",
    geo_target_constant="geoTargetConstants/2724",  # Spain
    value_multiplier=0.7)

# 3. Mobile conversions worth $20 less (higher return rates)
create_conversion_value_rule(client, cid,
    name="Mobile Discount",
    device_type="MOBILE",
    value_addition=-20.0)

# 4. Existing customers worth $50 extra (upsell potential)
create_conversion_value_rule(client, cid,
    name="Existing Customer Upsell",
    audience_rn="customers/{cid}/userLists/{existing_customers_list_id}",
    value_addition=50.0)
```

### Profit-Based Bidding Strategy

Instead of optimizing for revenue, optimize for profit margin:

**Option A: Pass profit as conversion value** (simplest)
- Instead of uploading order revenue ($100), upload profit margin ($30)
- Smart Bidding then optimizes for total profit, not total revenue
- Target ROAS becomes "target return on ad spend in profit terms"

**Option B: Use Conversion Value Rules by product category**
- Segment products by margin tier (high margin, medium, low)
- Create Customer Match lists per product category buyer
- Apply value rules: high-margin buyers get 1.5x multiplier

**Option C: Feed-level margins for Shopping**
- Add `custom_label_0` to Shopping feed with margin tier
- Use campaign-level subdivision to bid differently per margin tier

### LTV as Conversion Signal

The most powerful value-based bidding strategy feeds predicted LTV into Smart Bidding:

**Step 1**: Calculate predicted LTV per customer segment
**Step 2**: At acquisition, upload the predicted LTV as conversion value
**Step 3**: Use Conversion Adjustments (restatements) to update values as actual LTV emerges
**Step 4**: Smart Bidding learns the correlation between user signals and LTV, improving over time

```python
# Step 2: Upload with predicted LTV
upload_enhanced_conversion_for_leads(client, cid, conv_action_id,
    conversion_time="2026-02-01 10:00:00-05:00",
    conversion_value=850.0,  # Predicted 12-month LTV
    user_data={"email": "lead@example.com"})

# Step 3: Update 60 days later with actual realized value
# (See Conversion Adjustments section below)
```

---

## Customer Lifecycle Goals

### Customer Acquisition Goals

Tell Smart Bidding to value new customers more than returning ones. Configured at account
level, optionally overridden per campaign.

```python
def configure_customer_acquisition_goal(client, customer_id, 
                                         new_customer_value=50.0,
                                         high_ltv_value=100.0,
                                         existing_customer_list_rn=None):
    """
    Configure account-level customer acquisition goal.
    
    new_customer_value: extra value (in account currency) for each new customer
    high_ltv_value: extra value for new customers predicted to be high-LTV
    """
    # Step 1: Label existing customer lists
    if existing_customer_list_rn:
        ulct_service = client.get_service("UserListCustomerTypeService")
        ulct_op = client.get_type("UserListCustomerTypeOperation")
        ulct = ulct_op.create
        ulct.user_list = existing_customer_list_rn
        ulct.customer_type_category = (
            client.enums.UserListCustomerTypeCategoryEnum.PURCHASERS)
        ulct_service.mutate_user_list_customer_types(
            customer_id=customer_id, operations=[ulct_op])
        print(f"Labeled {existing_customer_list_rn} as PURCHASERS")
    
    # Step 2: Configure the lifecycle goal
    lifecycle_service = client.get_service("CustomerLifecycleGoalService")
    goal_op = client.get_type("CustomerLifecycleGoalOperation")
    goal = goal_op.create
    
    # Set acquisition values
    goal.customer_acquisition_goal_value_settings.value = new_customer_value
    goal.customer_acquisition_goal_value_settings.high_lifetime_value = high_ltv_value
    
    response = lifecycle_service.mutate_customer_lifecycle_goals(
        customer_id=customer_id, operation=goal_op)
    print(f"Lifecycle goal configured: +${new_customer_value} per new customer, "
          f"+${high_ltv_value} per high-LTV new customer")
    return response
```

### Campaign-Level Acquisition Goal Override

```python
def set_campaign_acquisition_goal(client, customer_id, campaign_id,
                                   optimization_mode="TARGET_AND_BID"):
    """
    Override acquisition goal at campaign level.
    
    optimization_mode:
      "BID_HIGHER" — bid more for new customers but still target existing ones
      "TARGET_AND_BID" — target ONLY new customers (pure prospecting)
    """
    campaign_service = client.get_service("CampaignService")
    campaign_op = client.get_type("CampaignOperation")
    campaign = campaign_op.update
    campaign.resource_name = f"customers/{customer_id}/campaigns/{campaign_id}"
    
    acq = campaign.customer_acquisition_goal_settings
    acq.optimization_mode = getattr(
        client.enums.CustomerAcquisitionOptimizationModeEnum, optimization_mode)
    
    from google.api_core import protobuf_helpers
    client.copy_from(campaign_op.update_mask,
                     protobuf_helpers.field_mask(None, campaign._pb))
    campaign_service.mutate_campaigns(
        customer_id=customer_id, operations=[campaign_op])
```

### Retention Goals (PMax Only)

```python
def configure_retention_goal(client, customer_id, churned_value=30.0):
    """
    Configure retention goals for Performance Max campaigns.
    Bids higher for lapsed customers to win them back.
    """
    goal_service = client.get_service("GoalService")
    # Retention goals are configured alongside acquisition goals
    # They optimize PMax to re-engage customers at risk of churning
    # The churned_value represents the additional value of retaining a customer
    pass  # GoalService API for retention is still being finalized in v23
```

### UserListCustomerType Categories

| Category | Use For |
|----------|---------|
| `PURCHASERS` | Anyone who has ever purchased |
| `HIGH_VALUE_CUSTOMERS` | Top-tier LTV customers |
| `DISENGAGED_CUSTOMERS` | Customers at risk of churn |
| `QUALIFIED_LEADS` | Leads that passed qualification |
| `CONVERTED_LEADS` | Leads that became customers |
| `CART_ABANDONERS` | Added to cart but didn't purchase |
| `LOYALTY_SIGN_UPS` | Joined loyalty program |

```python
# Label multiple lists with their types
labels = [
    (high_ltv_list_rn, "HIGH_VALUE_CUSTOMERS"),
    (all_purchasers_list_rn, "PURCHASERS"),
    (churning_list_rn, "DISENGAGED_CUSTOMERS"),
]
for list_rn, category in labels:
    ulct_op = client.get_type("UserListCustomerTypeOperation")
    ulct = ulct_op.create
    ulct.user_list = list_rn
    ulct.customer_type_category = getattr(
        client.enums.UserListCustomerTypeCategoryEnum, category)
    ulct_service.mutate_user_list_customer_types(
        customer_id=customer_id, operations=[ulct_op])
```

---

## Customer Match Master Strategy

### Segmentation Framework

The power of Customer Match isn't just uploading a list — it's **strategic segmentation**
that feeds into bidding, targeting, and exclusion strategies.

**RFM Segmentation (Recency, Frequency, Monetary):**

| Segment | Definition | Use in Google Ads |
|---------|-----------|-------------------|
| Champions | Recent, frequent, high spend | Lookalike seed, exclude from acquisition |
| Loyal Customers | Frequent buyers | Cross-sell campaigns, upsell |
| Potential Loyalists | Recent, mid-frequency | Nurture with brand campaigns |
| At Risk | Were frequent, now declining | Win-back campaigns, higher bids |
| Hibernating | Long absence, formerly active | Aggressive win-back, seasonal re-engagement |
| New Customers | Recent first purchase | Retention campaigns, onboarding |
| Lost | Very old, one-time | Low-bid or exclude |

**Implementation**: Create one Customer Match list per segment. Update lists every 24-48 hours
via Data Manager API or Google Ads API (OfflineUserDataJobService).

### Strategic Use Cases

**1. Pure Prospecting (New Customer Only)**
```
Campaign: Search — Brand Terms Excluded
Audiences: EXCLUDE all Customer Match lists (all purchasers)
Result: Every click is a genuinely new customer
```

**2. Upsell / Cross-Sell**
```
Campaign: Search/PMax — Product Category B
Audiences: TARGET Customer Match list of Product A buyers
Exclusion: Exclude Product B buyers
Result: Show Product B only to customers who bought A but not B
```

**3. Win-Back**
```
Campaign: Search/Display — Discount Offers
Audiences: TARGET "At Risk" + "Hibernating" Customer Match lists
Bidding: Value Rule +30% for these audiences
Result: Re-engage lapsed customers with incentive
```

**4. Lookalike Expansion from Best Customers**
```
Seed: Customer Match list of top 20% by LTV (Champions)
Platform: Google finds similar users in its network
Campaign: PMax/Display/Demand Gen
Result: Prospect pool that resembles your best customers
Min size: 1,000 matched users in seed list
```

**5. Exclusion of Pipeline Leads**
```
Campaign: All lead generation campaigns
Audiences: EXCLUDE Customer Match list of "in pipeline" leads
Update: Real-time via CRM webhook → API upload
Result: Stop paying for clicks from people already in your sales pipeline
```

**6. Tiered Bidding by Value**
```
Lists: High-LTV, Medium-LTV, Low-LTV Customer Match lists
Value Rules: High=2x, Medium=1x, Low=0.5x multiplier
Bidding: Maximize Conversion Value with tROAS
Result: Smart Bidding automatically bids more for high-value user patterns
```

**7. Seasonal Re-Engagement**
```
List: Customers who purchased during Black Friday last year
Campaign: Start targeting 6 weeks before this year's Black Friday
Creative: "You loved [product] last year — see what's new"
Result: Early engagement with proven seasonal buyers
```

### Automated Sync Architecture

```
CRM (Salesforce/HubSpot)
    ↓ Webhook on status change
Application Server
    ↓ Hashes PII, routes to correct list
Google Ads API (OfflineUserDataJobService) OR Data Manager API
    ↓ Updates Customer Match lists
Google Ads
    ↓ Smart Bidding uses audience signals
Ad Auctions
```

**Refresh cadence**: Update Customer Match lists every 24-48 hours minimum.
Lists that haven't been refreshed in 90 days lose effectiveness.

### Audience Size Requirements

- Minimum **1,000 matched users** to serve ads
- Recommended **5,000+** for stable performance
- For lookalike audiences, **10,000+** in seed list recommended
- Upload more records than you need matched — match rate is typically 30-60%
  (70-90% with enhanced matching via multiple identifiers)
- Check actual matched size in Google Ads UI → Audience Manager

---

## Conversion Adjustments

### Overview

Conversion Adjustments let you update or retract conversions after the original upload.
Critical for accurate value-based bidding.

**Types:**
- **RESTATEMENT**: Change the conversion value (e.g., lead scored higher, partial refund)
- **RETRACTION**: Remove the conversion entirely (e.g., full refund, cancelled order, fraud)

### Restatement: Update Conversion Value

```python
def restate_conversion_value(client, customer_id, conversion_action_id,
                              gclid, original_conversion_time,
                              new_value, adjustment_time=None):
    """
    Update the value of a previously uploaded conversion.
    
    Use cases: lead scoring update, partial refund, LTV revision
    """
    service = client.get_service("ConversionAdjustmentUploadService")
    adjustment = client.get_type("ConversionAdjustment")
    
    adjustment.conversion_action = client.get_service(
        "ConversionActionService").conversion_action_path(
        customer_id, conversion_action_id)
    adjustment.adjustment_type = (
        client.enums.ConversionAdjustmentTypeEnum.RESTATEMENT)
    
    # Identify the original conversion
    adjustment.gclid_date_time_pair.gclid = gclid
    adjustment.gclid_date_time_pair.conversion_date_time = original_conversion_time
    
    # New value
    adjustment.restatement_value.adjusted_value = new_value
    adjustment.restatement_value.currency_code = "USD"
    
    # When the adjustment happened
    if adjustment_time:
        adjustment.adjustment_date_time = adjustment_time
    
    response = service.upload_conversion_adjustments(
        customer_id=customer_id,
        conversion_adjustments=[adjustment],
        partial_failure=True)
    
    if response.partial_failure_error:
        print(f"Error: {response.partial_failure_error.message}")
    else:
        print(f"Restated conversion to ${new_value}")
    return response
```

### Retraction: Remove a Conversion

```python
def retract_conversion(client, customer_id, conversion_action_id,
                        gclid, original_conversion_time, adjustment_time=None):
    """
    Remove a previously uploaded conversion entirely.
    
    Use cases: full refund, cancelled order, fraudulent transaction
    """
    service = client.get_service("ConversionAdjustmentUploadService")
    adjustment = client.get_type("ConversionAdjustment")
    
    adjustment.conversion_action = client.get_service(
        "ConversionActionService").conversion_action_path(
        customer_id, conversion_action_id)
    adjustment.adjustment_type = (
        client.enums.ConversionAdjustmentTypeEnum.RETRACTION)
    
    adjustment.gclid_date_time_pair.gclid = gclid
    adjustment.gclid_date_time_pair.conversion_date_time = original_conversion_time
    
    if adjustment_time:
        adjustment.adjustment_date_time = adjustment_time
    
    response = service.upload_conversion_adjustments(
        customer_id=customer_id,
        conversion_adjustments=[adjustment],
        partial_failure=True)
    
    if response.partial_failure_error:
        print(f"Error: {response.partial_failure_error.message}")
    else:
        print("Conversion retracted successfully")
    return response
```

### Batch Adjustments

```python
def batch_adjust_conversions(client, customer_id, adjustments_data):
    """
    Batch process conversion adjustments.
    
    adjustments_data: list of dicts with keys:
      conversion_action_id, gclid, original_conversion_time,
      adjustment_type ("RESTATEMENT" or "RETRACTION"),
      new_value (for restatements), currency_code, adjustment_time
    """
    service = client.get_service("ConversionAdjustmentUploadService")
    adjustments = []
    
    for adj in adjustments_data:
        adjustment = client.get_type("ConversionAdjustment")
        adjustment.conversion_action = client.get_service(
            "ConversionActionService").conversion_action_path(
            customer_id, adj["conversion_action_id"])
        adjustment.adjustment_type = getattr(
            client.enums.ConversionAdjustmentTypeEnum, adj["adjustment_type"])
        adjustment.gclid_date_time_pair.gclid = adj["gclid"]
        adjustment.gclid_date_time_pair.conversion_date_time = adj["original_conversion_time"]
        
        if adj["adjustment_type"] == "RESTATEMENT":
            adjustment.restatement_value.adjusted_value = adj["new_value"]
            adjustment.restatement_value.currency_code = adj.get("currency_code", "USD")
        
        if "adjustment_time" in adj:
            adjustment.adjustment_date_time = adj["adjustment_time"]
        
        adjustments.append(adjustment)
    
    # Upload in chunks (max 2,000 per request)
    CHUNK = 2000
    for i in range(0, len(adjustments), CHUNK):
        chunk = adjustments[i:i+CHUNK]
        response = service.upload_conversion_adjustments(
            customer_id=customer_id,
            conversion_adjustments=chunk,
            partial_failure=True)
        
        if response.partial_failure_error:
            print(f"Chunk {i//CHUNK}: partial failures: "
                  f"{response.partial_failure_error.message}")
        else:
            print(f"Chunk {i//CHUNK}: {len(chunk)} adjustments succeeded")
```

### Enhanced Conversion Adjustments (Without GCLID)

For Enhanced Conversions for Leads (where you may not have a GCLID), you can use
`order_id` to identify the conversion to adjust:

```python
adjustment.order_id = "ORDER-12345"
# Instead of gclid_date_time_pair
```

### Key Rules

- Adjustments must be uploaded within **55 days** of the original conversion
- Multiple restatements are allowed — each replaces the previous value
- Retractions are final — cannot be un-retracted
- Adjustments affect Smart Bidding learning retroactively
- Allow 24-48 hours for adjustments to reflect in reporting
- Use `partial_failure=True` always — one bad record shouldn't fail the batch

---

## Server-Side Tracking Infrastructure

### Why Server-Side Tagging Matters

Client-side pixel tracking is increasingly unreliable:
- Safari ITP: JS-set cookies expire in 7 days (24h with link decoration)
- Firefox: blocks third-party cookies entirely
- Ad blockers: block pixels in 30%+ of users
- Chrome Privacy Sandbox: reduces cross-site tracking capability

**Server-side tagging** (via Google Tag Gateway or sGTM) solves this by setting cookies
from your own first-party domain's server, extending cookie life to 1+ year and bypassing
client-side blocking.

### Architecture

```
User Browser
    → Your website (client-side gtag/GTM container)
        → Your server-side GTM container (sGTM) on YOUR domain
            → Google Ads (conversion data)
            → GA4 (analytics data)
            → Meta CAPI (if needed)
            → Other destinations
```

### Benefits

| Benefit | Impact |
|---------|--------|
| Extended cookie lifetime | 7 days → 1+ year on Safari |
| Ad blocker bypass | Recover 30%+ lost conversions |
| Better Enhanced Conversions | More data reaches Google |
| Improved Smart Bidding signals | Better auction-time optimization |
| Data control | Filter/enrich data before sending to Google |
| Reduced page weight | Move tags server-side for faster pages |

### Google Tag Gateway

Simpler alternative to full sGTM setup. Managed by Google, deployed on your domain.
Sets first-party cookies from your subdomain (e.g., `tags.yourdomain.com`).

### AW-tag (2026)

The **AW-tag** is Google's new conversion tracking tag that replaces the Conversion Linker.
It's designed for server-side environments and provides improved conversion attribution in
cookieless contexts. Use alongside Enhanced Conversions for maximum signal recovery.

### Implementation Priority

For most advertisers, the priority order is:
1. Enhanced Conversions (biggest bang for buck, no infrastructure needed)
2. Consent Mode V2 Advanced (recovers modeled conversions)
3. Server-side tagging (infrastructure investment but long-term critical)

---

## Implementation Roadmap

### Week 1-2: Foundation

1. **Audit current conversion tracking**: What's using GCLID-only? What's missing?
2. **Implement Enhanced Conversions for Web**: Add hashed user data to existing tag
3. **Set up Consent Mode V2 Advanced**: Configure default denied + CMP integration
4. **Create conversion action for Enhanced Conversions for Leads**: If doing lead gen

### Week 3-4: Customer Data

5. **Build Customer Match lists**: Segment by RFM/LTV (minimum 5 lists)
6. **Upload initial Customer Match data**: Via Google Ads API or Data Manager
7. **Configure Conversion Value Rules**: At least margin-based adjustments
8. **Set up Customer Acquisition Goal**: Label existing customer lists, set values

### Month 2: Optimization

9. **Implement Conversion Adjustments**: Start feeding back refunds and lead score updates
10. **Activate LTV-based bidding**: Use predicted LTV as conversion value
11. **Configure Lifecycle Goals**: Acquisition goals on Search/PMax, retention on PMax
12. **Automate Customer Match refresh**: Set up 24-48h sync cadence

### Month 3: Scale

13. **Migrate to Data Manager API**: For automated warehouse/CRM syncs
14. **Implement server-side tagging**: Deploy sGTM or Google Tag Gateway
15. **Build cross-channel attribution**: Connect offline + online conversion data
16. **Optimize value rules**: A/B test different value multipliers

---

## Cross-Skill Integration: Talent Academy backend → Data Manager API

This is the worked example referenced from `SKILL.md` (`## Cross-Skill Integration`). It shows how
the Talent Academy platform (Next.js App Router + Supabase) reports a server-side conversion — a
completed sale — to Google Ads through the **Data Manager API**, which is the mandated path for new
integrations (see the gating table under *Data Manager API* above; direct `ConversionUploadService`
is allowlist-gated with `CUSTOMER_NOT_ALLOWLISTED_FOR_THIS_FEATURE` since Jun 15, 2026).

**Architecture (silo-safe, multi-tenant):**

```
sale completed (webhook / RPC)
        │
        ▼
Server Action  (Supabase user-context, RLS)   ── loads sale + hashed identifiers, checks consent,
        │                                         propagates programId (not a resolved credential)
        │  POST (internal, server-only auth)
        ▼
Conversion collector  (server-only route)      ── owns the Data Manager API OAuth token, resolves
        │  Data Manager API : events.ingest        per-tenant customerId/conversionActionId at point of use
        ▼
Google Ads  →  Smart Bidding signal
```

The collector resolves the tenant's `customerId`/`conversionActionId` **at the point of use** via
`resolveGoogleAdsConfig(programId)` — the same pattern as `resolveLLMKey(vendor, programId)` in
`src/lib/llm/index.ts` (`server-only`, backed by `createAdminClient().rpc(...)`, called
independently by whichever layer needs it rather than trusting a value forwarded across the trust
boundary — see e.g. `src/app/api/chatbot/stream/route.ts`). The Server Action only propagates the
non-secret `programId`; it never resolves or forwards Ads IDs itself. A tenant with no Ads config
fails closed — the collector rejects the upload, it never falls back to another tenant's account or
to a global env var. A second tenant works by data + provisioning (CLAUDE.md rule 25). The Data
Manager API OAuth token lives server-only (rule 18 / 25d), never in tenant-editable config.

```ts
// src/lib/google-ads/index.ts (sketch — mirrors resolveLLMKey in src/lib/llm/index.ts)
import "server-only"
import { createAdminClient } from "@/lib/supabase/admin"

export async function resolveGoogleAdsConfig(
  programId?: string | null,
): Promise<{ customerId: string; conversionActionId: string } | null> {
  const admin = createAdminClient()
  const { data } = await admin.rpc("get_google_ads_program_config", {
    p_program_id: programId ?? null, // null = global default row, same convention as resolveLLMKey
  })
  return data ?? null // no config for this tenant → caller must fail closed, never fall back
}
```

**1) Server Action — collect + gate, then hand off to the collector:**

```ts
// src/app/[locale]/(admin)/admin/ventas/_actions/report-conversion.ts
"use server"

import { createClient } from "@/lib/supabase/server"
import { createHash } from "node:crypto"

const normalizeEmail = (email: string) => email.trim().toLowerCase()
const sha256 = (value: string) =>
  createHash("sha256").update(value).digest("hex")

export async function reportConversion(
  saleId: string,
): Promise<{ ok: true } | { ok: false; message: string }> {
  const supabase = await createClient()

  // 1. Load the sale under RLS (user-context client — never the admin/service-role client here).
  const { data: sale, error } = await supabase
    .from("sales")
    .select("id, program_id, email, gross_amount, currency, marketing_consent, completed_at")
    .eq("id", saleId)
    .single()

  if (error || !sale) return { ok: false, message: "sale_not_found" }

  // 2. Consent gate — no consent, no upload (Consent Mode V2 / privacy contract).
  if (!sale.marketing_consent) return { ok: false, message: "no_consent" }

  // 3. Hash PII BEFORE it leaves the process (Data Manager API expects hashed identifiers).
  const payload = {
    saleId: sale.id,
    programId: sale.program_id, // non-secret; the collector re-resolves per-tenant Ads config from this
    hashedEmail: sha256(normalizeEmail(sale.email)),
    value: sale.gross_amount,
    currency: sale.currency,
    occurredAt: sale.completed_at,
    marketingConsent: sale.marketing_consent, // reflected downstream, never re-assumed by the collector
  }

  // 4. Hand off to the server-only collector that holds the Data Manager API credentials.
  const res = await fetch(`${process.env.INTERNAL_BASE_URL}/api/internal/conversion-upload`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${process.env.INTERNAL_SERVICE_TOKEN}`, // server-only
    },
    body: JSON.stringify(payload),
  })

  if (!res.ok) return { ok: false, message: "upload_failed" }
  return { ok: true }
}
```

**2) Collector — the only place that talks to the Data Manager API:**

```ts
// src/app/api/internal/conversion-upload/route.ts  (server-only; internal token auth)
import { NextResponse } from "next/server"
import { getDataManagerAccessToken } from "@/lib/ads/data-manager-auth" // OAuth token, server-only
import { resolveGoogleAdsConfig } from "@/lib/google-ads" // per-tenant customerId/conversionActionId

export async function POST(req: Request) {
  // Fail closed if the internal service token isn't configured — never compare against the literal
  // string "Bearer undefined" (see the auth gotcha table above).
  const token = process.env.INTERNAL_SERVICE_TOKEN
  if (!token) {
    return NextResponse.json({ ok: false }, { status: 500 })
  }
  if (req.headers.get("authorization") !== `Bearer ${token}`) {
    return NextResponse.json({ ok: false }, { status: 401 })
  }

  const { programId, saleId, hashedEmail, value, currency, occurredAt, marketingConsent } =
    await req.json()

  // Strict boolean check on untrusted JSON input — truthiness lets a stray "false" (string) or
  // 1 through as consent GRANTED via the ternary below; only a literal boolean is accepted.
  if (typeof marketingConsent !== "boolean") {
    return NextResponse.json({ ok: false, message: "invalid_consent_signal" }, { status: 400 })
  }

  // Resolve THIS tenant's Google Ads IDs here, not from a global process.env — a second tenant
  // must work by data + provisioning alone (CLAUDE.md rule 25).
  const adsConfig = await resolveGoogleAdsConfig(programId)
  if (!adsConfig) {
    return NextResponse.json({ ok: false, message: "no_ads_config_for_tenant" }, { status: 422 })
  }
  const { customerId, conversionActionId } = adsConfig

  const accessToken = await getDataManagerAccessToken()

  // Data Manager API : ingest a conversion event with hashed user data + explicit consent.
  const resp = await fetch("https://datamanager.googleapis.com/v1/events:ingest", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      destinations: [{
        operatingAccount: { accountType: "GOOGLE_ADS", accountId: customerId },
        productDestinationId: conversionActionId,
      }],
      consent: {
        // Reflects the consent signal received from the Server Action — never assumed GRANTED here.
        adUserData: marketingConsent ? "CONSENT_GRANTED" : "CONSENT_DENIED",
        adPersonalization: marketingConsent ? "CONSENT_GRANTED" : "CONSENT_DENIED",
      },
      encoding: "HEX",
      events: [{
        eventTimestamp: occurredAt,
        transactionId: saleId,
        conversionValue: value,
        currency,
        eventSource: "WEB",
        userData: { userIdentifiers: [{ emailAddress: hashedEmail }] }, // already SHA-256 hashed
      }],
    }),
  })

  if (!resp.ok) return NextResponse.json({ ok: false }, { status: 502 })
  return NextResponse.json({ ok: true })
}
```

> The exact request shape of `events:ingest` — `destinations[].operatingAccount` (`accountType` +
> `accountId`) and `productDestinationId`, the flat per-event fields (`eventTimestamp`,
> `transactionId`, `conversionValue`, `currency`, `eventSource`, `userData`), the top-level `consent`
> object (`adUserData`/`adPersonalization`, enum `CONSENT_GRANTED`/`CONSENT_DENIED` — distinct from
> `ConsentStatusEnum` in the classic Google Ads API used by `google_ads_helper.py`), and `encoding:
> "HEX"` for hashed identifiers — is verified against the Data Manager API `v1` reference
> (`developers.google.com/data-manager/api/reference/rest/v1/events/ingest`, `.../Destination`,
> `.../Consent`, and the `devguides/events/send-events` guide; `last_verified: 2026-07-18`). Re-verify
> before shipping — this surface can change. The pattern — **Server Action gates + hashes +
> propagates `programId`/consent → server-only collector resolves per-tenant Ads config + credentials
> → Data Manager API** — is the stable, tenant-safe part.
