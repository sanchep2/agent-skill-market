# GAQL (Google Ads Query Language) Reference

## Table of Contents
1. [Syntax Structure](#syntax-structure)
2. [Operators](#operators)
3. [Date Handling](#date-handling)
   - [37-Month Lookback Limit on Date Segments](#37-month-lookback-limit-on-date-segments)
4. [Field Types & Compatibility](#field-types--compatibility)
5. [Query Library — 30+ Production Examples](#query-library)
6. [Common Mistakes](#common-mistakes)
7. [Interactive Query Builder](#interactive-query-builder)

---

## Syntax Structure

```sql
SELECT field1, field2, ...
FROM resource
WHERE condition AND condition
ORDER BY field ASC|DESC
LIMIT n
PARAMETERS key = value
```

Only `SELECT` and `FROM` are required. `WHERE` only supports `AND` — no `OR`.
For OR logic, run separate queries.

**Resources** are the `FROM` target: `campaign`, `ad_group`, `ad_group_ad`, `keyword_view`,
`search_term_view`, `customer`, `ad_group_criterion`, `campaign_criterion`,
`campaign_budget`, `bidding_strategy`, `change_event`, `change_status`,
`geographic_view`, `gender_view`, `age_range_view`, `audience_view`, `asset`,
`asset_group`, `asset_group_listing_group_filter`, `shopping_performance_view`,
`product_group_view`, `conversion_action`, `customer_client`, `label`, etc.

---

## Operators

| Operator | Example | Notes |
|----------|---------|-------|
| `=` | `campaign.status = 'ENABLED'` | Exact match |
| `!=` | `campaign.status != 'REMOVED'` | Not equal |
| `>`, `<`, `>=`, `<=` | `metrics.clicks > 100` | Numeric/date comparison |
| `IN` | `campaign.status IN ('ENABLED', 'PAUSED')` | Multiple values |
| `NOT IN` | `campaign.status NOT IN ('REMOVED')` | Exclude multiple |
| `LIKE` | `campaign.name LIKE '%Brand%'` | Wildcard match (% = any chars) |
| `NOT LIKE` | `campaign.name NOT LIKE '%Test%'` | Exclude pattern |
| `BETWEEN` | `segments.date BETWEEN '2025-01-01' AND '2025-12-31'` | Inclusive range |
| `DURING` | `segments.date DURING LAST_30_DAYS` | Predefined date ranges |
| `REGEXP_MATCH` | `campaign.name REGEXP_MATCH '.*brand.*'` | Regex (RE2 syntax) |
| `NOT REGEXP_MATCH` | `campaign.name NOT REGEXP_MATCH '.*test.*'` | Negative regex |
| `IS NULL` | `ad_group_criterion.quality_info.quality_score IS NULL` | Null check |
| `IS NOT NULL` | `ad_group_criterion.quality_info.quality_score IS NOT NULL` | Not null |
| `CONTAINS ANY` | `campaign.labels CONTAINS ANY ('customers/123/labels/456')` | Array contains any |
| `CONTAINS ALL` | `campaign.labels CONTAINS ALL (...)` | Array contains all |
| `CONTAINS NONE` | `campaign.labels CONTAINS NONE (...)` | Array contains none |

---

## Date Handling

### Predefined Date Ranges (DURING)

```sql
DURING TODAY
DURING YESTERDAY
DURING LAST_7_DAYS
DURING LAST_14_DAYS
DURING LAST_30_DAYS
DURING LAST_BUSINESS_WEEK     -- Mon-Fri of last week
DURING THIS_WEEK_SUN_TODAY    -- Current week starting Sunday
DURING THIS_WEEK_MON_TODAY    -- Current week starting Monday
DURING LAST_WEEK_SUN_SAT     -- Last full week Sun-Sat
DURING LAST_WEEK_MON_SUN     -- Last full week Mon-Sun
DURING THIS_MONTH
DURING LAST_MONTH
```

### Custom Date Ranges (BETWEEN)

```sql
WHERE segments.date BETWEEN '2025-01-01' AND '2025-06-30'
```

### Critical Rule

If `segments.date` (or `.week`, `.month`, `.quarter`, `.year`) appears in `SELECT`,
a finite date range MUST be in `WHERE`. Without this, the query fails with
`DATE_RANGE_TOO_WIDE`.

```sql
-- VALID: date in SELECT, date range in WHERE
SELECT campaign.name, segments.date, metrics.clicks
FROM campaign WHERE segments.date DURING LAST_7_DAYS

-- INVALID: date in SELECT, no date range
SELECT campaign.name, segments.date, metrics.clicks
FROM campaign WHERE campaign.status = 'ENABLED'  -- ERROR!

-- VALID: no date segment in SELECT, no date range needed
SELECT campaign.name, metrics.clicks
FROM campaign WHERE campaign.status = 'ENABLED'  -- OK (lifetime metrics)
```

### 37-Month Lookback Limit on Date Segments

Since **June 1, 2026**, Google Ads caps the lookback window for **daily-granularity** date segments
(`segments.date`, `segments.week`) at **37 months**. A query that requests day/week rows older than
37 months from today is rejected (last_verified: 2026-07-17):

- **v24+** — error `DateRangeError.REQUESTED_DATE_GRANULARITY_NOT_SUPPORTED`
  (surfaced in the v24.1 release notes).
- **Earlier versions** — the same request tends to fail with `INVALID_DATE` / `DATE_RANGE_TOO_WIDE`.

```sql
-- REJECTED in mid-2026: daily rows older than 37 months
SELECT campaign.name, segments.date, metrics.clicks
FROM campaign WHERE segments.date BETWEEN '2021-01-01' AND '2021-12-31'
-- ERROR: REQUESTED_DATE_GRANULARITY_NOT_SUPPORTED (v24+)

-- FALLBACK: for older history, coarsen the granularity — monthly/quarterly/yearly
-- segments are NOT subject to the 37-month cap.
SELECT campaign.name, segments.month, metrics.clicks
FROM campaign WHERE segments.date BETWEEN '2021-01-01' AND '2021-12-31'  -- OK
```

**Rule of thumb**: need rows older than ~3 years? Query `segments.month`, `segments.quarter`, or
`segments.year` instead of `segments.date`/`segments.week`. For long-term retention of daily data,
export it to your own warehouse (e.g. BigQuery Data Transfer) before it ages past the window.

> Source: Google Ads API release notes / date-range documentation
> (`developers.google.com/google-ads/api/docs/release-notes`). Re-confirm the exact error enum for
> your pinned API version before relying on it programmatically.

---

## Field Types & Compatibility

Fields come in three types:

| Type | Example | Behavior |
|------|---------|----------|
| **Resource attributes** | `campaign.name`, `ad_group.id` | Properties of the entity |
| **Segments** | `segments.date`, `segments.device` | Break down metrics by dimension |
| **Metrics** | `metrics.clicks`, `metrics.impressions` | Aggregated performance data |

Not all segments and metrics are compatible with every resource. The official
**Query Builder** validates compatibility:
`developers.google.com/google-ads/api/fields/v24/campaign_query_builder`

### Key compatibility rules

- `segments.date` works with most resources that have metrics
- `segments.device` cannot combine with `segments.slot` in some resources
- Some metrics are only available on specific resources (e.g., `metrics.search_impression_share` only on `campaign` and `ad_group`)
- `segments.conversion_action` enables per-action conversion breakdowns but restricts which other segments can appear

---

## Query Library

### Campaign Performance

```sql
-- Basic campaign metrics
SELECT campaign.id, campaign.name, campaign.status,
       campaign.advertising_channel_type, campaign.bidding_strategy_type,
       metrics.impressions, metrics.clicks, metrics.ctr,
       metrics.average_cpc, metrics.cost_micros,
       metrics.conversions, metrics.cost_per_conversion
FROM campaign
WHERE campaign.status != 'REMOVED'
  AND segments.date DURING LAST_30_DAYS
ORDER BY metrics.cost_micros DESC

-- Campaign by device
SELECT campaign.name, segments.device,
       metrics.impressions, metrics.clicks, metrics.cost_micros, metrics.conversions
FROM campaign
WHERE segments.date DURING LAST_30_DAYS AND campaign.status = 'ENABLED'

-- Campaign by day
SELECT campaign.name, segments.date,
       metrics.impressions, metrics.clicks, metrics.cost_micros, metrics.conversions
FROM campaign
WHERE segments.date DURING LAST_30_DAYS AND campaign.status = 'ENABLED'
ORDER BY segments.date DESC

-- Campaign budget info
SELECT campaign.name, campaign.status,
       campaign_budget.amount_micros, campaign_budget.total_amount_micros,
       campaign_budget.status, campaign_budget.delivery_method,
       metrics.cost_micros
FROM campaign
WHERE campaign.status = 'ENABLED' AND segments.date DURING LAST_30_DAYS
```

### Ad Group Performance

```sql
SELECT ad_group.id, ad_group.name, ad_group.status,
       campaign.name,
       metrics.impressions, metrics.clicks, metrics.ctr,
       metrics.cost_micros, metrics.conversions, metrics.cost_per_conversion
FROM ad_group
WHERE campaign.status = 'ENABLED' AND ad_group.status = 'ENABLED'
  AND segments.date DURING LAST_30_DAYS
ORDER BY metrics.conversions DESC LIMIT 50
```

### Keywords & Quality Score

```sql
-- Keywords with quality scores
SELECT campaign.name, ad_group.name,
       ad_group_criterion.keyword.text,
       ad_group_criterion.keyword.match_type,
       ad_group_criterion.quality_info.quality_score,
       ad_group_criterion.quality_info.creative_quality_score,
       ad_group_criterion.quality_info.post_click_quality_score,
       ad_group_criterion.quality_info.search_predicted_ctr,
       metrics.impressions, metrics.clicks, metrics.conversions,
       metrics.cost_micros
FROM keyword_view
WHERE ad_group_criterion.status = 'ENABLED'
  AND campaign.status = 'ENABLED'
  AND segments.date DURING LAST_30_DAYS
ORDER BY metrics.impressions DESC LIMIT 200

-- Low quality score keywords (optimization target)
SELECT campaign.name, ad_group.name,
       ad_group_criterion.keyword.text,
       ad_group_criterion.quality_info.quality_score,
       metrics.impressions, metrics.cost_micros
FROM keyword_view
WHERE ad_group_criterion.quality_info.quality_score IS NOT NULL
  AND ad_group_criterion.quality_info.quality_score < 5
  AND segments.date DURING LAST_30_DAYS
  AND campaign.status = 'ENABLED'
ORDER BY metrics.cost_micros DESC
```

### Search Terms

```sql
-- Search terms report
SELECT search_term_view.search_term, search_term_view.status,
       campaign.name, ad_group.name,
       metrics.impressions, metrics.clicks, metrics.ctr,
       metrics.cost_micros, metrics.conversions,
       metrics.conversions_from_interactions_rate
FROM search_term_view
WHERE segments.date DURING LAST_30_DAYS
  AND metrics.impressions > 10
ORDER BY metrics.clicks DESC LIMIT 500

-- Unmatched search terms (potential negatives)
SELECT search_term_view.search_term, campaign.name,
       metrics.impressions, metrics.clicks, metrics.cost_micros, metrics.conversions
FROM search_term_view
WHERE segments.date DURING LAST_30_DAYS
  AND metrics.clicks > 5 AND metrics.conversions = 0
ORDER BY metrics.cost_micros DESC
```

### Ad Performance

```sql
-- Responsive search ad performance
SELECT ad_group_ad.ad.id, ad_group_ad.ad.responsive_search_ad.headlines,
       ad_group_ad.ad.responsive_search_ad.descriptions,
       ad_group_ad.ad.final_urls, ad_group_ad.status,
       campaign.name, ad_group.name,
       metrics.impressions, metrics.clicks, metrics.ctr,
       metrics.conversions, metrics.cost_micros
FROM ad_group_ad
WHERE ad_group_ad.ad.type = 'RESPONSIVE_SEARCH_AD'
  AND campaign.status = 'ENABLED'
  AND segments.date DURING LAST_30_DAYS
ORDER BY metrics.impressions DESC LIMIT 100

-- Ad asset performance (headline/description level)
SELECT asset.text_asset.text, ad_group_ad_asset_view.field_type,
       ad_group_ad_asset_view.performance_label,
       metrics.impressions, metrics.clicks
FROM ad_group_ad_asset_view
WHERE segments.date DURING LAST_30_DAYS
  AND campaign.status = 'ENABLED'
```

### Geographic Performance

```sql
SELECT geographic_view.country_criterion_id,
       geographic_view.location_type,
       campaign.name,
       metrics.impressions, metrics.clicks, metrics.cost_micros,
       metrics.conversions
FROM geographic_view
WHERE segments.date DURING LAST_30_DAYS AND campaign.status = 'ENABLED'
ORDER BY metrics.clicks DESC LIMIT 100
```

### Audience & Demographics

```sql
-- Age range performance
SELECT ad_group.name, ad_group_criterion.age_range.type,
       metrics.impressions, metrics.clicks, metrics.conversions
FROM age_range_view
WHERE segments.date DURING LAST_30_DAYS AND campaign.status = 'ENABLED'

-- Gender performance
SELECT ad_group.name, ad_group_criterion.gender.type,
       metrics.impressions, metrics.clicks, metrics.conversions
FROM gender_view
WHERE segments.date DURING LAST_30_DAYS AND campaign.status = 'ENABLED'
```

### Performance Max

```sql
-- PMax campaign overview
SELECT campaign.name, campaign.status,
       metrics.impressions, metrics.clicks, metrics.cost_micros,
       metrics.conversions, metrics.conversions_value
FROM campaign
WHERE campaign.advertising_channel_type = 'PERFORMANCE_MAX'
  AND segments.date DURING LAST_30_DAYS

-- PMax asset group performance (v23: new engagement metrics)
SELECT asset_group.name, asset_group.status,
       campaign.name,
       metrics.impressions, metrics.clicks, metrics.cost_micros,
       metrics.conversions,
       metrics.engagements, metrics.engagement_rate, metrics.average_cpe
FROM asset_group
WHERE segments.date DURING LAST_30_DAYS

-- PMax asset-level metrics (v23: video/CPM metrics)
SELECT asset_group_asset.asset, asset_group_asset.field_type,
       metrics.impressions, metrics.clicks,
       metrics.average_cpe, metrics.average_cpm,
       metrics.video_trueview_view_rate, metrics.video_trueview_views,
       metrics.trueview_average_cpv
FROM asset_group_asset
WHERE segments.date DURING LAST_30_DAYS

-- PMax network breakdown (v23+)
SELECT campaign.name, segments.ad_network_type,
       metrics.impressions, metrics.clicks, metrics.cost_micros, metrics.conversions
FROM campaign
WHERE campaign.advertising_channel_type = 'PERFORMANCE_MAX'
  AND segments.date DURING LAST_30_DAYS

-- PMax listing group (product) performance
SELECT asset_group_listing_group_filter.case_value.product_type.value,
       asset_group_listing_group_filter.case_value.product_brand.value,
       metrics.impressions, metrics.clicks, metrics.cost_micros, metrics.conversions
FROM asset_group_product_group_view
WHERE segments.date DURING LAST_30_DAYS
```

### Shopping

```sql
-- Shopping product performance
SELECT campaign.name, segments.product_title, segments.product_item_id,
       segments.product_brand, segments.product_type_l1,
       metrics.impressions, metrics.clicks, metrics.cost_micros,
       metrics.conversions, metrics.conversions_value
FROM shopping_performance_view
WHERE segments.date DURING LAST_30_DAYS
ORDER BY metrics.conversions_value DESC LIMIT 200

-- Shopping competitive metrics by conversion date (v23+)
SELECT campaign.name, segments.product_item_id,
       segments.conversion_action, segments.conversion_date,
       metrics.conversions, metrics.conversions_value,
       metrics.benchmark_average_max_cpc, metrics.benchmark_ctr
FROM shopping_performance_view
WHERE segments.date DURING LAST_30_DAYS
```

### Conversion Actions

```sql
SELECT conversion_action.id, conversion_action.name,
       conversion_action.type, conversion_action.status,
       conversion_action.category,
       metrics.conversions, metrics.conversions_value, metrics.cost_per_conversion
FROM conversion_action
WHERE segments.date DURING LAST_30_DAYS
ORDER BY metrics.conversions DESC
```

### Change History

```sql
-- Recent changes (last 14 days)
SELECT change_event.change_date_time, change_event.change_resource_type,
       change_event.changed_fields, change_event.client_type,
       change_event.user_email, change_event.old_resource, change_event.new_resource,
       campaign.name
FROM change_event
WHERE change_event.change_date_time DURING LAST_14_DAYS
  AND change_event.change_resource_type IN (
    'CAMPAIGN', 'AD_GROUP', 'AD_GROUP_AD', 'AD_GROUP_CRITERION')
ORDER BY change_event.change_date_time DESC
LIMIT 1000
```

### Labels

```sql
-- Campaigns with specific label
SELECT campaign.name, campaign.status, label.name,
       metrics.impressions, metrics.clicks
FROM campaign_label
WHERE label.name = 'Priority'
  AND segments.date DURING LAST_30_DAYS
```

### Account-Level Metrics

```sql
-- Account summary
SELECT customer.descriptive_name, customer.id,
       metrics.impressions, metrics.clicks, metrics.ctr,
       metrics.cost_micros, metrics.conversions
FROM customer
WHERE segments.date DURING LAST_30_DAYS
```

### Draft Campaigns

```sql
-- Include drafts (not included by default)
SELECT campaign.id, campaign.name, campaign.status
FROM campaign
PARAMETERS include_drafts = true
```

### PARAMETERS Clause Options

The `PARAMETERS` clause controls query behavior:

```sql
-- Include draft campaigns
PARAMETERS include_drafts = true

-- Omit unselected resource names (reduces response size)
PARAMETERS omit_unselected_resource_names = true

-- Both
SELECT campaign.name, metrics.clicks FROM campaign
PARAMETERS include_drafts = true, omit_unselected_resource_names = true
```

### Bidding Strategy Info

```sql
SELECT campaign.name, campaign.bidding_strategy_type,
       campaign.target_cpa.target_cpa_micros,
       campaign.target_roas.target_roas,
       campaign.maximize_conversions.target_cpa_micros,
       campaign.maximize_conversion_value.target_roas,
       metrics.conversions, metrics.cost_per_conversion
FROM campaign
WHERE campaign.status = 'ENABLED' AND segments.date DURING LAST_30_DAYS
```

### Customer Acquisition Goal Performance

```sql
-- Campaign-level acquisition goal settings and new customer metrics
SELECT campaign.name,
       campaign.customer_acquisition_goal_settings.optimization_mode,
       metrics.new_customer_lifetime_value,
       metrics.conversions, metrics.conversions_value,
       metrics.cost_micros
FROM campaign
WHERE campaign.status = 'ENABLED'
  AND segments.date DURING LAST_30_DAYS
```

### Conversion Value Rules

```sql
-- List all active conversion value rules
SELECT conversion_value_rule.name,
       conversion_value_rule.status,
       conversion_value_rule.action.operation,
       conversion_value_rule.action.value,
       conversion_value_rule.audience_condition.user_lists,
       conversion_value_rule.geo_location_condition.geo_target_constants,
       conversion_value_rule.device_condition.device_types
FROM conversion_value_rule
WHERE conversion_value_rule.status = 'ENABLED'
```

### Enhanced Conversion Diagnostics

```sql
-- Monitor conversion actions with type details
SELECT conversion_action.name,
       conversion_action.type,
       conversion_action.status,
       conversion_action.category,
       metrics.all_conversions,
       metrics.conversions,
       metrics.all_conversions_value
FROM conversion_action
WHERE conversion_action.status = 'ENABLED'
  AND conversion_action.type IN ('UPLOAD_CLICKS', 'WEBPAGE')
```

### Customer Match List Status

```sql
-- Check user list sizes and eligibility
SELECT user_list.name,
       user_list.type,
       user_list.size_for_search,
       user_list.size_for_display,
       user_list.eligible_for_search,
       user_list.eligible_for_display,
       user_list.membership_life_span
FROM user_list
WHERE user_list.type = 'CRM_BASED'
```

---

## Common Mistakes

| Mistake | Error | Fix |
|---------|-------|-----|
| `segments.date` in SELECT without date range in WHERE | `DATE_RANGE_TOO_WIDE` | Add `DURING` or `BETWEEN` |
| Using `OR` in WHERE | Parse error | Use `IN (...)` or run separate queries |
| Incompatible segment + metric combination | `QUERY_ERROR` | Check Query Builder for compatibility |
| Missing quotes around enum values | Parse error | Use `'ENABLED'` not `ENABLED` |
| Using customer_id with hyphens | `INVALID_CUSTOMER_ID` | Remove all hyphens: `1234567890` |
| Querying removed entities without explicit filter | Unexpected results | Add `WHERE status != 'REMOVED'` |
| Missing `LIMIT` on `change_event` | `LIMIT_NOT_SPECIFIED` | Change event queries always need LIMIT |

---

## Interactive Query Builder

Use Google's official tool to validate field compatibility and generate queries:

```
developers.google.com/google-ads/api/fields/v24/campaign_query_builder
```

Replace `campaign` in the URL with any resource name to get its specific builder.
The tool shows which fields, segments, and metrics can be combined in a single query.
