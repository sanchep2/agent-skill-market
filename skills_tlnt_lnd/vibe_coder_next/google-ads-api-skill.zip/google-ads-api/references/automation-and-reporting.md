# Automation & Reporting Reference

## Table of Contents
1. [Reporting with SearchStream](#reporting-with-searchstream)
2. [Batch Job Processing](#batch-job-processing)
3. [Recommendations API](#recommendations-api)
4. [Offline Conversion Tracking](#offline-conversion-tracking)
5. [Enhanced Conversions](#enhanced-conversions)
6. [Conversion Adjustments](#conversion-adjustments)
7. [Change Tracking & Audit](#change-tracking--audit)
8. [MCC Multi-Account Management](#mcc-multi-account-management)
9. [Error Handling & Retry Patterns](#error-handling--retry-patterns)
10. [Rate Limits & Quota Management](#rate-limits--quota-management)
11. [Google Ads Scripts vs API](#google-ads-scripts-vs-api)
12. [Conversion Action Setup](#conversion-action-setup)
13. [GA4 Integration](#ga4-integration)

---

## Reporting with SearchStream

Always prefer `search_stream` over `search` for data retrieval.

### Pattern: Stream to DataFrame

```python
import pandas as pd

def query_to_dataframe(client, customer_id, query):
    """Execute a GAQL query and return results as a pandas DataFrame."""
    ga_service = client.get_service("GoogleAdsService")
    rows = []
    stream = ga_service.search_stream(customer_id=customer_id, query=query)
    for batch in stream:
        for row in batch.results:
            rows.append(_flatten_row(row))
    return pd.DataFrame(rows)

def _flatten_row(row):
    """Flatten a protobuf row into a dict. Customize per query."""
    d = {}
    # Access nested fields safely
    if hasattr(row, 'campaign'):
        d['campaign_id'] = row.campaign.id
        d['campaign_name'] = row.campaign.name
        d['campaign_status'] = row.campaign.status.name
    if hasattr(row, 'metrics'):
        d['impressions'] = row.metrics.impressions
        d['clicks'] = row.metrics.clicks
        d['cost'] = row.metrics.cost_micros / 1_000_000
        d['conversions'] = row.metrics.conversions
        d['ctr'] = row.metrics.ctr
    if hasattr(row, 'segments'):
        if row.segments.date:
            d['date'] = row.segments.date
    return d
```

### Pattern: Export to CSV

```python
def export_report_csv(client, customer_id, query, output_path):
    df = query_to_dataframe(client, customer_id, query)
    df.to_csv(output_path, index=False)
    print(f"Exported {len(df)} rows to {output_path}")
```

### SearchStream vs Search Comparison

| Feature | SearchStream | Search |
|---------|-------------|--------|
| Connection | Single persistent stream | Multiple round-trips |
| Pagination | None needed | 10,000 rows/page (fixed since v17) |
| Performance | Faster for large datasets | OK for small datasets |
| Quota | 1 operation | 1 operation (regardless of pages) |
| Best for | All production use | Flaky network connections |

**Paginated Search** (for unreliable connections only):

```python
from google.ads.googleads.services.types import SearchGoogleAdsRequest

request = SearchGoogleAdsRequest(customer_id=customer_id, query=query)
response = ga_service.search(request=request)
for row in response:  # Client library auto-paginates via next_page_token
    process(row)
```

**Quota note**: Paginated `Search` requests using `next_page_token` do **not** count
additional operations against daily quotas — only the initial request counts.

---

## Batch Job Processing

For large operations (>10K mutations) or fire-and-forget async processing.

### Complete Batch Job Workflow

```python
def run_batch_job(client, customer_id, operations):
    """
    Run operations asynchronously via BatchJobService.
    Supports up to 10,000 operations per add call.
    Retries transient errors automatically.
    """
    batch_job_service = client.get_service("BatchJobService")

    # Step 1: Create the batch job
    create_op = client.get_type("BatchJobOperation")
    create_op.create.resource_name = ""  # Let API assign
    response = batch_job_service.mutate_batch_job(
        customer_id=customer_id, operation=create_op)
    batch_job_rn = response.result.resource_name
    print(f"Created batch job: {batch_job_rn}")

    # Step 2: Add operations (max 10,000 per call)
    CHUNK_SIZE = 10_000
    for i in range(0, len(operations), CHUNK_SIZE):
        chunk = operations[i:i + CHUNK_SIZE]
        batch_job_service.add_batch_job_operations(
            resource_name=batch_job_rn,
            mutate_operations=chunk)
        print(f"Added operations {i} to {i + len(chunk)}")

    # Step 3: Run the job (returns a long-running operation)
    lro = batch_job_service.run_batch_job(resource_name=batch_job_rn)

    # Step 4: Poll for completion
    print("Waiting for batch job to complete...")
    lro.result(timeout=3600)  # Wait up to 1 hour

    # Step 5: Retrieve results
    results = batch_job_service.list_batch_job_results(
        resource_name=batch_job_rn)
    successes = 0
    failures = 0
    for result in results:
        if result.status.code == 0:
            successes += 1
        else:
            failures += 1
            print(f"Failed: {result.status.message}")

    print(f"Batch complete: {successes} succeeded, {failures} failed")
    return results
```

### Batch Job Key Facts

- Max **10,000 operations** per `add_batch_job_operations` call
- Multiple add calls can be chained before running
- Transient errors are **automatically retried** by the service
- Supports `partial_failure` semantics
- `AssetGroupOperation` supported since v17 (for PMax creation at scale)
- Jobs expire after **7 days** if not run

---

## Recommendations API

Surface and auto-apply Google's optimization recommendations.

### Query Recommendations

```python
def get_recommendations(client, customer_id):
    ga_service = client.get_service("GoogleAdsService")
    query = """
        SELECT recommendation.type, recommendation.impact,
               recommendation.campaign, recommendation.ad_group,
               recommendation.resource_name
        FROM recommendation
    """
    stream = ga_service.search_stream(customer_id=customer_id, query=query)
    for batch in stream:
        for row in batch.results:
            rec = row.recommendation
            print(f"Type: {rec.type_.name}")
            print(f"Impact: {rec.impact.base_metrics}")
            print(f"Resource: {rec.resource_name}")
```

### Apply a Recommendation

```python
def apply_recommendation(client, customer_id, recommendation_resource_name):
    recommendation_service = client.get_service("RecommendationService")
    op = client.get_type("ApplyRecommendationOperation")
    op.resource_name = recommendation_resource_name
    response = recommendation_service.apply_recommendation(
        customer_id=customer_id, operations=[op])
    return response
```

### Dismiss a Recommendation

```python
def dismiss_recommendation(client, customer_id, recommendation_resource_name):
    recommendation_service = client.get_service("RecommendationService")
    op = client.get_type("DismissRecommendationRequest.DismissRecommendationOperation")
    op.resource_name = recommendation_resource_name
    response = recommendation_service.dismiss_recommendation(
        customer_id=customer_id, operations=[op])
```

### Auto-Apply Recommendations (Subscriptions)

```python
# Subscribe to auto-apply specific recommendation types
subscription_service = client.get_service("RecommendationSubscriptionService")
sub_op = client.get_type("RecommendationSubscriptionOperation")
sub = sub_op.create
sub.type_ = client.enums.RecommendationTypeEnum.KEYWORD
sub.status = client.enums.RecommendationSubscriptionStatusEnum.ENABLED
subscription_service.mutate_recommendation_subscription(
    customer_id=customer_id, operation=sub_op)
```

---

## Offline Conversion Tracking

### Upload Click Conversions

```python
def upload_conversions(client, customer_id, conversion_action_id, conversions_data):
    """
    conversions_data: list of dicts with keys:
      gclid, conversion_time, conversion_value, currency_code
    """
    service = client.get_service("ConversionUploadService")
    click_conversions = []

    for conv in conversions_data:
        cc = client.get_type("ClickConversion")
        cc.gclid = conv["gclid"]
        cc.conversion_action = service.conversion_action_path(
            customer_id, conversion_action_id)
        cc.conversion_date_time = conv["conversion_time"]  # "2025-01-15 12:30:00-05:00"
        cc.conversion_value = conv["conversion_value"]
        cc.currency_code = conv.get("currency_code", "USD")
        # Optional dedup key (prevents duplicate uploads)
        if "order_id" in conv:
            cc.order_id = conv["order_id"]
        # EU consent (required for EU traffic)
        cc.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
        cc.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED
        click_conversions.append(cc)

    response = service.upload_click_conversions(
        customer_id=customer_id,
        conversions=click_conversions,
        partial_failure=True,  # Always True — don't fail the entire batch
    )

    if response.partial_failure_error:
        print(f"Partial failures: {response.partial_failure_error.message}")
    else:
        print(f"Successfully uploaded {len(click_conversions)} conversions")
    return response
```

### Key Rules

- Conversions must be uploaded **within 90 days** of the click
- Use `order_id` as a natural deduplication key
- `partial_failure=True` prevents one bad record from failing the entire batch
- EU consent fields (`consent.ad_user_data`, `consent.ad_personalization`) are mandatory
  for EU traffic

### Enhanced Conversions

Enhanced Conversions supplement click data with **hashed first-party user data** (email,
phone, name, address) to improve match rates from ~50% to 80-90% and recover 15-30%
more attributed conversions. This is the most important measurement upgrade for 2026.

**Two types:**
- **Enhanced Conversions for Web**: Tag captures hashed data at online conversion time
- **Enhanced Conversions for Leads**: Tag captures data at form submit, you import offline
  conversion later — no GCLID required

**For complete implementation** (API code, batch uploads, diagnostics, Data Manager API
integration, migration guide from legacy offline imports): read
`references/first-party-data-strategy.md` → Enhanced Conversions section.

Quick API snippet (enhanced conversion upload with user identifiers):

```python
import hashlib

def normalize_and_hash(value):
    return hashlib.sha256(value.strip().lower().encode("utf-8")).hexdigest()

cc = client.get_type("ClickConversion")
cc.conversion_action = conv_action_path
cc.conversion_date_time = "2026-02-15 14:30:00-05:00"
cc.conversion_value = 150.0
cc.order_id = "ORDER-12345"

# Add hashed user identifiers (the key enhancement)
ui = cc.user_identifiers.add()
ui.hashed_email = normalize_and_hash("user@example.com")
ui2 = cc.user_identifiers.add()
ui2.hashed_phone_number = normalize_and_hash("+14155551234")

cc.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
cc.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED

response = service.upload_click_conversions(
    customer_id=cid, conversions=[cc], partial_failure=True)
```

### Conversion Adjustments (Restatements & Retractions)

Update or remove conversions after upload. Critical for accurate value-based bidding.

- **RESTATEMENT**: Change conversion value (lead score update, partial refund, LTV revision)
- **RETRACTION**: Remove conversion entirely (full refund, cancelled order, fraud)

```python
# Restate: update a conversion's value
adjustment = client.get_type("ConversionAdjustment")
adjustment.conversion_action = conv_action_rn
adjustment.adjustment_type = client.enums.ConversionAdjustmentTypeEnum.RESTATEMENT
adjustment.gclid_date_time_pair.gclid = "original_gclid"
adjustment.gclid_date_time_pair.conversion_date_time = "2026-01-15 12:30:00-05:00"
adjustment.restatement_value.adjusted_value = 500.0  # Updated value
adjustment.restatement_value.currency_code = "USD"
adjustment.adjustment_date_time = "2026-02-01 09:00:00-05:00"

# Retract: remove a conversion
retraction = client.get_type("ConversionAdjustment")
retraction.conversion_action = conv_action_rn
retraction.adjustment_type = client.enums.ConversionAdjustmentTypeEnum.RETRACTION
retraction.gclid_date_time_pair.gclid = "refunded_gclid"
retraction.gclid_date_time_pair.conversion_date_time = "2026-01-20 10:00:00-05:00"

service = client.get_service("ConversionAdjustmentUploadService")
response = service.upload_conversion_adjustments(
    customer_id=cid, conversion_adjustments=[adjustment, retraction],
    partial_failure=True)
```

Key rules: adjustments within **55 days** of original conversion, allow 24-48h to reflect
in reporting, retractions are final. For batch adjustments and enhanced conversion
adjustments (without GCLID, using order_id), see `references/first-party-data-strategy.md`.

### Data Manager API Alternative

For automated, scheduled data uploads from CRM/warehouses (Salesforce, HubSpot, BigQuery,
Snowflake, etc.), consider the **Data Manager API** instead of custom API code. It provides
native connectors and scheduling. Since Feb 2, 2026, session attributes and IP data **must**
use Data Manager API. See `references/first-party-data-strategy.md` → Data Manager API section.

---

## Change Tracking & Audit

### ChangeStatusService (for sync)

Returns the latest change per resource — useful for detecting what changed since your
last sync.

```python
query = """
    SELECT change_status.resource_name, change_status.resource_type,
           change_status.resource_status, change_status.last_change_date_time
    FROM change_status
    WHERE change_status.last_change_date_time DURING LAST_7_DAYS
    ORDER BY change_status.last_change_date_time DESC
    LIMIT 1000
"""
```

### ChangeEventService (for audit)

Provides granular detail: old/new values, user email, client type (API vs UI).

```python
query = """
    SELECT change_event.change_date_time,
           change_event.change_resource_type,
           change_event.changed_fields,
           change_event.client_type,
           change_event.user_email,
           change_event.old_resource,
           change_event.new_resource,
           campaign.name
    FROM change_event
    WHERE change_event.change_date_time DURING LAST_14_DAYS
      AND change_event.change_resource_type IN ('CAMPAIGN', 'AD_GROUP', 'AD_GROUP_AD')
    ORDER BY change_event.change_date_time DESC
    LIMIT 1000
"""
```

**Change events require LIMIT** and cover only the last **30 days**.

### Detecting UI vs API Conflicts

```python
# Find changes made in the UI that might conflict with API automation
query = """
    SELECT change_event.change_date_time, change_event.client_type,
           change_event.user_email, change_event.changed_fields,
           campaign.name
    FROM change_event
    WHERE change_event.client_type = 'GOOGLE_ADS_WEB_CLIENT'
      AND change_event.change_date_time DURING LAST_7_DAYS
    ORDER BY change_event.change_date_time DESC
    LIMIT 500
"""
```

---

## MCC Multi-Account Management

### List Accessible Accounts

```python
# No login_customer_id needed for this call
customer_service = client.get_service("CustomerService")
response = customer_service.list_accessible_customers()
for rn in response.resource_names:
    print(rn)  # customers/1234567890
```

### Get Account Hierarchy

```python
def get_account_hierarchy(client, mcc_id):
    ga_service = client.get_service("GoogleAdsService")
    query = """
        SELECT customer_client.client_customer,
               customer_client.descriptive_name,
               customer_client.manager,
               customer_client.level,
               customer_client.status,
               customer_client.currency_code,
               customer_client.time_zone
        FROM customer_client
        WHERE customer_client.level <= 1
          AND customer_client.status = 'ENABLED'
    """
    accounts = []
    stream = ga_service.search_stream(customer_id=mcc_id, query=query)
    for batch in stream:
        for row in batch.results:
            cc = row.customer_client
            accounts.append({
                "id": cc.client_customer,
                "name": cc.descriptive_name,
                "is_manager": cc.manager,
                "level": cc.level,
                "currency": cc.currency_code,
                "timezone": cc.time_zone,
            })
    return accounts
```

### Cross-Account Reporting

There is **no single MCC-level report endpoint**. You must iterate over accounts:

```python
def cross_account_report(client, mcc_id, query):
    """Run a GAQL query across all accounts under an MCC."""
    accounts = get_account_hierarchy(client, mcc_id)
    all_results = []
    for account in accounts:
        if account["is_manager"]:
            continue  # Skip manager accounts
        cid = account["id"].replace("customers/", "")
        try:
            df = query_to_dataframe(client, cid, query)
            df["account_name"] = account["name"]
            df["account_id"] = cid
            all_results.append(df)
        except Exception as e:
            print(f"Error on {account['name']} ({cid}): {e}")
    if all_results:
        return pd.concat(all_results, ignore_index=True)
    return pd.DataFrame()
```

Or use **gaarf** with MCC expansion (much simpler for batch operations).

### Link/Unlink Accounts

```python
# Send link invitation (from manager)
link_op = client.get_type("CustomerClientLinkOperation")
link = link_op.create
link.client_customer = f"customers/{client_customer_id}"
link.status = client.enums.ManagerLinkStatusEnum.PENDING
client_link_service.mutate_customer_client_link(
    customer_id=mcc_id, operation=link_op)

# Accept invitation (from client account)
manager_link_op = client.get_type("CustomerManagerLinkOperation")
manager_link = manager_link_op.update
manager_link.resource_name = f"customers/{client_id}/customerManagerLinks/{mcc_id}"
manager_link.status = client.enums.ManagerLinkStatusEnum.ACTIVE
```

---

## Error Handling & Retry Patterns

### Retry-Safe Error Categories

| Error Type | Retry? | Examples |
|-----------|--------|---------|
| `TRANSIENT_ERROR` | Yes | Temporary server issues |
| `INTERNAL_ERROR` | Yes (cautiously) | Server-side bugs |
| `RESOURCE_EXHAUSTED` | Yes (with backoff) | Rate limiting |
| `DEADLINE_EXCEEDED` | Yes | Timeout |
| `REQUEST_ERROR` | No | Bad query syntax |
| `AUTHORIZATION_ERROR` | No | Bad credentials |
| `POLICY_VIOLATION_ERROR` | No | Ad policy rejection |

### Exponential Backoff with Jitter

```python
import time
import random

def retry_with_backoff(func, max_retries=5, base_delay=5.0):
    """Retry a function with exponential backoff and jitter."""
    for attempt in range(max_retries):
        try:
            return func()
        except GoogleAdsException as ex:
            retryable = any(
                error.error_code.HasField("internal_error") or
                error.error_code.HasField("transient_error")
                for error in ex.failure.errors
            )
            if not retryable or attempt == max_retries - 1:
                raise
            delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
            print(f"Retry {attempt + 1}/{max_retries} in {delay:.1f}s...")
            time.sleep(delay)
```

### Partial Failure Handling

```python
from google.ads.googleads import util as ads_util

response = service.mutate_campaigns(
    customer_id=cid,
    operations=ops,
    partial_failure=True)

if response.partial_failure_error:
    errors = ads_util.get_all_errors(response.partial_failure_error)
    for error in errors:
        print(f"Operation index {error.location.field_path_elements[0].index}: "
              f"{error.message}")
```

---

## Rate Limits & Quota Management

| Dimension | Limit |
|-----------|-------|
| Mutate operations per request | 10,000 (exceeding returns `TOO_MANY_MUTATE_OPERATIONS`) |
| Daily operations (Basic) | 15,000 |
| Daily operations (Standard) | Unlimited |
| Keyword Planning QPS | 1 |
| Rate limiting algorithm | Token bucket |
| Rate limited response | `RESOURCE_EXHAUSTED` with `retryDelay` in metadata |

The API does not publish a fixed QPS number. Rate limits are metered per
**client customer ID** and per **developer token** independently.

**Optimization tips**:
- Reuse `GoogleAdsClient` instances (and their gRPC channels)
- Select only the GAQL fields you need
- Use SearchStream exclusively
- Batch mutations (up to 10K ops per call)
- Use BatchJobService for very large operations
- Implement client-side rate limiters for multi-threaded applications
- Cache access tokens (the client library does this automatically)

---

## Google Ads Scripts vs API

| Dimension | Scripts | API |
|-----------|---------|-----|
| Language | JavaScript (Apps Script) | Python, Java, PHP, Ruby, .NET, Perl |
| Infrastructure | None (Google servers) | Your own |
| Execution limit | **30 minutes** | None |
| Max per account | 250 scripts | Unlimited |
| Developer token | Not needed | Required |
| Entity coverage | Subset | Complete |
| Scheduling | Hourly/daily/weekly | Any (cron, Airflow, etc.) |
| External APIs | `UrlFetchApp` | Full network access |
| Version control | Manual | Git-native |

**Use Scripts for**: Quick prototyping, simple bid rules, budget alerts, Sheets reporting,
when you lack dev infrastructure.

**Use API for**: Enterprise scale, external system integration, operations >30min,
CI/CD workflows, commercial tools, complex multi-account orchestration.

---

## Conversion Action Setup

```python
def create_conversion_action(client, customer_id, name, category="PURCHASE"):
    conversion_action_service = client.get_service("ConversionActionService")
    op = client.get_type("ConversionActionOperation")
    ca = op.create
    ca.name = name
    ca.type_ = client.enums.ConversionActionTypeEnum.UPLOAD_CLICKS
    ca.category = getattr(client.enums.ConversionActionCategoryEnum, category)
    ca.status = client.enums.ConversionActionStatusEnum.ENABLED
    ca.value_settings.default_value = 0
    ca.value_settings.always_use_default_value = False
    ca.click_through_lookback_window_days = 90
    ca.counting_type = client.enums.ConversionActionCountingTypeEnum.ONE_PER_CLICK

    response = conversion_action_service.mutate_conversion_actions(
        customer_id=customer_id, operations=[op])
    return response.results[0].resource_name
```

---

## GA4 Integration

### Link GA4 Property

```python
# Link via ProductLinkService
product_link_service = client.get_service("ProductLinkService")
op = client.get_type("ProductLinkOperation")
pl = op.create
pl.google_analytics.property_id = 123456789  # GA4 property ID
response = product_link_service.mutate_product_link(
    customer_id=customer_id, operation=op)
```

### Import GA4 Conversions

GA4 conversion actions can be imported as Google Ads goals via the Google Ads UI
or programmatically by creating conversion actions with type
`GOOGLE_ANALYTICS_4_CUSTOM` or `GOOGLE_ANALYTICS_4_PURCHASE`.

### Cross-Account Conversion Tracking

For MCC-level conversion tracking, set the conversion tracking customer on the
client account:

```python
customer_op = client.get_type("CustomerOperation")
customer = customer_op.update
customer.resource_name = f"customers/{client_customer_id}"
customer.conversion_tracking_setting.cross_account_conversion_tracking_id = int(mcc_id)
```

---

## InvoiceService Enhancements (v23)

v23 significantly expanded InvoiceService with campaign-level cost breakdowns:

```python
invoice_service = client.get_service("InvoiceService")
response = invoice_service.list_invoices(
    customer_id=customer_id,
    billing_setup=f"customers/{customer_id}/billingSetups/{billing_setup_id}",
    issue_year="2026",
    issue_month=client.enums.MonthOfYearEnum.JANUARY,
    # NEW in v23: enable granular details
    # This returns campaign-level costs, regulatory fees, and adjustments
)
for invoice in response.invoices:
    print(f"Invoice: {invoice.id}, Total: {invoice.total_amount_micros / 1_000_000}")
    # Access campaign-level breakdowns, regulatory costs, adjustments
```

This enables precise financial tracking and reconciliation at the campaign level.

---

## PerStoreView (v23)

v23 introduced `PerStoreView` for accessing store-level performance data, matching
the Stores report in the Google Ads UI:

```python
query = """
    SELECT per_store_view.place_id,
           metrics.impressions, metrics.clicks, metrics.cost_micros,
           metrics.store_visits, metrics.store_visits_value
    FROM per_store_view
    WHERE segments.date DURING LAST_30_DAYS
    ORDER BY metrics.store_visits DESC
"""
```

Useful for retail/local businesses tracking which physical store locations drive
the most ad-attributed visits.

---

## Version Migration Guide

### Migration Checklist

When upgrading API versions (especially with monthly cadence in 2026):

1. **Audit current usage**: Scan codebase for version-specific imports, endpoint URLs
2. **Read the version diff**: `developers.google.com/google-ads/api/docs/release-notes`
3. **Update client library**: `pip install --upgrade google-ads`
4. **Check for breaking changes**: Removed fields, changed enums, deprecated services
5. **Update GAQL queries**: New metrics/segments may be available; removed ones will error
6. **Test on test account first**: Use Explorer Access test account before production
7. **Monitor error rates**: After deploying, watch for new error codes

### Key Migration Milestones (2025-2026)

| From | To | Breaking Changes |
|------|-----|-----------------|
| v18 → v19 | Feed entities removed entirely | All extensions must use Asset model |
| v19 → v20 | None major | PMax negative keywords added |
| v20 → v21 | AI Max fields added | New campaign settings to handle |
| v22 → v23 | CallAd removed, ad sharing blocked | `AD_SHARING_NOT_ALLOWED` error if sharing ads |

### Version Sunset Timeline

Each major version is supported for **12 months** from release. After sunset, all
requests to that version fail. Google announces sunset dates at least 4 months in advance.

**Current danger**: v20 sunsets June 2026. Plan migration to v22+ well before this date.

### Handling Monthly Release Cadence

With monthly releases in 2026, adopt a rolling upgrade strategy:
- Pin to a stable major version (e.g., v23)
- Evaluate each minor release (v23.1, v23.2) for useful additions
- Plan major version upgrades quarterly
- Use `pip install google-ads==XX.X.X` to pin specific library versions in production
