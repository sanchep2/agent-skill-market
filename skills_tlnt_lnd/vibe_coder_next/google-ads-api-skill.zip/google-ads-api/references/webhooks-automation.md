# Webhooks & Automation Reference

## Table of Contents
1. [Change Detection (No Webhooks)](#change-detection)
2. [Conversion Upload Automation](#conversion-upload-automation)
3. [Google Ads Scripts](#google-ads-scripts)
4. [iPaaS Automation](#ipaas-automation)
5. [MCP for Automation](#mcp-for-automation)
6. [Custom Webhook Patterns](#custom-webhook-patterns)
7. [Recommendation Auto-Apply](#recommendation-auto-apply)
8. [Scheduled Operations](#scheduled-operations)
9. [Alerting Patterns](#alerting-patterns)
10. [Multi-Account (MCC) Automation](#multi-account-mcc-automation)
11. [Adjacent Webhooks](#adjacent-webhooks)

---

## Change Detection

**Critical fact**: Google Ads API has **NO real-time webhook system**. Unlike Meta
(Lead Ads webhooks), TikTok, or LinkedIn (Lead Gen Forms), Google Ads does not push
notifications when events occur. All change detection requires **polling**.

### Two Services for Change Detection

| Service | Purpose | Best For |
|---------|---------|----------|
| `ChangeEventService` | WHO changed WHAT and WHEN (audit trail) | Compliance, activity log |
| `ChangeStatusService` | WHAT changed SINCE timestamp (sync) | Data sync, automation triggers |

### ChangeStatusService (Recommended for Automation)

Poll every 5-15 minutes to detect changes:

```python
from datetime import datetime, timedelta

def detect_changes(client, customer_id, since_minutes=15):
    """Detect resource changes in the last N minutes."""
    ga_service = client.get_service("GoogleAdsService")
    since = (datetime.utcnow() - timedelta(minutes=since_minutes)).strftime(
        "%Y-%m-%dT%H:%M:%S+00:00")

    query = f"""
        SELECT change_status.resource_type,
               change_status.resource_name,
               change_status.resource_status,
               change_status.last_change_date_time
        FROM change_status
        WHERE change_status.last_change_date_time >= '{since}'
        ORDER BY change_status.last_change_date_time DESC
    """
    changes = []
    stream = ga_service.search_stream(customer_id=customer_id, query=query)
    for batch in stream:
        for row in batch.results:
            changes.append({
                "type": row.change_status.resource_type.name,
                "resource": row.change_status.resource_name,
                "status": row.change_status.resource_status.name,
                "changed_at": row.change_status.last_change_date_time,
            })
    return changes
```

### ChangeEventService (For Audit Trail)

```python
def audit_changes(client, customer_id, days=7):
    """Get detailed change audit with user info."""
    ga_service = client.get_service("GoogleAdsService")
    query = f"""
        SELECT change_event.change_date_time,
               change_event.change_resource_type,
               change_event.change_resource_name,
               change_event.client_type,
               change_event.user_email,
               change_event.old_resource,
               change_event.new_resource
        FROM change_event
        WHERE change_event.change_date_time DURING LAST_{days}_DAYS
        ORDER BY change_event.change_date_time DESC
        LIMIT 1000
    """
    stream = ga_service.search_stream(customer_id=customer_id, query=query)
    for batch in stream:
        for row in batch.results:
            event = row.change_event
            print(f"{event.change_date_time}: {event.user_email} changed "
                  f"{event.change_resource_type.name} ({event.change_resource_name})")
```

### Polling Frequency Recommendations

| Use Case | Frequency | Notes |
|----------|-----------|-------|
| Budget monitoring | Every 5 minutes | Catch budget exhaustion early |
| Campaign status changes | Every 15 minutes | Balance API usage vs latency |
| General sync | Every 30 minutes | Standard monitoring |
| Audit logging | Every 1-6 hours | Low priority, batch processing |

---

## Conversion Upload Automation

Automating offline conversion uploads is the most common automation pattern.

### Pattern 1: Cron-Based Upload

```python
# Run via cron every hour
import schedule

def upload_pending_conversions():
    """Upload offline conversions from CRM/database."""
    # 1. Query pending conversions from your database
    pending = db.query("""
        SELECT gclid, conversion_time, conversion_value, conversion_action_name
        FROM conversions
        WHERE uploaded_to_google = FALSE
          AND conversion_time > NOW() - INTERVAL '7 days'
        LIMIT 2000
    """)

    if not pending:
        return

    # 2. Build conversion objects
    client = GoogleAdsClient.load_from_storage()
    conversion_upload_service = client.get_service("ConversionUploadService")
    conversions = []

    for row in pending:
        click_conv = client.get_type("ClickConversion")
        click_conv.gclid = row.gclid
        click_conv.conversion_action = (
            f"customers/{CUSTOMER_ID}/conversionActions/{ACTION_ID}")
        click_conv.conversion_date_time = row.conversion_time.strftime(
            "%Y-%m-%d %H:%M:%S%z")
        click_conv.conversion_value = float(row.conversion_value)
        click_conv.currency_code = "USD"
        click_conv.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
        click_conv.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED
        conversions.append(click_conv)

    # 3. Upload with partial_failure
    response = conversion_upload_service.upload_click_conversions(
        customer_id=CUSTOMER_ID,
        conversions=conversions,
        partial_failure=True
    )

    # 4. Handle results
    if response.partial_failure_error:
        print(f"Partial failures: {response.partial_failure_error.message}")
    else:
        db.execute("UPDATE conversions SET uploaded_to_google = TRUE WHERE ...")

schedule.every().hour.do(upload_pending_conversions)
```

### Pattern 2: Data Manager API (Scheduled)

For automated recurring syncs, Data Manager API is preferred (since October 2025):
- Configure once in Google Ads UI or API
- Automatic scheduled pulls from your data source
- Built-in monitoring and error reporting
- No custom cron infrastructure needed

See `first-party-data-strategy.md` §2 for Data Manager API setup.

### Pattern 3: Real-Time API Upload

For immediate conversion reporting (e.g., in-app purchase):

```python
# Call immediately after conversion event
def report_conversion_realtime(gclid, value, action_id):
    client = GoogleAdsClient.load_from_storage()
    service = client.get_service("ConversionUploadService")
    conv = client.get_type("ClickConversion")
    conv.gclid = gclid
    conv.conversion_action = f"customers/{CID}/conversionActions/{action_id}"
    conv.conversion_date_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S-05:00")
    conv.conversion_value = value
    conv.currency_code = "USD"
    conv.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
    conv.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED

    response = service.upload_click_conversions(
        customer_id=CID, conversions=[conv], partial_failure=True)
    return response
```

---

## Google Ads Scripts

Legacy automation system that runs JavaScript directly in Google Ads.

### Scripts vs API Comparison

| Dimension | Scripts | API |
|-----------|---------|-----|
| **Language** | JavaScript (Apps Script) | Python, Java, PHP, Ruby, .NET, Perl |
| **Infrastructure** | None (Google hosted) | Your own servers |
| **Execution limit** | 30 minutes | None |
| **Max per account** | 250 scripts | Unlimited API calls |
| **Scheduling** | Built-in (hourly, daily) | External (cron, Airflow) |
| **MCC support** | Yes (MCC scripts) | Yes |
| **Write operations** | Yes (limited subset) | Full API access |
| **Rate limits** | Script execution time | Token bucket |
| **Version control** | Manual copy/paste | Git |
| **Testing** | In-browser preview | Full test framework |

### When Scripts Still Make Sense

- Simple automated rules (pause campaigns when budget exhausted)
- Small accounts with basic automation needs
- No engineering resources for API infrastructure
- Quick one-off data exports

### Migration Path to API

If you're outgrowing Scripts:
1. Identify what the script does (read, write, or both)
2. Rewrite the GAQL query (Scripts use a different query syntax)
3. Implement in Python with `google-ads` library
4. Deploy on Cloud Functions, Cloud Run, or your own infrastructure
5. Schedule via Cloud Scheduler, Airflow, or cron

---

## iPaaS Automation

### Zapier

**Available triggers** (polling-based, not real-time):
- None native — Zapier polls Google Ads on schedule

**Available actions**:
- Upload offline conversion
- Add/remove user from Customer Match list
- Pause/enable campaign

**Common Zaps**:
```
CRM deal closed → Zapier → Upload offline conversion to Google Ads
Form submission (Typeform) → Zapier → Add to Customer Match list
Spreadsheet row added → Zapier → Create conversion upload
```

### Make (formerly Integromatic)

**20+ modules** for Google Ads:
- Search campaigns, ad groups, ads, keywords
- Create/update campaigns and budgets
- Upload conversions
- Manage audience lists
- Watch for changes (polling, 15-min minimum interval)

**Advantage over Zapier**: Visual scenario builder, better for complex multi-step
automations with conditional logic.

### n8n

**Self-hosted** option for data sovereignty:
- Google Ads node (community maintained)
- GAQL query execution
- Campaign management
- Webhook receiver node for external triggers → Google Ads actions

**Advantage**: No per-execution pricing, full data control, open source.

### Comparison

| Platform | Real-Time Triggers | Actions | Pricing | Best For |
|----------|-------------------|---------|---------|----------|
| Zapier | None (polling) | 5+ | Per-task | Simple, no-code |
| Make | Polling (15min) | 20+ | Per-operation | Complex scenarios |
| n8n | Webhook receiver | 10+ | Self-hosted (free) | Data sovereignty |

---

## MCP for Automation

Model Context Protocol servers enable LLMs to interact with Google Ads:

### Read Operations (Official MCP Server)

```
User: "Pause all campaigns spending more than $100/day with CPA > $50"
LLM → MCP → GAQL query → identifies campaigns → reports back to user
```

Currently read-only. The LLM can analyze and recommend but not execute changes.

### Write Operations (Community MCP)

The `@samihalawa/google-ads-mcp-server` adds write capabilities:
- Pause/enable campaigns
- Update budgets
- Export reports

### Autonomous Monitoring Pattern

```
Cron (every hour):
  → LLM + MCP Server
  → "Check all campaigns. Flag any with CPA > 2x target or budget exhaustion."
  → LLM queries via MCP → analyzes → sends Slack alert if issues found
```

See `ecosystem-tools.md` for MCP server setup details.

---

## Custom Webhook Patterns

Since Google Ads has no native webhooks, build your own:

### Poll → Detect → Dispatch → Act

```python
import requests
from datetime import datetime, timedelta

WEBHOOK_URL = "https://your-app.com/webhooks/google-ads"

def poll_and_dispatch(client, customer_id):
    """Poll for changes and dispatch webhooks."""
    changes = detect_changes(client, customer_id, since_minutes=15)

    for change in changes:
        # Dispatch webhook
        payload = {
            "event": "google_ads.resource_changed",
            "resource_type": change["type"],
            "resource_name": change["resource"],
            "status": change["status"],
            "changed_at": change["changed_at"],
            "detected_at": datetime.utcnow().isoformat(),
        }
        try:
            response = requests.post(WEBHOOK_URL, json=payload, timeout=10)
            response.raise_for_status()
        except requests.RequestException as e:
            print(f"Webhook dispatch failed: {e}")

# Run every 15 minutes via cron or scheduler
```

### Webhook Consumer (FastAPI)

```python
from fastapi import FastAPI, Request

app = FastAPI()

@app.post("/webhooks/google-ads")
async def handle_google_ads_webhook(request: Request):
    payload = await request.json()
    event = payload.get("event")
    resource_type = payload.get("resource_type")

    if event == "google_ads.resource_changed":
        if resource_type == "CAMPAIGN":
            await handle_campaign_change(payload)
        elif resource_type == "AD_GROUP_AD":
            await handle_ad_change(payload)

    return {"status": "ok"}
```

---

## Recommendation Auto-Apply

Google Ads generates optimization recommendations. You can auto-apply safe ones:

### RecommendationSubscriptionService

```python
# Subscribe to auto-apply specific recommendation types
subscription_op = client.get_type("RecommendationSubscriptionOperation")
sub = subscription_op.create
sub.type_ = client.enums.RecommendationTypeEnum.KEYWORD
sub.status = client.enums.RecommendationSubscriptionStatusEnum.ENABLED

recommendation_subscription_service.mutate_recommendation_subscription(
    customer_id=cid, operations=[subscription_op])
```

### Safe to Auto-Apply

| Recommendation Type | Risk | Auto-Apply? |
|--------------------|------|-------------|
| Remove redundant keywords | Low | Yes |
| Fix disapproved ads | Low | Yes |
| Add missing extensions | Low | Yes |
| Upgrade to RSA | Medium | Review first |
| Raise budget | Medium | Only with controls |
| Change bidding strategy | High | No — always review |
| Add broad match keywords | High | No — always review |

### Manual Apply via API

```python
def apply_recommendation(client, customer_id, recommendation_rn):
    """Apply a specific recommendation."""
    recommendation_service = client.get_service("RecommendationService")
    op = client.get_type("ApplyRecommendationOperation")
    op.resource_name = recommendation_rn
    response = recommendation_service.apply_recommendation(
        customer_id=customer_id, operations=[op])
    return response
```

---

## Scheduled Operations

Common operations to schedule via cron, Airflow, or Cloud Functions:

### Budget Management

```python
def adjust_weekend_budgets(client, customer_id, campaign_ids, multiplier=0.7):
    """Reduce budgets on weekends (run Friday evening, restore Monday)."""
    for campaign_id in campaign_ids:
        # Get current budget
        query = f"""
            SELECT campaign.campaign_budget, campaign_budget.amount_micros
            FROM campaign
            WHERE campaign.id = {campaign_id}
        """
        # Adjust budget
        current = get_budget_amount(client, customer_id, campaign_id)
        new_amount = int(current * multiplier)
        update_budget(client, customer_id, campaign_id, new_amount)
```

### Campaign Scheduling

```python
def enable_campaigns_for_event(client, customer_id, campaign_ids):
    """Enable campaigns for a scheduled event (run at event start)."""
    for campaign_id in campaign_ids:
        set_campaign_status(client, customer_id, campaign_id, "ENABLED")

def pause_campaigns_after_event(client, customer_id, campaign_ids):
    """Pause campaigns after event (run at event end)."""
    for campaign_id in campaign_ids:
        set_campaign_status(client, customer_id, campaign_id, "PAUSED")
```

### Customer Match Refresh

```python
def weekly_customer_match_refresh():
    """Refresh Customer Match lists from CRM (run weekly)."""
    # 1. Query CRM for updated customer data
    # 2. Hash PII (SHA-256)
    # 3. Remove all existing members
    # 4. Upload fresh list
    # See first-party-data-strategy.md for complete implementation
    pass
```

---

## Alerting Patterns

Build custom alerts since Google Ads has no built-in webhook alerts:

### Budget Pacing Alert

```python
def check_budget_pacing(client, customer_id, threshold=0.9):
    """Alert if campaign has spent >90% of daily budget before 6 PM."""
    query = """
        SELECT campaign.name, campaign_budget.amount_micros,
               metrics.cost_micros
        FROM campaign
        WHERE campaign.status = 'ENABLED'
          AND segments.date = '2026-02-23'
    """
    stream = ga_service.search_stream(customer_id=customer_id, query=query)
    for batch in stream:
        for row in batch.results:
            budget = row.campaign_budget.amount_micros
            spent = row.metrics.cost_micros
            if budget > 0 and spent / budget > threshold:
                send_alert(f"Campaign '{row.campaign.name}' has spent "
                          f"{spent/budget:.0%} of daily budget")
```

### CPA Spike Alert

```python
def check_cpa_anomaly(client, customer_id, max_cpa_multiplier=2.0):
    """Alert if CPA exceeds 2x target."""
    query = """
        SELECT campaign.name, campaign.target_cpa.target_cpa_micros,
               metrics.cost_micros, metrics.conversions
        FROM campaign
        WHERE campaign.status = 'ENABLED'
          AND campaign.bidding_strategy_type = 'TARGET_CPA'
          AND segments.date DURING LAST_7_DAYS
    """
    # Calculate actual CPA vs target, alert if > threshold
```

### Alert Destinations

| Destination | Method | Best For |
|-------------|--------|----------|
| Slack | Webhook POST | Team notifications |
| Email | SMTP / SES / Elastic Email | Formal alerts |
| PagerDuty | API integration | Critical budget issues |
| Custom dashboard | Database insert | Aggregate monitoring |

---

## Multi-Account (MCC) Automation

### Iterate Child Accounts

```python
def apply_to_all_accounts(client, mcc_id, action_func):
    """Apply an action across all child accounts."""
    children = get_child_account_ids(client, mcc_id)
    results = {}
    for child_id in children:
        try:
            results[child_id] = action_func(client, child_id)
        except GoogleAdsException as ex:
            results[child_id] = {"error": str(ex)}
    return results

# Example: check budget pacing across all accounts
apply_to_all_accounts(client, MCC_ID, check_budget_pacing)
```

### Template Deployment

```python
def deploy_campaign_template(client, mcc_id, template_config):
    """Deploy a campaign template to multiple accounts."""
    children = get_child_account_ids(client, mcc_id)
    for child_id in children:
        # Create campaign from template
        create_campaign_from_template(client, child_id, template_config)
```

### Centralized Reporting

```bash
# gaarf: most efficient for MCC-wide reporting
gaarf queries/*.sql --account=MCC_ID \
  --customer-ids-query="SELECT customer_client.client_customer FROM customer_client WHERE customer_client.level = 1" \
  --output=bq --bq.project=my-project --bq.dataset=mcc_reports
```

See `rate-limits.md` for cross-account rate limiting strategies.

---

## Adjacent Webhooks

While Google Ads lacks webhooks, adjacent Google products DO have push notifications:

### Merchant Center (Product Status)

Google Merchant Center supports push notifications for:
- Product disapprovals
- Feed processing errors
- Account-level warnings

Configure via Merchant Center API or UI.

### GA4 (BigQuery Streaming)

GA4 can stream events to BigQuery in near real-time:
- Use BigQuery subscriptions or Cloud Functions triggers
- React to conversion events as they arrive in BigQuery
- Upload to Google Ads as offline conversions

### Lead Form Extensions (Google Sheets)

Google Ads Lead Form Extensions can auto-export leads to Google Sheets:
- Configure in Google Ads UI → Extensions → Lead Forms → Export
- Use Sheets triggers (Apps Script) to react to new rows
- Forward to CRM or trigger conversion uploads

### Google Cloud Pub/Sub

For custom event-driven architecture:
1. Poll Google Ads changes
2. Publish to Pub/Sub topic
3. Cloud Functions subscribe and process
4. Enables fan-out to multiple downstream systems

---

## Cross-References

- **Change tracking GAQL queries** → `analytics-reporting.md` §13
- **Conversion upload code** → `automation-and-reporting.md` §4-6
- **Data Manager API automation** → `first-party-data-strategy.md` §2
- **Rate limits for polling** → `rate-limits.md`
- **iPaaS and MCP tools** → `ecosystem-tools.md`
- **Scripts vs API comparison** → `ecosystem-tools.md` §2 (Apps Script)
- **Customer Match refresh** → `audiences-targeting.md` §3
