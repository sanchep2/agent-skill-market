#!/usr/bin/env python3
"""
google_ads_helper.py — Reusable helper functions for Google Ads API operations.

Usage:
    from google_ads_helper import GoogleAdsHelper
    helper = GoogleAdsHelper("path/to/google-ads.yaml")
    df = helper.query_to_dataframe("1234567890", "SELECT campaign.name FROM campaign")

Or as CLI:
    python google_ads_helper.py --config google-ads.yaml --account 1234567890 \
        --query "SELECT campaign.name, metrics.clicks FROM campaign WHERE segments.date DURING LAST_7_DAYS" \
        --output report.csv
"""

import argparse
import csv
import json
import sys
import time
import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Generic, Optional, Callable, TypeVar

try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False

from google.ads.googleads.client import GoogleAdsClient
from google.ads.googleads.errors import GoogleAdsException


# === Typed request/response models ===

# Generic payload type for a typed API result envelope. Lets callers keep the concrete
# payload type (e.g. UploadResult, a dict, a DataFrame) while sharing the ok/error contract.
T = TypeVar("T")


@dataclass
class UploadResult:
    """Typed result of a first-party-data upload (conversions / customer match).

    Replaces the loose ``{"success_count": ..., "failure_count": ...}`` dict at call sites
    that want static typing; the existing methods still return dicts for backward compat and
    can be wrapped with ``UploadResult(**result_dict)``.
    """
    success_count: int = 0
    failure_count: int = 0
    job_resource_name: Optional[str] = None
    errors: list = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.failure_count == 0


@dataclass
class ApiResult(Generic[T]):
    """Generic ok/error envelope for a typed helper call.

    ``ApiResult[UploadResult]`` or ``ApiResult[list]`` keeps the payload type precise while
    sharing one success/error contract across query and mutate helpers.
    """
    ok: bool
    data: Optional[T] = None
    error: Optional[str] = None


# === CircuitBreaker Pattern ===


class CircuitBreakerState(Enum):
    """Estados del circuit breaker."""
    CLOSED = "closed"          # Normal: llamadas pasan
    OPEN = "open"              # Fallando: llamadas rechazadas
    HALF_OPEN = "half_open"    # Probando recuperación


class CircuitBreakerOpenError(Exception):
    """Se lanza cuando el circuit breaker está abierto y rechaza llamadas."""
    pass


class CircuitBreaker:
    """
    Implementación del patrón Circuit Breaker para proteger contra fallos en cascada.

    Flujo: CLOSED → (fallos >= threshold) → OPEN → (timeout) → HALF_OPEN → (éxito) → CLOSED
                                                                           → (fallo) → OPEN

    Uso standalone:
        cb = CircuitBreaker(failure_threshold=5, recovery_timeout=60)
        result = cb.call(lambda: api_call())

    Uso como decorador:
        @circuit_breaker(failure_threshold=3, recovery_timeout=30)
        def my_api_call():
            ...
    """

    def __init__(self, failure_threshold: int = 5, recovery_timeout: float = 60.0,
                 half_open_max_calls: int = 3, name: str = "default"):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.half_open_max_calls = half_open_max_calls
        self.name = name

        self._state = CircuitBreakerState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._half_open_calls = 0
        self._last_failure_time = 0.0
        self._last_state_change = time.time()

    @property
    def state(self) -> CircuitBreakerState:
        """Estado actual, con transición automática de OPEN → HALF_OPEN si pasó el timeout."""
        if self._state == CircuitBreakerState.OPEN:
            if time.time() - self._last_failure_time >= self.recovery_timeout:
                self._try_recovery()
        return self._state

    def call(self, func: Callable, *args, **kwargs):
        """
        Ejecuta la función a través del circuit breaker.
        Lanza CircuitBreakerOpenError si el circuito está abierto.
        """
        current_state = self.state

        if current_state == CircuitBreakerState.OPEN:
            raise CircuitBreakerOpenError(
                f"CircuitBreaker '{self.name}' abierto. "
                f"{self._failure_count} fallos consecutivos. "
                f"Reintento en {self._time_until_recovery():.0f}s"
            )

        if current_state == CircuitBreakerState.HALF_OPEN:
            if self._half_open_calls >= self.half_open_max_calls:
                raise CircuitBreakerOpenError(
                    f"CircuitBreaker '{self.name}' half-open: máximo de pruebas alcanzado"
                )
            self._half_open_calls += 1

        try:
            result = func(*args, **kwargs)
            self._record_success()
            return result
        except Exception as exc:
            self._record_failure()
            raise exc

    def _record_success(self):
        """Registra un éxito. En HALF_OPEN, cierra el circuito tras suficientes éxitos."""
        self._failure_count = 0
        self._success_count += 1
        if self._state == CircuitBreakerState.HALF_OPEN:
            if self._success_count >= self.half_open_max_calls:
                self._transition_to_closed()

    def _record_failure(self):
        """Registra un fallo. Abre el circuito si se supera el threshold."""
        self._failure_count += 1
        self._success_count = 0
        self._last_failure_time = time.time()
        if self._failure_count >= self.failure_threshold:
            self._transition_to_open()

    def _transition_to_open(self):
        """Transición a estado OPEN: rechaza todas las llamadas."""
        self._state = CircuitBreakerState.OPEN
        self._last_state_change = time.time()
        print(f"CircuitBreaker '{self.name}': OPEN (fallos={self._failure_count})",
              file=sys.stderr)

    def _transition_to_closed(self):
        """Transición a estado CLOSED: operación normal."""
        self._state = CircuitBreakerState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._half_open_calls = 0
        self._last_state_change = time.time()
        print(f"CircuitBreaker '{self.name}': CLOSED (recuperado)", file=sys.stderr)

    def _try_recovery(self):
        """Transición de OPEN → HALF_OPEN para probar si el servicio se recuperó."""
        self._state = CircuitBreakerState.HALF_OPEN
        self._half_open_calls = 0
        self._success_count = 0
        self._last_state_change = time.time()
        print(f"CircuitBreaker '{self.name}': HALF_OPEN (probando recuperación)",
              file=sys.stderr)

    def _time_until_recovery(self) -> float:
        """Tiempo restante hasta que el circuit breaker intente recuperarse."""
        elapsed = time.time() - self._last_failure_time
        remaining = self.recovery_timeout - elapsed
        return max(0.0, remaining)

    def get_status(self) -> dict:
        """Retorna el estado actual del circuit breaker como dict."""
        return {
            "name": self.name,
            "state": self.state.value,
            "failure_count": self._failure_count,
            "success_count": self._success_count,
            "time_until_recovery": self._time_until_recovery() if self._state == CircuitBreakerState.OPEN else 0,
            "last_state_change": self._last_state_change,
        }


def circuit_breaker(failure_threshold: int = 5, recovery_timeout: float = 60.0,
                    half_open_max_calls: int = 3, name: str = ""):
    """
    Decorador para proteger una función con circuit breaker.

    Uso:
        @circuit_breaker(failure_threshold=3, recovery_timeout=30)
        def llamar_api_externa():
            ...
    """
    def decorator(func):
        cb_name = name or f"{func.__module__}.{func.__qualname__}"
        cb = CircuitBreaker(
            failure_threshold=failure_threshold,
            recovery_timeout=recovery_timeout,
            half_open_max_calls=half_open_max_calls,
            name=cb_name,
        )
        func._circuit_breaker = cb

        def wrapper(*args, **kwargs):
            return cb.call(func, *args, **kwargs)
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        wrapper._circuit_breaker = cb
        return wrapper
    return decorator


# === GAQL Query Builder ===


class GAQLBuilder:
    """
    Constructor fluido de consultas GAQL para Google Ads API.

    Uso:
        query = (GAQLBuilder()
            .select("campaign.name", "metrics.clicks", "metrics.impressions")
            .from_resource("campaign")
            .where("campaign.status = 'ENABLED'")
            .during("LAST_7_DAYS")
            .order_by("metrics.clicks", descending=True)
            .limit(100)
            .build())
    """

    # Rangos de fecha predefinidos de GAQL
    LAST_7_DAYS = "LAST_7_DAYS"
    LAST_14_DAYS = "LAST_14_DAYS"
    LAST_30_DAYS = "LAST_30_DAYS"
    THIS_MONTH = "THIS_MONTH"
    LAST_MONTH = "LAST_MONTH"
    THIS_QUARTER = "THIS_QUARTER"
    LAST_QUARTER = "LAST_QUARTER"
    THIS_YEAR = "THIS_YEAR"
    LAST_YEAR = "LAST_YEAR"
    TODAY = "TODAY"
    YESTERDAY = "YESTERDAY"
    LAST_BUSINESS_WEEK = "LAST_BUSINESS_WEEK"

    def __init__(self):
        self._fields: list = []
        self._resource: str = ""
        self._conditions: list = []
        self._date_range: str = ""
        self._custom_date_start: str = ""
        self._custom_date_end: str = ""
        self._order_field: str = ""
        self._order_desc: bool = False
        self._limit_value: int = 0

    def select(self, *fields: str) -> "GAQLBuilder":
        """Agrega campos al SELECT."""
        self._fields.extend(fields)
        return self

    def from_resource(self, resource: str) -> "GAQLBuilder":
        """Define el recurso (FROM)."""
        self._resource = resource
        return self

    def where(self, condition: str) -> "GAQLBuilder":
        """Agrega una condición WHERE (se combinan con AND)."""
        self._conditions.append(condition)
        return self

    def during(self, date_range: str) -> "GAQLBuilder":
        """Aplica un rango de fecha predefinido (LAST_7_DAYS, THIS_MONTH, etc.)."""
        self._date_range = date_range
        return self

    def date_between(self, start_date: str, end_date: str) -> "GAQLBuilder":
        """
        Rango de fecha personalizado.
        Formato: 'YYYY-MM-DD'
        Agrega segments.date al WHERE con BETWEEN.
        """
        self._custom_date_start = start_date
        self._custom_date_end = end_date
        return self

    def order_by(self, field: str, descending: bool = False) -> "GAQLBuilder":
        """Define el campo de ordenamiento."""
        self._order_field = field
        self._order_desc = descending
        return self

    def limit(self, n: int) -> "GAQLBuilder":
        """Limita el número de resultados."""
        self._limit_value = n
        return self

    def build(self) -> str:
        """Construye y retorna la consulta GAQL como string."""
        if not self._fields:
            raise ValueError("SELECT requiere al menos un campo")
        if not self._resource:
            raise ValueError("FROM requiere un recurso")

        parts = [f"SELECT {', '.join(self._fields)}"]
        parts.append(f"FROM {self._resource}")

        all_conditions = list(self._conditions)
        if self._custom_date_start and self._custom_date_end:
            all_conditions.append(
                f"segments.date BETWEEN '{self._custom_date_start}' AND '{self._custom_date_end}'"
            )

        if all_conditions:
            parts.append(f"WHERE {' AND '.join(all_conditions)}")

        if self._date_range:
            parts.append(f"DURING {self._date_range}")

        if self._order_field:
            direction = "DESC" if self._order_desc else "ASC"
            parts.append(f"ORDER BY {self._order_field} {direction}")

        if self._limit_value > 0:
            parts.append(f"LIMIT {self._limit_value}")

        return " ".join(parts)

    # === Consultas Preset ===

    @staticmethod
    def campaign_performance(status_filter: str = "ENABLED",
                              date_range: str = "LAST_30_DAYS") -> str:
        """Query preset: rendimiento de campañas."""
        return (GAQLBuilder()
                .select("campaign.id", "campaign.name", "campaign.status",
                        "campaign.advertising_channel_type",
                        "metrics.impressions", "metrics.clicks", "metrics.ctr",
                        "metrics.average_cpc", "metrics.cost_micros",
                        "metrics.conversions", "metrics.cost_per_conversion")
                .from_resource("campaign")
                .where(f"campaign.status = '{status_filter}'")
                .during(date_range)
                .order_by("metrics.cost_micros", descending=True)
                .build())

    @staticmethod
    def adgroup_performance(campaign_id: Optional[str] = None,
                             date_range: str = "LAST_30_DAYS") -> str:
        """Query preset: rendimiento de grupos de anuncios."""
        builder = (GAQLBuilder()
                   .select("ad_group.id", "ad_group.name", "ad_group.status",
                           "campaign.name",
                           "metrics.impressions", "metrics.clicks", "metrics.ctr",
                           "metrics.average_cpc", "metrics.cost_micros",
                           "metrics.conversions", "metrics.cost_per_conversion")
                   .from_resource("ad_group")
                   .where("ad_group.status = 'ENABLED'")
                   .during(date_range))
        if campaign_id:
            builder.where(f"campaign.id = {campaign_id}")
        return builder.build()

    @staticmethod
    def keyword_performance(campaign_id: Optional[str] = None,
                             date_range: str = "LAST_30_DAYS") -> str:
        """Query preset: rendimiento de keywords."""
        builder = (GAQLBuilder()
                   .select("ad_group_criterion.keyword.text",
                           "ad_group_criterion.keyword.match_type",
                           "ad_group.name", "campaign.name",
                           "metrics.impressions", "metrics.clicks", "metrics.ctr",
                           "metrics.average_cpc", "metrics.cost_micros",
                           "metrics.conversions", "metrics.search_impression_share")
                   .from_resource("keyword_view")
                   .where("ad_group_criterion.status = 'ENABLED'")
                   .during(date_range)
                   .order_by("metrics.impressions", descending=True))
        if campaign_id:
            builder.where(f"campaign.id = {campaign_id}")
        return builder.build()

    @staticmethod
    def search_terms_report(campaign_id: Optional[str] = None,
                             date_range: str = "LAST_30_DAYS") -> str:
        """Query preset: términos de búsqueda."""
        builder = (GAQLBuilder()
                   .select("search_term_view.search_term",
                           "search_term_view.status",
                           "campaign.name", "ad_group.name",
                           "metrics.impressions", "metrics.clicks",
                           "metrics.cost_micros", "metrics.conversions")
                   .from_resource("search_term_view")
                   .during(date_range)
                   .order_by("metrics.impressions", descending=True)
                   .limit(1000))
        if campaign_id:
            builder.where(f"campaign.id = {campaign_id}")
        return builder.build()


# === Error Classification ===

# Códigos de error que pueden resolverse con reintentos
RETRYABLE_ERROR_CODES = {
    "internal_error",
    "transient_error",
    "resource_exhausted",
}

# Códigos de error permanentes que no se resuelven con reintentos
PERMANENT_ERROR_CODES = {
    "authorization_error",
    "authentication_error",
    "request_error",
    "field_error",
    "mutate_error",
    "policy_violation_error",
    "setting_error",
    "range_error",
    "not_allowlisted_error",
}


def classify_error(exception: GoogleAdsException) -> dict:
    """
    Clasifica un error de Google Ads API y retorna información útil.

    Retorna dict con:
      - is_retryable: bool — si vale la pena reintentar
      - error_type: str — tipo principal del error
      - error_codes: list — todos los códigos detectados
      - messages: list — mensajes legibles de cada error
      - recommended_action: str — sugerencia de acción a tomar
    """
    error_codes = []
    messages = []
    is_retryable = False

    for error in exception.failure.errors:
        error_code = error.error_code
        msg = error.message

        # Detectar qué campo tiene el código
        detected_code = "unknown_error"
        for code_field in list(RETRYABLE_ERROR_CODES) + list(PERMANENT_ERROR_CODES):
            try:
                if error_code.HasField(code_field):
                    detected_code = code_field
                    break
            except ValueError:
                continue

        error_codes.append(detected_code)
        messages.append(msg)

        if detected_code in RETRYABLE_ERROR_CODES:
            is_retryable = True

    # Determinar tipo principal (el primero)
    primary_type = error_codes[0] if error_codes else "unknown_error"

    # Sugerencia de acción
    action_map = {
        "internal_error": "Reintentar con backoff exponencial (error interno de Google)",
        "transient_error": "Reintentar en unos segundos (error transitorio)",
        "resource_exhausted": "Reducir frecuencia de llamadas o solicitar aumento de cuota",
        "authorization_error": "Verificar permisos de la cuenta y nivel de acceso",
        "authentication_error": "Renovar tokens OAuth o verificar credenciales",
        "request_error": "Corregir la estructura de la solicitud (parámetros inválidos)",
        "field_error": "Corregir valores de campos en la solicitud",
        "mutate_error": "Verificar la operación de mutación y restricciones de la entidad",
        "policy_violation_error": "El contenido viola políticas de Google Ads — revisar creativos",
        "setting_error": "Configuración inválida — verificar settings de campaña/cuenta",
        "range_error": "Valor fuera de rango permitido — verificar límites",
        "not_allowlisted_error": "Feature no habilitado para esta cuenta — contactar soporte",
        "unknown_error": "Error no clasificado — revisar logs y documentación",
    }

    return {
        "is_retryable": is_retryable,
        "error_type": primary_type,
        "error_codes": error_codes,
        "messages": messages,
        "recommended_action": action_map.get(primary_type, action_map["unknown_error"]),
        "request_id": exception.request_id,
    }


def get_quota_error_details(exception: GoogleAdsException) -> Optional[dict]:
    """
    Extrae detalles específicos de errores de cuota (resource_exhausted).

    Retorna None si el error no es de cuota.
    Retorna dict con rate_scope, retry_delay_seconds, y descripción.
    """
    for error in exception.failure.errors:
        try:
            if not error.error_code.HasField("resource_exhausted"):
                continue
        except ValueError:
            continue

        details = {
            "error_message": error.message,
            "rate_scope": "unknown",
            "retry_delay_seconds": 30,
            "description": "Cuota excedida en Google Ads API",
        }

        msg_lower = error.message.lower()
        if "per-customer" in msg_lower or "per customer" in msg_lower:
            details["rate_scope"] = "per_customer"
            details["retry_delay_seconds"] = 60
            details["description"] = "Cuota por cuenta de cliente excedida"
        elif "per-developer" in msg_lower or "developer token" in msg_lower:
            details["rate_scope"] = "per_developer"
            details["retry_delay_seconds"] = 120
            details["description"] = "Cuota del developer token excedida"
        elif "mutate" in msg_lower:
            details["rate_scope"] = "mutate_operations"
            details["retry_delay_seconds"] = 30
            details["description"] = "Límite de operaciones de mutación excedido"
        elif "report" in msg_lower or "search" in msg_lower:
            details["rate_scope"] = "reporting"
            details["retry_delay_seconds"] = 15
            details["description"] = "Límite de consultas de reporting excedido"

        return details

    return None


class GoogleAdsHelper:
    """High-level wrapper around the Google Ads API Python client."""

    def __init__(self, config_path: Optional[str] = None, config_dict: Optional[dict] = None,
                 circuit_breaker_config: Optional[dict] = None):
        if config_dict:
            self.client = GoogleAdsClient.load_from_dict(config_dict)
        elif config_path:
            self.client = GoogleAdsClient.load_from_storage(config_path)
        else:
            self.client = GoogleAdsClient.load_from_env()
        self.ga_service = self.client.get_service("GoogleAdsService")

        # Circuit breaker integrado para proteger contra fallos en cascada
        cb_config = circuit_breaker_config or {}
        self._circuit_breaker = CircuitBreaker(
            failure_threshold=cb_config.get("failure_threshold", 5),
            recovery_timeout=cb_config.get("recovery_timeout", 60.0),
            half_open_max_calls=cb_config.get("half_open_max_calls", 3),
            name=cb_config.get("name", "google-ads-api"),
        )

    def search_stream(self, customer_id: str, query: str):
        """Execute a GAQL query via SearchStream. Yields dicts."""
        customer_id = customer_id.replace("-", "")
        stream = self.ga_service.search_stream(customer_id=customer_id, query=query)
        for batch in stream:
            for row in batch.results:
                yield self._row_to_dict(row)

    def query_to_list(self, customer_id: str, query: str) -> list:
        """Execute a GAQL query and return a list of dicts."""
        return list(self.search_stream(customer_id, query))

    def query_to_dataframe(self, customer_id: str, query: str):
        """Execute a GAQL query and return a pandas DataFrame."""
        if not HAS_PANDAS:
            raise ImportError("pandas is required: pip install pandas")
        rows = self.query_to_list(customer_id, query)
        return pd.DataFrame(rows) if rows else pd.DataFrame()

    def mutate(self, customer_id: str, operations: list, partial_failure: bool = True):
        """Execute mutate operations with retry logic."""
        customer_id = customer_id.replace("-", "")
        return self._retry(
            lambda: self.ga_service.mutate(
                customer_id=customer_id,
                mutate_operations=operations,
                partial_failure=partial_failure))

    def list_accessible_customers(self) -> list:
        """List all customer IDs accessible with current credentials."""
        customer_service = self.client.get_service("CustomerService")
        response = customer_service.list_accessible_customers()
        return [rn.replace("customers/", "") for rn in response.resource_names]

    def get_account_hierarchy(self, mcc_id: str) -> list:
        """Get all child accounts under an MCC."""
        query = """
            SELECT customer_client.client_customer,
                   customer_client.descriptive_name,
                   customer_client.manager,
                   customer_client.level,
                   customer_client.status
            FROM customer_client
            WHERE customer_client.level <= 1
              AND customer_client.status = 'ENABLED'
        """
        results = self.query_to_list(mcc_id, query)
        return results

    def cross_account_query(self, mcc_id: str, query: str) -> list:
        """Run a GAQL query across all non-manager accounts under an MCC."""
        accounts = self.get_account_hierarchy(mcc_id)
        all_results = []
        for account in accounts:
            if account.get("customer_client.manager"):
                continue
            cid = str(account.get("customer_client.client_customer", "")).replace("customers/", "")
            if not cid:
                continue
            try:
                rows = self.query_to_list(cid, query)
                for row in rows:
                    row["_account_id"] = cid
                    row["_account_name"] = account.get("customer_client.descriptive_name", "")
                all_results.extend(rows)
            except GoogleAdsException as ex:
                print(f"Warning: Error on account {cid}: {ex.failure.errors[0].message}",
                      file=sys.stderr)
        return all_results

    def _row_to_dict(self, row) -> dict:
        """Convert a protobuf row to a flat dict using field paths as keys."""
        d = {}
        self._extract_fields(row, "", d)
        return d

    def _extract_fields(self, obj, prefix: str, result: dict):
        """Recursively extract fields from protobuf objects."""
        if hasattr(obj, "DESCRIPTOR"):
            for field in obj.DESCRIPTOR.fields:
                value = getattr(obj, field.name, None)
                key = f"{prefix}.{field.name}" if prefix else field.name
                if hasattr(value, "DESCRIPTOR"):
                    self._extract_fields(value, key, result)
                elif value is not None and value != 0 and value != "" and value != []:
                    # Convert enums to name
                    if hasattr(value, "name") and hasattr(value, "value"):
                        result[key] = value.name
                    else:
                        result[key] = value

    def _retry(self, func, max_retries=5, base_delay=5.0):
        """Retry with exponential backoff for transient errors, protegido por circuit breaker."""
        def _inner():
            for attempt in range(max_retries):
                try:
                    return func()
                except GoogleAdsException as ex:
                    retryable = any(
                        error.error_code.HasField("internal_error") or
                        error.error_code.HasField("transient_error")
                        for error in ex.failure.errors
                    )
                    if not retryable or attempt == max_retries - 1:
                        raise
                    delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
                    print(f"Retry {attempt + 1}/{max_retries} in {delay:.1f}s...",
                          file=sys.stderr)
                    time.sleep(delay)
        return self._circuit_breaker.call(_inner)

    def get_circuit_breaker_status(self) -> dict:
        """Retorna el estado actual del circuit breaker integrado."""
        return self._circuit_breaker.get_status()

    # === First-Party Data Methods ===

    @staticmethod
    def normalize_and_hash(value: str) -> str:
        """Normalize (lowercase, trim) and SHA-256 hash a value."""
        import hashlib
        return hashlib.sha256(value.strip().lower().encode("utf-8")).hexdigest()

    @staticmethod
    def normalize_and_hash_email(email: str) -> str:
        """Normalize email and SHA-256 hash. Handles gmail dot removal."""
        import hashlib
        email = email.strip().lower()
        parts = email.split("@")
        if len(parts) == 2 and parts[1] in ("gmail.com", "googlemail.com"):
            parts[0] = parts[0].replace(".", "")
        return hashlib.sha256("@".join(parts).encode("utf-8")).hexdigest()

    def _get_partial_failure_errors(self, partial_failure_error) -> list:
        """Deserialize a partial_failure_error (google.rpc.Status) into its flat list of
        GoogleAdsError entries. Returns [] when code == 0 (no failure) — this field is always
        present on the response (proto3 default), so truthiness/presence alone is NOT a valid
        failure check; you must check `.code != 0`, per Google's own
        is_partial_failure_error_present in examples/error_handling/handle_partial_failure.py.

        google.ads.googleads.util.get_all_errors() does NOT exist in the google-ads Python client
        (verified against 31.1.0) — deserialize `.details` into GoogleAdsFailure directly, per
        Google's official example.

        Deserialization branches on `self.client.use_proto_plus`: with the default `True`,
        `client.get_type(...)` returns a proto-plus-wrapped message and `.deserialize()` is a
        classmethod. With `use_proto_plus=False` (SKILL.md's own performance tip for high-volume
        scenarios — e.g. Customer Match bulk uploads), `client.get_type(...)` returns a NATIVE
        protobuf message instead (`util.convert_proto_plus_to_protobuf` inside the client), which
        has no `deserialize()` — it's parsed in place via `ParseFromString()`.
        """
        code = int(getattr(partial_failure_error, "code", 0) or 0)
        if code == 0:
            return []

        errors = []
        for detail in partial_failure_error.details:
            if self.client.use_proto_plus:
                failure_type = type(self.client.get_type("GoogleAdsFailure"))
                failure = failure_type.deserialize(detail.value)
            else:
                failure = self.client.get_type("GoogleAdsFailure")
                failure.ParseFromString(detail.value)
            errors.extend(failure.errors)
        return errors

    def _count_rejected_operations(self, partial_failure_error) -> int:
        """Count DISTINCT rejected operations from a partial_failure_error.

        A single failed operation can produce MULTIPLE GoogleAdsError entries (e.g. several field
        validations failing at once) that all share the same
        `error.location.field_path_elements[0].index` — so this counts DISTINCT indices, not raw
        error count (counting raw errors overcounts rejected operations and can drive
        success_count negative).
        """
        errors = self._get_partial_failure_errors(partial_failure_error)
        return len({error.location.field_path_elements[0].index for error in errors})

    def upload_enhanced_conversions(self, customer_id: str, conversion_action_id: str,
                                     conversions_data: list, batch_size: int = 2000) -> dict:
        """
        Upload enhanced conversions with hashed user identifiers.

        conversions_data: list of dicts with keys:
          conversion_time (required), conversion_value (required),
          ad_user_data_consent (required, bool), ad_personalization_consent (required, bool),
          email, phone, first_name, last_name (at least email recommended),
          gclid (optional), order_id (optional), currency_code (default USD)

        Consent is per-conversion here (Consent Mode V2) — ClickConversion legitimately carries its
        own consent, unlike Customer Match (see upload_customer_match). A record missing either
        consent key is excluded from the upload and counted in failure_count; consent is never
        assumed GRANTED by default.

        Returns dict with success_count and failure_count (wrap in UploadResult(**...) for a
        typed result).

        GATING (last_verified: 2026-07-17): this method uses ConversionUploadService, which is
        allowlist-gated since June 15, 2026 for developer tokens without recent first-party-data
        activity — a blocked call fails with CUSTOMER_NOT_ALLOWLISTED_FOR_THIS_FEATURE. This helper
        is retained for existing/allowlisted integrations; NEW integrations must route uploads
        through the Data Manager API instead (see references/first-party-data-strategy.md).
        """
        customer_id = customer_id.replace("-", "")
        service = self.client.get_service("ConversionUploadService")
        total_success = 0
        total_failure = 0

        for i in range(0, len(conversions_data), batch_size):
            batch = conversions_data[i:i + batch_size]
            click_conversions = []

            for conv in batch:
                user_data_consent = conv.get("ad_user_data_consent")
                personalization_consent = conv.get("ad_personalization_consent")
                # Strict bool check: truthiness/presence alone lets a stray "false" (string) or
                # 1 (int) through as GRANTED — only literal True/False is ever accepted.
                if not isinstance(user_data_consent, bool) or not isinstance(personalization_consent, bool):
                    total_failure += 1
                    print(f"Skipping conversion (consent must be a strict bool, got "
                          f"{user_data_consent!r}/{personalization_consent!r}): "
                          f"{conv.get('order_id', '?')}", file=sys.stderr)
                    continue

                cc = self.client.get_type("ClickConversion")
                cc.conversion_action = self.client.get_service(
                    "ConversionActionService").conversion_action_path(
                    customer_id, conversion_action_id)
                cc.conversion_date_time = conv["conversion_time"]
                cc.conversion_value = conv["conversion_value"]
                cc.currency_code = conv.get("currency_code", "USD")

                if "gclid" in conv:
                    cc.gclid = conv["gclid"]
                if "order_id" in conv:
                    cc.order_id = conv["order_id"]

                if "email" in conv:
                    ui = cc.user_identifiers.add()
                    ui.hashed_email = self.normalize_and_hash_email(conv["email"])
                if "phone" in conv:
                    ui = cc.user_identifiers.add()
                    ui.hashed_phone_number = self.normalize_and_hash(conv["phone"])
                if "first_name" in conv or "last_name" in conv:
                    ui = cc.user_identifiers.add()
                    if "first_name" in conv:
                        ui.address_info.hashed_first_name = self.normalize_and_hash(conv["first_name"])
                    if "last_name" in conv:
                        ui.address_info.hashed_last_name = self.normalize_and_hash(conv["last_name"])

                cc.consent.ad_user_data = (
                    self.client.enums.ConsentStatusEnum.GRANTED
                    if user_data_consent
                    else self.client.enums.ConsentStatusEnum.DENIED
                )
                cc.consent.ad_personalization = (
                    self.client.enums.ConsentStatusEnum.GRANTED
                    if personalization_consent
                    else self.client.enums.ConsentStatusEnum.DENIED
                )
                click_conversions.append(cc)

            if not click_conversions:
                # Every conversion in this batch was excluded (missing/invalid consent) — don't
                # call the service with an empty operations list.
                continue

            response = service.upload_click_conversions(
                customer_id=customer_id, conversions=click_conversions,
                partial_failure=True)

            rejected_count = self._count_rejected_operations(response.partial_failure_error)
            total_success += len(click_conversions) - rejected_count
            total_failure += rejected_count

        return {"success_count": total_success, "failure_count": total_failure}

    def upload_customer_match(self, customer_id: str, user_list_resource_name: str,
                               records: list, consent: dict, batch_size: int = 10000) -> dict:
        """
        Upload hashed customer data to a Customer Match list (create-only).

        records: list of dicts with keys:
          email (recommended), phone, first_name, last_name,
          country_code, postal_code

        consent (required): {"ad_user_data": bool, "ad_personalization": bool}. Customer Match sets
        consent ONCE per job (customer_match_user_list_metadata.consent) — NOT per record, unlike
        upload_enhanced_conversions. Both flags must be True: Google rejects a job create where
        either flag is DENIED with OfflineUserDataJobError.CUSTOMER_NOT_ACCEPTED_CUSTOMER_DATA_TERMS
        — there is no valid "upload with DENIED" path for a create. If some users haven't consented,
        exclude them from `records` entirely (this helper only creates; modeling a revocation/removal
        is a distinct `remove` operation, out of scope here).

        Returns dict with success_count / failure_count — operations ACCEPTED vs REJECTED when
        adding them to the job (partial_failure_error on AddOfflineUserDataJobOperations), NOT the
        final Customer Match processing/match-rate result, which is only knowable by polling job
        status separately — and job_resource_name. Wrap in UploadResult(**result) for a typed result.

        GATING (last_verified: 2026-07-17): this method uses OfflineUserDataJobService, which is
        allowlist-gated since April 1, 2026 for developer tokens without recent Customer Match
        activity (blocked calls fail with CUSTOMER_NOT_ALLOWLISTED_FOR_THIS_FEATURE). Retained for
        existing/allowlisted integrations; NEW integrations must upload Customer Match audiences via
        the Data Manager API instead (see references/first-party-data-strategy.md).
        """
        # Strict bool check: `is not True` rejects 1, "false" (string), None, etc. — only literal
        # True is ever accepted, since Customer Match has no valid DENIED path for a create.
        if consent.get("ad_user_data") is not True or consent.get("ad_personalization") is not True:
            raise ValueError(
                "upload_customer_match requires consent={'ad_user_data': True, "
                "'ad_personalization': True} as strict booleans — got "
                f"{consent.get('ad_user_data')!r}/{consent.get('ad_personalization')!r}. Customer "
                "Match rejects a job create with either flag not True "
                "(CUSTOMER_NOT_ACCEPTED_CUSTOMER_DATA_TERMS). Exclude non-consenting users from "
                "`records` instead of passing a falsy/non-bool consent flag."
            )

        customer_id = customer_id.replace("-", "")
        job_service = self.client.get_service("OfflineUserDataJobService")

        job = job_service.create_offline_user_data_job(
            customer_id=customer_id,
            job={
                "type_": self.client.enums.OfflineUserDataJobTypeEnum.CUSTOMER_MATCH_USER_LIST,
                "customer_match_user_list_metadata": {
                    "user_list": user_list_resource_name,
                    "consent": {
                        "ad_user_data": self.client.enums.ConsentStatusEnum.GRANTED,
                        "ad_personalization": self.client.enums.ConsentStatusEnum.GRANTED,
                    },
                }
            })

        total_added = 0
        total_rejected = 0

        for i in range(0, len(records), batch_size):
            batch = records[i:i + batch_size]
            ops = []
            for record in batch:
                op = self.client.get_type("OfflineUserDataJobOperation")

                if "email" in record:
                    ui = op.create.user_identifiers.add()
                    ui.hashed_email = self.normalize_and_hash_email(record["email"])
                if "phone" in record:
                    ui = op.create.user_identifiers.add()
                    ui.hashed_phone_number = self.normalize_and_hash(record["phone"])
                if "first_name" in record or "last_name" in record:
                    ui = op.create.user_identifiers.add()
                    if "first_name" in record:
                        ui.address_info.hashed_first_name = self.normalize_and_hash(record["first_name"])
                    if "last_name" in record:
                        ui.address_info.hashed_last_name = self.normalize_and_hash(record["last_name"])
                    if "country_code" in record:
                        ui.address_info.country_code = record["country_code"]
                    if "postal_code" in record:
                        ui.address_info.postal_code = record["postal_code"]

                ops.append(op)

            # enable_partial_failure: rejected operations land in partial_failure_error instead of
            # throwing and discarding the whole batch — see partial-failures best practices.
            add_response = job_service.add_offline_user_data_job_operations(
                resource_name=job.resource_name, operations=ops, enable_partial_failure=True)

            batch_rejected = self._count_rejected_operations(add_response.partial_failure_error)
            total_rejected += batch_rejected
            total_added += len(ops) - batch_rejected

            print(f"Added {len(ops) - batch_rejected}/{len(ops)} records (batch {i // batch_size + 1})",
                  file=sys.stderr)

        job_service.run_offline_user_data_job(resource_name=job.resource_name)
        print(f"Job started: {job.resource_name}", file=sys.stderr)

        return {
            "success_count": total_added,
            "failure_count": total_rejected,
            "job_resource_name": job.resource_name,
        }

    def adjust_conversions(self, customer_id: str, adjustments_data: list) -> dict:
        """
        Upload conversion adjustments (restatements or retractions).

        adjustments_data: list of dicts with keys:
          conversion_action_id, gclid, original_conversion_time,
          adjustment_type ("RESTATEMENT" or "RETRACTION"),
          new_value (required for RESTATEMENT), currency_code (default USD),
          order_id (alternative to gclid for enhanced conversions)

        Returns dict with success_count and failure_count.
        """
        customer_id = customer_id.replace("-", "")
        service = self.client.get_service("ConversionAdjustmentUploadService")
        adjustments = []

        for adj in adjustments_data:
            adjustment = self.client.get_type("ConversionAdjustment")
            adjustment.conversion_action = self.client.get_service(
                "ConversionActionService").conversion_action_path(
                customer_id, adj["conversion_action_id"])
            adjustment.adjustment_type = getattr(
                self.client.enums.ConversionAdjustmentTypeEnum, adj["adjustment_type"])

            if "gclid" in adj:
                adjustment.gclid_date_time_pair.gclid = adj["gclid"]
                adjustment.gclid_date_time_pair.conversion_date_time = adj["original_conversion_time"]
            elif "order_id" in adj:
                adjustment.order_id = adj["order_id"]

            if adj["adjustment_type"] == "RESTATEMENT":
                adjustment.restatement_value.adjusted_value = adj["new_value"]
                adjustment.restatement_value.currency_code = adj.get("currency_code", "USD")

            adjustments.append(adjustment)

        # Upload in chunks
        total_success = 0
        total_failure = 0
        CHUNK = 2000
        for i in range(0, len(adjustments), CHUNK):
            chunk = adjustments[i:i + CHUNK]
            response = service.upload_conversion_adjustments(
                customer_id=customer_id,
                conversion_adjustments=chunk,
                partial_failure=True)

            rejected_count = self._count_rejected_operations(response.partial_failure_error)
            total_success += len(chunk) - rejected_count
            total_failure += rejected_count

        return {"success_count": total_success, "failure_count": total_failure}

    # === Batch Operations ===

    def batch_create_campaigns(self, customer_id: str, campaigns_data: list,
                                partial_failure: bool = True) -> dict:
        """
        Crear múltiples campañas en una sola llamada mutate.

        campaigns_data: lista de dicts con claves:
          name (requerido), advertising_channel_type (requerido, ej: 'SEARCH', 'PERFORMANCE_MAX'),
          status ('ENABLED' | 'PAUSED'), campaign_budget (resource name del budget),
          bidding_strategy_type (ej: 'MAXIMIZE_CONVERSIONS', 'TARGET_CPA'),
          target_cpa_micros (opcional, para TARGET_CPA)

        Retorna dict con resource_names de campañas creadas y errores parciales.
        """
        customer_id = customer_id.replace("-", "")
        operations = []

        for campaign_data in campaigns_data:
            op = self._build_mutate_operation("campaign", "create", campaign_data, customer_id)
            operations.append(op)

        response = self.mutate(customer_id, operations, partial_failure=partial_failure)
        return self._parse_mutate_response(response, len(campaigns_data))

    def batch_update_campaigns(self, customer_id: str, updates: list,
                                partial_failure: bool = True) -> dict:
        """
        Actualizar múltiples campañas en una sola llamada mutate.

        updates: lista de dicts con claves:
          resource_name (requerido, ej: 'customers/123/campaigns/456'),
          campos a actualizar: status, name, campaign_budget, etc.

        Retorna dict con resultados y errores parciales.
        """
        customer_id = customer_id.replace("-", "")
        operations = []

        for update_data in updates:
            op = self._build_mutate_operation("campaign", "update", update_data, customer_id)
            operations.append(op)

        response = self.mutate(customer_id, operations, partial_failure=partial_failure)
        return self._parse_mutate_response(response, len(updates))

    def batch_create_adgroups(self, customer_id: str, adgroups_data: list,
                               partial_failure: bool = True) -> dict:
        """
        Crear múltiples grupos de anuncios en una sola llamada mutate.

        adgroups_data: lista de dicts con claves:
          name (requerido), campaign (resource name de la campaña),
          status ('ENABLED' | 'PAUSED'), type ('SEARCH_STANDARD', 'DISPLAY_STANDARD', etc.),
          cpc_bid_micros (opcional)

        Retorna dict con resource_names creados y errores parciales.
        """
        customer_id = customer_id.replace("-", "")
        operations = []

        for adgroup_data in adgroups_data:
            op = self._build_mutate_operation("ad_group", "create", adgroup_data, customer_id)
            operations.append(op)

        response = self.mutate(customer_id, operations, partial_failure=partial_failure)
        return self._parse_mutate_response(response, len(adgroups_data))

    def _build_mutate_operation(self, entity_type: str, operation_type: str,
                                 data: dict, customer_id: str):
        """
        Construye un MutateOperation para campañas, ad_groups u otras entidades.

        entity_type: 'campaign', 'ad_group', 'ad_group_ad', 'campaign_budget'
        operation_type: 'create' o 'update'
        data: dict con los campos de la entidad
        """
        op = self.client.get_type("MutateOperation")

        # Mapeo de entity_type a la operación correspondiente
        entity_map = {
            "campaign": "campaign_operation",
            "ad_group": "ad_group_operation",
            "ad_group_ad": "ad_group_ad_operation",
            "campaign_budget": "campaign_budget_operation",
            "campaign_criterion": "campaign_criterion_operation",
            "ad_group_criterion": "ad_group_criterion_operation",
        }

        if entity_type not in entity_map:
            raise ValueError(f"Tipo de entidad no soportado: {entity_type}. "
                             f"Usar: {', '.join(entity_map.keys())}")

        entity_op = getattr(op, entity_map[entity_type])
        target = getattr(entity_op, operation_type)

        # Asignar campos del data al protobuf
        for field_name, field_value in data.items():
            if field_name == "resource_name" and operation_type == "update":
                target.resource_name = field_value
                continue
            if hasattr(target, field_name):
                attr = getattr(target, field_name)
                if isinstance(field_value, str) and hasattr(attr, "name") and hasattr(attr, "value"):
                    # Es un enum, asignar por nombre
                    setattr(target, field_name, getattr(type(attr), field_value, field_value))
                else:
                    setattr(target, field_name, field_value)

        # Para updates, configurar la field mask
        if operation_type == "update":
            update_fields = [k for k in data.keys() if k != "resource_name"]
            entity_op.update_mask.paths.extend(update_fields)

        return op

    def _parse_mutate_response(self, response, total_operations: int) -> dict:
        """Parsear respuesta de mutate y extraer resource_names y errores."""
        resource_names = []
        errors = []

        if hasattr(response, "mutate_operation_responses"):
            for resp in response.mutate_operation_responses:
                # Extraer resource name del primer campo que lo tenga
                for field in ["campaign_result", "ad_group_result", "ad_group_ad_result",
                              "campaign_budget_result", "campaign_criterion_result",
                              "ad_group_criterion_result"]:
                    if hasattr(resp, field):
                        result = getattr(resp, field)
                        if hasattr(result, "resource_name") and result.resource_name:
                            resource_names.append(result.resource_name)
                            break

        if hasattr(response, "partial_failure_error"):
            raw_errors = self._get_partial_failure_errors(response.partial_failure_error)
            errors_by_index = {}
            for error in raw_errors:
                errors_by_index.setdefault(error.location.field_path_elements[0].index, error.message)
            errors = list(errors_by_index.values())

        return {
            "resource_names": resource_names,
            "success_count": total_operations - len(errors),
            "failure_count": len(errors),
            "errors": errors,
        }

    # === Campaign Budget Management ===

    def set_campaign_budget(self, customer_id: str, campaign_id: str,
                            daily_budget_micros: int) -> str:
        """
        Establecer o actualizar el presupuesto diario de una campaña.

        daily_budget_micros: presupuesto en micros (1 USD = 1_000_000 micros).
        Ejemplo: 50 USD/día → 50_000_000

        Retorna el resource_name del budget actualizado.
        """
        customer_id = customer_id.replace("-", "")

        # Obtener el budget asociado a la campaña
        query = f"""
            SELECT campaign.campaign_budget
            FROM campaign
            WHERE campaign.id = {campaign_id}
        """
        results = self.query_to_list(customer_id, query)
        if not results:
            raise ValueError(f"Campaña {campaign_id} no encontrada en cuenta {customer_id}")

        budget_resource = results[0].get("campaign.campaign_budget")
        if not budget_resource:
            raise ValueError(f"Campaña {campaign_id} no tiene budget asignado")

        # Actualizar el budget
        budget_op = self.client.get_type("CampaignBudgetOperation")
        budget = budget_op.update
        budget.resource_name = budget_resource
        budget.amount_micros = daily_budget_micros

        budget_op.update_mask.paths.append("amount_micros")

        budget_service = self.client.get_service("CampaignBudgetService")
        response = self._retry(
            lambda: budget_service.mutate_campaign_budgets(
                customer_id=customer_id, operations=[budget_op]))

        return response.results[0].resource_name

    def get_budget_utilization(self, customer_id: str,
                                campaign_ids: Optional[list] = None) -> list:
        """
        Obtener utilización de presupuesto: gasto actual vs presupuesto asignado.

        Retorna lista de dicts con:
          campaign_id, campaign_name, daily_budget_micros, cost_today_micros,
          utilization_percent, status
        """
        customer_id = customer_id.replace("-", "")

        query_builder = (GAQLBuilder()
                         .select("campaign.id", "campaign.name", "campaign.status",
                                 "campaign_budget.amount_micros",
                                 "metrics.cost_micros")
                         .from_resource("campaign")
                         .where("campaign.status != 'REMOVED'")
                         .during("TODAY"))

        if campaign_ids:
            ids_str = ", ".join(str(cid) for cid in campaign_ids)
            query_builder.where(f"campaign.id IN ({ids_str})")

        results = self.query_to_list(customer_id, query_builder.build())
        utilization = []

        for row in results:
            budget_micros = row.get("campaign_budget.amount_micros", 0)
            cost_micros = row.get("metrics.cost_micros", 0)
            pct = (cost_micros / budget_micros * 100) if budget_micros > 0 else 0.0

            utilization.append({
                "campaign_id": row.get("campaign.id"),
                "campaign_name": row.get("campaign.name"),
                "daily_budget_micros": budget_micros,
                "cost_today_micros": cost_micros,
                "utilization_percent": round(pct, 2),
                "status": row.get("campaign.status"),
            })

        return sorted(utilization, key=lambda x: x["utilization_percent"], reverse=True)

    def pause_overspending_campaigns(self, customer_id: str,
                                      threshold_percent: float = 95.0) -> list:
        """
        Pausar campañas cuyo gasto actual supera el umbral del presupuesto diario.

        threshold_percent: porcentaje de utilización para considerar "overspending" (default 95%).
        Retorna lista de campañas pausadas con sus datos.
        """
        utilization = self.get_budget_utilization(customer_id)
        to_pause = [
            u for u in utilization
            if u["utilization_percent"] >= threshold_percent
            and u["status"] == "ENABLED"
        ]

        if not to_pause:
            return []

        customer_id_clean = customer_id.replace("-", "")
        updates = []
        for campaign in to_pause:
            cid = campaign["campaign_id"]
            updates.append({
                "resource_name": f"customers/{customer_id_clean}/campaigns/{cid}",
                "status": "PAUSED",
            })

        if updates:
            self.batch_update_campaigns(customer_id, updates)

        for campaign in to_pause:
            campaign["action"] = "PAUSED"
            print(f"Pausada: {campaign['campaign_name']} "
                  f"(utilización: {campaign['utilization_percent']:.1f}%)",
                  file=sys.stderr)

        return to_pause

    # === Report Download & Parsing ===

    def query_to_csv(self, customer_id: str, query: str, output_path: str) -> int:
        """
        Ejecutar una query GAQL y guardar los resultados en CSV.

        Retorna el número de filas exportadas.
        """
        rows = self.query_to_list(customer_id, query)
        if not rows:
            print(f"Query sin resultados para cuenta {customer_id}", file=sys.stderr)
            return 0

        fieldnames = list(rows[0].keys())
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

        print(f"Exportadas {len(rows)} filas a {output_path}", file=sys.stderr)
        return len(rows)

    def query_to_json(self, customer_id: str, query: str, output_path: str) -> int:
        """
        Ejecutar una query GAQL y guardar los resultados en JSON.

        Retorna el número de filas exportadas.
        """
        rows = self.query_to_list(customer_id, query)
        if not rows:
            print(f"Query sin resultados para cuenta {customer_id}", file=sys.stderr)
            return 0

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(rows, f, indent=2, default=str, ensure_ascii=False)

        print(f"Exportadas {len(rows)} filas a {output_path}", file=sys.stderr)
        return len(rows)

    def query_multiple_accounts(self, mcc_id: str, query: str,
                                 max_workers: int = 5) -> dict:
        """
        Ejecutar una query GAQL en paralelo en todas las cuentas hijas de un MCC.

        Retorna dict con:
          results: lista consolidada de filas (con _account_id y _account_name),
          errors: dict de account_id → mensaje de error,
          summary: dict con total_accounts, successful, failed, total_rows
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        accounts = self.get_account_hierarchy(mcc_id)
        child_accounts = [
            acc for acc in accounts
            if not acc.get("customer_client.manager")
            and str(acc.get("customer_client.client_customer", "")).replace("customers/", "")
        ]

        all_results = []
        errors = {}
        successful = 0

        def _query_account(account):
            cid = str(account.get("customer_client.client_customer", "")).replace("customers/", "")
            name = account.get("customer_client.descriptive_name", "")
            rows = self.query_to_list(cid, query)
            for row in rows:
                row["_account_id"] = cid
                row["_account_name"] = name
            return cid, rows

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(_query_account, acc): acc
                for acc in child_accounts
            }

            for future in as_completed(futures):
                acc = futures[future]
                cid = str(acc.get("customer_client.client_customer", "")).replace("customers/", "")
                try:
                    _, rows = future.result()
                    all_results.extend(rows)
                    successful += 1
                except GoogleAdsException as ex:
                    error_msg = ex.failure.errors[0].message if ex.failure.errors else str(ex)
                    errors[cid] = error_msg
                    print(f"Error en cuenta {cid}: {error_msg}", file=sys.stderr)
                except Exception as ex:
                    errors[cid] = str(ex)
                    print(f"Error en cuenta {cid}: {ex}", file=sys.stderr)

        return {
            "results": all_results,
            "errors": errors,
            "summary": {
                "total_accounts": len(child_accounts),
                "successful": successful,
                "failed": len(errors),
                "total_rows": len(all_results),
            },
        }


def main():
    parser = argparse.ArgumentParser(description="Google Ads API Helper CLI")
    parser.add_argument("--config", default="google-ads.yaml", help="Path to google-ads.yaml")
    parser.add_argument("--account", required=True, help="Customer ID (no hyphens)")
    parser.add_argument("--query", required=True, help="GAQL query string")
    parser.add_argument("--output", default=None, help="Output CSV path (prints to stdout if omitted)")
    parser.add_argument("--mcc-expand", action="store_true",
                        help="Run query across all accounts under this MCC")
    args = parser.parse_args()

    helper = GoogleAdsHelper(args.config)

    if args.mcc_expand:
        results = helper.cross_account_query(args.account, args.query)
    else:
        results = helper.query_to_list(args.account, args.query)

    if HAS_PANDAS:
        df = pd.DataFrame(results)
        if args.output:
            df.to_csv(args.output, index=False)
            print(f"Exported {len(df)} rows to {args.output}", file=sys.stderr)
        else:
            print(df.to_csv(index=False))
    else:
        import json
        output = json.dumps(results, indent=2, default=str)
        if args.output:
            with open(args.output, "w") as f:
                f.write(output)
        else:
            print(output)


if __name__ == "__main__":
    main()
