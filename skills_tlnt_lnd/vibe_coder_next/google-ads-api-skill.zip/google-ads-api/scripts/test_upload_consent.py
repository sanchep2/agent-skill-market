#!/usr/bin/env python3
"""
test_upload_consent.py — Behavior tests for consent handling and partial-failure counting in
google_ads_helper.py (upload_enhanced_conversions / upload_customer_match).

Added for TAL-1949 rework (CodeRabbit findings 4 + 5 on PR #1181), then extended after a code-audit
round found that the first version's mocks hid 3 real bugs: (1) it faked a
google.ads.googleads.util.get_all_errors() that does not exist in the real client (31.1.0) — the
real pattern deserializes google.rpc.Status.details into GoogleAdsFailure directly, per Google's
own examples/error_handling/handle_partial_failure.py; (2) a single failed operation can produce
multiple GoogleAdsError entries sharing one operation index, so counting raw errors overcounts
rejected operations; (3) consent must be checked as a strict bool, not by truthiness (a stray
"false" string or 1 must never be treated as GRANTED). These tests now use fakes that mirror the
REAL response shape (a partial_failure_error with .code / .details, details deserializing into an
object with .errors, each error exposing .location.field_path_elements[0].index) instead of
mocking a nonexistent helper function.

Uses unittest.mock exclusively — no real Google Ads credentials or network calls; stubs the
google-ads SDK import surface if the real package isn't installed (see _ensure_sdk_importable).

Run: python3 test_upload_consent.py
"""

import os
import sys
import types
import unittest
from unittest.mock import MagicMock, patch


def _ensure_sdk_importable():
    """Prefer the real google-ads package; stub only the import surface google_ads_helper
    touches at module level if it isn't installed, so these tests run without it."""
    try:
        import google.ads.googleads.client  # noqa: F401
        import google.ads.googleads.errors  # noqa: F401
        return
    except ImportError:
        pass

    google_mod = types.ModuleType("google")
    ads_mod = types.ModuleType("google.ads")
    googleads_mod = types.ModuleType("google.ads.googleads")
    client_mod = types.ModuleType("google.ads.googleads.client")
    errors_mod = types.ModuleType("google.ads.googleads.errors")

    client_mod.GoogleAdsClient = MagicMock
    errors_mod.GoogleAdsException = Exception

    google_mod.ads = ads_mod
    ads_mod.googleads = googleads_mod
    googleads_mod.client = client_mod
    googleads_mod.errors = errors_mod

    for name, mod in [
        ("google", google_mod),
        ("google.ads", ads_mod),
        ("google.ads.googleads", googleads_mod),
        ("google.ads.googleads.client", client_mod),
        ("google.ads.googleads.errors", errors_mod),
    ]:
        sys.modules[name] = mod


_ensure_sdk_importable()
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from google_ads_helper import GoogleAdsHelper  # noqa: E402


def make_helper(use_proto_plus=True):
    """A GoogleAdsHelper with a mocked client, bypassing __init__ (which needs real credentials).
    use_proto_plus defaults True (the client's own default); pass False to exercise the native
    protobuf deserialization path (SKILL.md's own perf tip for high-volume scenarios)."""
    helper = object.__new__(GoogleAdsHelper)
    helper.client = MagicMock()
    helper.client.use_proto_plus = use_proto_plus
    return helper


# --- Fakes mirroring the REAL google-ads response shape (not a mocked nonexistent helper) ---
# google.rpc.Status always has .code (int) / .details (list); each detail.value deserializes into
# a GoogleAdsFailure exposing .errors, each with .location.field_path_elements[0].index.

class _FakeLocationElement:
    def __init__(self, index):
        self.index = index


class _FakeLocation:
    def __init__(self, index):
        self.field_path_elements = [_FakeLocationElement(index)]


class _FakeGoogleAdsError:
    def __init__(self, index, message="invalid"):
        self.location = _FakeLocation(index)
        self.message = message


class _FakeGoogleAdsFailure:
    """Stands in for the real GoogleAdsFailure type. `deserialize` is the real classmethod name;
    here it just returns the pre-built fake unchanged (no real protobuf bytes involved)."""

    def __init__(self, errors):
        self.errors = errors

    @classmethod
    def deserialize(cls, value):
        return value


class _FakeNativeGoogleAdsFailure:
    """Mimics a NATIVE protobuf message (use_proto_plus=False) — exposes ONLY ParseFromString,
    deliberately no deserialize() classmethod, so a test using this fails loudly (AttributeError)
    if the code under test still assumes proto-plus unconditionally (the code-audit r2 bug)."""

    def __init__(self):
        self.errors = []

    def ParseFromString(self, value):
        # `value` is the pre-built errors list the test hands in as fake wire bytes.
        self.errors = value
        return len(value)


class _FakeDetail:
    def __init__(self, value):
        self.value = value


class _FakePartialFailureError:
    """Mirrors google.rpc.Status: always present, code == 0 means no failure — presence/truthiness
    of this object is NOT a valid failure check (this is the bug MAYOR 1/the code-audit caught)."""

    def __init__(self, code=0, details=None):
        self.code = code
        self.details = details or []


def no_failure():
    return _FakePartialFailureError(code=0, details=[])


def failure_with_indices(indices):
    """Build a proto-plus-style partial_failure_error whose errors carry exactly `indices`
    (may repeat)."""
    errors = [_FakeGoogleAdsError(i) for i in indices]
    return _FakePartialFailureError(
        code=3, details=[_FakeDetail(_FakeGoogleAdsFailure(errors))]
    )


def failure_with_indices_native(indices):
    """Same as failure_with_indices, but detail.value is the raw errors list that
    _FakeNativeGoogleAdsFailure.ParseFromString consumes — mirrors native protobuf parsing."""
    errors = [_FakeGoogleAdsError(i) for i in indices]
    return _FakePartialFailureError(code=3, details=[_FakeDetail(errors)])


class CountRejectedOperationsTests(unittest.TestCase):
    def test_code_zero_is_not_a_failure_even_if_object_present(self):
        helper = make_helper()
        # A real success response still carries a non-None Status with code=0 — presence alone
        # must not be read as failure.
        self.assertEqual(helper._count_rejected_operations(no_failure()), 0)

    def test_multiple_errors_same_index_count_as_one_rejected_operation(self):
        helper = make_helper()
        helper.client.get_type.return_value = _FakeGoogleAdsFailure([])
        # Two validation errors on operation #0, one on operation #1 → 2 distinct operations, not 3.
        pfe = failure_with_indices([0, 0, 1])
        self.assertEqual(helper._count_rejected_operations(pfe), 2)

    def test_uses_get_type_deserialize_not_a_nonexistent_util_function(self):
        helper = make_helper()
        helper.client.get_type.return_value = _FakeGoogleAdsFailure([])
        helper._count_rejected_operations(failure_with_indices([0]))
        helper.client.get_type.assert_called_with("GoogleAdsFailure")

    def test_native_protobuf_use_proto_plus_false_uses_parsefromstring_not_deserialize(self):
        """Code-audit r2: with use_proto_plus=False (SKILL.md's own high-volume perf tip),
        client.get_type() returns a NATIVE protobuf message with no deserialize() classmethod —
        this fake only implements ParseFromString, so calling .deserialize() here would raise
        AttributeError and fail the test."""
        helper = make_helper(use_proto_plus=False)
        helper.client.get_type.return_value = _FakeNativeGoogleAdsFailure()
        pfe = failure_with_indices_native([0, 0, 1])
        self.assertEqual(helper._count_rejected_operations(pfe), 2)


class UploadEnhancedConversionsTests(unittest.TestCase):
    def test_missing_consent_excluded_and_counted_not_granted_by_default(self):
        helper = make_helper()
        service = helper.client.get_service.return_value
        service.upload_click_conversions.return_value = MagicMock(
            partial_failure_error=no_failure())

        result = helper.upload_enhanced_conversions(
            "123", "456",
            [
                {"conversion_time": "t", "conversion_value": 1,
                 "ad_user_data_consent": True, "ad_personalization_consent": True},
                {"conversion_time": "t", "conversion_value": 1},  # no consent keys
            ],
        )

        self.assertEqual(result["success_count"], 1)
        self.assertEqual(result["failure_count"], 1)
        _, kwargs = service.upload_click_conversions.call_args
        self.assertEqual(len(kwargs["conversions"]), 1)

    def test_non_strict_bool_consent_rejected_not_treated_as_granted(self):
        """A stray "false" string or 1 must never slip through as GRANTED."""
        helper = make_helper()
        service = helper.client.get_service.return_value
        service.upload_click_conversions.return_value = MagicMock(
            partial_failure_error=no_failure())

        for bad_value in ("false", 1, None, "true"):
            with self.subTest(bad_value=bad_value):
                result = helper.upload_enhanced_conversions(
                    "123", "456",
                    [{"conversion_time": "t", "conversion_value": 1,
                      "ad_user_data_consent": bad_value, "ad_personalization_consent": True}],
                )
                self.assertEqual(result["success_count"], 0)
                self.assertEqual(result["failure_count"], 1)

    def test_batch_entirely_without_consent_skips_service_call(self):
        helper = make_helper()
        service = helper.client.get_service.return_value

        result = helper.upload_enhanced_conversions(
            "123", "456",
            [{"conversion_time": "t", "conversion_value": 1}],  # no consent keys
        )

        service.upload_click_conversions.assert_not_called()
        self.assertEqual(result["success_count"], 0)
        self.assertEqual(result["failure_count"], 1)

    def test_partial_failure_deduped_by_index_reflected_in_counts(self):
        helper = make_helper()
        service = helper.client.get_service.return_value
        helper.client.get_type.side_effect = (
            lambda name: _FakeGoogleAdsFailure([]) if name == "GoogleAdsFailure" else MagicMock()
        )
        # 2 conversions submitted, both errors point at operation index 0 (same op) → 1 rejected.
        service.upload_click_conversions.return_value = MagicMock(
            partial_failure_error=failure_with_indices([0, 0]))

        result = helper.upload_enhanced_conversions(
            "123", "456",
            [
                {"conversion_time": "t", "conversion_value": 1,
                 "ad_user_data_consent": True, "ad_personalization_consent": True},
                {"conversion_time": "t", "conversion_value": 1,
                 "ad_user_data_consent": True, "ad_personalization_consent": True},
            ],
        )

        self.assertEqual(result["success_count"], 1)
        self.assertEqual(result["failure_count"], 1)


class UploadCustomerMatchTests(unittest.TestCase):
    def test_missing_consent_raises_before_creating_job(self):
        helper = make_helper()
        job_service = helper.client.get_service.return_value

        with self.assertRaises(ValueError):
            helper.upload_customer_match(
                "123", "customers/123/userLists/1", [{"email": "a@b.com"}], consent={},
            )

        job_service.create_offline_user_data_job.assert_not_called()

    def test_non_strict_true_consent_raises_before_creating_job(self):
        """Only a literal True is accepted — 1, "true", "false", None must all raise."""
        helper = make_helper()

        for bad_value in (1, "true", "false", None, False):
            with self.subTest(bad_value=bad_value):
                job_service = helper.client.get_service.return_value
                job_service.reset_mock()
                with self.assertRaises(ValueError):
                    helper.upload_customer_match(
                        "123", "customers/123/userLists/1", [{"email": "a@b.com"}],
                        consent={"ad_user_data": bad_value, "ad_personalization": True},
                    )
                job_service.create_offline_user_data_job.assert_not_called()

    def test_full_consent_set_once_at_job_level_returns_dict(self):
        helper = make_helper()
        job_service = helper.client.get_service.return_value
        job_service.create_offline_user_data_job.return_value = MagicMock(resource_name="job/1")
        job_service.add_offline_user_data_job_operations.return_value = MagicMock(
            partial_failure_error=no_failure())

        result = helper.upload_customer_match(
            "123", "customers/123/userLists/1", [{"email": "a@b.com"}],
            consent={"ad_user_data": True, "ad_personalization": True},
        )

        self.assertIsInstance(result, dict)
        self.assertEqual(result["job_resource_name"], "job/1")
        self.assertEqual(result["success_count"], 1)
        self.assertEqual(result["failure_count"], 0)

        _, kwargs = job_service.create_offline_user_data_job.call_args
        self.assertIn("consent", kwargs["job"]["customer_match_user_list_metadata"])

    def test_partial_failure_deduped_by_index_not_raw_error_count(self):
        helper = make_helper()
        job_service = helper.client.get_service.return_value
        job_service.create_offline_user_data_job.return_value = MagicMock(resource_name="job/1")
        helper.client.get_type.side_effect = (
            lambda name: _FakeGoogleAdsFailure([]) if name == "GoogleAdsFailure" else MagicMock()
        )
        # 3 records submitted; 2 raw errors both on operation index 1 → only 1 truly rejected.
        job_service.add_offline_user_data_job_operations.return_value = MagicMock(
            partial_failure_error=failure_with_indices([1, 1]))

        result = helper.upload_customer_match(
            "123", "customers/123/userLists/1",
            [{"email": "a@b.com"}, {"email": "c@d.com"}, {"email": "e@f.com"}],
            consent={"ad_user_data": True, "ad_personalization": True},
        )

        self.assertEqual(result["failure_count"], 1)
        self.assertEqual(result["success_count"], 2)


if __name__ == "__main__":
    unittest.main()
