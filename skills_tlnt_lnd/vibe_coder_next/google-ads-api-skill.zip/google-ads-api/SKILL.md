---
name: google-ads-api
description: >
  Use this skill whenever the user needs to work with Google Ads — both programmatically
  AND for ad creative strategy. This includes: writing Python/Node.js/any code that calls
  the Google Ads API, composing or debugging GAQL queries, setting up authentication
  (OAuth, service accounts, developer tokens, google-ads.yaml), creating or managing
  campaigns (Search, PMax, Demand Gen, Shopping, App, AI Max, Video, Display), pulling
  reports or metrics, uploading offline conversions, managing audiences or remarketing
  lists, working with MCC/manager accounts, using CLI tools like gaarf or gaql-cli,
  batch processing, automating bid strategies, handling API errors or rate limits,
  or migrating between API versions. ALSO trigger for first-party data strategy:
  connecting CRM/databases to Google Ads via Data Manager API, setting up Enhanced
  Conversions (web or leads), Customer Match segmentation and upload, Consent Mode V2,
  value-based bidding with LTV/profit data, Conversion Value Rules, Customer Lifecycle
  Goals (acquisition/retention), conversion adjustments (restatements/retractions),
  or server-side tracking infrastructure. ALSO trigger for ad creative tasks: writing winning
  ad copy, headlines, descriptions for RSAs or any campaign type, optimizing Ad Strength,
  building PMax asset groups, creating video ad scripts (YouTube, Shorts, bumper ads),
  writing product titles for Shopping feeds, Demand Gen carousel/image/video creative,
  display ad assets, app campaign creatives, ad copywriting best practices, A/B testing
  ad copy, keyword insertion or ad customizers, ABCD framework for video, Quality Score
  optimization, or any question about Google Ads character limits, image specs, video
  specs, or creative compliance/policies.
  Trigger keywords: "Google Ads", "AdWords API", "GAQL", "gaarf", "developer token",
  "PMax API", "google-ads-python", "SearchStream", "RSA", "responsive search ad",
  "ad copy", "ad creative", "headlines", "Performance Max assets", "Demand Gen",
  "Shopping feed", "YouTube ad", "bumper ad", "Ad Strength", "Quality Score",
  "ad extensions", "call assets", "video ad script", "AI Max", "Power Pack",
  "AI Overviews ads", "Connected TV ads", "Shoppable CTV", "Text Customization",
  "Asset Studio", "Brand Guidelines", "Data Manager API", "enhanced conversions",
  "Customer Match", "consent mode", "conversion value rules", "lifecycle goals",
  "first-party data", "offline conversions", "LTV bidding", "value-based bidding",
  "conversion adjustments", "server-side tagging", "GCLID", or any Google Ads campaign type.
  Even if the user just asks "write me Google Ads headlines", "what specs does PMax need",
  "how do I improve my Ad Strength", "help me create winning ads", "connect my CRM to
  Google Ads", "upload customer data", or "set up enhanced conversions", use this skill.
---

# Google Ads API & CLI — State of the Art (July 2026)

<!-- last_verified: 2026-07-17 (API version, SDK versions, Data Manager API mandate, GAQL lookback, v24 breaking changes) -->

## Quick Orientation

The Google Ads API is at **v24** (major released April 22, 2026; latest minor **v24.2**,
June 24, 2026) with ~4 major releases/year plus monthly minors and ~1 year of support per
major (`last_verified: 2026-07-17`).
It uses **gRPC** as primary transport (REST also available). Base URL:
`https://googleads.googleapis.com/v{VERSION}/`. Resources follow the naming pattern
`customers/{customer_id}/{resource_type}/{resource_id}`. Composite IDs use a **tilde
separator** (e.g., `customers/123/adGroupAds/456~789`). All monetary values are in
**micros** (divide by 1,000,000). The API requires three headers on every call:
`Authorization`, `developer-token`, and `login-customer-id` (when using MCC).
Responses include a `request-id` header critical for debugging.

**Data Manager API** (GA since October 2025): Google's unified first-party data ingestion
platform, and now the **mandatory path** for first-party data, not an optional one. Use it
for CRM/warehouse integrations, scheduled Customer Match syncs, and enhanced conversion
uploads. Timeline of the mandate (`last_verified: 2026-07-17`):

- **February 2, 2026** — session attributes and IP data must go through Data Manager API.
- **April 1, 2026** — Customer Match uploads via the Google Ads API (`OfflineUserDataJobService`)
  start being blocked for developer tokens without recent Customer Match activity (180 days).
- **June 15, 2026** — `ConversionUploadService.UploadClickConversions` (offline conversions,
  including Enhanced Conversions for Leads) is blocked for new adopters / tokens without
  activity between Dec 2025 and May 2026. Non-allowlisted callers get
  `CUSTOMER_NOT_ALLOWLISTED_FOR_THIS_FEATURE` — the fix is to migrate to Data Manager API.

New integrations should default to **Data Manager API**; direct Google Ads API upload paths
are legacy/soft-sunset. See `references/first-party-data-strategy.md` for complete coverage.

Official docs at `developers.google.com/google-ads/api` have five tabs: **Guides** (main
docs hub), **Reference** (API reference + upgrade guides), **Libraries and samples**
(6 languages), **Policies** (developer token policy, ToS), and **Support** (Discord, forms).

**For deeper topics, read the appropriate reference file before writing code:**

| Topic | Reference File | When to Read |
|-------|---------------|--------------|
| Auth, config, versions, access levels | `references/auth-and-setup.md` | Setting up credentials, google-ads.yaml, OAuth, service accounts |
| GAQL syntax, operators, 30+ query examples | `references/gaql-reference.md` | Writing or debugging any GAQL query |
| Campaign creation (Search, PMax, Demand Gen, Shopping, AI Max) | `references/campaign-management.md` | Creating, updating, or managing any campaign type |
| SDKs, CLI (gaarf, gaql-cli), MCP, ETL, iPaaS, ecosystem | `references/ecosystem-tools.md` | SDK setup, CLI tools, MCP servers, ETL/reverse-ETL, third-party platforms |
| Batch jobs, recommendations, MCC, error handling | `references/automation-and-reporting.md` | Automating operations, managing multiple accounts |
| **First-party data: Data Manager API, Enhanced Conversions, Consent Mode, Value-Based Bidding, Lifecycle Goals, Customer Match strategy** | **`references/first-party-data-strategy.md`** | **Connecting CRM/database to Google Ads, uploading customer data, conversion adjustments, LTV optimization, audience segmentation, privacy compliance — the #1 differentiator in 2026** |
| **Winning ad creative for ALL formats** (RSA, PMax, Demand Gen, Shopping, Video, Display, App) | **`references/ad-creative-guide.md`** | **Writing ad copy, building asset groups, video scripts, image/video specs, Ad Strength, copywriting frameworks, compliance, 2026 landscape (AI Overviews, CTV, Power Pack strategy)** |
| Audience types, targeting, remarketing, Customer Match strategy, PMax signals | `references/audiences-targeting.md` | Audience taxonomy, retargeting funnels, match rate optimization, exclusion patterns |
| Smart Bidding strategies, learning period, migration path | `references/smart-bidding.md` | Choosing bid strategies, tCPA/tROAS setup, experiments, value rules, troubleshooting |
| Metrics, attribution, PMax/Shopping/Demand Gen/Video/Search reporting | `references/analytics-reporting.md` | Pulling reports, understanding attribution, data freshness, segmentation |
| Rate limits, quotas, error codes, retry patterns, circuit breaker | `references/rate-limits.md` | API throttling, error handling, partial failure, MCC rate strategies |
| Polling, automation, scheduled ops, alerting (no webhooks) | `references/webhooks-automation.md` | Change detection, conversion upload automation, custom webhook patterns, alerting |

## Python Quick Start

```bash
pip install google-ads  # v31.1.0 as of Jul 2026 (last_verified: 2026-07-17); requires Python >=3.9,<3.15
```

### Configuration (google-ads.yaml)

```yaml
developer_token: "ABCDEFGHIJKLMNOPQRSTUV"
client_id: "YOUR_CLIENT_ID.apps.googleusercontent.com"
client_secret: "YOUR_CLIENT_SECRET"
refresh_token: "YOUR_REFRESH_TOKEN"
login_customer_id: "1234567890"  # MCC ID, no hyphens
use_proto_plus: True
```

Every field has an env var equivalent: `GOOGLE_ADS_DEVELOPER_TOKEN`, `GOOGLE_ADS_CLIENT_ID`, etc.

**All official client libraries** (versions `last_verified: 2026-07-17` against each language's
official registry — Maven Central, Packagist, RubyGems, NuGet, CPAN):

| Language | Package | Version | Min Runtime |
|----------|---------|---------|-------------|
| Python | `google-ads` | 31.1.0 | Python 3.9–3.14 |
| Java | `com.google.api-ads:google-ads` | 43.1.0 | Java 1.8+ |
| PHP | `googleads/google-ads-php` | 33.5.0 | PHP 8.1+ |
| Ruby | `google-ads-googleads` | 42.0.0 | Ruby 3.0+ |
| .NET | `Google.Ads.GoogleAds` | 26.0.1 | .NET 4.7.2+ |
| Perl | `Google::Ads::GoogleAds::Client` | 32.2.0 | Perl 5.28.1+ |

**Perl note**: Uses JSON REST over HTTP 1.1 (not gRPC) since Perl lacks native gRPC support.

Community: **Opteo** maintains a popular Node.js/TypeScript client
(`github.com/Opteo/google-ads-api`, npm `google-ads-api` **v24.1.0**, `last_verified: 2026-07-17`) —
see the runnable Quick Start in `references/ecosystem-tools.md`. **Go**: `google-ads-pb`
community library.

### Initialize Client

```python
from google.ads.googleads.client import GoogleAdsClient

# From YAML file (default: ~/google-ads.yaml)
client = GoogleAdsClient.load_from_storage("path/to/google-ads.yaml")

# From environment variables
client = GoogleAdsClient.load_from_env()

# From dict (useful in serverless / containers)
client = GoogleAdsClient.load_from_dict({
    "developer_token": "...",
    "client_id": "...",
    "client_secret": "...",
    "refresh_token": "...",
    "login_customer_id": "1234567890",
    "use_proto_plus": True,
})

# From YAML string (useful for config stored in secrets managers)
client = GoogleAdsClient.load_from_string(yaml_doc_string)
```

**Performance tip**: Set `use_proto_plus: False` in config for high-volume scenarios.
Default `True` gives Pythonic objects; `False` uses raw protobuf with lower marshaling
overhead (~2-3x faster for bulk processing). The library also supports **Application
Default Credentials (ADC)** for GCP-native environments.

### Read Data — Always Use SearchStream

```python
from google.ads.googleads.errors import GoogleAdsException

def get_campaigns(client, customer_id):
    ga_service = client.get_service("GoogleAdsService")
    query = """
        SELECT campaign.id, campaign.name, campaign.status,
               metrics.impressions, metrics.clicks, metrics.cost_micros
        FROM campaign
        WHERE campaign.status != 'REMOVED'
          AND segments.date DURING LAST_30_DAYS
        ORDER BY metrics.clicks DESC
    """
    try:
        stream = ga_service.search_stream(customer_id=customer_id, query=query)
        for batch in stream:
            for row in batch.results:
                cost = row.metrics.cost_micros / 1_000_000
                print(f"{row.campaign.name}: {row.metrics.clicks} clicks, ${cost:.2f}")
    except GoogleAdsException as ex:
        for error in ex.failure.errors:
            print(f"Error [{error.error_code}]: {error.message}")
```

**Why SearchStream over Search?** SearchStream returns the entire result set over one
persistent connection — no pagination, no round-trips. Search returns fixed **10,000-row
pages** (page size became non-configurable in v17). For a 100K-row report, Search needs
10 round-trips; SearchStream needs one. Both count as a single operation against daily
quotas. Paginated Search requests using `next_page_token` do **not** count against
daily quotas.

```python
# Paginated Search (fallback for unreliable connections)
from google.ads.googleads.v24.services.types.google_ads_service import SearchGoogleAdsRequest

response = ga_service.search(request=SearchGoogleAdsRequest(
    customer_id=customer_id, query=query))
for row in response:  # Client library auto-paginates
    process(row)
```

### Write Data — Mutate Operations

```python
def create_campaign_budget(client, customer_id, amount_micros=10_000_000):
    budget_service = client.get_service("CampaignBudgetService")
    budget_op = client.get_type("CampaignBudgetOperation")
    budget = budget_op.create
    budget.name = f"Budget_{amount_micros}"
    budget.amount_micros = amount_micros
    budget.delivery_method = client.enums.BudgetDeliveryMethodEnum.STANDARD

    response = budget_service.mutate_campaign_budgets(
        customer_id=customer_id, operations=[budget_op]
    )
    return response.results[0].resource_name
```

### Atomic Multi-Entity Creation (Temporary Resource Names)

Create Budget → Campaign → Ad Group → Ads in a single atomic request using negative IDs:

```python
def create_search_campaign_stack(client, customer_id):
    ga_service = client.get_service("GoogleAdsService")
    ops = []

    # Budget (temp ID: -1)
    budget_op = client.get_type("MutateOperation")
    budget = budget_op.campaign_budget_operation.create
    budget.resource_name = client.get_service("CampaignBudgetService").campaign_budget_path(
        customer_id, "-1")
    budget.name = "My Budget"
    budget.amount_micros = 10_000_000
    ops.append(budget_op)

    # Campaign (temp ID: -2, references budget -1)
    camp_op = client.get_type("MutateOperation")
    camp = camp_op.campaign_operation.create
    camp.resource_name = client.get_service("CampaignService").campaign_path(
        customer_id, "-2")
    camp.name = "My Search Campaign"
    camp.advertising_channel_type = client.enums.AdvertisingChannelTypeEnum.SEARCH
    camp.status = client.enums.CampaignStatusEnum.PAUSED
    camp.campaign_budget = client.get_service("CampaignBudgetService").campaign_budget_path(
        customer_id, "-1")
    camp.maximize_conversions.target_cpa_micros = 0  # No target CPA cap
    ops.append(camp_op)

    # Ad Group (temp ID: -3, references campaign -2)
    ag_op = client.get_type("MutateOperation")
    ag = ag_op.ad_group_operation.create
    ag.resource_name = client.get_service("AdGroupService").ad_group_path(
        customer_id, "-3")
    ag.campaign = client.get_service("CampaignService").campaign_path(
        customer_id, "-2")
    ag.name = "My Ad Group"
    ag.status = client.enums.AdGroupStatusEnum.ENABLED
    ag.type_ = client.enums.AdGroupTypeEnum.SEARCH_STANDARD
    ops.append(ag_op)

    response = ga_service.mutate(customer_id=customer_id, mutate_operations=ops)
    for result in response.mutate_operation_responses:
        print(f"Created: {result}")
```

Each temporary ID must be unique across all resource types within a single request.

## Essential Patterns

### GAQL Query Lifecycle

```
┌──────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────┐
│  Build   │───▶│  Validate    │───▶│  Execute     │───▶│  Process │
│  GAQL    │    │  (optional)  │    │              │    │  Results │
│  query   │    │              │    │              │    │          │
│  string  │    │ Query Builder│    │ SearchStream │    │ Iterate  │
│          │    │ or manual    │    │ (1 conn,     │    │ batches, │
│          │    │              │    │  no paging)  │    │ /1M div  │
└──────────┘    └──────────────┘    └──────────────┘    └──────────┘

Key rules:
  - Only AND in WHERE (no OR → run multiple queries)
  - segments.date in SELECT → requires date range in WHERE
  - All costs in micros (÷ 1,000,000)
  - SearchStream > Search (no pagination, 1 connection)
```

### Campaign Structure Hierarchy

```
┌─────────────────────────────────────────────────┐
│  MCC (Manager Account)                           │
│  login_customer_id in headers                    │
│                                                   │
│  ┌────────────────────────────────────────────┐  │
│  │  Customer Account (customer_id)             │  │
│  │                                              │  │
│  │  Budget ──────────────────┐                  │  │
│  │                           ▼                  │  │
│  │  Campaign ◄──── (references budget)          │  │
│  │  │  objective, status, bid strategy          │  │
│  │  │  Types: Search, PMax, Demand Gen,         │  │
│  │  │         Shopping, App, Video, Display,    │  │
│  │  │         AI Max                            │  │
│  │  │                                           │  │
│  │  └──▶ Ad Group                               │  │
│  │       │  targeting, keywords (Search)        │  │
│  │       │                                      │  │
│  │       └──▶ Ad Group Ad ──▶ Ad                │  │
│  │            (RSA, responsive display, etc.)    │  │
│  │                                              │  │
│  │  Asset ◄──── (images, videos, headlines)     │  │
│  │  AssetGroup ◄──── (PMax: listing groups)     │  │
│  └────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────┘

IDs: Composite use tilde → customers/123/adGroupAds/456~789
Temp IDs: Negative integers (-1, -2, -3) for atomic creation
```

### Conversion Tracking Flow

```
┌──────────┐    ┌──────────────┐    ┌──────────────┐
│  User    │───▶│  Clicks ad   │───▶│  Lands on    │
│  sees ad │    │  (captures   │    │  website     │
└──────────┘    │   GCLID)     │    └──────┬───────┘
                └──────────────┘           │
                                           ▼
                                    ┌──────────────┐
                                    │  Conversion  │
                                    │  happens     │
                                    └──────┬───────┘
                                           │
                        ┌──────────────────┼──────────────────┐
                        ▼                  ▼                  ▼
                 ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
                 │  gtag.js     │  │  Enhanced    │  │  Offline     │
                 │  (client)    │  │  Conversions │  │  Upload      │
                 │              │  │  (hashed PII │  │  (GCLID +    │
                 │  automatic   │  │   matching)  │  │   value)     │
                 └──────────────┘  └──────────────┘  └──────────────┘
                                           │                  │
                                    Data Manager API    ConversionUpload
                                    (Feb 2026: session  Service
                                     + IP data must     (partial_failure
                                     go through DM)      = True always)
```

---

## Essential GAQL Patterns

GAQL only supports `AND` in `WHERE` — no `OR`. When `segments.date` appears in `SELECT`,
a finite date range is required in `WHERE`.

```sql
-- Campaign performance last 30 days
SELECT campaign.name, campaign.status, metrics.impressions,
       metrics.clicks, metrics.ctr, metrics.cost_micros, metrics.conversions
FROM campaign
WHERE campaign.status != 'REMOVED' AND segments.date DURING LAST_30_DAYS

-- Keywords with quality scores
SELECT campaign.name, ad_group.name,
       ad_group_criterion.keyword.text, ad_group_criterion.keyword.match_type,
       ad_group_criterion.quality_info.quality_score,
       metrics.impressions, metrics.clicks, metrics.conversions
FROM keyword_view
WHERE campaign.status = 'ENABLED' AND ad_group.status = 'ENABLED'
  AND segments.date DURING LAST_30_DAYS
ORDER BY metrics.impressions DESC LIMIT 100

-- Search terms report
SELECT search_term_view.search_term, campaign.name,
       metrics.impressions, metrics.clicks, metrics.cost_micros, metrics.conversions
FROM search_term_view
WHERE metrics.clicks > 5 AND segments.date DURING LAST_7_DAYS
ORDER BY metrics.clicks DESC LIMIT 200
```

For the full GAQL reference with 30+ query examples, operators, date ranges,
and compatibility rules, read `references/gaql-reference.md`.

## Common API Patterns

### Pause/Enable a Campaign

```python
def set_campaign_status(client, customer_id, campaign_id, status="PAUSED"):
    campaign_service = client.get_service("CampaignService")
    campaign_op = client.get_type("CampaignOperation")
    campaign = campaign_op.update
    campaign.resource_name = campaign_service.campaign_path(customer_id, campaign_id)
    campaign.status = getattr(client.enums.CampaignStatusEnum, status)
    client.copy_from(campaign_op.update_mask,
                     protobuf_helpers.field_mask(None, campaign._pb))
    campaign_service.mutate_campaigns(
        customer_id=customer_id, operations=[campaign_op])
```

### Upload Offline Conversions

> ⚠️ **Gated since June 15, 2026** (`last_verified: 2026-07-17`): `ConversionUploadService`
> below is a **legacy** path. New adopters — and developer tokens without offline-conversion
> activity between Dec 2025 and May 2026 — receive `CUSTOMER_NOT_ALLOWLISTED_FOR_THIS_FEATURE`.
> For any new integration, use **Data Manager API** instead (see
> `references/first-party-data-strategy.md`). Keep this pattern only for already-allowlisted
> tokens still on the direct API.

```python
def upload_conversion(client, customer_id, gclid, conversion_action_id,
                      conversion_time, conversion_value):
    conversion_upload_service = client.get_service("ConversionUploadService")
    click_conversion = client.get_type("ClickConversion")
    click_conversion.gclid = gclid
    click_conversion.conversion_action = client.get_service(
        "ConversionActionService").conversion_action_path(
        customer_id, conversion_action_id)
    click_conversion.conversion_date_time = conversion_time  # "2025-01-15 12:30:00-05:00"
    click_conversion.conversion_value = conversion_value
    click_conversion.currency_code = "USD"
    # EU consent (required for EU traffic)
    click_conversion.consent.ad_user_data = client.enums.ConsentStatusEnum.GRANTED
    click_conversion.consent.ad_personalization = client.enums.ConsentStatusEnum.GRANTED

    response = conversion_upload_service.upload_click_conversions(
        customer_id=customer_id,
        conversions=[click_conversion],
        partial_failure=True,  # Always set True
    )
    if response.partial_failure_error:
        print(f"Partial failures: {response.partial_failure_error.message}")
```

### List All Accounts Under MCC

```python
def list_accessible_customers(client):
    """Lists all accounts the authenticated user can access."""
    customer_service = client.get_service("CustomerService")
    response = customer_service.list_accessible_customers()
    for resource_name in response.resource_names:
        print(resource_name)  # customers/1234567890

def get_mcc_hierarchy(client, mcc_id):
    """Gets child accounts of a manager account."""
    ga_service = client.get_service("GoogleAdsService")
    query = """
        SELECT customer_client.client_customer, customer_client.descriptive_name,
               customer_client.manager, customer_client.level, customer_client.status
        FROM customer_client
        WHERE customer_client.level <= 1 AND customer_client.status = 'ENABLED'
    """
    stream = ga_service.search_stream(customer_id=mcc_id, query=query)
    for batch in stream:
        for row in batch.results:
            cc = row.customer_client
            print(f"{'[MCC] ' if cc.manager else ''}{cc.descriptive_name} ({cc.client_customer})")
```

## Rate Limits and Best Practices

The API uses a token bucket rate limiter — no fixed published QPS. Key constraints:

- **Mutate requests**: max 10,000 operations per call
- **Basic access**: 15,000 operations/day; **Standard access**: unlimited
- **Keyword Planning**: 1 QPS hard limit
- Rate-limited responses return `RESOURCE_EXHAUSTED` with `retryDelay` in metadata

**Performance tips**: Reuse gRPC channels/client instances. Select only needed GAQL fields.
Use SearchStream exclusively. Batch mutations. Use BatchJobService for >10K operations.
Implement exponential backoff with jitter (5s base, 2x multiplier, 5 retries max).

## Active API Versions (July 2026)

Versions and dates `last_verified: 2026-07-17` against
`developers.google.com/google-ads/api/docs/release-notes`.

| Version | Released | Sunset | Key Addition |
|---------|----------|--------|-------------|
| v21 | Aug 2025 | Aug 2026 | AI Max for Search, search themes ×2 |
| v22 | Oct 2025 | Oct 2026 | AssetGenerationService, Demand Gen TargetCPC |
| v23 | Jan 2026 | ~Feb 2027 | PMax network transparency, precision scheduling |
| **v24** | **Apr 22, 2026** | **~Apr/May 2027** | **CartDataSalesView, mutable VideoResponsiveAdInfo, retail/lead-gen reporting** |
| v24.1 | May 13, 2026 | (parent) | `ADOPT_AI_MAX` experiment type, `REQUESTED_DATE_GRANULARITY_NOT_SUPPORTED` |
| v24.2 | Jun 24, 2026 | (parent) | Latest minor, additive changes |

**v20 was sunset June 10, 2026** — any code still on v20 is broken; do not target it.
v19 was sunset February 11, 2026. Google maintains max 4 major versions simultaneously
(~1 year of support per major). Minor versions (e.g., v24.1) share their parent's sunset
date and contain only additive changes.

### Precision Scheduling (v23)

v23 replaced date-only `start_date`/`end_date` with datetime fields for minute-level control:

```python
# Schedule campaign to run Feb 14 noon to midnight EST
camp.start_date_time = "2026-02-14T12:00:00-05:00"
camp.end_date_time = "2026-02-14T23:59:59-05:00"
```

## Critical Gotchas

1. **login_customer_id ≠ customer_id**: `login_customer_id` is the MCC through which you access accounts. `customer_id` is the target account in API calls. Mixing them → `USER_PERMISSION_DENIED`.

2. **Costs are in micros**: `metrics.cost_micros = 5000000` means $5.00. Always divide by 1,000,000.

3. **No OR in GAQL WHERE**: Only `AND`. For OR logic, run multiple queries.

4. **Date segments require date ranges**: If `segments.date` is in `SELECT`, you must have `segments.date DURING X` or `BETWEEN` in `WHERE`.

5. **Feed entities were removed in v19**: All extensions use Asset/AssetSet resources now.

6. **Create operations are NOT idempotent**: Retrying a failed create may produce duplicates. Use `order_id` for conversion uploads as a dedup key.

7. **Publish your OAuth app**: Unpublished apps have 7-day refresh token expiry. Publish the app (even as internal) to get persistent tokens.

8. **EU consent fields are mandatory**: Always set `consent.ad_user_data` and `consent.ad_personalization` on conversion uploads for EU traffic.

9. **CallAd removed in v23**: `CallAd` and `CallAdInfo` were removed entirely. Use Call extensions via Assets instead.

10. **Ad sharing blocked in v23**: Sharing an ad across multiple ad groups now returns `AD_SHARING_NOT_ALLOWED`. Create separate ads per ad group.

11. **Enhanced Conversions for Leads replaces legacy offline imports**: Google recommends migrating GCLID-only offline conversion uploads to Enhanced Conversions for Leads (hashed user data matching). Typical lift: 15-30% more attributed conversions. Migrate via Data Manager API or ConversionUploadService with `user_identifiers`. See `references/first-party-data-strategy.md`.

12. **Consent Mode V2 mandatory for EU/EEA**: Without the V2 signals (`ad_user_data`, `ad_personalization`), remarketing and Customer Match are blocked for EU traffic. All conversion uploads and Customer Match operations must include consent fields.

13. **First-party uploads gated toward Data Manager API** (`last_verified: 2026-07-17`): Since **April 1, 2026**, Customer Match via `OfflineUserDataJobService` is blocked for developer tokens without recent (180-day) Customer Match activity; since **June 15, 2026**, `ConversionUploadService.UploadClickConversions` (offline conversions + Enhanced Conversions for Leads) is blocked for new adopters / tokens inactive Dec 2025–May 2026. Non-allowlisted callers get `CUSTOMER_NOT_ALLOWLISTED_FOR_THIS_FEATURE`. Migrate new integrations to **Data Manager API**. See `references/first-party-data-strategy.md`.

14. **GAQL date-segment lookback capped at 37 months** (`last_verified: 2026-07-17`): Queries using **daily/weekly/hourly** granularity (`segments.date`, `segments.week`, hour segments) only support the last **37 months**. Beyond that, v24.1+ returns `DateRangeError.REQUESTED_DATE_GRANULARITY_NOT_SUPPORTED` (earlier versions: `DateRangeError.INVALID_DATE`). For older history, fall back to `segments.month`/`segments.quarter`/`segments.year`. See `references/gaql-reference.md`.

## Community & AI Integration

- **Official Discord**: `discord.com/invite/djsM2JfQaG` (~20K members, active Google DevRel)
- **Developer Blog**: `ads-developers.googleblog.com`
- **GitHub**: `github.com/googleads` (111+ repos — all 6 client libraries + samples)
- **Stack Overflow**: Tags `google-ads-api`, `google-ads-script`
- **Reddit**: r/PPC, r/googleads
- **GAQL Query Builder**: `developers.google.com/google-ads/api/fields/v24/campaign_query_builder`
- **MCP Server**: Official open-source Model Context Protocol server at
  `github.com/google-marketing-solutions/google_ads_mcp` — enables LLMs (Gemini, Claude)
  to query Google Ads via natural language. Declared read-only (Oct 2025); write capability
  not re-verified this pass (last_verified: 2026-07-17). See `references/ecosystem-tools.md`.
- Legacy Google Groups (`groups.google.com/g/adwords-api`) is being sunset in 2026.

## Integracion con Skill creative-multimedia

El skill `creative-multimedia` (`.claude/skills/creative-multimedia/`) produce assets listos para
Google Ads. Genera imagenes y videos adaptados a Display, PMax, Demand Gen y YouTube con las
dimensiones y formato exactos. Usar ese skill para PRODUCIR assets y este skill para SUBIRLOS.

### Placements disponibles (generados por `asset_adapter.py`)

**Imagen:** `responsive_display_landscape` (1200x628, 1.91:1), `responsive_display_square` (1200x1200, 1:1),
`responsive_display_small` (300x250, 6:5), `pmax_landscape` (1200x628, 1.91:1), `pmax_square` (1200x1200, 1:1),
`pmax_portrait` (960x1200, 4:5), `demand_gen_image` (1200x628, 1.91:1), `demand_gen_square` (1200x1200, 1:1),
`demand_gen_portrait` (960x1200, 4:5)

**Video:** `youtube_video` (1920x1080, 16:9), `youtube_shorts` (1080x1920, 9:16),
`youtube_bumper` (1920x1080, 16:9, exacto 6s)

### Flujo de subida de assets

```python
# 1. creative-multimedia genera los assets
result = await pipeline.produce(brief={..., "platforms": ["google"]}, brand=brand)
google_assets = result["assets"]["google"]

# 2. Subir imagen -> bytes base64 en AssetOperation.create (NO hay upload de archivo)
import base64
with open(asset["path"], "rb") as f:
    image_data = base64.b64encode(f.read()).decode()

asset_operation = client.get_type("AssetOperation")
asset_obj = asset_operation.create
asset_obj.name = f"campaign_image_{placement}"
asset_obj.image_asset.data = base64.b64decode(image_data)
# mutate: asset_service.mutate_assets(customer_id, [asset_operation])

# 3. Subir video -> YouTube primero, luego referenciar youtube_video_id
# Videos NO se suben directo a Google Ads — se suben a YouTube
# y se referencian con el youtube_video_id en el asset
asset_obj.youtube_video_asset.youtube_video_id = "VIDEO_ID_DE_YOUTUBE"

# 4. PMax Asset Group — requiere multiples ratios obligatorios
# Minimo: 1 landscape (1.91:1) + 1 square (1:1) + 1 portrait (4:5)
# creative-multimedia genera los 3 automaticamente
```

### Referencia cruzada

| Archivo en creative-multimedia | Que consultar |
|---|---|
| `references/cross-platform-specs.md` | Specs exactas por placement de Google |
| `scripts/asset_adapter.py` → `PLATFORM_SPECS["google"]` | Fuente de verdad de dimensiones |
| `scripts/quality_checker.py` | Validacion pre-upload |

| Archivo en google-ads-api | Que consulta creative-multimedia |
|---|---|
| `references/ad-creative-guide.md` | Formatos, ratios, mejores practicas |
| `references/ecosystem-tools.md` | gaarf CLI, SDK Python |
| `references/campaign-management.md` | Tipos de campana y requisitos de assets |

---

## Cross-Skill Integration

Beyond `creative-multimedia` (asset production, above), this skill plugs into the Talent Academy
backend when the app itself must push signals to Google Ads — the canonical case is a **server-side
conversion upload** fired from an internal event (a completed sale, a qualified lead), routed through
the **Data Manager API** (the mandated path for new integrations, see the Data Manager mandate above).

```ts
// Next.js Server Action (Supabase user-context) → internal webhook → Data Manager API upload.
// Sketch only — full runnable example (payload shaping, hashing, consent gate) lives in the reference.
"use server"
export async function reportConversion(saleId: string) {
  // 1. load the sale + hashed user identifiers (email/phone) under RLS
  // 2. POST to the internal collector that owns the Data Manager API credentials (server-only)
  // 3. never call ConversionUploadService directly — it is allowlist-gated since June 15, 2026
}
```

Full worked example (Server Action + collector + Data Manager API payload) →
`references/first-party-data-strategy.md`.

---

## Next Steps

Read the reference files based on your task:
- **Setting up from scratch?** → `references/auth-and-setup.md`
- **Writing GAQL queries?** → `references/gaql-reference.md`
- **Creating campaigns?** → `references/campaign-management.md`
- **Using SDKs, CLI tools, MCP, or third-party integrations?** → `references/ecosystem-tools.md`
- **Automating or scaling?** → `references/automation-and-reporting.md`
- **Writing winning ad copy, building assets, or optimizing creatives?** → `references/ad-creative-guide.md`
- **First-party data, CRM integration, enhanced conversions, value-based bidding, customer match strategy, or privacy/consent?** → `references/first-party-data-strategy.md`
- **Managing audiences, remarketing, targeting, or retargeting funnels?** → `references/audiences-targeting.md`
- **Choosing or troubleshooting bid strategies?** → `references/smart-bidding.md`
- **Pulling reports, understanding attribution, or analyzing metrics?** → `references/analytics-reporting.md`
- **Handling rate limits, errors, or retry logic?** → `references/rate-limits.md`
- **Building automation, polling, alerts, or scheduled operations?** → `references/webhooks-automation.md`
