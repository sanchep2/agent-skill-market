# iOS Native — Skill de Claude Code

Skill instalable para Claude Code que cubre el desarrollo de una **app iOS nativa moderna en Swift puro**: SwiftUI (con Liquid Glass), arquitectura (TCA y/o MVVM standalone), concurrencia con async/await y actors, red con URLSession + Codable, persistencia con SwiftData, navegación con NavigationStack y deep links, widgets, Live Activities / Dynamic Island y testing con Swift Testing + snapshots.

Es **autocontenida**: no depende de ningún repositorio externo, backend compartido ni puente entre lenguajes. Todo el stack vive en Swift.

## Qué hace

Cuando Claude Code detecta que estás construyendo una app iOS (pantallas SwiftUI, features, navegación, red, base de datos local, widgets o tests), este skill aporta patrones actuales y opinados:

- **UI** — SwiftUI: layout, animaciones, componentes, Liquid Glass (`glassEffect`, `GlassEffectContainer`).
- **Arquitectura** — The Composable Architecture (TCA) como opción escalable y MVVM con `@Observable` como alternativa ligera; cuándo usar cada una.
- **Concurrencia** — async/await, actors, `@Observable`, Swift 6 strict concurrency.
- **Red** — capa propia sobre `URLSession` async, `Codable`, manejo de errores, auth con Keychain.
- **Persistencia** — SwiftData (`@Model`, `@Query`, migraciones), offline-first, nota sobre Core Data.
- **Navegación** — `NavigationStack`, rutas basadas en estado, deep links y universal links.
- **Extras** — carga de imágenes, widgets (WidgetKit), Live Activities y Dynamic Island, permisos.
- **Testing** — Swift Testing, TCA `TestStore`, mocking, snapshot testing y CI.

## Instalación

### Prerrequisito: Claude Code instalado

Si aún no lo tienes: https://claude.com/code — verifica con `claude --version`.

### Paso 1 — Descomprimir el skill

```bash
# Instalación global (disponible en todas tus sesiones)
mkdir -p ~/.claude/skills
cd ~/.claude/skills
unzip /ruta/a/ios-native.zip
```

Esto crea `~/.claude/skills/ios-native/` con todo el contenido.

> **Alternativa por proyecto:** descomprime dentro de `.claude/skills/` de tu repositorio para que el skill viaje con ese proyecto.

### Paso 2 — Reiniciar Claude Code

Cierra e inicia de nuevo Claude Code para que detecte el skill. Listo — no requiere claves, MCP ni dependencias externas.

## Uso básico

En cualquier sesión de Claude Code puedes pedir, por ejemplo:

```
"Crea una pantalla de feed con SwiftUI y NavigationStack"
"Monta la capa de red con URLSession y un cliente genérico con async/await"
"Añade persistencia local con SwiftData y un patrón offline-first"
"Implementa un widget que muestre los últimos elementos"
"Escribe tests con Swift Testing para el API client"
"¿TCA o MVVM para esta feature?"
```

Claude Code activará el skill automáticamente cuando el contexto sea iOS/Swift. Para forzarlo:

```
"Usa el skill ios-native: <tu petición>"
```

## Estructura del skill

```
ios-native/
├── SKILL.md                     # entry point (siempre cargado): stack, versiones, decisiones, quick start
├── README.md                    # este archivo
└── references/                  # documentación bajo demanda (progressive disclosure)
    ├── swiftui.md               # SwiftUI + Liquid Glass, layout, animaciones, @Observable, concurrencia
    ├── architecture.md          # TCA (core, side effects, navegación, shared state) + MVVM standalone
    ├── networking.md            # URLSession async, Codable, cliente genérico, auth + Keychain
    ├── persistence.md           # SwiftData (@Model, @Query, migraciones), offline-first, Core Data
    ├── navigation.md            # NavigationStack, rutas por estado, deep links, universal links
    ├── platform-features.md     # WidgetKit, Live Activities, Dynamic Island, push
    └── testing.md               # Swift Testing, TestStore, mocking, snapshots, CI
```

## Cómo cargar referencias bajo demanda

El skill usa **progressive disclosure**: `SKILL.md` (corto) siempre está en contexto; las referencias se cargan solo cuando hacen falta. La tabla "Cuándo cargar qué referencia" del `SKILL.md` lo guía. También puedes pedirlo explícitamente:

```
"Lee references/networking.md, vamos a montar el cliente HTTP"
```

## Versiones verificadas (julio 2026)

Todas las versiones y APIs se verificaron contra la documentación oficial de Apple y los índices de paquetes el **5 de julio de 2026**:

- **Swift 6.3.3** · **Xcode 26.6** · **SDK de iOS 26** (obligatorio para App Store desde el 28-abr-2026)
- **The Composable Architecture 1.26.0** · **Kingfisher 8.10.0** · **Nuke 13.0.6** · **swift-snapshot-testing 1.19.2**
- **Swift Testing** incluido con Xcode 26
- **Liquid Glass** (iOS 26.0+) y **SwiftData** como baseline de iOS 26

Al usarlo, confirma siempre la última versión estable disponible en tu fecha.

## Actualizar el skill

```bash
cd ~/.claude/skills/
rm -rf ios-native/
unzip /ruta/a/ios-native-nuevo.zip
```

## Solución de problemas

### El skill no se activa cuando hablo de iOS

Verifica que el `SKILL.md` existe:

```bash
ls ~/.claude/skills/ios-native/SKILL.md
```

Si existe pero no auto-detecta, fuérzalo: `"Usa el skill ios-native: <tu petición>"`.

### Las referencias no se cargan

Son ficheros bajo demanda; pídelas por nombre: `"Lee references/persistence.md"`.

### El código de ejemplo no compila en mi versión de Xcode

El skill fija su baseline en el SDK de iOS 26 / Swift 6.3.x. Si usas una versión anterior, algunas APIs (p. ej. Liquid Glass, novedades de SwiftData) no estarán disponibles; ajusta el deployment target o usa las variantes con `if #available`.

---

_Cortesía de Talent Academy · Vibe Coder._
