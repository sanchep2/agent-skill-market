# Architecture — TCA Applied to Features (Native iOS)

> Reference for the `ios-native` skill. Pure Swift, no cross-language shared layer. For navigation specifics, see `NAVIGATION.md`.
>
> Verified toolchain: Swift 6.3.3, Xcode 26.6, iOS 26 SDK. TCA 1.26.0 (`@Reducer`, `@ObservableState`, `@DependencyClient`). SwiftData baseline iOS 17+.

## Table of Contents

1. [TCA Core Pattern](#1-tca-core-pattern)
2. [@Dependency System — Native URLSession Clients](#2-dependency-system--native-urlsession-clients)
3. [Reducer Composition](#3-reducer-composition)
4. [Side Effects Patterns](#4-side-effects-patterns)
5. [Error Handling](#5-error-handling)
6. [Offline-First Pattern — SwiftData Cache](#6-offline-first-pattern--swiftdata-cache)
7. [Delegate Actions for Parent-Child Communication](#7-delegate-actions)
8. [Cancellation and Debounce](#8-cancellation-and-debounce)
9. [Shared State](#9-shared-state)
10. [MVVM / @Observable as a Lightweight Standalone Alternative to TCA](#10-mvvm--observable-as-a-lightweight-standalone-alternative-to-tca)

---

## 1. TCA Core Pattern

Every feature follows this structure. The `@Reducer` macro auto-applies `@CasePathable` to Action and generates key-path syntax.

### Complete feature example: Feed

```swift
import ComposableArchitecture
import IdentifiedCollections

@Reducer
struct FeedFeature {
    // MARK: - State

    @ObservableState
    struct State: Equatable {
        var items: IdentifiedArrayOf<FeedItem> = []
        var filter: Filter = .all
        var isLoading = false
        var error: String?
        var page = 1
        var hasMorePages = true
        @Presents var destination: Destination.State?
    }

    enum Filter: String, CaseIterable, Equatable {
        case all, favorites, recent
    }

    // MARK: - Action

    enum Action: BindableAction {
        case onAppear
        case refresh
        case loadNextPage
        case itemsLoaded(Result<[FeedItem], Error>)
        case filterChanged(Filter)
        case itemTapped(FeedItem.ID)
        case toggleFavorite(FeedItem.ID)
        case favoriteToggled(Result<FeedItem.ID, Error>)
        case destination(PresentationAction<Destination.Action>)
        case binding(BindingAction<State>)
    }

    // MARK: - Dependencies

    @Dependency(\.feedClient) var feedClient
    @Dependency(\.hapticClient) var haptics

    // MARK: - Cancellation IDs

    private enum CancelID { case load }

    // MARK: - Body

    var body: some ReducerOf<Self> {
        BindingReducer()

        Reduce { state, action in
            switch action {
            case .onAppear:
                guard state.items.isEmpty else { return .none }
                state.isLoading = true
                return .run { [page = state.page, filter = state.filter] send in
                    let result = await Result {
                        try await feedClient.fetch(page, filter)
                    }
                    await send(.itemsLoaded(result))
                }
                .cancellable(id: CancelID.load)

            case .refresh:
                state.page = 1
                state.hasMorePages = true
                return .run { [filter = state.filter] send in
                    let result = await Result {
                        try await feedClient.fetch(1, filter)
                    }
                    await send(.itemsLoaded(result))
                }
                .cancellable(id: CancelID.load, cancelInFlight: true)

            case .loadNextPage:
                guard !state.isLoading, state.hasMorePages else { return .none }
                state.page += 1
                state.isLoading = true
                return .run { [page = state.page, filter = state.filter] send in
                    let result = await Result {
                        try await feedClient.fetch(page, filter)
                    }
                    await send(.itemsLoaded(result))
                }

            case let .itemsLoaded(.success(newItems)):
                if state.page == 1 {
                    state.items = IdentifiedArray(uniqueElements: newItems)
                } else {
                    state.items.append(contentsOf: newItems)
                }
                state.hasMorePages = !newItems.isEmpty
                state.isLoading = false
                state.error = nil
                return .none

            case let .itemsLoaded(.failure(error)):
                state.isLoading = false
                state.error = error.localizedDescription
                return .none

            case let .filterChanged(filter):
                state.filter = filter
                state.page = 1
                state.items = []
                return .send(.refresh)

            case let .itemTapped(id):
                guard let item = state.items[id: id] else { return .none }
                state.destination = .detail(DetailFeature.State(item: item))
                return .none

            case let .toggleFavorite(id):
                return .run { send in
                    await haptics.impact(.light)
                    let result = await Result { try await feedClient.toggleFavorite(id) }
                    await send(.favoriteToggled(result))
                }

            case let .favoriteToggled(.success(id)):
                state.items[id: id]?.isFavorite.toggle()
                return .none

            case .favoriteToggled(.failure):
                return .none // Could show toast

            case .destination, .binding:
                return .none
            }
        }
        .ifLet(\.$destination, action: \.destination)
    }

    // MARK: - Destination

    @Reducer(state: .equatable)
    enum Destination {
        case detail(DetailFeature)
        case share(ShareFeature)
    }
}
```

### The View (no WithViewStore)

```swift
struct FeedView: View {
    @Bindable var store: StoreOf<FeedFeature>

    var body: some View {
        Group {
            if store.isLoading && store.items.isEmpty {
                SkeletonFeedView()
            } else if let error = store.error, store.items.isEmpty {
                ErrorView(message: error) { store.send(.refresh) }
            } else if store.items.isEmpty {
                EmptyStateView(icon: "tray", title: "No items")
            } else {
                feedContent
            }
        }
        .navigationTitle("Feed")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Picker("Filter", selection: $store.filter.sending(\.filterChanged)) {
                        ForEach(FeedFeature.Filter.allCases, id: \.self) {
                            Text($0.rawValue.capitalized)
                        }
                    }
                } label: {
                    Image(systemName: "line.3.horizontal.decrease.circle")
                }
            }
        }
        .sheet(item: $store.scope(state: \.destination?.detail, action: \.destination.detail)) {
            DetailView(store: $0)
        }
        .task { store.send(.onAppear) }
    }

    private var feedContent: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(store.items) { item in
                    ContentCard(item: item) {
                        store.send(.toggleFavorite(item.id))
                    }
                    .onTapGesture { store.send(.itemTapped(item.id)) }
                    .onAppear {
                        if item.id == store.items.last?.id {
                            store.send(.loadNextPage)
                        }
                    }
                }

                if store.isLoading {
                    ProgressView().padding()
                }
            }
            .padding(.horizontal)
        }
        .refreshable { await store.send(.refresh).finish() }
    }
}
```

---

## 2. @Dependency System — Native URLSession Clients

In a pure-Swift app there is no foreign shared layer to bridge. Every external service — your backend, a system API, analytics — is modeled as a TCA dependency client whose `liveValue` is backed by a **native `URLSession` API client** using `async`/`await` and `Codable`. Domain models are ordinary Swift value types that conform to `Sendable`, `Decodable`, and `Equatable`. There are no cross-language DTOs and no manual mapping step: `URLSession` + `JSONDecoder` produce your domain models directly.

### Native domain models

```swift
struct FeedItem: Identifiable, Equatable, Sendable, Codable {
    let id: UUID
    var title: String
    var body: String
    var isFavorite: Bool
    let createdAt: Date
}
```

Because `FeedItem` is a value type composed of `Sendable` members, the compiler synthesizes `Sendable` conformance for free under Swift 6's strict concurrency checking — no `@unchecked` escape hatch, no `@preconcurrency` import. The same holds for `FeedItem.Filter` and any request/response payloads.

### The underlying URLSession API client

Keep the transport in one small, testable type. It knows how to build a `URLRequest`, run it on `URLSession`, validate the HTTP status, and decode JSON. Everything above it speaks in domain models.

```swift
struct APIError: LocalizedError, Equatable {
    enum Kind: Equatable {
        case transport            // no response / connectivity
        case status(Int)          // non-2xx
        case decoding             // body did not match the model
        case unauthorized         // 401 / 403
    }
    let kind: Kind

    var errorDescription: String? {
        switch kind {
        case .transport:        return "Network is unavailable."
        case .status(let code): return "Request failed (HTTP \(code))."
        case .decoding:         return "The server response could not be read."
        case .unauthorized:     return "Please sign in again."
        }
    }
}

struct APIClient: Sendable {
    var session: URLSession = .shared
    var baseURL: URL

    private static let decoder: JSONDecoder = {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .iso8601
        d.keyDecodingStrategy = .convertFromSnakeCase
        return d
    }()

    /// Runs a GET and decodes the body into `T`. Errors are surfaced as `APIError`.
    func get<T: Decodable & Sendable>(
        _ path: String,
        query: [URLQueryItem] = []
    ) async throws -> T {
        var components = URLComponents(
            url: baseURL.appending(path: path),
            resolvingAgainstBaseURL: false
        )!
        if !query.isEmpty { components.queryItems = query }
        var request = URLRequest(url: components.url!)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await session.data(for: request)
        } catch {
            throw APIError(kind: .transport)
        }

        guard let http = response as? HTTPURLResponse else {
            throw APIError(kind: .transport)
        }
        switch http.statusCode {
        case 200...299:
            do { return try Self.decoder.decode(T.self, from: data) }
            catch { throw APIError(kind: .decoding) }
        case 401, 403:
            throw APIError(kind: .unauthorized)
        default:
            throw APIError(kind: .status(http.statusCode))
        }
    }

    /// Runs a mutating request (POST/PUT/DELETE) and decodes the body.
    func send<Body: Encodable & Sendable, T: Decodable & Sendable>(
        _ method: String,
        _ path: String,
        body: Body
    ) async throws -> T {
        var request = URLRequest(url: baseURL.appending(path: path))
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(body)

        do {
            let (data, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                throw APIError(kind: .transport)
            }
            guard (200...299).contains(http.statusCode) else {
                throw http.statusCode == 401 || http.statusCode == 403
                    ? APIError(kind: .unauthorized)
                    : APIError(kind: .status(http.statusCode))
            }
            return try Self.decoder.decode(T.self, from: data)
        } catch let error as APIError {
            throw error
        } catch is DecodingError {
            throw APIError(kind: .decoding)
        } catch {
            throw APIError(kind: .transport)
        }
    }
}
```

### The dependency client (`@DependencyClient`)

The client is a struct of closures — not a protocol. `@DependencyClient` (TCA 1.26.0) synthesizes an "unimplemented" `testValue` automatically: any endpoint you forget to override in a test fails loudly instead of returning garbage.

```swift
import ComposableArchitecture

@DependencyClient
struct FeedClient: Sendable {
    var fetch: @Sendable (_ page: Int, _ filter: FeedFeature.Filter) async throws -> [FeedItem]
    var toggleFavorite: @Sendable (_ id: FeedItem.ID) async throws -> FeedItem.ID
    var delete: @Sendable (_ id: FeedItem.ID) async throws -> Void
}
```

`liveValue` wires the closures to the `URLSession`-backed `APIClient`. The transport throws `APIError`; the closures propagate it (native `throws` — the `Result` boundary is drawn in the reducer via `await Result { … }`, as in §1).

```swift
extension FeedClient: DependencyKey {
    static let liveValue: FeedClient = {
        let api = APIClient(baseURL: URL(string: "https://api.example.com")!)
        return FeedClient(
            fetch: { page, filter in
                // Returns [FeedItem] directly — JSONDecoder produces domain models.
                try await api.get(
                    "feed",
                    query: [
                        .init(name: "page", value: String(page)),
                        .init(name: "filter", value: filter.rawValue),
                    ]
                )
            },
            toggleFavorite: { id in
                struct Ack: Decodable, Sendable { let id: UUID }
                let ack: Ack = try await api.send(
                    "POST", "feed/\(id)/favorite", body: EmptyBody()
                )
                return ack.id
            },
            delete: { id in
                let _: EmptyResponse = try await api.send(
                    "DELETE", "feed/\(id)", body: EmptyBody()
                )
            }
        )
    }()
}

private struct EmptyBody: Encodable, Sendable {}
private struct EmptyResponse: Decodable, Sendable {}
```

`previewValue` returns static data so SwiftUI previews and simulators run without a network. `@DependencyClient` already provides an unimplemented `testValue`, so you only override the endpoints a given test actually exercises.

```swift
extension FeedClient: TestDependencyKey {
    // testValue is auto-synthesized by @DependencyClient (every closure fails
    // if called). Provide previewValue for design-time and simulator runs.
    static let previewValue = FeedClient(
        fetch: { _, _ in FeedItem.mocks },
        toggleFavorite: { $0 },
        delete: { _ in }
    )
}

extension DependencyValues {
    var feedClient: FeedClient {
        get { self[FeedClient.self] }
        set { self[FeedClient.self] = newValue }
    }
}
```

### Testing with native error propagation

Because the client returns Swift values and throws `APIError`, tests read naturally — override only what the case-under-test touches:

```swift
@Test
func fetchFailureSurfacesError() async {
    let store = TestStore(initialState: FeedFeature.State()) {
        FeedFeature()
    } withDependencies: {
        $0.feedClient.fetch = { _, _ in throw APIError(kind: .status(500)) }
    }
    await store.send(.onAppear) { $0.isLoading = true }
    await store.receive(\.itemsLoaded.failure) {
        $0.isLoading = false
        $0.error = "Request failed (HTTP 500)."
    }
}
```

### System-level dependencies

```swift
// Haptics
struct HapticClient: DependencyKey {
    var impact: @Sendable (UIImpactFeedbackGenerator.FeedbackStyle) async -> Void

    static let liveValue = Self(impact: { style in
        await UIImpactFeedbackGenerator(style: style).impactOccurred()
    })
    static let testValue = Self(impact: { _ in })
}

// Date, UUID and clock (TCA provides these — controllable in tests)
@Dependency(\.date.now) var now
@Dependency(\.uuid) var uuid
@Dependency(\.continuousClock) var clock
```

---

## 3. Reducer Composition

### Scope: embedding child features

```swift
@Reducer
struct AppFeature {
    @ObservableState
    struct State: Equatable {
        var feed = FeedFeature.State()
        var search = SearchFeature.State()
        var profile = ProfileFeature.State()
        var selectedTab: Tab = .feed
    }

    enum Tab: Equatable { case feed, search, profile }

    enum Action {
        case feed(FeedFeature.Action)
        case search(SearchFeature.Action)
        case profile(ProfileFeature.Action)
        case tabSelected(Tab)
    }

    var body: some ReducerOf<Self> {
        Scope(state: \.feed, action: \.feed) { FeedFeature() }
        Scope(state: \.search, action: \.search) { SearchFeature() }
        Scope(state: \.profile, action: \.profile) { ProfileFeature() }

        Reduce { state, action in
            switch action {
            case let .tabSelected(tab):
                state.selectedTab = tab
                return .none
            case .feed, .search, .profile:
                return .none
            }
        }
    }
}
```

### View scoping

```swift
struct AppView: View {
    @Bindable var store: StoreOf<AppFeature>

    var body: some View {
        TabView(selection: $store.selectedTab.sending(\.tabSelected)) {
            Tab("Feed", systemImage: "list.star", value: .feed) {
                NavigationStack {
                    FeedView(store: store.scope(state: \.feed, action: \.feed))
                }
            }
            Tab("Search", systemImage: "magnifyingglass", value: .search) {
                NavigationStack {
                    SearchView(store: store.scope(state: \.search, action: \.search))
                }
            }
            Tab("Profile", systemImage: "person", value: .profile) {
                NavigationStack {
                    ProfileView(store: store.scope(state: \.profile, action: \.profile))
                }
            }
        }
        .tabBarMinimizeBehavior(.onScrollDown)
    }
}
```

---

## 4. Side Effects Patterns

### `.run` — for async work

```swift
return .run { send in
    let items = try await feedClient.fetch(1, .all)
    await send(.itemsLoaded(.success(items)))
} catch: { error, send in
    await send(.itemsLoaded(.failure(error)))
}
```

### `.send` — for synchronous chaining

```swift
case .loginSucceeded:
    state.isLoggedIn = true
    return .send(.loadUserProfile)
```

### `.merge` / `.concatenate` — multiple effects

`.merge` runs effects concurrently; `.concatenate` runs them in strict order, each awaiting the previous to finish.

```swift
return .merge(
    .send(.loadProfile),
    .send(.loadNotifications),
    .run { _ in await analytics.track("login_success") }
)
```

### Long-running observation

```swift
case .onAppear:
    return .run { send in
        for await items in feedClient.observe() {
            await send(.itemsUpdated(items))
        }
    }
    .cancellable(id: CancelID.observe)

case .onDisappear:
    return .cancel(id: CancelID.observe)
```

---

## 5. Error Handling

### Typed, localized errors from the API client

The `URLSession`-backed client throws `APIError` (§2), which conforms to `LocalizedError`. Reducers wrap the throwing call in `await Result { … }` and switch on the failure. Define a feature-level error only when you need to add domain semantics on top of transport failures.

```swift
enum FeedError: LocalizedError, Equatable {
    case network(String)
    case notFound
    case unauthorized

    var errorDescription: String? {
        switch self {
        case .network(let msg): return msg
        case .notFound:         return "Content not found"
        case .unauthorized:     return "Please log in again"
        }
    }
}
```

Map transport errors into domain errors at the client boundary when it clarifies the reducer:

```swift
fetch: { page, filter in
    do {
        return try await api.get("feed", query: [
            .init(name: "page", value: String(page)),
            .init(name: "filter", value: filter.rawValue),
        ])
    } catch let error as APIError where error.kind == .unauthorized {
        throw FeedError.unauthorized
    } catch let error as APIError {
        throw FeedError.network(error.localizedDescription)
    }
}
```

### Error state in reducer

```swift
case let .itemsLoaded(.failure(error)):
    state.isLoading = false
    if let feedError = error as? FeedError {
        switch feedError {
        case .unauthorized:
            // Bubble up to the parent to route to login
            return .send(.delegate(.requiresAuth))
        default:
            state.error = feedError.localizedDescription
        }
    } else if let apiError = error as? APIError, apiError.kind == .unauthorized {
        return .send(.delegate(.requiresAuth))
    } else {
        state.error = "An unexpected error occurred"
    }
    return .none
```

---

## 6. Offline-First Pattern — SwiftData Cache

### Architecture: SwiftData cache → URLSession sync → TCA

The offline-first loop is entirely native. **SwiftData** is the on-device cache: a `@Model` class holds the persisted rows, a `ModelContext` reads and writes them, and a `ModelActor` gives you a thread-safe context for background sync so you never mutate the main-context store off the main thread. The network side is plain `URLSession` (via the `APIClient` from §2). Changes flow to TCA through a dependency that exposes an `AsyncStream` of the current cache snapshot; the reducer treats that stream exactly like any other long-running effect.

The shape is: **observe the cache for instant UI → kick off a background sync → sync writes fresh rows into SwiftData → the observation stream re-emits → UI updates.** The UI never blocks on the network.

### The SwiftData model and actor

```swift
import SwiftData

@Model
final class CachedFeedItem {
    @Attribute(.unique) var id: UUID
    var title: String
    var body: String
    var isFavorite: Bool
    var createdAt: Date

    init(id: UUID, title: String, body: String, isFavorite: Bool, createdAt: Date) {
        self.id = id
        self.title = title
        self.body = body
        self.isFavorite = isFavorite
        self.createdAt = createdAt
    }

    func toDomain() -> FeedItem {
        FeedItem(id: id, title: title, body: body,
                 isFavorite: isFavorite, createdAt: createdAt)
    }
}

/// A background actor owning its own ModelContext for off-main-thread writes.
@ModelActor
actor FeedStore {
    /// Reads the current cache snapshot as domain values.
    func snapshot() throws -> [FeedItem] {
        let descriptor = FetchDescriptor<CachedFeedItem>(
            sortBy: [SortDescriptor(\.createdAt, order: .reverse)]
        )
        return try modelContext.fetch(descriptor).map { $0.toDomain() }
    }

    /// Upserts fresh rows from the network into the cache.
    func merge(_ items: [FeedItem]) throws {
        for item in items {
            let id = item.id
            let existing = try modelContext.fetch(
                FetchDescriptor<CachedFeedItem>(predicate: #Predicate { $0.id == id })
            ).first
            if let row = existing {
                row.title = item.title
                row.body = item.body
                row.isFavorite = item.isFavorite
                row.createdAt = item.createdAt
            } else {
                modelContext.insert(CachedFeedItem(
                    id: item.id, title: item.title, body: item.body,
                    isFavorite: item.isFavorite, createdAt: item.createdAt
                ))
            }
        }
        try modelContext.save()
    }
}
```

### The dependency client — observe + sync

`observe()` bridges SwiftData changes into an `AsyncStream<[FeedItem]>`. It yields the current snapshot immediately, then re-emits whenever a sync writes to the store. A lightweight in-process notifier (a `Sendable` continuation registry, or SwiftData's `ModelContext` change notifications) triggers re-reads; here we drive it explicitly after each `sync`.

```swift
@DependencyClient
struct FeedClient: Sendable {
    var observe: @Sendable () -> AsyncStream<[FeedItem]> = { .finished }
    var sync: @Sendable () async throws -> Void
    var toggleFavorite: @Sendable (_ id: FeedItem.ID) async throws -> FeedItem.ID
}

extension FeedClient: DependencyKey {
    static let liveValue: FeedClient = {
        let container = try! ModelContainer(for: CachedFeedItem.self)
        let store = FeedStore(modelContainer: container)
        let api = APIClient(baseURL: URL(string: "https://api.example.com")!)

        // A tiny multicast so observers re-read after each sync.
        let (stream, continuation) = AsyncStream<Void>.makeStream()

        return FeedClient(
            observe: {
                AsyncStream { downstream in
                    let task = Task {
                        // Emit the current cache immediately.
                        if let first = try? await store.snapshot() {
                            downstream.yield(first)
                        }
                        // Re-emit on every sync tick.
                        for await _ in stream {
                            if let items = try? await store.snapshot() {
                                downstream.yield(items)
                            }
                        }
                        downstream.finish()
                    }
                    downstream.onTermination = { _ in task.cancel() }
                }
            },
            sync: {
                let fresh: [FeedItem] = try await api.get("feed")
                try await store.merge(fresh)
                continuation.yield(())   // wake observers → re-read cache
            },
            toggleFavorite: { id in
                struct Ack: Decodable, Sendable { let id: UUID }
                let ack: Ack = try await api.send(
                    "POST", "feed/\(id)/favorite", body: EmptyBody()
                )
                continuation.yield(())
                return ack.id
            }
        )
    }()
}

private struct EmptyBody: Encodable, Sendable {}
```

### Reducer pattern

```swift
case .onAppear:
    return .merge(
        // 1. Observe local cache (instant UI, even offline)
        .run { send in
            for await items in feedClient.observe() {
                await send(.localItemsUpdated(items))
            }
        }
        .cancellable(id: CancelID.observe),

        // 2. Trigger a background sync over URLSession
        .run { send in
            let result = await Result { try await feedClient.sync() }
            await send(.syncCompleted(result))
        }
    )

case let .localItemsUpdated(items):
    state.items = IdentifiedArray(uniqueElements: items)
    state.isLoading = false
    return .none

case .syncCompleted(.success):
    // SwiftData write already re-emitted via observe → localItemsUpdated.
    return .none

case .syncCompleted(.failure):
    state.syncError = "Offline — showing cached data"
    return .none
```

The reducer never distinguishes "from cache" versus "from network" — it only reacts to `localItemsUpdated`. That single source of truth (SwiftData) is what makes the feature correct offline: the first snapshot renders instantly from disk, and a successful sync simply produces a newer snapshot through the same channel.

---

## 7. Delegate Actions

Child features expose delegate actions instead of navigating or mutating parent state:

```swift
@Reducer
struct DetailFeature {
    // ...
    enum Action {
        case editTapped
        case deleteTapped
        case delegate(Delegate)

        enum Delegate: Equatable {
            case editItem(FeedItem)
            case itemDeleted(FeedItem.ID)
        }
    }

    var body: some ReducerOf<Self> {
        Reduce { state, action in
            switch action {
            case .editTapped:
                return .send(.delegate(.editItem(state.item)))
            case .deleteTapped:
                return .run { [id = state.item.id] send in
                    try await feedClient.delete(id)
                    await send(.delegate(.itemDeleted(id)))
                }
            case .delegate:
                return .none // Handled by parent
            }
        }
    }
}

// Parent intercepts:
case .path(.element(_, action: .detail(.delegate(.itemDeleted(let id))))):
    state.feed.items.remove(id: id)
    state.path.removeLast()
    return .none
```

---

## 8. Cancellation and Debounce

### Cancel in-flight requests

```swift
return .run { send in
    let items = try await feedClient.fetch(page, filter)
    await send(.loaded(items))
}
.cancellable(id: CancelID.load, cancelInFlight: true)
// cancelInFlight: true → auto-cancels previous effect with same ID
```

### Debounce for search

```swift
case let .searchQueryChanged(query):
    state.searchQuery = query
    guard !query.isEmpty else {
        return .cancel(id: CancelID.search)
    }
    return .run { send in
        try await clock.sleep(for: .milliseconds(300))
        let results = try await searchClient.search(query)
        await send(.searchResults(results))
    }
    .cancellable(id: CancelID.search, cancelInFlight: true)
```

### Throttle for scroll events

```swift
case .scrolledNearBottom:
    return .run { send in
        try await clock.sleep(for: .milliseconds(500))
        await send(.loadNextPage)
    }
    .cancellable(id: CancelID.pagination, cancelInFlight: true)
```

The injected `@Dependency(\.continuousClock)` makes these deterministic in tests — a `TestClock` lets you advance time instantly instead of waiting real milliseconds.

---

## 9. Shared State

### @Shared (TCA built-in)

For state that persists across features or app launches:

```swift
@ObservableState
struct State: Equatable {
    @Shared(.appStorage("onboardingCompleted")) var onboardingDone = false
    @Shared(.fileStorage(.documentsDirectory.appending(path: "user.json")))
    var currentUser: User?
}
```

`.appStorage` is backed by `UserDefaults` (small key-value flags); `.fileStorage` serializes a `Codable` value to disk (larger structured state). Both persist across launches and stay in sync across every feature that references the same key.

### Cross-feature state via parent

For state needed by multiple children, put it in the parent and read from scoped stores:

```swift
// Parent state
struct State: Equatable {
    var currentUser: User?
    var feed = FeedFeature.State()
    // Feed reducer reads user via @Dependency or parent passes it
}
```

Prefer `@Dependency` over shared state for read-only values — it keeps features decoupled and testable.

---

## 10. MVVM / @Observable as a Lightweight Standalone Alternative to TCA

TCA earns its ceremony on features with real state complexity: multi-step flows, deep parent-child trees, exhaustive testing, undo/time-travel, or many interleaved effects that must cancel and compose precisely. For a **simple screen** — a single list, a form, a detail view with one or two async calls — that ceremony is overhead. Reach instead for plain **MVVM built on `@Observable`**: a Swift value/reference model driving a SwiftUI view, with `async`/`await` talking to a `URLSession`-backed service.

### When NOT to reach for TCA

Prefer MVVM when the screen has **local, self-contained state** and no need for:

- Exhaustive, action-by-action test coverage of a state machine.
- Composable, independently cancellable effects that merge/concatenate.
- A shared navigation tree coordinated across many features.
- Replayable/inspectable action history.

If a screen is "load some data, show it, handle one mutation," MVVM is less code and easier to read. You can always graduate a screen to TCA later — the domain model and the service layer carry over unchanged.

### A clean `@Observable` view model

`@Observable` (the Observation framework) tracks property reads automatically, so SwiftUI re-renders only the views that actually depend on a changed property — no `@Published`, no `ObservableObject`. The view model owns its state and drives async work with structured concurrency.

```swift
import Observation

@MainActor
@Observable
final class FeedViewModel {
    // View-facing state
    private(set) var items: [FeedItem] = []
    private(set) var isLoading = false
    var errorMessage: String?
    var filter: FeedItem.Filter = .all {
        didSet { Task { await load() } }
    }

    private let service: FeedService

    init(service: FeedService = .live) {
        self.service = service
    }

    func load() async {
        isLoading = true
        errorMessage = nil
        do {
            items = try await service.fetch(page: 1, filter: filter)
        } catch let error as APIError {
            errorMessage = error.localizedDescription
        } catch {
            errorMessage = "Something went wrong."
        }
        isLoading = false
    }

    func toggleFavorite(_ id: FeedItem.ID) async {
        do {
            _ = try await service.toggleFavorite(id)
            if let index = items.firstIndex(where: { $0.id == id }) {
                items[index].isFavorite.toggle()
            }
        } catch {
            errorMessage = "Couldn't update favorite."
        }
    }
}
```

### The URLSession-backed service

The service is the MVVM analogue of a TCA dependency client: a struct of closures with a `live` implementation over `URLSession`, plus mock implementations for previews and tests. It reuses the exact same `APIClient` and domain models from §2 — nothing about the transport changes between the two architectures.

```swift
struct FeedService: Sendable {
    var fetch: @Sendable (_ page: Int, _ filter: FeedItem.Filter) async throws -> [FeedItem]
    var toggleFavorite: @Sendable (_ id: FeedItem.ID) async throws -> FeedItem.ID
}

extension FeedService {
    static let live: FeedService = {
        let api = APIClient(baseURL: URL(string: "https://api.example.com")!)
        return FeedService(
            fetch: { page, filter in
                try await api.get("feed", query: [
                    .init(name: "page", value: String(page)),
                    .init(name: "filter", value: filter.rawValue),
                ])
            },
            toggleFavorite: { id in
                struct Ack: Decodable, Sendable { let id: UUID }
                let ack: Ack = try await api.send(
                    "POST", "feed/\(id)/favorite", body: EmptyServiceBody()
                )
                return ack.id
            }
        )
    }()

    static let preview = FeedService(
        fetch: { _, _ in FeedItem.mocks },
        toggleFavorite: { $0 }
    )
}

private struct EmptyServiceBody: Encodable, Sendable {}
```

### `@State` / `@Bindable` wiring in the View

The view **owns** its view model with `@State` (the view model is a reference type, but `@State` keeps it alive for the view's lifetime). Use `@Bindable` — inline or as a property — when you need two-way bindings to the model's mutable properties (`$model.filter`).

```swift
struct FeedScreen: View {
    @State private var model = FeedViewModel()

    var body: some View {
        // @Bindable exposes $-bindings to @Observable properties
        @Bindable var model = model

        List {
            if let error = model.errorMessage {
                ErrorRow(message: error)
            }
            ForEach(model.items) { item in
                ContentCard(item: item) {
                    Task { await model.toggleFavorite(item.id) }
                }
            }
        }
        .overlay {
            if model.isLoading { ProgressView() }
        }
        .navigationTitle("Feed")
        .toolbar {
            Picker("Filter", selection: $model.filter) {
                ForEach(FeedItem.Filter.allCases, id: \.self) {
                    Text($0.rawValue.capitalized)
                }
            }
        }
        .task { await model.load() }
        .refreshable { await model.load() }
    }
}
```

If a child view needs to mutate the same model, pass it down as `@Bindable var model: FeedViewModel` (a binding into shared observable state) rather than re-creating it — only the view that *creates* the model uses `@State`.

### TCA-vs-MVVM decision note

| Signal | Choose MVVM (`@Observable`) | Choose TCA |
|---|---|---|
| State complexity | One screen, local state | State machine, multi-step flows |
| Effects | One or two async calls | Many effects to merge/cancel/debounce |
| Navigation | Self-contained | Coordinated across a feature tree |
| Testing needs | Spot-check the model | Exhaustive, action-by-action |
| Shared/persisted state | Rare | Frequent (`@Shared`) |
| Team convention | Small app / few screens | Larger app, uniform architecture |

Both approaches share the same foundation — native domain models, `Sendable` value types, and a `URLSession`-backed client/service. That shared floor is deliberate: it keeps the transport and models identical, so promoting a screen from MVVM to TCA (or keeping the two side by side in one app) is a mechanical change to the presentation layer, not a rewrite of the data layer.
