# SwiftUI Patterns — iOS 18 / iOS 26

> Reference for the `ios-native` skill. For architecture and TCA, see `ARCHITECTURE.md`.
>
> **Toolchain (verified 2026-07-05):** Swift 6.3.3, Xcode 26.6 (released 2026-06-25), iOS 26 SDK (26.5). Building against the iOS 26 SDK is mandatory for App Store submission since 2026-04-28. Recommended minimum deployment target: **iOS 18** (Liquid Glass features require iOS 26.0+).

## Table of Contents

1. [Liquid Glass (iOS 26)](#1-liquid-glass-ios-26)
2. [Layout System](#2-layout-system)
3. [Lazy Containers and Lists](#3-lazy-containers-and-lists)
4. [Pull-to-Refresh and Loading States](#4-pull-to-refresh-and-loading-states)
5. [Search](#5-search)
6. [Sheets, Popovers, Inspectors](#6-sheets-popovers-inspectors)
7. [Animations and Transitions](#7-animations-and-transitions)
8. [Image Loading](#8-image-loading)
9. [Adaptive Layouts](#9-adaptive-layouts)
10. [Observation Model](#10-observation-model)
11. [Swift 6 Concurrency in SwiftUI](#11-swift-6-concurrency-in-swiftui)

---

## 1. Liquid Glass (iOS 26)

Liquid Glass is Apple's design language introduced at WWDC 2025 (shipped September 2025). It uses translucent materials that refract and concentrate light in real-time. It applies **exclusively to navigation/control chrome** — never to content. All APIs below require **iOS 26.0+**.

### Automatic adoption

When compiled with Xcode 26, these components get Liquid Glass automatically:
- **TabView** → floating, translucent tab bar
- **NavigationBar** → glass treatment on scroll
- **Toolbars** → glass-styled buttons
- **Sheets** → glass handles and chrome

### Core modifier: `.glassEffect()`

```swift
// Basic glass
Text("Status").padding().glassEffect()

// Shape variants — glassEffect(_:in:)
Text("Pill").padding().glassEffect(.regular, in: .capsule)

// Glass variants:
// .regular  — default translucent glass
// .clear    — high transparency, minimal lensing
// .identity — no visual effect (for conditional toggling)

// Tinted glass
Button("Action") { }
    .buttonStyle(.glassProminent)
    .tint(.blue)

// Chaining modifiers
Text("Interactive")
    .padding()
    .glassEffect(.regular.tint(.purple).interactive())
    // .interactive() adds touch feedback: scale, bounce, shimmer
```

### GlassEffectContainer

Groups glass elements for shared rendering, preventing visual artifacts from overlapping effects:

```swift
GlassEffectContainer {
    HStack {
        Button("A") { }.glassEffect()
        Button("B") { }.glassEffect()
        Button("C") { }.glassEffect()
    }
}
```

### Glass morph transitions

Animate a glass element from one position/shape to another using shared IDs via `glassEffectID`:

```swift
@Namespace var glass

// Source
icon.glassEffectID("player", in: glass)

// Destination — glass morphs between them on transition
expandedPlayer.glassEffectID("player", in: glass)
```

### Button styles

```swift
Button("Glass") { }.buttonStyle(.glass)               // Subtle glass
Button("Prominent") { }.buttonStyle(.glassProminent)  // Vibrant glass
// Use symbol-based buttons in toolbars for best Liquid Glass rendering:
.toolbar {
    ToolbarItem(placement: .confirmationAction) {
        Button("Done", systemImage: "checkmark") { }
    }
}
```

### TabView with Liquid Glass

```swift
TabView {
    Tab("Home", systemImage: "house") {
        NavigationStack { HomeView() }
    }
    Tab("Search", systemImage: "magnifyingglass", role: .search) {
        NavigationStack { SearchView() }
    }
    Tab("Profile", systemImage: "person") {
        NavigationStack { ProfileView() }
    }
}
.tabBarMinimizeBehavior(.onScrollDown) // Collapses on scroll
.tabViewBottomAccessory {              // Persistent mini-player
    NowPlayingView()
}
```

### Design guidelines for Liquid Glass

- **Do**: let system handle chrome glass; use `.glassEffect()` for custom floating controls
- **Do**: use SF Symbols in toolbars (they render best in glass)
- **Don't**: apply glass to content areas (cards, cells, text blocks)
- **Don't**: stack multiple glass layers (visual noise)
- **Don't**: use opaque backgrounds behind glass elements

---

## 2. Layout System

### Core containers

```swift
// Vertical
VStack(alignment: .leading, spacing: 12) { /* ... */ }

// Horizontal
HStack(alignment: .firstTextBaseline, spacing: 8) { /* ... */ }

// Overlapping
ZStack(alignment: .bottomTrailing) { /* ... */ }

// Grid (iOS 16+)
Grid(alignment: .leading, horizontalSpacing: 12, verticalSpacing: 8) {
    GridRow {
        Text("Label").gridColumnAlignment(.trailing)
        TextField("Value", text: $value)
    }
}

// Lazy grid
LazyVGrid(columns: [
    GridItem(.flexible(), spacing: 12),
    GridItem(.flexible(), spacing: 12)
], spacing: 12) {
    ForEach(items) { item in CardView(item: item) }
}
```

### Geometry and safe areas

```swift
// Edge-to-edge content
.ignoresSafeArea(.container, edges: .bottom)

// Read geometry (iOS 18+)
ScrollView {
    content
}
.onScrollGeometryChange(for: CGFloat.self) { proxy in
    proxy.contentOffset.y
} action: { _, newValue in
    scrollOffset = newValue
}
```

### MeshGradient (iOS 18)

```swift
MeshGradient(
    width: 3, height: 3,
    points: [
        [0, 0], [0.5, 0], [1, 0],
        [0, 0.5], [0.5, 0.5], [1, 0.5],
        [0, 1], [0.5, 1], [1, 1]
    ],
    colors: [
        .red, .orange, .yellow,
        .green, .blue, .purple,
        .pink, .mint, .cyan
    ]
)
```

---

## 3. Lazy Containers and Lists

### Feed pattern with LazyVStack (preferred for 100+ items)

```swift
ScrollView {
    LazyVStack(spacing: 12, pinnedViews: [.sectionHeaders]) {
        Section {
            ForEach(store.items) { item in
                ContentCard(item: item)
                    .onTapGesture { store.send(.itemTapped(item.id)) }
            }
        } header: {
            SectionHeader(title: "Latest")
                .padding(.horizontal)
        }
    }
    .padding(.horizontal)
}
.refreshable { await store.send(.refresh).finish() }
```

### Pagination (infinite scroll)

```swift
LazyVStack {
    ForEach(store.items) { item in
        ContentCard(item: item)
            .onAppear {
                if item.id == store.items.last?.id {
                    store.send(.loadNextPage)
                }
            }
    }

    if store.isLoadingMore {
        ProgressView().padding()
    }
}
```

### List (for settings/forms only)

```swift
List {
    Section("Account") {
        LabeledContent("Email", value: store.email)
        Toggle("Notifications", isOn: $store.notificationsEnabled.sending(\.notificationsToggled))
    }
    Section("Preferences") {
        Picker("Theme", selection: $store.theme.sending(\.themeChanged)) {
            ForEach(Theme.allCases, id: \.self) { Text($0.label) }
        }
    }
}
```

---

## 4. Pull-to-Refresh and Loading States

### Skeleton loading

```swift
struct SkeletonView: View {
    @State private var isAnimating = false

    var body: some View {
        RoundedRectangle(cornerRadius: 8)
            .fill(Color.gray.opacity(0.3))
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .fill(
                        LinearGradient(
                            colors: [.clear, .white.opacity(0.4), .clear],
                            startPoint: .leading, endPoint: .trailing
                        )
                    )
                    .offset(x: isAnimating ? 300 : -300)
            )
            .clipped()
            .onAppear {
                withAnimation(.linear(duration: 1.5).repeatForever(autoreverses: false)) {
                    isAnimating = true
                }
            }
    }
}
```

### State-driven content switching

```swift
struct FeedView: View {
    let store: StoreOf<FeedFeature>

    var body: some View {
        Group {
            switch store.viewState {
            case .loading:
                SkeletonFeedView()
            case .empty:
                EmptyStateView(
                    icon: "tray",
                    title: "No items yet",
                    message: "Check back later for new content"
                )
            case .error(let message):
                ErrorView(message: message) {
                    store.send(.retryTapped)
                }
            case .loaded:
                FeedContentView(store: store)
            }
        }
        .task { store.send(.onAppear) }
    }
}
```

---

## 5. Search

### iOS 26 search (bottom-aligned on iPhone)

```swift
NavigationStack {
    FeedContentView(store: store)
        .searchable(text: $store.searchQuery.sending(\.searchQueryChanged),
                     prompt: "Search items...")
        .searchToolbarBehavior(.minimize)  // iOS 26: bottom search bar
        .searchSuggestions {
            ForEach(store.suggestions, id: \.self) { suggestion in
                Text(suggestion).searchCompletion(suggestion)
            }
        }
}
```

### Debounced search in TCA

Handle in the reducer with `Effect.cancel` and delay:

```swift
case let .searchQueryChanged(query):
    state.searchQuery = query
    guard !query.isEmpty else {
        state.searchResults = []
        return .cancel(id: CancelID.search)
    }
    return .run { send in
        try await Task.sleep(for: .milliseconds(300))
        let results = try await searchClient.search(query)
        await send(.searchResultsLoaded(results))
    }
    .cancellable(id: CancelID.search, cancelInFlight: true)
```

---

## 6. Sheets, Popovers, Inspectors

### Sheet with TCA tree-based navigation

```swift
// In view:
.sheet(item: $store.scope(state: \.destination?.detail, action: \.destination.detail)) { store in
    DetailView(store: store)
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
}

// Confirmation dialog:
.confirmationDialog($store.scope(state: \.destination?.confirmDelete, action: \.destination.confirmDelete))
```

### presentationSizing (iOS 18)

```swift
.sheet(isPresented: $showSettings) {
    SettingsView()
        .presentationSizing(.form)  // Compact, form-fitting size
        // .page — full page
        // .fitted — content-hugging
}
```

### Inspector (iPad sidebar)

```swift
.inspector(isPresented: $store.showInspector.sending(\.inspectorToggled)) {
    InspectorView(item: store.selectedItem)
        .inspectorColumnWidth(min: 200, ideal: 300, max: 400)
}
```

---

## 7. Animations and Transitions

### Shared element transitions (iOS 18)

```swift
@Namespace var heroNamespace

// Source
AsyncImage(url: item.imageURL)
    .matchedTransitionSource(id: item.id, in: heroNamespace)

// Destination (pushed via NavigationStack)
DetailImage(url: item.imageURL)
    .navigationTransition(.zoom(sourceID: item.id, in: heroNamespace))
```

### Phase animations

```swift
Text("Hello")
    .phaseAnimator([false, true]) { content, phase in
        content
            .scaleEffect(phase ? 1.1 : 1.0)
            .opacity(phase ? 1.0 : 0.8)
    }
```

### Spring animations (preferred default)

```swift
withAnimation(.spring(duration: 0.3, bounce: 0.2)) {
    store.send(.toggleExpanded)
}

// Or declarative:
.animation(.spring(duration: 0.3, bounce: 0.2), value: store.isExpanded)
```

### Custom transitions

```swift
extension AnyTransition {
    static var slideUp: AnyTransition {
        .asymmetric(
            insertion: .move(edge: .bottom).combined(with: .opacity),
            removal: .move(edge: .top).combined(with: .opacity)
        )
    }
}
```

---

## 8. Image Loading

### Kingfisher (recommended)

```swift
import Kingfisher

KFImage(URL(string: item.imageURL))
    .placeholder { SkeletonView().frame(height: 200) }
    .retry(maxCount: 3, retryInterval: .seconds(2))
    .fade(duration: 0.25)
    .resizable()
    .aspectRatio(contentMode: .fill)
    .frame(height: 200)
    .clipped()

// Animated GIF
KFAnimatedImage(URL(string: item.gifURL))
    .scaledToFit()

// Prefetching
let prefetcher = ImagePrefetcher(urls: upcomingURLs)
prefetcher.start()
```

### Nuke (alternative)

```swift
import NukeUI

LazyImage(url: URL(string: item.imageURL)) { state in
    if let image = state.image {
        image.resizable().aspectRatio(contentMode: .fill)
    } else if state.error != nil {
        Image(systemName: "photo").foregroundStyle(.secondary)
    } else {
        SkeletonView()
    }
}
.processors([.resize(width: 300)])
.priority(.high)
```

### When to use which

- **Kingfisher**: default for most apps. Simpler API, built-in GIF, 3x community size
- **Nuke**: choose for progressive JPEG, resumable downloads, max main-thread perf
- **AsyncImage**: never — no caching, no prefetching, no processing

---

## 9. Adaptive Layouts

### ViewThatFits (iOS 16+)

```swift
ViewThatFits(in: .horizontal) {
    HStack { icon; title; subtitle; action }  // Wide
    VStack { icon; title; action }             // Narrow
}
```

### Horizontal size class

```swift
@Environment(\.horizontalSizeClass) var sizeClass

var body: some View {
    if sizeClass == .compact {
        TabView { /* iPhone layout */ }
    } else {
        NavigationSplitView {
            Sidebar()
        } detail: {
            DetailView()
        }
    }
}
```

### Dynamic Type support

```swift
Text(item.title)
    .font(.headline)       // Always use semantic fonts
    .lineLimit(nil)         // Allow expansion for accessibility
    .minimumScaleFactor(0.8)

// Fixed sizes only for decorative/non-essential text:
Text("★").font(.system(size: 12))
```

---

## 10. Observation Model

### @Observable (iOS 17+)

Per-property tracking — only views reading a changed property re-render:

```swift
@Observable
class UserSession {
    var isLoggedIn = false
    var userName: String?
    var avatarURL: URL?
}

// In view:
@State var session = UserSession()
// Or via Environment:
@Environment(UserSession.self) var session
```

### @ObservableState (TCA)

TCA's equivalent for store state. Applied via `@Reducer` macro:

```swift
@ObservableState
struct State: Equatable {
    var count = 0
}
// Views read store.count directly — no WithViewStore needed
```

### Migration from ObservableObject

| Old | New |
|-----|-----|
| `class Foo: ObservableObject` | `@Observable class Foo` |
| `@Published var x` | `var x` (tracking is automatic) |
| `@StateObject var foo` | `@State var foo` |
| `@ObservedObject var foo` | `let foo` or `@Bindable var foo` |
| `@EnvironmentObject var foo` | `@Environment(Foo.self) var foo` |

---

## 11. Swift 6 Concurrency in SwiftUI

Swift 6.3.3 (Xcode 26.6) ships full strict concurrency. The "Approachable Concurrency" build settings introduced in Swift 6.2 (SE-0461, SE-0470, `@concurrent`) are the recommended on-ramp and are stable in 6.3.

### View protocol is @MainActor (iOS 18+)

All SwiftUI `View` properties and methods run on the main actor. This means:

```swift
struct MyView: View {
    // All of this is @MainActor-isolated:
    @State var items: [Item] = []

    var body: some View {
        Button("Load") {
            // This closure is @MainActor too
            Task {
                // To run on background, use @concurrent (Swift 6.2+):
                let data = await fetchData()
                items = data
            }
        }
    }
}
```

### SE-0461: nonisolated async defaults (Swift 6.2+)

Nonisolated async functions now run on the caller's actor by default. To opt into background execution:

```swift
@concurrent
func processImage(_ data: Data) async -> UIImage {
    // Runs on cooperative thread pool, not main actor
}
```

### SE-0470: Isolated conformances (Swift 6.2+)

`@MainActor` types can now conform to protocols in isolated context without compiler errors — a major improvement for TCA + SwiftUI patterns.

### Sendable model types

When passing your own value types across actor boundaries (e.g. from a `@concurrent` fetch back to a `@MainActor` view), conform them to `Sendable`. For plain immutable structs this is automatic once all stored properties are themselves `Sendable`:

```swift
struct FeedItem: Identifiable, Sendable {
    let id: UUID
    let title: String
    let imageURL: URL
}
```

Prefer `let` stored properties and value semantics so the compiler can synthesize `Sendable` for free; reach for `@unchecked Sendable` only when you are manually enforcing thread-safety (e.g. a lock-guarded reference type), and document why.

### Practical migration path

1. Stay on Swift 5 language mode
2. Set Strict Concurrency Checking → "Complete" in Build Settings
3. Fix warnings module by module (leaf modules first)
4. Enable the Swift 6.2+ "Approachable Concurrency" build settings for progressive disclosure
5. Flip to Swift 6 language mode when clean

---

## 12. iOS Version Compatibility

### Minimum deployment target strategy

Target **iOS 18** as minimum to access `@Observable`, improved `NavigationStack`, and modern SwiftUI APIs. Build against the iOS 26 SDK (26.5) with Xcode 26.6, and use `#available` checks for iOS 26 features (Liquid Glass, new controls).

### #available checks for iOS 26 features

```swift
struct AdaptiveHeader: View {
    let title: String

    var body: some View {
        if #available(iOS 26, *) {
            // Liquid Glass toolbar — iOS 26+
            Text(title)
                .glassEffect(.regular.interactive())
        } else {
            // Standard material — iOS 18
            Text(title)
                .background(.ultraThinMaterial)
        }
    }
}
```

### API availability reference

| Feature | Minimum iOS | Notes |
|---------|-------------|-------|
| `@Observable` | 17.0 | Backport via Perception library for iOS 16 |
| `NavigationStack` | 16.0 | Stable from iOS 17+ |
| `containerRelativeFrame` | 17.0 | — |
| `scrollTargetBehavior` | 17.0 | — |
| `.inspector` modifier | 17.0 | — |
| `SubscriptionStoreView` | 17.0 | StoreKit 2 |
| `.sensoryFeedback` | 17.0 | Replaces UIFeedbackGenerator in SwiftUI |
| `MeshGradient` | 18.0 | — |
| `onScrollGeometryChange` | 18.0 | — |
| Liquid Glass (`glassEffect`) | 26.0 | Automatic for TabView/NavigationBar/Toolbar |
| `GlassEffectContainer` / `glassEffectID` | 26.0 | Custom glass shapes and morph transitions |

### Dark mode + Liquid Glass coexistence

Liquid Glass adapts automatically to light/dark mode — the translucent material refracts content behind it. No manual color adjustments needed for glass elements.

For non-glass content, continue using semantic colors:

```swift
struct ThemedCard: View {
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        VStack {
            // Content uses semantic colors — adapts to light/dark
            Text("Title")
                .foregroundStyle(.primary)
            Text("Subtitle")
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(.background) // Semantic — not hardcoded
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
```

**Rules**:
- Never hardcode colors for glass-adjacent UI — use `.primary`, `.secondary`, `.background`
- Test glass effects in both light and dark mode with varied wallpapers
- On iOS < 26, glass modifiers are no-ops — no need for `#available` on `.glassEffect` itself if compiled with Xcode 26 and deployment target is iOS 18+
- Use `.preferredColorScheme()` only for previews, never force it in production
