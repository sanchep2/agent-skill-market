# Testing — Swift Testing, TCA TestStore, Snapshots

> Reference for the `ios-native` skill. For TCA architecture patterns, see `ARCHITECTURE.md`.

## Table of Contents

1. [Testing Pyramid](#1-testing-pyramid)
2. [Swift Testing Framework](#2-swift-testing-framework)
3. [TCA TestStore](#3-tca-teststore)
4. [Dependency Mocking](#4-dependency-mocking)
5. [Snapshot Testing](#5-snapshot-testing)
6. [XCUITest for UI Automation](#6-xcuitest-for-ui-automation)
7. [Testing the Networking & Persistence Layers](#7-testing-the-networking--persistence-layers)
8. [CI Configuration](#8-ci-configuration)
9. [Migration: XCTest → Swift Testing](#9-migration-xctest-to-swift-testing)

---

## 1. Testing Pyramid

| Layer | Ratio | Framework | What to Test |
|---|---|---|---|
| **Unit** | 70% | Swift Testing + TCA TestStore | Reducers, dependency clients, business logic, `Codable` decoding |
| **Integration** | 15% | Swift Testing | Feature reducers with real (fake) dependencies, navigation flows, networking + persistence layers |
| **Snapshot** | 10% | swift-snapshot-testing 1.19.2 | Key screens in all states (loading, empty, error, success), Dark Mode, Dynamic Type |
| **UI / E2E** | 5% | XCUITest | Critical user journeys (login, purchase, onboarding) |

Toolchain baseline: **Swift 6.3.3 / Xcode 26.6 / iOS 26 SDK**. Swift Testing ships with Xcode 26 — no package dependency required.

---

## 2. Swift Testing Framework

Ships stable with Xcode 16+ (September 2024) and is the default in Xcode 26. Recommended for all new tests.

### Basic patterns

```swift
import Testing

@Suite("FeedItem Decoding")
struct FeedItemDecodingTests {

    @Test("Decodes item from JSON")
    func decodeItem() throws {
        let json = Data("""
        { "id": "1", "title": "Test", "isFavorite": true }
        """.utf8)

        let item = try JSONDecoder().decode(FeedItem.self, from: json)

        #expect(item.id == "1")
        #expect(item.title == "Test")
        #expect(item.isFavorite == true)
    }

    @Test("Handles nil optional fields gracefully")
    func nilFields() throws {
        let json = Data("""
        { "id": "2", "title": "Test", "imageURL": null }
        """.utf8)

        let item = try JSONDecoder().decode(FeedItem.self, from: json)

        #expect(item.imageURL == nil)
    }

    @Test("Requires non-empty ID")
    func requiresID() throws {
        let item = try #require(FeedItem(id: "abc", title: "Test"))
        // #require throws if nil — fails test immediately
        #expect(item.id == "abc")
    }
}
```

### Parameterized tests

```swift
@Test("Filter maps correctly", arguments: [
    (FeedFeature.Filter.all, "all"),
    (FeedFeature.Filter.favorites, "favorites"),
    (FeedFeature.Filter.recent, "recent")
])
func filterMapping(filter: FeedFeature.Filter, expected: String) {
    #expect(filter.rawValue == expected)
}

// With zip for paired arguments:
@Test("Pagination calculates offset", arguments: zip(
    [1, 2, 3, 10],      // pages
    [0, 20, 40, 180]     // expected offsets
))
func paginationOffset(page: Int, expectedOffset: Int) {
    #expect((page - 1) * 20 == expectedOffset)
}
```

### Tags and traits

```swift
extension Tag {
    @Tag static var networking: Self
    @Tag static var offline: Self
    @Tag static var slow: Self
}

@Test("Syncs data from network", .tags(.networking, .slow), .timeLimit(.minutes(1)))
func syncTest() async throws {
    // ...
}

// Conditional:
@Test("Only on iOS 26", .enabled(if: ProcessInfo.processInfo.operatingSystemVersion.majorVersion >= 26))
func liquidGlassTest() { }

// Disabled with bug tracking:
@Test("Placeholder for a known-broken case", .disabled("Awaiting fix"), .bug("https://github.com/..."))
func knownBrokenTest() { }
```

### Async tests

```swift
@Test("Fetches items from API")
func fetchItems() async throws {
    let client = FeedClient.testValue
    // Override specific methods for this test
    let items = try await withDependencies {
        $0.feedClient.fetch = { _, _ in FeedItem.mocks }
    } operation: {
        @Dependency(\.feedClient) var feedClient
        return try await feedClient.fetch(1, .all)
    }
    #expect(items.count == 3)
}
```

---

## 3. TCA TestStore

TestStore is **exhaustive by default** — you must assert on every state change and every received effect action.

### Basic reducer test

```swift
import ComposableArchitecture
import Testing

@Suite("FeedFeature")
struct FeedFeatureTests {

    @Test("onAppear sets loading and fetches items")
    func onAppear() async {
        let mockItems = [FeedItem(id: "1", title: "Test")]

        let store = TestStore(initialState: FeedFeature.State()) {
            FeedFeature()
        } withDependencies: {
            $0.feedClient.fetch = { _, _ in mockItems }
        }

        await store.send(.onAppear) {
            $0.isLoading = true
        }

        await store.receive(\.itemsLoaded.success) {
            $0.items = IdentifiedArray(uniqueElements: mockItems)
            $0.isLoading = false
        }
    }

    @Test("Filter change triggers refresh")
    func filterChange() async {
        let store = TestStore(initialState: FeedFeature.State(
            items: IdentifiedArray(uniqueElements: FeedItem.mocks)
        )) {
            FeedFeature()
        } withDependencies: {
            $0.feedClient.fetch = { _, _ in [] }
        }

        await store.send(.filterChanged(.favorites)) {
            $0.filter = .favorites
            $0.page = 1
            $0.items = []
        }

        // filterChanged triggers .refresh internally
        await store.receive(\.refresh)

        await store.receive(\.itemsLoaded.success) {
            $0.hasMorePages = false
            $0.isLoading = false
        }
    }

    @Test("Error state on network failure")
    func networkError() async {
        let store = TestStore(initialState: FeedFeature.State()) {
            FeedFeature()
        } withDependencies: {
            $0.feedClient.fetch = { _, _ in
                throw NSError(domain: "Network", code: -1, userInfo: [
                    NSLocalizedDescriptionKey: "No internet"
                ])
            }
        }

        await store.send(.onAppear) {
            $0.isLoading = true
        }

        await store.receive(\.itemsLoaded.failure) {
            $0.isLoading = false
            $0.error = "No internet"
        }
    }
}
```

### Testing navigation

```swift
@Test("Item tap opens detail")
func itemTapNavigation() async {
    let item = FeedItem(id: "1", title: "Test")
    let store = TestStore(initialState: FeedFeature.State(
        items: IdentifiedArray(uniqueElements: [item])
    )) {
        FeedFeature()
    }

    await store.send(.itemTapped("1")) {
        $0.destination = .detail(DetailFeature.State(item: item))
    }
}

@Test("Stack navigation push and pop")
func stackNavigation() async {
    let item = FeedItem(id: "1", title: "Test")
    let store = TestStore(initialState: FeedCoordinator.State(
        feed: FeedFeature.State(items: IdentifiedArray(uniqueElements: [item]))
    )) {
        FeedCoordinator()
    }

    await store.send(.feed(.itemTapped("1"))) {
        $0.path[id: 0] = .detail(DetailFeature.State(item: item))
    }
}
```

### Non-exhaustive testing

For integration tests where you only care about specific state changes:

```swift
@Test("Integration: full load flow")
func integrationTest() async {
    let store = TestStore(initialState: FeedFeature.State()) {
        FeedFeature()
    } withDependencies: {
        $0.feedClient.fetch = { _, _ in FeedItem.mocks }
    }

    store.exhaustivity = .off  // Don't require asserting every change

    await store.send(.onAppear)
    await store.receive(\.itemsLoaded)

    // Just check final state
    #expect(store.state.items.count == 3)
    #expect(store.state.isLoading == false)
}
```

---

## 4. Dependency Mocking

### Override per-test

```swift
let store = TestStore(initialState: MyFeature.State()) {
    MyFeature()
} withDependencies: {
    $0.feedClient.fetch = { _, _ in mockItems }
    $0.feedClient.toggleFavorite = { id in id }
    $0.hapticClient.impact = { _ in }  // Silence haptics
    $0.date.now = Date(timeIntervalSince1970: 1700000000) // Fixed date
    $0.uuid = .incrementing  // Predictable UUIDs
}
```

### Unimplemented catches accidental calls

```swift
// testValue uses unimplemented() — if any method is called
// without being overridden, the test fails with a descriptive error:
// "FeedClient.fetch is unimplemented"
```

### Preview dependencies

```swift
#Preview {
    FeedView(store: Store(initialState: FeedFeature.State(
        items: IdentifiedArray(uniqueElements: FeedItem.mocks)
    )) {
        FeedFeature()
    } withDependencies: {
        $0.feedClient = .previewValue
    })
}
```

---

## 5. Snapshot Testing

Using **swift-snapshot-testing 1.19.2** by Point-Free.

### Setup

```swift
// Package.swift dependency:
.package(url: "https://github.com/pointfreeco/swift-snapshot-testing", from: "1.19.2")

// Test target:
.testTarget(name: "MyTests", dependencies: [
    "MyApp",
    .product(name: "SnapshotTesting", package: "swift-snapshot-testing"),
    .product(name: "InlineSnapshotTesting", package: "swift-snapshot-testing"),
])
```

### Image snapshots with Swift Testing

```swift
import SnapshotTesting
import Testing

@Suite(.snapshots(record: .missing)) // Only record if reference missing
@MainActor
struct FeedViewSnapshotTests {

    @Test("Feed loaded state")
    func feedLoaded() {
        let view = FeedView(store: Store(initialState: FeedFeature.State(
            items: IdentifiedArray(uniqueElements: FeedItem.mocks)
        )) { FeedFeature() })

        let vc = UIHostingController(rootView: view)
        vc.view.frame = UIScreen.main.bounds

        assertSnapshot(
            of: vc,
            as: .image(on: .iPhone17Pro, precision: 0.99, perceptualPrecision: 0.98)
        )
    }

    @Test("Feed empty state")
    func feedEmpty() {
        let view = FeedView(store: Store(initialState: FeedFeature.State()) {
            FeedFeature()
        })
        let vc = UIHostingController(rootView: view)
        assertSnapshot(of: vc, as: .image(on: .iPhone17Pro))
    }

    @Test("Feed error state")
    func feedError() {
        let view = FeedView(store: Store(initialState: FeedFeature.State(
            error: "Network error. Please try again."
        )) { FeedFeature() })
        let vc = UIHostingController(rootView: view)
        assertSnapshot(of: vc, as: .image(on: .iPhone17Pro))
    }

    @Test("Feed loading state - Dark Mode")
    func feedLoadingDark() {
        let view = FeedView(store: Store(initialState: FeedFeature.State(
            isLoading: true
        )) { FeedFeature() })
        let vc = UIHostingController(rootView: view)
        vc.overrideUserInterfaceStyle = .dark
        assertSnapshot(of: vc, as: .image(on: .iPhone17Pro))
    }
}
```

### Record modes

```swift
// On individual suite:
@Suite(.snapshots(record: .all))       // Re-record everything
@Suite(.snapshots(record: .missing))   // Only record if no reference exists
@Suite(.snapshots(record: .failed))    // Re-record only failing snapshots
@Suite(.snapshots(record: .never))     // Fail if reference missing (CI mode)

// Or per-assertion:
assertSnapshot(of: vc, as: .image, record: true)
```

### Inline snapshots (text-based)

```swift
import InlineSnapshotTesting

@Test("User JSON encoding")
func userJSON() {
    let user = User(id: "1", name: "Ada", email: "ada@example.com")
    assertInlineSnapshot(of: user, as: .json) {
        """
        {
          "email" : "ada@example.com",
          "id" : "1",
          "name" : "Ada"
        }
        """
    }
}
```

### Handling CI rendering differences

```swift
// Use perceptualPrecision to handle Apple Silicon vs Intel differences:
assertSnapshot(
    of: vc,
    as: .image(
        precision: 0.99,            // Exact pixel match within 1%
        perceptualPrecision: 0.98   // Sub-2% Delta E (imperceptible)
    )
)
```

---

## 6. XCUITest for UI Automation

Swift Testing **cannot** do UI automation. XCUITest remains required.

### Critical journey test

```swift
import XCTest

final class FeedUITests: XCTestCase {

    func testFeedLoadAndNavigateToDetail() {
        let app = XCUIApplication()
        app.launch()

        // Wait for feed to load
        let firstItem = app.staticTexts["ContentCard_Title_0"]
        XCTAssertTrue(firstItem.waitForExistence(timeout: 5))

        // Tap to navigate
        firstItem.tap()

        // Verify detail screen
        let detailTitle = app.navigationBars.staticTexts["Detail"]
        XCTAssertTrue(detailTitle.waitForExistence(timeout: 2))

        // Go back
        app.navigationBars.buttons.element(boundBy: 0).tap()
        XCTAssertTrue(firstItem.waitForExistence(timeout: 2))
    }

    func testPullToRefresh() {
        let app = XCUIApplication()
        app.launch()

        let feedList = app.scrollViews.firstMatch
        feedList.swipeDown()

        // Verify refresh indicator appeared and data reloaded
        let firstItem = app.staticTexts["ContentCard_Title_0"]
        XCTAssertTrue(firstItem.waitForExistence(timeout: 5))
    }
}
```

### Accessibility identifiers for testability

```swift
// In SwiftUI views:
ContentCard(item: item)
    .accessibilityIdentifier("ContentCard_\(item.id)")

Text(item.title)
    .accessibilityIdentifier("ContentCard_Title_\(index)")
```

---

## 7. Testing the Networking & Persistence Layers

The two layers most worth isolating in tests are the ones that touch the outside world: the
`URLSession`-backed API client and the on-device store. Neither should ever hit a real server or a
real database in unit tests. The recipes below keep both fully hermetic.

### 7.1 Testing the API client with a mocked `URLProtocol`

`URLSession` lets you install a custom `URLProtocol` subclass into its configuration. That protocol
intercepts every request the session makes and lets you return a canned `HTTPURLResponse` + body,
so you can exercise real decoding paths, status-code handling, and error mapping without a network.

```swift
import Foundation

/// A URLProtocol that returns a stubbed response for every request.
/// Set `MockURLProtocol.handler` per-test to control what comes back.
final class MockURLProtocol: URLProtocol {

    /// Given the outgoing request, return the status code, body and optional headers.
    nonisolated(unsafe) static var handler: (@Sendable (URLRequest) throws -> (Int, Data, [String: String]))?

    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }

    override func startLoading() {
        guard let handler = MockURLProtocol.handler else {
            client?.urlProtocol(self, didFailWithError: URLError(.badServerResponse))
            return
        }
        do {
            let (status, body, headers) = try handler(request)
            let response = HTTPURLResponse(
                url: request.url!,
                statusCode: status,
                httpVersion: "HTTP/1.1",
                headerFields: headers
            )!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: body)
            client?.urlProtocolDidFinishLoading(self)
        } catch {
            client?.urlProtocol(self, didFailWithError: error)
        }
    }

    override func stopLoading() {}
}

/// Builds a URLSession wired to the mock protocol. Use this in tests.
func makeMockedSession() -> URLSession {
    let config = URLSessionConfiguration.ephemeral
    config.protocolClasses = [MockURLProtocol.self]
    return URLSession(configuration: config)
}
```

The API client under test takes a `URLSession` (inject it — never reach for `.shared` inside the
type). A minimal client:

```swift
struct APIClient {
    var session: URLSession = .shared
    var baseURL = URL(string: "https://api.example.com")!

    func fetchFeed(page: Int) async throws -> [FeedItem] {
        var comps = URLComponents(url: baseURL.appending(path: "feed"), resolvingAgainstBaseURL: false)!
        comps.queryItems = [URLQueryItem(name: "page", value: String(page))]

        let (data, response) = try await session.data(from: comps.url!)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw APIError.badStatus((response as? HTTPURLResponse)?.statusCode ?? -1)
        }
        return try JSONDecoder.api.decode([FeedItem].self, from: data)
    }
}
```

Now the tests — success, decoding, non-2xx, and a malformed body:

```swift
import Testing
import Foundation

@Suite("APIClient")
struct APIClientTests {

    @Test("Decodes a successful feed response")
    func decodesFeed() async throws {
        MockURLProtocol.handler = { _ in
            let json = Data("""
            [ { "id": "1", "title": "First" },
              { "id": "2", "title": "Second" } ]
            """.utf8)
            return (200, json, ["Content-Type": "application/json"])
        }

        let client = APIClient(session: makeMockedSession())
        let items = try await client.fetchFeed(page: 1)

        #expect(items.count == 2)
        #expect(items.first?.title == "First")
    }

    @Test("Sends the expected query parameter")
    func sendsPageParam() async throws {
        MockURLProtocol.handler = { request in
            #expect(request.url?.query?.contains("page=3") == true)
            return (200, Data("[]".utf8), [:])
        }

        let client = APIClient(session: makeMockedSession())
        _ = try await client.fetchFeed(page: 3)
    }

    @Test("Maps a non-2xx status to APIError.badStatus")
    func mapsServerError() async {
        MockURLProtocol.handler = { _ in (503, Data(), [:]) }

        let client = APIClient(session: makeMockedSession())
        await #expect(throws: APIError.badStatus(503)) {
            try await client.fetchFeed(page: 1)
        }
    }

    @Test("Throws on a malformed body")
    func throwsOnMalformedBody() async {
        MockURLProtocol.handler = { _ in (200, Data("not json".utf8), [:]) }

        let client = APIClient(session: makeMockedSession())
        await #expect(throws: DecodingError.self) {
            try await client.fetchFeed(page: 1)
        }
    }
}
```

Notes:

- Prefer `URLSessionConfiguration.ephemeral` so no cache/cookies leak between tests.
- Reset `MockURLProtocol.handler` in each test (a fresh closure per `@Test` keeps suites parallel-safe;
  Swift Testing runs tests in parallel by default).
- To drive the same paths through a TCA dependency client, install the mocked session inside the
  `liveValue` factory and assert the decoded output — the boundary you care about is
  request → response → decoded domain model.

### 7.2 Testing the SwiftData layer with an in-memory `ModelContainer`

For persistence, spin up a `ModelContainer` configured with `isStoredInMemoryOnly: true`. Nothing
touches disk, each test gets a clean store, and inserts/fetches/deletes run against the real
SwiftData stack.

```swift
import Testing
import SwiftData

@Model
final class CachedFeedItem {
    @Attribute(.unique) var id: String
    var title: String
    var isFavorite: Bool
    var cachedAt: Date

    init(id: String, title: String, isFavorite: Bool = false, cachedAt: Date = .now) {
        self.id = id
        self.title = title
        self.isFavorite = isFavorite
        self.cachedAt = cachedAt
    }
}

/// Builds a throwaway in-memory container for the given models.
@MainActor
func makeInMemoryContainer() throws -> ModelContainer {
    let config = ModelConfiguration(isStoredInMemoryOnly: true)
    return try ModelContainer(for: CachedFeedItem.self, configurations: config)
}
```

The store under test operates on a `ModelContext`:

```swift
@MainActor
struct FeedCache {
    let context: ModelContext

    func upsert(_ items: [FeedItem]) throws {
        for item in items {
            context.insert(CachedFeedItem(id: item.id, title: item.title, isFavorite: item.isFavorite))
        }
        try context.save()
    }

    func all() throws -> [CachedFeedItem] {
        try context.fetch(FetchDescriptor<CachedFeedItem>(
            sortBy: [SortDescriptor(\.cachedAt, order: .forward)]
        ))
    }

    func favorites() throws -> [CachedFeedItem] {
        let predicate = #Predicate<CachedFeedItem> { $0.isFavorite }
        return try context.fetch(FetchDescriptor(predicate: predicate))
    }
}
```

Tests — each builds its own container, so there is no shared state to reset:

```swift
@Suite("FeedCache", .serialized)   // .serialized because @MainActor work shares the main actor
@MainActor
struct FeedCacheTests {

    @Test("Inserts and reads back items")
    func insertAndFetch() throws {
        let container = try makeInMemoryContainer()
        let cache = FeedCache(context: container.mainContext)

        try cache.upsert([
            FeedItem(id: "1", title: "One"),
            FeedItem(id: "2", title: "Two")
        ])

        let stored = try cache.all()
        #expect(stored.count == 2)
        #expect(stored.map(\.id).sorted() == ["1", "2"])
    }

    @Test("Filters favorites with a predicate")
    func fetchFavorites() throws {
        let container = try makeInMemoryContainer()
        let cache = FeedCache(context: container.mainContext)

        try cache.upsert([
            FeedItem(id: "1", title: "One", isFavorite: true),
            FeedItem(id: "2", title: "Two", isFavorite: false)
        ])

        let favorites = try cache.favorites()
        #expect(favorites.count == 1)
        #expect(favorites.first?.id == "1")
    }

    @Test("Deletes an item")
    func deleteItem() throws {
        let container = try makeInMemoryContainer()
        let context = container.mainContext
        let cache = FeedCache(context: context)

        try cache.upsert([FeedItem(id: "1", title: "One")])
        let toDelete = try #require(try cache.all().first)

        context.delete(toDelete)
        try context.save()

        #expect(try cache.all().isEmpty)
    }
}
```

Notes:

- `isStoredInMemoryOnly: true` gives isolation for free — a new container per test beats a shared
  one you have to wipe.
- Keep SwiftData work on the `@MainActor` (or a `ModelActor`) to match how the app uses the context.
- To test a TCA dependency client backed by SwiftData, inject the in-memory context into the
  client's `liveValue` and assert on the persisted result, exactly as with the networking client.

---

## 8. CI Configuration

### GitHub Actions (runs on macOS)

```yaml
name: iOS Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: macos-26  # Xcode 26 image
    steps:
      - uses: actions/checkout@v4

      - name: Select Xcode
        run: sudo xcode-select -s /Applications/Xcode_26.6.app

      - name: Build and Test
        run: |
          xcodebuild test \
            -workspace MyApp.xcworkspace \
            -scheme MyApp \
            -destination 'platform=iOS Simulator,name=iPhone 17 Pro,OS=26.5' \
            -resultBundlePath TestResults.xcresult \
            -enableCodeCoverage YES

      - name: Upload Results
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: test-results
          path: TestResults.xcresult
```

### Snapshot testing on CI

- Record reference images **on the same hardware** as CI (or use `perceptualPrecision`)
- Set record mode to `.never` on CI to fail on missing references
- Lock locale and language in Xcode test plan
- Use dedicated snapshot test scheme if rendering takes too long

```yaml
# Environment variable to control recording:
env:
  SNAPSHOT_TESTING_RECORD: "never"
```

---

## 9. Migration: XCTest → Swift Testing

### Incremental approach — both coexist

Swift Testing and XCTest live in the same target and even the same file. Migrate file by file:

### Mapping table

| XCTest | Swift Testing |
|---|---|
| `import XCTest` | `import Testing` |
| `class FooTests: XCTestCase` | `@Suite struct FooTests` |
| `func testFoo()` | `@Test func foo()` |
| `XCTAssertEqual(a, b)` | `#expect(a == b)` |
| `XCTAssertTrue(x)` | `#expect(x)` |
| `XCTAssertNil(x)` | `#expect(x == nil)` |
| `XCTAssertNotNil(x)` | `let val = try #require(x)` |
| `XCTAssertThrowsError` | `#expect(throws: MyError.self) { try foo() }` |
| `XCTFail("msg")` | `Issue.record("msg")` |
| `setUp()` | `init()` |
| `tearDown()` | `deinit` (class suites only) |
| `setUpWithError()` | `init() throws` |
| `measure { }` | ❌ Not available (use XCTest for perf tests) |

### What stays in XCTest

- **UI automation** (XCUITest) — Swift Testing has no UI testing capability
- **Performance testing** (`measure {}`, `XCTMetric`)
- **Objective-C tests**
- **XCTAttachment** (no equivalent in Swift Testing)

### TCA TestStore works with both

```swift
// Swift Testing (recommended for new tests):
import Testing
import ComposableArchitecture

@Test func basics() async {
    let store = TestStore(initialState: MyFeature.State()) {
        MyFeature()
    }
    await store.send(.action) { $0.value = 1 }
}

// XCTest (existing tests, still works fine):
import XCTest
import ComposableArchitecture

class MyFeatureTests: XCTestCase {
    func testBasics() async {
        let store = TestStore(initialState: MyFeature.State()) {
            MyFeature()
        }
        await store.send(.action) { $0.value = 1 }
    }
}
```

### Recommended strategy

1. New test files → Swift Testing from the start
2. Existing unit tests → migrate file by file when touching them
3. UI tests → keep in XCTest
4. Performance tests → keep in XCTest
5. TCA TestStore tests → migrate to Swift Testing (both work, Swift Testing is cleaner)
