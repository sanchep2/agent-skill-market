# Networking (URLSession, async/await, Codable)

This reference describes the native networking layer for a standalone iOS app built with
**Swift 6.3.3**, **Xcode 26.6**, and the **iOS 26 SDK**. It uses only Apple's own
`Foundation.URLSession` — no third-party dependency is required. All code assumes
**strict concurrency** is enabled (`SWIFT_STRICT_CONCURRENCY = complete`), so every type
that crosses an actor boundary is `Sendable`.

The goals of the layer are:

- A thin, testable client around `URLSession` async/await.
- A generic, reusable request-builder (`Endpoint`) + client (`APIClient`).
- A typed error model that maps transport, decoding, and HTTP-status failures.
- Bearer-token authentication with Keychain storage and transparent refresh-on-401.
- Interceptors for header injection and retry-with-backoff.
- First-class structured concurrency (`async let`, `TaskGroup`, cooperative cancellation).

> Rule of thumb: for the vast majority of apps, native `URLSession` is enough. Reach for a
> third-party library (see the last section) only when you have a concrete need it solves.

---

## 1. `URLSession` async/await basics

The async API returns a tuple `(Data, URLResponse)`. You are responsible for validating the
HTTP status code — `URLSession` only throws for transport-level failures (no connection,
timeout, cancellation), not for `4xx`/`5xx`.

```swift
import Foundation

// A single shared, configured session. `URLSession` is Sendable.
let session: URLSession = {
    let config = URLSessionConfiguration.default
    config.timeoutIntervalForRequest = 30
    config.timeoutIntervalForResource = 60
    config.waitsForConnectivity = true
    config.httpAdditionalHeaders = ["Accept": "application/json"]
    return URLSession(configuration: config)
}()

func fetchRaw() async throws {
    var request = URLRequest(url: URL(string: "https://api.example.com/v1/profile")!)
    request.httpMethod = "GET"
    request.setValue("application/json", forHTTPHeaderField: "Accept")

    let (data, response) = try await session.data(for: request)

    guard let http = response as? HTTPURLResponse else {
        throw URLError(.badServerResponse)
    }
    guard (200..<300).contains(http.statusCode) else {
        throw URLError(.badServerResponse)
    }

    print("Received \(data.count) bytes")
}
```

### HTTP methods as a small enum

```swift
enum HTTPMethod: String, Sendable {
    case get = "GET"
    case post = "POST"
    case put = "PUT"
    case patch = "PATCH"
    case delete = "DELETE"
}
```

### Sending a JSON body

```swift
func post<Body: Encodable>(_ body: Body, to url: URL) async throws -> Data {
    var request = URLRequest(url: url)
    request.httpMethod = HTTPMethod.post.rawValue
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    request.httpBody = try JSONEncoder().encode(body)

    let (data, response) = try await session.data(for: request)
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
        throw URLError(.badServerResponse)
    }
    return data
}
```

---

## 2. A reusable generic API client

The pattern separates three concerns:

- **`Endpoint`** — a value that describes *what* to call (path, method, query, body, headers).
- **`HTTPClient`** — a protocol so callers depend on an abstraction (easy to mock).
- **`APIClient`** — the concrete implementation that owns the `URLSession` and decoders.

### 2.1 The `Endpoint` request-builder

```swift
import Foundation

/// Declarative description of one request. `Sendable` so it can cross actors freely.
struct Endpoint: Sendable {
    var path: String                       // e.g. "/v1/users/42"
    var method: HTTPMethod = .get
    var query: [URLQueryItem] = []
    var headers: [String: String] = [:]
    var body: Data? = nil

    /// Build a `URLRequest` against a base URL. Throws for a malformed URL.
    func urlRequest(baseURL: URL) throws -> URLRequest {
        guard var components = URLComponents(
            url: baseURL.appendingPathComponent(path),
            resolvingAgainstBaseURL: false
        ) else {
            throw APIError.invalidURL(path)
        }
        if !query.isEmpty { components.queryItems = query }

        guard let url = components.url else {
            throw APIError.invalidURL(path)
        }

        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        request.httpBody = body
        for (field, value) in headers {
            request.setValue(value, forHTTPHeaderField: field)
        }
        return request
    }
}

extension Endpoint {
    /// Convenience factory that JSON-encodes a body and sets Content-Type.
    static func json<Body: Encodable>(
        _ path: String,
        method: HTTPMethod,
        body: Body,
        encoder: JSONEncoder = .api
    ) throws -> Endpoint {
        var endpoint = Endpoint(path: path, method: method)
        endpoint.headers["Content-Type"] = "application/json"
        endpoint.body = try encoder.encode(body)
        return endpoint
    }
}
```

### 2.2 The `HTTPClient` protocol

```swift
protocol HTTPClient: Sendable {
    func send<T: Decodable & Sendable>(_ endpoint: Endpoint) async throws -> T

    /// For endpoints with no meaningful response body (e.g. 204 No Content).
    func send(_ endpoint: Endpoint) async throws
}
```

### 2.3 The concrete `APIClient` (an actor)

Modeling the client as an `actor` gives it a private, serialized mutable state box that is
safe under strict concurrency. `URLSession`, `JSONDecoder`, and the base `URL` are all
`Sendable` and injected.

```swift
actor APIClient: HTTPClient {
    private let baseURL: URL
    private let session: URLSession
    private let decoder: JSONDecoder
    private let tokenProvider: TokenProvider?
    private let interceptors: [RequestInterceptor]

    init(
        baseURL: URL,
        session: URLSession = .shared,
        decoder: JSONDecoder = .api,
        tokenProvider: TokenProvider? = nil,
        interceptors: [RequestInterceptor] = []
    ) {
        self.baseURL = baseURL
        self.session = session
        self.decoder = decoder
        self.tokenProvider = tokenProvider
        self.interceptors = interceptors
    }

    func send<T: Decodable & Sendable>(_ endpoint: Endpoint) async throws -> T {
        let data = try await perform(endpoint)
        do {
            return try decoder.decode(T.self, from: data)
        } catch let decodingError as DecodingError {
            throw APIError.decoding(describe(decodingError))
        }
    }

    func send(_ endpoint: Endpoint) async throws {
        _ = try await perform(endpoint)
    }

    // MARK: - Core request pipeline

    private func perform(_ endpoint: Endpoint, isRetry: Bool = false) async throws -> Data {
        var request = try endpoint.urlRequest(baseURL: baseURL)

        // Attach a bearer token if a provider is configured.
        if let tokenProvider {
            let token = try await tokenProvider.currentAccessToken()
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        // Apply interceptors (header injection, tracing, etc.).
        for interceptor in interceptors {
            request = try await interceptor.adapt(request)
        }

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: request)
        } catch let urlError as URLError {
            throw APIError(urlError)          // map transport failures
        }

        guard let http = response as? HTTPURLResponse else {
            throw APIError.invalidResponse
        }

        switch http.statusCode {
        case 200..<300:
            return data

        case 401 where !isRetry && tokenProvider != nil:
            // Refresh once, then replay the original request.
            try await tokenProvider?.refresh()
            return try await perform(endpoint, isRetry: true)

        case 401:
            throw APIError.unauthorized

        default:
            throw APIError.http(status: http.statusCode, data: data)
        }
    }
}
```

Usage is a single line at the call site:

```swift
struct User: Decodable, Sendable {
    let id: Int
    let displayName: String
    let email: String
}

let client: HTTPClient = APIClient(baseURL: URL(string: "https://api.example.com")!)

let user: User = try await client.send(
    Endpoint(path: "/v1/users/42", query: [URLQueryItem(name: "expand", value: "profile")])
)
```

---

## 3. `Codable` configuration

Centralize decoder/encoder configuration so every request is consistent. Snake-case keys and
ISO-8601 dates are the most common server conventions.

```swift
extension JSONDecoder {
    static let api: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        // .iso8601 handles "2026-07-05T12:34:56Z"; for fractional seconds use a custom strategy.
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }()
}

extension JSONEncoder {
    static let api: JSONEncoder = {
        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }()
}
```

### Fractional-second dates

`.iso8601` rejects timestamps with milliseconds. Supply a custom formatter when the server
sends `2026-07-05T12:34:56.789Z`:

```swift
extension JSONDecoder {
    static let apiFractional: JSONDecoder = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]

        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        decoder.dateDecodingStrategy = .custom { decoder in
            let container = try decoder.singleValueContainer()
            let string = try container.decode(String.self)
            guard let date = formatter.date(from: string) else {
                throw DecodingError.dataCorruptedError(
                    in: container,
                    debugDescription: "Unrecognized ISO-8601 date: \(string)"
                )
            }
            return date
        }
        return decoder
    }()
}
```

### Custom `Codable` for irregular payloads

When the wire shape does not match your domain model, implement `init(from:)`. Here a server
sends a status string that we map to an enum, and a nested envelope we want to flatten:

```swift
struct Article: Decodable, Sendable {
    enum Status: String, Decodable, Sendable {
        case draft, published, archived
    }

    let id: String
    let title: String
    let status: Status
    let authorName: String     // flattened from a nested "author" object

    private enum CodingKeys: String, CodingKey {
        case id, title, status, author
    }
    private enum AuthorKeys: String, CodingKey {
        case name
    }

    init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(String.self, forKey: .id)
        title = try container.decode(String.self, forKey: .title)
        status = try container.decodeIfPresent(Status.self, forKey: .status) ?? .draft

        let author = try container.nestedContainer(keyedBy: AuthorKeys.self, forKey: .author)
        authorName = try author.decode(String.self, forKey: .name)
    }
}
```

### Surfacing decoding errors cleanly

`DecodingError` is verbose; convert it into a short, actionable message once, in the client
(as shown in `APIClient.send`). The helper:

```swift
func describe(_ error: DecodingError) -> String {
    switch error {
    case let .keyNotFound(key, context):
        return "Missing key '\(key.stringValue)' at \(path(context))"
    case let .typeMismatch(type, context):
        return "Type mismatch, expected \(type) at \(path(context))"
    case let .valueNotFound(type, context):
        return "Missing value of type \(type) at \(path(context))"
    case let .dataCorrupted(context):
        return "Corrupted data at \(path(context)): \(context.debugDescription)"
    @unknown default:
        return "Unknown decoding error"
    }
}

private func path(_ context: DecodingError.Context) -> String {
    context.codingPath.map(\.stringValue).joined(separator: ".")
}
```

---

## 4. Typed error model

A single `APIError` covers every failure mode the layer can produce and maps `URLError`
into meaningful cases (offline, timeout, cancelled).

```swift
enum APIError: Error, Sendable, Equatable {
    case invalidURL(String)
    case invalidResponse
    case transport(URLError.Code)     // generic transport failure
    case offline
    case timedOut
    case cancelled
    case unauthorized                 // 401 that could not be recovered
    case http(status: Int, data: Data)
    case decoding(String)

    /// Map a `URLError` onto a semantic case.
    init(_ urlError: URLError) {
        switch urlError.code {
        case .notConnectedToInternet, .dataNotAllowed:
            self = .offline
        case .timedOut:
            self = .timedOut
        case .cancelled:
            self = .cancelled
        default:
            self = .transport(urlError.code)
        }
    }
}

extension APIError: LocalizedError {
    var errorDescription: String? {
        switch self {
        case .invalidURL(let path):   return "Invalid URL: \(path)"
        case .invalidResponse:        return "The server response was not valid HTTP."
        case .transport(let code):    return "Network error (\(code.rawValue))."
        case .offline:                return "You appear to be offline."
        case .timedOut:               return "The request timed out."
        case .cancelled:              return "The request was cancelled."
        case .unauthorized:           return "Your session has expired. Please sign in again."
        case .http(let status, _):    return "The server returned status \(status)."
        case .decoding(let detail):   return "Could not read the server response: \(detail)"
        }
    }
}
```

Because `cancelled` is a distinct case, call sites can ignore it when a `Task` is torn down
intentionally rather than showing a spurious error.

---

## 5. Authentication: bearer tokens, refresh, and Keychain storage

Never hardcode tokens. Store them in the Keychain, hand them out through an `async` provider,
and refresh transparently on `401` (the retry hook lives in `APIClient.perform`, section 2.3).

### 5.1 A `KeychainStore` actor around `SecItem*`

The Keychain C API is thread-safe but blocking; wrapping it in an `actor` serializes access
and keeps the surface `Sendable`.

```swift
import Foundation
import Security

actor KeychainStore {
    private let service: String

    init(service: String = "com.example.app.tokens") {
        self.service = service
    }

    func set(_ value: String, for account: String) throws {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
        ]
        // Delete any existing item, then add fresh (upsert).
        SecItemDelete(query as CFDictionary)

        var attributes = query
        attributes[kSecValueData as String] = data
        attributes[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlock

        let status = SecItemAdd(attributes as CFDictionary, nil)
        guard status == errSecSuccess else {
            throw KeychainError.unhandled(status)
        }
    }

    func string(for account: String) throws -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        switch status {
        case errSecSuccess:
            guard let data = item as? Data else { return nil }
            return String(decoding: data, as: UTF8.self)
        case errSecItemNotFound:
            return nil
        default:
            throw KeychainError.unhandled(status)
        }
    }

    func delete(_ account: String) throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
        ]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw KeychainError.unhandled(status)
        }
    }

    enum KeychainError: Error, Sendable {
        case unhandled(OSStatus)
    }
}
```

### 5.2 The token provider (refresh-on-401)

The provider owns the tokens, coalesces concurrent refreshes into a single in-flight task,
and persists results in the Keychain. Placeholders (`"<access-token>"`) stand in for real
values — no secret is ever committed.

```swift
protocol TokenProvider: Sendable {
    func currentAccessToken() async throws -> String
    func refresh() async throws
}

actor BearerTokenProvider: TokenProvider {
    private let keychain: KeychainStore
    private let refreshEndpoint: URL

    private var accessToken: String?
    private var refreshTask: Task<Void, Error>?   // coalesces concurrent refreshes

    private static let accessAccount = "access_token"
    private static let refreshAccount = "refresh_token"

    init(keychain: KeychainStore, refreshEndpoint: URL) {
        self.keychain = keychain
        self.refreshEndpoint = refreshEndpoint
    }

    func currentAccessToken() async throws -> String {
        if let accessToken { return accessToken }
        if let stored = try await keychain.string(for: Self.accessAccount) {
            accessToken = stored
            return stored
        }
        throw APIError.unauthorized
    }

    func refresh() async throws {
        // If a refresh is already running, await its result instead of racing.
        if let refreshTask {
            try await refreshTask.value
            return
        }
        let task = Task { try await performRefresh() }
        refreshTask = task
        defer { refreshTask = nil }
        try await task.value
    }

    private func performRefresh() async throws {
        guard let refreshToken = try await keychain.string(for: Self.refreshAccount) else {
            throw APIError.unauthorized
        }

        var request = URLRequest(url: refreshEndpoint)
        request.httpMethod = HTTPMethod.post.rawValue
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder.api.encode(["refresh_token": refreshToken])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            // Refresh itself failed → force re-authentication.
            throw APIError.unauthorized
        }

        struct TokenPair: Decodable { let accessToken: String; let refreshToken: String }
        let pair = try JSONDecoder.api.decode(TokenPair.self, from: data)

        accessToken = pair.accessToken
        try await keychain.set(pair.accessToken, for: Self.accessAccount)
        try await keychain.set(pair.refreshToken, for: Self.refreshAccount)
    }

    /// Seed the store after a login flow. In real code these come from the auth response.
    func store(accessToken: String = "<access-token>",
               refreshToken: String = "<refresh-token>") async throws {
        self.accessToken = accessToken
        try await keychain.set(accessToken, for: Self.accessAccount)
        try await keychain.set(refreshToken, for: Self.refreshAccount)
    }
}
```

---

## 6. Request adapting / interceptors

An interceptor is a small `Sendable` unit that can mutate a request before it goes out
(inject headers, add tracing IDs) or decide whether to retry. Because `adapt` is `async`, it
can await other actors.

```swift
protocol RequestInterceptor: Sendable {
    func adapt(_ request: URLRequest) async throws -> URLRequest
}

/// Injects static headers, a per-request idempotency key, and a locale.
struct DefaultHeadersInterceptor: RequestInterceptor {
    let appVersion: String
    let locale: String

    func adapt(_ request: URLRequest) async throws -> URLRequest {
        var request = request
        request.setValue(appVersion, forHTTPHeaderField: "X-App-Version")
        request.setValue(locale, forHTTPHeaderField: "Accept-Language")
        request.setValue(UUID().uuidString, forHTTPHeaderField: "X-Request-Id")
        return request
    }
}
```

### Retry with exponential backoff

A free function that wraps any throwing async operation, retries on retryable failures, and
honors cancellation (it checks `Task.isCancelled` via `Task.sleep`, which throws when the
task is cancelled).

```swift
func withRetry<T: Sendable>(
    maxAttempts: Int = 3,
    initialDelay: Duration = .milliseconds(300),
    operation: @Sendable () async throws -> T
) async throws -> T {
    var attempt = 0
    var delay = initialDelay

    while true {
        do {
            return try await operation()
        } catch let error as APIError where error.isRetryable && attempt < maxAttempts - 1 {
            attempt += 1
            try await Task.sleep(for: delay)   // cancellation-aware
            delay = delay * 2                  // exponential backoff
        }
    }
}

extension APIError {
    var isRetryable: Bool {
        switch self {
        case .offline, .timedOut, .transport:      return true
        case .http(let status, _):                 return status >= 500
        default:                                   return false
        }
    }
}
```

### Cancellation via `Task`

`URLSession.data(for:)` is cancellation-aware: cancelling the surrounding `Task` cancels the
underlying request and surfaces `URLError.cancelled` (mapped to `APIError.cancelled`).

```swift
let loadTask = Task {
    try await client.send(Endpoint(path: "/v1/feed")) as Feed
}

// Later — e.g. the user leaves the screen:
loadTask.cancel()
```

---

## 7. Concurrency

Fetch independent resources in parallel and cancel cooperatively.

### `async let` for a fixed set of parallel requests

```swift
struct Dashboard: Sendable {
    let user: User
    let notifications: [Notification]
    let feed: Feed
}

func loadDashboard(_ client: HTTPClient) async throws -> Dashboard {
    async let user: User = client.send(Endpoint(path: "/v1/me"))
    async let notifications: [Notification] = client.send(Endpoint(path: "/v1/notifications"))
    async let feed: Feed = client.send(Endpoint(path: "/v1/feed"))

    // Awaiting binds all three; a throw in any cancels the siblings.
    return try await Dashboard(user: user, notifications: notifications, feed: feed)
}
```

### `TaskGroup` for a dynamic, homogeneous fan-out

```swift
func loadUsers(ids: [Int], client: HTTPClient) async throws -> [User] {
    try await withThrowingTaskGroup(of: User.self) { group in
        for id in ids {
            group.addTask {
                try await client.send(Endpoint(path: "/v1/users/\(id)"))
            }
        }
        var users: [User] = []
        for try await user in group {
            users.append(user)
        }
        return users
    }
}
```

Everything above composes: a `TaskGroup` child inherits cancellation from its parent, so
cancelling the outer `Task` tears down every in-flight request. Types crossing the group
boundary (`User`, `Endpoint`) are `Sendable`, and closures passed to `addTask` are `@Sendable`
— both requirements are satisfied by design.

### Bounded concurrency

To avoid firing hundreds of requests at once, cap the group's width by seeding it and refilling
as results arrive:

```swift
func loadUsersBounded(ids: [Int], limit: Int, client: HTTPClient) async throws -> [User] {
    var iterator = ids.makeIterator()
    var results: [User] = []

    try await withThrowingTaskGroup(of: User.self) { group in
        for _ in 0..<min(limit, ids.count) {
            if let id = iterator.next() {
                group.addTask { try await client.send(Endpoint(path: "/v1/users/\(id)")) }
            }
        }
        while let user = try await group.next() {
            results.append(user)
            if let id = iterator.next() {
                group.addTask { try await client.send(Endpoint(path: "/v1/users/\(id)")) }
            }
        }
    }
    return results
}
```

---

## 8. Uploads, downloads & multipart

### Upload from `Data`

```swift
func upload(_ payload: Data, to url: URL, session: URLSession) async throws -> Data {
    var request = URLRequest(url: url)
    request.httpMethod = HTTPMethod.post.rawValue
    let (data, response) = try await session.upload(for: request, from: payload)
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
        throw APIError.invalidResponse
    }
    return data
}
```

### Download to a file (memory-friendly for large payloads)

```swift
func download(_ url: URL, session: URLSession) async throws -> URL {
    let (tempURL, response) = try await session.download(from: url)
    guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
        throw APIError.invalidResponse
    }
    // `tempURL` is deleted when this function returns — move it somewhere durable.
    let destination = URL.cachesDirectory.appending(path: url.lastPathComponent)
    try? FileManager.default.removeItem(at: destination)
    try FileManager.default.moveItem(at: tempURL, to: destination)
    return destination
}
```

### Multipart form body

Multipart is just a `Content-Type: multipart/form-data; boundary=…` request with a
hand-built body. Keep it small and explicit:

```swift
func multipartBody(
    fields: [String: String],
    fileField: String,
    fileName: String,
    fileData: Data,
    mimeType: String,
    boundary: String = "Boundary-\(UUID().uuidString)"
) -> (body: Data, contentType: String) {
    var body = Data()
    func append(_ string: String) { body.append(Data(string.utf8)) }

    for (name, value) in fields {
        append("--\(boundary)\r\n")
        append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n")
        append("\(value)\r\n")
    }
    append("--\(boundary)\r\n")
    append("Content-Disposition: form-data; name=\"\(fileField)\"; filename=\"\(fileName)\"\r\n")
    append("Content-Type: \(mimeType)\r\n\r\n")
    body.append(fileData)
    append("\r\n--\(boundary)--\r\n")

    return (body, "multipart/form-data; boundary=\(boundary)")
}
```

### Background configuration (note)

For transfers that must continue after the app is suspended (large media, OS-scheduled
uploads), use `URLSessionConfiguration.background(withIdentifier:)`. Background sessions **do
not** support the async `data(for:)` / `upload(for:)` convenience methods — they are inherently
delegate-driven (`URLSessionDownloadDelegate`, `urlSession(_:downloadTask:didFinishDownloadingTo:)`).
Bridge the delegate callbacks into async with a `CheckedContinuation` if you need an
`async` surface. Reserve background sessions for genuine background needs; a standard
`.default` session is correct for everything foreground.

---

## 9. Testing hook

The whole layer is testable without a live server by injecting a `URLSession` configured with
a custom `URLProtocol` subclass that returns canned responses. Because `APIClient` takes its
`session` in the initializer, a test simply passes:

```swift
let config = URLSessionConfiguration.ephemeral
config.protocolClasses = [MockURLProtocol.self]
let testSession = URLSession(configuration: config)
let client = APIClient(baseURL: URL(string: "https://api.example.com")!, session: testSession)
```

The `MockURLProtocol` implementation, per-request stubbing, and assertions on outgoing
requests are covered in `testing.md`.

---

## 10. Native first; third-party only when justified

For almost every app, the native `URLSession` stack above is the right choice: zero
dependencies, first-class async/await, structured-concurrency cancellation, background
transfers, and full control over the request pipeline.

If you later hit a concrete need that native APIs make tedious — declarative request/response
interceptor chains, built-in reachability + automatic retriers, request/response validation
DSLs, or `Combine`/multipart conveniences — **Alamofire** (latest 5.x) is the well-maintained
option. Treat it as an optional convenience, not a default: it wraps `URLSession` rather than
replacing it, so migrating in or out is straightforward, and nothing in this reference depends
on it.
