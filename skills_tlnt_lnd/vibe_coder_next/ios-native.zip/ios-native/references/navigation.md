# Navigation — TCA + SwiftUI Patterns

> Reference for the `ios-native` skill. For TCA reducer patterns, see `ARCHITECTURE.md`.
>
> Verified 2026-07-05: Swift 6.3.3, Xcode 26.6, iOS 26 SDK; TCA 1.26.0. Liquid Glass requires iOS 26.0+ (`glassEffect`, TabView `.tabBarMinimizeBehavior`).

## Table of Contents

1. [Navigation Paradigms Overview](#1-navigation-paradigms-overview)
2. [Stack-Based Navigation (Drill-Down)](#2-stack-based-navigation)
3. [Tree-Based Navigation (Modals)](#3-tree-based-navigation)
4. [TabView with Liquid Glass](#4-tabview-with-liquid-glass)
5. [Deep Linking](#5-deep-linking)
6. [Universal Links](#6-universal-links)
7. [Push Notification → Navigation](#7-push-notification-navigation)
8. [Combining Paradigms](#8-combining-paradigms)

---

## 1. Navigation Paradigms Overview

TCA provides two navigation approaches. Use **both** in the same app — they solve different problems.

| Paradigm | Use For | TCA Primitives | SwiftUI Primitives |
|---|---|---|---|
| **Stack-based** | Linear drill-down (list → detail → edit) | `StackState`, `StackAction`, `.forEach` | `NavigationStack(path:)` |
| **Tree-based** | Modals: sheets, alerts, dialogs, popovers | `@Presents`, `PresentationAction`, `.ifLet` | `.sheet(item:)`, `.alert()` |

**Why TCA uses `StackState` instead of `NavigationPath`**: NavigationPath is type-erased — you can't inspect, test, or manipulate its contents. `StackState` is a typed collection where you can assert on every element.

---

## 2. Stack-Based Navigation

For multi-level drill-down with variable depth and deep-link support.

### Reducer pattern

```swift
@Reducer
struct FeedCoordinator {
    // Define all possible screens in the navigation stack
    @Reducer(state: .equatable)
    enum Path {
        case detail(DetailFeature)
        case edit(EditFeature)
        case userProfile(UserProfileFeature)
        case settings(SettingsFeature)
    }

    @ObservableState
    struct State: Equatable {
        var feed = FeedFeature.State()
        var path = StackState<Path.State>()
    }

    enum Action {
        case feed(FeedFeature.Action)
        case path(StackActionOf<Path>)
    }

    var body: some ReducerOf<Self> {
        Scope(state: \.feed, action: \.feed) { FeedFeature() }

        Reduce { state, action in
            switch action {
            // Child delegate → push screen
            case let .feed(.itemTapped(id)):
                guard let item = state.feed.items[id: id] else { return .none }
                state.path.append(.detail(DetailFeature.State(item: item)))
                return .none

            // Listen to path children's delegates
            case let .path(.element(id: _, action: .detail(.delegate(.editItem(item))))):
                state.path.append(.edit(EditFeature.State(item: item)))
                return .none

            case let .path(.element(id: _, action: .detail(.delegate(.showUser(userId))))):
                state.path.append(.userProfile(UserProfileFeature.State(userId: userId)))
                return .none

            case let .path(.element(id: _, action: .edit(.delegate(.saved)))):
                // Pop back to detail after save
                state.path.removeLast()
                return .none

            case .feed, .path:
                return .none
            }
        }
        .forEach(\.path, action: \.path)
    }
}
```

### View pattern

```swift
struct FeedCoordinatorView: View {
    @Bindable var store: StoreOf<FeedCoordinator>

    var body: some View {
        NavigationStack(path: $store.scope(state: \.path, action: \.path)) {
            // Root view
            FeedView(store: store.scope(state: \.feed, action: \.feed))
        } destination: { store in
            // Pattern match on each path case
            switch store.case {
            case let .detail(store):
                DetailView(store: store)
            case let .edit(store):
                EditView(store: store)
            case let .userProfile(store):
                UserProfileView(store: store)
            case let .settings(store):
                SettingsView(store: store)
            }
        }
    }
}
```

### Programmatic navigation

```swift
// Push
state.path.append(.detail(DetailFeature.State(item: item)))

// Pop
state.path.removeLast()

// Pop to root
state.path.removeAll()

// Pop to specific screen
if let index = state.path.firstIndex(where: { 
    if case .detail = $0 { return true }
    return false
}) {
    state.path.removeSubrange((index + 1)...)
}

// Replace entire stack (useful for deep links)
state.path = StackState([
    .detail(DetailFeature.State(itemId: itemId)),
    .edit(EditFeature.State(itemId: itemId))
])
```

---

## 3. Tree-Based Navigation

For modals (sheets, alerts, confirmation dialogs, full-screen covers).

### Single destination

```swift
@Reducer
struct ProfileFeature {
    @ObservableState
    struct State: Equatable {
        @Presents var editSheet: EditProfileFeature.State?
        @Presents var alert: AlertState<Action.Alert>?
    }

    enum Action {
        case editTapped
        case deleteTapped
        case editSheet(PresentationAction<EditProfileFeature.Action>)
        case alert(PresentationAction<Action.Alert>)

        @CasePathable
        enum Alert {
            case confirmDelete
            case cancel
        }
    }

    var body: some ReducerOf<Self> {
        Reduce { state, action in
            switch action {
            case .editTapped:
                state.editSheet = EditProfileFeature.State(user: state.user)
                return .none

            case .deleteTapped:
                state.alert = AlertState {
                    TextState("Delete Account?")
                } actions: {
                    ButtonState(role: .destructive, action: .confirmDelete) {
                        TextState("Delete")
                    }
                    ButtonState(role: .cancel, action: .cancel) {
                        TextState("Cancel")
                    }
                } message: {
                    TextState("This action cannot be undone.")
                }
                return .none

            case .editSheet, .alert:
                return .none
            }
        }
        .ifLet(\.$editSheet, action: \.editSheet) { EditProfileFeature() }
        .ifLet(\.$alert, action: \.alert)
    }
}
```

### Multiple destinations via enum

When a feature can present different modals:

```swift
@Reducer(state: .equatable)
enum Destination {
    case edit(EditFeature)
    case share(ShareFeature)
    case alert(AlertState<Alert>)

    @CasePathable
    enum Alert { case confirmDelete }
}

@ObservableState
struct State: Equatable {
    @Presents var destination: Destination.State?
}

// View bindings:
.sheet(item: $store.scope(state: \.destination?.edit, action: \.destination.edit)) {
    EditView(store: $0)
}
.sheet(item: $store.scope(state: \.destination?.share, action: \.destination.share)) {
    ShareView(store: $0)
}
.alert($store.scope(state: \.destination?.alert, action: \.destination.alert))
```

### Dismissal

```swift
// From child: send a delegate action, parent sets destination = nil
case .destination(.presented(.edit(.delegate(.saved)))):
    state.destination = nil
    return .none

// Or child can self-dismiss:
@Dependency(\.dismiss) var dismiss

case .closeTapped:
    return .run { _ in await dismiss() }
```

---

## 4. TabView with Liquid Glass

### Root app structure

```swift
@Reducer
struct AppFeature {
    @ObservableState
    struct State: Equatable {
        var selectedTab: Tab = .feed
        var feedCoordinator = FeedCoordinator.State()
        var searchCoordinator = SearchCoordinator.State()
        var profileCoordinator = ProfileCoordinator.State()
    }

    enum Tab: Int, Equatable { case feed, search, profile }

    enum Action {
        case tabSelected(Tab)
        case feedCoordinator(FeedCoordinator.Action)
        case searchCoordinator(SearchCoordinator.Action)
        case profileCoordinator(ProfileCoordinator.Action)
    }

    var body: some ReducerOf<Self> {
        Scope(state: \.feedCoordinator, action: \.feedCoordinator) { FeedCoordinator() }
        Scope(state: \.searchCoordinator, action: \.searchCoordinator) { SearchCoordinator() }
        Scope(state: \.profileCoordinator, action: \.profileCoordinator) { ProfileCoordinator() }

        Reduce { state, action in
            switch action {
            case let .tabSelected(tab):
                state.selectedTab = tab
                return .none
            case .feedCoordinator, .searchCoordinator, .profileCoordinator:
                return .none
            }
        }
    }
}
```

### View with iOS 26 Liquid Glass

```swift
struct AppView: View {
    @Bindable var store: StoreOf<AppFeature>

    var body: some View {
        TabView(selection: $store.selectedTab.sending(\.tabSelected)) {
            Tab("Feed", systemImage: "list.star", value: .feed) {
                FeedCoordinatorView(
                    store: store.scope(state: \.feedCoordinator, action: \.feedCoordinator)
                )
            }

            Tab("Search", systemImage: "magnifyingglass", value: .search, role: .search) {
                SearchCoordinatorView(
                    store: store.scope(state: \.searchCoordinator, action: \.searchCoordinator)
                )
            }

            Tab("Profile", systemImage: "person.circle", value: .profile) {
                ProfileCoordinatorView(
                    store: store.scope(state: \.profileCoordinator, action: \.profileCoordinator)
                )
            }
        }
        .tabBarMinimizeBehavior(.onScrollDown)
    }
}
```

Each tab owns its own `NavigationStack` inside the coordinator view. Tab state is preserved when switching tabs.

---

## 5. Deep Linking

### URL routing

```swift
enum DeepLink {
    case feedItem(id: String)
    case userProfile(id: String)
    case settings
    case search(query: String)

    static func parse(_ url: URL) -> DeepLink? {
        guard let components = URLComponents(url: url, resolvingAgainstBaseURL: true) else {
            return nil
        }
        let pathComponents = components.path.split(separator: "/").map(String.init)

        switch pathComponents.first {
        case "items":
            guard let id = pathComponents[safe: 1] else { return nil }
            return .feedItem(id: id)
        case "users":
            guard let id = pathComponents[safe: 1] else { return nil }
            return .userProfile(id: id)
        case "settings":
            return .settings
        case "search":
            let query = components.queryItems?.first(where: { $0.name == "q" })?.value ?? ""
            return .search(query: query)
        default:
            return nil
        }
    }
}
```

### Handling in root reducer

```swift
// In AppFeature
enum Action {
    // ...
    case onOpenURL(URL)
    case deepLinkHandled(DeepLink)
}

case let .onOpenURL(url):
    guard let deepLink = DeepLink.parse(url) else { return .none }
    return .send(.deepLinkHandled(deepLink))

case let .deepLinkHandled(link):
    switch link {
    case let .feedItem(id):
        state.selectedTab = .feed
        state.feedCoordinator.path.removeAll()
        state.feedCoordinator.path.append(
            .detail(DetailFeature.State(itemId: id))
        )

    case let .userProfile(id):
        state.selectedTab = .profile
        state.profileCoordinator.path.append(
            .otherUser(UserProfileFeature.State(userId: id))
        )

    case .settings:
        state.selectedTab = .profile
        state.profileCoordinator.path.append(
            .settings(SettingsFeature.State())
        )

    case let .search(query):
        state.selectedTab = .search
        state.searchCoordinator.search.query = query
        return .send(.searchCoordinator(.search(.performSearch)))
    }
    return .none
```

### Wiring in the app entry point

```swift
@main
struct SampleApp: App {
    let store = Store(initialState: AppFeature.State()) { AppFeature() }

    var body: some Scene {
        WindowGroup {
            AppView(store: store)
                .onOpenURL { url in
                    store.send(.onOpenURL(url))
                }
        }
    }
}
```

---

## 6. Universal Links

### Setup (Associated Domains)

1. Add `applinks:example.com` to Associated Domains capability
2. Host `apple-app-site-association` at `https://example.com/.well-known/`:

```json
{
    "applinks": {
        "apps": [],
        "details": [{
            "appID": "ABCDE12345.com.example.app",
            "paths": ["/items/*", "/users/*", "/settings"]
        }]
    }
}
```

3. Handle in SwiftUI:

```swift
AppView(store: store)
    .onOpenURL { url in
        store.send(.onOpenURL(url))
    }
    // Universal Links also come through onOpenURL on iOS 17+
```

---

## 7. Push Notification → Navigation

### Flow: notification payload → deep link → TCA

```swift
// In AppDelegate or notification handler:
func userNotificationCenter(
    _ center: UNUserNotificationCenter,
    didReceive response: UNNotificationResponse
) async {
    let userInfo = response.notification.request.content.userInfo
    guard let deepLinkString = userInfo["deep_link"] as? String,
          let url = URL(string: deepLinkString) else { return }

    // Send to store — will be processed by onOpenURL handler
    await MainActor.run {
        store.send(.onOpenURL(url))
    }
}
```

### Payload convention

```json
{
    "aps": { "alert": { "title": "New item!", "body": "Check it out" } },
    "deep_link": "myapp://items/abc123"
}
```

---

## 8. Combining Paradigms

A real app uses both stack and tree navigation together:

```swift
@Reducer
struct FeedCoordinator {
    // Stack: drill-down screens
    @Reducer(state: .equatable)
    enum Path {
        case detail(DetailFeature)
        case userProfile(UserProfileFeature)
    }

    @ObservableState
    struct State: Equatable {
        var feed = FeedFeature.State()
        var path = StackState<Path.State>()
    }

    enum Action {
        case feed(FeedFeature.Action)
        case path(StackActionOf<Path>)
    }

    var body: some ReducerOf<Self> {
        Scope(state: \.feed, action: \.feed) { FeedFeature() }

        Reduce { state, action in
            switch action {
            // Stack push
            case let .feed(.itemTapped(id)):
                guard let item = state.feed.items[id: id] else { return .none }
                state.path.append(.detail(DetailFeature.State(item: item)))
                return .none

            // Detail uses TREE-based for its own modals (sheet, alert)
            // Those are handled inside DetailFeature via @Presents

            // Detail delegates for stack navigation
            case let .path(.element(id: _, action: .detail(.delegate(.showUser(userId))))):
                state.path.append(.userProfile(UserProfileFeature.State(userId: userId)))
                return .none

            case .feed, .path:
                return .none
            }
        }
        .forEach(\.path, action: \.path)
    }
}
```

**Rule of thumb**: stack-based for forward navigation (list → detail → edit), tree-based for overlays (sheets, alerts, action sheets) within any screen.
