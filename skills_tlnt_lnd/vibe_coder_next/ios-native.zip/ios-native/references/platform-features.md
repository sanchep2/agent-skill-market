# Platform Features — Widgets, Live Activities, Notifications

> Reference for the `ios-native` skill. For Liquid Glass UI patterns, see `SWIFTUI.md`.
>
> Toolchain baseline: iOS 26 SDK, Xcode 26.6, Swift 6.3.3.

## Table of Contents

1. [WidgetKit Overview](#1-widgetkit-overview)
2. [Interactive Widgets](#2-interactive-widgets)
3. [Widget Configuration with AppIntents](#3-widget-configuration-with-appintents)
4. [Sharing Native Data with Widgets](#4-sharing-native-data-with-widgets)
5. [Live Activities and Dynamic Island](#5-live-activities-and-dynamic-island)
6. [Push-Based Live Activity Updates](#6-push-based-live-activity-updates)
7. [Push Notifications](#7-push-notifications)
8. [WidgetKit in iOS 26](#8-widgetkit-in-ios-26)
9. [Limitations and Budgets](#9-limitations-and-budgets)

---

## 1. WidgetKit Overview

### Evolution

| iOS Version | Feature |
|---|---|
| 14 | Static widgets (read-only timeline) |
| 16 | Lock Screen widgets, accessory families |
| 17 | **Interactive widgets** (Button/Toggle), AppIntentConfiguration |
| 18 | Control Widgets (Control Center), tinted rendering |
| 26 | Liquid Glass, CarPlay widgets, widget push updates, Developer Mode |

### Widget anatomy

```swift
struct SampleWidget: Widget {
    let kind: String = "SampleWidget"

    var body: some WidgetConfiguration {
        AppIntentConfiguration(
            kind: kind,
            intent: SelectCategoryIntent.self,
            provider: SampleTimelineProvider()
        ) { entry in
            SampleWidgetView(entry: entry)
                .containerBackground(.fill.tertiary, for: .widget) // Required iOS 17+
        }
        .configurationDisplayName("Sample Feed")
        .description("See the latest updates")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}
```

### Timeline provider (async)

```swift
struct SampleTimelineProvider: AppIntentTimelineProvider {
    typealias Entry = SampleWidgetEntry
    typealias Intent = SelectCategoryIntent

    func placeholder(in context: Context) -> Entry {
        Entry(date: .now, items: FeedItem.placeholders, category: .all)
    }

    func snapshot(for configuration: Intent, in context: Context) async -> Entry {
        let items = await fetchItems(category: configuration.category)
        return Entry(date: .now, items: items, category: configuration.category)
    }

    func timeline(for configuration: Intent, in context: Context) async -> Timeline<Entry> {
        let items = await fetchItems(category: configuration.category)
        let entry = Entry(date: .now, items: items, category: configuration.category)

        // Refresh every 30 minutes
        let nextUpdate = Calendar.current.date(byAdding: .minute, value: 30, to: .now)!
        return Timeline(entries: [entry], policy: .after(nextUpdate))
    }

    private func fetchItems(category: Category) async -> [WidgetFeedItem] {
        // Read from App Group shared container
        guard let defaults = UserDefaults(suiteName: "group.com.example.app"),
              let data = defaults.data(forKey: "widget_feed_\(category.rawValue)"),
              let items = try? JSONDecoder().decode([WidgetFeedItem].self, from: data)
        else {
            return []
        }
        return Array(items.prefix(5))
    }
}

struct SampleWidgetEntry: TimelineEntry {
    let date: Date
    let items: [WidgetFeedItem]
    let category: Category
}
```

---

## 2. Interactive Widgets

Only **Button** and **Toggle** are supported. They execute via **AppIntents** — no closures.

### Button in widget

```swift
struct SampleWidgetView: View {
    var entry: SampleWidgetEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(entry.items.prefix(3)) { item in
                HStack {
                    Text(item.title).font(.caption).lineLimit(1)
                    Spacer()
                    Button(intent: ToggleFavoriteIntent(itemId: item.id)) {
                        Image(systemName: item.isFavorite ? "heart.fill" : "heart")
                            .foregroundStyle(item.isFavorite ? .red : .secondary)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}
```

### AppIntent for widget interaction

```swift
struct ToggleFavoriteIntent: AppIntent {
    static var title: LocalizedStringResource = "Toggle Favorite"

    @Parameter(title: "Item ID")
    var itemId: String

    init() {}
    init(itemId: String) { self.itemId = itemId }

    func perform() async throws -> some IntentResult {
        // Read shared data
        let defaults = UserDefaults(suiteName: "group.com.example.app")!
        var items = loadItems(from: defaults)

        // Toggle
        if let index = items.firstIndex(where: { $0.id == itemId }) {
            items[index].isFavorite.toggle()
            saveItems(items, to: defaults)
        }

        // No need to call WidgetCenter.reloadTimelines — WidgetKit
        // automatically reloads after AppIntent.perform() returns
        return .result()
    }
}
```

**Important**: The AppIntent's target membership must include **both** the main app and the widget extension.

### Toggle in widget

```swift
Toggle(isOn: item.isCompleted,
       intent: MarkCompleteIntent(taskId: item.id)) {
    Text(item.title)
        .strikethrough(item.isCompleted)
}
.toggleStyle(.switch)
```

---

## 3. Widget Configuration with AppIntents

### Configurable widget (user selects category)

```swift
struct SelectCategoryIntent: WidgetConfigurationIntent {
    static var title: LocalizedStringResource = "Select Category"
    static var description: IntentDescription = "Choose which category to display"

    @Parameter(title: "Category", default: .all)
    var category: Category
}

// Category must conform to AppEnum for widget config:
enum Category: String, AppEnum, CaseIterable, Codable {
    case all, tech, business, creator

    static var typeDisplayRepresentation: TypeDisplayRepresentation = "Category"
    static var caseDisplayRepresentations: [Category: DisplayRepresentation] = [
        .all: "All",
        .tech: "Tech",
        .business: "Business",
        .creator: "Creator"
    ]
}
```

---

## 4. Sharing Native Data with Widgets

Widget extensions run in a **separate process** — they cannot read the main app's memory, and the widget's timeline provider must be able to render even when the app has never launched in the background. The native answer is a **shared container** provided by an **App Group**: the main app writes, the widget reads. Two storage options cover most needs — a shared `UserDefaults` suite for small, flat payloads, and a shared SwiftData `ModelContainer` for larger or relational data. Both live in the App Group's shared file container.

### App Group setup

1. Enable the **App Groups** capability on **both** the main app target and the widget extension target.
2. Use an identical group identifier on both, e.g. `group.com.example.app`.
3. Both targets now see the same `UserDefaults(suiteName:)` and the same shared file-system container URL (`FileManager.default.containerURL(forSecurityApplicationGroupIdentifier:)`).

### Option A — Shared `UserDefaults(suiteName:)` (small, flat data)

Best for a handful of Codable values or a short list (a few KB). The app encodes and writes; the widget decodes and reads.

```swift
enum SharedStore {
    static let suiteName = "group.com.example.app"
    static var defaults: UserDefaults { UserDefaults(suiteName: suiteName)! }
}

// In the main app — after fetching data from your data layer:
func syncWidgetData(_ items: [FeedItem]) {
    let widgetItems = items.map { WidgetFeedItem(from: $0) }
    if let data = try? JSONEncoder().encode(widgetItems) {
        SharedStore.defaults.set(data, forKey: "widget_feed_all")
    }

    // Nudge the widget to rebuild its timeline (this call is NOT budgeted)
    WidgetCenter.shared.reloadTimelines(ofKind: "SampleWidget")
}

// In the widget timeline provider:
func fetchItems() -> [WidgetFeedItem] {
    guard let data = SharedStore.defaults.data(forKey: "widget_feed_all") else { return [] }
    return (try? JSONDecoder().decode([WidgetFeedItem].self, from: data)) ?? []
}
```

Keep the payload small — `UserDefaults` is not meant for large blobs, and the widget process has a tight memory budget (~30 MB).

### Option B — Shared SwiftData `ModelContainer` (larger / relational data)

For richer data, point a SwiftData `ModelContainer` at the App Group container URL so both the app and the widget open the **same** store file. The app writes on the main actor; the widget's provider opens the container read-only-ish and fetches what it needs.

```swift
import SwiftData

@Model
final class FeedItemModel {
    @Attribute(.unique) var id: String
    var title: String
    var isFavorite: Bool
    var updatedAt: Date

    init(id: String, title: String, isFavorite: Bool, updatedAt: Date) {
        self.id = id
        self.title = title
        self.isFavorite = isFavorite
        self.updatedAt = updatedAt
    }
}

// Shared container factory — used identically by the app and the widget.
enum SharedModelContainer {
    static let appGroupID = "group.com.example.app"

    static func make() -> ModelContainer {
        let url = FileManager.default
            .containerURL(forSecurityApplicationGroupIdentifier: appGroupID)!
            .appending(path: "Model.sqlite")

        let config = ModelConfiguration(url: url)
        return try! ModelContainer(for: FeedItemModel.self, configurations: config)
    }
}
```

Reading from the widget's timeline provider:

```swift
struct SampleTimelineProvider: AppIntentTimelineProvider {
    func timeline(for configuration: SelectCategoryIntent,
                  in context: Context) async -> Timeline<SampleWidgetEntry> {
        let items = await fetchItems()
        let entry = SampleWidgetEntry(date: .now, items: items, category: configuration.category)

        let nextUpdate = Calendar.current.date(byAdding: .minute, value: 30, to: .now)!
        return Timeline(entries: [entry], policy: .after(nextUpdate))
    }

    @MainActor
    private func fetchItems() -> [WidgetFeedItem] {
        let context = SharedModelContainer.make().mainContext
        var descriptor = FetchDescriptor<FeedItemModel>(
            sortBy: [SortDescriptor(\.updatedAt, order: .reverse)]
        )
        descriptor.fetchLimit = 5
        let models = (try? context.fetch(descriptor)) ?? []
        return models.map { WidgetFeedItem(id: $0.id, title: $0.title, isFavorite: $0.isFavorite) }
    }
}
```

After the app mutates the shared store, call
`WidgetCenter.shared.reloadTimelines(ofKind: "SampleWidget")` (or `reloadAllTimelines()`)
so the widget re-runs its provider against the updated store.

### Choosing between A and B

| | Shared `UserDefaults` | Shared SwiftData container |
|---|---|---|
| Payload size | A few KB | Larger, many rows |
| Shape | Flat / Codable blob | Relational, queryable |
| Read cost in widget | Minimal | Fetch + model init overhead |
| Write concurrency | App writes wholesale | App inserts/updates rows |

For a single small feed, Option A is simplest. When the widget needs to filter/sort a non-trivial dataset (or the same models already back the app's UI), Option B avoids re-serializing everything on each change. Both stay fully native — no cross-language bridging.

---

## 5. Live Activities and Dynamic Island

### Define attributes

```swift
import ActivityKit

struct DeliveryAttributes: ActivityAttributes {
    // Static data (set at creation, never changes)
    let orderNumber: String
    let vendorName: String
    let vendorLogo: String

    // Dynamic data (updated throughout lifecycle)
    struct ContentState: Codable, Hashable {
        enum Status: String, Codable {
            case preparing, enRoute, nearBy, delivered
        }
        var status: Status
        var eta: Date
        var driverName: String?
    }
}
```

### Start a Live Activity

```swift
func startDeliveryTracking(order: Order) throws -> Activity<DeliveryAttributes> {
    let attributes = DeliveryAttributes(
        orderNumber: order.id,
        vendorName: order.vendorName,
        vendorLogo: order.vendorLogoURL
    )

    let initialState = DeliveryAttributes.ContentState(
        status: .preparing,
        eta: order.estimatedDelivery
    )

    let content = ActivityContent(
        state: initialState,
        staleDate: Calendar.current.date(byAdding: .hour, value: 1, to: .now),
        relevanceScore: 75
    )

    return try Activity.request(
        attributes: attributes,
        content: content,
        pushType: .token  // Enable push updates
    )
}
```

### Lock Screen + Dynamic Island UI

```swift
struct DeliveryLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: DeliveryAttributes.self) { context in
            // LOCK SCREEN / BANNER presentation
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(context.attributes.vendorName).font(.headline)
                    Spacer()
                    Text(context.state.status.rawValue.capitalized)
                        .font(.caption).bold()
                        .padding(.horizontal, 8).padding(.vertical, 4)
                        .background(statusColor(context.state.status))
                        .clipShape(Capsule())
                }
                HStack {
                    Image(systemName: statusIcon(context.state.status))
                    Text("ETA: ").font(.subheadline) +
                    Text(context.state.eta, style: .timer).font(.subheadline).bold()
                }
                if let driver = context.state.driverName {
                    Text("Driver: \(driver)").font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding()

        } dynamicIsland: { context in
            DynamicIsland {
                // EXPANDED presentation (long-press)
                DynamicIslandExpandedRegion(.leading) {
                    Image(systemName: statusIcon(context.state.status))
                        .font(.title2)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text(context.state.eta, style: .timer)
                        .font(.caption).monospacedDigit()
                }
                DynamicIslandExpandedRegion(.bottom) {
                    HStack {
                        Text(context.attributes.vendorName)
                        Spacer()
                        Text(context.state.status.rawValue.capitalized)
                    }
                    .font(.caption)
                }
            } compactLeading: {
                // COMPACT (single activity visible)
                Image(systemName: statusIcon(context.state.status))
            } compactTrailing: {
                Text(context.state.eta, style: .timer)
                    .monospacedDigit().font(.caption)
            } minimal: {
                // MINIMAL (multiple activities, shows just icon)
                Image(systemName: "box.truck")
            }
        }
    }
}
```

### Update and end

```swift
// Update (local)
func updateDelivery(activity: Activity<DeliveryAttributes>, newState: DeliveryAttributes.ContentState) async {
    let content = ActivityContent(
        state: newState,
        staleDate: Calendar.current.date(byAdding: .minute, value: 30, to: .now)
    )
    await activity.update(content)
}

// End
func endDelivery(activity: Activity<DeliveryAttributes>) async {
    let finalState = DeliveryAttributes.ContentState(
        status: .delivered, eta: .now
    )
    await activity.end(
        ActivityContent(state: finalState, staleDate: nil),
        dismissalPolicy: .after(.now.addingTimeInterval(3600)) // Stay 1 hour
    )
}
```

---

## 6. Push-Based Live Activity Updates

### Get push token

```swift
let activity = try startDeliveryTracking(order: order)

// Observe token updates
Task {
    for await tokenData in activity.pushTokenUpdates {
        let token = tokenData.map { String(format: "%02x", $0) }.joined()
        // Send token to your server
        try await api.registerActivityPushToken(
            activityId: activity.id,
            pushToken: token
        )
    }
}
```

### Server-side APNs payload

Headers:
- `apns-push-type: liveactivity`
- `apns-topic: com.example.app.push-type.liveactivity`
- `apns-priority: 10`

```json
{
    "aps": {
        "timestamp": 1706200000,
        "event": "update",
        "content-state": {
            "status": "enRoute",
            "eta": "2026-01-25T18:30:00Z",
            "driverName": "Carlos"
        },
        "alert": {
            "title": "Your order is on the way!",
            "body": "Carlos is heading to you — ETA 15 min"
        },
        "sound": "default"
    }
}
```

To end via push, set `"event": "end"` with optional `"dismissal-date"`.

### Push-to-start (iOS 17.2+)

Register for push-to-start tokens and start activities remotely:

```swift
Task {
    for await tokenData in Activity<DeliveryAttributes>.pushToStartTokenUpdates {
        let token = tokenData.map { String(format: "%02x", $0) }.joined()
        try await api.registerPushToStartToken(token)
    }
}
```

---

## 7. Push Notifications

### Registration and handling

```swift
// In AppDelegate
func application(_ application: UIApplication,
                 didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
    let token = deviceToken.map { String(format: "%02x", $0) }.joined()
    // Send to server
}

// Rich notification handling
func userNotificationCenter(
    _ center: UNUserNotificationCenter,
    didReceive response: UNNotificationResponse
) async {
    let userInfo = response.notification.request.content.userInfo

    // Route to deep link
    if let deepLink = userInfo["deep_link"] as? String,
       let url = URL(string: deepLink) {
        await MainActor.run {
            appStore.send(.onOpenURL(url))
        }
    }
}
```

### Notification categories and actions

```swift
let likeAction = UNNotificationAction(identifier: "LIKE", title: "❤️ Like")
let viewAction = UNNotificationAction(identifier: "VIEW", title: "View",
                                       options: .foreground)

let category = UNNotificationCategory(
    identifier: "NEW_CONTENT",
    actions: [likeAction, viewAction],
    intentIdentifiers: []
)

UNUserNotificationCenter.current().setNotificationCategories([category])
```

---

## 8. WidgetKit in iOS 26

### New features

- **Liquid Glass**: Widgets automatically adopt glass material when compiled with Xcode 26
- **CarPlay widgets**: Extend your widgets to CarPlay dashboard
- **Widget push updates**: Server can push timeline updates via APNs (separate from Live Activity push)
- **RelevanceConfiguration**: Surface widgets contextually in Smart Stack
- **Developer Mode**: Bypass refresh budgets during testing (Settings → Developer)

### Relevance-based widgets

```swift
struct RelevantWidget: Widget {
    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: "RelevantWidget", intent: MyIntent.self,
                               provider: MyProvider()) { entry in
            MyWidgetView(entry: entry)
                .containerBackground(.fill.tertiary, for: .widget)
        }
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

// In provider — set relevance per entry:
func timeline(for configuration: MyIntent, in context: Context) async -> Timeline<Entry> {
    let entry = Entry(date: .now, data: data, relevance: .init(score: 80))
    return Timeline(entries: [entry], policy: .after(nextUpdate))
}
```

---

## 9. Limitations and Budgets

### WidgetKit

| Constraint | Value |
|---|---|
| Memory limit | ~30 MB per widget extension |
| Timeline refreshes/day | 40–70 (dynamically allocated by system) |
| `reloadTimelines()` from app | NOT budgeted (unlimited) |
| SwiftUI only | No UIKit, no animations, no `@State`/`@ObservedObject` |
| `systemSmall` tap | Single target only (`widgetURL`) |
| `systemMedium`/`Large` | Multiple `Link` destinations allowed |
| Widget push budget | Limited; not for real-time updates |

### Live Activities

| Constraint | Value |
|---|---|
| Concurrent activities | ~5 per app |
| Active in Dynamic Island | Up to 8 hours |
| Active on Lock Screen | Up to 12 hours |
| Push update payload | 4 KB max |
| Content update frequency | Budgeted (set `NSSupportsLiveActivitiesFrequentUpdates` for real-time) |
| Lock Screen height | 84–160 points |
| Media support | No images, GIFs, or video |
| Auto-updating time | Use `Text(date, style: .timer)` — updates without push |

### Tips for budget management

- Call `WidgetCenter.shared.reloadTimelines(ofKind:)` from the app (not budgeted) after data changes
- Use `.after(date)` reload policy instead of `.atEnd`
- Batch data updates and write to the App Group container before triggering reload
- Enable WidgetKit Developer Mode during testing to bypass budget limits
