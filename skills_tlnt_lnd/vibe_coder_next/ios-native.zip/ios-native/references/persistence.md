# Persistence (SwiftData & Core Data)

This reference covers on-device persistence for a standalone native iOS app. The
default recommendation is **SwiftData** — Apple's declarative persistence
framework layered on the same storage engine as Core Data, but with a modern,
type-safe, Swift-first API. This document targets the **iOS 26 SDK**, **Swift
6.3.3**, and **Xcode 26.6**. SwiftData is available from iOS 17; this app sets a
**minimum deployment target of iOS 18**, which gives you the stabilized
`ModelActor`, `#Index`, `#Unique`, and compound-uniqueness APIs without falling
back to Core Data interop for common cases.

The persistence layer has three jobs: (1) model the domain as `@Model` types, (2)
expose live reads to SwiftUI via `@Query`, and (3) apply writes safely from the
main actor for UI-driven edits and from a background `ModelActor` for sync. The
rest of this document builds each of those up, then covers migrations, an
offline-first sync pattern, App Group sharing with a widget, when Core Data is
still the right call, and the smaller stores (`UserDefaults`, Keychain, files).

---

## 1. SwiftData fundamentals

### 1.1 Declaring models with `@Model`

`@Model` is a macro applied to a `final class`. It makes every stored property
persistent by default, synthesizes the schema, and turns instances into
change-tracked objects managed by a `ModelContext`.

```swift
import Foundation
import SwiftData

@Model
final class Article {
    // A stable, app-assigned identifier is strongly recommended for anything
    // that comes from a server. `.unique` enforces upsert semantics on insert.
    #Unique<Article>([\.remoteID])

    // Speed up the common query paths.
    #Index<Article>([\.publishedAt], [\.remoteID])

    @Attribute(.unique) var remoteID: String
    var title: String
    var summary: String
    var publishedAt: Date
    var isBookmarked: Bool

    // Large binary data stored out-of-line in an external file, referenced by
    // the row. Good for images/blobs you don't want inflating the row.
    @Attribute(.externalStorage) var coverImageData: Data?

    // Relationship: one Article has many Comments; deleting the Article cascades.
    @Relationship(deleteRule: .cascade, inverse: \Comment.article)
    var comments: [Comment] = []

    // A transient property is NOT persisted (recomputed at runtime).
    @Transient var isExpandedInUI: Bool = false

    init(
        remoteID: String,
        title: String,
        summary: String,
        publishedAt: Date,
        isBookmarked: Bool = false
    ) {
        self.remoteID = remoteID
        self.title = title
        self.summary = summary
        self.publishedAt = publishedAt
        self.isBookmarked = isBookmarked
    }
}

@Model
final class Comment {
    var body: String
    var createdAt: Date

    // Inverse side of the relationship. Nullify on delete so a deleted comment
    // doesn't drag the article with it.
    @Relationship(deleteRule: .nullify) var article: Article?

    init(body: String, createdAt: Date = .now, article: Article? = nil) {
        self.body = body
        self.createdAt = createdAt
        self.article = article
    }
}
```

Key attribute and macro semantics:

- `@Attribute(.unique)` — enforces a unique constraint on a single property.
  On insert, a matching existing row is **updated** rather than duplicated
  (native upsert). This is the backbone of the sync pattern in §5.
- `#Unique<Model>([\.a, \.b])` — a **compound** uniqueness constraint across
  several key paths (iOS 18+). Use it when the natural key is a tuple.
- `#Index<Model>([\.keyPath], …)` — declares single or compound indexes to make
  filtered/sorted queries fast. Index the columns you sort and predicate on.
- `@Attribute(.externalStorage)` — stores large `Data` in a sidecar file.
- `@Attribute(.transformable(by:))` — for legacy value transformers; rarely
  needed in greenfield code.
- `@Transient` — excluded from persistence; must have a default value.
- `@Relationship(deleteRule:inverse:)` — declares the delete rule and the
  inverse key path. Delete rules:
  - `.cascade` — deleting the parent deletes the related objects.
  - `.nullify` — deleting the parent sets the relationship to `nil` (default
    for optional relationships).
  - `.deny` — deletion fails if related objects still exist.
  - `.noAction` — you take responsibility for consistency (rare).

### 1.2 The container and the context

- **`ModelContainer`** owns the on-disk store and the schema. Create one per
  store; it's the source of truth.
- **`ModelContext`** is a scratchpad/unit-of-work bound to a container. It
  tracks inserts/updates/deletes until you `save()`. Each context has its own
  view of unsaved changes.

Wire the container into the app once with the `.modelContainer(for:)` modifier.
This creates (or reuses) a container for the given model types, installs its
main-actor context into the SwiftUI environment, and enables autosave:

```swift
import SwiftUI
import SwiftData

@main
struct ReaderApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
        // Schema is inferred from the model list. Related models
        // (Comment) are pulled in transitively via the relationship.
        .modelContainer(for: [Article.self])
    }
}
```

For anything beyond the defaults (custom URL, App Group, in-memory tests,
migration plan) build the container yourself and hand it over:

```swift
@main
struct ReaderApp: App {
    let container: ModelContainer

    init() {
        let schema = Schema([Article.self, Comment.self])
        let config = ModelConfiguration(
            "Reader",
            schema: schema,
            isStoredInMemoryOnly: false,
            allowsSave: true
        )
        do {
            container = try ModelContainer(
                for: schema,
                migrationPlan: ReaderMigrationPlan.self,
                configurations: [config]
            )
        } catch {
            fatalError("Failed to create ModelContainer: \(error)")
        }
    }

    var body: some Scene {
        WindowGroup { RootView() }
            .modelContainer(container)
    }
}
```

The `.modelContainer(_:)` overload injects **both** the container and its
associated main-actor `ModelContext` into `@Environment`, so views can use
`@Query` and `@Environment(\.modelContext)` immediately.

---

## 2. Querying

### 2.1 `@Query` in SwiftUI

`@Query` is a property wrapper that runs a fetch against the environment's
context and **keeps the view in sync** — when the underlying data changes, the
view re-renders. It reads the container installed by `.modelContainer`.

```swift
import SwiftUI
import SwiftData

struct ArticleListView: View {
    // Sorted, unfiltered.
    @Query(sort: \Article.publishedAt, order: .reverse)
    private var articles: [Article]

    var body: some View {
        List(articles) { article in
            VStack(alignment: .leading) {
                Text(article.title).font(.headline)
                Text(article.summary).font(.subheadline).lineLimit(2)
            }
        }
    }
}
```

Filtering uses a `#Predicate`. Because a `@Query`'s parameters can depend on
runtime state (a search term, a toggle), pass them through `init` and build the
descriptor there:

```swift
struct FilteredArticleList: View {
    @Query private var articles: [Article]

    init(searchText: String, bookmarkedOnly: Bool) {
        let predicate = #Predicate<Article> { article in
            (searchText.isEmpty || article.title.localizedStandardContains(searchText))
            && (!bookmarkedOnly || article.isBookmarked)
        }
        _articles = Query(
            filter: predicate,
            sort: [SortDescriptor(\.publishedAt, order: .reverse)]
        )
    }

    var body: some View {
        List(articles) { Text($0.title) }
    }
}
```

`#Predicate` compiles to a form SwiftData can push down to the store. Supported
operations include comparisons, boolean logic, `localizedStandardContains`,
`contains` on to-many relationships, and optional handling. Anything not
translatable throws at fetch time, so keep predicates to storable expressions —
don't call arbitrary Swift functions inside them.

### 2.2 Fetching in code with `FetchDescriptor`

Outside a view (services, actors, tests) use `context.fetch(_:)` with a
`FetchDescriptor`:

```swift
func recentBookmarks(in context: ModelContext, limit: Int = 20) throws -> [Article] {
    var descriptor = FetchDescriptor<Article>(
        predicate: #Predicate { $0.isBookmarked },
        sortBy: [SortDescriptor(\.publishedAt, order: .reverse)]
    )
    descriptor.fetchLimit = limit
    // Only hydrate the properties you need; relationships load lazily.
    descriptor.propertiesToFetch = [\.title, \.publishedAt]
    // Prefetch relationships you know you'll touch to avoid N+1.
    descriptor.relationshipKeyPathsForPrefetching = [\.comments]
    return try context.fetch(descriptor)
}
```

`fetchCount(_:)` returns a count without hydrating objects — cheap for badges
and "N results" labels:

```swift
let unread = try context.fetchCount(
    FetchDescriptor<Article>(predicate: #Predicate { !$0.isBookmarked })
)
```

### 2.3 Pagination

Use `fetchOffset` + `fetchLimit` for page-at-a-time reads:

```swift
func page(_ index: Int, size: Int, in context: ModelContext) throws -> [Article] {
    var d = FetchDescriptor<Article>(
        sortBy: [SortDescriptor(\.publishedAt, order: .reverse)]
    )
    d.fetchOffset = index * size
    d.fetchLimit = size
    return try context.fetch(d)
}
```

Offset paging is simple but gets slower deep into a large table and can skip or
repeat rows if data mutates between pages. For large, mutating datasets prefer
**keyset paging**: remember the sort value of the last row and predicate for
"strictly after" it.

```swift
func nextPage(after last: Article?, size: Int, in context: ModelContext) throws -> [Article] {
    let boundary = last?.publishedAt ?? Date.distantFuture
    var d = FetchDescriptor<Article>(
        predicate: #Predicate { $0.publishedAt < boundary },
        sortBy: [SortDescriptor(\.publishedAt, order: .reverse)]
    )
    d.fetchLimit = size
    return try context.fetch(d)
}
```

For very long lists in SwiftUI, `List` + `@Query` virtualizes rows efficiently;
add explicit paging only when the full result set is too large to hold or the
initial fetch is measurably slow.

---

## 3. Mutations & concurrency

### 3.1 Inserting, deleting, saving on the main actor

`@Model` objects are bound to a context; you insert, mutate, and delete through
it. From a view, read the environment's main-actor context:

```swift
struct AddArticleButton: View {
    @Environment(\.modelContext) private var context

    var body: some View {
        Button("Add") {
            let article = Article(
                remoteID: UUID().uuidString,
                title: "Untitled",
                summary: "",
                publishedAt: .now
            )
            context.insert(article)
            // With autosave on, an explicit save is optional, but calling it
            // makes error handling explicit at a known point.
            try? context.save()
        }
    }
}

func delete(_ article: Article, from context: ModelContext) {
    context.delete(article)
    try? context.save()
}
```

Bulk delete by predicate avoids hydrating objects:

```swift
try context.delete(
    model: Article.self,
    where: #Predicate { $0.publishedAt < cutoff }
)
```

### 3.2 Autosave

The environment's main-actor context has **autosave enabled** by default: it
saves on app lifecycle boundaries and periodically. Contexts you create by hand
default to autosave off — set `context.autosaveEnabled = true` or call `save()`
yourself. During a large batch import, turn autosave off and save once at the
end to avoid churn.

### 3.3 Background work with `ModelActor`

`@Model` objects are **not `Sendable`** — you must not pass a live model
instance across actor/thread boundaries. Do background work inside a
`ModelActor`, which owns its own `ModelContext` bound to a background executor:

```swift
import SwiftData

@ModelActor
actor ImportActor {
    func importArticles(_ payloads: [ArticleDTO]) throws {
        for dto in payloads {
            // Upsert: .unique on remoteID means insert-or-update.
            let article = Article(
                remoteID: dto.id,
                title: dto.title,
                summary: dto.summary,
                publishedAt: dto.publishedAt
            )
            modelContext.insert(article)
        }
        try modelContext.save()
    }
}
```

Construct it from the container (the `@ModelActor` macro synthesizes
`init(modelContainer:)`):

```swift
let importer = ImportActor(modelContainer: container)
try await importer.importArticles(dtos)
```

### 3.4 Passing identifiers across actors, not models

Because models aren't `Sendable`, hand a **`PersistentIdentifier`** across the
boundary and re-fetch on the other side. `PersistentIdentifier` is `Sendable`
and stable across contexts of the same store.

```swift
@ModelActor
actor ArticleEditor {
    func markBookmarked(_ id: PersistentIdentifier) throws {
        // Resolve the id into THIS actor's context.
        guard let article = self[id, as: Article.self] else { return }
        article.isBookmarked = true
        try modelContext.save()
    }
}

// Caller (e.g. main actor):
let id = article.persistentModelID          // Sendable
try await editor.markBookmarked(id)         // safe hand-off
```

`self[_:as:]` (the `ModelActor` subscript) fetches the object by id in the
actor's own context. Never capture the `article` reference itself in the
`Task`/actor call.

The main-actor equivalent, `@MainActor`-isolated, is available via the
`@MainActor` context you already have; to build a dedicated main-actor context
use `ModelContext(container)` on the main actor or the SwiftUI environment
context.

---

## 4. Migrations

When you change the shape of a model — add/remove/rename properties, change
uniqueness — you evolve the schema through **versioned schemas** and a
**migration plan**.

### 4.1 Versioned schemas

Each version is a `VersionedSchema` that lists the model types **as they existed
at that version**. In practice you keep the current model definitions and, for
older versions, typealias or snapshot the shape as needed.

```swift
import SwiftData

enum SchemaV1: VersionedSchema {
    static var versionIdentifier = Schema.Version(1, 0, 0)
    static var models: [any PersistentModel.Type] { [ArticleV1.self] }

    @Model
    final class ArticleV1 {
        @Attribute(.unique) var remoteID: String
        var title: String
        var body: String            // renamed to `summary` in V2
        var publishedAt: Date
        init(remoteID: String, title: String, body: String, publishedAt: Date) {
            self.remoteID = remoteID
            self.title = title
            self.body = body
            self.publishedAt = publishedAt
        }
    }
}

enum SchemaV2: VersionedSchema {
    static var versionIdentifier = Schema.Version(2, 0, 0)
    static var models: [any PersistentModel.Type] { [Article.self] }
    // `Article` here is the current definition (summary + isBookmarked, etc.)
}
```

### 4.2 The migration plan

A `SchemaMigrationPlan` lists the ordered schemas and the stages between them.
A **lightweight** stage covers additive/inferable changes (new optional
properties, new models, added indexes) with no code. A **custom** stage runs
`willMigrate`/`didMigrate` closures for transforms the framework can't infer
(renames with data copy, splitting/merging fields, backfilling).

```swift
enum ReaderMigrationPlan: SchemaMigrationPlan {
    static var schemas: [any VersionedSchema.Type] {
        [SchemaV1.self, SchemaV2.self]
    }

    static var stages: [MigrationStage] {
        [migrateV1toV2]
    }

    static let migrateV1toV2 = MigrationStage.custom(
        fromVersion: SchemaV1.self,
        toVersion: SchemaV2.self,
        willMigrate: nil,
        didMigrate: { context in
            // Backfill: copy old `body` into new `summary`, default bookmark.
            let articles = try context.fetch(FetchDescriptor<Article>())
            for article in articles where article.summary.isEmpty {
                article.summary = String(article.title.prefix(140))
            }
            try context.save()
        }
    )
}
```

For a purely additive change (e.g. adding `isBookmarked` with a default), use a
lightweight stage instead:

```swift
static let migrateV1toV2 = MigrationStage.lightweight(
    fromVersion: SchemaV1.self,
    toVersion: SchemaV2.self
)
```

Pass the plan to the container (`migrationPlan: ReaderMigrationPlan.self`, as in
§1.2). SwiftData opens the store, detects the on-disk version, and runs the
stages in order to reach the current schema. Guidelines:

- New models and new **optional** properties are lightweight-safe.
- New **non-optional** properties need a default value to be lightweight-safe.
- Renames, type changes, and merges/splits need a custom stage.
- Always test migrations against a copy of a real old store before shipping.

---

## 5. Offline-first: SwiftData as local cache + sync service

The pattern: SwiftData is the **single source of truth for the UI**. A sync
service fetches from the network over `URLSession`, decodes DTOs, and **upserts**
into the store on a background `ModelActor`. The UI never talks to the network
directly — it observes the store via `@Query`, so it renders instantly from
cache and updates the moment sync writes land.

```
   URLSession → decode DTO → ModelActor.upsert() → SwiftData store
                                                        │
                                          @Query (SwiftUI) / observation stream
                                                        ↓
                                                    live UI
```

### 5.1 DTOs and the sync service

Keep wire types (`Codable` DTOs) separate from `@Model` types. The service
depends only on the container.

```swift
struct ArticleDTO: Codable, Sendable {
    let id: String
    let title: String
    let summary: String
    let publishedAt: Date
}

@ModelActor
actor SyncActor {
    func upsert(_ dtos: [ArticleDTO]) throws {
        for dto in dtos {
            // `.unique` on remoteID makes insert act as upsert: an existing
            // row with the same remoteID is updated in place.
            let existing = try modelContext.fetch(
                FetchDescriptor<Article>(
                    predicate: #Predicate { $0.remoteID == dto.id }
                )
            ).first

            if let existing {
                existing.title = dto.title
                existing.summary = dto.summary
                existing.publishedAt = dto.publishedAt
            } else {
                modelContext.insert(
                    Article(
                        remoteID: dto.id,
                        title: dto.title,
                        summary: dto.summary,
                        publishedAt: dto.publishedAt
                    )
                )
            }
        }
        try modelContext.save()
    }
}

struct SyncService {
    let container: ModelContainer
    let session: URLSession = .shared
    let endpoint = URL(string: "https://api.example.com/v1/articles")!

    func refresh() async throws {
        let (data, response) = try await session.data(from: endpoint)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let dtos = try decoder.decode([ArticleDTO].self, from: data)

        let sync = SyncActor(modelContainer: container)
        try await sync.upsert(dtos)     // background write; UI updates via @Query
    }
}
```

Trigger `refresh()` on launch, on foreground, on pull-to-refresh, and on a timer
or push. Because reads go through `@Query`, the view stays on cached data if the
network is down and reconciles automatically when a sync succeeds. (For request
auth headers and token handling, see `networking.md`.)

### 5.2 Exposing changes to non-SwiftUI code

`@Query` only works inside SwiftUI views. For a view model, coordinator, or
service that needs to react to store changes, poll on a schedule or expose an
`AsyncStream` you feed after each successful write. A pragmatic approach: have
the sync layer publish "did-change" signals and let observers re-fetch.

```swift
actor ArticleStore {
    private let container: ModelContainer
    private var continuations: [UUID: AsyncStream<[Article.Snapshot]>.Continuation] = [:]

    init(container: ModelContainer) { self.container = container }

    // Snapshots are Sendable value copies — safe to send across actors,
    // unlike the @Model objects themselves.
    func changes() -> AsyncStream<[Article.Snapshot]> {
        AsyncStream { continuation in
            let id = UUID()
            continuations[id] = continuation
            continuation.onTermination = { _ in
                Task { await self.removeContinuation(id) }
            }
        }
    }

    private func removeContinuation(_ id: UUID) { continuations[id] = nil }

    // Called by the sync layer after a successful upsert.
    func notifyChanged() async {
        let snapshots = await currentSnapshots()
        for continuation in continuations.values {
            continuation.yield(snapshots)
        }
    }

    @MainActor
    private func currentSnapshots() -> [Article.Snapshot] {
        let ctx = ModelContext(container)
        let articles = (try? ctx.fetch(
            FetchDescriptor<Article>(sortBy: [SortDescriptor(\.publishedAt, order: .reverse)])
        )) ?? []
        return articles.map(Article.Snapshot.init)
    }
}

extension Article {
    // A plain, Sendable value type to carry data out of the store.
    struct Snapshot: Sendable, Identifiable {
        let id: String
        let title: String
        let summary: String
        let publishedAt: Date
        init(_ a: Article) {
            id = a.remoteID; title = a.title
            summary = a.summary; publishedAt = a.publishedAt
        }
    }
}
```

The rule that makes this safe: **only value snapshots or `PersistentIdentifier`
cross actor boundaries — never a live `@Model` instance.**

---

## 6. App Group sharing (widget reads the same store)

To let a widget (or an extension) read the same data, put the store in a shared
**App Group** container and point every process's `ModelConfiguration` at that
URL. Both the app target and the widget extension must have the App Group
capability `group.com.example.app` enabled.

Define one shared container factory used by all targets:

```swift
import SwiftData
import Foundation

enum SharedStore {
    static let appGroupID = "group.com.example.app"

    static let container: ModelContainer = {
        guard let groupURL = FileManager.default
            .containerURL(forSecurityApplicationGroupIdentifier: appGroupID)
        else {
            fatalError("App Group \(appGroupID) is not configured")
        }
        let storeURL = groupURL.appending(path: "Reader.store")

        let schema = Schema([Article.self, Comment.self])
        let config = ModelConfiguration(
            schema: schema,
            url: storeURL          // <-- shared location, both targets read/write
        )
        do {
            return try ModelContainer(for: schema, configurations: [config])
        } catch {
            fatalError("Failed to open shared store: \(error)")
        }
    }()
}
```

App target:

```swift
@main
struct ReaderApp: App {
    var body: some Scene {
        WindowGroup { RootView() }
            .modelContainer(SharedStore.container)
    }
}
```

Widget target (read-only fetch in the timeline provider):

```swift
import WidgetKit
import SwiftData

struct LatestArticleProvider: TimelineProvider {
    func getTimeline(in context: Context, completion: @escaping (Timeline<ArticleEntry>) -> Void) {
        let ctx = ModelContext(SharedStore.container)
        var descriptor = FetchDescriptor<Article>(
            sortBy: [SortDescriptor(\.publishedAt, order: .reverse)]
        )
        descriptor.fetchLimit = 1
        let latest = (try? ctx.fetch(descriptor))?.first

        let entry = ArticleEntry(date: .now, title: latest?.title ?? "No articles")
        completion(Timeline(entries: [entry], policy: .after(.now.addingTimeInterval(1800))))
    }

    func placeholder(in: Context) -> ArticleEntry { ArticleEntry(date: .now, title: "…") }
    func getSnapshot(in: Context, completion: @escaping (ArticleEntry) -> Void) {
        completion(ArticleEntry(date: .now, title: "Preview"))
    }
}

struct ArticleEntry: TimelineEntry { let date: Date; let title: String }
```

Notes:

- The app writes; the widget should generally treat the store as **read-only**
  to avoid write contention. Call `WidgetCenter.shared.reloadAllTimelines()`
  from the app after a sync so the widget re-fetches.
- The main app's `ModelConfiguration` must use the **same** `url` — don't let
  the app default to its sandbox `Application Support` while the widget reads
  the group URL, or they'll be two different stores.

---

## 7. When to use Core Data instead of SwiftData

**Default to SwiftData for new apps.** It's less code, type-safe, and the
concurrency story (`ModelActor`, `PersistentIdentifier`) is designed for Swift
6. Reach for Core Data directly only when you hit a specific need SwiftData
doesn't yet cover cleanly:

- **`NSFetchedResultsController`-grade sectioning/change granularity** driving a
  large `UITableView`/`UICollectionView` in UIKit with precise per-row diffs.
- **Advanced predicates/expressions** (aggregate `NSExpression`, complex
  subqueries) that don't translate through `#Predicate`.
- **Fine-grained store control** — multiple stores with custom configurations,
  store-level encryption options, or migration mapping models you already own.
- **Existing Core Data codebase** you're extending rather than rewriting.

SwiftData and Core Data share the same underlying storage, and you can bridge:
expose a `NSManagedObjectModel` / `NSPersistentContainer` alongside a
`ModelContainer` over the same schema when you need one Core Data-only feature.
Prefer not to run both write paths against one store simultaneously.

Minimal Core Data stack for reference (only if you deliberately choose it):

```swift
import CoreData

final class LegacyStack {
    let container: NSPersistentContainer

    init(modelName: String = "Reader") {
        container = NSPersistentContainer(name: modelName)
        container.loadPersistentStores { _, error in
            if let error { fatalError("Core Data load failed: \(error)") }
        }
        container.viewContext.automaticallyMergesChangesFromParent = true
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
    }

    func newBackgroundContext() -> NSManagedObjectContext {
        container.newBackgroundContext()
    }
}
```

Recommendation stands: **new app → SwiftData.** Only add Core Data for a
concrete capability gap, and isolate it behind a small interface.

---

## 8. Other stores

Not everything belongs in the database. Match the store to the data.

### 8.1 `UserDefaults` / `@AppStorage` — small preferences

For a handful of small, non-sensitive values (last selected tab, sort order, a
feature toggle). Use `@AppStorage` in SwiftUI for a two-way bound value:

```swift
struct SettingsView: View {
    @AppStorage("sortNewestFirst") private var newestFirst = true
    @AppStorage("preferredTextSize") private var textSize = 1.0

    var body: some View {
        Form {
            Toggle("Newest first", isOn: $newestFirst)
            Slider(value: $textSize, in: 0.8...1.6)
        }
    }
}
```

To share prefs with the widget, use the App Group suite:

```swift
extension UserDefaults {
    static let shared = UserDefaults(suiteName: "group.com.example.app")!
}
// SwiftUI: @AppStorage("key", store: .shared)
```

Do **not** put large blobs, arrays of records, or anything you query in
`UserDefaults` — that's what SwiftData is for.

### 8.2 Keychain — secrets

API tokens, refresh tokens, and any credential go in the **Keychain**, never in
`UserDefaults` or the SwiftData store. Store the minimum, mark items with an
appropriate accessibility class, and use an access group tied to the App Group
if a widget/extension needs the same token. Full token lifecycle, access
groups, and the `Security` framework wrappers are covered in `networking.md` —
cross-reference it rather than duplicating here.

### 8.3 Files in the app container

For user documents, exported files, downloaded media, and caches, write to the
app's container directories:

```swift
let fm = FileManager.default

// Backed up, user-visible-ish data:
let docs = try fm.url(for: .documentDirectory, in: .userDomainMask,
                      appropriateFor: nil, create: true)

// Purgeable cache — the system may evict this under pressure:
let caches = try fm.url(for: .cachesDirectory, in: .userDomainMask,
                        appropriateFor: nil, create: true)

let fileURL = docs.appending(path: "export.json")
try jsonData.write(to: fileURL, options: .atomic)
```

Guidance: keep structured, queryable state in SwiftData; keep opaque bytes
(images, PDFs, downloads) as files and store only the relative path (or use
`@Attribute(.externalStorage)` to let SwiftData manage the sidecar). Use
`.cachesDirectory` for anything you can regenerate, `.documentDirectory` for
data the user would miss if it vanished, and exclude large regenerable files
from backup with `URLResourceValues.isExcludedFromBackup`.

---

## 9. Coming soon (not in the iOS 26 baseline)

Several SwiftData additions were previewed at WWDC 2026 and are **targeted at
Apple's 2027 OS releases (iOS 27), not the iOS 26 SDK this app builds against.**
Treat the following as **future** APIs — design around today's baseline and
adopt them behind availability checks once those releases ship:

- **Sectioned queries** — a `@Query(sectionBy:)`-style form that returns results
  pre-grouped into sections, removing hand-rolled grouping for sectioned lists.
- **`@Attribute(.codable)`** — first-class storage of arbitrary `Codable` value
  types as a single attribute, without a manual transformer.
- **`ResultsObserver`** — a non-SwiftUI observation type for live query results,
  giving view models and services the reactivity `@Query` gives views today
  (superseding the manual `AsyncStream` bridge in §5.2 when available).
- **`HistoryObserver`** — a streamlined API over persistent history for
  observing the transaction log (inserts/updates/deletes) across processes.

None of these are available on iOS 26. Do not present them as usable now; the
patterns in §5 (background `ModelActor` upserts + `@Query` for the UI + snapshot
streams for non-UI code) are the correct approach on the current baseline, and
they migrate cleanly to `ResultsObserver`/`HistoryObserver` later.

---

## Checklist

- Model domain types with `@Model`; give server-sourced rows a unique key
  (`@Attribute(.unique)` / `#Unique`) and index hot query paths (`#Index`).
- Install one `ModelContainer` at the App level with `.modelContainer(…)`.
- Read with `@Query` in views; `FetchDescriptor` + `fetch`/`fetchCount` in code.
- Never cross an actor boundary with a live `@Model` — pass
  `PersistentIdentifier` or a `Sendable` snapshot and re-fetch.
- Do network sync on a `@ModelActor`, upsert by unique key, let `@Query`
  propagate changes to the UI (offline-first).
- Version the schema and ship a `SchemaMigrationPlan` (lightweight when
  additive, custom when transforming).
- Share the store via an App Group URL (`group.com.example.app`) for widgets.
- Small prefs → `UserDefaults`/`@AppStorage`; secrets → Keychain (see
  `networking.md`); opaque bytes → files/`.externalStorage`.
- Prefer SwiftData for new work; reach for Core Data only for a concrete gap.
