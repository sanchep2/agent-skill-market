---
name: ios-native
description: Build modern, standalone native iOS apps in pure Swift — SwiftUI (including Liquid Glass), TCA and/or MVVM architecture, async/await + actors, URLSession networking with Codable, SwiftData persistence, NavigationStack and deep links, WidgetKit widgets, Live Activities / Dynamic Island, and Swift Testing + snapshot testing. Use this skill whenever building iOS screens, views, features, navigation, a networking or persistence layer, widgets, Live Activities, or tests for a self-contained iOS app. Triggers on any iOS/SwiftUI/Swift development including feature creation, UI composition, state management (TCA reducers or @Observable view models), navigation flows, HTTP clients, local databases, widget extensions, Dynamic Island, and testing. Also use when the user asks about Liquid Glass, NavigationStack patterns, Swift 6 concurrency, SwiftData migrations, Keychain, Kingfisher/Nuke image loading, or any iOS architecture decision.
---

# iOS Native — modern standalone iOS apps in pure Swift

This skill builds **self-contained native iOS apps**. Everything — UI, state, networking, persistence, navigation, widgets, testing — lives in Swift. There is no shared cross-language backend and no external build system to satisfy; the app owns its full stack.

Load `SKILL.md` (this file) for the stack, version baseline, architecture decision and a quick start. Pull a `references/*.md` file only when you need depth in that area (progressive disclosure).

## Version matrix

**All versions and APIs verified against Apple's official documentation and the Swift Package Index on July 5, 2026.** Apple uses year-aligned versioning since WWDC 2025 (iOS 26, Xcode 26). Always re-confirm the latest stable release on your own date before pinning.

| Component | Version | Notes |
|-----------|---------|-------|
| Swift | **6.3.3** | Bundled with Xcode 26.6; strict concurrency, Approachable Concurrency |
| Xcode | **26.6** | Released 2026-06-25 |
| iOS SDK | **26** (26.5) | iOS 26 SDK mandatory for App Store submissions since 2026-04-28 |
| Deployment target (recommended min) | **iOS 18** | Liquid Glass and some SwiftData/observation APIs require iOS 26.0+ — gate with `if #available` |
| Swift Testing | Ships with Xcode 26 | `import Testing`; `@Suite`/`@Test`/`#expect` |
| The Composable Architecture (TCA) | **1.26.0** | `@Reducer`, `@ObservableState`, `@DependencyClient` (2026-06-09) |
| Kingfisher | **8.10.0** | Async image loading + caching (2026-06-12) |
| Nuke | **13.0.6** | Alternative image loading system (2026-05-07) |
| swift-snapshot-testing | **1.19.2** | Swift Testing support (2026-03-30) |

Third-party libraries are consumed via **Swift Package Manager**. CocoaPods goes read-only on 2026-12-02, so prefer SPM for all dependencies.

## The native iOS stack

| Concern | Choice | Reference |
|---------|--------|-----------|
| UI | SwiftUI (+ Liquid Glass on iOS 26) | `references/swiftui.md` |
| Architecture | TCA (scalable) or MVVM with `@Observable` (lightweight) | `references/architecture.md` |
| Concurrency | Swift 6 async/await, actors, `@Observable`, `Sendable` | `references/swiftui.md` |
| Networking | `URLSession` async + `Codable`, own client, Keychain auth | `references/networking.md` |
| Persistence | SwiftData (`@Model`, `@Query`); Core Data when needed | `references/persistence.md` |
| Navigation | `NavigationStack`, state-driven routing, deep/universal links | `references/navigation.md` |
| Images | Kingfisher or Nuke (never bare `AsyncImage` for lists) | `references/swiftui.md` |
| Widgets / Live Activities | WidgetKit, AppIntents, ActivityKit, Dynamic Island | `references/platform-features.md` |
| Testing | Swift Testing, TCA `TestStore`, snapshots, XCUITest | `references/testing.md` |

## Architecture decision: TCA vs. MVVM

Both are valid for a standalone app — pick per feature, not per app.

- **The Composable Architecture (TCA)** — a single, testable state container with explicit actions, a `Reducer`, and a controlled effect/dependency system. Reach for it when a feature has real side effects, shared/derived state, complex navigation, or you want exhaustive tests. State lives in `@ObservableState`, effects run through `.run`, and every dependency is injected via `@Dependency`, backed in production by native services (a `URLSession` client, a SwiftData store).
- **MVVM with `@Observable`** — a plain `@Observable final class ViewModel` calling native services with async/await, wired to the view with `@State`/`@Bindable`. Reach for it for simpler screens, prototypes, or when TCA's ceremony isn't earning its keep.

Do **not** use `ObservableObject` for new shared state — prefer `@Observable` (Observation framework, iOS 17+). See `references/architecture.md` for a full comparison, a TCA feature example, and a standalone MVVM example.

## Recommended project structure

A native app organizes by feature, with clear seams for networking and persistence:

```
SampleApp/
├── SampleApp.swift            # @main App, composition root (dependency wiring, root store/view)
├── Features/
│   └── Feed/
│       ├── FeedFeature.swift  # TCA @Reducer  (or FeedViewModel.swift for MVVM)
│       └── FeedView.swift     # SwiftUI view
├── Networking/
│   ├── APIClient.swift        # URLSession-backed client (async/await, Codable)
│   ├── Endpoint.swift         # request builder
│   └── KeychainStore.swift    # secure token storage
├── Persistence/
│   ├── Models/                # @Model types (SwiftData)
│   └── Store.swift            # ModelContainer / ModelActor
├── DesignSystem/              # semantic colors, typography, reusable views
└── SampleWidget/              # WidgetKit extension (shares an App Group container)
```

There is no separate DI framework requirement: the composition root wires dependencies explicitly (or via TCA's `@Dependency` registry). Keep domain models defined in Swift.

## Quick start — a TCA feature backed by a native URLSession client

```swift
import ComposableArchitecture
import SwiftUI

// Domain model — plain Swift, Sendable, Codable.
struct FeedItem: Identifiable, Equatable, Codable, Sendable {
    let id: UUID
    let title: String
}

// Dependency: production value calls URLSession; test/preview values are trivial.
@DependencyClient
struct APIClient {
    var fetchFeed: @Sendable () async throws -> [FeedItem]
}

extension APIClient: DependencyKey {
    static let liveValue = APIClient(
        fetchFeed: {
            let url = URL(string: "https://api.example.com/feed")!
            let (data, response) = try await URLSession.shared.data(from: url)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else {
                throw URLError(.badServerResponse)
            }
            return try JSONDecoder().decode([FeedItem].self, from: data)
        }
    )
}
extension DependencyValues {
    var apiClient: APIClient {
        get { self[APIClient.self] }
        set { self[APIClient.self] = newValue }
    }
}

@Reducer
struct FeedFeature {
    @ObservableState
    struct State: Equatable {
        var items: [FeedItem] = []
        var isLoading = false
    }
    enum Action { case task, feedResponse(Result<[FeedItem], Error>) }

    @Dependency(\.apiClient) var apiClient

    var body: some ReducerOf<Self> {
        Reduce { state, action in
            switch action {
            case .task:
                state.isLoading = true
                return .run { send in
                    await send(.feedResponse(Result { try await apiClient.fetchFeed() }))
                }
            case let .feedResponse(.success(items)):
                state.isLoading = false
                state.items = items
                return .none
            case .feedResponse(.failure):
                state.isLoading = false
                return .none
            }
        }
    }
}

struct FeedView: View {
    let store: StoreOf<FeedFeature>
    var body: some View {
        NavigationStack {
            List(store.items) { item in Text(item.title) }
                .overlay { if store.isLoading { ProgressView() } }
                .navigationTitle("Feed")
                .task { store.send(.task) }
        }
    }
}
```

The same screen in MVVM (`@Observable` view model calling a native service) is in `references/architecture.md`.

## When to load which reference

| You are working on… | Load |
|----------------------|------|
| SwiftUI views, Liquid Glass, animations, layout, concurrency idioms | `references/swiftui.md` |
| TCA reducers/effects/navigation, shared state, or MVVM view models | `references/architecture.md` |
| An HTTP client, Codable models, auth tokens, Keychain | `references/networking.md` |
| Local database, `@Query`, migrations, offline-first | `references/persistence.md` |
| `NavigationStack`, routing, deep links, universal links | `references/navigation.md` |
| Widgets, Live Activities, Dynamic Island, push | `references/platform-features.md` |
| Swift Testing, `TestStore`, mocking, snapshots, CI | `references/testing.md` |

## Antipatterns

- **AP-1** — `ObservableObject` for new shared state. Use `@Observable` (or `@ObservableState` in TCA).
- **AP-2** — Network calls from a view `body`. Do work in `.task` / an effect / a view model method.
- **AP-3** — Ignoring Swift 6 strict concurrency. Make crossing types `Sendable`; do UI work on `@MainActor`.
- **AP-4** — `List`/`VStack` for large collections without laziness. Use `List`/`LazyVStack`/`LazyVGrid` appropriately.
- **AP-5** — Hardcoding colors instead of semantic tokens; breaks dark mode and Liquid Glass.
- **AP-6** — Forgetting `.task` cancellation; long work should honor cooperative cancellation.
- **AP-7** — Reaching for a heavy architecture on a throwaway screen. Match the tool to the feature.
- **AP-8** — Bare `AsyncImage` in scrolling lists. Use Kingfisher/Nuke for caching and cancellation.
