# Architecture Patterns Reference

## Table of Contents
1. [Tenant Management](#tenant-management)
2. [Queue-Based Sending](#queue-based-sending)
3. [Cross-Account Sending Authorization](#cross-account-sending-authorization)
4. [Multi-Region with Global Endpoints](#multi-region-with-global-endpoints)
5. [Templates and Personalization](#templates-and-personalization)
6. [Email Validation Integration](#email-validation-integration)
7. [Virtual Deliverability Manager](#virtual-deliverability-manager)

---

## Tenant Management

Launched August 2025. Native multi-tenant isolation with independent reputation metrics and automated enforcement.

### Creating and Managing Tenants

```python
ses = boto3.client('sesv2')

# Create a tenant
ses.create_multi_region_endpoint(...)  # Different API

# Tenant operations use dedicated APIs:
# CreateTenant, GetTenant, ListTenants, UpdateTenant, DeleteTenant

# Example tenant creation
ses.create_tenant(
    TenantName='customer-alpha',
    Tags=[{'Key': 'customer_id', 'Value': 'alpha-123'}]
)
```

### Tenant Architecture

```
[SES Account]
├── Tenant: customer-alpha
│   ├── Identity: mail.alpha.example.com
│   ├── Config Set: cfg-alpha
│   │   ├── IP Pool: alpha-pool (managed)
│   │   ├── Event Destination: alpha-events → EventBridge
│   │   └── Suppression: bounces only (transactional)
│   └── Reputation Policy: auto-pause on high-severity
│
├── Tenant: customer-beta
│   ├── Identity: mail.beta.example.com
│   ├── Config Set: cfg-beta
│   │   ├── IP Pool: shared-marketing (managed)
│   │   └── Suppression: bounces + complaints
│   └── Reputation Policy: auto-pause on any finding
│
└── Shared Resources
    ├── IP Pool: shared-transactional (standard dedicated)
    └── Templates: shared template library
```

### Sending with Tenant Attribution

**API:**
```python
ses.send_email(
    FromEmailAddress='noreply@mail.alpha.example.com',
    Destination={'ToAddresses': ['user@gmail.com']},
    Content={'Simple': {...}},
    ConfigurationSetName='cfg-alpha'
    # Tenant is inferred from the configuration set + identity combination
)
```

**SMTP:**
Add `X-SES-TENANT: customer-alpha` header to attribute the send to a specific tenant.

### Tenant Reputation Policies

Each tenant can have independent pause policies:
- **Standard**: Auto-pause on high-severity findings (bounce > 10%, complaint > 0.5%)
- **Strict**: Auto-pause on any finding (bounce > 5%, complaint > 0.1%)
- **Custom**: Set your own thresholds
- **None**: No auto-pause (you handle enforcement externally)

EventBridge notifications fire on tenant status changes, enabling automated responses.

### Limits and Pricing
- Up to 10,000 tenants per account (expandable to 300,000)
- $0.005/month per tenant
- $0.005 per 1,000 emails attributed to a tenant

---

## Queue-Based Sending

For high-volume sending that exceeds SES per-second rate limits or needs to absorb traffic spikes.

### SQS + Lambda Architecture

```
[Email Producers]
    │
    ▼
[SQS Queue (Standard)]  ←── Dead Letter Queue (3 retries)
    │
    ▼
[Lambda Consumer]
    │ maxConcurrency = ceil(SES_RATE_LIMIT / EMAILS_PER_INVOCATION)
    │ batchSize = 10
    │ maxBatchingWindow = 5s
    ▼
[SES v2 SendEmail / SendBulkEmail]
```

```python
# Lambda consumer for SQS → SES
import json
import boto3
import time

ses = boto3.client('sesv2')
MAX_SEND_RATE = 14  # Your account's per-second limit

def handler(event, context):
    for i, record in enumerate(event['Records']):
        message = json.loads(record['body'])

        try:
            ses.send_email(
                FromEmailAddress=message['from'],
                Destination={'ToAddresses': [message['to']]},
                Content=message['content'],
                ConfigurationSetName=message.get('config_set', 'default')
            )
        except ses.exceptions.MessageRejected as e:
            # Don't retry rejected messages
            print(f"Rejected: {e}")
        except ses.exceptions.TooManyRequestsException:
            # Throttled — raise to trigger SQS retry with backoff
            raise

        # Rate limiting within the batch
        if i < len(event['Records']) - 1:
            time.sleep(1.0 / MAX_SEND_RATE)
```

### ECS Fargate for Long-Running Batch Jobs

For sending campaigns > 100K emails where Lambda's 15-minute timeout is insufficient:

```python
# Fargate task: reads from SQS, sends via SES with rate limiting
import boto3
import json

ses = boto3.client('sesv2')
sqs = boto3.client('sqs')
QUEUE_URL = 'https://sqs.us-east-1.amazonaws.com/123456789012/email-queue'
SEND_RATE = 14  # per second
```

See `sending-patterns.md` → Rate Limiting for the token bucket implementation.

```python
from rate_limiter import TokenBucket  # or inline from sending-patterns.md

limiter = TokenBucket(SEND_RATE)

while True:
    response = sqs.receive_message(
        QueueUrl=QUEUE_URL,
        MaxNumberOfMessages=10,
        WaitTimeSeconds=20
    )

    messages = response.get('Messages', [])
    if not messages:
        continue

    for msg in messages:
        limiter.wait_and_acquire()
        body = json.loads(msg['Body'])
        try:
            ses.send_email(**body['ses_params'])
            sqs.delete_message(QueueUrl=QUEUE_URL, ReceiptHandle=msg['ReceiptHandle'])
        except Exception as e:
            print(f"Error: {e}")
            # Message returns to queue after visibility timeout
```

---

## Cross-Account Sending Authorization

Enables Account B (delegate) to send using Account A's (owner) verified domain.

### Owner: Create Authorization Policy

```python
# Account A (identity owner)
ses_owner = boto3.client('sesv2')

policy = {
    "Version": "2012-10-17",
    "Statement": [{
        "Sid": "AllowPartnerSending",
        "Effect": "Allow",
        "Resource": "arn:aws:ses:us-east-1:888888888888:identity/example.com",
        "Principal": {"AWS": ["arn:aws:iam::123456789012:root"]},
        "Action": ["ses:SendEmail", "ses:SendRawEmail"],
        "Condition": {
            "StringEquals": {
                "ses:FromAddress": ["partner@example.com", "noreply@example.com"]
            }
        }
    }]
}

ses_owner.create_email_identity_policy(
    EmailIdentity='example.com',
    PolicyName='partner-sending',
    Policy=json.dumps(policy)
)
```

### Delegate: Send Using Owner's Identity

```python
# Account B (delegate sender)
ses_delegate = boto3.client('sesv2')

ses_delegate.send_email(
    FromEmailAddress='partner@example.com',
    # Must specify the owner's identity ARN as the source
    FromEmailAddressIdentityArn='arn:aws:ses:us-east-1:888888888888:identity/example.com',
    Destination={'ToAddresses': ['user@gmail.com']},
    Content={'Simple': {
        'Subject': {'Data': 'Hello from partner'},
        'Body': {'Text': {'Data': 'Sent via delegated authorization'}}
    }},
    ConfigurationSetName='partner-config'  # Delegate's config set
)
```

**Key behavior:** Bounces and complaints count against the **delegate's** account. DKIM signing uses the **owner's** keys.

---

## Multi-Region with Global Endpoints

Launched December 2024. Automatic failover across two AWS regions.

### Setup

```python
ses = boto3.client('sesv2', region_name='us-east-1')

# Create global endpoint
ses.create_multi_region_endpoint(
    EndpointName='production-global',
    Details={
        'RoutesDetails': [
            {'Region': 'us-east-1'},
            {'Region': 'eu-west-1'}
        ]
    }
)
```

### Combined with Deterministic Easy DKIM

DEED + Global Endpoints = the ideal multi-region setup:
1. Create identity with DEED in both regions — same DNS records
2. Create Global Endpoint spanning both regions
3. Single MAIL FROM configuration works across regions
4. SES automatically routes and fails over

### Cost

Global Endpoints add $0.03 per 1,000 emails on top of standard sending costs.

---

## Templates and Personalization

### Stored Templates

```python
ses.create_email_template(
    TemplateName='order-confirmation',
    TemplateContent={
        'Subject': 'Order #{{order_id}} confirmed',
        'Html': '<h1>Thanks {{name}}!</h1><p>Your order #{{order_id}} has been confirmed.</p>',
        'Text': 'Thanks {{name}}! Your order #{{order_id}} has been confirmed.'
    }
)

# Send with template
ses.send_email(
    FromEmailAddress='orders@tx.example.com',
    Destination={'ToAddresses': ['user@gmail.com']},
    Content={
        'Template': {
            'TemplateName': 'order-confirmation',
            'TemplateData': json.dumps({
                'name': 'Raul',
                'order_id': 'TL-2026-001'
            })
        }
    },
    ConfigurationSetName='transactional-critical'
)
```

### Inline Templates (No Pre-Creation Needed)

```python
ses.send_email(
    FromEmailAddress='news@mktg.example.com',
    Destination={'ToAddresses': ['user@gmail.com']},
    Content={
        'Template': {
            'TemplateContent': {
                'Subject': 'Weekly Update for {{name}}',
                'Html': '<h1>Hi {{name}}</h1><p>{{content}}</p>',
                'Text': 'Hi {{name}}\n\n{{content}}'
            },
            'TemplateData': json.dumps({
                'name': 'Raul',
                'content': 'Here are this week\'s highlights...'
            })
        }
    }
)
```

Inline templates don't count against the 20,000 stored template limit and support up to 1 MB input JSON.

---

## Email Validation Integration

Launched December 2025. Two modes: API-based and automatic.

### API Validation (Pre-Send)

```python
# Validate before adding to send queue
result = ses.get_email_address_insights(EmailAddress='user@example.com')

risk = result['Insights']['Risk']
# Risk levels: LOW, MEDIUM, HIGH

if risk == 'HIGH':
    print("Skip sending — high risk address")
elif risk == 'MEDIUM':
    print("Send with caution — monitor for bounce")
else:
    print("Safe to send")
```

### Automatic Validation (At Send Time)

Enable at account or configuration set level. SES automatically checks recipients and blocks risky addresses.

```python
# Enable at configuration set level
ses.put_configuration_set_email_validation(
    ConfigurationSetName='marketing-config',
    EmailValidation={
        'ValidationMode': 'AUTOMATIC',
        'AutoValidationThreshold': 'MEDIUM'  # Block MEDIUM and HIGH risk
    }
)
```

### Pricing
- API validation: $0.01 per validation
- Auto validation: $0.01 per 1,000 validations

---

## Virtual Deliverability Manager

### Enabling VDM

```python
ses.put_account_vdm_attributes(
    VdmAttributes={
        'VdmEnabled': 'ENABLED',
        'DashboardAttributes': {'EngagementMetrics': 'ENABLED'},
        'GuardianAttributes': {'OptimizedSharedDelivery': 'ENABLED'}
    }
)
```

### Per-Configuration-Set Override

Disable optimized delivery for time-sensitive transactional email:

```python
ses.put_configuration_set_vdm_options(
    ConfigurationSetName='transactional-critical',
    VdmOptions={
        'DashboardOptions': {'EngagementMetrics': 'ENABLED'},
        'GuardianOptions': {'OptimizedSharedDelivery': 'DISABLED'}
        # Disable optimized delivery to avoid preemptive delays
    }
)
```

### Querying VDM Metrics

```python
# Get ISP-level delivery metrics
from datetime import datetime, timedelta

metrics = ses.batch_get_metric_data(
    Queries=[{
        'Id': 'gmail-delivery-rate',
        'Namespace': 'VDM',
        'Metric': 'DELIVERY',
        'Dimensions': {'ISP': 'GMAIL'},
        'StartDate': datetime.now() - timedelta(days=7),
        'EndDate': datetime.now()
    }]
)
```

### VDM Advisor Recommendations

Check regularly for:
- DKIM key length warnings (upgrade to 2048-bit)
- Missing BIMI records
- Custom MAIL FROM not configured
- High bounce/complaint rates by ISP
- Authentication failures
- Suppression list gaps
