# IP Management Reference

## Table of Contents
1. [IP Type Comparison](#ip-type-comparison)
2. [Shared IPs](#shared-ips)
3. [Standard Dedicated IPs](#standard-dedicated-ips)
4. [Managed Dedicated IPs](#managed-dedicated-ips)
5. [IP Pools](#ip-pools)
6. [IP Warm-Up](#ip-warm-up)
7. [Reputation Monitoring](#reputation-monitoring)
8. [Cost Analysis by Volume](#cost-analysis-by-volume)

---

## IP Type Comparison

| Feature | Shared | Standard Dedicated | Managed Dedicated |
|---|---|---|---|
| Cost | $0 | $24.95/mo per IP | $15/mo + $0.02–$0.08/1K |
| Warm-up | None needed | Manual or auto (45 days) | Automatic per-ISP |
| Reputation control | None | Full | AWS-managed + observable |
| Scaling | Automatic | Add IPs manually | Auto-scales |
| Pool assignment | N/A | Yes | Yes |
| SNDS registration | No | Yes | Yes (Oct 2025+) |
| IP visibility | No | Yes | Yes (Oct 2025+) |
| Best for | < 50K/mo, variable volume | Predictable high volume, full control | > 500K/mo, operational simplicity |

---

## Shared IPs

Default for all SES accounts. No cost, no configuration. SES manages the shared pool reputation by enforcing sending policies across all users.

**Advantages:**
- Zero setup and warm-up
- SES absorbs the reputation management burden
- Good for low/variable volume senders
- VDM Optimized Shared Delivery selects optimal IPs per send

**Disadvantages:**
- No control over IP reputation
- Cannot register with Microsoft SNDS or Google Postmaster Tools at IP level
- Other senders' behavior affects your deliverability
- Some enterprise receivers block shared IP ranges

**When to use:** Volume < 50K/month, unpredictable send patterns, testing/development, non-critical email streams.

---

## Standard Dedicated IPs

You lease specific IP addresses exclusively for your sending. Full control over reputation.

### Provisioning

```python
ses = boto3.client('sesv2')

# Request a dedicated IP
# Done through AWS Support or console — not directly via API
# After provisioning, IPs appear in your account

# List your dedicated IPs
response = ses.get_dedicated_ips()
for ip in response['DedicatedIps']:
    print(f"IP: {ip['Ip']}, Pool: {ip['PoolName']}, Warmup: {ip['WarmupStatus']}")
```

### How Many IPs Do You Need

| Monthly Volume | Recommended IPs | Rationale |
|---|---|---|
| 50K–200K | 1 | Minimum viable for reputation building |
| 200K–500K | 1–2 | Redundancy for warm-up period |
| 500K–2M | 2–3 | Distribute across ISPs |
| 2M–10M | 3–5 | Avoid per-IP throttling at major ISPs |
| 10M–50M | 5–15 | Consider managed instead |
| 50M+ | 15–30+ | Managed is strongly recommended at this scale |

Rule of thumb: Each IP should handle at least several hundred emails per major ISP per day to maintain reputation. Too many IPs dilutes volume per IP and hurts warm-up.

### Warm-Up Behavior

Automatic warm-up (enabled by default) gradually increases the percentage of email sent through the new IP over 45 days. During warm-up, SES sends a fraction through the new IP and the rest through the shared pool.

```python
# Check warm-up status
ip_info = ses.get_dedicated_ip(Ip='203.0.113.1')
print(f"Warmup: {ip_info['DedicatedIp']['WarmupStatus']}")
# IN_PROGRESS or DONE
print(f"Warmup percentage: {ip_info['DedicatedIp']['WarmupPercentage']}%")
```

---

## Managed Dedicated IPs

AWS manages the entire IP lifecycle: provisioning, warm-up, scaling, and reputation maintenance. Launched October 2022, significantly enhanced through 2025.

### Key Differentiators

1. **Per-ISP warm-up**: Instead of a flat warm-up curve, the system warms each ISP independently. You might be fully warmed for Gmail while still ramping for Outlook.
2. **Intelligent overflow**: During warm-up, excess traffic spills to the shared pool seamlessly.
3. **Auto-scaling**: SES adds/removes IPs based on your sending volume without manual intervention.
4. **ISP-specific optimization**: ML-based routing decisions that are impractical to replicate manually.
5. **IP observability** (Oct 2025): View exact IP addresses assigned to your managed pool and their SNDS metrics.

### Configuration

```python
# Create a managed dedicated IP pool
ses.create_dedicated_ip_pool(
    PoolName='marketing-managed',
    ScalingMode='MANAGED'  # STANDARD for standard dedicated
)

# Assign to a configuration set
ses.put_configuration_set_delivery_options(
    ConfigurationSetName='marketing-config',
    SendingPoolName='marketing-managed'
)
```

### Pricing (Tiered)

| Monthly Volume | Per 1,000 Emails | Monthly Base |
|---|---|---|
| 0–10M | $0.08 | $15 |
| 10M–50M | $0.04 | $15 |
| 50M–100M | $0.02 | $15 |

### When Managed Beats Standard (Cost)

At low volumes, standard is cheaper. The crossover depends on the number of standard IPs needed:

- **2 standard IPs** ($49.90/mo) vs managed: Managed costs less below ~625K emails/month
- **5 standard IPs** ($124.75/mo): Managed costs less below ~1.5M/month
- **10 standard IPs** ($249.50/mo): Managed costs less below ~3M/month
- **30 standard IPs** ($748.50/mo): Managed costs less below ~9M/month

At 10M+/month, managed's operational simplicity usually justifies the premium even when standard is cheaper on paper. The per-ISP intelligence alone can prevent deliverability incidents that cost far more than the price difference.

---

## IP Pools

Pools group IPs for assignment to configuration sets, enabling reputation isolation between sending streams.

### Creating and Managing Pools

```python
# Create pools for different streams
ses.create_dedicated_ip_pool(PoolName='transactional-pool', ScalingMode='STANDARD')
ses.create_dedicated_ip_pool(PoolName='marketing-pool', ScalingMode='MANAGED')
ses.create_dedicated_ip_pool(PoolName='partner-pool', ScalingMode='MANAGED')

# Move a standard dedicated IP into a pool
ses.put_dedicated_ip_in_pool(Ip='203.0.113.1', DestinationPoolName='transactional-pool')

# Assign pool to config set
ses.put_configuration_set_delivery_options(
    ConfigurationSetName='transactional',
    SendingPoolName='transactional-pool',
    TlsPolicy='REQUIRE'
)
```

### Pool Strategy

```
Account
├── transactional-pool (Standard, 2 IPs)
│   ├── Config: transactional-critical (password resets, OTP)
│   └── Config: transactional-standard (order confirmations)
├── marketing-pool (Managed)
│   ├── Config: marketing-engaged (active subscribers)
│   └── Config: marketing-reengagement (win-back campaigns)
├── partner-pool (Managed)
│   └── Config: partner-sends (delegated sending)
└── ses-shared-pool (default, always available)
    └── Config: system-notifications (low volume alerts)
```

### Limits
- Maximum 50 IP pools per account
- Standard pools can be converted to managed (one-way, irreversible)
- The `ses-default-dedicated-pool` contains unassigned dedicated IPs
- The shared pool (`ses-shared-pool`) is always available as fallback

---

## IP Warm-Up

### Standard Dedicated IP Warm-Up Schedule

With automatic warm-up enabled, SES follows approximately this schedule:

| Day | % Through Dedicated IP |
|---|---|
| 1 | 2% |
| 7 | 10% |
| 14 | 25% |
| 21 | 50% |
| 30 | 75% |
| 45 | 100% |

Remainder goes through the shared pool. SES adjusts the curve based on bounces and complaints.

### Manual Warm-Up (If Automatic Disabled)

If you disable automatic warm-up, follow this sending volume ramp per IP:

| Day | Emails/Day | Notes |
|---|---|---|
| 1–2 | 200 | Most engaged recipients only |
| 3–4 | 500 | |
| 5–7 | 1,000 | |
| 8–14 | 5,000 | Monitor bounce rate daily |
| 15–21 | 10,000 | Check Google Postmaster |
| 22–28 | 25,000 | |
| 29–35 | 50,000 | |
| 36–45 | 100,000+ | Full volume |

### Critical Rules
- **Never skip warm-up** — ISPs track IP history; new IPs have zero trust
- **Consistency matters** — Send every day during warm-up, including weekends
- **Target engaged users first** — High open/click rates build positive reputation signals
- **Monitor aggressively** — Any bounce rate spike > 3% = pause and investigate
- **Re-warm after dormancy** — If an IP hasn't sent in 5+ days, it starts losing reputation. 30+ days of inactivity effectively resets it.

---

## Reputation Monitoring

### SES Native Metrics

```python
# Account-level reputation
account = ses.get_account()
print(f"Send quota: {account['SendQuota']['Max24HourSend']}")
print(f"Sending enabled: {account['SendingEnabled']}")

# Reputation metrics
# Auto-published to CloudWatch: Reputation.BounceRate, Reputation.ComplaintRate
```

### CloudWatch Alarms

```python
import boto3
cw = boto3.client('cloudwatch')

# Bounce rate alarm
cw.put_metric_alarm(
    AlarmName='SES-BounceRate-Critical',
    Namespace='AWS/SES',
    MetricName='Reputation.BounceRate',
    Statistic='Average',
    Period=900,  # 15 minutes
    EvaluationPeriods=2,
    Threshold=0.05,  # 5%
    ComparisonOperator='GreaterThanThreshold',
    AlarmActions=['arn:aws:sns:us-east-1:123456789012:ses-alerts']
)

# Complaint rate alarm
cw.put_metric_alarm(
    AlarmName='SES-ComplaintRate-Warning',
    Namespace='AWS/SES',
    MetricName='Reputation.ComplaintRate',
    Statistic='Average',
    Period=900,
    EvaluationPeriods=2,
    Threshold=0.001,  # 0.1%
    ComparisonOperator='GreaterThanThreshold',
    AlarmActions=['arn:aws:sns:us-east-1:123456789012:ses-alerts']
)
```

### External Monitoring

| Tool | What It Monitors | Setup |
|---|---|---|
| Google Postmaster Tools | Gmail reputation, spam rate, auth pass rate | Verify domain at postmaster.google.com |
| Microsoft SNDS | Outlook IP reputation, spam traps, complaints | Register IPs at postmaster.live.com |
| VDM Dashboard | ISP-level delivery rates, engagement, advisor | Enable in SES console or API |
| MXToolbox | Blacklist monitoring | Set up free monitoring alerts |

### SNDS Metrics in SES (Oct 2025+)

For both standard and managed dedicated IPs, SES now surfaces Microsoft SNDS data:
- `SNDS.SpamRate` — Percentage flagged as spam by Outlook
- `SNDS.ComplaintRate` — Junk button complaints
- `SNDS.TrapHits` — Spam trap activations

These metrics appear in CloudWatch and can trigger alarms directly.

---

## Cost Analysis by Volume

### Monthly Cost Comparison

| Volume/mo | Shared | Standard (2 IPs) | Standard (5 IPs) | Managed |
|---|---|---|---|---|
| 100K | $10 | $59.90 | $134.75 | $23 |
| 500K | $50 | $99.90 | $174.75 | $55 |
| 1M | $100 | $149.90 | $224.75 | $95 |
| 5M | $500 | $549.90 | $624.75 | $415 |
| 10M | $1,000 | $1,049.90 | $1,124.75 | $815 |
| 50M | $5,000 | $5,249.50 | $5,624.75 | $2,415 |
| 100M | $10,000 | $10,749.00 | - | $3,415 |

*Standard costs = base sending ($0.10/1K) + IP cost. Managed = base sending + $15 base + tiered per-1K.*

**The sweet spot for managed IPs is 5M–50M emails/month** — operational complexity is too high for standard at this scale, and managed's tiered pricing kicks in favorably.
