# Sending Patterns Reference

## Table of Contents
1. [API vs SMTP Decision](#api-vs-smtp)
2. [Python (boto3) Examples](#python-boto3)
3. [Node.js Examples](#nodejs)
4. [Bulk Sending Patterns](#bulk-sending)
5. [Rate Limiting Strategies](#rate-limiting)
6. [Raw Email for Maximum Control](#raw-email)
7. [Key Quotas](#key-quotas)

---

## API vs SMTP

| Factor | SES v2 API (SDK) | SMTP Interface |
|---|---|---|
| Performance | Persistent HTTPS, ~50ms/call | TCP handshake overhead per session |
| Max message size | 40 MB | 40 MB |
| Feature access | All v2 features | Basic send only |
| Templates | Yes (stored + inline) | No |
| Bulk send | Yes (50/call) | One at a time per connection |
| VDM, tenants | Yes | Partial (via headers) |
| Configuration sets | Yes (parameter) | Yes (X-SES-CONFIGURATION-SET header) |
| Best for | All new development | Legacy apps, email servers, WordPress |

**Always prefer the API** unless integrating with legacy software that only speaks SMTP.

### SMTP Details (When Needed)

- Endpoint: `email-smtp.{region}.amazonaws.com`
- Ports: 587 (STARTTLS), 465 (TLS Wrapper), 2587, 2465
- Auth: SMTP credentials (derived from IAM, NOT the same as access keys)
- Generate credentials: `aws ses create-smtp-password` or via IAM console
- Region-specific: each region has separate SMTP endpoints and credentials

---

## Python (boto3)

### Simple Transactional Email

```python
import boto3

ses = boto3.client('sesv2', region_name='us-east-1')

response = ses.send_email(
    FromEmailAddress='noreply@tx.example.com',
    Destination={
        'ToAddresses': ['user@gmail.com'],
        'CcAddresses': [],
        'BccAddresses': []
    },
    Content={
        'Simple': {
            'Subject': {'Data': 'Your order has shipped', 'Charset': 'UTF-8'},
            'Body': {
                'Html': {
                    'Data': '<h1>Order Shipped!</h1><p>Track: <a href="...">here</a></p>',
                    'Charset': 'UTF-8'
                },
                'Text': {
                    'Data': 'Order Shipped! Track here: ...',
                    'Charset': 'UTF-8'
                }
            },
            'Headers': [
                {'Name': 'List-Unsubscribe', 'Value': '<https://example.com/unsub?t=abc>'},
                {'Name': 'List-Unsubscribe-Post', 'Value': 'List-Unsubscribe=One-Click'},
                {'Name': 'X-Priority', 'Value': '1'}
            ]
        }
    },
    EmailTags=[
        {'Name': 'campaign', 'Value': 'order-shipped'},
        {'Name': 'environment', 'Value': 'production'}
    ],
    ConfigurationSetName='transactional-critical'
)

message_id = response['MessageId']
print(f"Sent: {message_id}")
```

### Templated Email

```python
import json

# Create template once
ses.create_email_template(
    TemplateName='welcome-v2',
    TemplateContent={
        'Subject': 'Welcome to {{company_name}}, {{first_name}}!',
        'Html': '''
        <div style="max-width:600px;margin:0 auto;">
            <h1>Welcome, {{first_name}}!</h1>
            <p>Your account at {{company_name}} is ready.</p>
            <a href="{{dashboard_url}}" style="background:#007bff;color:#fff;padding:12px 24px;">
                Go to Dashboard
            </a>
            <hr>
            <p style="font-size:12px;color:#666;">
                {{company_address}}<br>
                <a href="{{unsubscribe_url}}">Unsubscribe</a>
            </p>
        </div>
        ''',
        'Text': 'Welcome {{first_name}}! Visit your dashboard: {{dashboard_url}}'
    }
)

# Send with template
ses.send_email(
    FromEmailAddress='welcome@tx.example.com',
    Destination={'ToAddresses': ['newuser@gmail.com']},
    Content={
        'Template': {
            'TemplateName': 'welcome-v2',
            'TemplateData': json.dumps({
                'first_name': 'Raul',
                'company_name': 'Mi Empresa',
                'dashboard_url': 'https://app.example.com/dashboard',
                'company_address': 'Guadalajara, Jalisco, MX',
                'unsubscribe_url': 'https://app.example.com/unsubscribe?t=xyz'
            })
        }
    },
    ConfigurationSetName='transactional-standard'
)
```

### With Error Handling and Retries

```python
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
import time

# Configure retries
config = Config(
    retries={'max_attempts': 3, 'mode': 'adaptive'},
    max_pool_connections=50
)
ses = boto3.client('sesv2', region_name='us-east-1', config=config)

def send_with_retry(params, max_retries=3):
    for attempt in range(max_retries):
        try:
            return ses.send_email(**params)
        except ClientError as e:
            error_code = e.response['Error']['Code']

            if error_code == 'TooManyRequestsException':
                # Throttled — exponential backoff
                wait = 2 ** attempt + (random.random() * 0.5)
                time.sleep(wait)
                continue
            elif error_code == 'MessageRejected':
                # Don't retry — content or recipient issue
                raise
            elif error_code == 'AccountSendingPausedException':
                # Account paused — alert ops team
                alert_ops_team(f"SES account paused: {e}")
                raise
            else:
                raise

    raise Exception(f"Failed after {max_retries} retries")
```

---

## Node.js

### Using @aws-sdk/client-sesv2

```javascript
import { SESv2Client, SendEmailCommand, SendBulkEmailCommand } from "@aws-sdk/client-sesv2";

const ses = new SESv2Client({ region: 'us-east-1' });

// Simple send
const response = await ses.send(new SendEmailCommand({
    FromEmailAddress: 'noreply@tx.example.com',
    Destination: { ToAddresses: ['user@gmail.com'] },
    Content: {
        Simple: {
            Subject: { Data: 'Order Confirmed' },
            Body: {
                Html: { Data: '<h1>Thanks!</h1>' },
                Text: { Data: 'Thanks!' }
            },
            Headers: [
                { Name: 'List-Unsubscribe', Value: '<https://example.com/unsub?t=abc>' },
                { Name: 'List-Unsubscribe-Post', Value: 'List-Unsubscribe=One-Click' }
            ]
        }
    },
    EmailTags: [{ Name: 'campaign', Value: 'order-confirm' }],
    ConfigurationSetName: 'transactional-critical'
}));

console.log(`Sent: ${response.MessageId}`);
```

### Bulk Send

```javascript
const BATCH_SIZE = 50;
const SEND_RATE = 14;
const DELAY_MS = (BATCH_SIZE / SEND_RATE) * 1000;

for (let i = 0; i < recipients.length; i += BATCH_SIZE) {
    const batch = recipients.slice(i, i + BATCH_SIZE).map(r => ({
        Destination: { ToAddresses: [r.email] },
        ReplacementEmailContent: {
            ReplacementTemplate: {
                ReplacementTemplateData: JSON.stringify({ name: r.name })
            }
        }
    }));

    await ses.send(new SendBulkEmailCommand({
        FromEmailAddress: 'news@mktg.example.com',
        DefaultContent: {
            Template: {
                TemplateName: 'weekly-newsletter',
                TemplateData: JSON.stringify({ name: 'Subscriber' })
            }
        },
        BulkEmailEntries: batch,
        ConfigurationSetName: 'marketing-engaged'
    }));

    await new Promise(r => setTimeout(r, DELAY_MS));
}
```

---

## Bulk Sending

### SendBulkEmail — Up to 50 Recipients Per Call

```python
import json, time

recipients = [
    {'email': 'user1@gmail.com', 'name': 'Alice', 'prefs': 'https://...'},
    {'email': 'user2@yahoo.com', 'name': 'Bob', 'prefs': 'https://...'},
    # ... thousands more
]

BATCH_SIZE = 50
SEND_RATE = 14  # per-second limit (check your account)
DELAY = BATCH_SIZE / SEND_RATE

errors = []

for i in range(0, len(recipients), BATCH_SIZE):
    batch = recipients[i:i + BATCH_SIZE]

    entries = [{
        'Destination': {'ToAddresses': [r['email']]},
        'ReplacementEmailContent': {
            'ReplacementTemplate': {
                'ReplacementTemplateData': json.dumps({
                    'name': r['name'],
                    'preferences_url': r['prefs']
                })
            }
        },
        'ReplacementTags': [
            {'Name': 'recipient_id', 'Value': r.get('id', 'unknown')}
        ]
    } for r in batch]

    response = ses.send_bulk_email(
        FromEmailAddress='news@mktg.example.com',
        ReplyToAddresses=['reply@example.com'],
        DefaultContent={
            'Template': {
                'TemplateName': 'newsletter-2026-02',
                'TemplateData': json.dumps({
                    'name': 'Subscriber',
                    'preferences_url': 'https://example.com/prefs'
                })
            }
        },
        DefaultEmailTags=[
            {'Name': 'campaign', 'Value': 'newsletter-2026-02-20'},
            {'Name': 'list', 'Value': 'weekly'}
        ],
        BulkEmailEntries=entries,
        ConfigurationSetName='marketing-engaged'
    )

    # Check per-recipient results
    for j, result in enumerate(response['BulkEmailEntryResults']):
        if result['Status'] != 'SUCCESS':
            errors.append({
                'email': batch[j]['email'],
                'error': result.get('Error', 'Unknown'),
                'message_id': result.get('MessageId')
            })

    time.sleep(DELAY)

print(f"Sent: {len(recipients) - len(errors)}, Errors: {len(errors)}")
```

---

## Rate Limiting

### Token Bucket Implementation

```python
import time
import threading

class TokenBucket:
    def __init__(self, rate, capacity=None):
        self.rate = rate
        self.capacity = capacity or rate
        self.tokens = self.capacity
        self.lock = threading.Lock()
        self.last_refill = time.monotonic()

    def acquire(self, tokens=1):
        with self.lock:
            now = time.monotonic()
            elapsed = now - self.last_refill
            self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)
            self.last_refill = now

            if self.tokens >= tokens:
                self.tokens -= tokens
                return 0  # No wait needed

            wait_time = (tokens - self.tokens) / self.rate
            self.tokens = 0
            return wait_time

    def wait_and_acquire(self, tokens=1):
        wait = self.acquire(tokens)
        if wait > 0:
            time.sleep(wait)

# Usage
limiter = TokenBucket(rate=14)  # 14 emails/second

for recipient in recipients:
    limiter.wait_and_acquire()
    ses.send_email(...)
```

### Concurrent Sending with asyncio

```python
import asyncio
import aioboto3
from asyncio import Semaphore

CONCURRENCY = 10  # Max concurrent API calls
RATE_LIMIT = 14   # Per second

async def send_batch(recipients):
    session = aioboto3.Session()
    semaphore = Semaphore(CONCURRENCY)

    async with session.client('sesv2', region_name='us-east-1') as ses:
        tasks = []
        for i, recipient in enumerate(recipients):
            task = send_one(ses, recipient, semaphore)
            tasks.append(task)

            # Rate limiting
            if (i + 1) % RATE_LIMIT == 0:
                await asyncio.sleep(1)

        results = await asyncio.gather(*tasks, return_exceptions=True)

    return results

async def send_one(ses, recipient, semaphore):
    async with semaphore:
        return await ses.send_email(
            FromEmailAddress='noreply@example.com',
            Destination={'ToAddresses': [recipient['email']]},
            Content={'Simple': {...}},
            ConfigurationSetName='production'
        )
```

---

## Raw Email for Maximum Control

When you need full control over headers, MIME structure, attachments, or multipart content:

```python
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

# Build MIME message
msg = MIMEMultipart('mixed')
msg['From'] = 'noreply@tx.example.com'
msg['To'] = 'user@gmail.com'
msg['Subject'] = 'Your invoice is attached'
msg['List-Unsubscribe'] = '<https://example.com/unsub?t=abc>'
msg['List-Unsubscribe-Post'] = 'List-Unsubscribe=One-Click'
msg['Feedback-ID'] = 'invoice:transactional:example.com:ses'

# Text/HTML body
body = MIMEMultipart('alternative')
body.attach(MIMEText('Your invoice is attached.', 'plain'))
body.attach(MIMEText('<h1>Your invoice is attached</h1>', 'html'))
msg.attach(body)

# Attachment
with open('invoice.pdf', 'rb') as f:
    att = MIMEApplication(f.read(), _subtype='pdf')
    att.add_header('Content-Disposition', 'attachment', filename='invoice.pdf')
    msg.attach(att)

# Send raw
ses.send_email(
    FromEmailAddress='noreply@tx.example.com',
    Destination={'ToAddresses': ['user@gmail.com']},
    Content={'Raw': {'Data': msg.as_string()}},
    ConfigurationSetName='transactional-standard'
)
```

---

## Key Quotas

| Resource | Default Limit | Adjustable |
|---|---|---|
| Daily sending quota (sandbox) | 200 | Move to production |
| Daily sending quota (production) | 50,000 (auto-scales) | Yes, via support |
| Max sending rate | 14/sec (auto-scales) | Yes, via support |
| Max message size (v2 API) | 40 MB | No |
| Max message size (SMTP) | 40 MB | No |
| Max recipients per message | 50 (To + CC + BCC) | No |
| Max bulk destinations per call | 50 | No |
| Max configuration sets per region | 10,000 | No |
| Max event destinations per config set | 10 | No |
| Max templates per region | 20,000 | No |
| Max identities per region | 10,000 | Contact AWS |
| Max IP pools | 50 | No |
| Max tenants | 10,000 (→ 300K) | Yes |
| Max contact lists | 1,000 | No |
| Max contacts per list | No hard limit | Performance degrades > 1M |
| Template size | 500 KB | No |
| Inline template data | 1 MB | No |

### Requesting Quota Increases

```bash
# Check current quotas
aws sesv2 get-account --query 'SendQuota'

# Request increase via Service Quotas
aws service-quotas request-service-quota-increase \
  --service-code ses \
  --quota-code L-E2E7B4C1 \
  --desired-value 500000
```

Quota increases are typically approved within 24 hours for accounts with good reputation history.
