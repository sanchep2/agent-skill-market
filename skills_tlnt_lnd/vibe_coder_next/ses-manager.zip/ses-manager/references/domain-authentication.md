# Domain Authentication Reference

## Table of Contents
1. [Domain Verification and DKIM](#domain-verification-and-dkim)
2. [Custom MAIL FROM](#custom-mail-from)
3. [DMARC Configuration](#dmarc-configuration)
4. [BIMI Setup](#bimi-setup)
5. [Deterministic Easy DKIM (Multi-Region)](#deterministic-easy-dkim)
6. [Multi-Domain Strategy](#multi-domain-strategy)
7. [Domain Warm-Up](#domain-warm-up)
8. [Complete DNS Record Template](#complete-dns-record-template)

---

## Domain Verification and DKIM

### Easy DKIM (Recommended)

SES generates and manages the key pair. Three CNAME records serve as both DKIM signing config and domain ownership proof.

```python
import boto3
ses = boto3.client('sesv2', region_name='us-east-1')

# Create identity with Easy DKIM (2048-bit is default since Sept 2021)
response = ses.create_email_identity(
    EmailIdentity='example.com',
    DkimSigningAttributes={
        'NextSigningKeyLength': 'RSA_2048_BIT'  # Always use 2048-bit
    }
)

# Retrieve DKIM tokens for DNS
tokens = response['DkimAttributes']['Tokens']
for token in tokens:
    print(f"CNAME: {token}._domainkey.example.com → {token}.dkim.amazonses.com")
```

**Key rotation**: Easy DKIM rotates keys automatically. No manual intervention needed.

**Route 53 auto-publish**: If using Route 53, SES can publish DKIM records automatically when creating the identity through the console.

### BYODKIM (Bring Your Own DKIM)

For organizations requiring control over key material. Uses a single TXT record with RSA key pair you generate.

```bash
# Generate 2048-bit RSA key pair
openssl genrsa -f4 -out private.key 2048
openssl rsa -in private.key -outform PEM -pubout -out public.key

# Extract public key for DNS (strip headers, join lines)
PUBLIC_KEY=$(grep -v "^-" public.key | tr -d '\n')
```

```python
ses.create_email_identity(
    EmailIdentity='example.com',
    DkimSigningAttributes={
        'DomainSigningSelector': 'ses202602',  # Choose a selector name
        'DomainSigningPrivateKey': open('private.key').read()
    }
)
```

DNS record: `ses202602._domainkey.example.com` TXT `"v=DKIM1;k=rsa;p={PUBLIC_KEY}"`

**Key rotation with BYODKIM**: You must rotate manually by generating new keys, updating the identity, and updating DNS. Plan rotation every 6–12 months.

### Verification Check

```python
identity = ses.get_email_identity(EmailIdentity='example.com')
dkim_status = identity['DkimAttributes']['Status']
# Values: PENDING, SUCCESS, FAILED, TEMPORARY_FAILURE, NOT_STARTED
print(f"DKIM Status: {dkim_status}")
print(f"Signing enabled: {identity['DkimAttributes']['SigningEnabled']}")
```

---

## Custom MAIL FROM

Without Custom MAIL FROM, the envelope sender (Return-Path) shows `something@amazonses.com`, which **breaks DMARC SPF alignment**. This is one of the most impactful configuration steps.

### Setup

```python
ses.put_email_identity_mail_from_attributes(
    EmailIdentity='example.com',
    MailFromDomain='mail.example.com',
    BehaviorOnMxFailure='USE_DEFAULT_VALUE'  # Falls back to amazonses.com if MX fails
    # Use 'REJECT_MESSAGE' to hard-fail instead
)
```

### Required DNS Records

| Record | Type | Value |
|---|---|---|
| `mail.example.com` | MX | `10 feedback-smtp.{region}.amazonses.com` |
| `mail.example.com` | TXT | `"v=spf1 include:amazonses.com ~all"` |

Replace `{region}` with your SES region (e.g., `us-east-1`, `eu-west-1`).

### Multi-Region MAIL FROM

If sending from multiple regions, you need **separate MX records per region** using different subdomains, OR use Global Endpoints which handle this automatically.

```
mail-use1.example.com  MX  10 feedback-smtp.us-east-1.amazonses.com
mail-euw1.example.com  MX  10 feedback-smtp.eu-west-1.amazonses.com
```

Each region's identity uses its own MAIL FROM subdomain.

---

## DMARC Configuration

### Phased Rollout

**Phase 1 — Monitor (2-4 weeks):**
```
_dmarc.example.com  TXT  "v=DMARC1;p=none;rua=mailto:dmarc-reports@example.com;ruf=mailto:dmarc-forensics@example.com"
```

**Phase 2 — Quarantine (2-4 weeks):**
```
_dmarc.example.com  TXT  "v=DMARC1;p=quarantine;pct=25;rua=mailto:dmarc-reports@example.com"
```
Gradually increase `pct` from 25 → 50 → 75 → 100.

**Phase 3 — Reject (production):**
```
_dmarc.example.com  TXT  "v=DMARC1;p=reject;rua=mailto:dmarc-reports@example.com;adkim=r;aspf=r"
```

### Alignment Modes

- `adkim=r` (relaxed): DKIM signing domain can be a subdomain of the From header domain. **Recommended** because SES signs with the verified domain.
- `aspf=r` (relaxed): SPF domain (MAIL FROM) can be a subdomain of From header domain. **Required** because Custom MAIL FROM always uses a subdomain.

### DMARC with Multiple Sending Services

If using SES alongside other services (e.g., Google Workspace for employee email), SPF must include all senders:

```
mail.example.com  TXT  "v=spf1 include:amazonses.com include:_spf.google.com ~all"
```

DKIM alignment handles the rest — each service signs with its own selector under the same domain.

---

## BIMI Setup

BIMI displays your brand logo next to emails in supported clients (Gmail, Apple Mail, Yahoo, Fastmail).

### Prerequisites
1. DMARC enforcement: `p=quarantine;pct=100` or `p=reject`
2. Custom MAIL FROM configured
3. Easy DKIM or BYODKIM active
4. SVG Tiny P/S format logo
5. VMC (Verified Mark Certificate) from DigiCert or Entrust — **required for Gmail and Apple Mail**
6. Registered trademark for the logo (required for VMC)

### DNS Record

```
default._bimi.example.com  TXT  "v=BIMI1;l=https://cdn.example.com/brand/logo.svg;a=https://cdn.example.com/brand/vmc.pem"
```

- `l=` is the logo URL (must be HTTPS, SVG Tiny P/S format, square aspect ratio)
- `a=` is the VMC certificate URL (PEM format)

### Without VMC

Yahoo and Fastmail support BIMI without VMC. Gmail and Apple Mail require it. You can publish BIMI without `a=` to get coverage on Yahoo/Fastmail:

```
default._bimi.example.com  TXT  "v=BIMI1;l=https://cdn.example.com/brand/logo.svg"
```

### VDM Advisor Check

VDM automatically flags missing or misconfigured BIMI records. Enable VDM and check the Advisor dashboard for BIMI-specific recommendations.

---

## Deterministic Easy DKIM

Launched December 2024. Generates consistent DKIM tokens across all AWS regions for the same domain. Previously, each region generated unique tokens requiring separate DNS records.

### How to Enable

Create the identity in your primary region, then create in secondary regions using the same signing attributes:

```python
# Primary region
ses_primary = boto3.client('sesv2', region_name='us-east-1')
response = ses_primary.create_email_identity(
    EmailIdentity='example.com',
    DkimSigningAttributes={
        'NextSigningKeyLength': 'RSA_2048_BIT',
        'DomainSigningAttributesOrigin': 'AWS_SES_EASY_DKIM'
    }
)
tokens = response['DkimAttributes']['Tokens']
# Publish these 3 CNAME records to DNS

# Secondary region — DEED generates the SAME tokens
ses_secondary = boto3.client('sesv2', region_name='eu-west-1')
ses_secondary.create_email_identity(
    EmailIdentity='example.com',
    DkimSigningAttributes={
        'NextSigningKeyLength': 'RSA_2048_BIT',
        'DomainSigningAttributesOrigin': 'AWS_SES_EASY_DKIM'
    }
)
# No new DNS records needed — same tokens work
```

### Use with Global Endpoints

Global Endpoints (December 2024) + DEED is the recommended setup for multi-region. Global Endpoints provide automatic failover between two regions, and DEED ensures consistent DKIM regardless of which region handles the send.

---

## Multi-Domain Strategy

### Recommended Subdomain Architecture

```
example.com (root)
├── tx.example.com          → Transactional (order confirmations, password resets)
├── mktg.example.com        → Marketing (newsletters, promotions)
├── support.example.com     → Customer service (ticket updates, surveys)
├── notify.example.com      → System notifications (alerts, status updates)
└── [partner].example.com   → Partner/white-label sending
```

Each subdomain gets:
- Its own SES identity (verified via Easy DKIM)
- Its own Custom MAIL FROM (e.g., `mail.tx.example.com`)
- Its own configuration set
- Its own IP pool assignment
- Its own tenant (if using tenant management)
- Independent DMARC reporting (optional: subdomain-specific DMARC records)

### Why Subdomains Over Separate Domains

- SPF alignment works with relaxed mode across subdomains
- DKIM signing can use the parent domain's key (organizational alignment)
- DMARC inheritance from parent domain (unless overridden)
- Reputation isolation while maintaining brand trust
- Easier DNS management under a single zone

---

## Domain Warm-Up

### Schedule

| Week | Daily Volume | Target Audience |
|---|---|---|
| 1 | 1,000–3,000 | Opened within last 30 days |
| 2 | 3,000–10,000 | Opened within last 30 days |
| 3 | 10,000–30,000 | Active last 60 days |
| 4 | 30,000–100,000 | Active last 90 days |
| 5–6 | 100,000+ | Full list (validated) |

### Rules
- Never increase more than **20% per day**
- Start with most engaged subscribers
- Monitor bounce rate daily — pause if it exceeds 3%
- Monitor complaint rate — pause if it exceeds 0.1%
- Send consistently — gaps in sending degrade reputation
- Post-warmup, maintain at least 1,000 emails/day/IP/major ISP
- Any volume increase beyond 5× your established baseline requires re-warming

---

## Complete DNS Record Template

For domain `example.com` with MAIL FROM `mail.example.com`:

```dns
; DKIM (Easy DKIM - 3 CNAME records from SES)
{token1}._domainkey.example.com.  CNAME  {token1}.dkim.amazonses.com.
{token2}._domainkey.example.com.  CNAME  {token2}.dkim.amazonses.com.
{token3}._domainkey.example.com.  CNAME  {token3}.dkim.amazonses.com.

; Custom MAIL FROM
mail.example.com.  MX   10 feedback-smtp.us-east-1.amazonses.com.
mail.example.com.  TXT  "v=spf1 include:amazonses.com ~all"

; DMARC
_dmarc.example.com.  TXT  "v=DMARC1;p=reject;rua=mailto:dmarc-reports@example.com;adkim=r;aspf=r"

; BIMI (optional, requires DMARC enforcement + VMC for Gmail/Apple)
default._bimi.example.com.  TXT  "v=BIMI1;l=https://cdn.example.com/logo.svg;a=https://cdn.example.com/vmc.pem"

; MTA-STS (optional, enhances transport security)
_mta-sts.example.com.  TXT  "v=STSv1;id=20260223"

; TLS Reporting (optional, receives TLS failure reports)
_smtp._tls.example.com.  TXT  "v=TLSRPTv1;rua=mailto:tls-reports@example.com"
```

---

## MTA-STS (RFC 8461)

MTA-STS (Mail Transfer Agent Strict Transport Security) previene ataques de downgrade TLS en el transporte SMTP. Sin MTA-STS, un atacante man-in-the-middle puede forzar conexiones SMTP a texto plano, exponiendo el contenido del email.

### Por qué importa con SES

SES envía email con TLS oportunista (STARTTLS) por defecto. Puedes forzar TLS en los envíos salientes configurando `TlsPolicy: REQUIRE` en tu configuration set. Pero MTA-STS protege el **lado receptor**: garantiza que servidores que te envían email a ti también usen TLS verificado.

### Componentes necesarios

**1. Registro DNS TXT:**

```
_mta-sts.example.com  TXT  "v=STSv1;id=20260223"
```

El `id` debe actualizarse cada vez que se modifique la política. Usar formato YYYYMMDD.

**2. Archivo de política HTTP:**

Publicar en `https://mta-sts.example.com/.well-known/mta-sts.txt`:

```
version: STSv1
mode: testing
mx: *.amazonses.com
mx: feedback-smtp.us-east-1.amazonses.com
max_age: 604800
```

- `mode: testing` — reporta fallos sin rechazar (usar primero 2-4 semanas para validar)
- `mode: enforce` — rechaza conexiones que no cumplan TLS verificado
- `mode: none` — desactiva la política
- `max_age` — tiempo en segundos que los emisores cachean la política (604800 = 7 días)
- Los `mx` deben coincidir con los MX records del dominio

**3. Fases de deployment:**

| Fase | `mode` | `max_age` | Duración |
|------|--------|-----------|----------|
| 1. Monitoreo | `testing` | `86400` (1 día) | 2-4 semanas |
| 2. Enforce parcial | `enforce` | `86400` (1 día) | 1-2 semanas |
| 3. Producción | `enforce` | `604800` (7 días) | Permanente |

### TLS Reporting (RFC 8460)

Complemento de MTA-STS que recibe reportes JSON diarios de emisores (Google, Microsoft, Yahoo) sobre fallos TLS al entregar email a tu dominio:

```
_smtp._tls.example.com  TXT  "v=TLSRPTv1;rua=mailto:tls-reports@example.com"
```

Los reportes incluyen: nombre del dominio emisor, política MTA-STS aplicada, total de sesiones exitosas/fallidas, y tipo de fallo (certificate_expired, certificate_not_trusted, etc.).

### Adopción

La adopción global de MTA-STS es <1% de dominios, pero Google, Microsoft y Yahoo validan políticas MTA-STS activamente. Para dominios de alto valor (financiero, salud, gobierno), MTA-STS es una capa de seguridad importante.

---

## ARC (Authenticated Received Chain — RFC 8617)

ARC preserva los resultados de autenticación SPF/DKIM/DMARC cuando un email pasa por intermediarios (listas de correo, reenvíos, filtros corporativos). Sin ARC, un reenvío legítimo puede fallar DMARC porque el intermediario modifica headers o el envelope sender.

### Cómo funciona

Cada intermediario agrega 3 headers ARC:
- `ARC-Authentication-Results` — resultados SPF/DKIM/DMARC que el intermediario observó
- `ARC-Message-Signature` — firma del intermediario sobre el mensaje
- `ARC-Seal` — firma sobre la cadena ARC completa (previene manipulación)

### SES y ARC

**SES aplica ARC automáticamente** en emails salientes. No requiere configuración manual. Cuando un email enviado por SES es reenviado por un intermediario confiable que añade headers ARC, los ISPs receptores pueden evaluar la cadena ARC para validar autenticidad.

### Soporte de ISPs receptores

| ISP | Evalúa ARC | Desde |
|-----|-----------|-------|
| Gmail | Sí | 2018 |
| Microsoft (Outlook.com/365) | Sí | 2019 |
| Yahoo | Sí | 2020 |
| Apple Mail (iCloud) | Parcial | 2023 |

### Impacto práctico

- **No necesitas hacer nada** — SES maneja ARC automáticamente
- ARC es especialmente relevante para listas de correo (mailing lists) donde DMARC falla frecuentemente
- Si recibes reportes DMARC con fallos en emails reenviados, ARC mitiga este problema
- ARC NO reemplaza DMARC — es un mecanismo complementario que los ISPs usan como señal adicional
