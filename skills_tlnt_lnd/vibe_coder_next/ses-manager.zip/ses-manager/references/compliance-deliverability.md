# Compliance & Deliverability Reference

## Table of Contents
1. [Gmail/Yahoo Bulk Sender Requirements (2024)](#gmailyahoo-requirements)
2. [Microsoft Requirements (2025)](#microsoft-requirements)
3. [Suppression List Management](#suppression-list-management)
4. [One-Click Unsubscribe Implementation](#one-click-unsubscribe)
5. [Google Postmaster Tools Integration](#google-postmaster-tools)
6. [Microsoft SNDS Integration](#microsoft-snds)
7. [CAN-SPAM Compliance](#can-spam)
8. [GDPR Considerations](#gdpr)
9. [Feedback Loops](#feedback-loops)

---

## Gmail/Yahoo Requirements

Enforced since February 2024 (authentication) and June 2024 (one-click unsubscribe). Apply to senders of 5,000+ messages/day to Gmail or Yahoo addresses.

### Mandatory Requirements

| Requirement | How SES Addresses It |
|---|---|
| SPF authentication | Custom MAIL FROM + SPF record |
| DKIM authentication | Easy DKIM (2048-bit) |
| DMARC (min p=none) | DNS TXT record on _dmarc subdomain |
| One-click unsubscribe (RFC 8058) | `ListManagementOptions` or custom headers |
| Honor unsubscribe within 2 days | SES subscription management or custom processing |
| Spam rate < 0.1% (never > 0.3%) | Suppression lists + engagement targeting |
| Valid forward/reverse DNS | SES handles for its own IPs |
| TLS for transmission | SES default (opportunistic TLS) |

### Monitoring Compliance

```python
# Check account sending review status
account = ses.get_account()
enforcement = account.get('EnforcementStatus', 'HEALTHY')
# HEALTHY, PROBATION, SHUTDOWN

review_status = account.get('Details', {}).get('ReviewDetails', {})
# Check for pending reviews
```

---

## Microsoft Requirements

Announced May 2025, enforced for Outlook.com, Hotmail, Live.com. Nearly identical to Gmail/Yahoo:

- SPF, DKIM, DMARC authentication required
- One-click unsubscribe for bulk email
- Spam complaint rate monitoring
- Valid sender addresses

### Additional Microsoft-Specific

- Microsoft's Junk Email Reporting Program (JMRP) — SES handles this through its feedback loop
- SNDS data now surfaced in SES CloudWatch (Oct 2025+) for dedicated IP users
- Microsoft Smart Screen filtering — content-based, harder to optimize for

---

## Suppression List Management

### Three Layers

**1. Global Suppression List** (SES-managed, invisible)
- Addresses that hard-bounce for ANY SES customer
- Automatic, no configuration needed
- Temporary suppression (removed after a period)
- You cannot view or modify this list

**2. Account-Level Suppression List**
```python
# Enable (default for accounts created after Nov 2019)
ses.put_account_suppression_attributes(
    SuppressedReasons=['BOUNCE', 'COMPLAINT']
)

# Add address manually
ses.put_suppressed_destination(
    EmailAddress='bad@example.com',
    Reason='COMPLAINT'
)

# Check if address is suppressed
try:
    result = ses.get_suppressed_destination(EmailAddress='user@example.com')
    print(f"Suppressed: {result['SuppressedDestination']['Reason']}")
except ses.exceptions.NotFoundException:
    print("Not suppressed")

# List suppressed addresses (paginated, 1000 per page)
paginator = ses.get_paginator('list_suppressed_destinations')
for page in paginator.paginate(Reasons=['BOUNCE', 'COMPLAINT']):
    for dest in page['SuppressedDestinationSummaries']:
        print(f"{dest['EmailAddress']}: {dest['Reason']} ({dest['LastUpdateTime']})")

# Bulk import from S3
ses.create_import_job(
    ImportDestination={
        'SuppressionListDestination': {
            'SuppressionListImportAction': 'PUT'  # or 'DELETE' to remove
        }
    },
    ImportDataSource={
        'S3Url': 's3://my-bucket/suppression-list.csv',
        'DataFormat': 'CSV'
    }
)
# CSV format: email_address (one per line, no header)
```

**3. Configuration Set-Level Suppression**

Override account-level settings for specific use cases:

```python
# Transactional: only suppress bounces (password resets should reach complaint-flagged users)
ses.put_configuration_set_suppression_options(
    ConfigurationSetName='transactional-critical',
    SuppressedReasons=['BOUNCE']  # NOT complaint
)

# Marketing: suppress both
ses.put_configuration_set_suppression_options(
    ConfigurationSetName='marketing-config',
    SuppressedReasons=['BOUNCE', 'COMPLAINT']
)

# System notifications: disable suppression entirely (rare, use with extreme caution)
ses.put_configuration_set_suppression_options(
    ConfigurationSetName='system-critical',
    SuppressedReasons=[]  # Empty = no suppression at config set level
)
```

---

## One-Click Unsubscribe

### Option 1: SES Native (ListManagementOptions)

Uses SES contact lists and topics. SES adds headers and manages an unsubscribe page automatically.

```python
# Create contact list
ses.create_contact_list(
    ContactListName='marketing-subscribers',
    Topics=[{
        'TopicName': 'weekly-newsletter',
        'DisplayName': 'Weekly Newsletter',
        'DefaultSubscriptionStatus': 'OPT_IN'
    }, {
        'TopicName': 'product-updates',
        'DisplayName': 'Product Updates',
        'DefaultSubscriptionStatus': 'OPT_IN'
    }]
)

# Send with automatic unsubscribe headers
ses.send_email(
    FromEmailAddress='news@mktg.example.com',
    Destination={'ToAddresses': ['user@gmail.com']},
    Content={'Simple': {
        'Subject': {'Data': 'Weekly Newsletter'},
        'Body': {
            'Html': {'Data': '''
                <h1>This week's news</h1>
                <p>Content here...</p>
                <p><a href="{{amazonSESUnsubscribeUrl}}">Unsubscribe</a></p>
            '''}
        }
    }},
    ListManagementOptions={
        'ContactListName': 'marketing-subscribers',
        'TopicName': 'weekly-newsletter'
    },
    ConfigurationSetName='marketing-config'
)
```

SES automatically adds:
- `List-Unsubscribe: <https://...>` header
- `List-Unsubscribe-Post: List-Unsubscribe=One-Click` header
- Replaces `{{amazonSESUnsubscribeUrl}}` in the body

**Limitation:** Only works for single-recipient emails (not SendBulkEmail with multiple To addresses).

### Option 2: Custom Implementation

For full control or when using SendBulkEmail:

```python
import urllib.parse

# Generate unique unsubscribe token per recipient
unsub_url = f"https://api.example.com/unsubscribe?token={generate_token(user_id, list_id)}"

ses.send_email(
    FromEmailAddress='news@mktg.example.com',
    Destination={'ToAddresses': ['user@gmail.com']},
    Content={'Simple': {
        'Subject': {'Data': 'Weekly Newsletter'},
        'Body': {'Html': {'Data': html_with_unsub_link}},
        'Headers': [
            {
                'Name': 'List-Unsubscribe',
                'Value': f'<{unsub_url}>'
            },
            {
                'Name': 'List-Unsubscribe-Post',
                'Value': 'List-Unsubscribe=One-Click'
            }
        ]
    }},
    ConfigurationSetName='marketing-config'
)
```

**Your HTTPS endpoint must:**
1. Accept POST requests
2. Process unsubscription immediately (no confirmation page required for the POST)
3. Return 200 OK
4. Honor within 2 days (immediate is strongly preferred)

### Adding Feedback-ID for Gmail

Gmail uses Feedback-ID for per-campaign spam rate tracking in Google Postmaster Tools:

```python
headers = [
    {'Name': 'Feedback-ID', 'Value': 'campaign123:newsletter:example.com:ses'},
    {'Name': 'List-Unsubscribe', 'Value': f'<{unsub_url}>'},
    {'Name': 'List-Unsubscribe-Post', 'Value': 'List-Unsubscribe=One-Click'}
]
```

Format: `campaignId:mailType:senderId:senderDomain` (colon-separated, up to 4 fields).

---

## Google Postmaster Tools

### Setup
1. Go to postmaster.google.com
2. Add your sending domain
3. Verify ownership via DNS TXT record
4. Wait 24–48 hours for data to populate (requires minimum volume)

### What It Shows
- **Domain reputation**: High, Medium, Low, Bad
- **IP reputation**: Per-IP breakdown (for dedicated IPs)
- **Spam rate**: Percentage of your emails marked as spam by Gmail users
- **Authentication**: SPF, DKIM, DMARC pass rates
- **Encryption**: TLS usage percentage
- **Delivery errors**: Categorized error rates

### Integration with SES

Google Postmaster Tools does NOT integrate directly with SES. You must:
1. Check GPT dashboard manually or use the GPT API
2. Cross-reference with SES CloudWatch metrics
3. Use Feedback-ID headers to get per-campaign breakdown
4. Google Postmaster API: `gmailpostmastertools.googleapis.com/v1/domains/{domain}/trafficStats`

**Critical**: Google does NOT participate in traditional feedback loops (ARF reports). The only way to see Gmail spam complaints is through Google Postmaster Tools. SES complaint rates will NOT include Gmail "Report Spam" clicks.

---

## Microsoft SNDS

### Setup for Dedicated IPs
1. Go to postmaster.live.com
2. Sign in with Microsoft account
3. Add your dedicated IP addresses
4. Complete automated ownership verification

### SES-Native SNDS (October 2025+)

For both standard and managed dedicated IPs, SES now publishes SNDS metrics to CloudWatch:
- `SNDS.SpamRate`
- `SNDS.ComplaintRate`
- `SNDS.TrapHits`

```python
# CloudWatch alarm for SNDS spam rate
cw.put_metric_alarm(
    AlarmName='SNDS-SpamRate-Warning',
    Namespace='AWS/SES',
    MetricName='SNDS.SpamRate',
    Statistic='Average',
    Period=86400,  # Daily
    EvaluationPeriods=1,
    Threshold=0.05,
    ComparisonOperator='GreaterThanThreshold',
    AlarmActions=['arn:aws:sns:us-east-1:123456789012:ses-alerts']
)
```

---

## CAN-SPAM

Every commercial email must include:

1. **Accurate header information** — From, To, Reply-To, routing info must not be misleading
2. **Non-deceptive subject line** — Must relate to email content
3. **Identification as advertisement** — Unless prior consent exists
4. **Valid physical mailing address** — In the email body (PO Box is acceptable)
5. **Working unsubscribe mechanism** — Must be honored within 10 business days
6. **Responsible monitoring** — If using third parties to send on your behalf

SES monitors compliance and reviews accounts that generate complaints indicating CAN-SPAM violations.

---

## GDPR

### AWS Data Processing

AWS's Global Data Processing Addendum automatically applies. Includes EU Standard Contractual Clauses.

### Your Responsibilities

1. **Consent**: Obtain explicit opt-in with timestamp before adding to marketing lists
2. **Transparency**: Disclose what data you collect (including open/click tracking) in privacy policy
3. **Right to erasure**: Remove personal data from SES suppression lists, contact lists, and analytics on request
4. **Data retention**: Define and enforce retention policies for event data in S3/DynamoDB
5. **Data Processing Records**: Maintain records of email processing activities
6. **Cross-border transfers**: SES processes email in the region you choose — select EU regions for EU recipients

### Practical Implementation

```python
# GDPR erasure: remove from all SES data stores
def gdpr_erase(email):
    # 1. Remove from contact lists
    for list_name in get_all_contact_lists():
        try:
            ses.delete_contact(ContactListName=list_name, EmailAddress=email)
        except ses.exceptions.NotFoundException:
            pass

    # 2. Add to suppression (prevents future sends)
    ses.put_suppressed_destination(EmailAddress=email, Reason='COMPLAINT')

    # 3. Delete from your analytics/DynamoDB
    delete_analytics_for_email(email)

    # 4. Log the erasure for compliance records
    log_gdpr_action('erasure', email)
```

---

## Feedback Loops

### How SES Feedback Loops Work

SES automatically processes feedback loop (FBL) reports from ISPs that participate in the ARF (Abuse Reporting Format) standard. When a recipient clicks "Report Spam":

1. ISP sends ARF report to SES
2. SES publishes COMPLAINT event through your configured event destinations
3. SES adds address to account suppression list (if enabled)

### ISP Feedback Loop Coverage

| ISP | Feedback Loop | Notes |
|---|---|---|
| Yahoo/AOL | Yes (ARF) | Reports flow through SES events |
| Microsoft | Yes (JMRP) | Reports flow through SES events |
| Gmail | **No** | Use Google Postmaster Tools instead |
| Apple Mail | No | No FBL program |
| Corporate | Varies | Many don't participate |

**The Gmail gap is critical**: Gmail processes ~30% of global email. You MUST monitor Google Postmaster Tools separately, as SES complaint metrics will underreport true complaint rates.

### Maximizing FBL Coverage

1. Enable complaint processing on all configuration sets
2. Set up Google Postmaster Tools for Gmail visibility
3. Register dedicated IPs with Microsoft SNDS
4. Use `Feedback-ID` headers for Gmail per-campaign tracking
5. Monitor VDM dashboard for ISP-level engagement signals
