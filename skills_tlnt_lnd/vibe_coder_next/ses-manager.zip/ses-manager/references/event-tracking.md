# Event Tracking & Webhooks Reference

## Table of Contents
1. [Event Types](#event-types)
2. [Destination Types](#destination-types)
3. [Configuration Examples](#configuration-examples)
4. [SNS Webhook Setup](#sns-webhook-setup)
5. [EventBridge Integration](#eventbridge-integration)
6. [Firehose Analytics Pipeline](#firehose-analytics-pipeline)
7. [Custom Tracking Domains](#custom-tracking-domains)
8. [Open/Click Tracking Caveats](#openclick-tracking-caveats)

---

## Event Types

| Event | Description | Use For |
|---|---|---|
| SEND | Email accepted by SES | Send confirmation, rate tracking |
| DELIVERY | Email delivered to recipient server | Delivery rate monitoring |
| OPEN | Tracking pixel loaded | Engagement metrics (unreliable with Apple MPP) |
| CLICK | Tracked link clicked | Engagement metrics, content optimization |
| BOUNCE | Hard or soft bounce | List hygiene, suppression |
| COMPLAINT | Recipient marked as spam | Immediate suppression, content review |
| REJECT | SES rejected before sending | Virus scan failures, policy violations |
| RENDERING_FAILURE | Template rendering failed | Template debugging |
| DELIVERY_DELAY | Temporary delivery failure | ISP throttling detection |
| SUBSCRIPTION | Unsubscribe/resubscribe via SES | List management |

### Bounce Sub-Types

```json
{
  "bounceType": "Permanent",  // or "Transient", "Undetermined"
  "bounceSubType": "General",  // General, NoEmail, Suppressed, OnAccountSuppressionList,
                                // MailboxFull, MessageTooLarge, ContentRejected, AttachmentRejected
  "bouncedRecipients": [{
    "emailAddress": "user@example.com",
    "action": "failed",
    "status": "5.1.1",
    "diagnosticCode": "smtp; 550 5.1.1 The email account does not exist"
  }]
}
```

**Permanent bounces**: Remove address immediately. Never retry.
**Transient bounces**: SES retries automatically for up to 14 hours. Monitor for patterns.

### Complaint Sub-Types

```json
{
  "complainedRecipients": [{"emailAddress": "user@example.com"}],
  "complaintSubType": "",  // or "OnAccountSuppressionList"
  "complaintFeedbackType": "abuse"  // abuse, auth-failure, fraud, not-spam, other, virus
}
```

**Always suppress immediately on complaint.** Never re-add. Even if the user later re-subscribes through your form, treat with extreme caution.

---

## Destination Types

### CloudWatch (Aggregate Metrics)

Best for: Dashboards, alarms, high-level monitoring. Events are aggregated into counts — individual event details are lost.

```python
ses.create_configuration_set_event_destination(
    ConfigurationSetName='production',
    EventDestinationName='cloudwatch-metrics',
    EventDestination={
        'Enabled': True,
        'MatchingEventTypes': ['SEND', 'DELIVERY', 'BOUNCE', 'COMPLAINT'],
        'CloudWatchDestination': {
            'DimensionConfigurations': [
                {
                    'DimensionName': 'ses:configuration-set',
                    'DimensionValueSource': 'MESSAGE_TAG',
                    'DefaultDimensionValue': 'default'
                },
                {
                    'DimensionName': 'campaign',
                    'DimensionValueSource': 'MESSAGE_TAG',
                    'DefaultDimensionValue': 'none'
                }
            ]
        }
    }
)
```

Custom dimensions allow slicing metrics by campaign, from-address, or any message tag you attach to sends.

### Amazon SNS (Real-Time Notifications)

Best for: Webhooks, immediate bounce/complaint processing, Lambda triggers.

```python
ses.create_configuration_set_event_destination(
    ConfigurationSetName='production',
    EventDestinationName='bounce-handler',
    EventDestination={
        'Enabled': True,
        'MatchingEventTypes': ['BOUNCE', 'COMPLAINT'],
        'SnsDestination': {
            'TopicArn': 'arn:aws:sns:us-east-1:123456789012:ses-bounces'
        }
    }
)
```

**SNS → HTTPS Webhook:**
```python
# Subscribe an HTTPS endpoint to the SNS topic
sns = boto3.client('sns')
sns.subscribe(
    TopicArn='arn:aws:sns:us-east-1:123456789012:ses-bounces',
    Protocol='https',
    Endpoint='https://api.example.com/webhooks/ses-events'
)
```

Your webhook endpoint must:
1. Handle SNS subscription confirmation (respond to SubscribeURL)
2. Verify SNS message signatures
3. Process events idempotently (SNS may deliver duplicates)
4. Respond with 2xx within 15 seconds

### Amazon EventBridge (Event-Driven Architecture)

Added June 2024. Routes events to 35+ AWS service targets with content-based filtering.

```python
ses.create_configuration_set_event_destination(
    ConfigurationSetName='production',
    EventDestinationName='eventbridge-all',
    EventDestination={
        'Enabled': True,
        'MatchingEventTypes': ['SEND', 'DELIVERY', 'OPEN', 'CLICK',
                                'BOUNCE', 'COMPLAINT', 'DELIVERY_DELAY'],
        'EventBridgeDestination': {
            'EventBusArn': 'arn:aws:events:us-east-1:123456789012:event-bus/ses-events'
        }
    }
)
```

**EventBridge Rules for routing:**
```json
{
  "source": ["aws.ses"],
  "detail-type": ["Email Bounce"],
  "detail": {
    "bounce": {
      "bounceType": ["Permanent"]
    }
  }
}
```

EventBridge advantage over SNS: content-based filtering at the service level, direct integration with Step Functions, and built-in dead-letter queues.

### Amazon Data Firehose (Analytics Pipeline)

Best for: Full event history, data warehouse integration, batch analytics.

```python
ses.create_configuration_set_event_destination(
    ConfigurationSetName='production',
    EventDestinationName='analytics-pipeline',
    EventDestination={
        'Enabled': True,
        'MatchingEventTypes': ['SEND', 'DELIVERY', 'OPEN', 'CLICK',
                                'BOUNCE', 'COMPLAINT', 'REJECT',
                                'RENDERING_FAILURE', 'DELIVERY_DELAY',
                                'SUBSCRIPTION'],
        'KinesisFirehoseDestination': {
            'IamRoleArn': 'arn:aws:iam::123456789012:role/ses-firehose-role',
            'DeliveryStreamArn': 'arn:aws:firehose:us-east-1:123456789012:deliverystream/ses-events'
        }
    }
)
```

---

## SNS Webhook Setup

### Lambda-Based Bounce/Complaint Processor

```python
# Lambda function for processing SES events via SNS
import json
import boto3

dynamodb = boto3.resource('dynamodb')
suppression_table = dynamodb.Table('email-suppressions')

def handler(event, context):
    for record in event['Records']:
        message = json.loads(record['Sns']['Message'])
        event_type = message.get('eventType') or message.get('notificationType')

        if event_type == 'Bounce':
            bounce = message['bounce']
            if bounce['bounceType'] == 'Permanent':
                for recipient in bounce['bouncedRecipients']:
                    suppress_email(recipient['emailAddress'], 'hard_bounce')

        elif event_type == 'Complaint':
            for recipient in message['complaint']['complainedRecipients']:
                suppress_email(recipient['emailAddress'], 'complaint')

def suppress_email(email, reason):
    suppression_table.put_item(Item={
        'email': email.lower(),
        'reason': reason,
        'timestamp': int(time.time()),
        'source': 'ses_webhook'
    })
    # Also add to SES account suppression list
    ses = boto3.client('sesv2')
    ses.put_suppressed_destination(
        EmailAddress=email,
        Reason='COMPLAINT' if reason == 'complaint' else 'BOUNCE'
    )
```

### External Webhook (Non-AWS)

For processing events in your own application:

```python
# Flask webhook endpoint example
from flask import Flask, request, jsonify
import json
import requests

app = Flask(__name__)

@app.route('/webhooks/ses-events', methods=['POST'])
def ses_webhook():
    body = json.loads(request.data)

    # Handle SNS subscription confirmation
    if body.get('Type') == 'SubscriptionConfirmation':
        requests.get(body['SubscribeURL'])
        return jsonify({'status': 'confirmed'}), 200

    # Process SES event
    if body.get('Type') == 'Notification':
        message = json.loads(body['Message'])
        event_type = message.get('eventType', message.get('notificationType'))

        if event_type == 'Bounce':
            process_bounce(message['bounce'])
        elif event_type == 'Complaint':
            process_complaint(message['complaint'])
        elif event_type == 'Delivery':
            record_delivery(message['delivery'])
        elif event_type == 'Open':
            record_open(message['open'])
        elif event_type == 'Click':
            record_click(message['click'])

    return jsonify({'status': 'ok'}), 200
```

---

## Firehose Analytics Pipeline

### Recommended Architecture

```
SES Events → Firehose (buffer 5min/5MB) → S3 (Parquet, partitioned by date)
                                                → Glue Crawler (daily)
                                                    → Athena (SQL queries)
                                                        → QuickSight (dashboards)
```

### Firehose Configuration

Configure Firehose to output Parquet format with date partitioning:
- **Buffer size**: 64–128 MB (Parquet conversion needs larger buffers)
- **Buffer interval**: 300 seconds (5 minutes)
- **Compression**: Snappy
- **S3 prefix**: `ses-events/year=!{timestamp:yyyy}/month=!{timestamp:MM}/day=!{timestamp:dd}/`

### Sample Athena Queries

```sql
-- Daily delivery rate by configuration set
SELECT
  date_format(from_unixtime(cast(ses.timestamp/1000 as bigint)), '%Y-%m-%d') as send_date,
  ses.configurationset as config_set,
  count(case when ses.eventtype = 'Send' then 1 end) as sends,
  count(case when ses.eventtype = 'Delivery' then 1 end) as deliveries,
  count(case when ses.eventtype = 'Bounce' then 1 end) as bounces,
  count(case when ses.eventtype = 'Complaint' then 1 end) as complaints,
  round(count(case when ses.eventtype = 'Delivery' then 1 end) * 100.0 /
        nullif(count(case when ses.eventtype = 'Send' then 1 end), 0), 2) as delivery_rate
FROM ses_events ses
WHERE year = '2026' AND month = '02'
GROUP BY 1, 2
ORDER BY 1 DESC;

-- Click-through rate by campaign tag
SELECT
  ses.tags['campaign'] as campaign,
  count(distinct case when ses.eventtype = 'Delivery' then ses.destination end) as delivered,
  count(distinct case when ses.eventtype = 'Click' then ses.destination end) as clicked,
  round(count(distinct case when ses.eventtype = 'Click' then ses.destination end) * 100.0 /
        nullif(count(distinct case when ses.eventtype = 'Delivery' then ses.destination end), 0), 2) as ctr
FROM ses_events ses
WHERE year = '2026'
GROUP BY 1
ORDER BY ctr DESC;
```

---

## Custom Tracking Domains

### Why Custom Domains Are Essential

Default SES tracking uses `awstrack.me` for click redirects and open pixels. This domain is:
- Blocked by many ad blockers
- Filtered by corporate firewalls
- Recognized as a tracking domain by privacy tools
- Shared across all SES customers

Custom tracking domains solve all of these issues and improve brand trust.

### Setup

```python
# Create custom redirect domain for click tracking
# Step 1: Create a CNAME record in DNS
# click.example.com  CNAME  {region}.r.appspot.com
# (SES provides the exact value during setup)

# Step 2: Configure in SES (via console or CloudFormation)
# As of Sept 2024, HTTPS is supported for both open and click tracking
```

### HTTPS Tracking (September 2024+)

Both open tracking pixels and click redirect links now support HTTPS with custom domains. This requires:
1. An ACM certificate for your tracking subdomain
2. Configuration through the SES console or API
3. CNAME records pointing to SES endpoints

Use subdomains like `t.example.com` or `click.example.com` — never the root domain.

---

## Open/Click Tracking Caveats

### Apple Mail Privacy Protection

Since iOS 15 (September 2021), Apple Mail preloads all tracking pixels through Apple's proxy servers. This affects roughly 48% of email client market share and means:
- Open events fire for virtually all Apple Mail users regardless of actual engagement
- Open rates are inflated by 20-40%+
- You cannot distinguish real opens from proxy prefetches
- Geo-location from open events is Apple's servers, not the recipient

### Recommendations

1. **Do not use open rate as a primary metric** — Use click-through rate, conversion events, and reply rates instead
2. **Engagement segmentation**: Define "engaged" based on clicks (not opens) within last 90 days
3. **Sunset policies**: Base re-engagement triggers on click activity, not open activity
4. **A/B testing**: Use click rate as the success metric, not open rate
5. **VDM engagement metrics** partially compensate — VDM aggregates ISP-level engagement signals that are more reliable than pixel tracking

### Bot Click Protection

Some email security tools (Barracuda, Mimecast, Proofpoint) pre-click all links in emails to scan for malware. This inflates click metrics. Mitigation strategies:
- Implement JavaScript-based confirmation on landing pages
- Filter clicks that happen within 1-2 seconds of delivery
- Look for patterns: bot clicks hit all links simultaneously
- Use time-to-click analysis: real clicks typically happen minutes to hours after delivery
