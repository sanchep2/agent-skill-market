# Pricing Comparison Reference

## Table of Contents
1. [SES Pricing Model](#ses-pricing-model)
2. [Full Cost Calculator](#full-cost-calculator)
3. [Competitor Comparison](#competitor-comparison)
4. [Cost Optimization Strategies](#cost-optimization)
5. [When NOT to Use SES](#when-not-to-use-ses)

---

## SES Pricing Model

### Base Sending

| Component | Cost |
|---|---|
| Email sending | $0.10 per 1,000 emails |
| Outgoing data transfer | $0.12 per GB (first 10 TB/mo) |
| Inbound email (Mail Manager) | $0.10 per 1,000 emails received |
| Inbound data | $0.09 per GB |
| Attachments | Included in data transfer costs |

Average email size ~75 KB = ~$0.009/1K in data costs, negligible for most volumes.

### Add-On Services

| Service | Cost | Notes |
|---|---|---|
| Standard Dedicated IP | $24.95/month per IP | Fixed, regardless of volume |
| Managed Dedicated IP (base) | $15/month | Per managed pool |
| Managed Dedicated IP (0–10M) | $0.08 per 1,000 | Tiered |
| Managed Dedicated IP (10M–50M) | $0.04 per 1,000 | Tiered |
| Managed Dedicated IP (50M–100M) | $0.02 per 1,000 | Tiered |
| VDM (0–10M) | $0.07 per 1,000 | Tiered |
| VDM (10M–100M) | $0.05 per 1,000 | Tiered |
| VDM (100M+) | $0.02 per 1,000 | Tiered |
| VDM API queries | $0.0005 per 1,000 | 5,000 free/month |
| Email Validation (API) | $0.01 per validation | One-time per address |
| Email Validation (Auto) | $0.01 per 1,000 | At send time |
| Tenant Management | $0.005/month per tenant | Plus $0.005/1K emails |
| Global Endpoints | $0.03 per 1,000 | Additional per email |

### Free Tier

- **Pre-July 2025 accounts**: 3,000 messages/month for 12 months (from EC2 only historically, now universal)
- **Post-July 2025 accounts**: $200 AWS credits applicable to SES
- VDM: 25,000 free messages/month included in free tier

---

## Full Cost Calculator

### Scenario: 1 Million Emails/Month

**Minimal setup (shared IPs, no VDM):**
```
Base sending:     1,000K × $0.10/1K  = $100.00
Data transfer:    ~75 GB × $0.12/GB  = $9.00
                                Total: $109.00
```

**Production setup (2 standard IPs, VDM):**
```
Base sending:     1,000K × $0.10/1K  = $100.00
Data transfer:    ~75 GB × $0.12/GB  = $9.00
2 Dedicated IPs:  2 × $24.95         = $49.90
VDM:              1,000K × $0.07/1K  = $70.00
                                Total: $228.90
```

**Full stack (managed IPs, VDM, validation, tenants):**
```
Base sending:     1,000K × $0.10/1K  = $100.00
Data transfer:    ~75 GB × $0.12/GB  = $9.00
Managed IPs:      $15 + 1,000K×$0.08 = $95.00
VDM:              1,000K × $0.07/1K  = $70.00
Validation:       1,000K × $0.01/1K  = $10.00
5 Tenants:        5 × $0.005 + neg.  = $0.03
                                Total: $284.03
```

### Scenario: 10 Million Emails/Month

**Full stack:**
```
Base sending:     10,000K × $0.10/1K   = $1,000.00
Data transfer:    ~750 GB × $0.12/GB   = $90.00
Managed IPs:      $15 + 10,000K×$0.08  = $815.00
VDM:              10,000K × $0.07/1K   = $700.00
Validation:       10,000K × $0.01/1K   = $100.00
50 Tenants:       50 × $0.005 + $0.50  = $0.75
                                  Total: $2,705.75
```

### Scenario: 50 Million Emails/Month

**Full stack (tiered pricing kicks in):**
```
Base sending:     50,000K × $0.10/1K                    = $5,000.00
Data transfer:    ~3.75 TB × $0.12/GB                   = $450.00
Managed IPs:      $15 + (10M×$0.08)+(40M×$0.04)         = $2,415.00
VDM:              (10M×$0.07)+(40M×$0.05)                = $2,700.00
Validation:       50,000K × $0.01/1K                     = $500.00
                                                   Total: $11,065.00
```

---

## Competitor Comparison

### At 1 Million Emails/Month

| Provider | Plan | Monthly Cost | Notes |
|---|---|---|---|
| **Amazon SES** (full stack) | Pay-as-you-go | ~$285 | Requires engineering setup |
| **Amazon SES** (minimal) | Pay-as-you-go | ~$109 | Shared IPs, no VDM |
| **SendGrid** | Pro 1M | ~$400–800 | Includes UI, templates, A/B testing |
| **Postmark** | Pay-as-you-go | ~$700 | Best transactional deliverability |
| **Mailgun** | Scale | ~$900+ | API-focused, good docs |
| **Mailchimp** | Standard | ~$1,200+ | Full marketing automation |
| **SparkPost** | Enterprise | Custom | High-volume specialist |

### At 10 Million Emails/Month

| Provider | Monthly Cost | Savings vs SES |
|---|---|---|
| **Amazon SES** (full stack) | ~$2,700 | Baseline |
| **SendGrid** | $5,000–15,000 (custom) | SES saves 46–82% |
| **Postmark** | $6,000+ (custom) | SES saves 55%+ |
| **Mailgun** | $8,000+ (custom) | SES saves 66%+ |

### Feature Comparison

| Feature | SES | SendGrid | Postmark | Mailgun |
|---|---|---|---|---|
| Drag-and-drop editor | No | Yes | No | No |
| Marketing automation | No | Yes | No | No |
| A/B testing | No | Yes | No | Yes |
| Inbound email | Yes (Mail Manager) | Yes | Yes | Yes |
| Dedicated IPs | Yes ($24.95/mo) | Yes ($89/mo) | Yes (included Pro+) | Yes ($59/mo) |
| Managed IPs | Yes | No | N/A | No |
| Email validation | Yes (native) | Yes (add-on) | No | Yes (add-on) |
| Webhooks | Yes (5 dest types) | Yes | Yes | Yes |
| ISP-level analytics | Yes (VDM) | No | Yes (limited) | No |
| Multi-tenant | Yes (native) | No (manual) | No | Yes (subaccounts) |
| Seed testing | No | No | No | Yes (add-on) |
| AWS integration | Yes (native) | No | No | No |

---

## Cost Optimization

### 1. Use Configuration Sets for Everything

Without configuration sets, you have no per-stream metrics and can't optimize spending. Free to create (up to 10,000).

### 2. Right-Size Dedicated IPs

Each unused dedicated IP costs $24.95/month. Audit quarterly:
- IP sending < 200 emails/day? Consider consolidating or moving to shared
- Using 10+ standard IPs? Evaluate managed (may be cheaper AND better)

### 3. VDM Cost-Benefit Analysis

VDM at $0.07/1K = $70/month at 1M emails. Value proposition:
- Single deliverability incident (domain reputation drop) can cost 10-30% delivery rate loss
- At 1M emails with $0.50 average revenue per delivered email, 10% delivery drop = $50K/month revenue loss
- VDM pays for itself if it prevents one incident per year

### 4. Email Validation ROI

At $0.01/validation, validating 1M addresses costs $10,000 one-time.
- Average list has 5-15% invalid addresses
- Each hard bounce costs: reputation damage + potential account review + lost sending time
- Validate once, save continuously. Re-validate quarterly for active lists.

### 5. Region Selection

SES pricing is the same across all 28 regions. Choose based on:
- Proximity to recipients (lower latency)
- Data residency requirements (GDPR → eu-west-1)
- Feature availability (check latest region support table)

### 6. Minimize Data Transfer

- Keep emails under 100 KB (ideal: 50-75 KB)
- Host images externally (S3 + CloudFront), don't inline
- Use text-only for transactional alerts where HTML isn't needed
- Compress HTML templates

---

## When NOT to Use SES

SES is not the best choice when:

1. **You need a full marketing platform** — No drag-and-drop editor, no automation workflows, no A/B testing. Use Mailchimp, HubSpot, or Brevo if marketing teams need self-serve tools.

2. **You have no engineering resources** — SES requires AWS expertise for setup, monitoring, and maintenance. SendGrid or Postmark offer simpler onboarding.

3. **Volume < 10K/month** — The engineering investment doesn't justify the cost savings. Any provider works at this scale.

4. **You need inbox placement testing** — SES has no native seed-list testing. Use GlockApps or Validity alongside SES, or choose a provider with built-in testing.

5. **Single-send simplicity** — If you just need to send one-off emails from a web form, SMTP relay services or even Gmail API may be simpler.

SES wins decisively when: you have AWS expertise, send > 100K/month, need maximum control, want to minimize cost, or need deep AWS service integration.
