# ses-manager — Skill de Claude Code

Skill instalable para **Claude Code**: infraestructura de email con **Amazon SES v2** y
máxima entregabilidad en bandeja de entrada. Cubre autenticación de dominio (DKIM, SPF,
DMARC, BIMI), IPs dedicadas y pools, warm-up de IP/dominio, tracking de eventos y webhooks,
manejo de bounces/quejas y listas de supresión, cumplimiento de remitentes masivos
(Gmail/Yahoo/Microsoft), análisis de coste y patrones multi-tenant. Autocontenida.

## Cómo instalar
1. Descomprime este ZIP. Obtendrás una carpeta `ses-manager/`.
2. Cópiala a tu directorio de skills de Claude Code:
   - **Personal:** `~/.claude/skills/ses-manager/`
   - **Solo un proyecto:** `<tu-proyecto>/.claude/skills/ses-manager/`
3. Reinicia Claude Code. Se activará sola al trabajar con Amazon SES.

## Contenido
- `SKILL.md` — guía principal.
- `references/` — domain-authentication, ip-management, sending-patterns,
  compliance-deliverability, event-tracking, architecture-patterns, pricing-comparison.

Cortesía de **Talent Academy · Vibe Coder**.
