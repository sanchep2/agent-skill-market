---
name: amazon-ses-master
description: "Master skill for Amazon SES email infrastructure with maximum inbox deliverability. Use whenever the user works with SES (any version), email sending on AWS, domain authentication (DKIM, SPF, DMARC, BIMI), dedicated IPs/IP pools, deliverability optimization, event tracking/webhooks, bounce/complaint handling, suppression lists, VDM, multi-tenant email, email validation, IP/domain warm-up, Gmail/Yahoo/Microsoft bulk sender compliance, SES pricing analysis, SES v2 API, bulk email campaigns, configuration sets, custom MAIL FROM, or email templates. Trigger on mentions of 'SES', 'email deliverability', 'inbox placement', 'email reputation', 'bulk email', 'transactional email', or 'email API' in AWS context. Use even for simple SES questions — contains critical best practices that prevent common mistakes."
---

# Amazon SES Master Skill

Build the best email infrastructure on the planet using Amazon SES v2, with maximum inbox deliverability across Gmail, Outlook, Yahoo, Apple Mail, and corporate servers.

## Quick Orientation

| Property | Value |
|----------|-------|
| **API Version** | **SES v2** (v1 frozen, v2 for all new features) |
| **SDK** | AWS SDK (`@aws-sdk/client-sesv2`, `boto3 sesv2`) |
| **Base Pricing** | $0.10 / 1,000 emails + $0.12/GB outgoing |
| **Regions** | us-east-1, us-west-2, eu-west-1, ap-southeast-1, + more |
| **Dedicated IPs** | Standard: $24.95/mo, Managed: $15/mo + usage |
| **Max Message Size** | 40 MB (v2) |
| **Recipients/message** | 50 |
| **Key Paradigm** | Config sets per stream + IP pool isolation |
| **Event Types** | 10: Send, Delivery, Open, Click, Bounce, Complaint, Reject, RenderingFailure, DeliveryDelay, Subscription |
| **Event Destinations** | CloudWatch, Firehose, SNS, EventBridge, Pinpoint |

## Wrapper Script

Todas las operaciones comunes de SES se ejecutan via AWS CLI directamente:

```bash
aws sesv2 <command> [--region us-east-1]
```

## Portability

This skill is project-agnostic. Copy `.claude/skills/ses-manager/` to any project that uses Amazon SES.

## Reference Files

| Topic | Reference File | When to Read |
|-------|---------------|-------------|
| Domain authentication | `references/domain-authentication.md` | Setting up DKIM, SPF, DMARC, BIMI, Custom MAIL FROM, and multi-region DEED. |
| IP management | `references/ip-management.md` | Dedicated IP purchase, IP pools, warm-up schedules, rDNS, managed vs standard IPs. |
| Architecture patterns | `references/architecture-patterns.md` | Multi-tenant isolation, queue-based sending, cross-account authorization, configuration sets. |
| Event tracking | `references/event-tracking.md` | SNS/Firehose/EventBridge pipelines, webhook setup, bounce/complaint processing. |
| Sending patterns | `references/sending-patterns.md` | Bulk sending, templates, rate limiting, SDK examples (Python, Node.js). |
| Compliance & deliverability | `references/compliance-deliverability.md` | Gmail/Yahoo/Microsoft requirements, GDPR, CAN-SPAM, monitoring tools, VDM. |
| Pricing comparison | `references/pricing-comparison.md` | SES cost analysis vs SendGrid, Postmark, Mailgun, Elastic Email at various volumes. |

## Quick Decision Framework

Before writing any code or configuration, determine the use case:

| Scenario | API | IPs | Config Set | Key Priority |
|---|---|---|---|---|
| Transactional (< 50K/mo) | v2 `SendEmail` | Shared | Dedicated per stream | Speed, reliability |
| Transactional (> 50K/mo) | v2 `SendEmail` | Standard dedicated | Dedicated per stream | Control, consistency |
| Marketing (< 500K/mo) | v2 `SendEmail` or `SendBulkEmail` | Shared or 1 dedicated | Separate from transactional | Engagement, compliance |
| Marketing (> 500K/mo) | v2 `SendBulkEmail` | Managed dedicated | Separate from transactional | Auto warm-up, ISP optimization |
| Multi-tenant platform | v2 with Tenant Management | Managed dedicated | Per-tenant | Isolation, reputation protection |
| High-volume (> 10M/mo) | v2 + SQS queue architecture | Managed dedicated | Per stream + per brand | Cost, scalability |

## Core Principles (Apply to EVERY SES Implementation)

1. **Always use SES v2 API** — v1 is frozen; all new features (tenants, validation, VDM, global endpoints, DEED) are v2-only. The only exception: email receiving (receipt rules) remains v1-only.

2. **Always separate transactional from marketing** — Different subdomains, configuration sets, IP pools, and tenants. A marketing complaint spike must never degrade password reset delivery.

3. **Always configure full authentication** — DKIM 2048-bit (Easy DKIM), Custom MAIL FROM domain, DMARC (start `p=none`, advance to `p=reject`), and BIMI when trademark is available.

4. **Always implement one-click unsubscribe** — Mandatory for bulk senders since June 2024 (Gmail/Yahoo) and May 2025 (Microsoft). Use `ListManagementOptions` for native support or custom `List-Unsubscribe` + `List-Unsubscribe-Post` headers.

5. **Always set up event processing** — Route bounces and complaints to SNS→Lambda for immediate action. Route all events to Firehose→S3 for analytics.

6. **Always monitor reputation** — CloudWatch alarms on bounce rate (≥3% warning, ≥5% critical) and complaint rate (≥0.08% warning, ≥0.1% critical). Enable VDM for ISP-level visibility.

## Essential Patterns

### Multi-Tenant Isolation Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    SES Account                           │
│                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │  Tenant A    │  │  Tenant B    │  │  Tenant C    │  │
│  │              │  │              │  │              │  │
│  │ Config Set:  │  │ Config Set:  │  │ Config Set:  │  │
│  │ tenant-a-tx  │  │ tenant-b-tx  │  │ tenant-c-tx  │  │
│  │ tenant-a-mkt │  │ tenant-b-mkt │  │ tenant-c-mkt │  │
│  │              │  │              │  │              │  │
│  │ Domain:      │  │ Domain:      │  │ Domain:      │  │
│  │ a.example.com│  │ b.example.com│  │ c.example.com│  │
│  │              │  │              │  │              │  │
│  │ IP Pool:     │  │ IP Pool:     │  │ Shared Pool  │  │
│  │ pool-a       │  │ pool-b       │  │              │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
│                                                          │
│  X-SES-TENANT header for SMTP routing (Aug 2025)        │
└─────────────────────────────────────────────────────────┘
```

### Event Pipeline (SES → SNS → Lambda/Firehose)

```
┌──────────┐    ┌────────────┐    ┌──────────────────────────┐
│  Email   │───▶│    SES     │───▶│  Configuration Set       │
│  sent    │    │  processes │    │  Event Destinations:     │
└──────────┘    └────────────┘    └──────────┬───────────────┘
                                             │
                      ┌──────────────────────┼──────────────┐
                      ▼                      ▼              ▼
               ┌──────────────┐    ┌──────────────┐  ┌───────────┐
               │ SNS Topic    │    │ Firehose     │  │CloudWatch │
               │ (Bounce +    │    │ (ALL events  │  │ (metrics  │
               │  Complaint)  │    │  → S3 → ETL) │  │  alarms)  │
               └──────┬───────┘    └──────────────┘  └───────────┘
                      │
                      ▼
               ┌──────────────┐
               │ Lambda       │
               │ (immediate   │
               │  suppress +  │
               │  alert)      │
               └──────────────┘

Also available: EventBridge (Jun 2024) → 35+ AWS targets
```

### IP Warmup Schedule (Standard Dedicated)

```
Week 1:    ████                                      50-200/day
Week 2:    ████████                                  1,000-5,000/day
Week 3:    ████████████████                          10,000-25,000/day
Week 4:    ████████████████████████                  50,000/day
Week 5:    ██████████████████████████████            100,000/day
Week 6+:   ██████████████████████████████████████    Full volume

Rules: Max +20% increase/day. Engaged contacts first.
       Managed Dedicated IPs auto-warm (recommended >500K/mo).
       45-day full warm-up for standard dedicated IPs.
```

---

## Reference Architecture

For detailed implementation of any section below, read the corresponding reference file in `references/`.

### Domain Setup Checklist

Read `references/domain-authentication.md` for complete DNS records, DKIM options, and BIMI setup.

For each sending domain/subdomain:
```
1. Create identity:       aws sesv2 create-email-identity --email-identity example.com
2. Easy DKIM:             Publish 3 CNAME records (auto-generated)
3. Custom MAIL FROM:      aws sesv2 put-email-identity-mail-from-attributes \
                            --email-identity example.com \
                            --mail-from-domain mail.example.com
4. MAIL FROM DNS:         MX → feedback-smtp.{region}.amazonses.com
                          TXT → "v=spf1 include:amazonses.com ~all"
5. DMARC:                 TXT at _dmarc.example.com → "v=DMARC1;p=none;rua=mailto:dmarc@example.com"
6. BIMI (optional):       TXT at default._bimi.example.com (requires DMARC p=quarantine or p=reject + VMC)
```

For multi-region deployments, use **Deterministic Easy DKIM (DEED)** — same DKIM tokens across all regions, single set of DNS records. Create the identity in the primary region first, then replicate.

### IP Strategy

Read `references/ip-management.md` for warm-up schedules, pool configuration, and cost analysis.

**Three options:**
- **Shared** ($0): No setup, SES manages. Best for < 50K/month or unpredictable volume.
- **Standard Dedicated** ($24.95/mo per IP): Full control, manual warm-up (45 days). Need consistent volume per IP.
- **Managed Dedicated** ($15/mo base + $0.02–$0.08/1K): SES auto-provisions, warms per-ISP, scales automatically. Best for > 500K/month. As of Oct 2025, you can view exact IPs and SNDS metrics.

**IP pools** isolate reputation between streams. Assign pools to configuration sets:
```python
ses.create_configuration_set(ConfigurationSetName='marketing-config')
ses.put_configuration_set_delivery_options(
    ConfigurationSetName='marketing-config',
    SendingPoolName='marketing-pool'
)
```

### Configuration Sets Architecture

Read `references/architecture-patterns.md` for multi-tenant isolation, queue-based sending, and cross-account authorization.

Every email should specify a configuration set. Structure them by purpose:
```
transactional-critical    → Dedicated IP pool, TLS required, fast timeout (300s)
transactional-standard    → Dedicated IP pool, TLS required
marketing-engaged         → Marketing IP pool, VDM optimized delivery
marketing-reengagement    → Separate IP pool, conservative throttling
system-notifications      → Shared IPs, minimal tracking
```

Each configuration set can have: sending pool, TLS policy, suppression overrides, up to 10 event destinations, custom tracking domain, and reputation metrics.

### Event Tracking & Webhooks

Read `references/event-tracking.md` for complete pipeline architectures and webhook setup.

**10 event types:** Send, Delivery, Open, Click, Bounce, Complaint, Reject, RenderingFailure, DeliveryDelay, Subscription.

**5 destination types:** CloudWatch, Firehose, SNS, EventBridge (added June 2024), Pinpoint.

Recommended minimum setup:
```python
# 1. Bounces/complaints → SNS → Lambda (immediate processing)
ses.create_configuration_set_event_destination(
    ConfigurationSetName='production',
    EventDestinationName='bounce-handler',
    EventDestination={
        'Enabled': True,
        'MatchingEventTypes': ['BOUNCE', 'COMPLAINT'],
        'SnsDestination': {'TopicArn': 'arn:aws:sns:...'}
    }
)

# 2. All events → Firehose → S3 (analytics pipeline)
ses.create_configuration_set_event_destination(
    ConfigurationSetName='production',
    EventDestinationName='analytics-pipeline',
    EventDestination={
        'Enabled': True,
        'MatchingEventTypes': ['SEND', 'DELIVERY', 'OPEN', 'CLICK',
                                'BOUNCE', 'COMPLAINT', 'REJECT',
                                'DELIVERY_DELAY'],
        'KinesisFirehoseDestination': {
            'IamRoleArn': 'arn:aws:iam::...',
            'DeliveryStreamArn': 'arn:aws:firehose:...'
        }
    }
)

# 3. Reputation metrics → CloudWatch (alarms)
# Automatically published: Reputation.BounceRate, Reputation.ComplaintRate
```

**Custom tracking domains** — Set up HTTPS custom domains for open/click tracking to avoid `awstrack.me` being blocked by ad blockers and corporate firewalls.

### Sending Email — Code Patterns

Read `references/sending-patterns.md` for bulk sending, templates, rate limiting, and SDK examples.

**Single transactional email (Python):**
```python
import boto3
ses = boto3.client('sesv2', region_name='us-east-1')

ses.send_email(
    FromEmailAddress='noreply@tx.example.com',
    Destination={'ToAddresses': ['user@gmail.com']},
    Content={'Simple': {
        'Subject': {'Data': 'Your order is confirmed'},
        'Body': {'Html': {'Data': html_content}, 'Text': {'Data': text_content}},
        'Headers': [
            {'Name': 'List-Unsubscribe', 'Value': '<https://example.com/unsub?t=TOKEN>'},
            {'Name': 'List-Unsubscribe-Post', 'Value': 'List-Unsubscribe=One-Click'}
        ]
    }},
    ConfigurationSetName='transactional-critical'
)
```

**Bulk marketing email (Python):**
```python
import json, time
BATCH_SIZE = 50
DELAY = BATCH_SIZE / SEND_RATE_PER_SEC  # respect per-second quota

for i in range(0, len(recipients), BATCH_SIZE):
    batch = [{
        'Destination': {'ToAddresses': [r['email']]},
        'ReplacementEmailContent': {
            'ReplacementTemplate': {
                'ReplacementTemplateData': json.dumps({'name': r['name'], 'prefs_url': r['prefs']})
            }
        }
    } for r in recipients[i:i+BATCH_SIZE]]

    ses.send_bulk_email(
        FromEmailAddress='news@mktg.example.com',
        DefaultContent={'Template': {
            'TemplateName': 'weekly-newsletter',
            'TemplateData': json.dumps({'name': 'Subscriber'})
        }},
        BulkEmailEntries=batch,
        ConfigurationSetName='marketing-engaged'
    )
    time.sleep(DELAY)
```

### Deliverability Compliance Checklist

Read `references/compliance-deliverability.md` for Gmail/Yahoo/Microsoft requirements, GDPR, CAN-SPAM, and monitoring tools.

**Before going to production, verify ALL of these:**

- [ ] DKIM passes (2048-bit, Easy DKIM or BYODKIM)
- [ ] SPF passes (Custom MAIL FROM configured)
- [ ] DMARC published (minimum `p=none`)
- [ ] Custom MAIL FROM domain with MX + SPF records
- [ ] One-click unsubscribe headers on all marketing/promotional email
- [ ] Unsubscribe requests processed within 2 days
- [ ] Physical mailing address in email footer (CAN-SPAM)
- [ ] Account-level suppression list enabled (bounces + complaints)
- [ ] Bounce rate < 2%, complaint rate < 0.1%
- [ ] VDM enabled with advisor recommendations reviewed
- [ ] CloudWatch alarms set for bounce and complaint thresholds
- [ ] Google Postmaster Tools verified for sending domain
- [ ] Microsoft SNDS registered (if using dedicated IPs)
- [ ] Custom open/click tracking domain configured with HTTPS
- [ ] Email validation enabled or integrated pre-send

### Pricing Quick Reference

Read `references/pricing-comparison.md` for detailed cost analysis and competitor comparison.

| Component | Cost |
|---|---|
| Base sending | $0.10 / 1,000 emails |
| Outgoing data | $0.12 / GB |
| Standard Dedicated IP | $24.95 / month per IP |
| Managed Dedicated IP | $15/mo + $0.02–$0.08 / 1K emails |
| VDM | $0.02–$0.07 / 1K emails (tiered) |
| Email Validation | $0.01 per validation (API) |
| Tenant Management | $0.005/mo per tenant + $0.005 / 1K emails |
| Global Endpoints | $0.03 / 1K additional |

**At 1M emails/month:** SES full stack ≈ $290 vs SendGrid $400–800 vs Postmark $700 vs Mailgun $900+.

### Key Quotas

| Resource | Default Limit |
|---|---|
| Daily sending quota | Starts 50K, auto-scales |
| Max send rate | Starts 14/sec, auto-scales |
| Message size (v2) | 40 MB |
| Recipients per message | 50 |
| Bulk destinations per call | 50 |
| Configuration sets | 10,000 per region |
| Identities | 10,000 per region |
| Templates | 20,000 per region |
| Tenants | 10,000 (expandable to 300K) |

## Latest Features (2024–2025)

When implementing SES, always consider these recent capabilities:

- **Email Validation** (Dec 2025): `GetEmailAddressInsights` API or auto-validation at send time. $0.01/validation.
- **Tenant Management** (Aug 2025): Up to 10K isolated tenants with independent reputation. Use `X-SES-TENANT` header for SMTP.
- **Managed IP Observability** (Oct 2025): View exact IPs and SNDS data for managed pools.
- **Global Endpoints** (Dec 2024): Automatic failover across 2 regions.
- **Deterministic Easy DKIM** (Dec 2024): Consistent DKIM across all regions.
- **EventBridge Destination** (Jun 2024): Route SES events to 35+ AWS targets.
- **Mail Manager** (May 2024): Full email gateway with traffic policies and archiving.
- **One-Click Unsubscribe** (Mar 2024): Native RFC 8058 support.

## Common Mistakes to Avoid

1. **Using v1 API for new projects** — You lose access to templates, bulk send, VDM, tenants, validation, and all modern features.
2. **Not setting Custom MAIL FROM** — Breaks DMARC SPF alignment. Without it, envelope sender shows `amazonses.com`.
3. **Mixing transactional and marketing on same subdomain/IP** — Marketing complaints tank transactional delivery.
4. **Skipping one-click unsubscribe** — Gmail and Yahoo will reject or junk your email.
5. **Sending to unvalidated lists** — High bounce rates trigger SES account review/pause.
6. **Using `awstrack.me` for tracking** — Gets blocked by ad blockers. Always set up custom tracking domains.
7. **Not monitoring reputation** — By the time you notice deliverability drops, damage is already done.
8. **Warm-up too fast** — Never increase volume more than 20% per day. Target engaged subscribers first.
9. **Ignoring suppression list management** — Transactional config sets should only suppress bounces, not complaints.
10. **Not using configuration sets** — Every email without a config set is invisible to your analytics.
11. **Relying only on SES complaint events for Gmail** — Gmail does NOT participate in traditional feedback loops (ARF). SES complaint metrics will NOT include Gmail "Report Spam" clicks. You MUST set up Google Postmaster Tools separately (postmaster.google.com) to monitor Gmail spam rates. Gmail processes ~30% of global email — without GPT, you have a massive blind spot.

## AWS CLI Quick Reference

Common operations via AWS CLI:

```bash
# Account info
aws sesv2 get-account

# Identity management
aws sesv2 list-email-identities
aws sesv2 get-email-identity --email-identity example.com
aws sesv2 create-email-identity --email-identity example.com

# DNS verification
aws sesv2 get-email-identity --email-identity example.com --query 'DkimAttributes'

# Configuration sets
aws sesv2 list-configuration-sets

# Suppression list
aws sesv2 list-suppressed-destinations
aws sesv2 get-suppressed-destination --email-address user@example.com

# Reputation
aws sesv2 get-account --query 'SendQuota'

# Send test email
aws sesv2 send-email \
  --from-email-address test@example.com \
  --destination '{"ToAddresses":["recipient@example.com"]}' \
  --content '{"Simple":{"Subject":{"Data":"Test"},"Body":{"Text":{"Data":"Test email"}}}}'
```

## Cross-Skill Integration

### convex-skill
SES API calls MUST run in Convex **actions** (not queries or mutations) because they make external HTTP calls via the AWS SDK. Store email status and message IDs in Convex tables. Use SES event destinations (SNS → HTTP) to sync bounce/complaint events back to Convex via HTTP actions.

```typescript
// convex/email.ts — Convex action
"use node";
import { SESv2Client, SendEmailCommand } from "@aws-sdk/client-sesv2";
import { action } from "./_generated/server";
import { v } from "convex/values";

export const sendTransactional = action({
  args: { to: v.string(), subject: v.string(), html: v.string() },
  handler: async (ctx, args) => {
    const ses = new SESv2Client({ region: "us-east-1" });
    const result = await ses.send(new SendEmailCommand({
      FromEmailAddress: process.env.SES_FROM_ADDRESS!,
      Destination: { ToAddresses: [args.to] },
      Content: { Simple: {
        Subject: { Data: args.subject },
        Body: { Html: { Data: args.html } },
      }},
      ConfigurationSetName: "transactional-critical",
    }));
    return result.MessageId;
  },
});
```

### supabase-skill
SES sending can be triggered from Supabase Edge Functions using the AWS SDK for JavaScript. Use `Deno.env.get()` for credentials. Alternatively, use a database trigger + `pg_net` to call an Edge Function that sends via SES, keeping email logic close to the data layer.

### nextjs-web
Trigger SES sends from Server Actions or API routes. The webhook handler for SES events (bounces, complaints) goes in `app/api/webhooks/ses/route.ts` — parse the SNS notification JSON and verify the signature. Never use Edge Runtime for SES operations (requires Node.js AWS SDK).

### stripe-skill
Combine Stripe webhooks with SES for transactional receipts: on `checkout.session.completed` or `invoice.paid` events, trigger a Convex action or Edge Function that sends a branded receipt email via SES. Use SES templates with `SendBulkEmail` for batch invoice notifications.

### elastic-email
Both are email providers — choose based on context. Use **SES** when you need AWS ecosystem integration, lowest per-message cost at scale (>1M/month), full infrastructure control (dedicated IPs, custom MAIL FROM), or multi-region failover. Use **Elastic Email** when you need built-in campaign management, visual template builder, contact segmentation, or simpler setup without AWS expertise. They can coexist: SES for transactional, Elastic Email for marketing campaigns.
