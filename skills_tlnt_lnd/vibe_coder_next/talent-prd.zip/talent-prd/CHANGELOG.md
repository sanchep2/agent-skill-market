# Changelog — talent-prd

## 1.0 (2026-08-04) — primera versión pública

- Pipeline de PRD en 7 fases: intake → interrogatorio de producto (6 forcing
  questions) → premisas y landscape → escalada de fidelidad → alcance y
  alternativas → documento → review adversarial + desgranado a backlog.
- 3 modos de entrada: greenfield · brownfield-reconversión (el as-is sale del
  código antes de preguntar) · PRD inicial existente (auditoría de gaps).
- Plantillas de 3 niveles por appetite: Lite (9 secciones), Estándar (18) y
  Completo (27, superset acumulativo), con formato híbrido (historias de usuario
  → casos de uso formales + diagrama actores-módulos + modelo de entidades en
  Completo).
- Wayfinder local de decisiones (una ficha por decisión + índice) y backlog
  portable con trazabilidad «Surfaced by §N» — todo en ficheros, sin tracker y
  sin red.
- Scripts mecánicos: `verificar-prd.sh` (forma del artefacto) y
  `auditar-gaps.sh` (huecos contra tu nivel declarado).
- Suite de probadores incluida: rojo/verde del verificador, 3 escenarios
  extremo a extremo, invariantes con prueba de mutación y prueba standalone en
  un HOME limpio con espacios en la ruta.
