# talent-prd — de la idea al PRD aprobado

Skill para Claude Code que te lleva de una idea (o un repo existente, o un PRD
viejo) a un PRD aprobado con su backlog, sin saltarte las preguntas incomodas.

## Instalacion

Copia esta carpeta entera a tu directorio de skills de Claude Code:

```bash
# para un proyecto concreto
cp -r talent-prd /ruta/a/tu/proyecto/.claude/skills/talent-prd

# o global, para todos tus proyectos
cp -r talent-prd ~/.claude/skills/talent-prd
```

Listo: la proxima sesion de Claude Code en ese proyecto ya puede usarlo. Pidele
por ejemplo «quiero escribir el PRD de mi idea» o «documenta este repo como PRD».

## Que trae

- `SKILL.md` — el mapa del skill: pipeline de 7 fases, 3 modos de entrada,
  reglas que no se negocian y como verificar tu documento.
- `references/` — las guias por fase: pipeline, modos de entrada, plantillas y
  superset de 27 secciones, review adversarial, wayfinder de decisiones.
- `assets/` — plantillas listas para copiar: PRD en 3 niveles (Lite/Estandar/
  Completo), ficha de decision y backlog portable.
- `scripts/` — verificacion mecanica de tu artefacto: `verificar-prd.sh`
  (forma) y `auditar-gaps.sh` (huecos contra tu nivel). Solo bash + coreutils,
  cero red.
- `tests/` — la suite que demuestra que todo lo anterior funciona (46 casos).

## Requisitos

Bash y coreutils (Linux o macOS). Nada mas: sin red, sin cuentas, sin trackers.
