#!/usr/bin/env npx tsx
/**
 * stripe_helper.ts — Reusable helper functions for Stripe API operations.
 *
 * Usage:
 *   import { StripeHelper } from './stripe_helper';
 *   const helper = new StripeHelper(process.env.STRIPE_SECRET_KEY!);
 *   const pi = await helper.createPaymentIntent({ amount: 2000, currency: 'usd' });
 *
 * Or as CLI:
 *   npx tsx stripe_helper.ts --action create-payment-intent --amount 2000 --currency usd
 *   npx tsx stripe_helper.ts --action create-checkout-session --price price_xxx --mode payment
 *   npx tsx stripe_helper.ts --action list-customers --limit 10
 *   npx tsx stripe_helper.ts --action verify-webhook --payload '...' --signature '...' --secret whsec_xxx
 *
 * Requires: npm install stripe@20.3.1
 * API Version: 2026-01-28.clover | stripe npm v20.3.1
 */

import Stripe from 'stripe';


// ═══════════════════════════════════════════════════════════════════════════════
// Types & Interfaces
// ═══════════════════════════════════════════════════════════════════════════════

interface RetryOptions {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
  jitter: boolean;
}

interface CircuitBreakerOptions {
  failureThreshold: number;
  resetTimeoutMs: number;
  halfOpenMax: number;
}

interface CircuitBreakerStats {
  state: CircuitBreakerState;
  failureCount: number;
  successCount: number;
  halfOpenCalls: number;
  lastFailureTime: number;
  timeUntilRecoveryMs: number;
}


// ═══════════════════════════════════════════════════════════════════════════════
// CircuitBreaker Pattern
// ═══════════════════════════════════════════════════════════════════════════════


/** Estados del circuit breaker. */
enum CircuitBreakerState {
  CLOSED = 'closed',       // Normal: llamadas pasan
  OPEN = 'open',           // Fallando: llamadas rechazadas
  HALF_OPEN = 'half_open', // Probando recuperacion
}


/** Se lanza cuando el circuit breaker esta abierto y rechaza llamadas. */
class CircuitBreakerOpenError extends Error {
  public readonly state: CircuitBreakerState;
  public readonly failureCount: number;
  public readonly timeUntilRecoveryMs: number;

  constructor(message: string, state: CircuitBreakerState, failureCount: number, timeUntilRecoveryMs: number) {
    super(message);
    this.name = 'CircuitBreakerOpenError';
    this.state = state;
    this.failureCount = failureCount;
    this.timeUntilRecoveryMs = timeUntilRecoveryMs;
  }
}


/**
 * Implementacion del patron Circuit Breaker para proteger contra fallos en cascada.
 *
 * Flujo: CLOSED -> (fallos >= threshold) -> OPEN -> (timeout) -> HALF_OPEN -> (exito) -> CLOSED
 *                                                                            -> (fallo) -> OPEN
 *
 * Uso standalone:
 *   const cb = new CircuitBreaker({ failureThreshold: 5, resetTimeoutMs: 30000, halfOpenMax: 3 });
 *   const result = await cb.execute(() => stripeApiCall());
 *
 * Integrado en StripeHelper:
 *   Todas las llamadas API pasan automaticamente por el circuit breaker.
 */
class CircuitBreaker {
  private state: CircuitBreakerState = CircuitBreakerState.CLOSED;
  private failureCount = 0;
  private successCount = 0;
  private halfOpenCalls = 0;
  private lastFailureTime = 0;
  private lastStateChange: number = Date.now();

  private readonly failureThreshold: number;
  private readonly resetTimeoutMs: number;
  private readonly halfOpenMax: number;

  constructor(options: CircuitBreakerOptions = { failureThreshold: 5, resetTimeoutMs: 30000, halfOpenMax: 3 }) {
    this.failureThreshold = options.failureThreshold;
    this.resetTimeoutMs = options.resetTimeoutMs;
    this.halfOpenMax = options.halfOpenMax;
  }

  /**
   * Ejecuta la funcion a traves del circuit breaker.
   * Lanza CircuitBreakerOpenError si el circuito esta abierto.
   */
  async execute<T>(fn: () => Promise<T>): Promise<T> {
    const currentState = this.getCurrentState();

    if (currentState === CircuitBreakerState.OPEN) {
      const remaining = this.timeUntilRecovery();
      throw new CircuitBreakerOpenError(
        `Circuit breaker OPEN. ${this.failureCount} fallos consecutivos. ` +
        `Reintento en ${Math.ceil(remaining / 1000)}s`,
        currentState,
        this.failureCount,
        remaining,
      );
    }

    if (currentState === CircuitBreakerState.HALF_OPEN) {
      if (this.halfOpenCalls >= this.halfOpenMax) {
        // Limite de pruebas alcanzado, volver a OPEN
        this.transitionToOpen();
        throw new CircuitBreakerOpenError(
          `Circuit breaker re-opened: maximo de pruebas half-open alcanzado`,
          CircuitBreakerState.OPEN,
          this.failureCount,
          this.resetTimeoutMs,
        );
      }
      this.halfOpenCalls++;
    }

    try {
      const result = await fn();
      this.recordSuccess();
      return result;
    } catch (error) {
      if (this.isRetryable(error)) {
        this.recordFailure(error);
      }
      throw error;
    }
  }

  /** Registra un exito. En HALF_OPEN, cierra el circuito tras suficientes exitos. */
  private recordSuccess(): void {
    this.failureCount = 0;
    this.successCount++;
    if (this.state === CircuitBreakerState.HALF_OPEN) {
      if (this.successCount >= this.halfOpenMax) {
        this.transitionToClosed();
      }
    }
  }

  /** Registra un fallo. Abre el circuito si se supera el threshold. */
  private recordFailure(error: unknown): void {
    this.failureCount++;
    this.successCount = 0;
    this.lastFailureTime = Date.now();
    if (this.failureCount >= this.failureThreshold) {
      this.transitionToOpen();
    }
    if (this.state === CircuitBreakerState.HALF_OPEN) {
      // Fallo durante half-open: volver a OPEN
      this.transitionToOpen();
    }
  }

  /**
   * Clasifica si un error de Stripe es retryable (transitorio).
   * StripeRateLimitError, StripeConnectionError, y StripeAPIError con status >= 500
   * son considerados transitorios y activan el circuit breaker.
   */
  isRetryable(error: unknown): boolean {
    if (!(error instanceof Stripe.errors.StripeError)) {
      return false;
    }
    // Errores de rate limit siempre son transitorios
    if (error.type === 'StripeRateLimitError') return true;
    // Errores de conexion son transitorios
    if (error.type === 'StripeConnectionError') return true;
    // Errores de API con status 500+ son transitorios (error del servidor)
    if (error.type === 'StripeAPIError' && error.statusCode !== undefined && error.statusCode >= 500) return true;
    // Errores de autenticacion, validacion, etc. NO son transitorios
    return false;
  }

  /** Estado actual, con transicion automatica de OPEN -> HALF_OPEN si paso el timeout. */
  private getCurrentState(): CircuitBreakerState {
    if (this.state === CircuitBreakerState.OPEN) {
      if (Date.now() - this.lastFailureTime >= this.resetTimeoutMs) {
        this.tryRecovery();
      }
    }
    return this.state;
  }

  private transitionToOpen(): void {
    this.state = CircuitBreakerState.OPEN;
    this.lastStateChange = Date.now();
    process.stderr.write(
      `[CircuitBreaker] OPEN (fallos=${this.failureCount})\n`
    );
  }

  private transitionToClosed(): void {
    this.state = CircuitBreakerState.CLOSED;
    this.failureCount = 0;
    this.successCount = 0;
    this.halfOpenCalls = 0;
    this.lastStateChange = Date.now();
    process.stderr.write(`[CircuitBreaker] CLOSED (recuperado)\n`);
  }

  /** Transicion de OPEN -> HALF_OPEN para probar si el servicio se recupero. */
  private tryRecovery(): void {
    this.state = CircuitBreakerState.HALF_OPEN;
    this.halfOpenCalls = 0;
    this.successCount = 0;
    this.lastStateChange = Date.now();
    process.stderr.write(`[CircuitBreaker] HALF_OPEN (probando recuperacion)\n`);
  }

  /** Tiempo restante hasta que el circuit breaker intente recuperarse. */
  private timeUntilRecovery(): number {
    const elapsed = Date.now() - this.lastFailureTime;
    return Math.max(0, this.resetTimeoutMs - elapsed);
  }

  /** Retorna el estado publico del circuit breaker. */
  getState(): CircuitBreakerState {
    return this.getCurrentState();
  }

  /** Retorna estadisticas completas del circuit breaker. */
  getStats(): CircuitBreakerStats {
    return {
      state: this.getCurrentState(),
      failureCount: this.failureCount,
      successCount: this.successCount,
      halfOpenCalls: this.halfOpenCalls,
      lastFailureTime: this.lastFailureTime,
      timeUntilRecoveryMs: this.state === CircuitBreakerState.OPEN ? this.timeUntilRecovery() : 0,
    };
  }
}


// ═══════════════════════════════════════════════════════════════════════════════
// Retry with Exponential Backoff + Jitter
// ═══════════════════════════════════════════════════════════════════════════════


/**
 * Ejecuta una funcion con reintentos y backoff exponencial con full jitter.
 *
 * Full jitter: delay = random(0, min(maxDelay, baseDelay * 2^attempt))
 * Esto distribuye reintentos para evitar thundering herd.
 *
 * @param fn - Funcion asincrona a ejecutar
 * @param options - Configuracion de reintentos
 * @param isRetryable - Funcion para determinar si un error es transitorio
 */
async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  options: RetryOptions = { maxRetries: 3, baseDelayMs: 500, maxDelayMs: 30000, jitter: true },
  isRetryable: (error: unknown) => boolean = () => true,
): Promise<T> {
  let lastError: Error | undefined;

  for (let attempt = 0; attempt <= options.maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;

      // Si el error no es retryable, lanzar inmediatamente
      if (!isRetryable(error)) {
        throw error;
      }

      // Si ya agotamos todos los reintentos, lanzar
      if (attempt >= options.maxRetries) {
        break;
      }

      // Calcular delay con full jitter
      const exponentialCap = Math.min(options.maxDelayMs, options.baseDelayMs * Math.pow(2, attempt));
      const delay = options.jitter ? Math.random() * exponentialCap : exponentialCap;

      const errorType = error instanceof Stripe.errors.StripeError ? error.type : 'UnknownError';
      process.stderr.write(
        `[stripe_helper] Retry ${attempt + 1}/${options.maxRetries} ` +
        `en ${Math.round(delay)}ms (${errorType})\n`
      );

      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  throw lastError!;
}


// ═══════════════════════════════════════════════════════════════════════════════
// Amount Formatting Utilities
// ═══════════════════════════════════════════════════════════════════════════════


/**
 * Monedas de cero decimales en Stripe.
 * Para estas monedas, el monto enviado a Stripe es el monto real (sin multiplicar por 100).
 * Referencia: https://docs.stripe.com/currencies#zero-decimal
 */
const ZERO_DECIMAL_CURRENCIES: Set<string> = new Set([
  'bif', 'clp', 'djf', 'gnf', 'jpy', 'kmf', 'krw', 'mga',
  'pyg', 'rwf', 'ugx', 'vnd', 'vuv', 'xaf', 'xof', 'xpf',
]);

/**
 * Monedas con tratamiento especial: diferente precision para cargos vs. payouts.
 * Stripe acepta cargos con centavos pero los payouts se redondean a la unidad.
 */
const SPECIAL_CURRENCIES: Record<string, { chargeDecimals: number; payoutDecimals: number }> = {
  huf: { chargeDecimals: 2, payoutDecimals: 0 },
  twd: { chargeDecimals: 2, payoutDecimals: 0 },
};

/**
 * Convierte un monto en unidades mayores (ej: dolares) a la unidad mas pequena (ej: centavos).
 * Respeta las monedas de cero decimales y monedas especiales.
 */
function toSmallestUnit(amount: number, currency: string): number {
  const cur = currency.toLowerCase();
  if (ZERO_DECIMAL_CURRENCIES.has(cur)) {
    return Math.round(amount);
  }
  const special = SPECIAL_CURRENCIES[cur];
  if (special) {
    return Math.round(amount * Math.pow(10, special.chargeDecimals));
  }
  return Math.round(amount * 100);
}

/**
 * Convierte un monto en la unidad mas pequena (ej: centavos) a unidades mayores (ej: dolares).
 */
function fromSmallestUnit(amount: number, currency: string): number {
  const cur = currency.toLowerCase();
  if (ZERO_DECIMAL_CURRENCIES.has(cur)) {
    return amount;
  }
  const special = SPECIAL_CURRENCIES[cur];
  if (special) {
    return amount / Math.pow(10, special.chargeDecimals);
  }
  return amount / 100;
}

/**
 * Formatea un monto (en unidad mas pequena) para display humano usando Intl.NumberFormat.
 * Ejemplo: formatCurrency(2000, 'usd') -> "$20.00"
 */
function formatCurrency(amountInSmallestUnit: number, currency: string): string {
  const displayAmount = fromSmallestUnit(amountInSmallestUnit, currency);
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency.toUpperCase(),
    }).format(displayAmount);
  } catch {
    // Fallback si la moneda no es soportada por Intl
    return `${displayAmount.toFixed(2)} ${currency.toUpperCase()}`;
  }
}


// ═══════════════════════════════════════════════════════════════════════════════
// StripeHelper Class
// ═══════════════════════════════════════════════════════════════════════════════


/**
 * Clase principal: wrapper de alto nivel sobre el SDK de Stripe.
 *
 * Todas las operaciones pasan por CircuitBreaker + retry automatico.
 * Soporta Payment Intents, Checkout Sessions, Subscriptions, Customers,
 * Connect, Webhooks, Products/Prices, y Billing Meter Events.
 */
class StripeHelper {
  private readonly stripe: Stripe;
  private readonly circuitBreaker: CircuitBreaker;
  private readonly retryOptions: RetryOptions;

  constructor(
    apiKey: string,
    options: {
      maxNetworkRetries?: number;
      timeout?: number;
      apiVersion?: string;
      circuitBreaker?: CircuitBreakerOptions;
      retry?: Partial<RetryOptions>;
    } = {},
  ) {
    this.stripe = new Stripe(apiKey, {
      maxNetworkRetries: options.maxNetworkRetries ?? 2,
      timeout: options.timeout ?? 30_000,
    });

    this.circuitBreaker = new CircuitBreaker(
      options.circuitBreaker ?? {
        failureThreshold: 5,
        resetTimeoutMs: 30_000,
        halfOpenMax: 3,
      },
    );

    this.retryOptions = {
      maxRetries: options.retry?.maxRetries ?? 3,
      baseDelayMs: options.retry?.baseDelayMs ?? 500,
      maxDelayMs: options.retry?.maxDelayMs ?? 30_000,
      jitter: options.retry?.jitter ?? true,
    };
  }

  /**
   * Wrapper interno: circuit breaker + retry con backoff.
   * Todas las llamadas a la API de Stripe pasan por aqui.
   */
  private async execute<T>(fn: () => Promise<T>): Promise<T> {
    return this.circuitBreaker.execute(() =>
      retryWithBackoff(fn, this.retryOptions, (err) => this.circuitBreaker.isRetryable(err)),
    );
  }

  // ─── Payment Operations ──────────────────────────────────────────────────

  /**
   * Crea un PaymentIntent para cobrar un monto.
   * El monto debe estar en la unidad mas pequena de la moneda (centavos para USD).
   *
   * @example
   *   const pi = await helper.createPaymentIntent({ amount: 2000, currency: 'usd' });
   *   // pi.client_secret se envia al frontend para confirmar el pago
   */
  async createPaymentIntent(params: {
    amount: number;
    currency: string;
    customer?: string;
    paymentMethod?: string;
    confirm?: boolean;
    captureMethod?: 'automatic' | 'automatic_async' | 'manual';
    setupFutureUsage?: 'on_session' | 'off_session';
    metadata?: Record<string, string>;
    idempotencyKey?: string;
  }): Promise<Stripe.PaymentIntent> {
    return this.execute(() =>
      this.stripe.paymentIntents.create(
        {
          amount: params.amount,
          currency: params.currency,
          customer: params.customer,
          payment_method: params.paymentMethod,
          confirm: params.confirm,
          capture_method: params.captureMethod,
          setup_future_usage: params.setupFutureUsage,
          automatic_payment_methods: { enabled: true },
          metadata: params.metadata,
        },
        params.idempotencyKey ? { idempotencyKey: params.idempotencyKey } : undefined,
      ),
    );
  }

  /**
   * Confirma un PaymentIntent existente.
   * Normalmente se hace desde el frontend con Stripe.js, pero puede hacerse server-side.
   */
  async confirmPaymentIntent(
    id: string,
    params?: { paymentMethod?: string; returnUrl?: string },
  ): Promise<Stripe.PaymentIntent> {
    return this.execute(() =>
      this.stripe.paymentIntents.confirm(id, {
        payment_method: params?.paymentMethod,
        return_url: params?.returnUrl,
      }),
    );
  }

  /**
   * Captura un PaymentIntent previamente autorizado (captureMethod: 'manual').
   * Opcionalmente captura un monto parcial.
   */
  async capturePaymentIntent(
    id: string,
    params?: { amountToCapture?: number },
  ): Promise<Stripe.PaymentIntent> {
    return this.execute(() =>
      this.stripe.paymentIntents.capture(id, {
        ...(params?.amountToCapture !== undefined
          ? { amount_to_capture: params.amountToCapture }
          : {}),
      }),
    );
  }

  /**
   * Cancela un PaymentIntent que aun no ha sido capturado.
   */
  async cancelPaymentIntent(
    id: string,
    params?: { cancellationReason?: 'duplicate' | 'fraudulent' | 'requested_by_customer' | 'abandoned' },
  ): Promise<Stripe.PaymentIntent> {
    return this.execute(() =>
      this.stripe.paymentIntents.cancel(id, {
        cancellation_reason: params?.cancellationReason,
      }),
    );
  }

  /**
   * Crea una Checkout Session hospedada por Stripe.
   * Soporta modos: payment (pago unico), subscription, setup (guardar metodo de pago).
   *
   * Para embedded checkout (uiMode: 'embedded'), no se necesita successUrl/cancelUrl,
   * sino returnUrl con {CHECKOUT_SESSION_ID} placeholder.
   *
   * @example
   *   const session = await helper.createCheckoutSession({
   *     mode: 'subscription',
   *     lineItems: [{ price: 'price_xxx', quantity: 1 }],
   *     successUrl: 'https://example.com/success?session_id={CHECKOUT_SESSION_ID}',
   *     cancelUrl: 'https://example.com/cancel',
   *   });
   */
  async createCheckoutSession(params: {
    mode: 'payment' | 'subscription' | 'setup';
    lineItems: Array<{ price: string; quantity?: number }>;
    successUrl?: string;
    cancelUrl?: string;
    returnUrl?: string;
    uiMode?: 'embedded' | 'hosted';
    customer?: string;
    metadata?: Record<string, string>;
    idempotencyKey?: string;
  }): Promise<Stripe.Checkout.Session> {
    const createParams: Stripe.Checkout.SessionCreateParams = {
      mode: params.mode,
      line_items: params.lineItems,
      customer: params.customer,
      metadata: params.metadata,
    };

    if (params.uiMode === 'embedded') {
      createParams.ui_mode = 'embedded';
      createParams.return_url = params.returnUrl;
    } else {
      createParams.success_url = params.successUrl;
      createParams.cancel_url = params.cancelUrl;
    }

    return this.execute(() =>
      this.stripe.checkout.sessions.create(
        createParams,
        params.idempotencyKey ? { idempotencyKey: params.idempotencyKey } : undefined,
      ),
    );
  }

  /**
   * Recupera una Checkout Session existente con expansion opcional.
   */
  async retrieveCheckoutSession(
    id: string,
    expand?: string[],
  ): Promise<Stripe.Checkout.Session> {
    return this.execute(() =>
      this.stripe.checkout.sessions.retrieve(id, {
        expand: expand ?? ['line_items', 'payment_intent'],
      }),
    );
  }

  /**
   * Crea un reembolso total o parcial.
   * Especificar paymentIntent O charge (no ambos).
   */
  async refundPayment(params: {
    paymentIntent?: string;
    charge?: string;
    amount?: number;
    reason?: 'duplicate' | 'fraudulent' | 'requested_by_customer';
  }): Promise<Stripe.Refund> {
    return this.execute(() =>
      this.stripe.refunds.create({
        payment_intent: params.paymentIntent,
        charge: params.charge,
        amount: params.amount,
        reason: params.reason,
      }),
    );
  }

  // ─── Subscription Operations ─────────────────────────────────────────────

  /**
   * Crea una suscripcion para un customer existente.
   * Soporta multiples items (ej: plan base + add-ons), trial, y uso-basado.
   *
   * @example
   *   const sub = await helper.createSubscription({
   *     customer: 'cus_xxx',
   *     items: [{ price: 'price_monthly', quantity: 1 }],
   *     trialPeriodDays: 14,
   *   });
   */
  async createSubscription(params: {
    customer: string;
    items: Array<{ price: string; quantity?: number }>;
    defaultPaymentMethod?: string;
    paymentBehavior?: 'default_incomplete' | 'error_if_incomplete' | 'allow_incomplete';
    trialPeriodDays?: number;
    metadata?: Record<string, string>;
  }): Promise<Stripe.Subscription> {
    return this.execute(() =>
      this.stripe.subscriptions.create({
        customer: params.customer,
        items: params.items,
        default_payment_method: params.defaultPaymentMethod,
        payment_behavior: params.paymentBehavior ?? 'default_incomplete',
        payment_settings: { save_default_payment_method: 'on_subscription' },
        trial_period_days: params.trialPeriodDays,
        metadata: params.metadata,
        expand: ['latest_invoice.payment_intent'],
      }),
    );
  }

  /**
   * Actualiza una suscripcion existente: cambiar plan, cantidad, cancelar al final del periodo, etc.
   */
  async updateSubscription(
    id: string,
    params: {
      items?: Array<{ id?: string; price?: string; quantity?: number }>;
      cancelAtPeriodEnd?: boolean;
      metadata?: Record<string, string>;
      prorationBehavior?: 'create_prorations' | 'always_invoice' | 'none';
    },
  ): Promise<Stripe.Subscription> {
    const updateParams: Stripe.SubscriptionUpdateParams = {};

    if (params.items !== undefined) {
      updateParams.items = params.items;
    }
    if (params.cancelAtPeriodEnd !== undefined) {
      updateParams.cancel_at_period_end = params.cancelAtPeriodEnd;
    }
    if (params.metadata !== undefined) {
      updateParams.metadata = params.metadata;
    }
    if (params.prorationBehavior !== undefined) {
      updateParams.proration_behavior = params.prorationBehavior;
    }

    return this.execute(() =>
      this.stripe.subscriptions.update(id, updateParams),
    );
  }

  /**
   * Cancela una suscripcion inmediatamente o al final del periodo actual.
   */
  async cancelSubscription(
    id: string,
    params?: { invoiceNow?: boolean; prorate?: boolean; cancelAtPeriodEnd?: boolean },
  ): Promise<Stripe.Subscription> {
    if (params?.cancelAtPeriodEnd) {
      return this.execute(() =>
        this.stripe.subscriptions.update(id, { cancel_at_period_end: true }),
      );
    }
    return this.execute(() =>
      this.stripe.subscriptions.cancel(id, {
        invoice_now: params?.invoiceNow,
        prorate: params?.prorate,
      }),
    );
  }

  /**
   * Pausa la cobranza de una suscripcion usando pause_collection.
   * La suscripcion sigue activa pero no genera invoices cobrables.
   */
  async pauseSubscription(id: string): Promise<Stripe.Subscription> {
    return this.execute(() =>
      this.stripe.subscriptions.update(id, {
        pause_collection: { behavior: 'void' },
      }),
    );
  }

  /**
   * Reanuda una suscripcion pausada removiendo pause_collection.
   */
  async resumeSubscription(id: string): Promise<Stripe.Subscription> {
    return this.execute(() =>
      this.stripe.subscriptions.update(id, {
        pause_collection: '' as any, // Stripe SDK: pasar string vacio para remover
      }),
    );
  }

  /**
   * Reporta un evento de medicion para facturacion basada en uso (usage-based billing).
   * Requiere un Billing Meter configurado en el dashboard de Stripe.
   */
  async reportMeterEvent(params: {
    eventName: string;
    payload: Record<string, string>;
    customer: string;
    timestamp?: number;
    idempotencyKey?: string;
  }): Promise<Stripe.Billing.MeterEvent> {
    return this.execute(() =>
      this.stripe.billing.meterEvents.create(
        {
          event_name: params.eventName,
          payload: {
            ...params.payload,
            stripe_customer_id: params.customer,
          },
          timestamp: params.timestamp ?? Math.floor(Date.now() / 1000),
        },
        params.idempotencyKey ? { idempotencyKey: params.idempotencyKey } : undefined,
      ),
    );
  }

  /**
   * Crea una sesion del Customer Portal de Stripe para que el cliente
   * gestione sus suscripciones, metodos de pago, y facturas.
   */
  async createCustomerPortalSession(params: {
    customer: string;
    returnUrl: string;
  }): Promise<Stripe.BillingPortal.Session> {
    return this.execute(() =>
      this.stripe.billingPortal.sessions.create({
        customer: params.customer,
        return_url: params.returnUrl,
      }),
    );
  }

  // ─── Customer Operations ─────────────────────────────────────────────────

  /**
   * Crea un nuevo customer. Opcionalmente adjunta un metodo de pago.
   */
  async createCustomer(params: {
    email?: string;
    name?: string;
    metadata?: Record<string, string>;
    paymentMethod?: string;
  }): Promise<Stripe.Customer> {
    const customer = await this.execute(() =>
      this.stripe.customers.create({
        email: params.email,
        name: params.name,
        metadata: params.metadata,
      }),
    );

    // Si se proporciono un metodo de pago, adjuntarlo y establecerlo como default
    if (params.paymentMethod) {
      await this.attachPaymentMethod(params.paymentMethod, customer.id);
      await this.setDefaultPaymentMethod(customer.id, params.paymentMethod);
    }

    return customer;
  }

  /**
   * Actualiza un customer existente.
   */
  async updateCustomer(
    id: string,
    params: {
      email?: string;
      name?: string;
      metadata?: Record<string, string>;
      defaultPaymentMethod?: string;
    },
  ): Promise<Stripe.Customer> {
    const updateParams: Stripe.CustomerUpdateParams = {};
    if (params.email !== undefined) updateParams.email = params.email;
    if (params.name !== undefined) updateParams.name = params.name;
    if (params.metadata !== undefined) updateParams.metadata = params.metadata;
    if (params.defaultPaymentMethod !== undefined) {
      updateParams.invoice_settings = { default_payment_method: params.defaultPaymentMethod };
    }

    return this.execute(() =>
      this.stripe.customers.update(id, updateParams),
    );
  }

  /**
   * Recupera un customer por ID con expansion opcional.
   */
  async retrieveCustomer(
    id: string,
    expand?: string[],
  ): Promise<Stripe.Customer | Stripe.DeletedCustomer> {
    return this.execute(() =>
      this.stripe.customers.retrieve(id, {
        expand: expand,
      }),
    );
  }

  /**
   * Lista customers con paginacion y filtro opcional por email.
   */
  async listCustomers(params?: {
    limit?: number;
    startingAfter?: string;
    email?: string;
  }): Promise<Stripe.ApiList<Stripe.Customer>> {
    return this.execute(() =>
      this.stripe.customers.list({
        limit: params?.limit ?? 10,
        starting_after: params?.startingAfter,
        email: params?.email,
      }),
    );
  }

  /**
   * Busca customers usando la Search API de Stripe (query language).
   * Ejemplo: 'email:"user@example.com"' o 'metadata["plan"]:"enterprise"'
   */
  async searchCustomers(query: string): Promise<Stripe.ApiSearchResult<Stripe.Customer>> {
    return this.execute(() =>
      this.stripe.customers.search({ query }),
    );
  }

  /**
   * Adjunta un PaymentMethod a un Customer.
   */
  async attachPaymentMethod(
    paymentMethodId: string,
    customerId: string,
  ): Promise<Stripe.PaymentMethod> {
    return this.execute(() =>
      this.stripe.paymentMethods.attach(paymentMethodId, { customer: customerId }),
    );
  }

  /**
   * Establece un PaymentMethod como el default para invoices del customer.
   */
  async setDefaultPaymentMethod(
    customerId: string,
    paymentMethodId: string,
  ): Promise<Stripe.Customer> {
    return this.execute(() =>
      this.stripe.customers.update(customerId, {
        invoice_settings: { default_payment_method: paymentMethodId },
      }),
    );
  }

  // ─── Connect Operations ──────────────────────────────────────────────────

  /**
   * Crea una cuenta conectada (Connected Account) para plataformas de marketplace.
   * Soporta cuentas Standard, Express, y Custom.
   *
   * Para el nuevo flujo de onboarding (controller-based), usar el parametro controller.
   */
  async createConnectedAccount(params: {
    type?: 'standard' | 'express' | 'custom';
    country?: string;
    email?: string;
    capabilities?: Record<string, { requested: boolean }>;
    businessType?: 'individual' | 'company' | 'non_profit' | 'government_entity';
    controller?: {
      fees?: { payer: 'application' | 'account' };
      losses?: { payments: 'application' | 'stripe' };
      stripeDashboard?: { type: 'express' | 'full' | 'none' };
      requirementCollection?: 'application' | 'stripe';
    };
  }): Promise<Stripe.Account> {
    const createParams: Stripe.AccountCreateParams = {
      type: params.type ?? 'express',
      country: params.country ?? 'US',
      email: params.email,
      capabilities: params.capabilities ?? {
        card_payments: { requested: true },
        transfers: { requested: true },
      },
      business_type: params.businessType,
    };

    if (params.controller) {
      createParams.controller = {
        fees: params.controller.fees,
        losses: params.controller.losses,
        stripe_dashboard: params.controller.stripeDashboard,
        requirement_collection: params.controller.requirementCollection,
      } as any;
    }

    return this.execute(() =>
      this.stripe.accounts.create(createParams),
    );
  }

  /**
   * Crea un Account Link para el flujo de onboarding de cuentas conectadas.
   * El usuario sera redirigido a Stripe para completar la verificacion.
   */
  async createAccountLink(params: {
    account: string;
    refreshUrl: string;
    returnUrl: string;
    type?: 'account_onboarding' | 'account_update';
  }): Promise<Stripe.AccountLink> {
    return this.execute(() =>
      this.stripe.accountLinks.create({
        account: params.account,
        refresh_url: params.refreshUrl,
        return_url: params.returnUrl,
        type: params.type ?? 'account_onboarding',
      }),
    );
  }

  /**
   * Crea un cargo directo: el PaymentIntent se crea en la cuenta conectada.
   * La plataforma cobra un application_fee_amount.
   * Usa el header Stripe-Account para operar como la cuenta conectada.
   */
  async createDirectCharge(params: {
    amount: number;
    currency: string;
    customer: string;
    paymentMethod: string;
    connectedAccountId: string;
    applicationFeeAmount?: number;
    idempotencyKey?: string;
  }): Promise<Stripe.PaymentIntent> {
    return this.execute(() =>
      this.stripe.paymentIntents.create(
        {
          amount: params.amount,
          currency: params.currency,
          customer: params.customer,
          payment_method: params.paymentMethod,
          application_fee_amount: params.applicationFeeAmount,
          automatic_payment_methods: { enabled: true },
        },
        {
          stripeAccount: params.connectedAccountId,
          ...(params.idempotencyKey ? { idempotencyKey: params.idempotencyKey } : {}),
        },
      ),
    );
  }

  /**
   * Crea un cargo de destino: el PaymentIntent se crea en la plataforma
   * y los fondos se transfieren automaticamente a la cuenta conectada.
   */
  async createDestinationCharge(params: {
    amount: number;
    currency: string;
    customer?: string;
    paymentMethod?: string;
    destination: string;
    applicationFeeAmount?: number;
    idempotencyKey?: string;
  }): Promise<Stripe.PaymentIntent> {
    return this.execute(() =>
      this.stripe.paymentIntents.create(
        {
          amount: params.amount,
          currency: params.currency,
          customer: params.customer,
          payment_method: params.paymentMethod,
          application_fee_amount: params.applicationFeeAmount,
          transfer_data: { destination: params.destination },
          automatic_payment_methods: { enabled: true },
        },
        params.idempotencyKey ? { idempotencyKey: params.idempotencyKey } : undefined,
      ),
    );
  }

  /**
   * Crea una transferencia manual a una cuenta conectada.
   * Util para transferencias separadas del flujo de pago (separate charges and transfers).
   */
  async createTransfer(params: {
    amount: number;
    currency: string;
    destination: string;
    transferGroup?: string;
    sourceTransaction?: string;
  }): Promise<Stripe.Transfer> {
    return this.execute(() =>
      this.stripe.transfers.create({
        amount: params.amount,
        currency: params.currency,
        destination: params.destination,
        transfer_group: params.transferGroup,
        source_transaction: params.sourceTransaction,
      }),
    );
  }

  // ─── Webhook Operations ──────────────────────────────────────────────────

  /**
   * Verifica la firma de un webhook y construye el evento.
   * Lanza un error si la firma es invalida.
   *
   * @param payload - El body raw del request (string o Buffer)
   * @param signature - El header 'stripe-signature' del request
   * @param secret - El webhook signing secret (whsec_xxx)
   */
  verifyWebhookSignature(
    payload: string | Buffer,
    signature: string,
    secret: string,
  ): Stripe.Event {
    return this.stripe.webhooks.constructEvent(payload, signature, secret);
  }

  /**
   * Alias de verifyWebhookSignature para consistencia con la documentacion de Stripe.
   */
  constructEvent(
    payload: string | Buffer,
    signature: string,
    secret: string,
  ): Stripe.Event {
    return this.stripe.webhooks.constructEvent(payload, signature, secret);
  }

  // ─── Product & Price Operations ──────────────────────────────────────────

  /**
   * Crea un producto en Stripe. Los productos son el contenedor para los precios.
   */
  async createProduct(params: {
    name: string;
    description?: string;
    metadata?: Record<string, string>;
    defaultPriceData?: {
      unitAmount: number;
      currency: string;
      recurring?: { interval: 'day' | 'week' | 'month' | 'year' };
    };
  }): Promise<Stripe.Product> {
    const createParams: Stripe.ProductCreateParams = {
      name: params.name,
      description: params.description,
      metadata: params.metadata,
    };

    if (params.defaultPriceData) {
      createParams.default_price_data = {
        unit_amount: params.defaultPriceData.unitAmount,
        currency: params.defaultPriceData.currency,
        recurring: params.defaultPriceData.recurring,
      };
    }

    return this.execute(() =>
      this.stripe.products.create(createParams),
    );
  }

  /**
   * Crea un precio para un producto existente.
   * Soporta precios unicos y recurrentes.
   */
  async createPrice(params: {
    product: string;
    unitAmount: number;
    currency: string;
    recurring?: { interval: 'day' | 'week' | 'month' | 'year'; intervalCount?: number };
    lookupKey?: string;
    transferLookupKey?: boolean;
  }): Promise<Stripe.Price> {
    return this.execute(() =>
      this.stripe.prices.create({
        product: params.product,
        unit_amount: params.unitAmount,
        currency: params.currency,
        recurring: params.recurring,
        lookup_key: params.lookupKey,
        transfer_lookup_key: params.transferLookupKey,
      }),
    );
  }

  /**
   * Migra un precio existente a un nuevo monto, transfiriendo el lookup_key.
   * Esto permite cambiar el precio sin actualizar las referencias en el codigo.
   *
   * El precio viejo pierde el lookup_key y el nuevo lo obtiene automaticamente
   * gracias a transfer_lookup_key: true.
   *
   * @example
   *   await helper.migratePrice({
   *     oldPriceId: 'price_old_xxx',
   *     newUnitAmount: 2500,
   *     currency: 'usd',
   *     lookupKey: 'pro_monthly',
   *   });
   */
  async migratePrice(params: {
    oldPriceId: string;
    newUnitAmount: number;
    currency: string;
    lookupKey: string;
  }): Promise<Stripe.Price> {
    // Recuperar el precio viejo para obtener el producto y recurrencia
    const oldPrice = await this.execute(() =>
      this.stripe.prices.retrieve(params.oldPriceId),
    );

    const product = typeof oldPrice.product === 'string' ? oldPrice.product : oldPrice.product.id;

    return this.createPrice({
      product,
      unitAmount: params.newUnitAmount,
      currency: params.currency,
      recurring: oldPrice.recurring
        ? { interval: oldPrice.recurring.interval, intervalCount: oldPrice.recurring.interval_count }
        : undefined,
      lookupKey: params.lookupKey,
      transferLookupKey: true,
    });
  }

  // ─── Diagnostics ─────────────────────────────────────────────────────────

  /** Retorna estadisticas del circuit breaker. */
  getCircuitBreakerStats(): CircuitBreakerStats {
    return this.circuitBreaker.getStats();
  }
}


// ═══════════════════════════════════════════════════════════════════════════════
// IdempotentEventProcessor
// ═══════════════════════════════════════════════════════════════════════════════


/**
 * Procesador de eventos idempotente para webhooks de Stripe.
 *
 * Mantiene un cache en memoria de eventos ya procesados para evitar
 * procesamiento duplicado (Stripe puede enviar el mismo evento multiples veces).
 *
 * Incluye TTL automatico para limpiar eventos viejos y evitar memory leaks.
 *
 * @example
 *   const processor = new IdempotentEventProcessor({ ttlMs: 3600000 }); // 1 hora
 *   const result = await processor.processEvent(event, async (evt) => {
 *     if (evt.type === 'checkout.session.completed') {
 *       await fulfillOrder(evt.data.object);
 *     }
 *   });
 *   // result.processed === true si fue procesado, false si ya habia sido visto
 */
class IdempotentEventProcessor {
  private processedEvents: Map<string, { timestamp: number; result: string }>;
  private readonly ttlMs: number;

  constructor(options?: { ttlMs?: number }) {
    this.processedEvents = new Map();
    this.ttlMs = options?.ttlMs ?? 3_600_000; // Default: 1 hora
  }

  /**
   * Procesa un evento de webhook de forma idempotente.
   * Si el evento ya fue procesado (por su ID), se salta.
   */
  async processEvent(
    event: Stripe.Event,
    handler: (event: Stripe.Event) => Promise<void>,
  ): Promise<{ processed: boolean; skipped: boolean; eventId: string }> {
    // Limpiar eventos expirados periodicamente
    this.cleanup();

    // Verificar si ya fue procesado
    if (this.processedEvents.has(event.id)) {
      return { processed: false, skipped: true, eventId: event.id };
    }

    // Procesar el evento
    await handler(event);

    // Registrar como procesado
    this.processedEvents.set(event.id, {
      timestamp: Date.now(),
      result: event.type,
    });

    return { processed: true, skipped: false, eventId: event.id };
  }

  /**
   * Limpia eventos cuyo TTL ha expirado para evitar crecimiento ilimitado del cache.
   */
  private cleanup(): void {
    const now = Date.now();
    const cutoff = now - this.ttlMs;
    for (const [eventId, data] of this.processedEvents) {
      if (data.timestamp < cutoff) {
        this.processedEvents.delete(eventId);
      } else {
        // El Map mantiene orden de insercion; si encontramos uno no expirado,
        // los siguientes tampoco lo estan
        break;
      }
    }
  }

  /** Retorna estadisticas del procesador. */
  getStats(): { totalProcessed: number; cacheSize: number } {
    return {
      totalProcessed: this.processedEvents.size,
      cacheSize: this.processedEvents.size,
    };
  }
}


// ═══════════════════════════════════════════════════════════════════════════════
// CLI Interface
// ═══════════════════════════════════════════════════════════════════════════════


/**
 * Parser de argumentos minimalista sin dependencias externas.
 * Soporta --key value y --flag (sin valor, se interpreta como 'true').
 */
function parseArgs(argv: string[]): Record<string, string> {
  const parsed: Record<string, string> = {};
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg.startsWith('--')) {
      const key = arg.slice(2);
      const nextArg = argv[i + 1];
      if (nextArg !== undefined && !nextArg.startsWith('--')) {
        parsed[key] = nextArg;
        i++;
      } else {
        parsed[key] = 'true';
      }
    }
  }
  return parsed;
}

/**
 * Imprime el resultado en formato JSON o tabla.
 */
function printResult(data: unknown, format: 'json' | 'table' = 'json'): void {
  if (format === 'table' && typeof data === 'object' && data !== null) {
    if (Array.isArray(data)) {
      console.table(
        data.map((item) => {
          if (typeof item === 'object' && item !== null) {
            const flat: Record<string, unknown> = {};
            for (const [k, v] of Object.entries(item)) {
              flat[k] = typeof v === 'object' ? JSON.stringify(v) : v;
            }
            return flat;
          }
          return item;
        }),
      );
    } else {
      const flat: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(data as Record<string, unknown>)) {
        flat[k] = typeof v === 'object' ? JSON.stringify(v) : v;
      }
      console.table(flat);
    }
  } else {
    console.log(JSON.stringify(data, null, 2));
  }
}

/**
 * Imprime la ayuda del CLI con todas las acciones soportadas.
 */
function printHelp(): void {
  const help = `
stripe_helper.ts -- Stripe API helper con circuit breaker y retry logic.

Usage:
  npx tsx stripe_helper.ts --action <action> [options]

Actions:
  --- Payments -------------------------------------------------------
  create-payment-intent    --amount <int> --currency <str> [--customer <str>]
  capture-payment          --payment-intent <str> [--amount <int>]
  refund                   --payment-intent <str> [--amount <int>] [--reason <str>]

  --- Checkout -------------------------------------------------------
  create-checkout-session  --price <str> --mode <payment|subscription|setup>
                           [--success-url <str>] [--cancel-url <str>]

  --- Subscriptions --------------------------------------------------
  create-subscription      --customer <str> --price <str> [--trial-days <int>]
  cancel-subscription      --subscription <str> [--at-period-end]

  --- Customers ------------------------------------------------------
  create-customer          [--email <str>] [--name <str>]
  list-customers           [--limit <int>] [--email <str>]
  search-customers         --query <str>

  --- Connect --------------------------------------------------------
  create-connected-account [--type <str>] [--country <str>] [--email <str>]
  create-account-link      --account <str> --return-url <str> --refresh-url <str>

  --- Products & Prices ----------------------------------------------
  create-product           --name <str> [--description <str>]
  create-price             --product <str> --unit-amount <int> --currency <str>
                           [--interval <day|week|month|year>]

  --- Webhooks -------------------------------------------------------
  verify-webhook           --payload <str> --signature <str> --secret <str>

  --- Utilities ------------------------------------------------------
  format-amount            --amount <int> --currency <str>
                           [--direction <to-smallest|from-smallest>]
  diagnostics              Show circuit breaker stats

Global Options:
  --format <json|table>    Output format (default: json)
  --key <str>              Stripe secret key (default: STRIPE_SECRET_KEY env var)
`;
  console.log(help.trim());
}

/**
 * Punto de entrada del CLI.
 */
async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));

  if (!args.action) {
    printHelp();
    process.exit(0);
  }

  const format = (args.format as 'json' | 'table') || 'json';

  // Acciones de utilidad que no requieren API key
  if (args.action === 'format-amount') {
    const amount = parseInt(args.amount, 10);
    const currency = args.currency || 'usd';
    const direction = args.direction || 'display';

    if (direction === 'to-smallest') {
      printResult({ result: toSmallestUnit(amount, currency), currency, direction }, format);
    } else if (direction === 'from-smallest') {
      printResult({ result: fromSmallestUnit(amount, currency), currency, direction }, format);
    } else {
      printResult({ formatted: formatCurrency(amount, currency), raw: amount, currency }, format);
    }
    return;
  }

  // Todas las demas acciones requieren API key
  const secretKey = args.key || process.env.STRIPE_SECRET_KEY;
  if (!secretKey && args.action !== 'diagnostics') {
    process.stderr.write('Error: STRIPE_SECRET_KEY env var o --key flag requerido\n');
    process.exit(1);
  }

  const helper = new StripeHelper(secretKey!);

  try {
    let result: unknown;

    switch (args.action) {
      // --- Payments ---
      case 'create-payment-intent':
        result = await helper.createPaymentIntent({
          amount: parseInt(args.amount, 10),
          currency: args.currency || 'usd',
          customer: args.customer,
          idempotencyKey: args['idempotency-key'],
        });
        break;

      case 'capture-payment':
        result = await helper.capturePaymentIntent(
          args['payment-intent'],
          args.amount ? { amountToCapture: parseInt(args.amount, 10) } : undefined,
        );
        break;

      case 'refund':
        result = await helper.refundPayment({
          paymentIntent: args['payment-intent'],
          amount: args.amount ? parseInt(args.amount, 10) : undefined,
          reason: args.reason as 'duplicate' | 'fraudulent' | 'requested_by_customer' | undefined,
        });
        break;

      // --- Checkout ---
      case 'create-checkout-session':
        result = await helper.createCheckoutSession({
          mode: (args.mode as 'payment' | 'subscription' | 'setup') || 'payment',
          lineItems: [{ price: args.price, quantity: parseInt(args.quantity || '1', 10) }],
          successUrl: args['success-url'],
          cancelUrl: args['cancel-url'],
          customer: args.customer,
        });
        break;

      // --- Subscriptions ---
      case 'create-subscription':
        result = await helper.createSubscription({
          customer: args.customer,
          items: [{ price: args.price, quantity: args.quantity ? parseInt(args.quantity, 10) : undefined }],
          trialPeriodDays: args['trial-days'] ? parseInt(args['trial-days'], 10) : undefined,
        });
        break;

      case 'cancel-subscription':
        result = await helper.cancelSubscription(args.subscription, {
          cancelAtPeriodEnd: args['at-period-end'] === 'true',
        });
        break;

      // --- Customers ---
      case 'create-customer':
        result = await helper.createCustomer({
          email: args.email,
          name: args.name,
        });
        break;

      case 'list-customers':
        result = await helper.listCustomers({
          limit: args.limit ? parseInt(args.limit, 10) : undefined,
          email: args.email,
        });
        break;

      case 'search-customers':
        result = await helper.searchCustomers(args.query);
        break;

      // --- Connect ---
      case 'create-connected-account':
        result = await helper.createConnectedAccount({
          type: args.type as 'standard' | 'express' | 'custom' | undefined,
          country: args.country,
          email: args.email,
        });
        break;

      case 'create-account-link':
        result = await helper.createAccountLink({
          account: args.account,
          returnUrl: args['return-url'],
          refreshUrl: args['refresh-url'],
        });
        break;

      // --- Products & Prices ---
      case 'create-product':
        result = await helper.createProduct({
          name: args.name,
          description: args.description,
        });
        break;

      case 'create-price':
        result = await helper.createPrice({
          product: args.product,
          unitAmount: parseInt(args['unit-amount'], 10),
          currency: args.currency || 'usd',
          recurring: args.interval
            ? { interval: args.interval as 'day' | 'week' | 'month' | 'year' }
            : undefined,
        });
        break;

      // --- Webhooks ---
      case 'verify-webhook':
        result = helper.verifyWebhookSignature(args.payload, args.signature, args.secret);
        break;

      // --- Diagnostics ---
      case 'diagnostics':
        result = {
          circuitBreaker: helper.getCircuitBreakerStats(),
        };
        break;

      default:
        process.stderr.write(`Accion desconocida: ${args.action}\n`);
        process.stderr.write(`Ejecuta sin --action para ver la ayuda.\n`);
        process.exit(1);
    }

    printResult(result, format);
  } catch (err) {
    if (err instanceof Stripe.errors.StripeError) {
      const errorOutput = {
        error: true,
        type: err.type,
        code: err.code,
        message: err.message,
        requestId: err.requestId,
        statusCode: err.statusCode,
      };
      process.stderr.write(JSON.stringify(errorOutput, null, 2) + '\n');
    } else if (err instanceof CircuitBreakerOpenError) {
      const errorOutput = {
        error: true,
        type: 'CircuitBreakerOpen',
        message: err.message,
        state: err.state,
        failureCount: err.failureCount,
        timeUntilRecoveryMs: err.timeUntilRecoveryMs,
      };
      process.stderr.write(JSON.stringify(errorOutput, null, 2) + '\n');
    } else {
      process.stderr.write(String(err) + '\n');
    }
    process.exit(1);
  }
}


// ═══════════════════════════════════════════════════════════════════════════════
// Exports
// ═══════════════════════════════════════════════════════════════════════════════

export {
  // Clases principales
  StripeHelper,
  CircuitBreaker,
  CircuitBreakerOpenError,
  CircuitBreakerState,
  IdempotentEventProcessor,
  // Funciones de utilidad
  retryWithBackoff,
  toSmallestUnit,
  fromSmallestUnit,
  formatCurrency,
  // Constantes
  ZERO_DECIMAL_CURRENCIES,
  SPECIAL_CURRENCIES,
};

export type { RetryOptions, CircuitBreakerOptions, CircuitBreakerStats };

// Ejecutar CLI si se invoca directamente
if (
  typeof process !== 'undefined' &&
  process.argv[1] &&
  (process.argv[1].endsWith('stripe_helper.ts') || process.argv[1].endsWith('stripe_helper'))
) {
  main().catch((err) => {
    process.stderr.write(`Fatal: ${err}\n`);
    process.exit(1);
  });
}
