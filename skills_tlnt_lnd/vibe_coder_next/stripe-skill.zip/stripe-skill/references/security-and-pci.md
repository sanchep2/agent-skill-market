# Security & PCI — Complete Reference

Covers PCI compliance, API key management, webhook security, CSP configuration, metadata best practices, expanding objects, pagination, and performance optimization for Stripe. API version `2026-01-28.clover`.

## Table of Contents

1. [PCI Compliance](#1-pci-compliance)
2. [API Key Management](#2-api-key-management)
3. [Webhook Security](#3-webhook-security)
4. [CSP Configuration](#4-csp-configuration)
5. [Metadata Security](#5-metadata-security)
6. [Expanding Objects](#6-expanding-objects)
7. [Pagination](#7-pagination)
8. [Performance Optimization](#8-performance-optimization)
9. [Gotchas & Cross-References](#9-gotchas--cross-references)

---

## 1. PCI Compliance

### 1.1 Compliance Levels

Stripe is a **PCI Level 1 Service Provider** — the highest level of certification. Your PCI requirements depend on your integration method:

| Integration | SAQ Level | Questions | Effort |
|-------------|-----------|-----------|--------|
| Checkout (hosted) | **SAQ A** | ~20 | Minimal |
| Checkout (embedded) | **SAQ A** | ~20 | Minimal |
| Payment Element | **SAQ A** | ~20 | Minimal |
| Stripe.js + Elements | **SAQ A** | ~20 | Minimal |
| Direct API (server-side card handling) | **SAQ D** | ~300+ | Extensive |
| Stripe Terminal | **SAQ B-IP** or **SAQ C** | Varies | Moderate |

### 1.2 Decision Tree

```
Do you handle raw card numbers on your server?
├── YES → SAQ D (300+ questions, annual audit)
│         You MUST use PCI-compliant infrastructure
│         Consider migrating to Elements/Checkout
│
└── NO → Do you use Stripe.js/Elements or Checkout?
         ├── YES → SAQ A (~20 questions, self-assessment)
         │         Minimal PCI scope
         │
         └── NO → Do you use iframes or redirects?
                  ├── YES → SAQ A-EP (~140 questions)
                  └── NO → SAQ D
```

### 1.3 Compliance Checklist (SAQ A)

- [ ] Use Stripe.js/Elements or Checkout (card numbers never touch your server)
- [ ] Serve payment pages over HTTPS (TLS 1.2+)
- [ ] Keep Stripe.js loaded from `js.stripe.com` (not self-hosted)
- [ ] Don't log or store card numbers, CVCs, or full track data
- [ ] Use restricted API keys with minimal permissions
- [ ] Rotate API keys periodically
- [ ] Monitor for key leaks (Stripe auto-scans GitHub)
- [ ] Complete SAQ A questionnaire annually
- [ ] Maintain an information security policy

---

## 2. API Key Management

### 2.1 Key Types

| Type | Prefix | Scope | Where to Use |
|------|--------|-------|-------------|
| Publishable | `pk_test_` / `pk_live_` | Client-safe, limited operations | Frontend, Stripe.js |
| Secret | `sk_test_` / `sk_live_` | Full access to all operations | Server only |
| Restricted | `rk_test_` / `rk_live_` | Configurable permissions | Server, CI/CD, MCP |

### 2.2 Restricted Keys

```typescript
// Create restricted key via Dashboard: Developers > API keys > Create restricted key
// Or via API:
const key = await stripe.apiKeys.create({
  name: 'Webhook handler',
  permissions: {
    'customers': 'read',
    'payment_intents': 'read',
    'subscriptions': 'read',
    'webhook_endpoints': 'none',
    'charges': 'read',
  },
});
```

### 2.3 Permission Scopes

| Resource | Permissions |
|----------|-------------|
| Charges | none, read, write |
| Customers | none, read, write |
| Disputes | none, read, write |
| Invoices | none, read, write |
| PaymentIntents | none, read, write |
| Payouts | none, read, write |
| Prices | none, read, write |
| Products | none, read, write |
| Refunds | none, read, write |
| Subscriptions | none, read, write |
| Webhook Endpoints | none, read, write |
| Balance | none, read |

### 2.4 Key Rotation

```typescript
// Step 1: Create new key in Dashboard
// Step 2: Update environment variables / secrets manager
// Step 3: Deploy with new key
// Step 4: Monitor for errors (bad auth)
// Step 5: Revoke old key after confirmation

// Best practice: Use secrets manager (AWS Secrets Manager, Vault, etc.)
// Never store keys in:
// - Source code
// - Git repositories
// - Client-side code
// - Logs
// - Error messages
```

### 2.5 Key Leak Detection

Stripe automatically scans GitHub for leaked API keys and:
1. Revokes the key immediately
2. Emails the account owner
3. Creates a Dashboard notification

**Prevention**:
- Use `.env` files (never committed)
- Use secrets managers in production
- Add `sk_*` to `.gitignore` patterns
- Use pre-commit hooks to scan for secrets

---

## 3. Webhook Security

### 3.1 Transport Security

- Webhook endpoints **must use HTTPS** with TLS 1.2 or higher
- Stripe verifies SSL certificates (no self-signed in production)
- IP allowlisting not recommended (Stripe IPs change) — use signature verification

### 3.2 Signature Verification

Always verify the `stripe-signature` header. See `webhooks.md` for complete implementation per framework.

```typescript
// Core pattern
const event = stripe.webhooks.constructEvent(
  rawBody,    // MUST be raw, unparsed body
  signature,  // stripe-signature header
  secret      // whsec_... endpoint secret
);
```

### 3.3 Replay Attack Prevention

The signature includes a timestamp (`t=`). The SDK rejects events older than **5 minutes** by default:

```typescript
// Custom tolerance (seconds)
const event = stripe.webhooks.constructEvent(
  rawBody, signature, secret,
  300  // 5 minutes (default) — decrease for stricter security
);
```

### 3.4 Endpoint Secret Management

- Test and live modes have **different** endpoint secrets
- Stripe CLI `listen` generates a **temporary** secret
- Store endpoint secrets in environment variables, not code
- Each webhook endpoint has its own secret — don't mix them

---

## 4. CSP Configuration

### 4.1 Required Domains

Content Security Policy headers must allow Stripe's domains:

```
Content-Security-Policy:
  script-src 'self' https://js.stripe.com;
  frame-src 'self' https://js.stripe.com https://hooks.stripe.com;
  connect-src 'self' https://api.stripe.com https://maps.googleapis.com;
  img-src 'self' https://*.stripe.com;
```

### 4.2 Framework-Specific CSP

**Next.js** (`next.config.js`):

```typescript
const nextConfig = {
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'Content-Security-Policy',
            value: [
              "default-src 'self'",
              "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://js.stripe.com",
              "frame-src 'self' https://js.stripe.com https://hooks.stripe.com",
              "connect-src 'self' https://api.stripe.com https://maps.googleapis.com",
              "img-src 'self' https://*.stripe.com data:",
              "style-src 'self' 'unsafe-inline'",
            ].join('; '),
          },
        ],
      },
    ];
  },
};
```

**Express.js** (with helmet):

```typescript
import helmet from 'helmet';

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://js.stripe.com"],
      frameSrc: ["'self'", "https://js.stripe.com", "https://hooks.stripe.com"],
      connectSrc: ["'self'", "https://api.stripe.com", "https://maps.googleapis.com"],
      imgSrc: ["'self'", "https://*.stripe.com", "data:"],
    },
  },
}));
```

**Django** (django-csp):

```python
# settings.py
CSP_SCRIPT_SRC = ("'self'", "https://js.stripe.com")
CSP_FRAME_SRC = ("'self'", "https://js.stripe.com", "https://hooks.stripe.com")
CSP_CONNECT_SRC = ("'self'", "https://api.stripe.com", "https://maps.googleapis.com")
CSP_IMG_SRC = ("'self'", "https://*.stripe.com")
```

### 4.3 Stripe Domains Reference

| Domain | Purpose |
|--------|---------|
| `js.stripe.com` | Stripe.js SDK |
| `api.stripe.com` | API calls from Stripe.js |
| `hooks.stripe.com` | 3DS authentication iframes |
| `maps.googleapis.com` | Address Element autocomplete |
| `*.stripe.com` | Various Stripe assets |

---

## 5. Metadata Security

### 5.1 Limits

| Constraint | Limit |
|------------|-------|
| Maximum keys per object | 50 |
| Key maximum length | 40 characters |
| Value maximum length | 500 characters |
| Character restrictions | No square brackets in keys |
| Storage type | All values stored as strings |

### 5.2 Usage Patterns

```typescript
// Set metadata on creation
const pi = await stripe.paymentIntents.create({
  amount: 2000, currency: 'usd',
  metadata: {
    order_id: 'ORD-12345',
    user_id: 'usr_abc',
    source: 'web_checkout',
  },
});

// Update metadata (merge semantics)
await stripe.paymentIntents.update('pi_xxx', {
  metadata: {
    fulfilled: 'true',           // Add new key
    source: 'mobile_checkout',   // Update existing key
    user_id: '',                 // Delete key (set to empty string)
  },
});
```

### 5.3 Search API

```typescript
// Search objects by metadata
const customers = await stripe.customers.search({
  query: 'metadata["plan"]:"enterprise"',
});

const payments = await stripe.paymentIntents.search({
  query: 'metadata["order_id"]:"ORD-12345"',
});
```

### 5.4 Security Rules

**NEVER store in metadata**:
- Credit card numbers (PAN)
- CVCs or security codes
- Social Security Numbers (SSN)
- Bank account numbers
- Passwords or authentication tokens
- Full dates of birth
- Any PII governed by HIPAA, GDPR, or similar

**Safe to store**:
- Internal IDs (order, user, session)
- Status flags
- Feature flags
- Non-sensitive business data
- References to external systems

---

## 6. Expanding Objects

### 6.1 How Expansions Work

Replace related object IDs with full objects in API responses:

```typescript
// Without expansion — customer is just an ID
const pi = await stripe.paymentIntents.retrieve('pi_xxx');
// pi.customer === 'cus_abc123' (string)

// With expansion — customer is full object
const pi = await stripe.paymentIntents.retrieve('pi_xxx', {
  expand: ['customer'],
});
// pi.customer === { id: 'cus_abc123', email: '...', ... } (object)
```

### 6.2 Expansion Rules

| Rule | Example |
|------|---------|
| Max 4 levels deep | `expand: ['a.b.c.d']` — 4 levels max |
| List endpoints prefix with `data.` | `expand: ['data.customer']` |
| Multiple expansions allowed | `expand: ['customer', 'latest_charge']` |
| Nested expansion | `expand: ['latest_charge.balance_transaction']` |
| Webhook events NOT expandable | Events always sent in minimal form |

### 6.3 Common Expansions

```typescript
// PaymentIntent with customer and charge
const pi = await stripe.paymentIntents.retrieve('pi_xxx', {
  expand: ['customer', 'latest_charge', 'latest_charge.balance_transaction'],
});

// Subscription with invoice and payment intent
const sub = await stripe.subscriptions.retrieve('sub_xxx', {
  expand: [
    'latest_invoice',
    'latest_invoice.payment_intent',
    'default_payment_method',
    'items.data.price.product',
  ],
});

// Invoice list with subscriptions
const invoices = await stripe.invoices.list({
  customer: 'cus_xxx',
  expand: ['data.subscription', 'data.charge'],
});
```

### 6.4 Performance Impact

- Each expansion adds data to the response (larger payloads)
- Deep expansions may trigger additional internal API calls
- Excessive expansions can contribute to rate limiting
- Only expand what you need — don't expand everything "just in case"

---

## 7. Pagination

### 7.1 List Pagination

```typescript
// Basic list
const customers = await stripe.customers.list({
  limit: 100,                            // 1-100, default 10
  starting_after: 'cus_xxx',             // Cursor: after this ID
  // OR
  ending_before: 'cus_yyy',             // Cursor: before this ID (mutually exclusive)
});

// Response
// customers.data: Stripe.Customer[]
// customers.has_more: boolean
// customers.url: string

// Manual pagination
let hasMore = true;
let startingAfter: string | undefined;

while (hasMore) {
  const page = await stripe.customers.list({
    limit: 100,
    ...(startingAfter && { starting_after: startingAfter }),
  });
  for (const customer of page.data) {
    await processCustomer(customer);
  }
  hasMore = page.has_more;
  if (page.data.length > 0) {
    startingAfter = page.data[page.data.length - 1].id;
  }
}
```

### 7.2 Auto-Pagination (Recommended)

```typescript
// Async iterator (Node.js)
for await (const customer of stripe.customers.list({ limit: 100 })) {
  await processCustomer(customer);
}

// Collect all
const all = await stripe.customers.list({ limit: 100 })
  .autoPagingToArray({ limit: 10000 });

// Python
for customer in stripe.Customer.list(limit=100).auto_paging_iter():
    process(customer)

# Python async
async for customer in await stripe.Customer.list_async(limit=100).auto_paging_iter():
    await process(customer)

# Ruby
Stripe::Customer.list(limit: 100).auto_paging_each do |customer|
  process(customer)
end
```

### 7.3 Search API Pagination

Different from list pagination — uses `page` cursor:

```typescript
let nextPage: string | undefined;

do {
  const result = await stripe.customers.search({
    query: 'metadata["plan"]:"pro"',
    limit: 100,
    ...(nextPage && { page: nextPage }),
  });

  for (const customer of result.data) {
    await processCustomer(customer);
  }

  nextPage = result.next_page ?? undefined;
} while (nextPage);
```

**Search API limits**: Max 20 reads/second. Use list + filters when possible for higher throughput.

---

## 8. Performance Optimization

### 8.1 Client Reuse (Singleton)

```typescript
// GOOD: Single instance, connection pool reused
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  maxNetworkRetries: 2,
  timeout: 30000,
});

// BAD: New instance per request — wastes connections
app.post('/pay', (req, res) => {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!); // Don't do this
});
```

### 8.2 Expand Wisely

```typescript
// GOOD: Expand only what you need
const pi = await stripe.paymentIntents.retrieve('pi_xxx', {
  expand: ['customer'],  // Only need customer email
});

// BAD: Over-expanding
const pi = await stripe.paymentIntents.retrieve('pi_xxx', {
  expand: [
    'customer', 'latest_charge', 'latest_charge.balance_transaction',
    'latest_charge.refunds', 'payment_method',  // Don't expand everything
  ],
});
```

### 8.3 Webhook-Based Caching

```typescript
// Cache products and prices, invalidate via webhooks
const priceCache = new Map<string, Stripe.Price>();

// Webhook handler
switch (event.type) {
  case 'price.created':
  case 'price.updated':
    const price = event.data.object as Stripe.Price;
    priceCache.set(price.id, price);
    break;
  case 'price.deleted':
    priceCache.delete((event.data.object as Stripe.Price).id);
    break;
}

// API route
async function getPrice(priceId: string): Promise<Stripe.Price> {
  if (priceCache.has(priceId)) return priceCache.get(priceId)!;
  const price = await stripe.prices.retrieve(priceId);
  priceCache.set(priceId, price);
  return price;
}
```

### 8.4 Webhook Timeout

Return 200 within **20 seconds** (Stripe's timeout). Process events asynchronously:

```typescript
// GOOD: Return immediately, process async
app.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const event = stripe.webhooks.constructEvent(req.body, sig, secret);
  res.json({ received: true });           // Return 200 immediately
  processEventAsync(event);               // Background processing
});

// BAD: Long processing before responding
app.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const event = stripe.webhooks.constructEvent(req.body, sig, secret);
  await heavyProcessing(event);           // May timeout!
  res.json({ received: true });           // Too late if >20s
});
```

### 8.5 Serialized Mutations

```typescript
// Serialize mutations on the same object to avoid lock_timeout
// BAD: Concurrent updates
await Promise.all([
  stripe.paymentIntents.update('pi_xxx', { metadata: { a: '1' } }),
  stripe.paymentIntents.update('pi_xxx', { metadata: { b: '2' } }),
]); // One will get 429 lock_timeout

// GOOD: Sequential updates
await stripe.paymentIntents.update('pi_xxx', { metadata: { a: '1' } });
await stripe.paymentIntents.update('pi_xxx', { metadata: { b: '2' } });

// BEST: Single update with all changes
await stripe.paymentIntents.update('pi_xxx', { metadata: { a: '1', b: '2' } });
```

---

## 9. Gotchas & Cross-References

### Security Gotchas

1. **Never self-host Stripe.js** — Always load from `js.stripe.com`. Self-hosting breaks PCI compliance and prevents security updates.
2. **Secret keys are server-only** — Never expose `sk_*` in client-side code, logs, or error messages.
3. **Stripe scans GitHub for leaked keys** — Keys are auto-revoked. Use `.env` and secrets managers.
4. **Webhook secrets are environment-specific** — Test and live have different `whsec_` values. CLI generates a temporary one.
5. **Max 4 expansion levels** — Deeper expansions silently fail. Design your queries accordingly.
6. **Search API: 20 req/sec limit** — Much lower than list endpoints. Use filters on list when possible.
7. **Metadata values are strings** — Store `"true"` not `true`. Parse on read.
8. **No square brackets in metadata keys** — `metadata["my[key]"]` will fail. Use underscores or dots.

### Cross-References

- For webhook signature verification → `webhooks.md`
- For API key usage in frameworks → `framework-integration.md`
- For error handling patterns → `error-handling-and-rate-limits.md`
- For MCP server security → `agentic-commerce-and-ai.md`
- For rate limit details → `error-handling-and-rate-limits.md`
