# Subscriptions & Billing — Complete Reference

Covers the full Stripe billing stack: Subscription lifecycle, Products & Prices architecture, pricing models (flat, per-seat, metered, tiered), Meters API, billing cycles & proration, Invoices API, Customer Portal, trials & promotions, Stripe Tax, failed payment recovery (dunning), and Credit Grants. API version `2026-01-28.clover`, stripe npm v20.3.1.

## Table of Contents

1. [Subscription Lifecycle](#1-subscription-lifecycle)
2. [Products & Prices Architecture](#2-products--prices-architecture)
3. [Pricing Models](#3-pricing-models)
4. [Meters API — Usage-Based Billing](#4-meters-api--usage-based-billing)
5. [Billing Cycles & Proration](#5-billing-cycles--proration)
6. [Invoices API](#6-invoices-api)
7. [Customer Portal](#7-customer-portal)
8. [Trials, Coupons & Promotions](#8-trials-coupons--promotions)
9. [Stripe Tax](#9-stripe-tax)
10. [Failed Payment Recovery (Dunning)](#10-failed-payment-recovery-dunning)
11. [Credit Grants & Prepaid Balances](#11-credit-grants--prepaid-balances)
12. [Gotchas & Cross-References](#12-gotchas--cross-references)

---

## 1. Subscription Lifecycle

### 1.1 Status Flow (8 Statuses)

```
                        ┌──────────────────────────────────────────────────────────┐
                        │              Subscription Status Machine                  │
                        │                                                          │
                        │  ┌─────────┐    payment    ┌─────────┐                   │
                        │  │incomplete├──succeeds────►│ active  │                   │
                        │  └────┬─────┘              └───┬──┬──┘                   │
                        │       │                        │  │                       │
                        │  23h timeout              fails│  │cancel                │
                        │       │                        │  │                       │
                        │       ▼                        ▼  │                       │
                        │  ┌──────────────┐    ┌──────────┐│                       │
                        │  │ incomplete_  │    │ past_due ││                       │
                        │  │  expired     │    └────┬─────┘│                       │
                        │  │  [terminal]  │         │      │                       │
                        │  └──────────────┘    retries     │                       │
                        │                     exhausted    │                       │
                        │                         │        │                       │
                        │                         ▼        ▼                       │
                        │  ┌────────┐        ┌──────────────┐                      │
                        │  │trialing├──end──►│  canceled     │                     │
                        │  └────────┘        │  [terminal]   │                     │
                        │                    └──────────────┘                      │
                        │                                                          │
                        │  active ──pause──► paused ──resume──► active             │
                        │  active ──config──► unpaid (invoices stay open)           │
                        │                                                          │
                        │  CRITICAL: canceled is TERMINAL — cannot reactivate      │
                        └──────────────────────────────────────────────────────────┘
```

**Status details**:
- `incomplete` — First invoice payment failed. 23-hour window to complete payment before expiration.
- `incomplete_expired` — Terminal. First payment never completed within 23 hours.
- `trialing` — In trial period. No charges until trial ends.
- `active` — Current period paid. The happy path.
- `past_due` — Most recent invoice payment failed. Stripe is retrying (Smart Retries).
- `canceled` — **Terminal. Cannot be reactivated.** Must create a new subscription.
- `unpaid` — Retries exhausted, configured to leave invoices open rather than cancel.
- `paused` — Payment collection paused. Can be resumed.

### 1.2 Creating Subscriptions

```typescript
// Standard subscription
const subscription = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_xxx' }],
  default_payment_method: 'pm_xxx',
  payment_behavior: 'default_incomplete',    // Recommended: handles SCA
  payment_settings: {
    save_default_payment_method: 'on_subscription',
    payment_method_options: {
      card: {
        request_three_d_secure: 'automatic',
      },
    },
  },
  expand: ['latest_invoice.payment_intent'],
});

// Check if payment needs action
const invoice = subscription.latest_invoice as Stripe.Invoice;
const pi = invoice.payment_intent as Stripe.PaymentIntent;
if (pi.status === 'requires_action') {
  // Pass pi.client_secret to frontend for 3DS
} else if (pi.status === 'succeeded') {
  // Subscription active, provision access
}
```

### 1.3 `payment_behavior` Values

| Value | Behavior | Use Case |
|-------|----------|----------|
| `default_incomplete` | PI created in `requires_action`/`requires_payment_method` state | **Recommended** — handles SCA gracefully |
| `allow_incomplete` | Subscription becomes active even if payment pending | Trusting existing customers |
| `error_if_incomplete` | Returns 402 if first payment fails | Strict payment enforcement |
| `pending_if_incomplete` | Stores as pending subscription update | Mid-cycle changes |

### 1.4 Cancellation Patterns

```typescript
// Cancel at period end (reversible)
await stripe.subscriptions.update('sub_xxx', {
  cancel_at_period_end: true,
});

// Undo scheduled cancellation
await stripe.subscriptions.update('sub_xxx', {
  cancel_at_period_end: false,
});

// Cancel immediately
await stripe.subscriptions.cancel('sub_xxx');

// Cancel at specific date
await stripe.subscriptions.update('sub_xxx', {
  cancel_at: Math.floor(Date.now() / 1000) + 30 * 86400, // 30 days from now
});

// Cancel and prorate (give credit for unused time)
await stripe.subscriptions.cancel('sub_xxx', {
  prorate: true,
  invoice_now: true,  // Generate final invoice immediately
});
```

### 1.5 Pause / Resume

```typescript
// Pause payment collection (subscription stays active-ish)
await stripe.subscriptions.update('sub_xxx', {
  pause_collection: {
    behavior: 'void',           // 'void' (skip invoices) | 'keep_as_draft' | 'mark_uncollectible'
    resumes_at: timestamp,      // Optional: auto-resume date
  },
});

// Resume from void pause
await stripe.subscriptions.update('sub_xxx', {
  pause_collection: '',  // Empty string clears pause
});

// True pause (status becomes 'paused') — newer API
// POST /v1/subscriptions/:id/pause
await stripe.subscriptions.pause('sub_xxx');

// Resume from true pause
// POST /v1/subscriptions/:id/resume
await stripe.subscriptions.resume('sub_xxx', {
  billing_cycle_anchor: 'now',  // Reset billing to resume date
});
```

---

## 2. Products & Prices Architecture

### 2.1 Product/Price Model

Products represent what you sell. Prices represent how much and how often you charge.

```typescript
// Create product
const product = await stripe.products.create({
  name: 'Pro Plan',
  description: 'Full access to all features',
  metadata: { tier: 'pro' },
  default_price_data: {
    unit_amount: 2900,
    currency: 'usd',
    recurring: { interval: 'month' },
  },
  marketing_features: [
    { name: 'Unlimited projects' },
    { name: 'Priority support' },
    { name: 'API access' },
  ],
});

// Create separate price for same product
const annualPrice = await stripe.prices.create({
  product: product.id,
  unit_amount: 29000,          // $290/year (2 months free)
  currency: 'usd',
  recurring: { interval: 'year' },
  lookup_key: 'pro_annual',
});
```

### 2.2 Price Immutability

**Prices are immutable** in `unit_amount`, `currency`, and `recurring.interval`. To change pricing:

```typescript
// Step 1: Create new price with lookup_key transfer
const newPrice = await stripe.prices.create({
  product: 'prod_xxx',
  unit_amount: 3900,                    // New price: $39/mo
  currency: 'usd',
  recurring: { interval: 'month' },
  lookup_key: 'pro_monthly',            // Same key as old price
  transfer_lookup_key: true,            // Transfers key from old price
});

// Step 2: Fetch by lookup_key (always gets latest price)
const prices = await stripe.prices.list({
  lookup_keys: ['pro_monthly'],
  active: true,
});
const currentPrice = prices.data[0];

// Step 3: Migrate existing subscribers (optional)
await stripe.subscriptions.update('sub_xxx', {
  items: [{
    id: 'si_xxx',                       // Existing subscription item
    price: newPrice.id,
  }],
  proration_behavior: 'create_prorations',
});
```

### 2.3 Archive vs Delete

```typescript
// Archive price (can't be used for new subs, existing subs continue)
await stripe.prices.update('price_xxx', { active: false });

// Archive product (archives all prices too)
await stripe.products.update('prod_xxx', { active: false });

// Products and prices cannot be deleted if they have any associated resources
```

---

## 3. Pricing Models

### 3.1 Flat Rate

```typescript
const price = await stripe.prices.create({
  product: 'prod_xxx',
  unit_amount: 2900,
  currency: 'usd',
  recurring: { interval: 'month' },
});
```

### 3.2 Per-Seat (Quantity-Based)

```typescript
// Create with initial seats
const sub = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_per_seat', quantity: 5 }],
});

// Add seats (prorated by default)
await stripe.subscriptionItems.update('si_xxx', { quantity: 10 });

// Remove seats
await stripe.subscriptionItems.update('si_xxx', {
  quantity: 3,
  proration_behavior: 'create_prorations',
});
```

### 3.3 Tiered Pricing

```typescript
// Graduated tiers: each range charged at its own rate
const graduated = await stripe.prices.create({
  product: 'prod_xxx',
  currency: 'usd',
  recurring: { interval: 'month' },
  billing_scheme: 'tiered',
  tiers_mode: 'graduated',
  tiers: [
    { up_to: 10, unit_amount: 1000 },     // First 10: $10/each
    { up_to: 100, unit_amount: 800 },      // 11-100: $8/each
    { up_to: 'inf', unit_amount: 500 },    // 101+: $5/each
  ],
});

// Volume tiers: ALL units charged at the tier rate reached
const volume = await stripe.prices.create({
  product: 'prod_xxx',
  currency: 'usd',
  recurring: { interval: 'month' },
  billing_scheme: 'tiered',
  tiers_mode: 'volume',
  tiers: [
    { up_to: 10, unit_amount: 1000 },     // 1-10 units: $10/each for ALL
    { up_to: 100, unit_amount: 800 },      // 11-100 units: $8/each for ALL
    { up_to: 'inf', unit_amount: 500 },    // 101+ units: $5/each for ALL
  ],
});

// Tiers with flat fees
const tieredWithFlat = await stripe.prices.create({
  product: 'prod_xxx',
  currency: 'usd',
  recurring: { interval: 'month' },
  billing_scheme: 'tiered',
  tiers_mode: 'graduated',
  tiers: [
    { up_to: 5, unit_amount: 0, flat_amount: 5000 },   // Base: $50 for first 5
    { up_to: 'inf', unit_amount: 1000, flat_amount: 0 }, // $10/each after
  ],
});
```

### 3.4 Metered/Usage-Based (Legacy — via Subscription Items)

```typescript
// Legacy approach: report usage at end of billing period
await stripe.subscriptionItems.createUsageRecord('si_xxx', {
  quantity: 150,
  timestamp: Math.floor(Date.now() / 1000),
  action: 'increment',  // or 'set'
});
```

**Note**: Legacy `createUsageRecord`/`listUsageRecordSummaries` removed in Basil. Use the Meters API (section 4) for new integrations.

---

## 4. Meters API — Usage-Based Billing

GA since April 2024. The modern approach to usage-based billing with real-time event ingestion.

### 4.1 Create a Meter

```typescript
// Via API (or Dashboard: Billing > Meters)
const meter = await stripe.billing.meters.create({
  display_name: 'API Calls',
  event_name: 'api_calls',              // Unique event identifier
  default_aggregation: {
    formula: 'sum',                      // 'sum' | 'count' | 'last'
  },
  customer_mapping: {
    type: 'by_id',                       // Uses stripe_customer_id in payload
    event_payload_key: 'stripe_customer_id',
  },
  value_settings: {
    event_payload_key: 'value',          // Key in payload containing the value
  },
});

// Create a price linked to the meter
const price = await stripe.prices.create({
  product: 'prod_xxx',
  currency: 'usd',
  recurring: {
    interval: 'month',
    usage_type: 'metered',
    meter: meter.id,
  },
  unit_amount: 1,                        // $0.01 per API call
  // OR use tiers for volume discounts
});
```

### 4.2 Report Usage Events

```typescript
// Single event
await stripe.billing.meterEvents.create({
  event_name: 'api_calls',
  payload: {
    value: '150',                        // String value
    stripe_customer_id: 'cus_xxx',
  },
  timestamp: Math.floor(Date.now() / 1000),
});

// High-throughput: Batch meter event stream (10,000 events/sec)
// Use the meter event stream endpoint for high volume
await stripe.v2.billing.meterEventSession.create({});
// Then stream events to the session endpoint
```

**Rate limits**: Standard: 1,000 events/second. High-throughput stream: 10,000 events/second. Events can be sent up to 24 hours after occurrence.

### 4.3 Query Usage

```typescript
// Get aggregated usage for a customer
const summary = await stripe.billing.meters.listEventSummaries(meter.id, {
  customer: 'cus_xxx',
  start_time: Math.floor(Date.now() / 1000) - 86400 * 30,
  end_time: Math.floor(Date.now() / 1000),
  value_grouping_window: 'day',          // 'hour' | 'day'
});

for (const bucket of summary.data) {
  console.log(`${bucket.start_time}: ${bucket.aggregated_value} calls`);
}
```

### 4.4 Dimensional Pricing (Preview)

Bill different rates based on event attributes:

```typescript
// Example: Different rates for different AI models
await stripe.billing.meterEvents.create({
  event_name: 'ai_tokens',
  payload: {
    value: '1000',
    stripe_customer_id: 'cus_xxx',
    model: 'gpt-4',                      // Dimension for pricing
  },
});
// Pricing tiers can vary by the 'model' dimension
```

### 4.5 Subscription with Metered Price

```typescript
const sub = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [
    { price: 'price_base_monthly' },     // Fixed base fee
    { price: 'price_metered_api_calls' }, // Usage-based component
  ],
});
// Meter events accumulate during billing period
// Invoice at period end includes both fixed + usage charges
```

---

## 5. Billing Cycles & Proration

### 5.1 Billing Cycle Anchor

```typescript
// Set anchor to specific date
const sub = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_xxx' }],
  billing_cycle_anchor: Math.floor(new Date('2026-03-01').getTime() / 1000),
});

// Reset anchor to now
await stripe.subscriptions.update('sub_xxx', {
  billing_cycle_anchor: 'now',
  proration_behavior: 'create_prorations',
});
```

**Edge case**: Monthly sub anchored to 31st bills on last available day (Feb 28, Mar 31, Apr 30, etc.).

### 5.2 Proration Behavior

| Value | Behavior | When to Use |
|-------|----------|-------------|
| `create_prorations` | Prorated credit/charge added to next invoice (default) | Most plan changes |
| `always_invoice` | Proration created AND immediately invoiced | Immediate billing for upgrades |
| `none` | New price applies from next period only | Downgrades effective next period |

```typescript
// Upgrade with immediate billing
await stripe.subscriptions.update('sub_xxx', {
  items: [{ id: 'si_xxx', price: 'price_higher' }],
  proration_behavior: 'always_invoice',
});

// Preview proration before applying
const upcoming = await stripe.invoices.retrieveUpcoming({
  customer: 'cus_xxx',
  subscription: 'sub_xxx',
  subscription_items: [{ id: 'si_xxx', price: 'price_higher' }],
  subscription_proration_behavior: 'create_prorations',
});
console.log(`Proration amount: ${upcoming.amount_due}`);
```

### 5.3 Interval Switching (Monthly → Annual)

When switching from monthly to annual:
1. Unused time on monthly plan is credited
2. Full annual price is charged immediately
3. Billing anchor resets to now

```typescript
// Monthly to annual upgrade
await stripe.subscriptions.update('sub_xxx', {
  items: [{
    id: 'si_xxx',
    price: 'price_annual',
  }],
  proration_behavior: 'always_invoice',
  billing_cycle_anchor: 'now',
});
```

---

## 6. Invoices API

### 6.1 Invoice Status Flow

```
draft → open → paid / void / uncollectible
         │
         └──► payment_failed → (retry) → paid
```

- `draft` — Editable. Add/remove line items.
- `open` — Finalized. Payment pending or attempted.
- `paid` — Successfully paid. Terminal.
- `void` — Canceled. Terminal. Cannot be undone.
- `uncollectible` — Marked as bad debt. Can be re-opened.

### 6.2 One-Off Invoices

```typescript
// Add invoice items (not attached to subscription)
await stripe.invoiceItems.create({
  customer: 'cus_xxx',
  price: 'price_xxx',
  quantity: 2,
});

await stripe.invoiceItems.create({
  customer: 'cus_xxx',
  amount: 5000,                          // Custom amount
  currency: 'usd',
  description: 'Consulting — 2 hours',
});

// Create and finalize invoice
const invoice = await stripe.invoices.create({
  customer: 'cus_xxx',
  collection_method: 'charge_automatically', // or 'send_invoice'
  days_until_due: 30,                        // For send_invoice method
  auto_advance: true,
});

await stripe.invoices.finalizeInvoice(invoice.id);

// For send_invoice: send the invoice email
await stripe.invoices.sendInvoice(invoice.id);
```

### 6.3 Invoice Properties

Every finalized invoice has:
- `hosted_invoice_url` — Stripe-hosted payment page
- `invoice_pdf` — Downloadable PDF URL
- `number` — Human-readable invoice number (e.g., `INV-0001`)
- `status` — Current status
- `amount_due` — Amount to collect
- `amount_paid` — Amount already paid
- `amount_remaining` — Outstanding balance

### 6.4 Preview Upcoming Invoice

```typescript
// Preview what the next invoice will look like
const upcoming = await stripe.invoices.retrieveUpcoming({
  customer: 'cus_xxx',
});

// Preview with proposed changes
const preview = await stripe.invoices.retrieveUpcoming({
  customer: 'cus_xxx',
  subscription: 'sub_xxx',
  subscription_items: [{
    id: 'si_xxx',
    price: 'price_new',              // Proposed new price
  }],
});

console.log(`Next invoice: ${preview.amount_due / 100} ${preview.currency}`);
for (const item of preview.lines.data) {
  console.log(`  ${item.description}: ${item.amount / 100}`);
}
```

### 6.5 Credit Notes

```typescript
// Issue credit note against an invoice
const creditNote = await stripe.creditNotes.create({
  invoice: 'in_xxx',
  lines: [{
    type: 'invoice_line_item',
    invoice_line_item: 'il_xxx',
    quantity: 1,
  }],
  reason: 'product_unsatisfactory', // or 'duplicate', 'fraudulent', 'order_change'
  memo: 'Refund for defective item',
});
// Credit notes can apply to customer balance or trigger refund
```

### 6.6 `auto_advance` and Webhook Timing

When `auto_advance: true` (default):
1. Stripe fires `invoice.created` webhook
2. Waits **~1 hour** for successful webhook response
3. If webhook endpoint fails → delays finalization up to **72 hours**
4. After successful webhook or timeout → finalizes invoice and attempts payment

**Critical**: Ensure your `invoice.created` webhook handler is reliable. Failures delay the entire billing cycle.

---

## 7. Customer Portal

### 7.1 Create Portal Session

```typescript
const session = await stripe.billingPortal.sessions.create({
  customer: 'cus_xxx',
  return_url: 'https://yourapp.com/account',
});
// Redirect to session.url
```

### 7.2 Deep Links to Specific Flows

```typescript
// Direct to cancellation flow
const cancelSession = await stripe.billingPortal.sessions.create({
  customer: 'cus_xxx',
  return_url: 'https://yourapp.com/account',
  flow_data: {
    type: 'subscription_cancel',
    subscription_cancel: { subscription: 'sub_xxx' },
  },
});

// Direct to payment method update
const pmSession = await stripe.billingPortal.sessions.create({
  customer: 'cus_xxx',
  return_url: 'https://yourapp.com/account',
  flow_data: {
    type: 'payment_method_update',
  },
});

// Direct to plan change
const planSession = await stripe.billingPortal.sessions.create({
  customer: 'cus_xxx',
  return_url: 'https://yourapp.com/account',
  flow_data: {
    type: 'subscription_update',
    subscription_update: {
      subscription: 'sub_xxx',
    },
  },
});
```

### 7.3 Portal Configuration

Configure via API or Dashboard (Settings > Billing > Customer portal):

```typescript
const config = await stripe.billingPortal.configurations.create({
  business_profile: {
    headline: 'Manage your subscription',
    privacy_policy_url: 'https://example.com/privacy',
    terms_of_service_url: 'https://example.com/tos',
  },
  features: {
    customer_update: {
      enabled: true,
      allowed_updates: ['email', 'address', 'phone', 'tax_id'],
    },
    payment_method_update: { enabled: true },
    invoice_history: { enabled: true },
    subscription_cancel: {
      enabled: true,
      mode: 'at_period_end',           // or 'immediately'
      cancellation_reason: {
        enabled: true,
        options: ['too_expensive', 'missing_features', 'switched_service',
                  'unused', 'customer_service', 'too_complex', 'low_quality', 'other'],
      },
    },
    subscription_update: {
      enabled: true,
      default_allowed_updates: ['price', 'quantity'],
      products: [{
        product: 'prod_xxx',
        prices: ['price_monthly', 'price_annual'],
      }],
      proration_behavior: 'create_prorations',
    },
  },
});
```

### 7.4 Portal Limitations

- Maximum **10 products** for plan switching
- Cannot embed in iframe
- Modifying a trialing subscription **ends the trial immediately**
- Cannot show custom UI elements inside the portal
- No programmatic control over portal actions (use API + custom UI for complex flows)

---

## 8. Trials, Coupons & Promotions

### 8.1 Free Trials

```typescript
// Trial without payment method
const sub = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_xxx' }],
  trial_period_days: 14,
  trial_settings: {
    end_behavior: {
      missing_payment_method: 'cancel',   // 'cancel' | 'pause' | 'create_invoice'
    },
  },
});

// Trial with payment method required (higher conversion)
const sub2 = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_xxx' }],
  trial_period_days: 14,
  default_payment_method: 'pm_xxx',
  // After trial: automatic charge
});

// Trial until specific date
const sub3 = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_xxx' }],
  trial_end: Math.floor(new Date('2026-04-01').getTime() / 1000),
});
```

**Key event**: `customer.subscription.trial_will_end` fires **3 days** before trial ends — send an email reminder.

**Max trial**: 730 days (2 years).

### 8.2 Coupons

```typescript
// Percentage discount
const percentCoupon = await stripe.coupons.create({
  percent_off: 25,
  duration: 'repeating',
  duration_in_months: 3,
  name: '25% off for 3 months',
  max_redemptions: 100,
  redeem_by: Math.floor(new Date('2026-12-31').getTime() / 1000),
});

// Fixed amount discount
const fixedCoupon = await stripe.coupons.create({
  amount_off: 500,                       // $5.00 off
  currency: 'usd',
  duration: 'once',
  name: '$5 off first month',
});

// Forever discount (never expires)
const foreverCoupon = await stripe.coupons.create({
  percent_off: 10,
  duration: 'forever',
  name: 'Partner 10% discount',
});
```

### 8.3 Promotion Codes (Customer-Facing)

```typescript
// Create promotion code from coupon
const promo = await stripe.promotionCodes.create({
  coupon: percentCoupon.id,
  code: 'SUMMER25',                      // Customer enters this
  restrictions: {
    first_time_transaction: true,        // New customers only
    minimum_amount: 1000,                // $10 minimum
    minimum_amount_currency: 'usd',
  },
  max_redemptions: 50,
  expires_at: Math.floor(new Date('2026-09-01').getTime() / 1000),
});

// Apply to subscription
const sub = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_xxx' }],
  promotion_code: promo.id,
});

// Apply to Checkout Session
const session = await stripe.checkout.sessions.create({
  mode: 'subscription',
  line_items: [{ price: 'price_xxx', quantity: 1 }],
  allow_promotion_codes: true,           // Let customer enter code
  success_url: 'https://example.com/success',
});
```

### 8.4 Stackable Discounts

```typescript
// Apply multiple discounts to a subscription
const sub = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_xxx' }],
  discounts: [
    { coupon: 'coupon_partner_10pct' },
    { promotion_code: 'promo_summer25' },
  ],
});
```

Discounts are applied sequentially (first discount, then second on remaining amount).

---

## 9. Stripe Tax

### 9.1 Enable Automatic Tax

```typescript
// On subscriptions
const sub = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_xxx' }],
  automatic_tax: { enabled: true },
});

// On Checkout Sessions
const session = await stripe.checkout.sessions.create({
  mode: 'payment',
  line_items: [{ price: 'price_xxx', quantity: 1 }],
  automatic_tax: { enabled: true },
  success_url: 'https://example.com/success',
});

// On Invoices
const invoice = await stripe.invoices.create({
  customer: 'cus_xxx',
  automatic_tax: { enabled: true },
});
```

### 9.2 Tax Behavior on Prices

| Behavior | Description | Common Use |
|----------|-------------|------------|
| `exclusive` | Tax added on top of price | US, B2B |
| `inclusive` | Tax included in price | EU B2C, UK |
| `unspecified` | No tax behavior (default) | Non-taxed items |

```typescript
// Create price with tax behavior
const price = await stripe.prices.create({
  product: 'prod_xxx',
  unit_amount: 2900,
  currency: 'usd',
  recurring: { interval: 'month' },
  tax_behavior: 'exclusive',            // Tax added on top
});
```

**Critical**: Cannot change `tax_behavior` after price creation — must create a new price.

### 9.3 Tax Registration and Filing

- Register tax IDs in Stripe Dashboard (Settings > Tax)
- Stripe Tax supports **102 countries** with automatic rate calculation
- Tax reporting available via Dashboard or API
- Filing supported through Stripe Tax partners

### 9.4 Tax Calculation API (Standalone)

```typescript
// Calculate tax without creating a payment
const calculation = await stripe.tax.calculations.create({
  currency: 'usd',
  line_items: [{
    amount: 2000,
    reference: 'item_1',
    tax_behavior: 'exclusive',
    tax_code: 'txcd_10000000',          // General goods
  }],
  customer_details: {
    address: { country: 'US', state: 'CA', postal_code: '94110' },
    address_source: 'shipping',
  },
});
console.log(`Tax: $${calculation.tax_amount_exclusive / 100}`);
```

---

## 10. Failed Payment Recovery (Dunning)

### 10.1 Smart Retries

ML-powered retry optimization using network signals to choose optimal retry timing.

**Default behavior**: 8 retries within 2 weeks. Does NOT retry hard declines (card canceled, doesn't exist). Configure in Dashboard: Billing → Revenue Recovery.

### 10.2 Dunning Flow

```
Invoice Payment Failed
    │
    ├── Smart Retries begin (up to 8 attempts over 2 weeks)
    │
    ├── Email: "Payment failed" (immediate)
    │
    ├── Email: "Update your payment method" (3 days)
    │
    ├── In-app banner: "Payment past due" (display in your app)
    │
    ├── Email: "Final warning" (7 days)
    │
    └── All retries exhausted → configurable outcome:
        ├── Cancel subscription
        ├── Mark as unpaid (invoices stay open)
        └── Leave as past_due
```

### 10.3 Webhook-Based Recovery

```typescript
// Listen for payment failures
switch (event.type) {
  case 'invoice.payment_failed':
    const invoice = event.data.object as Stripe.Invoice;
    const customerId = invoice.customer as string;

    // Check attempt count
    if (invoice.attempt_count === 1) {
      // First failure: gentle notification
      await sendEmail(customerId, 'payment_failed_first');
    } else if (invoice.attempt_count >= 3) {
      // Multiple failures: urgent notification with portal link
      const session = await stripe.billingPortal.sessions.create({
        customer: customerId,
        return_url: 'https://app.example.com/account',
        flow_data: { type: 'payment_method_update' },
      });
      await sendEmail(customerId, 'payment_failed_urgent', { url: session.url });
    }
    break;

  case 'customer.subscription.updated':
    const sub = event.data.object as Stripe.Subscription;
    if (sub.status === 'past_due') {
      // Show in-app banner prompting payment update
      await setAccountFlag(sub.customer as string, 'payment_past_due', true);
    } else if (sub.status === 'active') {
      // Payment recovered — clear banner
      await setAccountFlag(sub.customer as string, 'payment_past_due', false);
    }
    break;

  case 'customer.subscription.deleted':
    const canceled = event.data.object as Stripe.Subscription;
    // Revoke access, send win-back email
    await revokeAccess(canceled.customer as string);
    await sendEmail(canceled.customer as string, 'subscription_canceled_winback');
    break;
}
```

### 10.4 Revenue Recovery Configuration

Configure in Dashboard (Billing → Revenue Recovery):
- **Smart Retries**: On/off, max attempts, retry window
- **Failed payment emails**: Customizable templates
- **Subscription status after exhaustion**: Cancel, mark unpaid, or leave past_due
- **Customer emails**: Payment failure, upcoming renewal, trial ending

---

## 11. Credit Grants & Prepaid Balances

### 11.1 Customer Balance

```typescript
// Add credit to customer balance (negative = credit)
await stripe.customers.createBalanceTransaction('cus_xxx', {
  amount: -5000,                         // $50.00 credit
  currency: 'usd',
  description: 'Referral bonus',
});

// Check balance
const customer = await stripe.customers.retrieve('cus_xxx');
console.log(`Balance: ${customer.balance}`); // Negative = credit owed to customer

// Balance auto-applies to next invoice
```

### 11.2 Credit Grants (Enhanced)

```typescript
// Create credit grant
const grant = await stripe.billing.creditGrants.create({
  customer: 'cus_xxx',
  amount: {
    type: 'monetary',
    monetary: { value: 10000, currency: 'usd' }, // $100 credit
  },
  category: 'promotional',
  effective_at: Math.floor(Date.now() / 1000),
  expires_at: Math.floor(Date.now() / 1000) + 90 * 86400, // 90 days
  name: 'Welcome credit',
  applicability_config: {
    scope: {
      price_type: 'metered',             // Only applies to metered charges
    },
  },
});

// Query real-time balance burn-down
const balance = await stripe.billing.creditBalanceSummary.retrieve({
  customer: 'cus_xxx',
  filter: { type: 'credit_grant', credit_grant: grant.id },
});
```

---

## 12. Gotchas & Cross-References

### Billing Gotchas

1. **Canceled is forever** — `status: 'canceled'` is terminal. Create a new subscription. Use `cancel_at_period_end` for reversible cancellation.
2. **Price immutability** — Cannot modify amount/currency/interval. Create new price with `transfer_lookup_key`.
3. **Trial modification ends trial** — Changing a trialing subscription via Customer Portal ends trial immediately.
4. **invoice.created webhook reliability** — If your webhook fails, invoice finalization delays up to 72 hours.
5. **tax_behavior is immutable** — Cannot change after price creation. Must create a new price.
6. **Meters API replaces legacy usage records** — `createUsageRecord`/`listUsageRecordSummaries` removed in Basil.
7. **Proration on downgrade** — Default prorates immediately. Use `proration_behavior: 'none'` to apply at next period.
8. **billing_cycle_anchor on 31st** — Bills on last day of months with fewer days (Feb 28, Apr 30, etc.).

### Cross-References

- For payment method handling → `payments-and-checkout.md`
- For Connect platform billing → `stripe-connect.md`
- For frontend subscription UI → `elements-and-frontend.md`
- For subscription webhooks → `webhooks.md`
- For framework-specific billing code → `framework-integration.md`
- For billing error handling → `error-handling-and-rate-limits.md`
- For testing subscriptions with Test Clocks → `testing-and-tooling.md`
- For tax and revenue optimization → `stripe-tax-and-revenue.md`
