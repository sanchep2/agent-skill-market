# Webhooks — Complete Reference

Covers the full Stripe webhook system: critical events catalog, signature verification, framework-specific handlers (10+ frameworks), best practices, Event Destinations API, Thin Events, Connect webhooks, and CLI testing. API version `2026-01-28.clover`.

## Table of Contents

1. [Critical Events Catalog](#1-critical-events-catalog)
2. [Signature Verification](#2-signature-verification)
3. [Framework Handlers](#3-framework-handlers)
4. [Best Practices](#4-best-practices)
5. [Event Destinations API & Thin Events](#5-event-destinations-api--thin-events)
6. [Connect Webhooks](#6-connect-webhooks)
7. [CLI Testing](#7-cli-testing)
8. [Production Webhook Architecture](#8-production-webhook-architecture)
9. [Gotchas & Cross-References](#9-gotchas--cross-references)

---

## 1. Critical Events Catalog

### 1.1 Payments

| Event | When | Recommended Action |
|-------|------|-------------------|
| `payment_intent.succeeded` | Payment completed | Fulfill order, send receipt |
| `payment_intent.payment_failed` | Payment failed | Notify customer, suggest retry |
| `payment_intent.canceled` | Payment canceled | Release inventory hold |
| `payment_intent.requires_action` | 3DS/SCA needed | Email customer with payment link |
| `payment_intent.processing` | Bank debit in-flight | Show pending status |
| `payment_intent.amount_capturable_updated` | Manual capture authorized | Capture when ready |

### 1.2 Checkout

| Event | When | Recommended Action |
|-------|------|-------------------|
| `checkout.session.completed` | **Primary fulfillment event** | Provision access, send confirmation |
| `checkout.session.expired` | Session timed out | Release reserved inventory |
| `checkout.session.async_payment_succeeded` | Async PM (ACH/SEPA) completed | Fulfill order |
| `checkout.session.async_payment_failed` | Async PM failed | Notify customer |

### 1.3 Subscriptions

| Event | When | Recommended Action |
|-------|------|-------------------|
| `customer.subscription.created` | New subscription | Initialize access, welcome email |
| `customer.subscription.updated` | Plan/status changed | Update access level, sync DB |
| `customer.subscription.deleted` | Canceled (terminal) | Revoke access, win-back email |
| `customer.subscription.trial_will_end` | 3 days before trial ends | Remind to add payment method |
| `customer.subscription.paused` | Subscription paused | Show pause notice in app |
| `customer.subscription.resumed` | Subscription resumed | Restore access |
| `customer.subscription.pending_update_applied` | Pending change applied | Update access |
| `customer.subscription.pending_update_expired` | Pending change expired | Notify customer |

### 1.4 Invoices

| Event | When | Recommended Action |
|-------|------|-------------------|
| `invoice.created` | Draft invoice created | Add custom line items (within 1 hour) |
| `invoice.finalized` | Invoice ready for payment | Log, generate receipt number |
| `invoice.paid` | **Payment source of truth** | Provision/renew access |
| `invoice.payment_failed` | Payment attempt failed | Notify customer, show banner |
| `invoice.payment_action_required` | SCA required | Email customer with auth link |
| `invoice.upcoming` | ~3 days before next invoice | Preview notification |
| `invoice.marked_uncollectible` | Marked as bad debt | Write off, revoke access |
| `invoice.voided` | Invoice voided | Adjust records |

### 1.5 Disputes

| Event | When | Recommended Action |
|-------|------|-------------------|
| `charge.dispute.created` | Chargeback filed | Alert team, auto-gather evidence |
| `charge.dispute.updated` | Status changed | Track progress |
| `charge.dispute.closed` | Resolution reached | Update records, learn from outcome |
| `charge.refunded` | Charge refunded | Update order status |
| `radar.early_fraud_warning.created` | Pre-dispute signal | Consider proactive refund |

### 1.6 Connect

| Event | When | Recommended Action |
|-------|------|-------------------|
| `account.updated` | Account info changed | Check requirements, capabilities |
| `account.application.deauthorized` | Disconnected from platform | Deactivate seller |
| `payout.failed` | Payout to bank failed | Notify connected account |
| `payout.paid` | Payout succeeded | Confirm to connected account |
| `capability.updated` | Capability status changed | Update account status |

### 1.7 Customers

| Event | When | Recommended Action |
|-------|------|-------------------|
| `customer.created` | New customer | Sync to CRM |
| `customer.updated` | Customer info changed | Sync changes |
| `customer.deleted` | Customer deleted | Clean up records |
| `payment_method.attached` | PM added to customer | Update stored PM info |
| `payment_method.detached` | PM removed | Update UI |

---

## 2. Signature Verification

### 2.1 How It Works

The `stripe-signature` header contains: `t=1672531200,v1=abc123def456...`
- `t` — UNIX timestamp when event was sent
- `v1` — HMAC-SHA256 of `{timestamp}.{raw_body}` using your endpoint secret

### 2.2 Verification Code

```typescript
// Standard verification
const event = stripe.webhooks.constructEvent(
  rawBody,                               // RAW body string/Buffer — NOT parsed JSON
  request.headers['stripe-signature']!,  // stripe-signature header
  process.env.STRIPE_WEBHOOK_SECRET!     // whsec_... from endpoint or CLI
);
```

### 2.3 Manual Verification (Without SDK)

```typescript
import crypto from 'crypto';

function verifyStripeSignature(
  payload: string | Buffer,
  header: string,
  secret: string,
  tolerance: number = 300  // 5 minutes
): boolean {
  const elements = header.split(',');
  const timestamp = elements.find(e => e.startsWith('t='))?.slice(2);
  const signature = elements.find(e => e.startsWith('v1='))?.slice(3);

  if (!timestamp || !signature) return false;

  // Check timestamp tolerance (prevent replay attacks)
  const now = Math.floor(Date.now() / 1000);
  if (now - parseInt(timestamp) > tolerance) return false;

  // Compute expected signature
  const signedPayload = `${timestamp}.${payload}`;
  const expected = crypto
    .createHmac('sha256', secret)
    .update(signedPayload, 'utf8')
    .digest('hex');

  // Constant-time comparison
  return crypto.timingSafeEqual(
    Buffer.from(signature, 'hex'),
    Buffer.from(expected, 'hex')
  );
}
```

### 2.4 Raw Body Access by Framework

**This is the #1 source of webhook bugs.** If the body is parsed as JSON before verification, the signature will NOT match.

| Framework | Raw Body Access | Critical Note |
|-----------|----------------|---------------|
| **Express.js** | `express.raw({ type: 'application/json' })` | Place BEFORE `express.json()` |
| **Next.js App Router** | `await request.text()` | NOT `request.json()` |
| **Next.js Pages Router** | `export const config = { api: { bodyParser: false } }` + `buffer(req)` | Disable body parser |
| **Fastify** | `fastify-raw-body` plugin | Or custom content type parser |
| **Django** | `request.body` | NOT `request.data` |
| **Django REST Framework** | `request.body` | NOT `request.data` (DRF parses) |
| **Flask** | `request.data` or `request.get_data(as_text=True)` | Before any parsing |
| **FastAPI** | `await request.body()` | NOT Pydantic model |
| **Rails** | `request.body.read` | In controller |
| **AWS Lambda** | `event.body` | Decode if `isBase64Encoded` |
| **Vercel Serverless** | `await req.text()` (Edge) or `rawBody` (Node) | Depends on runtime |
| **Cloudflare Workers** | `await request.text()` | Standard Web API |
| **Deno / Supabase Edge** | `await request.text()` | Standard Web API |

---

## 3. Framework Handlers

### 3.1 Express.js

```typescript
import express from 'express';
import Stripe from 'stripe';

const app = express();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET!;

// CRITICAL: Webhook route MUST come BEFORE express.json()
app.post('/webhook',
  express.raw({ type: 'application/json' }),
  async (req, res) => {
    let event: Stripe.Event;
    try {
      event = stripe.webhooks.constructEvent(
        req.body,
        req.headers['stripe-signature']!,
        endpointSecret
      );
    } catch (err) {
      console.error(`Signature verification failed: ${err}`);
      return res.status(400).send(`Webhook Error: ${err}`);
    }

    // Return 200 immediately
    res.json({ received: true });

    // Process asynchronously
    await handleStripeEvent(event);
  }
);

// Regular JSON parsing for all other routes
app.use(express.json());
```

### 3.2 Next.js App Router

```typescript
// app/api/webhooks/stripe/route.ts
import { headers } from 'next/headers';
import { stripe } from '@/lib/stripe';

// Do NOT export runtime = 'edge' — Stripe needs Node.js
export async function POST(req: Request) {
  const body = await req.text();                    // CRITICAL: text, not json
  const headersList = await headers();
  const signature = headersList.get('stripe-signature')!;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    console.error('Webhook signature verification failed');
    return new Response('Invalid signature', { status: 400 });
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        await fulfillOrder(session);
        break;
      }
      case 'invoice.paid': {
        const invoice = event.data.object as Stripe.Invoice;
        await provisionAccess(invoice);
        break;
      }
      case 'customer.subscription.deleted': {
        const sub = event.data.object as Stripe.Subscription;
        await revokeAccess(sub);
        break;
      }
    }
  } catch (err) {
    console.error(`Webhook handler error: ${err}`);
    return new Response('Handler error', { status: 500 });
  }

  return new Response(null, { status: 200 });
}
```

### 3.3 Next.js Pages Router (Legacy)

```typescript
// pages/api/webhook.ts
import { buffer } from 'micro';
import type { NextApiRequest, NextApiResponse } from 'next';

// CRITICAL: Disable body parser
export const config = { api: { bodyParser: false } };

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();

  const buf = await buffer(req);
  const sig = req.headers['stripe-signature']!;

  const event = stripe.webhooks.constructEvent(buf, sig, endpointSecret);
  // Handle event...
  res.json({ received: true });
}
```

### 3.4 Fastify

```typescript
import Fastify from 'fastify';
import rawBody from 'fastify-raw-body';

const fastify = Fastify();
await fastify.register(rawBody, {
  field: 'rawBody',
  global: false,                         // Only on opt-in routes
  encoding: 'utf8',
  runFirst: true,
});

fastify.post('/webhook', {
  config: { rawBody: true },             // Enable for this route
}, async (request, reply) => {
  const event = stripe.webhooks.constructEvent(
    request.rawBody!,
    request.headers['stripe-signature']!,
    endpointSecret
  );
  // Handle event...
  return { received: true };
});
```

### 3.5 Python / Django

```python
# views.py
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
import stripe

@csrf_exempt
@require_POST
def stripe_webhook(request):
    payload = request.body                # Raw body — NOT request.POST
    sig_header = request.META.get('HTTP_STRIPE_SIGNATURE')

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, settings.STRIPE_WEBHOOK_SECRET
        )
    except ValueError:
        return HttpResponse(status=400)
    except stripe.error.SignatureVerificationError:
        return HttpResponse(status=400)

    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        fulfill_order(session)
    elif event['type'] == 'invoice.paid':
        invoice = event['data']['object']
        provision_access(invoice)

    return HttpResponse(status=200)
```

### 3.6 Python / FastAPI

```python
from fastapi import FastAPI, Request, HTTPException
import stripe

app = FastAPI()

@app.post("/webhook")
async def stripe_webhook(request: Request):
    payload = await request.body()       # Raw bytes — NOT Pydantic model
    sig_header = request.headers.get("stripe-signature")

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, STRIPE_WEBHOOK_SECRET
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid payload")
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Invalid signature")

    match event["type"]:
        case "checkout.session.completed":
            session = event["data"]["object"]
            await fulfill_order(session)
        case "invoice.paid":
            invoice = event["data"]["object"]
            await provision_access(invoice)

    return {"received": True}
```

### 3.7 Python / Flask

```python
from flask import Flask, request, jsonify
import stripe

app = Flask(__name__)

@app.route('/webhook', methods=['POST'])
def stripe_webhook():
    payload = request.data               # Raw data
    sig_header = request.headers.get('Stripe-Signature')

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, STRIPE_WEBHOOK_SECRET
        )
    except (ValueError, stripe.error.SignatureVerificationError):
        return '', 400

    # Handle event...
    return jsonify(received=True), 200
```

### 3.8 Ruby / Rails

```ruby
# app/controllers/webhooks/stripe_controller.rb
class Webhooks::StripeController < ApplicationController
  skip_before_action :verify_authenticity_token  # Critical for webhooks

  def create
    payload = request.body.read
    sig_header = request.env['HTTP_STRIPE_SIGNATURE']

    begin
      event = Stripe::Webhook.construct_event(
        payload, sig_header,
        Rails.application.credentials.dig(:stripe, :signing_secret)
      )
    rescue JSON::ParserError, Stripe::SignatureVerificationError
      head :bad_request
      return
    end

    # Process async via background job
    StripeWebhookJob.perform_later(event.to_json)
    head :ok
  end
end
```

### 3.9 AWS Lambda

```typescript
// handler.ts
import Stripe from 'stripe';
import type { APIGatewayProxyHandler } from 'aws-lambda';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

export const handler: APIGatewayProxyHandler = async (event) => {
  const body = event.isBase64Encoded
    ? Buffer.from(event.body!, 'base64').toString('utf8')
    : event.body!;

  const sig = event.headers['stripe-signature'] || event.headers['Stripe-Signature'];

  let stripeEvent: Stripe.Event;
  try {
    stripeEvent = stripe.webhooks.constructEvent(
      body, sig!, process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    return { statusCode: 400, body: 'Invalid signature' };
  }

  // Handle event...
  return { statusCode: 200, body: JSON.stringify({ received: true }) };
};
```

### 3.10 Cloudflare Workers

```typescript
export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method !== 'POST') {
      return new Response('Method not allowed', { status: 405 });
    }

    const body = await request.text();
    const sig = request.headers.get('stripe-signature')!;

    // Note: Use Web Crypto API for verification in Workers
    // Or use stripe-js with node compat mode
    const stripe = new Stripe(env.STRIPE_SECRET_KEY);
    const event = await stripe.webhooks.constructEventAsync(
      body, sig, env.STRIPE_WEBHOOK_SECRET
    );

    // Handle event...
    return new Response(JSON.stringify({ received: true }), { status: 200 });
  },
};
```

### 3.11 Supabase Edge Functions (Deno)

```typescript
// supabase/functions/stripe-webhook/index.ts
import Stripe from 'npm:stripe';

Deno.serve(async (req) => {
  const body = await req.text();
  const sig = req.headers.get('stripe-signature')!;

  const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!);
  const event = await stripe.webhooks.constructEventAsync(
    body, sig, Deno.env.get('STRIPE_WEBHOOK_SECRET')!,
    undefined, Stripe.createSubtleCryptoProvider()
  );

  // Handle event...
  return new Response(JSON.stringify({ received: true }), {
    headers: { 'Content-Type': 'application/json' },
  });
});
```

---

## 4. Best Practices

### 4.1 Core Principles

1. **Return 200 immediately** — Process events asynchronously in background jobs. Stripe's timeout is **20 seconds**.
2. **Implement idempotency** — Track `event.id` to prevent duplicate processing.
3. **Don't assume event ordering** — Events may arrive out of order. Design handlers to work regardless of sequence.
4. **Use the correct endpoint secret** — Test and live modes have different secrets. CLI provides a temporary secret.

### 4.2 Idempotent Event Processing

```typescript
// In-memory (development only)
const processedEvents = new Set<string>();

// Production: use database
async function processEvent(event: Stripe.Event) {
  // Check if already processed
  const existing = await db.stripeEvents.findUnique({
    where: { eventId: event.id },
  });
  if (existing) {
    console.log(`Event ${event.id} already processed, skipping`);
    return;
  }

  // Process event
  await handleEvent(event);

  // Mark as processed
  await db.stripeEvents.create({
    data: {
      eventId: event.id,
      type: event.type,
      processedAt: new Date(),
    },
  });
}
```

### 4.3 Type-Safe Event Handling

```typescript
// Use DiscriminatedEvent for automatic type narrowing (stripe npm v13.11+)
const event = stripe.webhooks.constructEvent(
  rawBody, sig, secret
) as Stripe.DiscriminatedEvent;

switch (event.type) {
  case 'payment_intent.succeeded':
    // TypeScript knows event.data.object is Stripe.PaymentIntent
    const amount = event.data.object.amount;
    break;
  case 'customer.subscription.deleted':
    // TypeScript knows event.data.object is Stripe.Subscription
    const status = event.data.object.status;
    break;
}
```

### 4.4 Retry Behavior

| Mode | Retry Duration | Retry Pattern |
|------|---------------|---------------|
| Live | **3 days** | Exponential backoff |
| Test | **3 hours** | Exponential backoff |

After retries exhausted, Stripe **disables** the endpoint. Re-enable in Dashboard.

**What triggers retries**:
- HTTP status 3xx, 4xx (except 410), 5xx
- Connection timeout (>20 seconds)
- Network error / DNS failure

**What does NOT trigger retries**:
- HTTP 200-299 (success)
- HTTP 410 (Gone — Stripe disables endpoint)

### 4.5 Timestamp Tolerance

Default: **5 minutes**. Events older than tolerance window are rejected. Adjust in SDK if needed:

```typescript
// Custom tolerance (in seconds)
const event = stripe.webhooks.constructEvent(
  body, sig, secret,
  300  // 5 minutes (default)
);
```

---

## 5. Event Destinations API & Thin Events

### 5.1 Event Destinations (New)

Modern replacement for webhook endpoints with more features:

```typescript
// Create event destination
const destination = await stripe.v2.core.eventDestinations.create({
  name: 'My Webhook',
  enabled_events: ['v1.payment_intent.succeeded', 'v1.checkout.session.completed'],
  type: 'webhook_endpoint',
  webhook_endpoint: {
    url: 'https://example.com/webhooks',
  },
  event_payload: 'thin',                // 'thin' | 'snapshot' (full payload)
});
```

### 5.2 Thin Events

Lighter webhook payloads containing only the event type and object ID — you fetch the full object via API:

```typescript
// Thin event payload
{
  "id": "evt_xxx",
  "type": "v1.payment_intent.succeeded",
  "data": {
    "id": "pi_xxx"                       // Only the ID, not full object
  }
}

// Handler: fetch full object
async function handleThinEvent(event: any) {
  switch (event.type) {
    case 'v1.payment_intent.succeeded':
      const pi = await stripe.paymentIntents.retrieve(event.data.id);
      await fulfillOrder(pi);
      break;
  }
}
```

**Benefits**: Unversioned (no API version mismatch), smaller payloads, always-fresh data (since you fetch on-demand).

**Trade-off**: Requires extra API call per event. Use `snapshot` (traditional full payload) for high-volume endpoints.

---

## 6. Connect Webhooks

### 6.1 Two Types

| Type | Purpose | `event.account` | How to Create |
|------|---------|-----------------|---------------|
| Account webhook | Platform's own events | Not present | Normal endpoint |
| Connect webhook | Connected account events | Connected account ID | Endpoint with `connect: true` |

### 6.2 Connect Event Handling

```typescript
// Every Connect event includes event.account
app.post('/connect-webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const event = stripe.webhooks.constructEvent(
    req.body, req.headers['stripe-signature']!, connectSecret
  );

  const connectedAccountId = event.account;
  console.log(`Event from connected account: ${connectedAccountId}`);

  // Query connected account's objects using Stripe-Account header
  const pi = await stripe.paymentIntents.retrieve('pi_xxx', undefined, {
    stripeAccount: connectedAccountId!,
  });

  res.json({ received: true });
});
```

### 6.3 Separate Endpoints

Best practice: use separate URLs for account and connect webhooks:

```typescript
// Platform events
app.post('/webhooks/stripe', express.raw({ type: 'application/json' }), handlePlatformWebhook);

// Connected account events
app.post('/webhooks/stripe/connect', express.raw({ type: 'application/json' }), handleConnectWebhook);
```

---

## 7. CLI Testing

### 7.1 Basic Commands

```bash
# Login (one-time)
stripe login

# Forward all events to local server
stripe listen --forward-to localhost:3000/webhook
# Output: whsec_xxx (use as endpoint secret in dev)

# Forward specific events only
stripe listen \
  --events payment_intent.succeeded,checkout.session.completed \
  --forward-to localhost:3000/webhook

# Forward Connect events to separate endpoint
stripe listen \
  --forward-to localhost:3000/webhook \
  --forward-connect-to localhost:3000/connect-webhook
```

### 7.2 Trigger Events

```bash
# Trigger standard events
stripe trigger payment_intent.succeeded
stripe trigger checkout.session.completed
stripe trigger customer.subscription.created
stripe trigger invoice.payment_failed
stripe trigger charge.dispute.created

# Resend a specific event
stripe events resend evt_xxx

# Trigger with custom fixture data
stripe trigger payment_intent.succeeded \
  --override payment_intent:amount=5000 \
  --override payment_intent:currency=eur
```

### 7.3 Fixtures

```bash
# Create complex test scenarios
stripe fixtures path/to/fixture.json

# View fixture format
stripe fixtures --print-fixture-data payment_intent.succeeded
```

```json
// fixture.json
{
  "_meta": { "template_version": 0 },
  "fixtures": [
    {
      "name": "customer",
      "path": "/v1/customers",
      "method": "post",
      "params": {
        "email": "test@example.com",
        "name": "Test Customer"
      }
    },
    {
      "name": "payment_intent",
      "path": "/v1/payment_intents",
      "method": "post",
      "params": {
        "customer": "${customer:id}",
        "amount": 2000,
        "currency": "usd",
        "confirm": true,
        "payment_method": "pm_card_visa"
      }
    }
  ]
}
```

### 7.4 Log Streaming

```bash
# Stream API request logs
stripe logs tail

# Filter by status
stripe logs tail --filter-status-code 400

# Filter by HTTP method
stripe logs tail --filter-http-method POST

# Filter by source
stripe logs tail --filter-source api
```

---

## 8. Production Webhook Architecture

### 8.1 Recommended Pattern

```
Stripe → HTTPS Endpoint → Verify Signature → Return 200 → Queue (Redis/SQS/DB)
                                                                     │
                                                              Background Worker
                                                                     │
                                                              Process Event
                                                              (idempotent)
```

### 8.2 Full Production Handler

```typescript
import { Queue } from 'bullmq';

const stripeEventQueue = new Queue('stripe-events');

// Webhook endpoint — thin and fast
app.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      req.body, req.headers['stripe-signature']!, endpointSecret
    );
  } catch (err) {
    console.error(`Webhook signature failed: ${err}`);
    return res.status(400).send();
  }

  // Enqueue for async processing — return 200 within seconds
  await stripeEventQueue.add(event.type, {
    eventId: event.id,
    type: event.type,
    data: event.data,
    account: event.account,
    created: event.created,
  });

  res.status(200).json({ received: true });
});

// Background worker — handles retries, idempotency
import { Worker } from 'bullmq';

const worker = new Worker('stripe-events', async (job) => {
  const { eventId, type, data } = job.data;

  // Idempotency check
  const processed = await db.processedWebhookEvent.findUnique({
    where: { eventId },
  });
  if (processed) return;

  // Process based on event type
  switch (type) {
    case 'checkout.session.completed':
      await fulfillCheckoutSession(data.object);
      break;
    case 'invoice.paid':
      await handleInvoicePaid(data.object);
      break;
    case 'customer.subscription.deleted':
      await handleSubscriptionCanceled(data.object);
      break;
  }

  // Record as processed
  await db.processedWebhookEvent.create({
    data: { eventId, type, processedAt: new Date() },
  });
}, {
  connection: redisConnection,
  concurrency: 5,
});
```

### 8.3 Monitoring Checklist

- [ ] Webhook endpoint returns 200 within 5 seconds (max 20s)
- [ ] All events processed idempotently (tracked by `event.id`)
- [ ] Failed events logged with full context for debugging
- [ ] Alert on webhook endpoint failures (Stripe disables after 3 days)
- [ ] Separate endpoints for account vs Connect webhooks
- [ ] Correct endpoint secrets for test vs live modes
- [ ] Webhook processing does NOT block the HTTP response

---

## 9. Gotchas & Cross-References

### Webhook Gotchas

1. **Raw body is mandatory** — Parsed JSON breaks signature verification. This is the #1 webhook bug.
2. **Express middleware order** — `express.raw()` for webhook route MUST come before `express.json()`.
3. **Return 200 quickly** — Stripe timeout is 20 seconds. Process async.
4. **Stripe retries for 3 days** — Then disables the endpoint. Monitor and fix promptly.
5. **Test vs live secrets differ** — `whsec_` values are environment-specific. CLI provides a temporary one.
6. **invoice.created failure delays 72h** — Unreliable webhook endpoints delay invoice finalization.
7. **No event ordering guarantee** — Design idempotent handlers that don't depend on sequence.
8. **Don't use Edge Runtime** — Stripe SDK crypto needs Node.js. Next.js webhook routes should be `runtime: 'nodejs'`.
9. **Connect events need `connect: true`** — Regular endpoints don't receive connected account events.
10. **Duplicate events happen** — Network retries can deliver the same event multiple times. Always track `event.id`.

### Cross-References

- For payment events and fulfillment → `payments-and-checkout.md`
- For subscription lifecycle events → `subscriptions-and-billing.md`
- For Connect webhook setup → `stripe-connect.md`
- For framework-specific full integration → `framework-integration.md`
- For error handling in webhook processing → `error-handling-and-rate-limits.md`
- For CLI testing commands → `testing-and-tooling.md`
- For webhook security → `security-and-pci.md`
