# Agentic Commerce & AI — Complete Reference

Covers Stripe's AI and agentic commerce ecosystem: Agent Commerce Protocol (ACP), Stripe Agent Toolkit, Stripe MCP Server, VS Code AI Assistant, Radar Assistant, Dashboard AI Assistant, and LLMs.txt. As of February 2026.

## Table of Contents

1. [Agent Commerce Protocol (ACP)](#1-agent-commerce-protocol-acp)
2. [Stripe Agent Toolkit](#2-stripe-agent-toolkit)
3. [Stripe MCP Server](#3-stripe-mcp-server)
4. [VS Code AI Assistant](#4-vs-code-ai-assistant)
5. [Radar Assistant](#5-radar-assistant)
6. [Dashboard AI Assistant](#6-dashboard-ai-assistant)
7. [LLMs.txt](#7-llmstxt)
8. [Gotchas & Cross-References](#8-gotchas--cross-references)

---

## 1. Agent Commerce Protocol (ACP)

### 1.1 Overview

Open standard co-developed by Stripe and OpenAI enabling AI agents to conduct commerce on behalf of users. Powers Instant Checkout in ChatGPT and other AI-native commerce experiences.

### 1.2 Key Concepts

| Concept | Description |
|---------|-------------|
| **Shared Payment Tokens** | Tokens that allow AI agents to pay using a customer's saved payment method without exposing card details |
| **Merchant Registration** | Merchants register products/services as purchasable by AI agents |
| **Agent Authorization** | Users grant agents permission to make purchases within defined limits |
| **Transaction Verification** | Multi-step verification ensuring user intent before completing purchases |
| **Agentic Commerce Suite** | Low-code solution (Dec 2025) for selling across multiple AI agents |

### 1.3 How ACP Works

```
User → AI Agent → ACP Protocol → Stripe → Merchant
  │                   │              │         │
  │ "Buy me a        │              │         │
  │  blue widget"    │              │         │
  │                   │              │         │
  │                   ▼              │         │
  │              Find product        │         │
  │              via merchant API    │         │
  │                   │              │         │
  │◄── Confirm ──────┤              │         │
  │    purchase?      │              │         │
  │                   │              │         │
  │── Yes ──────────►│              │         │
  │                   │              │         │
  │                   ├── Shared ────►         │
  │                   │   Payment    │         │
  │                   │   Token      │         │
  │                   │              ├────────►│
  │                   │              │ Charge  │
  │                   │              │◄────────│
  │                   │              │ Success │
  │◄── Receipt ──────┤              │         │
```

### 1.4 Merchant Setup

```typescript
// Register products for agentic commerce
// Products must have structured metadata for agent discovery

const product = await stripe.products.create({
  name: 'Premium Widget',
  description: 'High-quality widget with 2-year warranty',
  metadata: {
    acp_enabled: 'true',
    category: 'electronics',
    agent_description: 'Premium electronic widget, blue color, ships in 2 days',
  },
  default_price_data: {
    unit_amount: 2999,
    currency: 'usd',
  },
});
```

### 1.5 Agentic Commerce Suite (Dec 2025)

Low-code solution enabling merchants to sell across multiple AI agents:
- Dashboard configuration — no code changes needed
- Product catalog sync with AI agent platforms
- Unified analytics across all AI channels
- Automatic compliance with platform-specific requirements

---

## 2. Stripe Agent Toolkit

Python and TypeScript SDKs for adding Stripe capabilities to agentic AI workflows.

### 2.1 Installation

```bash
# Python
pip install stripe-agent-toolkit

# TypeScript
npm install @stripe/agent-toolkit
```

### 2.2 OpenAI Agents SDK Integration

```python
from stripe_agent_toolkit.openai import StripeAgentToolkit

toolkit = StripeAgentToolkit(
    secret_key="sk_test_...",
    configuration={
        "actions": {
            "payment_links": {"create": True},
            "products": {"create": True},
            "prices": {"create": True},
            "customers": {"create": True, "read": True},
            "invoices": {"create": True},
        }
    }
)

# Use with OpenAI Agents SDK
from openai import OpenAI

client = OpenAI()
agent = client.beta.assistants.create(
    name="Commerce Agent",
    instructions="You help users manage their Stripe payments and subscriptions.",
    tools=toolkit.get_tools(),
    model="gpt-4o",
)

# The agent can now create products, prices, payment links, etc.
```

### 2.3 Vercel AI SDK Integration

```typescript
import { StripeAgentToolkit } from '@stripe/agent-toolkit/ai-sdk';
import { openai } from '@ai-sdk/openai';
import { generateText } from 'ai';

const stripeToolkit = new StripeAgentToolkit({
  secretKey: process.env.STRIPE_SECRET_KEY!,
  configuration: {
    actions: {
      paymentLinks: { create: true },
      products: { create: true },
      prices: { create: true },
      customers: { create: true, read: true },
    },
  },
});

const result = await generateText({
  model: openai('gpt-4o'),
  tools: stripeToolkit.getTools(),
  maxSteps: 5,
  prompt: 'Create a payment link for a $29.99 monthly subscription called "Pro Plan"',
});
```

### 2.4 LangChain Integration

```python
from stripe_agent_toolkit.langchain import StripeAgentToolkit
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_openai_functions_agent
from langchain_core.prompts import ChatPromptTemplate

toolkit = StripeAgentToolkit(
    secret_key="sk_test_...",
    configuration={
        "actions": {
            "payment_links": {"create": True},
            "customers": {"create": True, "read": True},
            "subscriptions": {"create": True, "read": True},
        }
    }
)

llm = ChatOpenAI(model="gpt-4o", temperature=0)
tools = toolkit.get_tools()

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful commerce assistant that manages Stripe operations."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])

agent = create_openai_functions_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

result = agent_executor.invoke({
    "input": "Find customer test@example.com and create a subscription for price_xxx"
})
```

### 2.5 CrewAI Integration

```python
from stripe_agent_toolkit.crewai import StripeAgentToolkit
from crewai import Agent, Task, Crew

toolkit = StripeAgentToolkit(
    secret_key="sk_test_...",
    configuration={
        "actions": {
            "customers": {"create": True, "read": True},
            "invoices": {"create": True, "read": True},
        }
    }
)

billing_agent = Agent(
    role="Billing Manager",
    goal="Manage customer billing and invoicing",
    backstory="You are an expert billing manager for a SaaS company.",
    tools=toolkit.get_tools(),
)

task = Task(
    description="Create an invoice for customer cus_xxx with a $500 consulting charge",
    agent=billing_agent,
)

crew = Crew(agents=[billing_agent], tasks=[task])
result = crew.kickoff()
```

### 2.6 Permission Configuration

```typescript
// Fine-grained permission control
const toolkit = new StripeAgentToolkit({
  secretKey: process.env.STRIPE_SECRET_KEY!,
  configuration: {
    actions: {
      // Each resource has create/read/update/delete permissions
      customers: { create: true, read: true, update: false, delete: false },
      products: { create: true, read: true },
      prices: { create: true, read: true },
      paymentLinks: { create: true, read: true },
      invoices: { create: true, read: true },
      subscriptions: { read: true },             // Read-only
      paymentIntents: { create: true, read: true },
      refunds: { create: false },                 // Prevent agent from refunding
      balance: { read: true },
    },
  },
});
```

---

## 3. Stripe MCP Server

Model Context Protocol server enabling AI assistants to interact with Stripe directly.

### 3.1 Remote MCP (Hosted by Stripe)

```json
{
  "mcpServers": {
    "stripe": {
      "url": "https://mcp.stripe.com",
      "headers": {
        "Authorization": "Bearer sk_test_xxx"
      }
    }
  }
}
```

### 3.2 Local MCP (via npx)

```bash
# All tools
npx -y @stripe/mcp --api-key=sk_test_xxx --tools=all

# Specific tools only
npx -y @stripe/mcp --api-key=sk_test_xxx --tools=customers,payment_intents,subscriptions

# With verbose logging
npx -y @stripe/mcp --api-key=sk_test_xxx --tools=all --verbose
```

### 3.3 Claude Desktop Configuration

```json
// ~/Library/Application Support/Claude/claude_desktop_config.json
{
  "mcpServers": {
    "stripe": {
      "command": "npx",
      "args": ["-y", "@stripe/mcp", "--api-key=sk_test_xxx", "--tools=all"]
    }
  }
}
```

### 3.4 Claude Code Configuration

```json
// .claude/settings.json in project root
{
  "mcpServers": {
    "stripe": {
      "command": "npx",
      "args": ["-y", "@stripe/mcp", "--api-key=sk_test_xxx", "--tools=all"]
    }
  }
}
```

### 3.5 Tool Catalog

| Category | Tools |
|----------|-------|
| **Customers** | create, retrieve, list, update, delete, search |
| **PaymentIntents** | create, retrieve, list, update, confirm, capture, cancel |
| **Checkout Sessions** | create, retrieve, list |
| **Subscriptions** | create, retrieve, list, update, cancel |
| **Invoices** | create, retrieve, list, finalize, pay, void, send |
| **Products** | create, retrieve, list, update |
| **Prices** | create, retrieve, list |
| **Refunds** | create, retrieve, list |
| **Payment Methods** | list, retrieve, attach, detach |
| **Balance** | retrieve |
| **Events** | list, retrieve |
| **Disputes** | retrieve, list, update (submit evidence) |
| **Webhook Endpoints** | create, retrieve, list, update, delete |
| **Coupons** | create, retrieve, list |
| **Payment Links** | create, retrieve, list |

### 3.6 Safety Best Practices

1. **Use test mode keys** — Never give live keys to MCP in development
2. **Use restricted keys** — Scope permissions to only what's needed
3. **Audit MCP actions** — Review Stripe Dashboard logs for MCP-initiated requests
4. **Rate limit awareness** — MCP operations count against your API rate limits

---

## 4. VS Code AI Assistant

Launched March 2025. Works with GitHub Copilot via the `@stripe` mention.

### 4.1 Features

- **Code generation** — Generate Stripe integration code from natural language
- **API reference** — Ask about any Stripe API endpoint, parameter, or concept
- **Error debugging** — Paste error messages for contextual help
- **Migration assistance** — Help upgrading between API versions
- **Best practices** — Stripe-specific coding patterns and security guidance

### 4.2 Usage

```
// In VS Code with GitHub Copilot Chat:
@stripe How do I create a subscription with a 14-day trial?
@stripe What's the best way to handle 3DS authentication in Next.js?
@stripe Help me migrate from Sources API to PaymentMethods
@stripe Explain the difference between direct and destination charges
```

### 4.3 Requirements

- GitHub Copilot subscription
- VS Code with GitHub Copilot Chat extension
- Stripe extension for VS Code (optional but recommended)

---

## 5. Radar Assistant

Natural language interface for creating and managing Radar fraud rules.

### 5.1 Features

- **Rule creation** — Describe fraud patterns in plain English
- **Rule testing** — Test rules against historical transactions
- **Performance analysis** — See impact of rules before deploying
- **Anomaly detection** — AI surfaces unusual patterns

### 5.2 Example Interactions

```
"Block all transactions over $5,000 from prepaid cards"
→ Generates: Block if :amount_in_usd: > 5000 AND :card_funding: = 'prepaid'

"Review orders from new customers using international cards"
→ Generates: Review if :is_new_customer: AND :card_country: != :ip_country:

"Show me the impact of blocking transactions from VPN IP addresses"
→ Runs backtest against last 30 days of transactions
```

---

## 6. Dashboard AI Assistant

Natural language task completion in the Stripe Dashboard.

### 6.1 Capabilities

- **Data queries** — "Show me revenue for last quarter"
- **Object lookup** — "Find customer john@example.com"
- **Report generation** — "Generate a churn report for January"
- **Configuration** — "Enable Apple Pay for my account"
- **Navigation** — "Take me to webhook settings"

---

## 7. LLMs.txt

Stripe provides AI-consumable documentation at every doc URL.

### 7.1 How It Works

- Add `.md` suffix to any Stripe doc URL to get AI-optimized markdown
- `https://docs.stripe.com/llms.txt` — Index of all available docs
- Content optimized for LLM consumption (structured, concise, code-heavy)
- Updated with every documentation release

### 7.2 Usage in AI Applications

```python
# Fetch Stripe docs for RAG pipeline
import httpx

async def fetch_stripe_docs(topic: str) -> str:
    url = f"https://docs.stripe.com/{topic}.md"
    async with httpx.AsyncClient() as client:
        response = await client.get(url)
        return response.text

# Example: fetch payment intents docs
docs = await fetch_stripe_docs("payments/payment-intents")

# Use in RAG context
from openai import OpenAI

client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {"role": "system", "content": f"Use this Stripe documentation:\n{docs}"},
        {"role": "user", "content": "How do I handle SCA for off-session payments?"},
    ],
)
```

### 7.3 llms.txt Structure

```
# https://docs.stripe.com/llms.txt
# Lists all available documentation paths

/payments/payment-intents
/billing/subscriptions
/connect/accounts
/webhooks
/elements
...
```

---

## 8. Gotchas & Cross-References

### AI Integration Gotchas

1. **Never use live keys with AI tools** — Always use test or restricted keys with MCP/Agent Toolkit.
2. **Rate limits apply** — MCP and Agent Toolkit operations count against your API rate limits.
3. **Agent actions need confirmation** — Always implement human-in-the-loop for destructive operations (refunds, cancellations).
4. **ACP is still emerging** — The protocol is evolving. Check Stripe docs for latest status.
5. **MCP tools are read-write** — Even with read-only intent, verify tool configuration carefully.
6. **LLMs.txt content is version-specific** — Content matches current API version, not your pinned version.

### Cross-References

- For MCP Server details → `testing-and-tooling.md`
- For Radar rules syntax → `payments-and-checkout.md`
- For API key management → `security-and-pci.md`
- For error handling in agent workflows → `error-handling-and-rate-limits.md`
