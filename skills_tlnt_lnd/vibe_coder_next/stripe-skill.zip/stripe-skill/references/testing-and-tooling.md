# Testing & Tooling — Complete Reference

Covers the full Stripe testing and developer tooling ecosystem: test cards, test bank accounts, Test Clocks for billing simulation, Stripe CLI, stripe-mock, Sandboxes, Workbench, Stripe MCP Server, and Sigma. API version `2026-01-28.clover`.

## Table of Contents

1. [Test Cards](#1-test-cards)
2. [Test Bank Accounts](#2-test-bank-accounts)
3. [Test Clocks](#3-test-clocks)
4. [Stripe CLI](#4-stripe-cli)
5. [stripe-mock](#5-stripe-mock)
6. [Sandboxes](#6-sandboxes)
7. [Workbench](#7-workbench)
8. [Stripe MCP Server](#8-stripe-mcp-server)
9. [Sigma](#9-sigma)
10. [Gotchas & Cross-References](#10-gotchas--cross-references)

---

## 1. Test Cards

### 1.1 Basic Test Cards

All test cards use **any future expiry date**, **any 3-digit CVC**, and **any postal code**.

| Number | Brand | Scenario |
|--------|-------|----------|
| `4242424242424242` | Visa | Always succeeds |
| `5555555555554444` | Mastercard | Always succeeds |
| `3782822463100005` | Amex | Always succeeds |
| `6011111111111117` | Discover | Always succeeds |
| `3566002020360505` | JCB | Always succeeds |
| `6200000000000005` | UnionPay | Always succeeds |

### 1.2 Decline Test Cards

| Number | Decline Code | Description |
|--------|-------------|-------------|
| `4000000000000002` | `generic_decline` | Generic decline |
| `4000000000009995` | `insufficient_funds` | Insufficient funds |
| `4000000000009987` | `lost_card` | Lost card (sensitive) |
| `4000000000009979` | `stolen_card` | Stolen card (sensitive) |
| `4000000000000069` | `expired_card` | Expired card |
| `4000000000000127` | `incorrect_cvc` | Incorrect CVC |
| `4000000000000119` | `processing_error` | Processing error |
| `4100000000000019` | `fraudulent` | Fraudulent (blocked by Radar) |
| `4000000000000101` | — | CVC check fails |
| `4000000000000036` | — | Address line 1 check fails |
| `4000000000000044` | — | Address ZIP check fails |

### 1.3 3D Secure Test Cards

| Number | 3DS Behavior |
|--------|-------------|
| `4000002500003155` | Requires 3DS authentication |
| `4000000000003220` | 3DS required, authentication succeeds |
| `4000008400001629` | 3DS required, authentication fails |
| `4000000000003055` | 3DS supported but not required |
| `4000000000003097` | 3DS required, attempts processing |
| `4000002760003184` | 3DS required on setup, succeeds |
| `4000003800000446` | 3DS required, challenge flow |

### 1.4 Payment Method-Specific Test Cards

| Number | Scenario |
|--------|----------|
| `4000000000000341` | Attach succeeds, charge fails |
| `4000000000005126` | Succeeds and saves for future use |
| `4000003720000278` | Debit card (Visa Debit) |
| `5200828282828210` | Debit card (Mastercard Debit) |
| `4000056655665556` | Visa — always succeeds (US billing) |
| `4000000760000002` | Visa — always succeeds (BR billing) |
| `4000001240000000` | Visa — always succeeds (CA billing) |

### 1.5 Dispute Test Cards

| Number | Dispute Scenario |
|--------|-----------------|
| `4000000000000259` | Creates dispute `fraudulent` |
| `4000000000001976` | Creates dispute `product_not_received` |
| `4000000000005423` | Creates Early Fraud Warning |
| `4000000000002685` | Creates dispute, evidence wins |

### 1.6 Wallet Test Tokens

| Token | Wallet |
|-------|--------|
| `pm_card_visa` | Visa card payment method |
| `pm_card_mastercard` | Mastercard payment method |
| `pm_card_amex` | Amex payment method |

---

## 2. Test Bank Accounts

### 2.1 ACH (US Bank Accounts)

| Routing | Account | Scenario |
|---------|---------|----------|
| `110000000` | `000123456789` | Succeeds |
| `110000000` | `000111111116` | Fails (account closed) |
| `110000000` | `000111111113` | Fails (no account) |
| `110000000` | `000222222227` | Fails (insufficient funds) |
| `110000000` | `000333333335` | Fails (debit not authorized) |
| `110000000` | `000444444440` | Fails (invalid currency) |

### 2.2 SEPA Test IBANs

| IBAN | Country | Scenario |
|------|---------|----------|
| `DE89370400440532013000` | Germany | Succeeds |
| `IE29AIBK93115212345678` | Ireland | Succeeds |
| `DE62370400440532013001` | Germany | Fails (insufficient funds) |
| `DE35370400440532013002` | Germany | Fails (debit not authorized) |

### 2.3 BACS (UK)

| Sort Code | Account | Scenario |
|-----------|---------|----------|
| `108800` | `00012345` | Succeeds |
| `108800` | `90012345` | Fails (account closed) |

---

## 3. Test Clocks

Simulate time progression for billing testing. Create a clock, attach customers to it, then advance time to trigger renewals, trial ends, payment retries, etc.

### 3.1 Complete Workflow

```typescript
// Step 1: Create Test Clock
const testClock = await stripe.testHelpers.testClocks.create({
  frozen_time: Math.floor(new Date('2026-01-01').getTime() / 1000),
  name: 'Subscription lifecycle test',
});

// Step 2: Create customer attached to clock
const customer = await stripe.customers.create({
  email: 'test@example.com',
  test_clock: testClock.id,
  payment_method: 'pm_card_visa',
  invoice_settings: { default_payment_method: 'pm_card_visa' },
});

// Step 3: Create subscription
const sub = await stripe.subscriptions.create({
  customer: customer.id,
  items: [{ price: 'price_monthly' }],
  trial_period_days: 14,
});
// sub.status === 'trialing'

// Step 4: Advance clock past trial end
await stripe.testHelpers.testClocks.advance(testClock.id, {
  frozen_time: Math.floor(new Date('2026-01-16').getTime() / 1000),
});
// Wait for clock to finish advancing (poll status)
let clock = await stripe.testHelpers.testClocks.retrieve(testClock.id);
while (clock.status === 'advancing') {
  await new Promise(r => setTimeout(r, 1000));
  clock = await stripe.testHelpers.testClocks.retrieve(testClock.id);
}
// sub.status === 'active' (trial ended, payment charged)

// Step 5: Advance to next billing cycle
await stripe.testHelpers.testClocks.advance(testClock.id, {
  frozen_time: Math.floor(new Date('2026-02-01').getTime() / 1000),
});
// Triggers: invoice.created, invoice.paid, customer.subscription.updated

// Step 6: Simulate payment failure
// Attach failing card first
await stripe.paymentMethods.attach('pm_card_chargeDeclined', { customer: customer.id });
await stripe.customers.update(customer.id, {
  invoice_settings: { default_payment_method: 'pm_card_chargeDeclined' },
});
// Advance past next billing
await stripe.testHelpers.testClocks.advance(testClock.id, {
  frozen_time: Math.floor(new Date('2026-03-01').getTime() / 1000),
});
// sub.status === 'past_due' (Smart Retries in progress)

// Advance further to exhaust retries
await stripe.testHelpers.testClocks.advance(testClock.id, {
  frozen_time: Math.floor(new Date('2026-03-15').getTime() / 1000),
});
// sub.status === 'canceled' or 'unpaid' (depending on config)

// Step 7: Clean up
await stripe.testHelpers.testClocks.delete(testClock.id);
```

### 3.2 Test Clock Limitations

- Max **3 active Test Clocks** per account
- Can only advance **forward** in time
- Objects attached to clocks are isolated — can't interact with non-clock objects
- Clock advancement is async — poll `status` until `ready`
- Only available in test mode

### 3.3 Automated Testing with Test Clocks

```typescript
// Jest / Vitest test
describe('Subscription lifecycle', () => {
  let testClock: Stripe.TestHelpers.TestClock;
  let customer: Stripe.Customer;

  beforeEach(async () => {
    testClock = await stripe.testHelpers.testClocks.create({
      frozen_time: Math.floor(Date.now() / 1000),
    });
    customer = await stripe.customers.create({
      test_clock: testClock.id,
      payment_method: 'pm_card_visa',
      invoice_settings: { default_payment_method: 'pm_card_visa' },
    });
  });

  afterEach(async () => {
    await stripe.testHelpers.testClocks.delete(testClock.id);
  });

  it('should transition from trial to active', async () => {
    const sub = await stripe.subscriptions.create({
      customer: customer.id,
      items: [{ price: testPriceId }],
      trial_period_days: 7,
    });
    expect(sub.status).toBe('trialing');

    await advanceClock(testClock.id, 8 * 86400); // 8 days
    const updated = await stripe.subscriptions.retrieve(sub.id);
    expect(updated.status).toBe('active');
  });

  it('should handle payment failure gracefully', async () => {
    // ... similar pattern with failing card
  });
});

async function advanceClock(clockId: string, seconds: number) {
  const clock = await stripe.testHelpers.testClocks.retrieve(clockId);
  await stripe.testHelpers.testClocks.advance(clockId, {
    frozen_time: clock.frozen_time + seconds,
  });
  // Wait for advancement to complete
  let updated: Stripe.TestHelpers.TestClock;
  do {
    await new Promise(r => setTimeout(r, 500));
    updated = await stripe.testHelpers.testClocks.retrieve(clockId);
  } while (updated.status === 'advancing');
}
```

---

## 4. Stripe CLI

### 4.1 Installation

```bash
# macOS
brew install stripe/stripe-cli/stripe

# Linux (apt)
curl -s https://packages.stripe.dev/api/security/keypair/stripe-cli-gpg/public | gpg --dearmor | sudo tee /usr/share/keyrings/stripe.gpg
echo "deb [signed-by=/usr/share/keyrings/stripe.gpg] https://packages.stripe.dev/stripe-cli-debian-local stable main" | sudo tee -a /etc/apt/sources.list.d/stripe.list
sudo apt update && sudo apt install stripe

# Docker
docker run --rm -it stripe/stripe-cli

# npm (npx)
npx stripe
```

### 4.2 Authentication

```bash
stripe login
# Opens browser for authentication
# Stores API key in ~/.config/stripe/config.toml

# Use specific API key
stripe --api-key sk_test_xxx

# Use specific project/account
stripe --project-name my-project
```

### 4.3 Essential Commands

```bash
# ─── Webhook Development ───
stripe listen --forward-to localhost:3000/webhook
stripe listen --events payment_intent.succeeded,checkout.session.completed --forward-to localhost:3000/webhook
stripe listen --forward-to localhost:3000/webhook --forward-connect-to localhost:3000/connect-webhook

# ─── Event Triggers ───
stripe trigger payment_intent.succeeded
stripe trigger checkout.session.completed
stripe trigger customer.subscription.created
stripe trigger invoice.payment_failed
stripe trigger charge.dispute.created

# Trigger with overrides
stripe trigger payment_intent.succeeded --override payment_intent:amount=5000

# Resend an existing event
stripe events resend evt_xxx

# ─── API Logs ───
stripe logs tail
stripe logs tail --filter-status-code 400
stripe logs tail --filter-http-method POST
stripe logs tail --filter-source api

# ─── CRUD Operations ───
stripe customers create --email="test@test.com" --name="Test User"
stripe customers list --limit 5
stripe customers retrieve cus_xxx
stripe prices list --active=true

# ─── Fixtures ───
stripe fixtures path/to/fixture.json
stripe fixtures --print-fixture-data payment_intent.succeeded

# ─── Samples ───
stripe samples create accept-a-payment
stripe samples list

# ─── Resources ───
stripe resources         # List all API resources
stripe get /v1/customers # Raw API call
stripe post /v1/customers -d email=test@example.com

# ─── Status ───
stripe status           # Stripe system status
stripe config --list    # Show current configuration
```

### 4.4 CI/CD Usage

```yaml
# GitHub Actions
- name: Install Stripe CLI
  run: |
    curl -s https://packages.stripe.dev/api/security/keypair/stripe-cli-gpg/public | gpg --dearmor | sudo tee /usr/share/keyrings/stripe.gpg
    echo "deb [signed-by=/usr/share/keyrings/stripe.gpg] https://packages.stripe.dev/stripe-cli-debian-local stable main" | sudo tee /etc/apt/sources.list.d/stripe.list
    sudo apt update && sudo apt install stripe

- name: Run Stripe fixture tests
  env:
    STRIPE_API_KEY: ${{ secrets.STRIPE_TEST_KEY }}
  run: |
    stripe fixtures tests/fixtures/setup.json
    npm test
```

---

## 5. stripe-mock

Open-source HTTP server that mimics the Stripe API — for CI/CD without hitting the real API.

### 5.1 Running

```bash
# Docker (recommended)
docker run --rm -p 12111:12111 -p 12112:12112 stripe/stripe-mock

# From source
go install github.com/stripe/stripe-mock@latest
stripe-mock

# Ports: 12111 (HTTP), 12112 (HTTPS)
```

### 5.2 Using in Tests

```typescript
// Point Stripe SDK at mock server
const stripe = new Stripe('sk_test_mock', {
  apiVersion: '2026-01-28',
  host: 'localhost',
  port: 12111,
  protocol: 'http',
});

// All API calls hit the mock
const customer = await stripe.customers.create({ email: 'test@example.com' });
// Returns valid-shaped mock data (not persisted between requests)
```

### 5.3 CI Integration

```yaml
# docker-compose.test.yml
services:
  stripe-mock:
    image: stripe/stripe-mock:latest
    ports:
      - "12111:12111"

  tests:
    build: .
    environment:
      STRIPE_API_BASE: http://stripe-mock:12111
    depends_on:
      - stripe-mock
    command: npm test
```

### 5.4 Limitations

- Does NOT persist data between requests
- Does NOT enforce business logic (e.g., won't decline test cards)
- Does NOT trigger webhooks
- Useful for: unit tests, type checking, CI/CD pipeline validation
- NOT useful for: integration testing, webhook testing, billing flow testing

---

## 6. Sandboxes

GA since May 2025. Isolated test environments with their own data, settings, and webhook endpoints.

### 6.1 Key Features

- **Isolated data**: Separate customers, subscriptions, products from main test mode
- **Separate settings**: Own webhook endpoints, Radar rules, billing config
- **Team access**: Invite specific team members per sandbox
- **Quick reset**: Wipe all data and start fresh
- **API key per sandbox**: Each sandbox has its own `sk_test_` and `pk_test_` keys

### 6.2 Use Cases

| Use Case | Sandbox Benefit |
|----------|----------------|
| Feature development | Isolated data doesn't affect QA |
| QA testing | Clean state, reproducible |
| Demo environments | Pre-configured showcase data |
| CI/CD per branch | Unique sandbox per feature branch |
| Partner testing | Isolated sandbox for each partner |

### 6.3 Management

```bash
# Create via Dashboard: Settings > Sandboxes > Create sandbox
# Or via API:
stripe sandboxes create --name "Feature-X Testing"

# Switch CLI context to sandbox
stripe --project-name my-sandbox

# List sandboxes
stripe sandboxes list
```

---

## 7. Workbench

GA since August 2024. Developer home in the Stripe Dashboard — the central hub for API development.

### 7.1 Features

| Feature | Description |
|---------|-------------|
| **API Explorer** | Interactive API reference with live requests |
| **Event catalog** | Browse all event types with sample payloads |
| **Request logs** | Real-time API request/response viewer |
| **Webhook logs** | Webhook delivery attempts and responses |
| **API keys** | Manage and create restricted keys |
| **Webhooks** | Create and manage endpoints |
| **Shell** | Built-in terminal for Stripe CLI commands |

### 7.2 API Explorer

- Select any API endpoint
- Fill in parameters interactively
- Send requests directly from Dashboard
- View formatted responses
- Copy code snippets in any language

---

## 8. Stripe MCP Server

Model Context Protocol server enabling AI assistants (Claude, GPT) to interact with Stripe.

### 8.1 Remote MCP (Hosted by Stripe)

```json
// .claude/settings.json or Claude Desktop config
{
  "mcpServers": {
    "stripe": {
      "url": "https://mcp.stripe.com",
      "headers": {
        "Authorization": "Bearer sk_test_xxx"
      }
    }
  }
}
```

### 8.2 Local MCP (via npx)

```bash
# Run locally
npx -y @stripe/mcp --api-key=sk_test_xxx --tools=all

# With specific tools only
npx -y @stripe/mcp --api-key=sk_test_xxx --tools=customers,payment_intents,subscriptions
```

### 8.3 Available Tools

The MCP server exposes these Stripe operations:

- **Customers**: create, retrieve, list, update, search
- **PaymentIntents**: create, retrieve, list, confirm, capture, cancel
- **Subscriptions**: create, retrieve, list, update, cancel
- **Invoices**: create, retrieve, list, finalize, pay, void
- **Products**: create, retrieve, list, update
- **Prices**: create, retrieve, list
- **Checkout Sessions**: create, retrieve
- **Refunds**: create, retrieve, list
- **Balance**: retrieve
- **Events**: list, retrieve
- **Webhook Endpoints**: create, list

### 8.4 Claude Code Integration

```bash
# Add to Claude Code project
# In your project's .claude/settings.json:
{
  "mcpServers": {
    "stripe": {
      "command": "npx",
      "args": ["-y", "@stripe/mcp", "--api-key=sk_test_xxx", "--tools=all"]
    }
  }
}

# Then in Claude Code:
# "Create a test customer with email test@example.com"
# "List all active subscriptions"
# "Create a checkout session for price_xxx"
```

### 8.5 Permissions and Safety

- Use **restricted keys** with only necessary permissions
- Never use live secret keys with MCP in development
- The MCP server logs all operations
- Read-only tools available: `--tools=customers.read,subscriptions.read`

---

## 9. Sigma

SQL analytics on Stripe data, available in Dashboard or via API.

### 9.1 Features

- **SQL queries** on all Stripe data
- **3-hour data freshness** (down from 12h in 2024)
- **AI-powered queries** — describe what you want in natural language
- **Scheduled reports** — email or webhook delivery
- **API access** — run Sigma queries programmatically

### 9.2 Example Queries

```sql
-- Monthly recurring revenue
SELECT
  DATE_TRUNC('month', created) AS month,
  SUM(amount) / 100.0 AS mrr
FROM subscriptions
WHERE status = 'active'
GROUP BY 1
ORDER BY 1 DESC;

-- Churn rate by month
SELECT
  DATE_TRUNC('month', canceled_at) AS month,
  COUNT(*) AS churned,
  COUNT(*) * 100.0 / LAG(COUNT(*)) OVER (ORDER BY DATE_TRUNC('month', canceled_at)) AS churn_rate
FROM subscriptions
WHERE canceled_at IS NOT NULL
GROUP BY 1
ORDER BY 1 DESC;

-- Top customers by lifetime value
SELECT
  c.id,
  c.email,
  SUM(ch.amount) / 100.0 AS lifetime_value,
  COUNT(ch.id) AS total_charges
FROM customers c
JOIN charges ch ON ch.customer_id = c.id
WHERE ch.status = 'succeeded'
GROUP BY c.id, c.email
ORDER BY lifetime_value DESC
LIMIT 20;
```

---

## 10. Gotchas & Cross-References

### Testing Gotchas

1. **Test cards only work in test mode** — Using `4242...` in live mode returns an error.
2. **Test Clocks limit: 3 active** — Delete old clocks before creating new ones.
3. **Test Clock advancement is async** — Poll `status` until `ready` before asserting.
4. **stripe-mock doesn't persist** — Each request is independent. Use for type checking, not flow testing.
5. **CLI `listen` secret is temporary** — Changes each time you run `stripe listen`. Don't hardcode.
6. **Sandbox keys are separate** — Each sandbox has its own API keys. Don't mix them.
7. **Test mode rate limit: 25/sec** — Much lower than live (100/sec). Load tests may hit limits.
8. **Test cards don't trigger real 3DS** — They simulate the flow but don't invoke actual bank authentication.

### Cross-References

- For test card decline codes → `error-handling-and-rate-limits.md`
- For webhook testing → `webhooks.md`
- For billing flow testing with Test Clocks → `subscriptions-and-billing.md`
- For MCP integration → `agentic-commerce-and-ai.md`
- For CI/CD integration → `security-and-pci.md`
