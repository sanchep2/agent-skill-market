# Stripe Connect — Complete Reference

Covers the full Connect platform: account types and controller properties, onboarding flows, charge types (direct/destination/separate), transfers and payouts, Connect webhooks, embedded components, Radar for Platforms, and platform fee strategies. API version `2026-01-28.clover`.

## Table of Contents

1. [Account Types & Controller Properties](#1-account-types--controller-properties)
2. [Onboarding Flows](#2-onboarding-flows)
3. [Charge Types — The Critical Decision](#3-charge-types--the-critical-decision)
4. [Transfers & Payouts](#4-transfers--payouts)
5. [Connect Webhooks](#5-connect-webhooks)
6. [Embedded Components](#6-embedded-components)
7. [Accounts v2 API](#7-accounts-v2-api)
8. [Radar for Platforms](#8-radar-for-platforms)
9. [Platform Fee Strategies](#9-platform-fee-strategies)
10. [Gotchas & Cross-References](#10-gotchas--cross-references)

---

## 1. Account Types & Controller Properties

### 1.1 Traditional Account Types

| Factor | Standard | Express | Custom |
|--------|----------|---------|--------|
| Dashboard access | Full Stripe Dashboard | Express Dashboard | None (build your own) |
| Onboarding | Stripe-hosted | Stripe-hosted | Custom or Stripe-hosted |
| Integration effort | Low | Medium | High |
| Dispute handling | Connected account | Platform | Platform |
| Support | Stripe direct | Mixed | Platform only |
| Additional Connect fees | None | Yes | Yes |
| Negative balance liability | Connected account | Platform | Platform |
| Best for | SaaS platforms | Marketplaces, gig economy | Full white-label |

**Critical: Cannot change account type after creation.**

### 1.2 Controller Properties (Modern Approach)

Instead of picking Standard/Express/Custom, configure granular controller properties:

```typescript
const account = await stripe.accounts.create({
  controller: {
    stripe_dashboard: {
      type: 'express',                   // 'full' | 'express' | 'none'
    },
    fees: {
      payer: 'application',              // 'application' (platform pays) | 'account'
    },
    losses: {
      payments: 'application',           // 'application' (platform liable) | 'stripe'
    },
    requirement_collection: 'stripe',    // 'stripe' (Stripe collects KYC) | 'application'
  },
  capabilities: {
    card_payments: { requested: true },
    transfers: { requested: true },
  },
  country: 'US',
  email: 'seller@example.com',
});
```

### 1.3 Controller Property Combinations

| Combo | Equivalent | Description |
|-------|-----------|-------------|
| `dashboard: full, fees: account, losses: stripe, requirements: stripe` | Standard | Full autonomy |
| `dashboard: express, fees: application, losses: application, requirements: stripe` | Express | Managed by platform |
| `dashboard: none, fees: application, losses: application, requirements: application` | Custom | Full white-label |

### 1.4 Capabilities

Request capabilities based on your platform needs:

```typescript
const account = await stripe.accounts.create({
  // ... controller config
  capabilities: {
    card_payments: { requested: true },
    transfers: { requested: true },
    us_bank_account_ach_payments: { requested: true },
    link_payments: { requested: true },
    tax_reporting_us_1099_k: { requested: true },
    tax_reporting_us_1099_misc: { requested: true },
  },
});
```

---

## 2. Onboarding Flows

### 2.1 Account Links (Standard Onboarding)

```typescript
// Step 1: Create account
const account = await stripe.accounts.create({
  controller: {
    stripe_dashboard: { type: 'express' },
    fees: { payer: 'application' },
    losses: { payments: 'application' },
    requirement_collection: 'stripe',
  },
  country: 'US',
  email: 'seller@example.com',
  business_type: 'individual',
  // Prefill data BEFORE creating Account Link (becomes read-only after)
  individual: {
    first_name: 'Jane',
    last_name: 'Doe',
    email: 'jane@example.com',
  },
  business_profile: {
    mcc: '5734',                         // Computer Software Stores
    url: 'https://janesstore.com',
    product_description: 'Handmade jewelry and accessories',
  },
});

// Step 2: Create Account Link (single-use, expires in minutes)
const accountLink = await stripe.accountLinks.create({
  account: account.id,
  refresh_url: 'https://platform.com/reauth',  // Regenerate link if expired
  return_url: 'https://platform.com/return',    // User returns here (may NOT be done)
  type: 'account_onboarding',
  collection_options: {
    fields: 'eventually_due',            // or 'currently_due' for less friction
    future_requirements: 'include',
  },
});

// Step 3: Redirect user
res.redirect(303, accountLink.url);
```

### 2.2 Onboarding State Machine

```
Account Created
    │
    ▼
Account Link Created → User redirected
    │
    ├── Link expired → refresh_url hit → Create new Account Link
    │
    ├── User abandons → return_url hit (incomplete)
    │   └── Check requirements, create new Account Link
    │
    └── User completes
        │
        ▼
    Check account.charges_enabled && account.payouts_enabled
        │
        ├── Both true → Fully onboarded ✓
        │
        └── requirements.currently_due not empty
            └── Create new Account Link for remaining requirements
```

### 2.3 Check Onboarding Status

```typescript
const account = await stripe.accounts.retrieve('acct_xxx');

if (account.charges_enabled && account.payouts_enabled) {
  console.log('Fully onboarded — can accept payments and receive payouts');
} else {
  console.log('Incomplete onboarding');
  console.log('Currently due:', account.requirements?.currently_due);
  console.log('Eventually due:', account.requirements?.eventually_due);
  console.log('Past due:', account.requirements?.past_due);
  console.log('Errors:', account.requirements?.errors);

  if (account.requirements?.disabled_reason) {
    console.log('Disabled reason:', account.requirements.disabled_reason);
  }
}
```

### 2.4 Networked Onboarding (3-Click)

For users who already have a Stripe account — they can link their existing account to your platform in 3 clicks. Enabled automatically when using Account Links with Standard accounts.

### 2.5 Prefill Best Practices

- **Always prefill** business info, email, name, URL before creating Account Link
- After Account Link creation on Standard accounts, KYC data becomes **read-only**
- Prefill reduces onboarding friction and abandonment
- Use `business_profile.mcc` (Merchant Category Code) to pre-classify the business

---

## 3. Charge Types — The Critical Decision

### 3.1 Comparison

| | Direct Charges | Destination Charges | Separate Charges & Transfers |
|--|----|----|-----|
| Payment created on | Connected account | Platform | Platform |
| API pattern | `Stripe-Account` header | `transfer_data[destination]` | `transfer_group` + Transfer API |
| Statement descriptor | Connected account's | Platform's | Platform's |
| Customer belongs to | Connected account | Platform | Platform |
| Multi-party splits | No | No | **Yes** |
| Dispute responsibility | Connected account | Platform | Platform |
| Radar rules | Connected account's | Platform's | Platform's |
| Refund control | Connected account | Platform | Platform |
| Best for | SaaS (Shopify-like) | Marketplaces (Airbnb) | Complex splits (DoorDash) |

### 3.2 Decision Flowchart

```
Q1: Does the connected account own the customer relationship?
│
├── YES → Direct Charges
│         • Customer sees connected account on statement
│         • Connected account handles disputes
│         • Customer data lives on connected account
│         • Platform takes app fee
│
└── NO → Q2: Is there a single seller per transaction?
         │
         ├── YES → Destination Charges
         │         • Customer sees platform on statement
         │         • Platform handles disputes
         │         • Simple one-to-one: charge → transfer
         │         • Platform takes app fee from transfer
         │
         └── NO → Separate Charges & Transfers
                   • Maximum flexibility
                   • Multiple recipients per charge
                   • Platform handles disputes
                   • Manual transfer management
                   • Most complex to implement
```

### 3.3 Direct Charges

```typescript
// Direct charge via Checkout Session
const session = await stripe.checkout.sessions.create({
  line_items: [{
    price_data: {
      currency: 'usd',
      product_data: { name: 'Handmade Necklace' },
      unit_amount: 5000,
    },
    quantity: 1,
  }],
  mode: 'payment',
  payment_intent_data: {
    application_fee_amount: 750,         // Platform takes $7.50
  },
  success_url: 'https://seller-store.com/success',
  cancel_url: 'https://seller-store.com/cancel',
}, {
  stripeAccount: 'acct_CONNECTED',       // Charge on connected account
});

// Direct charge via PaymentIntent
const pi = await stripe.paymentIntents.create({
  amount: 5000,
  currency: 'usd',
  application_fee_amount: 750,
  customer: 'cus_on_connected_account',  // Customer on connected account
}, {
  stripeAccount: 'acct_CONNECTED',
});
```

### 3.4 Destination Charges

```typescript
// Simple destination charge
const pi = await stripe.paymentIntents.create({
  amount: 10000,                         // $100.00
  currency: 'usd',
  customer: 'cus_on_platform',           // Customer on platform
  application_fee_amount: 1500,          // Platform keeps $15.00
  transfer_data: {
    destination: 'acct_CONNECTED',       // Seller receives $85.00
  },
});

// Destination charge with on_behalf_of
const pi2 = await stripe.paymentIntents.create({
  amount: 10000,
  currency: 'usd',
  application_fee_amount: 1500,
  transfer_data: { destination: 'acct_CONNECTED' },
  on_behalf_of: 'acct_CONNECTED',       // Statement shows connected account, settled in their country
});
```

### 3.5 Separate Charges and Transfers

```typescript
// Step 1: Charge on platform
const charge = await stripe.paymentIntents.create({
  amount: 10000,                         // $100.00 total
  currency: 'usd',
  customer: 'cus_xxx',
  confirm: true,
  payment_method: 'pm_xxx',
  transfer_group: 'ORDER_100',           // Group related transfers
});

// Step 2: Transfer to restaurant
const transfer1 = await stripe.transfers.create({
  amount: 7000,                          // $70.00 to restaurant
  currency: 'usd',
  destination: 'acct_restaurant',
  transfer_group: 'ORDER_100',
  source_transaction: charge.latest_charge as string, // Links transfer to charge
});

// Step 3: Transfer to driver
const transfer2 = await stripe.transfers.create({
  amount: 2000,                          // $20.00 to driver
  currency: 'usd',
  destination: 'acct_driver',
  transfer_group: 'ORDER_100',
});

// Platform keeps: $100 - $70 - $20 = $10.00
```

### 3.6 Key Pitfalls by Charge Type

**Direct charges**:
- Platform Radar rules do NOT apply — only connected account's rules
- Customer data lives on connected account — requires `stripeAccount` header to query
- Cannot query payment data without the connected account header
- App fee must ≥ Stripe's processing fee to avoid platform losses

**Destination charges**:
- Cannot split to multiple destinations
- `on_behalf_of` changes statement descriptor AND settlement country
- Refund returns the full amount; platform must handle app fee refund logic

**Separate charges and transfers**:
- Must manage transfer timing and amounts manually
- `source_transaction` links transfer to charge (transfer inherits pending status)
- Without `source_transaction`, transfers are independent (can overdraw)
- Transfer amount total can exceed charge amount if platform has sufficient balance

---

## 4. Transfers & Payouts

### 4.1 Transfers (Platform → Connected Account)

```typescript
// Standard transfer
const transfer = await stripe.transfers.create({
  amount: 5000,
  currency: 'usd',
  destination: 'acct_xxx',
  description: 'Weekly payout for Order #100-105',
  metadata: { week: '2026-08' },
});

// Transfer with source_transaction (inherits pending status)
const transfer2 = await stripe.transfers.create({
  amount: 5000,
  currency: 'usd',
  destination: 'acct_xxx',
  source_transaction: 'ch_xxx',          // Linked to specific charge
});

// Reverse a transfer
const reversal = await stripe.transfers.createReversal(transfer.id, {
  amount: 2000,                          // Partial reversal
});
```

### 4.2 Payout Schedules

```typescript
// Set payout schedule for connected account
await stripe.accounts.update('acct_xxx', {
  settings: {
    payouts: {
      schedule: {
        interval: 'weekly',              // 'daily' | 'weekly' | 'monthly' | 'manual'
        weekly_anchor: 'friday',         // For weekly
        // monthly_anchor: 15,           // For monthly (1-31)
      },
      debit_negative_balances: true,
    },
  },
});

// Manual payout
const payout = await stripe.payouts.create({
  amount: 10000,
  currency: 'usd',
}, {
  stripeAccount: 'acct_xxx',
});
```

### 4.3 Instant Payouts

```typescript
// Check eligibility
const account = await stripe.accounts.retrieve('acct_xxx');
const balance = await stripe.balance.retrieve({ stripeAccount: 'acct_xxx' });

const instantAvailable = balance.instant_available?.[0];
if (instantAvailable && instantAvailable.amount > 0) {
  // Create instant payout (~30 minutes)
  const payout = await stripe.payouts.create({
    amount: instantAvailable.amount,
    currency: 'usd',
    method: 'instant',
  }, {
    stripeAccount: 'acct_xxx',
  });
}
```

Instant Payouts are available 24/7 including weekends and holidays. Fee: typically 1% with $0.50 minimum.

### 4.4 Negative Balance Handling

- Connected accounts can accumulate negative balances from refunds/disputes
- Stripe offsets negative balances against future payments
- After **180 days** of negative balance, Stripe auto-debit from platform's reserve
- Platform liable for negative balances on Express/Custom accounts

---

## 5. Connect Webhooks

### 5.1 Two Webhook Types

| Type | Endpoint Setting | Events From | `event.account` |
|------|-----------------|-------------|-----------------|
| **Account webhooks** | Standard endpoint | Platform account activity | Not present |
| **Connect webhooks** | Endpoint with `connect: true` | Connected account activity | Connected account ID |

### 5.2 Setting Up Connect Webhooks

```typescript
// Create Connect webhook endpoint
const endpoint = await stripe.webhookEndpoints.create({
  url: 'https://platform.com/connect-webhook',
  enabled_events: [
    'account.updated',
    'account.application.deauthorized',
    'payment_intent.succeeded',
    'payment_intent.payment_failed',
    'payout.failed',
    'payout.paid',
  ],
  connect: true,                         // Receives events from connected accounts
});
```

### 5.3 Handling Connect Events

```typescript
app.post('/connect-webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const event = stripe.webhooks.constructEvent(
    req.body, req.headers['stripe-signature']!, connectWebhookSecret
  );

  const connectedAccountId = event.account; // Always present for Connect events

  switch (event.type) {
    case 'account.updated':
      const account = event.data.object as Stripe.Account;
      if (account.charges_enabled && account.payouts_enabled) {
        // Onboarding complete — activate seller
        await activateSeller(connectedAccountId);
      }
      if (account.requirements?.currently_due?.length) {
        // Additional requirements needed
        await notifySeller(connectedAccountId, 'requirements_needed');
      }
      break;

    case 'account.application.deauthorized':
      // Connected account disconnected from platform
      await deactivateSeller(connectedAccountId);
      break;

    case 'payout.failed':
      const payout = event.data.object as Stripe.Payout;
      await notifySeller(connectedAccountId, 'payout_failed', {
        amount: payout.amount,
        failure_code: payout.failure_code,
      });
      break;
  }

  res.json({ received: true });
});
```

### 5.4 CLI Testing for Connect

```bash
# Forward both account and connect webhooks
stripe listen \
  --forward-to localhost:4242/webhook \
  --forward-connect-to localhost:4242/connect-webhook

# Trigger connect-specific events
stripe trigger account.updated
stripe trigger payout.failed
```

---

## 6. Embedded Components

### 6.1 Overview

17 pre-built UI components for Connect platforms, rendered in your app via `@stripe/connect-js`:

| Component | Purpose |
|-----------|---------|
| `AccountOnboarding` | KYC collection inline |
| `AccountManagement` | Account settings management |
| `Payments` | Payment list and details |
| `Payouts` | Payout history and scheduling |
| `PayoutsList` | Compact payout list |
| `Balances` | Balance overview |
| `Documents` | Tax documents and forms |
| `NotificationBanner` | Action-required alerts |
| `TaxRegistrations` | Tax registration management |
| `TaxSettings` | Tax configuration |
| `FinancialAccount` | Treasury financial accounts |
| `FinancialAccountTransactions` | Transaction history |
| `IssuingCardsList` | Issuing cards management |
| `CapitalOverview` | Capital offers |
| `CapitalFinancing` | Active financing details |
| `PaymentDetails` | Single payment deep-dive |
| `DisputeDetails` | Dispute evidence and management |

### 6.2 React Integration

```typescript
import {
  ConnectComponentsProvider,
  ConnectAccountOnboarding,
  ConnectPayments,
  ConnectPayouts,
} from '@stripe/react-connect-js';
import { loadConnectAndInitialize } from '@stripe/connect-js';

const stripeConnectInstance = loadConnectAndInitialize({
  publishableKey: 'pk_test_...',
  fetchClientSecret: async () => {
    const res = await fetch('/api/connect/account-session', { method: 'POST' });
    const { clientSecret } = await res.json();
    return clientSecret;
  },
  appearance: {
    variables: {
      colorPrimary: '#0570de',
    },
  },
});

function SellerDashboard() {
  return (
    <ConnectComponentsProvider connectInstance={stripeConnectInstance}>
      <ConnectAccountOnboarding
        onExit={() => console.log('Onboarding exited')}
      />
      <ConnectPayments />
      <ConnectPayouts />
    </ConnectComponentsProvider>
  );
}
```

### 6.3 Server-Side: Account Session

```typescript
// Create account session for embedded components
app.post('/api/connect/account-session', async (req, res) => {
  const accountSession = await stripe.accountSessions.create({
    account: 'acct_xxx',                 // Connected account ID
    components: {
      payments: { enabled: true },
      payouts: { enabled: true },
      account_onboarding: { enabled: true },
      account_management: { enabled: true },
      balances: { enabled: true },
      notification_banner: { enabled: true },
    },
  });
  res.json({ clientSecret: accountSession.client_secret });
});
```

---

## 7. Accounts v2 API

GA since December 2025. Unified account object across Billing and Connect.

### 7.1 Key Changes

- Single `Account` object replaces separate Billing/Connect account models
- Simplified field structure with consistent naming
- Better support for platform configurations
- Backward-compatible with v1 endpoints

### 7.2 Creating Accounts v2

```typescript
// v2 account creation
const account = await stripe.v2.core.accounts.create({
  display_name: 'Jane\'s Store',
  contact_email: 'jane@example.com',
  dashboard: 'express',
  identity: {
    business_details: {
      registered_name: 'Jane Doe LLC',
      structure: 'sole_proprietorship',
    },
  },
  defaults: {
    currency: 'usd',
    responsibilities: {
      fees: 'stripe',
      losses: 'stripe',
      requirements: 'stripe',
    },
  },
  configuration: {
    card_payments: { requested: true },
    transfers: { requested: true },
  },
});
```

---

## 8. Radar for Platforms

AI-based detection of fraudulent connected accounts (not just fraudulent transactions).

### 8.1 What It Detects

- Accounts created for money laundering
- Accounts with synthetic/stolen identities
- Accounts that will generate excessive disputes
- Coordinated fraud rings across multiple accounts

### 8.2 Platform-Level Radar Rules

```
# Block onboarding from high-risk email patterns
Block if :account_email: matches '*@disposable-email.com'

# Review accounts with rapid high-value charges
Review if :account_age_days: < 7 AND :total_charge_amount: > 10000

# Flag accounts with unusual payout patterns
Review if :payout_frequency: = 'daily' AND :account_age_days: < 30
```

### 8.3 Monitoring

```typescript
// Listen for Radar alerts
switch (event.type) {
  case 'radar.early_fraud_warning.created':
    const warning = event.data.object;
    // Review connected account
    break;
}
```

---

## 9. Platform Fee Strategies

### 9.1 Application Fee

```typescript
// Fixed fee
const pi = await stripe.paymentIntents.create({
  amount: 10000,
  currency: 'usd',
  application_fee_amount: 1000,          // Fixed $10 fee
  transfer_data: { destination: 'acct_xxx' },
});

// Percentage-based fee (calculate server-side)
function calculateFee(amount: number, feePercent: number): number {
  return Math.round(amount * feePercent / 100);
}
const fee = calculateFee(10000, 15);     // 15% = $15.00
```

### 9.2 Fee Structures

| Model | Implementation | Use Case |
|-------|---------------|----------|
| Fixed percentage | `application_fee_amount: amount * 0.15` | Most marketplaces |
| Flat fee | `application_fee_amount: 200` | Low-value transactions |
| Tiered | Percentage varies by volume/tier | Enterprise platforms |
| Subscription + percentage | Monthly fee + per-transaction fee | SaaS + marketplace hybrid |
| Surge/dynamic | Fee varies by demand/time | Ride-sharing, delivery |

### 9.3 Avoiding Platform Losses

```typescript
// CRITICAL: Application fee must cover Stripe's processing fee
// Stripe's fee: typically 2.9% + $0.30 for US cards

function safeFee(amount: number, platformPercent: number): number {
  const stripeFee = Math.round(amount * 0.029 + 30); // Stripe's approx fee
  const platformFee = Math.round(amount * platformPercent / 100);
  // Ensure platform fee covers Stripe fee
  return Math.max(platformFee, stripeFee);
}
```

### 9.4 Refunding Application Fees

```typescript
// Refund charge — application fee NOT automatically refunded
const refund = await stripe.refunds.create({
  payment_intent: 'pi_xxx',
  refund_application_fee: true,          // Also refund the app fee
});

// Partial refund with proportional fee refund
const refund = await stripe.refunds.create({
  payment_intent: 'pi_xxx',
  amount: 5000,                          // Refund $50 of $100
  refund_application_fee: true,          // Refunds proportional app fee
});
```

---

## 10. Gotchas & Cross-References

### Connect Gotchas

1. **Cannot change account type after creation** — This is the hardest-to-reverse decision. Plan carefully.
2. **Account Link URLs are single-use** — Never email them. Generate fresh on each user access.
3. **Prefill BEFORE Account Link** — KYC data becomes read-only after Account Link on Standard accounts.
4. **Platform Radar rules don't apply to direct charges** — Only the connected account's rules apply.
5. **App fee must cover Stripe fee** — If app fee < Stripe processing fee, the platform absorbs the loss.
6. **Direct charge data lives on connected account** — Must use `stripeAccount` header to query.
7. **Don't change charge type post-launch** — Switching from direct to destination (or vice versa) requires re-architecture.
8. **Negative balances after 180 days** — Platform auto-debited for unrecovered connected account negative balances.
9. **return_url ≠ completion** — User hitting `return_url` does NOT mean onboarding is complete. Always check `charges_enabled` and `payouts_enabled`.
10. **Connect webhook vs Account webhook** — Connected account events only arrive at endpoints with `connect: true`.

### Cross-References

- For payment flows on connected accounts → `payments-and-checkout.md`
- For subscription billing on connected accounts → `subscriptions-and-billing.md`
- For frontend embedded components → `elements-and-frontend.md`
- For Connect webhook handling → `webhooks.md`
- For framework-specific Connect code → `framework-integration.md`
- For Connect error handling → `error-handling-and-rate-limits.md`
- For testing Connect flows → `testing-and-tooling.md`
