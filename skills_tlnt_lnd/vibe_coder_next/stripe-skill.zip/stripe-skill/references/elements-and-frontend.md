# Elements & Frontend — Complete Reference

Covers all Stripe client-side integration: Payment Element, Appearance API, Express Checkout Element, Address Element, Stripe.js core methods, React Stripe.js, Link (accelerated checkout), Embedded Checkout, and mobile SDKs. @stripe/stripe-js v8.8.0, @stripe/react-stripe-js latest.

## Table of Contents

1. [Payment Element](#1-payment-element)
2. [Appearance API](#2-appearance-api)
3. [Express Checkout Element](#3-express-checkout-element)
4. [Address Element](#4-address-element)
5. [Stripe.js Core Methods](#5-stripejs-core-methods)
6. [React Stripe.js](#6-react-stripejs)
7. [Link — Accelerated Checkout](#7-link--accelerated-checkout)
8. [Embedded Checkout](#8-embedded-checkout)
9. [Mobile SDKs](#9-mobile-sdks)
10. [Gotchas & Cross-References](#10-gotchas--cross-references)

---

## 1. Payment Element

Single unified component accepting **100+ payment methods**. Dynamically displays relevant methods based on customer location, currency, amount, and Dashboard configuration.

### 1.1 Server: Create Intent

```typescript
// Option A: PaymentIntent (one-time payment)
const pi = await stripe.paymentIntents.create({
  amount: 1099,
  currency: 'usd',
  automatic_payment_methods: { enabled: true },
});
// Send pi.client_secret to frontend

// Option B: SetupIntent (save payment method)
const si = await stripe.setupIntents.create({
  customer: 'cus_xxx',
  automatic_payment_methods: { enabled: true },
});
// Send si.client_secret to frontend

// Option C: Deferred intent (collect PM first, create intent later)
// No server call needed initially — use elements.submit() on frontend
```

### 1.2 Client: Mount Payment Element

```typescript
import { loadStripe } from '@stripe/stripe-js';

const stripe = await loadStripe('pk_test_...');  // OUTSIDE component render

const elements = stripe.elements({
  clientSecret: 'pi_xxx_secret_yyy',     // From server
  appearance,                             // See Appearance API section
  loader: 'auto',                        // Shows skeleton while loading
  locale: 'auto',                        // Auto-detect locale
});

const paymentElement = elements.create('payment', {
  layout: {
    type: 'accordion',                   // 'tabs' | 'accordion' | 'auto'
    defaultCollapsed: false,
    radios: true,
    spacedAccordionItems: true,
  },
  defaultValues: {
    billingDetails: {
      name: 'John Doe',
      email: 'john@example.com',
      phone: '+1234567890',
      address: {
        country: 'US',
        postal_code: '94110',
      },
    },
  },
  business: {
    name: 'My Store',                    // Shown in some payment methods
  },
  fields: {
    billingDetails: {
      name: 'auto',                      // 'auto' | 'never' (if collecting elsewhere)
      email: 'auto',
      phone: 'never',
      address: 'auto',                   // 'auto' | 'never' | { country: 'never' }
    },
  },
  terms: {
    card: 'auto',                        // Show card terms
    auBecsDebit: 'auto',
    bancontact: 'auto',
    ideal: 'auto',
    sepaDebit: 'auto',
    sofort: 'auto',
    usBankAccount: 'auto',
  },
  wallets: {
    applePay: 'auto',                    // 'auto' | 'never'
    googlePay: 'auto',
  },
});

paymentElement.mount('#payment-element');

// Listen for events
paymentElement.on('change', (event) => {
  if (event.complete) {
    // Form is complete and valid
  }
  if (event.error) {
    setErrorMessage(event.error.message);
  }
});

paymentElement.on('ready', () => {
  // Element is fully rendered
});
```

### 1.3 Layout Options

| Layout | Description | Best For |
|--------|-------------|----------|
| `tabs` | Horizontal tabs (default) | 1-3 payment methods |
| `accordion` | Expandable sections with radio buttons | 4+ payment methods |
| `auto` | Stripe selects based on method count | General use |

### 1.4 Confirm Payment

```typescript
const form = document.getElementById('payment-form');
form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const { error } = await stripe.confirmPayment({
    elements,
    confirmParams: {
      return_url: 'https://example.com/order/complete',
      receipt_email: 'customer@example.com',
      shipping: {
        name: 'John Doe',
        address: { line1: '123 Main St', city: 'SF', state: 'CA', postal_code: '94110', country: 'US' },
      },
    },
    redirect: 'if_required',            // 'always' (default) | 'if_required'
  });

  if (error) {
    if (error.type === 'card_error' || error.type === 'validation_error') {
      setMessage(error.message);
    } else {
      setMessage('An unexpected error occurred.');
    }
  }
  // If redirect: 'if_required' and no redirect needed, payment succeeded here
});
```

### 1.5 Deferred Intent Flow

Collect payment details first, create the intent server-side after:

```typescript
// Client: Submit form without intent
const { error: submitError } = await elements.submit();
if (submitError) { handleError(submitError); return; }

// Client: Request intent from server
const res = await fetch('/create-intent', {
  method: 'POST',
  body: JSON.stringify({ items: cart }),
});
const { clientSecret } = await res.json();

// Client: Confirm with the new intent
const { error } = await stripe.confirmPayment({
  elements,
  clientSecret,
  confirmParams: { return_url: 'https://example.com/complete' },
});
```

---

## 2. Appearance API

### 2.1 Built-in Themes

| Theme | Description |
|-------|-------------|
| `stripe` | Default — clean, white background |
| `night` | Dark mode |
| `flat` | Minimal, flat design |

### 2.2 Variables

```typescript
const appearance: Stripe.Appearance = {
  theme: 'stripe',
  variables: {
    // Colors
    colorPrimary: '#0570de',
    colorBackground: '#ffffff',
    colorText: '#30313d',
    colorDanger: '#df1b41',
    colorSuccess: '#28a745',
    colorWarning: '#ffc107',
    colorTextSecondary: '#6d6e78',
    colorTextPlaceholder: '#aab7c4',

    // Typography
    fontFamily: 'Ideal Sans, system-ui, sans-serif',
    fontSizeBase: '16px',
    fontSizeSm: '14px',
    fontSizeLg: '18px',
    fontSizeXl: '20px',
    fontWeightNormal: '400',
    fontWeightMedium: '500',
    fontWeightBold: '700',
    fontLineHeight: '1.5',

    // Spacing & Shape
    borderRadius: '4px',
    spacingUnit: '4px',
    spacingGridRow: '16px',
    spacingGridColumn: '16px',
    spacingTab: '12px',
    spacingAccordionItem: '8px',

    // Shadows
    focusBoxShadow: '0 0 0 3px rgba(5, 112, 222, 0.25)',
    focusOutline: 'none',
  },
};
```

### 2.3 Rules (CSS-like Targeting)

```typescript
const appearance: Stripe.Appearance = {
  theme: 'stripe',
  variables: { colorPrimary: '#0570de' },
  rules: {
    '.Tab': {
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      padding: '10px 12px',
      transition: 'all 0.2s ease',
    },
    '.Tab:hover': {
      border: '1px solid #0570de',
    },
    '.Tab--selected': {
      border: '1px solid #0570de',
      boxShadow: '0 0 0 2px rgba(5, 112, 222, 0.2)',
      backgroundColor: '#f7f9fc',
    },
    '.Input': {
      padding: '12px',
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      transition: 'border-color 0.15s ease',
    },
    '.Input:focus': {
      border: '1px solid #0570de',
      boxShadow: '0 0 0 3px rgba(5, 112, 222, 0.15)',
    },
    '.Input--invalid': {
      border: '1px solid #df1b41',
      boxShadow: '0 0 0 2px rgba(223, 27, 65, 0.15)',
    },
    '.Label': {
      fontWeight: '500',
      fontSize: '14px',
      marginBottom: '4px',
    },
    '.Error': {
      color: '#df1b41',
      fontSize: '13px',
      marginTop: '4px',
    },
    '.AccordionItem': {
      border: '1px solid #e0e0e0',
      borderRadius: '8px',
      marginBottom: '8px',
    },
    '.Block': {
      padding: '12px',
      backgroundColor: '#f8f9fa',
      borderRadius: '4px',
    },
    '.CheckboxLabel': {
      fontSize: '14px',
    },
    '.PickerItem': {
      padding: '8px 12px',
      borderRadius: '4px',
    },
    '.PickerItem--selected': {
      backgroundColor: '#f0f7ff',
      border: '1px solid #0570de',
    },
  },
};
```

### 2.4 Targetable Selectors

| Selector | Description |
|----------|-------------|
| `.Tab` | Payment method tab |
| `.Input` | Text input fields |
| `.Label` | Field labels |
| `.Error` | Error messages |
| `.Block` | Container blocks |
| `.AccordionItem` | Accordion section |
| `.CheckboxLabel` | Checkbox labels |
| `.PickerItem` | Dropdown/picker items |
| `.RedirectText` | Redirect info text |
| `.MenuAction` | Menu action items |

**States**: `--selected`, `--empty`, `--invalid`, `--focused`
**Pseudo-classes**: `:hover`, `:focus`, `:disabled`, `::placeholder`, `::selection`

### 2.5 Dark Mode Toggle

```typescript
function getAppearance(isDark: boolean): Stripe.Appearance {
  return {
    theme: isDark ? 'night' : 'stripe',
    variables: {
      colorPrimary: isDark ? '#7c93ee' : '#0570de',
      colorBackground: isDark ? '#1a1a2e' : '#ffffff',
      colorText: isDark ? '#e0e0e0' : '#30313d',
      fontFamily: 'Inter, system-ui, sans-serif',
      borderRadius: '8px',
    },
    rules: {
      '.Input': {
        backgroundColor: isDark ? '#16213e' : '#ffffff',
        border: `1px solid ${isDark ? '#2a2a4a' : '#e0e0e0'}`,
      },
    },
  };
}

// Update appearance dynamically
elements.update({ appearance: getAppearance(true) });
```

---

## 3. Express Checkout Element

Single component displaying one-click wallet buttons: Apple Pay, Google Pay, PayPal, Link, Klarna, Amazon Pay. Buttons auto-sort by relevance to the customer.

### 3.1 Setup

```typescript
const expressCheckout = elements.create('expressCheckout', {
  buttonHeight: 50,
  buttonType: {
    applePay: 'buy',                     // 'buy' | 'plain' | 'book' | 'check-out' | 'donate' | 'subscribe'
    googlePay: 'buy',
  },
  buttonTheme: {
    applePay: 'black',                   // 'black' | 'white' | 'white-outline'
    googlePay: 'black',
  },
  layout: {
    maxColumns: 3,
    maxRows: 1,
    overflow: 'auto',                    // 'auto' | 'never'
  },
  paymentMethodOrder: ['apple_pay', 'google_pay', 'link'],
});

expressCheckout.mount('#express-checkout');
```

### 3.2 Event Handling

```typescript
expressCheckout.on('confirm', async (event) => {
  const { error } = await stripe.confirmPayment({
    elements,
    clientSecret,
    confirmParams: {
      return_url: 'https://example.com/success',
    },
  });
  if (error) {
    // Inform customer
  }
});

expressCheckout.on('cancel', () => {
  // User canceled wallet payment
});

expressCheckout.on('shippingaddresschange', async (event) => {
  // Calculate shipping based on address
  const response = await calculateShipping(event.address);
  event.resolve({
    shippingRates: response.rates,
  });
});

expressCheckout.on('shippingratechange', async (event) => {
  // User selected a shipping rate
  const rate = event.shippingRate;
  // Update total on server
});
```

### 3.3 Deduplication with Payment Element

When Express Checkout Element and Payment Element are rendered together from the **same `elements` instance**, wallet methods (Apple Pay, Google Pay) appear only in Express Checkout to avoid duplication. This happens automatically — no configuration needed.

```typescript
// Same elements instance → automatic deduplication
const elements = stripe.elements({ clientSecret, appearance });
const expressCheckout = elements.create('expressCheckout');
const paymentElement = elements.create('payment');
// Apple Pay / Google Pay only show in Express Checkout, not Payment Element
```

---

## 4. Address Element

### 4.1 Modes

| Mode | Description |
|------|-------------|
| `shipping` | Collects shipping address, includes "Use as billing" checkbox |
| `billing` | Collects billing address, hides billing fields in Payment Element |

### 4.2 Setup

```typescript
const addressElement = elements.create('address', {
  mode: 'shipping',
  allowedCountries: ['US', 'CA', 'GB', 'DE', 'FR'],
  autocomplete: {
    mode: 'google_maps_api',             // Free with Payment Element
    apiKey: 'GOOGLE_MAPS_KEY',           // Optional for standalone
  },
  blockPoBox: true,
  contacts: [                            // Pre-filled addresses
    {
      name: 'John Doe',
      address: {
        line1: '123 Main St',
        city: 'San Francisco',
        state: 'CA',
        postal_code: '94110',
        country: 'US',
      },
    },
  ],
  defaultValues: {
    name: 'John Doe',
    address: { country: 'US' },
  },
  display: {
    name: 'full',                        // 'full' | 'split' | 'organization'
  },
  fields: {
    phone: 'always',                     // 'always' | 'auto' | 'never'
  },
  validation: {
    phone: { required: 'always' },       // 'always' | 'auto' | 'never'
  },
});

addressElement.mount('#address-element');
```

### 4.3 Get Address Value

```typescript
addressElement.on('change', (event) => {
  if (event.complete) {
    const address = event.value;
    console.log(address.name);
    console.log(address.address.line1);
    console.log(address.address.city);
    console.log(address.address.state);
    console.log(address.address.postal_code);
    console.log(address.address.country);
    console.log(address.phone);
  }
});

// Or get value imperatively
const { complete, value } = addressElement.getValue();
```

### 4.4 Combined with Payment Element

Create from the **same `elements` instance** for automatic billing address population:

```typescript
const elements = stripe.elements({ clientSecret, appearance });
const addressElement = elements.create('address', { mode: 'billing' });
const paymentElement = elements.create('payment');
// Billing fields hidden in Payment Element, collected by Address Element
```

---

## 5. Stripe.js Core Methods

### 5.1 Loading

```typescript
import { loadStripe } from '@stripe/stripe-js';

// Load Stripe.js — call ONCE at module level
const stripePromise = loadStripe('pk_test_...', {
  locale: 'auto',                        // Auto-detect or specify: 'en', 'es', 'fr', etc.
  stripeAccount: 'acct_xxx',             // For Connect direct charges
  betas: ['address_element_beta_1'],     // Enable beta features
});

const stripe = await stripePromise;
```

### 5.2 Elements Instance

```typescript
// With client secret (standard flow)
const elements = stripe.elements({
  clientSecret: 'pi_xxx_secret_yyy',
  appearance,
  locale: 'auto',
  loader: 'auto',                        // 'auto' | 'always' | 'never'
  fonts: [
    { cssSrc: 'https://fonts.googleapis.com/css2?family=Inter' },
  ],
});

// Without client secret (deferred intent)
const elements = stripe.elements({
  mode: 'payment',                       // 'payment' | 'setup' | 'subscription'
  amount: 1099,
  currency: 'usd',
  appearance,
  paymentMethodCreation: 'manual',
});

// Update elements
elements.update({ appearance: newAppearance });
```

### 5.3 Confirm Methods

```typescript
// Confirm payment (redirects by default)
const { error } = await stripe.confirmPayment({
  elements,
  confirmParams: {
    return_url: 'https://example.com/complete',
    receipt_email: 'customer@example.com',
  },
  redirect: 'if_required',
});

// Confirm setup (save PM)
const { error } = await stripe.confirmSetup({
  elements,
  confirmParams: {
    return_url: 'https://example.com/setup-complete',
  },
});

// Confirm card payment (legacy, still works)
const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
  payment_method: {
    card: cardElement,
    billing_details: { name: 'Jenny Rosen' },
  },
});
```

### 5.4 Retrieve Methods

```typescript
// Check payment status after redirect
const { paymentIntent } = await stripe.retrievePaymentIntent(clientSecret);
switch (paymentIntent.status) {
  case 'succeeded': showSuccess(); break;
  case 'processing': showProcessing(); break;
  case 'requires_payment_method': showError('Payment failed.'); break;
  default: showError('Something went wrong.'); break;
}

// Check setup status
const { setupIntent } = await stripe.retrieveSetupIntent(clientSecret);
```

### 5.5 Form Validation (Deferred)

```typescript
// Validate form without confirming
const { error } = await elements.submit();
if (error) {
  console.log(error.type);     // 'validation_error'
  console.log(error.message);  // Human-readable message
}
```

### 5.6 Payment Method Creation

```typescript
// Create PaymentMethod manually (deferred intent flow)
const { error, paymentMethod } = await stripe.createPaymentMethod({
  elements,
  params: {
    billing_details: {
      name: 'Jenny Rosen',
      email: 'jenny@example.com',
    },
  },
});
// Send paymentMethod.id to server
```

---

## 6. React Stripe.js

### 6.1 Setup

```bash
npm install @stripe/stripe-js @stripe/react-stripe-js
```

```tsx
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';

// CRITICAL: Load OUTSIDE any component (module level)
const stripePromise = loadStripe('pk_test_...');
```

### 6.2 Elements Provider

```tsx
function App() {
  const [clientSecret, setClientSecret] = useState('');

  useEffect(() => {
    fetch('/create-payment-intent', { method: 'POST' })
      .then(res => res.json())
      .then(data => setClientSecret(data.clientSecret));
  }, []);

  if (!clientSecret) return <LoadingSkeleton />;

  return (
    <Elements
      stripe={stripePromise}
      options={{
        clientSecret,
        appearance: {
          theme: 'stripe',
          variables: { colorPrimary: '#0570de' },
        },
        loader: 'auto',
      }}
    >
      <CheckoutForm />
    </Elements>
  );
}
```

### 6.3 Checkout Form Component

```tsx
import {
  PaymentElement,
  useStripe,
  useElements,
  AddressElement,
  ExpressCheckoutElement,
} from '@stripe/react-stripe-js';

function CheckoutForm() {
  const stripe = useStripe();
  const elements = useElements();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;
    setLoading(true);
    setError(null);

    // Validate form
    const { error: submitError } = await elements.submit();
    if (submitError) {
      setError(submitError.message ?? 'Validation failed');
      setLoading(false);
      return;
    }

    // Confirm payment
    const { error: confirmError } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/order/complete`,
      },
    });

    if (confirmError) {
      setError(confirmError.message ?? 'Payment failed');
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit}>
      <ExpressCheckoutElement
        onConfirm={async () => {
          if (!stripe || !elements) return;
          await stripe.confirmPayment({
            elements,
            confirmParams: { return_url: `${window.location.origin}/order/complete` },
          });
        }}
      />
      <hr />
      <AddressElement options={{ mode: 'shipping' }} />
      <PaymentElement
        options={{
          layout: { type: 'accordion', defaultCollapsed: false },
        }}
      />
      <button type="submit" disabled={!stripe || loading}>
        {loading ? 'Processing...' : 'Pay now'}
      </button>
      {error && <div className="text-red-500 mt-2">{error}</div>}
    </form>
  );
}
```

### 6.4 Next.js App Router Integration

```tsx
// app/checkout/page.tsx (Server Component — fetches client secret)
import { stripe } from '@/lib/stripe';  // Server-side singleton
import CheckoutClient from './checkout-client';

export default async function CheckoutPage() {
  const paymentIntent = await stripe.paymentIntents.create({
    amount: 2000,
    currency: 'usd',
    automatic_payment_methods: { enabled: true },
  });

  return <CheckoutClient clientSecret={paymentIntent.client_secret!} />;
}

// app/checkout/checkout-client.tsx (Client Component)
'use client';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!);

function CheckoutForm() {
  const stripe = useStripe();
  const elements = useElements();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: { return_url: `${window.location.origin}/checkout/complete` },
    });
    if (error) console.error(error);
  };

  return (
    <form onSubmit={handleSubmit}>
      <PaymentElement />
      <button type="submit" disabled={!stripe}>Pay</button>
    </form>
  );
}

export default function CheckoutClient({ clientSecret }: { clientSecret: string }) {
  return (
    <Elements stripe={stripePromise} options={{ clientSecret }}>
      <CheckoutForm />
    </Elements>
  );
}
```

### 6.5 Server Components — Pricing Page

```tsx
// app/pricing/page.tsx (Server Component — no client JS)
import { stripe } from '@/lib/stripe';

export default async function PricingPage() {
  const prices = await stripe.prices.list({
    lookup_keys: ['starter_monthly', 'pro_monthly', 'enterprise_monthly'],
    active: true,
    expand: ['data.product'],
  });

  return (
    <div className="grid grid-cols-3 gap-8">
      {prices.data.map((price) => {
        const product = price.product as Stripe.Product;
        return (
          <div key={price.id} className="border rounded-lg p-6">
            <h2>{product.name}</h2>
            <p className="text-3xl font-bold">
              ${(price.unit_amount! / 100).toFixed(2)}/mo
            </p>
            <ul>
              {product.marketing_features?.map((f, i) => (
                <li key={i}>{f.name}</li>
              ))}
            </ul>
            <form action={`/api/checkout?price=${price.id}`} method="POST">
              <button type="submit">Subscribe</button>
            </form>
          </div>
        );
      })}
    </div>
  );
}
```

---

## 7. Link — Accelerated Checkout

Stripe Link saves payment info and addresses across all Stripe merchants. **14% increase** in returning user conversion.

### 7.1 How It Works

1. Customer enters email in Payment Element
2. If email has Link account → auto-fills payment and shipping
3. If new email → offers to save for future purchases
4. Works across all Stripe merchants (network effect)

### 7.2 Integration Approaches

```tsx
// Approach 1: Default — collect email in Payment Element
<PaymentElement />
// Link auto-activates when customer enters email

// Approach 2: Pass email via defaultValues
<PaymentElement
  options={{
    defaultValues: {
      billingDetails: { email: userEmail },
    },
  }}
/>
// Immediately checks for Link account

// Approach 3: Link Authentication Element (dedicated email input)
import { LinkAuthenticationElement } from '@stripe/react-stripe-js';

<LinkAuthenticationElement
  options={{
    defaultValues: { email: userEmail },
  }}
  onChange={(event) => {
    setEmail(event.value.email);
  }}
/>
<PaymentElement />
// Renders email input that auto-fills on Link match
```

### 7.3 Enabling/Disabling

Enable Link in Stripe Dashboard: Settings > Payment methods > Link. Enabled by default when Payment Element is active.

---

## 8. Embedded Checkout

### 8.1 React Component

```tsx
import { loadStripe } from '@stripe/stripe-js';
import {
  EmbeddedCheckoutProvider,
  EmbeddedCheckout,
} from '@stripe/react-stripe-js';

const stripePromise = loadStripe('pk_test_...');

function EmbeddedCheckoutPage() {
  const fetchClientSecret = useCallback(async () => {
    const res = await fetch('/api/create-checkout-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ priceId: 'price_xxx' }),
    });
    const { clientSecret } = await res.json();
    return clientSecret;
  }, []);

  return (
    <EmbeddedCheckoutProvider
      stripe={stripePromise}
      options={{ fetchClientSecret }}
    >
      <EmbeddedCheckout />
    </EmbeddedCheckoutProvider>
  );
}
```

### 8.2 Server: Create Embedded Session

```typescript
// API route
export async function POST(req: Request) {
  const { priceId } = await req.json();

  const session = await stripe.checkout.sessions.create({
    ui_mode: 'embedded',
    mode: 'subscription',
    line_items: [{ price: priceId, quantity: 1 }],
    return_url: `${process.env.NEXT_PUBLIC_URL}/checkout/return?session_id={CHECKOUT_SESSION_ID}`,
  });

  return Response.json({ clientSecret: session.client_secret });
}
```

### 8.3 Return Page

```tsx
// app/checkout/return/page.tsx
'use client';
import { useSearchParams } from 'next/navigation';

export default function ReturnPage() {
  const searchParams = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const [status, setStatus] = useState<string>('loading');

  useEffect(() => {
    fetch(`/api/checkout-session?session_id=${sessionId}`)
      .then(res => res.json())
      .then(data => setStatus(data.status));
  }, [sessionId]);

  if (status === 'complete') return <p>Payment successful!</p>;
  if (status === 'open') return <p>Payment not completed. Please try again.</p>;
  return <p>Loading...</p>;
}
```

### 8.4 Embedded vs Hosted Checkout

| Feature | Embedded | Hosted |
|---------|----------|--------|
| UI location | In your page | Stripe's page (redirect) |
| Customization | Theme/appearance | Limited branding |
| URL | Your domain | checkout.stripe.com |
| Session management | Client secret + React | Redirect to session.url |
| Mobile experience | Inline | Full-page redirect |
| Best for | Seamless UX | Simplest integration |

---

## 9. Mobile SDKs

### 9.1 React Native (Expo/RN)

```bash
# Expo
npx expo install @stripe/stripe-react-native

# Bare React Native
npm install @stripe/stripe-react-native
cd ios && pod install
```

```tsx
import { StripeProvider, useStripe } from '@stripe/stripe-react-native';

function App() {
  return (
    <StripeProvider
      publishableKey="pk_test_..."
      merchantIdentifier="merchant.com.example"  // Apple Pay
      urlScheme="myapp"                           // For redirects
    >
      <PaymentScreen />
    </StripeProvider>
  );
}

function PaymentScreen() {
  const { initPaymentSheet, presentPaymentSheet } = useStripe();

  const setup = async () => {
    const { clientSecret } = await fetchPaymentIntent();

    const { error } = await initPaymentSheet({
      paymentIntentClientSecret: clientSecret,
      merchantDisplayName: 'My Store',
      applePay: { merchantCountryCode: 'US' },
      googlePay: { merchantCountryCode: 'US', testEnv: true },
      returnURL: 'myapp://stripe-redirect',
      defaultBillingDetails: { name: 'John Doe' },
    });
    if (error) console.error(error);
  };

  const pay = async () => {
    const { error } = await presentPaymentSheet();
    if (error) {
      Alert.alert('Error', error.message);
    } else {
      Alert.alert('Success', 'Payment confirmed!');
    }
  };

  useEffect(() => { setup(); }, []);

  return <Button title="Pay" onPress={pay} />;
}
```

### 9.2 Apple Pay / Google Pay (Mobile)

```tsx
import { useApplePay, useGooglePay } from '@stripe/stripe-react-native';

function WalletPayment() {
  const { presentApplePay, isApplePaySupported } = useApplePay();
  const { presentGooglePay, isGooglePaySupported } = useGooglePay();

  const payWithApple = async () => {
    const { error } = await presentApplePay({
      cartItems: [{ label: 'Total', amount: '20.00', paymentType: 'Immediate' }],
      country: 'US',
      currency: 'USD',
    });
    if (error) console.error(error);
  };

  return (
    <>
      {isApplePaySupported && <Button title="Apple Pay" onPress={payWithApple} />}
      {isGooglePaySupported && <Button title="Google Pay" onPress={payWithGoogle} />}
    </>
  );
}
```

---

## 10. Gotchas & Cross-References

### Frontend Gotchas

1. **loadStripe() outside component render** — Calling inside a component body creates multiple instances, memory leaks, and duplicate Elements. Always call at module level.
2. **Same `elements` instance for deduplication** — Express Checkout and Payment Element must share the same `elements` instance for wallet method deduplication.
3. **`redirect: 'if_required'`** — Use this to avoid unnecessary redirects for card payments. Default `'always'` redirects even when not needed.
4. **CSP configuration** — Allow `js.stripe.com` and `api.stripe.com` in Content-Security-Policy headers.
5. **Appearance updates** — Call `elements.update({ appearance })` to change theme. Don't recreate the elements instance.
6. **Server Components cannot use Stripe.js** — `@stripe/stripe-js` and `@stripe/react-stripe-js` are client-only. Use `'use client'` directive.
7. **Mobile `returnURL` scheme** — Must match your app's URL scheme for redirect-based payment methods.
8. **Input font size** — Use `fontSizeBase: '16px'` or larger to prevent iOS Safari auto-zoom on input focus.

### Cross-References

- For server-side payment creation → `payments-and-checkout.md`
- For Connect embedded components → `stripe-connect.md`
- For webhook-based fulfillment after payment → `webhooks.md`
- For framework-specific integration → `framework-integration.md`
- For testing Elements → `testing-and-tooling.md`
- For security (CSP, PCI) → `security-and-pci.md`
