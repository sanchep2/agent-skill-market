# Migration & Versioning — Complete Reference

Covers Stripe's API versioning system, biannual release cadence (Acacia/Basil/Clover), breaking changes per release, Sources API migration, legacy Meters migration, SDK upgrade guide, and key deprecation timeline. API version `2026-01-28.clover`.

## Table of Contents

1. [API Versioning System](#1-api-versioning-system)
2. [Release History](#2-release-history)
3. [Basil Breaking Changes](#3-basil-breaking-changes)
4. [Clover Breaking Changes](#4-clover-breaking-changes)
5. [Sources API Migration](#5-sources-api-migration)
6. [Legacy Usage Records → Meters API](#6-legacy-usage-records--meters-api)
7. [SDK Upgrade Guide](#7-sdk-upgrade-guide)
8. [Key Deprecations Timeline](#8-key-deprecations-timeline)
9. [Gotchas & Cross-References](#9-gotchas--cross-references)

---

## 1. API Versioning System

### 1.1 How Versioning Works

Stripe uses **date-based API versions** with biannual **major releases** (named alphabetically) plus monthly backward-compatible updates.

```
Format: YYYY-MM-DD.release_name
Example: 2026-01-28.clover

Major releases: Acacia → Basil → Clover → (next: D-name)
Monthly releases: 2025-10-28.clover, 2025-11-28.clover, 2025-12-28.clover, 2026-01-28.clover
```

### 1.2 Version Pinning

```typescript
// SDKs auto-pin API version at release time
// stripe npm v20.3.1 → auto-uses 2026-01-28.clover
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// Override API version (advanced — not recommended)
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2026-01-28',
});

// Per-request version override
const pi = await stripe.paymentIntents.retrieve('pi_xxx', {
  apiVersion: '2025-09-30.clover' as any,
});
```

### 1.3 Account Version vs SDK Version

| Concept | Description | Where Set |
|---------|-------------|-----------|
| **Account API version** | Default for Dashboard, webhooks, and un-versioned requests | Dashboard > Developers > API version |
| **SDK API version** | Pinned at SDK release — overrides account version for SDK requests | Automatic per SDK release |
| **Request override** | Per-request version | `apiVersion` parameter |

**Webhook events use your account API version**, not the SDK version. Upgrade your account version to get new event shapes.

### 1.4 Rollback Window

After upgrading your account API version:
- **72-hour rollback window** — can revert to previous version via Dashboard
- After 72 hours, the upgrade is permanent
- Rollback only affects account version (not SDK behavior)

### 1.5 Safe Upgrade Path

```
1. Read changelog for target version
2. Update SDK to latest
3. Run test suite against new SDK
4. Fix any breaking changes in code
5. Deploy updated code
6. Upgrade account API version in Dashboard
7. Monitor webhooks for 72 hours
8. If issues: rollback within 72 hours
```

---

## 2. Release History

### 2.1 Major Releases

| Release | Name | Date | Key Changes |
|---------|------|------|-------------|
| — | Acacia | 2024-09-30 | First named release; new versioning system |
| — | Basil | 2025-03-31 | Removed legacy usage records, invoice changes |
| — | Clover | 2025-09-30 | Flexible billing default, currency_conversion removed |

### 2.2 Monthly Releases (Clover Family)

| Version | Date | Notable Additions |
|---------|------|-------------------|
| `2025-09-30.clover` | Sep 2025 | Clover initial release |
| `2025-10-28.clover` | Oct 2025 | Minor additive changes |
| `2025-11-28.clover` | Nov 2025 | Minor additive changes |
| `2025-12-28.clover` | Dec 2025 | Accounts v2 GA, Agentic Commerce Suite |
| `2026-01-28.clover` | Jan 2026 | **Current** — latest monthly release |

Monthly releases within the same family are **backward-compatible** — safe to upgrade without code changes.

---

## 3. Basil Breaking Changes

### 3.1 Removed APIs

| Removed | Replacement | Migration |
|---------|-------------|-----------|
| `SubscriptionItem.createUsageRecord()` | Meters API `billing.meterEvents.create()` | See section 6 |
| `SubscriptionItem.listUsageRecordSummaries()` | Meters API `billing.meters.listEventSummaries()` | See section 6 |
| `Invoice.retrieveUpcoming()` | Invoice Create Preview API | Use `stripe.invoices.createPreview()` |
| `invoice` field on Charge/PaymentIntent | Separate invoice retrieval | Fetch invoice separately via `invoice` ID |
| `total_count` expansion on list endpoints | Count separately or use Search API | Remove `expand: ['total_count']` |

### 3.2 Behavioral Changes

| Change | Before | After |
|--------|--------|-------|
| Checkout subscription creation | Subscription created at session start | Subscription created after payment completes |
| Invoice retrieval from Charge | `charge.invoice` was expandable object | `charge.invoice` is string ID only |

### 3.3 Migration Code

```typescript
// BEFORE (pre-Basil): Usage records
await stripe.subscriptionItems.createUsageRecord('si_xxx', {
  quantity: 100,
  action: 'increment',
});

// AFTER (Basil+): Meters API
await stripe.billing.meterEvents.create({
  event_name: 'api_calls',
  payload: {
    value: '100',
    stripe_customer_id: 'cus_xxx',
  },
});

// BEFORE (pre-Basil): Upcoming invoice
const upcoming = await stripe.invoices.retrieveUpcoming({
  customer: 'cus_xxx',
});

// AFTER (Basil+): Create preview
const preview = await stripe.invoices.createPreview({
  customer: 'cus_xxx',
});
```

---

## 4. Clover Breaking Changes

### 4.1 Changes

| Change | Before | After |
|--------|--------|-------|
| Flexible billing mode | Opt-in | **Default** for new subscriptions |
| `currency_conversion` field | Present on charges | Removed — use `presentment_details` |
| Client secret reuse in Elements | Allowed | Prevented — create new intent for each attempt |
| Subscription proration | Automatic | More explicit proration_behavior handling |

### 4.2 Migration Code

```typescript
// BEFORE (pre-Clover): currency_conversion
const charge = await stripe.charges.retrieve('ch_xxx');
const conversion = charge.currency_conversion;  // Removed

// AFTER (Clover+): presentment_details
const charge = await stripe.charges.retrieve('ch_xxx');
const details = charge.presentment_details;
// details.presentment_amount, details.presentment_currency

// BEFORE: Reuse client_secret in Elements
// (User could retry with same client_secret after failure)

// AFTER: Create new PaymentIntent for each attempt
// If payment fails, create a new PI instead of retrying the same one
```

### 4.3 Flexible Billing Mode

In Clover, flexible billing is the default. This means:
- Subscriptions can have items with different billing intervals
- Proration behavior is more granular
- Invoice line items have more detailed metadata

```typescript
// Flexible billing: multiple intervals on one subscription
const sub = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [
    { price: 'price_monthly' },           // Monthly component
    { price: 'price_annual_addon' },       // Annual add-on
  ],
});
```

---

## 5. Sources API Migration

### 5.1 Overview

The Sources API is **deprecated**. Migrate to PaymentMethods + PaymentIntents.

| Old (Sources) | New (PaymentMethods) |
|--------------|---------------------|
| `stripe.sources.create()` | `stripe.paymentMethods.create()` |
| `source` param on charge | `payment_method` param on PaymentIntent |
| Source object (`src_xxx`) | PaymentMethod object (`pm_xxx`) |
| Token-based flow | Intent-based flow |

### 5.2 Migration Steps

```typescript
// BEFORE: Sources flow
// 1. Create source
const source = await stripe.sources.create({
  type: 'card',
  token: 'tok_xxx',
});

// 2. Attach to customer
await stripe.customers.update('cus_xxx', {
  source: source.id,
});

// 3. Charge
await stripe.charges.create({
  amount: 2000,
  currency: 'usd',
  customer: 'cus_xxx',
  source: source.id,
});

// AFTER: PaymentMethods + PaymentIntents flow
// 1. Create PaymentMethod (or use Elements)
const pm = await stripe.paymentMethods.create({
  type: 'card',
  card: { token: 'tok_xxx' },
});

// 2. Attach to customer
await stripe.paymentMethods.attach(pm.id, { customer: 'cus_xxx' });
await stripe.customers.update('cus_xxx', {
  invoice_settings: { default_payment_method: pm.id },
});

// 3. Create PaymentIntent
await stripe.paymentIntents.create({
  amount: 2000,
  currency: 'usd',
  customer: 'cus_xxx',
  payment_method: pm.id,
  confirm: true,
});
```

### 5.3 Source Types → PaymentMethod Types

| Source Type | PaymentMethod Type | Notes |
|-----------|-------------------|-------|
| `card` | `card` | Direct replacement |
| `sepa_debit` | `sepa_debit` | Direct replacement |
| `ideal` | `ideal` | Use PaymentIntents flow |
| `bancontact` | `bancontact` | Use PaymentIntents flow |
| `sofort` | `sofort` | Deprecated, use `sepa_debit` |
| `alipay` | `alipay` | Use PaymentIntents flow |
| `wechat` | `wechat_pay` | Use PaymentIntents flow |
| `three_d_secure` | Built into PaymentIntents | 3DS is automatic |

### 5.4 Timeline

- Card payments via Sources still work (no removal date set)
- All other Source types: migrate ASAP
- New integrations should NEVER use Sources API
- `three_d_secure` source type: handled automatically by PaymentIntents

---

## 6. Legacy Usage Records → Meters API

### 6.1 Key Differences

| Feature | Legacy Usage Records | Meters API |
|---------|---------------------|------------|
| API | `subscriptionItems.createUsageRecord()` | `billing.meterEvents.create()` |
| Reporting | End of period only | **Real-time** |
| Throughput | Limited | 1,000/sec (10,000/sec high-throughput) |
| Aggregation | Sum only | Sum, count, last |
| Dimensions | None | **Dimensional pricing** (Preview) |
| Status | **Removed in Basil** | GA since April 2024 |

### 6.2 Migration Steps

```typescript
// Step 1: Create Meter (replaces implicit usage tracking)
const meter = await stripe.billing.meters.create({
  display_name: 'API Calls',
  event_name: 'api_calls',
  default_aggregation: { formula: 'sum' },
  customer_mapping: {
    type: 'by_id',
    event_payload_key: 'stripe_customer_id',
  },
  value_settings: { event_payload_key: 'value' },
});

// Step 2: Create metered price linked to Meter
const price = await stripe.prices.create({
  product: 'prod_xxx',
  currency: 'usd',
  recurring: {
    interval: 'month',
    usage_type: 'metered',
    meter: meter.id,
  },
  unit_amount: 1,  // $0.01 per unit
});

// Step 3: Update existing subscriptions to use new price
await stripe.subscriptions.update('sub_xxx', {
  items: [{
    id: 'si_xxx',
    price: price.id,  // New metered price
  }],
});

// Step 4: Replace usage record calls with meter events
// BEFORE:
// await stripe.subscriptionItems.createUsageRecord('si_xxx', {
//   quantity: 100, action: 'increment'
// });

// AFTER:
await stripe.billing.meterEvents.create({
  event_name: 'api_calls',
  payload: {
    value: '100',
    stripe_customer_id: 'cus_xxx',
  },
});
```

---

## 7. SDK Upgrade Guide

### 7.1 Node.js / TypeScript

| From | To | Breaking Changes |
|------|-----|-----------------|
| v15.x | v16.x | ESM support, Node 14+ required |
| v16.x | v17.x | DiscriminatedEvent type added |
| v17.x–v19.x | v20.x | Minor type changes, Clover API default |
| Any | v20.3.1 | Latest — recommended target |

```bash
# Check current version
npm list stripe

# Upgrade
npm install stripe@latest

# Check for type errors
npx tsc --noEmit
```

### 7.2 Python

| From | To | Breaking Changes |
|------|-----|-----------------|
| v8.x | v9.x | StripeClient pattern introduced |
| v9.x–v13.x | v14.x | Async support, type hints |
| Any | v14.3.0 | Latest — recommended target |

```bash
pip install --upgrade stripe
```

### 7.3 Ruby

| From | To | Breaking Changes |
|------|-----|-----------------|
| v10.x | v11.x+ | StripeClient pattern |
| Any | v18.3.0 | Latest — recommended target |

```bash
bundle update stripe
```

### 7.4 Compatibility Matrix

| SDK Version | Min API Version | Max API Version | Runtime |
|------------|----------------|----------------|---------|
| stripe npm v20.x | Acacia | Clover (2026-01-28) | Node 14+ |
| stripe npm v19.x | Acacia | Basil-era | Node 14+ |
| stripe-python v14.x | Acacia | Clover (2026-01-28) | Python 3.8+ |
| stripe-ruby v18.x | Acacia | Clover (2026-01-28) | Ruby 3.0+ |
| @stripe/stripe-js v8.x | — | — | Any browser |

---

## 8. Key Deprecations Timeline

### 8.1 Chronological

| Date | Deprecation | Status | Action |
|------|-------------|--------|--------|
| 2024 Q3 | Old per-date versioning system | Replaced | Use named releases |
| 2024 Q4 | `total_count` on list expansions | Removed in Basil | Remove expansion |
| 2025 Q1 | Legacy `createUsageRecord` | Removed in Basil | Use Meters API |
| 2025 Q1 | `Invoice.retrieveUpcoming()` | Removed in Basil | Use Create Preview |
| 2025 Q1 | `invoice` expansion on Charge | Removed in Basil | Fetch separately |
| 2025 Q3 | `currency_conversion` field | Removed in Clover | Use `presentment_details` |
| 2025 Q3 | Client secret reuse in Elements | Blocked in Clover | Create new intent |
| Ongoing | Sources API | Deprecated (no removal date) | Use PaymentMethods |
| Ongoing | Tokens API for server-side | Soft-deprecated | Use PaymentMethods |
| 2026 | Google Groups `adwords-api` | Being sunset | Use Discord/Stack Overflow |

### 8.2 Upcoming / Predicted

- **Sources API full removal**: No date set, but expect eventual sunset
- **Sofort**: Replaced by SEPA debit in most regions
- **Next major release (D-name)**: Expected September 2026
- **Pre-Acacia API versions**: Will eventually stop being supported

---

## 9. Gotchas & Cross-References

### Migration Gotchas

1. **72-hour rollback window** — Upgrade account version on a Monday, not Friday. Monitor through the week.
2. **Webhook event versions** — Events use your account API version, not SDK version. Upgrade account to get new event shapes.
3. **Monthly releases are safe** — Within the same family (e.g., Clover), monthly releases are backward-compatible.
4. **SDK auto-pins version** — Updating the SDK changes the API version for SDK requests. Read the changelog first.
5. **Sources API still works for cards** — No removal date, but don't use for new integrations.
6. **Basil removed usage records** — If you're on Basil+, you must use Meters API. No fallback.
7. **Clover prevents client secret reuse** — Can't retry a failed payment with the same PaymentIntent. Create a new one.
8. **Test before upgrading** — Always run your test suite against the new SDK version before deploying.

### Cross-References

- For Meters API details → `subscriptions-and-billing.md`
- For PaymentIntents (replacing Sources) → `payments-and-checkout.md`
- For SDK setup per framework → `framework-integration.md`
- For error handling changes → `error-handling-and-rate-limits.md`
- For testing migration → `testing-and-tooling.md`
