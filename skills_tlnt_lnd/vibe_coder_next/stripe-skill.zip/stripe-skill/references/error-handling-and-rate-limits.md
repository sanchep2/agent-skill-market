# Error Handling & Rate Limits — Complete Reference

Covers the full Stripe error taxonomy, decline codes, error handling patterns in 3 languages, rate limits by endpoint, retry patterns with exponential backoff, and circuit breaker implementation. API version `2026-01-28.clover`.

## Table of Contents

1. [Error Types Taxonomy](#1-error-types-taxonomy)
2. [Decline Codes](#2-decline-codes)
3. [Error Handling Patterns](#3-error-handling-patterns)
4. [Rate Limits](#4-rate-limits)
5. [Retry Patterns](#5-retry-patterns)
6. [Circuit Breaker](#6-circuit-breaker)
7. [Structured Logging & Alerting](#7-structured-logging--alerting)
8. [Gotchas & Cross-References](#8-gotchas--cross-references)

---

## 1. Error Types Taxonomy

### 1.1 Error Type → HTTP Status Mapping

| Error Type | HTTP Status | Description | Retryable |
|------------|-------------|-------------|-----------|
| `StripeCardError` | 402 | Card declined or failed | Depends on decline code |
| `StripeInvalidRequestError` | 400 | Invalid parameters | **No** — fix code |
| `StripeAuthenticationError` | 401 | Invalid API key | **No** — fix key |
| `StripeRateLimitError` | 429 | Too many requests | **Yes** — backoff |
| `StripeAPIError` | 500, 502, 503 | Stripe server error | **Yes** — retry |
| `StripeConnectionError` | — | Network connectivity issue | **Yes** — retry |
| `StripePermissionError` | 403 | Restricted key lacks permission | **No** — update key scope |
| `StripeIdempotencyError` | 400 | Idempotency key reuse with different params | **No** — use new key |
| `StripeSignatureVerificationError` | — | Webhook signature mismatch | **No** — fix raw body |

### 1.2 Error Object Structure

```typescript
interface StripeError {
  type: string;           // Error type (e.g., 'StripeCardError')
  message: string;        // Human-readable message
  code?: string;          // Error code (e.g., 'card_declined')
  decline_code?: string;  // Decline reason (e.g., 'insufficient_funds')
  param?: string;         // Parameter that caused the error
  statusCode?: number;    // HTTP status code
  requestId?: string;     // Stripe request ID for support
  charge?: string;        // Charge ID (for card errors)
  payment_intent?: object; // Partial PI object (for card errors)
  payment_method?: object; // PM that failed
  doc_url?: string;       // Link to relevant docs
}
```

---

## 2. Decline Codes

### 2.1 Complete Decline Code Table

| Decline Code | Description | User-Facing Message | Retryable |
|-------------|-------------|---------------------|-----------|
| `authentication_required` | SCA needed | Please authenticate your payment | Yes (with auth) |
| `approve_with_id` | Can sometimes be retried | Payment not authorized | Yes |
| `call_issuer` | Contact bank | Please contact your bank | No |
| `card_not_supported` | Card doesn't support this type | Card not supported | No |
| `card_velocity_exceeded` | Too many transactions | Too many transactions. Try later. | Yes (later) |
| `currency_not_supported` | Card doesn't support currency | Currency not supported | No |
| `do_not_honor` | Generic bank decline | Payment declined | No |
| `do_not_try_again` | Permanent decline | Payment declined | **No** |
| `duplicate_transaction` | Recently submitted similar | Duplicate transaction detected | No |
| `expired_card` | Card expired | Card expired. Update payment method. | No |
| `fraudulent` | **NEVER show to user** | Payment declined | **No** |
| `generic_decline` | Generic decline | Payment declined | No |
| `incorrect_cvc` | Wrong CVC | Incorrect security code | Yes (retry) |
| `incorrect_number` | Wrong card number | Incorrect card number | Yes (retry) |
| `incorrect_zip` | Wrong ZIP/postal code | Incorrect ZIP code | Yes (retry) |
| `insufficient_funds` | Not enough money | Insufficient funds | Yes (later) |
| `invalid_account` | Account doesn't exist | Card account invalid | No |
| `invalid_amount` | Amount rejected | Amount rejected by card | No |
| `invalid_cvc` | CVC format invalid | Invalid security code | Yes (retry) |
| `invalid_expiry_month` | Invalid month | Invalid expiration month | Yes (retry) |
| `invalid_expiry_year` | Invalid year | Invalid expiration year | Yes (retry) |
| `invalid_number` | Not a valid card number | Invalid card number | Yes (retry) |
| `issuer_not_available` | Issuer unreachable | Bank unavailable. Try later. | Yes (later) |
| `lost_card` | **NEVER show to user** | Payment declined | **No** |
| `merchant_blacklist` | Blocked by Radar | Payment declined | No |
| `new_account_information_available` | Account changed | Please update payment method | No |
| `no_action_taken` | No decline reason | Payment declined | No |
| `not_permitted` | Not permitted by bank | Transaction not allowed | No |
| `offline_pin_required` | PIN needed | PIN required. Use a different card. | No |
| `online_or_offline_pin_required` | PIN needed | PIN required | No |
| `pickup_card` | **NEVER show to user** | Payment declined | **No** |
| `pin_try_exceeded` | Too many PIN attempts | PIN attempts exceeded | No |
| `processing_error` | Temporary processing error | Processing error. Try again. | **Yes** |
| `reenter_transaction` | Retry requested | Please try again | **Yes** |
| `restricted_card` | Cannot use this card | Card restricted | No |
| `revocation_of_all_authorizations` | All auths revoked | Payment declined | No |
| `revocation_of_authorization` | Auth revoked | Payment declined | No |
| `security_violation` | Security concern | Payment declined | No |
| `service_not_allowed` | Service not allowed | Service not allowed | No |
| `stolen_card` | **NEVER show to user** | Payment declined | **No** |
| `stop_payment_order` | Stop payment filed | Payment declined | No |
| `testmode_decline` | Test card decline | — | — |
| `transaction_not_allowed` | Not allowed | Transaction not allowed | No |
| `try_again_later` | Temporary issue | Please try again later | **Yes** |
| `withdrawal_count_exceeded` | Withdrawal limit | Withdrawal limit reached | No |

### 2.2 Security-Sensitive Codes

**NEVER reveal these to the end user** — they indicate potential fraud or criminal activity:

- `fraudulent` → Show: "Payment declined. Please try another method."
- `lost_card` → Show: "Payment declined. Please try another method."
- `stolen_card` → Show: "Payment declined. Please try another method."
- `pickup_card` → Show: "Payment declined. Please try another method."

Log the actual code server-side for fraud analytics. Revealing these codes could tip off fraudsters.

---

## 3. Error Handling Patterns

### 3.1 TypeScript / Node.js

```typescript
import Stripe from 'stripe';

async function handlePayment(stripe: Stripe, params: Stripe.PaymentIntentCreateParams) {
  try {
    const pi = await stripe.paymentIntents.create(params);
    return { success: true, paymentIntent: pi };
  } catch (err) {
    if (err instanceof Stripe.errors.StripeError) {
      // Structured error logging
      const errorLog = {
        type: err.type,
        code: err.code,
        decline_code: (err as any).decline_code,
        message: err.message,
        param: (err as any).param,
        requestId: err.requestId,
        statusCode: err.statusCode,
        timestamp: new Date().toISOString(),
      };
      console.error('Stripe error:', JSON.stringify(errorLog));

      switch (err.type) {
        case 'StripeCardError':
          return handleCardError(err);
        case 'StripeRateLimitError':
          // Retry with backoff
          return { success: false, retryable: true, error: 'Rate limited' };
        case 'StripeInvalidRequestError':
          // Developer error — fix code
          return { success: false, retryable: false, error: 'Invalid request' };
        case 'StripeAuthenticationError':
          return { success: false, retryable: false, error: 'Authentication failed' };
        case 'StripeAPIError':
        case 'StripeConnectionError':
          return { success: false, retryable: true, error: 'Service unavailable' };
        case 'StripeIdempotencyError':
          return { success: false, retryable: false, error: 'Idempotency conflict' };
        default:
          return { success: false, retryable: false, error: 'Unknown error' };
      }
    }
    // Non-Stripe error
    throw err;
  }
}

function handleCardError(err: Stripe.errors.StripeCardError) {
  const declineCode = (err as any).decline_code;

  // Security-sensitive codes — never reveal
  const sensitiveDeclines = new Set(['fraudulent', 'lost_card', 'stolen_card', 'pickup_card']);
  if (sensitiveDeclines.has(declineCode)) {
    return {
      success: false,
      retryable: false,
      userMessage: 'Payment declined. Please try another payment method.',
      internalCode: declineCode,  // Log, don't show
    };
  }

  // Retryable declines
  const retryableDeclines = new Set([
    'authentication_required', 'approve_with_id', 'card_velocity_exceeded',
    'incorrect_cvc', 'incorrect_number', 'incorrect_zip', 'insufficient_funds',
    'invalid_cvc', 'invalid_expiry_month', 'invalid_expiry_year', 'invalid_number',
    'issuer_not_available', 'processing_error', 'reenter_transaction', 'try_again_later',
  ]);

  return {
    success: false,
    retryable: retryableDeclines.has(declineCode),
    userMessage: err.message,  // Safe to show for non-sensitive codes
    internalCode: declineCode,
  };
}
```

### 3.2 Python

```python
import stripe

def handle_payment(amount, currency, payment_method, customer):
    try:
        pi = stripe.PaymentIntent.create(
            amount=amount,
            currency=currency,
            payment_method=payment_method,
            customer=customer,
            confirm=True,
        )
        return {"success": True, "payment_intent": pi}

    except stripe.error.CardError as e:
        body = e.json_body
        err = body.get("error", {})
        return {
            "success": False,
            "retryable": err.get("decline_code") in RETRYABLE_DECLINES,
            "user_message": e.user_message,
            "code": err.get("code"),
            "decline_code": err.get("decline_code"),
            "request_id": e.request_id,
        }

    except stripe.error.RateLimitError as e:
        return {"success": False, "retryable": True, "error": "rate_limited"}

    except stripe.error.InvalidRequestError as e:
        return {"success": False, "retryable": False, "error": str(e)}

    except stripe.error.AuthenticationError as e:
        return {"success": False, "retryable": False, "error": "auth_failed"}

    except stripe.error.APIConnectionError as e:
        return {"success": False, "retryable": True, "error": "connection_error"}

    except stripe.error.StripeError as e:
        return {"success": False, "retryable": True, "error": str(e)}

RETRYABLE_DECLINES = {
    "authentication_required", "approve_with_id", "card_velocity_exceeded",
    "incorrect_cvc", "incorrect_number", "incorrect_zip", "insufficient_funds",
    "issuer_not_available", "processing_error", "reenter_transaction", "try_again_later",
}
```

### 3.3 Ruby

```ruby
def handle_payment(amount:, currency:, payment_method:, customer:)
  pi = Stripe::PaymentIntent.create(
    amount: amount,
    currency: currency,
    payment_method: payment_method,
    customer: customer,
    confirm: true
  )
  { success: true, payment_intent: pi }

rescue Stripe::CardError => e
  {
    success: false,
    retryable: RETRYABLE_DECLINES.include?(e.code),
    user_message: e.message,
    code: e.code,
    decline_code: e.json_body.dig(:error, :decline_code),
    request_id: e.request_id
  }

rescue Stripe::RateLimitError => e
  { success: false, retryable: true, error: 'rate_limited' }

rescue Stripe::InvalidRequestError => e
  { success: false, retryable: false, error: e.message }

rescue Stripe::AuthenticationError => e
  { success: false, retryable: false, error: 'auth_failed' }

rescue Stripe::APIConnectionError => e
  { success: false, retryable: true, error: 'connection_error' }

rescue Stripe::StripeError => e
  { success: false, retryable: true, error: e.message }
end
```

---

## 4. Rate Limits

### 4.1 Global Limits

| Mode | Limit |
|------|-------|
| **Live mode** | **100 operations/second** (global), 25/second per endpoint |
| **Test/Sandbox mode** | **25 operations/second** |

### 4.2 Per-Resource Limits

| Resource | Limit | Notes |
|----------|-------|-------|
| PaymentIntent updates | 1,000/hour per object | Serialize mutations |
| Search API reads | 20/second | Use list + filters when possible |
| Meter events | 1,000/second (standard) | 10,000/s for high-throughput stream |
| File uploads | 20/second | Batch where possible |
| Read requests | Avg 500/transaction (30-day rolling) | Minimum 10,000/month |

### 4.3 Rate Limit Response

```typescript
// HTTP 429 response
{
  "error": {
    "type": "StripeRateLimitError",
    "message": "Rate limit exceeded",
    "code": "rate_limit"
  }
}

// Response header
// Stripe-Rate-Limited-Reason: <reason>
```

### 4.4 Lock Timeout (429 Subtype)

When multiple concurrent requests mutate the same object:

```typescript
// Two simultaneous updates to same PaymentIntent → one gets 429 lock_timeout
try {
  await stripe.paymentIntents.update('pi_xxx', { metadata: { key: 'value' } });
} catch (err) {
  if (err.statusCode === 429 && err.code === 'lock_timeout') {
    // Another request is modifying this object — retry after short delay
    await sleep(500);
    await stripe.paymentIntents.update('pi_xxx', { metadata: { key: 'value' } });
  }
}
```

**Prevention**: Serialize mutations on the same object. Don't update the same PaymentIntent/Subscription from multiple concurrent requests.

---

## 5. Retry Patterns

### 5.1 Retry Decision Tree

```
Error occurred
    │
    ├── StripeCardError
    │   ├── decline_code in retryable set → Retry (user action needed)
    │   └── decline_code is permanent → Do NOT retry
    │
    ├── StripeRateLimitError (429) → Retry with exponential backoff
    │
    ├── StripeAPIError (500/502/503) → Retry with exponential backoff
    │
    ├── StripeConnectionError → Retry with exponential backoff
    │
    ├── StripeInvalidRequestError (400) → Do NOT retry (fix code)
    │
    ├── StripeAuthenticationError (401) → Do NOT retry (fix key)
    │
    ├── StripePermissionError (403) → Do NOT retry (fix key scope)
    │
    └── StripeIdempotencyError → Do NOT retry (use new key)
```

### 5.2 Exponential Backoff with Jitter

```typescript
async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  options: {
    maxRetries?: number;
    baseDelay?: number;
    maxDelay?: number;
    retryableErrors?: Set<string>;
  } = {}
): Promise<T> {
  const {
    maxRetries = 3,
    baseDelay = 500,     // 500ms base
    maxDelay = 30000,    // 30s max
    retryableErrors = new Set([
      'StripeRateLimitError',
      'StripeAPIError',
      'StripeConnectionError',
    ]),
  } = options;

  let lastError: Error;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err as Error;

      if (err instanceof Stripe.errors.StripeError) {
        if (!retryableErrors.has(err.type)) {
          throw err;  // Not retryable
        }
      }

      if (attempt === maxRetries) break;

      // Exponential backoff with full jitter
      const exponentialDelay = baseDelay * Math.pow(2, attempt);
      const jitter = Math.random() * exponentialDelay;
      const delay = Math.min(jitter, maxDelay);

      console.warn(`Retry ${attempt + 1}/${maxRetries} after ${Math.round(delay)}ms`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  throw lastError!;
}

// Usage
const pi = await retryWithBackoff(() =>
  stripe.paymentIntents.create({
    amount: 2000,
    currency: 'usd',
  }, {
    idempotencyKey: `order_${orderId}_payment`,
  })
);
```

### 5.3 Python Backoff

```python
import time
import random
import stripe

def retry_with_backoff(fn, max_retries=3, base_delay=0.5, max_delay=30):
    for attempt in range(max_retries + 1):
        try:
            return fn()
        except (stripe.error.RateLimitError,
                stripe.error.APIError,
                stripe.error.APIConnectionError) as e:
            if attempt == max_retries:
                raise
            delay = min(base_delay * (2 ** attempt) + random.uniform(0, 1), max_delay)
            time.sleep(delay)
        except stripe.error.StripeError:
            raise  # Non-retryable
```

### 5.4 SDK Built-in Retries

```typescript
// stripe npm — built-in retry
const stripe = new Stripe('sk_...', {
  maxNetworkRetries: 2,     // Retries on network errors and 5xx
  timeout: 30000,           // Request timeout
});

// Auto-generates idempotency keys for retried POST requests
// Does NOT retry 4xx errors (except 429)
```

---

## 6. Circuit Breaker

### 6.1 Implementation

```typescript
enum CircuitState {
  CLOSED = 'closed',       // Normal: requests pass through
  OPEN = 'open',           // Failing: requests rejected immediately
  HALF_OPEN = 'half_open', // Testing: limited requests allowed
}

class CircuitBreaker {
  private state: CircuitState = CircuitState.CLOSED;
  private failureCount = 0;
  private successCount = 0;
  private lastFailureTime = 0;
  private halfOpenAttempts = 0;

  constructor(
    private readonly failureThreshold: number = 5,
    private readonly resetTimeout: number = 30000,     // 30 seconds
    private readonly halfOpenMaxAttempts: number = 3,
  ) {}

  async execute<T>(fn: () => Promise<T>): Promise<T> {
    if (this.state === CircuitState.OPEN) {
      if (Date.now() - this.lastFailureTime >= this.resetTimeout) {
        this.state = CircuitState.HALF_OPEN;
        this.halfOpenAttempts = 0;
      } else {
        throw new Error(`Circuit breaker OPEN. Retry after ${this.resetTimeout}ms`);
      }
    }

    if (this.state === CircuitState.HALF_OPEN) {
      if (this.halfOpenAttempts >= this.halfOpenMaxAttempts) {
        this.state = CircuitState.OPEN;
        this.lastFailureTime = Date.now();
        throw new Error('Circuit breaker OPEN (half-open limit reached)');
      }
      this.halfOpenAttempts++;
    }

    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (err) {
      this.onFailure();
      throw err;
    }
  }

  private onSuccess() {
    if (this.state === CircuitState.HALF_OPEN) {
      this.successCount++;
      if (this.successCount >= this.halfOpenMaxAttempts) {
        this.state = CircuitState.CLOSED;
        this.failureCount = 0;
        this.successCount = 0;
      }
    } else {
      this.failureCount = 0;
    }
  }

  private onFailure() {
    this.failureCount++;
    this.lastFailureTime = Date.now();
    if (this.failureCount >= this.failureThreshold) {
      this.state = CircuitState.OPEN;
    }
  }

  getState(): CircuitState { return this.state; }
}

// Usage
const stripeCircuit = new CircuitBreaker(5, 30000);

async function createPayment(params: Stripe.PaymentIntentCreateParams) {
  return stripeCircuit.execute(() =>
    stripe.paymentIntents.create(params)
  );
}
```

---

## 7. Structured Logging & Alerting

### 7.1 Error Logging

```typescript
function logStripeError(err: Stripe.errors.StripeError, context: Record<string, unknown>) {
  const log = {
    level: err.type === 'StripeRateLimitError' ? 'warn' : 'error',
    service: 'stripe',
    error: {
      type: err.type,
      code: err.code,
      decline_code: (err as any).decline_code,
      message: err.message,
      param: (err as any).param,
      status: err.statusCode,
      requestId: err.requestId,
    },
    context,
    timestamp: new Date().toISOString(),
  };

  if (err.type === 'StripeAPIError' || err.type === 'StripeConnectionError') {
    // Alert: Stripe service issue
    alertOpsTeam('stripe_service_error', log);
  }

  console.error(JSON.stringify(log));
}
```

### 7.2 Alerting Rules

| Condition | Severity | Action |
|-----------|----------|--------|
| 5+ `StripeAPIError` in 1 minute | Critical | Page on-call |
| 429 rate limit errors | Warning | Scale back, increase backoff |
| `StripeAuthenticationError` | Critical | API key compromised or expired |
| Dispute rate > 0.75% | Critical | Review fraud rules, may lose processing |
| Webhook endpoint failures > 50% | High | Fix endpoint before Stripe disables it |
| `lock_timeout` errors | Medium | Serialize mutations on same objects |

---

## 8. Gotchas & Cross-References

### Error Handling Gotchas

1. **Never show `lost_card`/`stolen_card`/`fraudulent`** — Show generic "Payment declined" to all sensitive codes.
2. **requestId is crucial** — Always log it. Stripe support requires it for investigation.
3. **429 with same idempotency key is safe** — Rate-limited responses are NOT cached.
4. **lock_timeout ≠ rate limit** — It means concurrent mutation on same object. Serialize, don't just backoff.
5. **SDK auto-retry handles network errors** — `maxNetworkRetries` covers 5xx and timeouts. Don't double-retry.
6. **Card errors are NOT retryable by default** — Only specific decline codes can be retried with user action.
7. **StripeIdempotencyError means param mismatch** — Same key, different params. Use a new key or fix params.
8. **Test mode has lower rate limits** — 25/sec vs 100/sec in live. Don't benchmark against test.

### Cross-References

- For payment error flows → `payments-and-checkout.md`
- For webhook error handling → `webhooks.md`
- For framework-specific error patterns → `framework-integration.md`
- For circuit breaker in helper script → `../scripts/stripe_helper.ts`
- For testing error scenarios → `testing-and-tooling.md`
