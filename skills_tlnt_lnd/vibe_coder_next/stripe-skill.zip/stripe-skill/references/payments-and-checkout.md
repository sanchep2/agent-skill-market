# Payments & Checkout — Complete Reference

Covers the full payment lifecycle in Stripe: PaymentIntents, Checkout Sessions, Payment Methods, 3D Secure/SCA, Disputes & Radar, Refunds, Currency Handling, and Idempotency. API version `2026-01-28.clover`, stripe npm v20.3.1.

## Table of Contents

1. [PaymentIntents API — Complete Lifecycle](#1-paymentintents-api--complete-lifecycle)
2. [Checkout Sessions — Hosted & Embedded](#2-checkout-sessions--hosted--embedded)
3. [Payment Methods Catalog](#3-payment-methods-catalog)
4. [Payment Links](#4-payment-links)
5. [3D Secure / SCA](#5-3d-secure--sca)
6. [Disputes and Radar](#6-disputes-and-radar)
7. [Refunds](#7-refunds)
8. [Currency Handling](#8-currency-handling)
9. [Idempotency](#9-idempotency)
10. [Gotchas & Cross-References](#10-gotchas--cross-references)

---

## 1. PaymentIntents API — Complete Lifecycle

### 1.1 Status Flow

```
                    ┌─────────────────────────────────────────────────────────────────┐
                    │                    PaymentIntent Lifecycle                        │
                    │                                                                   │
                    │  requires_payment_method                                          │
                    │        │                                                          │
                    │        ▼ (attach PM)                                              │
                    │  requires_confirmation                                            │
                    │        │                                                          │
                    │        ▼ (confirm)                                                │
                    │  requires_action ──────── (3DS/SCA auth) ─┐                      │
                    │        │                                    │                      │
                    │        ▼ (no action needed)                ▼ (auth succeeds)      │
                    │    processing                              │                      │
                    │        │                                    │                      │
                    │        ▼                                   ▼                      │
                    │  requires_capture ◄────────────────────────┘                      │
                    │   (manual capture)                                                │
                    │        │                                                          │
                    │        ▼ (capture)                                                │
                    │    succeeded                                                      │
                    │                                                                   │
                    │  On decline at any step: reverts to requires_payment_method       │
                    │  canceled: can be set at any pre-succeeded state                  │
                    └─────────────────────────────────────────────────────────────────┘
```

**Key statuses explained**:
- `requires_payment_method` — No payment method attached, or previous method was declined
- `requires_confirmation` — PM attached, awaiting `paymentIntents.confirm()` call
- `requires_action` — 3DS/SCA authentication needed; `next_action` object contains redirect URL
- `processing` — Payment in-flight; may take days for ACH/SEPA/bank debits
- `requires_capture` — Authorized but not captured (manual capture mode); capture within **7 days** for cards
- `succeeded` — Funds collected; terminal state
- `canceled` — Released; terminal state

### 1.2 Core Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `amount` | integer | Amount in smallest currency unit (cents for USD). **Required**. |
| `currency` | string | 3-letter ISO code, lowercase (`'usd'`, `'eur'`, `'jpy'`). **Required**. |
| `customer` | string | Customer ID (`cus_xxx`). Required for saving payment methods. |
| `payment_method` | string | PM ID (`pm_xxx`). Omit to let customer choose at confirmation. |
| `confirm` | boolean | `true` to create+confirm in one call. Default `false`. |
| `capture_method` | string | `'automatic'` (default) or `'manual'` (authorize only). |
| `setup_future_usage` | string | `'on_session'` or `'off_session'` — saves PM for reuse, optimizes SCA exemptions. |
| `automatic_payment_methods` | object | `{ enabled: true }` — lets Stripe auto-select PMs from Dashboard config. |
| `payment_method_types` | array | Explicit list (`['card', 'ideal']`). Alternative to `automatic_payment_methods`. |
| `metadata` | object | Up to 50 key-value pairs. Keys ≤40 chars, values ≤500 chars. |
| `idempotency_key` | string | Dedup key, max 255 chars, retained 24 hours. |
| `description` | string | Shown in Dashboard and receipts. |
| `statement_descriptor` | string | Up to 22 chars on card statement. |
| `statement_descriptor_suffix` | string | Appended to account statement descriptor. |
| `receipt_email` | string | Email for Stripe-generated receipt. |
| `shipping` | object | Shipping details (name, address, phone, carrier, tracking). |
| `transfer_data` | object | `{ destination: 'acct_xxx' }` for Connect destination charges. |
| `application_fee_amount` | integer | Platform fee for Connect charges. |
| `transfer_group` | string | Groups related charges and transfers in Connect. |
| `on_behalf_of` | string | Connected account for statement descriptor and settlement. |

### 1.3 Create + Confirm (Single Step)

```typescript
const pi = await stripe.paymentIntents.create({
  amount: 2000,                              // $20.00
  currency: 'usd',
  customer: 'cus_abc123',
  payment_method: 'pm_card_visa',
  confirm: true,
  automatic_payment_methods: { enabled: true },
  setup_future_usage: 'off_session',         // Save PM for future charges
  metadata: { order_id: '6735' },
}, {
  idempotencyKey: 'order_6735_payment',      // Deterministic key from order ID
});

if (pi.status === 'succeeded') {
  // Payment complete — fulfill order
} else if (pi.status === 'requires_action') {
  // 3DS needed — pass pi.client_secret to frontend
}
```

### 1.4 Manual Capture (Authorize Then Capture)

```typescript
// Step 1: Authorize
const auth = await stripe.paymentIntents.create({
  amount: 5000,
  currency: 'eur',
  payment_method: 'pm_card_visa',
  capture_method: 'manual',
  confirm: true,
});
// auth.status === 'requires_capture'

// Step 2: Capture (within 7 days for cards)
const captured = await stripe.paymentIntents.capture(auth.id, {
  amount_to_capture: 4500,  // Partial capture OK — remaining released
});

// Step 2 alt: Release authorization
await stripe.paymentIntents.cancel(auth.id, {
  cancellation_reason: 'abandoned',
});
```

**Capture window by payment method**:
- Cards: 7 days (some networks extend to 31)
- Afterpay/Clearpay: 13 days
- Klarna: 28 days
- Most others: immediate capture only

### 1.5 Off-Session Payments (Saved Cards)

```typescript
// Charge a saved card without customer present
try {
  const pi = await stripe.paymentIntents.create({
    amount: 3000,
    currency: 'usd',
    customer: 'cus_abc123',
    payment_method: 'pm_saved_card',
    off_session: true,
    confirm: true,
  });
} catch (err) {
  if (err.code === 'authentication_required') {
    // SCA required — email customer with payment link
    const piId = err.raw.payment_intent.id;
    // Send email with link to re-authenticate
  }
}
```

### 1.6 Incremental Authorization

```typescript
// Hotel/rental: increase authorized amount
const updated = await stripe.paymentIntents.incrementAuthorization(pi.id, {
  amount: 7500,  // New total (not increment delta)
});
```

Supported only on Visa and Mastercard. Check `payment_method_details.card.incremental_authorization_supported`.

---

## 2. Checkout Sessions — Hosted & Embedded

### 2.1 Three Modes

| Mode | Use Case | Creates |
|------|----------|---------|
| `payment` | One-time purchase | PaymentIntent |
| `subscription` | Recurring billing | Subscription + Invoice |
| `setup` | Save payment method | SetupIntent |

### 2.2 Hosted Checkout (Redirect to Stripe)

```typescript
const session = await stripe.checkout.sessions.create({
  mode: 'payment',
  line_items: [{
    price_data: {
      currency: 'usd',
      product_data: {
        name: 'Premium T-shirt',
        description: '100% organic cotton',
        images: ['https://example.com/tshirt.png'],
      },
      unit_amount: 2000,
    },
    quantity: 1,
    adjustable_quantity: {
      enabled: true,
      minimum: 1,
      maximum: 10,
    },
  }],
  success_url: 'https://example.com/success?session_id={CHECKOUT_SESSION_ID}',
  cancel_url: 'https://example.com/cancel',
  customer: 'cus_abc123',
  customer_email: 'customer@example.com',   // Pre-fill if no customer
  metadata: { order_id: '12345' },
  expires_at: Math.floor(Date.now() / 1000) + 3600,  // 1 hour
  after_expiration: {
    recovery: { enabled: true, allow_promotion_codes: true },
  },
  shipping_address_collection: {
    allowed_countries: ['US', 'CA', 'GB', 'DE', 'FR'],
  },
  shipping_options: [
    {
      shipping_rate_data: {
        type: 'fixed_amount',
        fixed_amount: { amount: 0, currency: 'usd' },
        display_name: 'Free shipping',
        delivery_estimate: {
          minimum: { unit: 'business_day', value: 5 },
          maximum: { unit: 'business_day', value: 7 },
        },
      },
    },
    {
      shipping_rate_data: {
        type: 'fixed_amount',
        fixed_amount: { amount: 1500, currency: 'usd' },
        display_name: 'Express (2-3 days)',
      },
    },
  ],
  custom_fields: [
    {
      key: 'engraving',
      label: { type: 'custom', custom: 'Engraving text' },
      type: 'text',
      optional: true,
      text: { maximum_length: 30 },
    },
  ],
  allow_promotion_codes: true,
  automatic_tax: { enabled: true },
  consent_collection: { terms_of_service: 'required' },
  custom_text: {
    submit: { message: 'Your order will ship within 2 business days.' },
    terms_of_service_acceptance: {
      message: 'I agree to the [Terms of Service](https://example.com/tos)',
    },
  },
  invoice_creation: { enabled: true },  // Generate invoice for one-time payments
  phone_number_collection: { enabled: true },
});

// Redirect
res.redirect(303, session.url!);
```

### 2.3 Embedded Checkout (In Your Page)

```typescript
// Server
const session = await stripe.checkout.sessions.create({
  mode: 'payment',
  ui_mode: 'embedded',
  line_items: [{ price: 'price_xxx', quantity: 1 }],
  return_url: 'https://example.com/return?session_id={CHECKOUT_SESSION_ID}',
});
// Return session.client_secret to frontend

// React Frontend
import { loadStripe } from '@stripe/stripe-js';
import { EmbeddedCheckoutProvider, EmbeddedCheckout } from '@stripe/react-stripe-js';

const stripePromise = loadStripe('pk_test_...');

function CheckoutPage() {
  const fetchClientSecret = useCallback(async () => {
    const res = await fetch('/create-checkout-session', { method: 'POST' });
    const { clientSecret } = await res.json();
    return clientSecret;
  }, []);

  return (
    <EmbeddedCheckoutProvider
      stripe={stripePromise}
      options={{ fetchClientSecret }}
    >
      <EmbeddedCheckout />
    </EmbeddedCheckoutProvider>
  );
}
```

### 2.4 Subscription Checkout

```typescript
const session = await stripe.checkout.sessions.create({
  mode: 'subscription',
  line_items: [{ price: 'price_monthly', quantity: 1 }],
  success_url: 'https://example.com/success?session_id={CHECKOUT_SESSION_ID}',
  cancel_url: 'https://example.com/pricing',
  subscription_data: {
    trial_period_days: 14,
    metadata: { plan: 'pro' },
  },
  payment_method_collection: 'if_required',  // Skip PM for free trials
  tax_id_collection: { enabled: true },
});
```

### 2.5 Session Statuses and Retrieval

```typescript
// Statuses: open → complete / expired
const session = await stripe.checkout.sessions.retrieve('cs_xxx', {
  expand: ['line_items', 'payment_intent', 'subscription'],
});

if (session.status === 'complete') {
  const customerId = session.customer as string;
  const subscriptionId = session.subscription as string;
}

// List recent sessions
const sessions = await stripe.checkout.sessions.list({
  limit: 10,
  status: 'complete',
  created: { gte: Math.floor(Date.now() / 1000) - 86400 },
});
```

**Critical**: `{CHECKOUT_SESSION_ID}` template in URLs is auto-replaced by Stripe. **Always fulfill via `checkout.session.completed` webhook**, not the redirect.

### 2.6 Checkout vs PaymentIntents Decision

| Factor | Checkout Sessions | PaymentIntents + Elements |
|--------|------------------|--------------------------|
| Integration time | Hours | Days |
| UI customization | Limited (themes, logo, colors) | Full control |
| Payment methods | Auto-managed by Stripe | You configure |
| SCA/3DS | Handled automatically | Handled via Stripe.js |
| Subscription support | Built-in mode | Manual with Billing API |
| Tax collection | Built-in | Manual with Tax API |
| Promo codes | Built-in | Manual |
| Best for | MVPs, standard e-commerce | Custom UIs, embedded flows |

---

## 3. Payment Methods Catalog

### 3.1 Categories and Coverage

| Category | Payment Methods | Regions |
|----------|----------------|---------|
| **Cards** | Visa, Mastercard, Amex, Discover, JCB, Diners, UnionPay, Cartes Bancaires, Interac | Global |
| **Wallets** | Apple Pay, Google Pay, Link, PayPal, Cash App Pay, Amazon Pay, Alipay, WeChat Pay | Global |
| **Bank debits** | ACH (US), SEPA (EU), BACS (UK), BECS (AU), Canadian PADs, PayTo (AU) | Regional |
| **Bank redirects** | iDEAL (NL), Bancontact (BE), EPS (AT), P24 (PL), FPX (MY), Sofort | EU |
| **BNPL** | Klarna, Afterpay/Clearpay, Affirm, Zip, Alma, Scalapay, Billie | US/EU/AU |
| **Real-time** | PIX (BR), PromptPay (TH), PayNow (SG), UPI (IN), Swish (SE) | Regional |
| **Vouchers** | OXXO (MX), Boleto (BR), Konbini (JP), Multibanco (PT) | Regional |
| **Stablecoins** | USDC on Ethereum, Solana, Polygon, Base | Global |

Total: **125+ payment methods** supported.

### 3.2 Refund Support by Method

| Method | Refund Type | Settlement Time | Notes |
|--------|-------------|-----------------|-------|
| Cards | Full/partial | 5-10 business days | Via original card |
| ACH | Full/partial | 3-5 business days | Risk of failure |
| SEPA | Full/partial | 5-8 business days | Must refund within 180 days |
| iDEAL | Full/partial | 5-10 business days | Via SEPA credit transfer |
| Klarna | Full/partial | 5-10 business days | Refunds through Klarna |
| PayPal | Full/partial | 3-5 business days | Via PayPal balance |
| Apple/Google Pay | Full/partial | 5-10 business days | Via underlying card |
| PIX | Full only | Instant | Must refund within 90 days |
| OXXO/Boleto | Not supported | — | Issue credit/store credit instead |

### 3.3 SetupIntents — Save Without Charging

```typescript
// Server: Create SetupIntent
const setupIntent = await stripe.setupIntents.create({
  customer: 'cus_abc123',
  automatic_payment_methods: { enabled: true },
  usage: 'off_session',  // Optimize for off-session future charges
});

// Client: Confirm setup
const { error } = await stripe.confirmSetup({
  elements,
  confirmParams: { return_url: 'https://example.com/setup-complete' },
});

// Attach/detach payment methods manually
await stripe.paymentMethods.attach('pm_xxx', { customer: 'cus_xxx' });
await stripe.paymentMethods.detach('pm_xxx');

// Set as default for invoices
await stripe.customers.update('cus_xxx', {
  invoice_settings: { default_payment_method: 'pm_xxx' },
});
```

---

## 4. Payment Links

No-code shareable payment URLs. Less customizable than Checkout Sessions but zero integration effort.

```typescript
const link = await stripe.paymentLinks.create({
  line_items: [{ price: 'price_xxx', quantity: 1 }],
  after_completion: {
    type: 'redirect',
    redirect: { url: 'https://example.com/thank-you' },
  },
  allow_promotion_codes: true,
  automatic_tax: { enabled: true },
  phone_number_collection: { enabled: true },
  shipping_address_collection: {
    allowed_countries: ['US', 'CA'],
  },
});
// Share link.url via email, SMS, social media, QR code

// Update (limited)
await stripe.paymentLinks.update(link.id, { active: false });

// List line items
const items = await stripe.paymentLinks.listLineItems(link.id);
```

**Limitations vs Checkout Sessions**: No `ui_mode: 'embedded'`, no `expires_at`, no custom fields, no `customer` parameter (always creates new), limited webhook control. Use Checkout Sessions for programmatic integrations.

---

## 5. 3D Secure / SCA

### 5.1 When 3DS Triggers

Stripe triggers 3DS authentication automatically when:
1. **SCA regulation requires it** — EU/UK/EEA PSD2 for customer-initiated online payments where both bank and business are in EEA/UK/Switzerland
2. **Radar rules request it** — `Request 3D Secure if :condition:`
3. **Issuer soft-declines** — Bank requests authentication

### 5.2 Frontend Handling

```typescript
// Stripe.js handles 3DS modal automatically
const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
  payment_method: {
    card: cardElement,
    billing_details: { name: 'Jenny Rosen' },
  },
});

if (error) {
  if (error.type === 'card_error' || error.type === 'validation_error') {
    setMessage(error.message);
  }
} else if (paymentIntent.status === 'succeeded') {
  // Payment complete
} else if (paymentIntent.status === 'processing') {
  // Bank debit — show pending message
}
```

### 5.3 Off-Session 3DS Recovery

```typescript
// Step 1: Create off-session payment
try {
  const pi = await stripe.paymentIntents.create({
    amount: 5000, currency: 'usd',
    customer: 'cus_xxx', payment_method: 'pm_xxx',
    off_session: true, confirm: true,
  });
} catch (err) {
  if (err.code === 'authentication_required') {
    const piId = err.raw.payment_intent.id;

    // Step 2: Email customer with payment link
    // Include link to page that calls stripe.confirmCardPayment(clientSecret)

    // Step 3: Retrieve PI for client secret
    const pi = await stripe.paymentIntents.retrieve(piId);
    // Send pi.client_secret to customer via your payment page
  }
}
```

### 5.4 SCA Exemptions

| Exemption | Criteria | Liability Shift |
|-----------|----------|-----------------|
| Low Value | < €30 (resets after 5 consecutive or cumulative €100) | No |
| Transaction Risk Analysis (TRA) | ≤€100 at ≤0.13% fraud, ≤€250 at ≤0.06%, ≤€500 at ≤0.01% | No |
| Merchant-Initiated (MIT) | Off-session saved cards, recurring after initial auth | N/A |
| Secure Corporate | Corporate cards with dedicated processes | No |
| Trusted Beneficiary | Customer whitelists merchant with bank | No |

Stripe automatically requests applicable exemptions. When exemptions are granted, **no liability shift** to the issuer — the merchant bears fraud risk.

### 5.5 Radar Rules for 3DS

```
# Request 3DS for high-value transactions
Request 3D Secure if :amount_in_usd: > 500

# Request 3DS for new customers
Request 3D Secure if :is_new_customer:

# Request 3DS for high-risk countries
Request 3D Secure if :ip_country: in ('RU', 'BR', 'NG')
```

---

## 6. Disputes and Radar

### 6.1 Stripe Radar

ML-powered fraud detection trained on **$1.4T+ annual processing volume** across millions of merchants. Built into every Stripe account (Radar for Fraud Teams adds custom rules for $0.07/screened transaction).

**Rule syntax**: `{action} if {condition}` — evaluated in order: Request 3DS → Allow → Block → Review.

```
# Block highest risk
Block if :risk_level: = 'highest'

# Review large prepaid card purchases
Review if :amount_in_usd: > 1000 AND :card_funding: = 'prepaid'

# Block velocity abuse
Block if :card_count_for_email: > 3 AND :seconds_since_email_first_seen: < 3600

# Allow trusted customers
Allow if :customer_email: ends_with '@trustedcorp.com'

# Block specific countries for card payments
Block if :card_country: in ('XX', 'YY') AND :payment_method: = 'card'

# Request 3DS for risky but not blocked
Request 3D Secure if :risk_level: = 'elevated' AND :amount_in_usd: > 100
```

**Available attributes**: `:risk_level:`, `:risk_score:`, `:amount_in_usd:`, `:card_funding:` (credit/debit/prepaid), `:card_country:`, `:ip_country:`, `:ip_address:`, `:is_new_customer:`, `:customer_email:`, `:card_count_for_email:`, `:payment_method:`, `:is_3d_secure:`, `:has_3d_secure:`, etc.

### 6.2 Dispute Lifecycle

```
Early Fraud Warning (EFW)
    │
    ▼ (if not proactively refunded)
Chargeback Created
    │ funds + $15 fee debited from balance
    │
    ▼
Evidence Submission Window (14-21 days)
    │
    ▼
Bank Review (60-75 days)
    │
    ├── Won → funds + $15 fee returned
    └── Lost → funds permanently lost, $15 fee retained
```

### 6.3 Dispute Categories and Evidence

| Category | Key Evidence | Win Rate Tips |
|----------|-------------|---------------|
| `fraudulent` | AVS/CVC match, 3DS proof, IP logs, delivery proof | Highest priority evidence |
| `product_not_received` | Tracking number, delivery confirmation, shipping carrier | Signed delivery is strongest |
| `product_unacceptable` | Photos, correspondence, return policy, refund offer | Show you attempted resolution |
| `duplicate` | Separate receipts, proof charges are distinct | Show different orders/dates |
| `credit_not_processed` | Refund policy, prior refund attempts | Show refund was issued or policy |
| `subscription_canceled` | Cancel confirmation, terms of service | Timestamp of cancellation |
| `unrecognized` | Receipt, billing descriptor explanation | Help customer recognize charge |
| `general` | All relevant documentation | Cover all bases |

```typescript
// Submit dispute evidence
await stripe.disputes.update('dp_xxx', {
  evidence: {
    customer_name: 'Jenny Rosen',
    customer_email_address: 'jenny@example.com',
    product_description: 'Premium subscription — monthly plan',
    shipping_tracking_number: '1Z999AA10123456784',
    shipping_carrier: 'ups',
    shipping_date: '2026-02-10',
    shipping_documentation: 'file_xxx',  // Upload via Files API first
    uncategorized_text: 'Customer confirmed delivery via email on Feb 12.',
    access_activity_log: 'Account login from same IP on Feb 11, 12, 13.',
  },
  submit: true,  // false to save draft
});

// Upload evidence file
const file = await stripe.files.create({
  purpose: 'dispute_evidence',
  file: {
    data: fs.readFileSync('/path/to/evidence.pdf'),
    name: 'evidence.pdf',
    type: 'application/pdf',
  },
});
```

**Best practice**: Proactively refund actionable Early Fraud Warnings to prevent chargebacks. An EFW refund avoids the $15 dispute fee and doesn't count toward your dispute rate.

### 6.4 Dispute Webhooks

```typescript
// Listen for these events
switch (event.type) {
  case 'charge.dispute.created':
    // Alert team, gather evidence, consider auto-response
    const dispute = event.data.object as Stripe.Dispute;
    console.log(`Dispute ${dispute.id}: ${dispute.reason}, amount: ${dispute.amount}`);
    break;
  case 'charge.dispute.updated':
    // Evidence submitted or status changed
    break;
  case 'charge.dispute.closed':
    // Won or lost — update records
    const closed = event.data.object as Stripe.Dispute;
    if (closed.status === 'won') { /* Celebrate */ }
    break;
  case 'radar.early_fraud_warning.created':
    // Consider proactive refund
    break;
}
```

---

## 7. Refunds

### 7.1 Creating Refunds

```typescript
// Full refund (by PaymentIntent)
const refund = await stripe.refunds.create({
  payment_intent: 'pi_xxx',
});

// Full refund (by Charge)
const refund = await stripe.refunds.create({
  charge: 'ch_xxx',
});

// Partial refund
const refund = await stripe.refunds.create({
  payment_intent: 'pi_xxx',
  amount: 500,  // $5.00 partial refund
});

// With reason (fraudulent adds card+email to Radar block lists)
const refund = await stripe.refunds.create({
  payment_intent: 'pi_xxx',
  reason: 'fraudulent',  // Also: 'duplicate', 'requested_by_customer'
});

// With metadata
const refund = await stripe.refunds.create({
  payment_intent: 'pi_xxx',
  metadata: { return_id: 'RET-789', agent: 'support_team' },
});
```

### 7.2 Refund Statuses

```
pending → succeeded    (normal flow)
pending → failed       (bank rejected — funds return to YOUR balance)
pending → canceled     (reversed before processing)
requires_action        (customer action needed — rare, some bank transfers)
```

### 7.3 Failed Refund Handling

```typescript
// Listen for refund.failed webhook
if (event.type === 'refund.failed') {
  const refund = event.data.object as Stripe.Refund;
  // Funds returned to your Stripe balance
  // Issue alternative refund (check, store credit, etc.)
  console.log(`Refund ${refund.id} failed: ${refund.failure_reason}`);
  // failure_reason: 'lost_or_stolen_card', 'expired_or_canceled_card', 'unknown'
}
```

**Rules**: Multiple partial refunds allowed up to original amount. Refund processing fees are NOT returned (Stripe keeps its fee). Card refunds can take 5-10 business days to appear on customer statement.

---

## 8. Currency Handling

### 8.1 Amount Representation

All amounts in **smallest currency unit**. For most currencies, this means cents:

```typescript
// USD: $20.00 → amount: 2000
// EUR: €15.50 → amount: 1550
// GBP: £99.99 → amount: 9999
```

### 8.2 Zero-Decimal Currencies

These currencies have NO decimal subdivision — use the amount directly:

| Currency | Code | Example |
|----------|------|---------|
| Japanese Yen | JPY | ¥1000 → `amount: 1000` |
| Korean Won | KRW | ₩50000 → `amount: 50000` |
| Burundian Franc | BIF | — |
| Chilean Peso | CLP | — |
| Djiboutian Franc | DJF | — |
| Guinean Franc | GNF | — |
| Comorian Franc | KMF | — |
| Malagasy Ariary | MGA | — |
| Paraguayan Guarani | PYG | — |
| Rwandan Franc | RWF | — |
| Ugandan Shilling | UGX | — |
| Vietnamese Dong | VND | — |
| Vanuatu Vatu | VUV | — |
| CFA Franc BEAC | XAF | — |
| CFA Franc BCEAO | XOF | — |
| CFP Franc | XPF | — |

**Special cases**:
- ISK (Icelandic Króna): two-decimal representation for backward compat
- HUF (Hungarian Forint): two-decimal for charges, zero-decimal for payouts (amounts must be divisible by 100)
- TWD (Taiwan Dollar): same as HUF

### 8.3 Amount Formatting Utility

```typescript
const ZERO_DECIMAL_CURRENCIES = new Set([
  'bif', 'clp', 'djf', 'gnf', 'jpy', 'kmf', 'krw', 'mga',
  'pyg', 'rwf', 'ugx', 'vnd', 'vuv', 'xaf', 'xof', 'xpf',
]);

function toSmallestUnit(amount: number, currency: string): number {
  const cur = currency.toLowerCase();
  if (ZERO_DECIMAL_CURRENCIES.has(cur)) {
    return Math.round(amount);
  }
  return Math.round(amount * 100);
}

function fromSmallestUnit(amount: number, currency: string): number {
  const cur = currency.toLowerCase();
  if (ZERO_DECIMAL_CURRENCIES.has(cur)) {
    return amount;
  }
  return amount / 100;
}

function formatCurrency(amount: number, currency: string): string {
  const displayAmount = fromSmallestUnit(amount, currency);
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency.toUpperCase(),
  }).format(displayAmount);
}
```

### 8.4 Multi-Currency

Stripe supports **135+ presentment currencies**. If presentment ≠ settlement currency, Stripe auto-converts at mid-market rate + conversion fee (~2% for most accounts).

```typescript
// Charge in EUR, settle in USD
const pi = await stripe.paymentIntents.create({
  amount: 2000,     // 20.00 EUR
  currency: 'eur',  // Presentment currency
  // Settlement happens in your default currency (e.g., USD)
});
```

Multi-currency settlement (maintain separate balances per currency) available in select countries via Dashboard settings.

---

## 9. Idempotency

### 9.1 How It Works

All POST requests accept an `Idempotency-Key` header (max **255 chars**). Stripe caches the response of the first successful request for **24 hours**. Replayed requests return the cached response with `Idempotent-Replayed: true` header.

### 9.2 Key Generation Strategies

```typescript
// Strategy 1: UUID v4 (random — for generic dedup)
import { randomUUID } from 'crypto';
const key = randomUUID();

// Strategy 2: Business object ID (deterministic — for order fulfillment)
const key = `order_${orderId}_payment`;

// Strategy 3: Composite (deterministic — for retries of specific operations)
const key = `create_sub_${customerId}_${priceId}_${Date.now()}`;

// Usage with stripe SDK
const pi = await stripe.paymentIntents.create(
  { amount: 2000, currency: 'usd' },
  { idempotencyKey: key }
);
```

### 9.3 Behavior Edge Cases

- **Parameter mismatch**: Same key with different params → `400 StripeIdempotencyError`
- **Rate-limited (429)**: NOT cached — safe to retry with same key
- **Network timeout**: If you didn't receive a response, retry with same key (safe)
- **Different HTTP methods**: Keys only scope to POST; GET/DELETE are naturally idempotent
- **Key expiration**: 24 hours — for longer retry windows, implement your own dedup
- **SDK auto-retry**: `maxNetworkRetries: 2` auto-generates idempotency keys for retried requests

### 9.4 Best Practices

1. Always use idempotency keys for PaymentIntent creation (prevent double charges)
2. Use deterministic keys derived from business IDs (not random) for operations that must be exactly-once
3. Store the idempotency key alongside the order in your database for audit
4. For webhook handlers, track `event.id` (not idempotency key) for idempotent processing

---

## 10. Gotchas & Cross-References

### Payment Gotchas

1. **Never use floating-point for amounts** — `0.1 + 0.2 !== 0.3`. Always calculate in integer cents.
2. **Checkout Session expiration** — Default 24 hours, configurable 30 min to 24 hours via `expires_at`.
3. **Payment Method reuse** — Must set `setup_future_usage` during initial payment to save PM optimally for SCA.
4. **Card brand detection** — Use `payment_method.card.brand` not `payment_method.card.display_brand` for routing logic.
5. **Minimum charge amounts** — $0.50 USD (varies by currency). Check Stripe docs for per-currency minimums.

### Cross-References

- For subscription-specific payment handling → `subscriptions-and-billing.md`
- For Connect platform payments → `stripe-connect.md`
- For Payment Element frontend integration → `elements-and-frontend.md`
- For webhook-based fulfillment → `webhooks.md`
- For error handling and retries → `error-handling-and-rate-limits.md`
- For testing payment flows → `testing-and-tooling.md`
- For currency and tax handling → `stripe-tax-and-revenue.md`
