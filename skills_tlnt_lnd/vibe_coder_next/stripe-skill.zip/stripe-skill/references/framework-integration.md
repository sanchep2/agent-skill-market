# Framework Integration — Complete Reference

Covers Stripe integration patterns for every major framework: Node.js/TypeScript, Express.js, Next.js App Router, Next.js Pages Router, Python/Django, Python/FastAPI, Python/Flask, Ruby/Rails, Serverless (AWS Lambda, Vercel, Cloudflare Workers), and Fastify. API version `2026-01-28.clover`.

## Table of Contents

1. [Node.js / TypeScript Core](#1-nodejs--typescript-core)
2. [Express.js](#2-expressjs)
3. [Next.js App Router (2026 Recommended)](#3-nextjs-app-router-2026-recommended)
4. [Next.js Pages Router (Legacy)](#4-nextjs-pages-router-legacy)
5. [Python / Django](#5-python--django)
6. [Python / FastAPI](#6-python--fastapi)
7. [Python / Flask](#7-python--flask)
8. [Ruby / Rails](#8-ruby--rails)
9. [Serverless Patterns](#9-serverless-patterns)
10. [Fastify](#10-fastify)
11. [Gotchas & Cross-References](#11-gotchas--cross-references)

---

## 1. Node.js / TypeScript Core

### 1.1 Installation & Singleton

```bash
npm install stripe          # v20.3.1 — server-side SDK
```

```typescript
// lib/stripe.ts — Singleton pattern (reuse across requests)
import Stripe from 'stripe';

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  maxNetworkRetries: 2,                  // Auto-retry on network errors
  timeout: 30000,                        // 30-second timeout
  // apiVersion auto-pinned to SDK release — no manual override needed
});

// Request/response logging (development)
if (process.env.NODE_ENV === 'development') {
  stripe.on('request', (e) => {
    console.log(`→ ${e.method.toUpperCase()} ${e.path}`);
  });
  stripe.on('response', (e) => {
    console.log(`← ${e.status} ${e.path} (${e.elapsed}ms) [${e.request_id}]`);
  });
}
```

### 1.2 TypeScript Types

```typescript
// Full type safety on API responses
const pi: Stripe.PaymentIntent = await stripe.paymentIntents.retrieve('pi_xxx', {
  expand: ['customer', 'latest_charge'],
});
const email = (pi.customer as Stripe.Customer).email;
const charge = pi.latest_charge as Stripe.Charge;

// Type-safe webhook handling (DiscriminatedEvent — v13.11+)
const event = stripe.webhooks.constructEvent(
  rawBody, sig, secret
) as Stripe.DiscriminatedEvent;

switch (event.type) {
  case 'payment_intent.succeeded':
    // TypeScript knows: event.data.object is Stripe.PaymentIntent
    console.log(event.data.object.amount);
    console.log(event.data.object.status); // 'succeeded'
    break;
  case 'customer.subscription.deleted':
    // TypeScript knows: event.data.object is Stripe.Subscription
    console.log(event.data.object.current_period_end);
    break;
  case 'invoice.paid':
    // TypeScript knows: event.data.object is Stripe.Invoice
    console.log(event.data.object.amount_paid);
    break;
}
```

### 1.3 Error Handling

```typescript
try {
  await stripe.paymentIntents.create({ amount: 2000, currency: 'usd' });
} catch (err) {
  if (err instanceof Stripe.errors.StripeError) {
    console.error(`Type: ${err.type}`);
    console.error(`Message: ${err.message}`);
    console.error(`Code: ${err.code}`);
    console.error(`Request ID: ${err.requestId}`);  // For Stripe support
    console.error(`Status: ${err.statusCode}`);

    switch (err.type) {
      case 'StripeCardError':
        // Show err.message to customer (safe)
        // Log err.decline_code for analytics
        break;
      case 'StripeRateLimitError':
        // Implement backoff and retry
        break;
      case 'StripeInvalidRequestError':
        // Bad parameters — fix code
        break;
      case 'StripeAuthenticationError':
        // Wrong API key
        break;
      case 'StripeAPIError':
        // Stripe server error — retry
        break;
      case 'StripeConnectionError':
        // Network issue — retry
        break;
      case 'StripeIdempotencyError':
        // Idempotency key reuse with different params
        break;
    }
  }
}
```

### 1.4 Auto-Pagination

```typescript
// Async iterator (recommended)
for await (const customer of stripe.customers.list({ limit: 100 })) {
  await processCustomer(customer);
}

// Collect all into array
const allCustomers = await stripe.customers.list({ limit: 100 }).autoPagingToArray({
  limit: 10000,  // Safety cap
});

// Each method with callback
await stripe.customers.list({ limit: 100 }).autoPagingEach(async (customer) => {
  await processCustomer(customer);
});
```

### 1.5 Expanding Objects

```typescript
// Single expansion
const pi = await stripe.paymentIntents.retrieve('pi_xxx', {
  expand: ['customer'],
});

// Nested expansion (max 4 levels)
const pi2 = await stripe.paymentIntents.retrieve('pi_xxx', {
  expand: ['customer', 'latest_charge.balance_transaction'],
});

// Expansion on list endpoints — prefix with 'data.'
const invoices = await stripe.invoices.list({
  customer: 'cus_xxx',
  expand: ['data.subscription', 'data.charge'],
});

// Expansion on create
const sub = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_xxx' }],
  expand: ['latest_invoice.payment_intent'],
});
```

---

## 2. Express.js

### 2.1 Complete Server Setup

```typescript
import express from 'express';
import Stripe from 'stripe';

const app = express();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// ═══════════════════════════════════════════════════
// CRITICAL: Webhook route BEFORE express.json()
// ═══════════════════════════════════════════════════
app.post('/webhook',
  express.raw({ type: 'application/json' }),
  async (req, res) => {
    const sig = req.headers['stripe-signature']!;
    let event: Stripe.Event;
    try {
      event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
    } catch (err) {
      return res.status(400).json({ error: `Webhook Error: ${err}` });
    }
    res.json({ received: true });
    await handleStripeEvent(event);
  }
);

// JSON parsing for all other routes (AFTER webhook)
app.use(express.json());

// ═══════════════════════════════════════════════════
// API Routes
// ═══════════════════════════════════════════════════

// Create Checkout Session
app.post('/create-checkout-session', async (req, res) => {
  const { priceId, customerId } = req.body;
  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    line_items: [{ price: priceId, quantity: 1 }],
    mode: 'subscription',
    success_url: `${process.env.CLIENT_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.CLIENT_URL}/pricing`,
  });
  res.json({ url: session.url });
});

// Create PaymentIntent (for custom payment form)
app.post('/create-payment-intent', async (req, res) => {
  const { amount, currency = 'usd' } = req.body;
  const pi = await stripe.paymentIntents.create({
    amount,
    currency,
    automatic_payment_methods: { enabled: true },
  });
  res.json({ clientSecret: pi.client_secret });
});

// Create Customer Portal session
app.post('/create-portal-session', async (req, res) => {
  const { customerId } = req.body;
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: `${process.env.CLIENT_URL}/account`,
  });
  res.json({ url: session.url });
});

app.listen(3000);
```

---

## 3. Next.js App Router (2026 Recommended)

### 3.1 Stripe Singleton

```typescript
// lib/stripe.ts (server-side only)
import Stripe from 'stripe';

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  maxNetworkRetries: 2,
});
```

### 3.2 Server Actions

```typescript
// app/actions/stripe.ts
'use server';

import { stripe } from '@/lib/stripe';
import { redirect } from 'next/navigation';
import { auth } from '@/lib/auth';

export async function createCheckoutSession(priceId: string) {
  const session = await auth();
  if (!session?.user) throw new Error('Not authenticated');

  const checkoutSession = await stripe.checkout.sessions.create({
    customer: session.user.stripeCustomerId,
    line_items: [{ price: priceId, quantity: 1 }],
    mode: 'subscription',
    success_url: `${process.env.NEXT_PUBLIC_URL}/dashboard?success=true`,
    cancel_url: `${process.env.NEXT_PUBLIC_URL}/pricing`,
    subscription_data: {
      metadata: { userId: session.user.id },
    },
  });

  redirect(checkoutSession.url!);
}

export async function createEmbeddedCheckoutSession(priceId: string) {
  const checkoutSession = await stripe.checkout.sessions.create({
    ui_mode: 'embedded',
    line_items: [{ price: priceId, quantity: 1 }],
    mode: 'subscription',
    return_url: `${process.env.NEXT_PUBLIC_URL}/checkout/return?session_id={CHECKOUT_SESSION_ID}`,
  });

  return { clientSecret: checkoutSession.client_secret };
}

export async function createPortalSession() {
  const session = await auth();
  if (!session?.user?.stripeCustomerId) throw new Error('No Stripe customer');

  const portalSession = await stripe.billingPortal.sessions.create({
    customer: session.user.stripeCustomerId,
    return_url: `${process.env.NEXT_PUBLIC_URL}/account`,
  });

  redirect(portalSession.url);
}
```

### 3.3 Webhook Route

```typescript
// app/api/webhooks/stripe/route.ts
import { headers } from 'next/headers';
import { stripe } from '@/lib/stripe';

// CRITICAL: Do NOT export runtime = 'edge'
export async function POST(req: Request) {
  const body = await req.text();
  const headersList = await headers();
  const sig = headersList.get('stripe-signature')!;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err) {
    return new Response(`Webhook Error: ${err}`, { status: 400 });
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = session.metadata?.userId || session.subscription_data?.metadata?.userId;
        await db.user.update({
          where: { id: userId },
          data: {
            stripeSubscriptionId: session.subscription as string,
            stripeCustomerId: session.customer as string,
            subscriptionStatus: 'active',
          },
        });
        break;
      }

      case 'invoice.paid': {
        const invoice = event.data.object as Stripe.Invoice;
        const subscriptionId = invoice.subscription as string;
        await db.user.updateMany({
          where: { stripeSubscriptionId: subscriptionId },
          data: {
            subscriptionStatus: 'active',
            currentPeriodEnd: new Date((invoice.lines.data[0]?.period?.end ?? 0) * 1000),
          },
        });
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        await db.user.updateMany({
          where: { stripeSubscriptionId: invoice.subscription as string },
          data: { subscriptionStatus: 'past_due' },
        });
        break;
      }

      case 'customer.subscription.deleted': {
        const sub = event.data.object as Stripe.Subscription;
        await db.user.updateMany({
          where: { stripeSubscriptionId: sub.id },
          data: { subscriptionStatus: 'canceled', stripeSubscriptionId: null },
        });
        break;
      }
    }
  } catch (err) {
    console.error(`Webhook handler error: ${err}`);
    return new Response('Handler error', { status: 500 });
  }

  return new Response(null, { status: 200 });
}
```

### 3.4 Pricing Page (Server Component)

```tsx
// app/pricing/page.tsx — Zero client JS for pricing display
import { stripe } from '@/lib/stripe';
import { createCheckoutSession } from '@/app/actions/stripe';

export default async function PricingPage() {
  const prices = await stripe.prices.list({
    lookup_keys: ['starter_monthly', 'pro_monthly', 'enterprise_monthly'],
    active: true,
    expand: ['data.product'],
  });

  return (
    <section className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto py-16">
      {prices.data
        .sort((a, b) => (a.unit_amount ?? 0) - (b.unit_amount ?? 0))
        .map((price) => {
          const product = price.product as Stripe.Product;
          return (
            <div key={price.id} className="border rounded-xl p-8 flex flex-col">
              <h2 className="text-2xl font-bold">{product.name}</h2>
              <p className="text-4xl font-bold mt-4">
                ${((price.unit_amount ?? 0) / 100).toFixed(2)}
                <span className="text-lg text-gray-500">/mo</span>
              </p>
              <p className="text-gray-600 mt-2">{product.description}</p>
              <ul className="mt-6 space-y-2 flex-1">
                {product.marketing_features?.map((f, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <span className="text-green-500">✓</span> {f.name}
                  </li>
                ))}
              </ul>
              <form action={createCheckoutSession.bind(null, price.id)}>
                <button
                  type="submit"
                  className="mt-8 w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700"
                >
                  Get Started
                </button>
              </form>
            </div>
          );
        })}
    </section>
  );
}
```

### 3.5 Subscription Dashboard (Server Component)

```tsx
// app/dashboard/billing/page.tsx
import { stripe } from '@/lib/stripe';
import { auth } from '@/lib/auth';
import { createPortalSession } from '@/app/actions/stripe';

export default async function BillingPage() {
  const session = await auth();
  if (!session?.user?.stripeSubscriptionId) {
    return <p>No active subscription. <a href="/pricing">Choose a plan</a></p>;
  }

  const subscription = await stripe.subscriptions.retrieve(
    session.user.stripeSubscriptionId,
    { expand: ['default_payment_method', 'items.data.price.product'] }
  );

  const price = subscription.items.data[0].price;
  const product = price.product as Stripe.Product;
  const pm = subscription.default_payment_method as Stripe.PaymentMethod;

  return (
    <div className="max-w-2xl mx-auto p-8">
      <h1 className="text-2xl font-bold">Billing</h1>

      <div className="mt-6 border rounded-lg p-6">
        <h2 className="font-semibold">{product.name}</h2>
        <p className="text-3xl font-bold mt-2">
          ${((price.unit_amount ?? 0) / 100).toFixed(2)}/{price.recurring?.interval}
        </p>
        <p className="text-gray-600 mt-1">
          Status: <span className="capitalize">{subscription.status}</span>
        </p>
        <p className="text-gray-600">
          Next billing: {new Date(subscription.current_period_end * 1000).toLocaleDateString()}
        </p>
        {pm?.card && (
          <p className="text-gray-600 mt-2">
            {pm.card.brand.toUpperCase()} •••• {pm.card.last4} — expires {pm.card.exp_month}/{pm.card.exp_year}
          </p>
        )}
      </div>

      <form action={createPortalSession} className="mt-4">
        <button type="submit" className="text-blue-600 underline">
          Manage subscription
        </button>
      </form>
    </div>
  );
}
```

---

## 4. Next.js Pages Router (Legacy)

### 4.1 API Route

```typescript
// pages/api/create-checkout-session.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { stripe } from '@/lib/stripe';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();

  const { priceId } = req.body;
  const session = await stripe.checkout.sessions.create({
    line_items: [{ price: priceId, quantity: 1 }],
    mode: 'subscription',
    success_url: `${req.headers.origin}/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${req.headers.origin}/pricing`,
  });

  res.json({ url: session.url });
}
```

### 4.2 Webhook (Disable Body Parser)

```typescript
// pages/api/webhook.ts
import { buffer } from 'micro';
import type { NextApiRequest, NextApiResponse } from 'next';

export const config = { api: { bodyParser: false } };

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();
  const buf = await buffer(req);
  const sig = req.headers['stripe-signature'] as string;
  const event = stripe.webhooks.constructEvent(buf.toString(), sig, process.env.STRIPE_WEBHOOK_SECRET!);
  // Handle event...
  res.json({ received: true });
}
```

### 4.3 Migration to App Router

Key differences:
- API routes → Route Handlers (`app/api/*/route.ts`)
- `getServerSideProps` → Server Components (direct `await`)
- API calls from components → Server Actions (`'use server'`)
- `micro` buffer → `req.text()` (built-in)
- `req.body` → `await request.json()` or `await request.text()`

---

## 5. Python / Django

### 5.1 Installation

```bash
pip install stripe        # v14.3.0
pip install dj-stripe     # v2.10.3 (optional — ORM integration)
```

### 5.2 Manual Integration

```python
# settings.py
STRIPE_SECRET_KEY = os.environ.get('STRIPE_SECRET_KEY')
STRIPE_WEBHOOK_SECRET = os.environ.get('STRIPE_WEBHOOK_SECRET')
STRIPE_PUBLISHABLE_KEY = os.environ.get('STRIPE_PUBLISHABLE_KEY')

# stripe_config.py
import stripe
stripe.api_key = settings.STRIPE_SECRET_KEY
stripe.max_network_retries = 2
```

```python
# views.py
import stripe
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.conf import settings

def create_checkout_session(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)

    import json
    data = json.loads(request.body)
    session = stripe.checkout.Session.create(
        customer=data.get('customer_id'),
        line_items=[{'price': data['price_id'], 'quantity': 1}],
        mode='subscription',
        success_url=f"{settings.FRONTEND_URL}/success?session_id={{CHECKOUT_SESSION_ID}}",
        cancel_url=f"{settings.FRONTEND_URL}/pricing",
    )
    return JsonResponse({'url': session.url})

@csrf_exempt
@require_POST
def stripe_webhook(request):
    payload = request.body
    sig_header = request.META.get('HTTP_STRIPE_SIGNATURE')

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, settings.STRIPE_WEBHOOK_SECRET
        )
    except (ValueError, stripe.error.SignatureVerificationError):
        return HttpResponse(status=400)

    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        handle_checkout(session)
    elif event['type'] == 'invoice.paid':
        invoice = event['data']['object']
        handle_invoice_paid(invoice)
    elif event['type'] == 'customer.subscription.deleted':
        subscription = event['data']['object']
        handle_cancellation(subscription)

    return HttpResponse(status=200)
```

### 5.3 dj-stripe Integration

```python
# settings.py
INSTALLED_APPS = [
    # ...
    'djstripe',
]

DJSTRIPE_WEBHOOK_SECRET = os.environ.get('STRIPE_WEBHOOK_SECRET')
DJSTRIPE_FOREIGN_KEY_TO_FIELD = 'id'
DJSTRIPE_USE_NATIVE_JSONFIELD = True

# urls.py
urlpatterns = [
    path('stripe/', include('djstripe.urls', namespace='djstripe')),
    # Webhooks auto-mounted at /stripe/webhook/
]

# Signal-based webhook handling
from djstripe import webhooks

@webhooks.handler('customer.subscription.created')
def handle_new_sub(event, **kwargs):
    subscription = event.data['object']
    # dj-stripe auto-syncs to Django ORM
    # Access via: djstripe.models.Subscription.objects.get(id=subscription['id'])

@webhooks.handler('invoice.paid')
def handle_invoice_paid(event, **kwargs):
    invoice = event.data['object']
    # Provision access

# Query synced models
from djstripe.models import Customer, Subscription

customer = Customer.objects.get(subscriber=user)
active_subs = customer.subscriptions.filter(status='active')
```

---

## 6. Python / FastAPI

### 6.1 Complete Application

```python
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import JSONResponse, RedirectResponse
from pydantic import BaseModel
import stripe
import os

app = FastAPI()
stripe.api_key = os.environ['STRIPE_SECRET_KEY']

# ─── Pydantic Models ───

class CheckoutRequest(BaseModel):
    price_id: str
    customer_id: str | None = None

class PortalRequest(BaseModel):
    customer_id: str

class PaymentIntentRequest(BaseModel):
    amount: int
    currency: str = 'usd'

# ─── Payment Routes ───

@app.post("/create-checkout-session")
async def create_checkout_session(req: CheckoutRequest):
    session = stripe.checkout.Session.create(
        customer=req.customer_id,
        line_items=[{"price": req.price_id, "quantity": 1}],
        mode="subscription",
        success_url=f"{os.environ['FRONTEND_URL']}/success?session_id={{CHECKOUT_SESSION_ID}}",
        cancel_url=f"{os.environ['FRONTEND_URL']}/pricing",
    )
    return {"url": session.url, "session_id": session.id}

@app.post("/create-payment-intent")
async def create_payment_intent(req: PaymentIntentRequest):
    pi = stripe.PaymentIntent.create(
        amount=req.amount,
        currency=req.currency,
        automatic_payment_methods={"enabled": True},
    )
    return {"client_secret": pi.client_secret}

@app.post("/create-portal-session")
async def create_portal_session(req: PortalRequest):
    session = stripe.billing_portal.Session.create(
        customer=req.customer_id,
        return_url=f"{os.environ['FRONTEND_URL']}/account",
    )
    return {"url": session.url}

# ─── Webhook ───

@app.post("/webhook")
async def stripe_webhook(request: Request):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, os.environ["STRIPE_WEBHOOK_SECRET"]
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid payload")
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Invalid signature")

    match event["type"]:
        case "checkout.session.completed":
            session = event["data"]["object"]
            await handle_checkout_completed(session)
        case "invoice.paid":
            invoice = event["data"]["object"]
            await handle_invoice_paid(invoice)
        case "invoice.payment_failed":
            invoice = event["data"]["object"]
            await handle_payment_failed(invoice)
        case "customer.subscription.deleted":
            subscription = event["data"]["object"]
            await handle_subscription_deleted(subscription)

    return {"received": True}

# ─── Async StripeClient ───

from stripe import StripeClient

client = StripeClient(os.environ["STRIPE_SECRET_KEY"])

@app.get("/customers/{customer_id}")
async def get_customer(customer_id: str):
    customer = await client.v1.customers.retrieve_async(customer_id)
    return {"id": customer.id, "email": customer.email}

@app.get("/subscriptions/{customer_id}")
async def get_subscriptions(customer_id: str):
    subs = await client.v1.subscriptions.list_async(
        params={"customer": customer_id, "status": "active"}
    )
    return {"subscriptions": [{"id": s.id, "status": s.status} for s in subs.data]}
```

---

## 7. Python / Flask

```python
from flask import Flask, request, jsonify, redirect
import stripe
import os

app = Flask(__name__)
stripe.api_key = os.environ['STRIPE_SECRET_KEY']

@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    data = request.get_json()
    session = stripe.checkout.Session.create(
        line_items=[{'price': data['price_id'], 'quantity': 1}],
        mode='subscription',
        success_url=f"{os.environ['FRONTEND_URL']}/success",
        cancel_url=f"{os.environ['FRONTEND_URL']}/pricing",
    )
    return jsonify(url=session.url)

@app.route('/webhook', methods=['POST'])
def stripe_webhook():
    payload = request.data
    sig_header = request.headers.get('Stripe-Signature')

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, os.environ['STRIPE_WEBHOOK_SECRET']
        )
    except (ValueError, stripe.error.SignatureVerificationError):
        return '', 400

    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        handle_checkout(session)
    elif event['type'] == 'invoice.paid':
        handle_invoice_paid(event['data']['object'])

    return jsonify(received=True), 200

if __name__ == '__main__':
    app.run(port=4242)
```

---

## 8. Ruby / Rails

### 8.1 Installation

```ruby
# Gemfile
gem 'stripe', '~> 18.3'
gem 'pay', '~> 11.0'        # Optional: high-level billing
gem 'stripe_event', '~> 2.14' # Optional: event routing
```

### 8.2 Configuration

```ruby
# config/initializers/stripe.rb
Stripe.api_key = Rails.application.credentials.dig(:stripe, :secret_key)
Stripe.max_network_retries = 2

# Modern StripeClient
STRIPE_CLIENT = Stripe::StripeClient.new(
  Rails.application.credentials.dig(:stripe, :secret_key)
)
```

### 8.3 Controller

```ruby
# app/controllers/checkouts_controller.rb
class CheckoutsController < ApplicationController
  def create
    session = Stripe::Checkout::Session.create(
      customer: current_user.stripe_customer_id,
      line_items: [{ price: params[:price_id], quantity: 1 }],
      mode: 'subscription',
      success_url: "#{root_url}success?session_id={CHECKOUT_SESSION_ID}",
      cancel_url: "#{root_url}pricing"
    )
    redirect_to session.url, allow_other_host: true, status: :see_other
  end
end

# app/controllers/billing_portal_controller.rb
class BillingPortalController < ApplicationController
  def create
    session = Stripe::BillingPortal::Session.create(
      customer: current_user.stripe_customer_id,
      return_url: account_url
    )
    redirect_to session.url, allow_other_host: true, status: :see_other
  end
end
```

### 8.4 Webhook Controller

```ruby
# app/controllers/webhooks/stripe_controller.rb
class Webhooks::StripeController < ApplicationController
  skip_before_action :verify_authenticity_token

  def create
    payload = request.body.read
    sig_header = request.env['HTTP_STRIPE_SIGNATURE']

    begin
      event = Stripe::Webhook.construct_event(
        payload, sig_header,
        Rails.application.credentials.dig(:stripe, :webhook_secret)
      )
    rescue JSON::ParserError, Stripe::SignatureVerificationError
      head :bad_request
      return
    end

    # Process async via Active Job
    StripeWebhookJob.perform_later(event.to_json)
    head :ok
  end
end

# app/jobs/stripe_webhook_job.rb
class StripeWebhookJob < ApplicationJob
  queue_as :default

  def perform(event_json)
    event = Stripe::Event.construct_from(JSON.parse(event_json))

    case event.type
    when 'checkout.session.completed'
      handle_checkout(event.data.object)
    when 'invoice.paid'
      handle_invoice_paid(event.data.object)
    when 'customer.subscription.deleted'
      handle_cancellation(event.data.object)
    end
  end
end
```

### 8.5 Pay Gem

```ruby
# Auto-mounts webhooks at /pay/webhooks/stripe
# Provides Pay::Subscription, Pay::Charge, Pay::Customer models

class User < ApplicationRecord
  pay_customer default_payment_processor: :stripe
end

# Create subscription
user.payment_processor.subscribe(plan: 'price_xxx')

# Check status
user.payment_processor.subscribed?
user.payment_processor.on_trial?

# Charge
user.payment_processor.charge(2000) # $20.00
```

### 8.6 stripe_event Gem

```ruby
# config/initializers/stripe_event.rb
StripeEvent.configure do |events|
  events.subscribe 'checkout.session.completed' do |event|
    CheckoutCompletedHandler.new.call(event)
  end

  events.subscribe 'invoice.paid' do |event|
    InvoicePaidHandler.new.call(event)
  end

  # Wildcard
  events.all do |event|
    Rails.logger.info "Stripe event: #{event.type}"
  end
end

# config/routes.rb
mount StripeEvent::Engine, at: '/stripe-webhooks'
```

---

## 9. Serverless Patterns

### 9.1 General Principles

- Initialize Stripe at **module level** (reused across warm invocations)
- Set `timeout` < function timeout
- Use `maxNetworkRetries: 1` to avoid exceeding function timeout
- **Do NOT use Edge Runtime** for Stripe server-side calls

### 9.2 AWS Lambda

```typescript
// handler.ts
import Stripe from 'stripe';
import type { APIGatewayProxyHandler } from 'aws-lambda';

// Module-level — reused across warm invocations
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  maxNetworkRetries: 1,
  timeout: 10000,
});

export const createCheckout: APIGatewayProxyHandler = async (event) => {
  const { priceId } = JSON.parse(event.body || '{}');

  const session = await stripe.checkout.sessions.create({
    line_items: [{ price: priceId, quantity: 1 }],
    mode: 'subscription',
    success_url: `${process.env.FRONTEND_URL}/success`,
    cancel_url: `${process.env.FRONTEND_URL}/pricing`,
  });

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url: session.url }),
  };
};

export const webhook: APIGatewayProxyHandler = async (event) => {
  const body = event.isBase64Encoded
    ? Buffer.from(event.body!, 'base64').toString('utf8')
    : event.body!;
  const sig = event.headers['stripe-signature'] || event.headers['Stripe-Signature'];

  const stripeEvent = stripe.webhooks.constructEvent(
    body, sig!, process.env.STRIPE_WEBHOOK_SECRET!
  );

  // Handle event...
  return { statusCode: 200, body: '{"received":true}' };
};
```

### 9.3 Vercel Serverless Functions

```typescript
// api/create-checkout.ts (Vercel serverless — Node.js runtime)
import type { VercelRequest, VercelResponse } from '@vercel/node';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') return res.status(405).end();

  const session = await stripe.checkout.sessions.create({
    line_items: [{ price: req.body.priceId, quantity: 1 }],
    mode: 'subscription',
    success_url: `${process.env.NEXT_PUBLIC_URL}/success`,
    cancel_url: `${process.env.NEXT_PUBLIC_URL}/pricing`,
  });

  res.json({ url: session.url });
}
```

### 9.4 Cloudflare Workers

```typescript
export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const stripe = new Stripe(env.STRIPE_SECRET_KEY);

    const url = new URL(request.url);

    if (url.pathname === '/create-checkout' && request.method === 'POST') {
      const { priceId } = await request.json() as { priceId: string };
      const session = await stripe.checkout.sessions.create({
        line_items: [{ price: priceId, quantity: 1 }],
        mode: 'subscription',
        success_url: `${env.FRONTEND_URL}/success`,
        cancel_url: `${env.FRONTEND_URL}/pricing`,
      });
      return Response.json({ url: session.url });
    }

    if (url.pathname === '/webhook' && request.method === 'POST') {
      const body = await request.text();
      const sig = request.headers.get('stripe-signature')!;
      const event = await stripe.webhooks.constructEventAsync(
        body, sig, env.STRIPE_WEBHOOK_SECRET
      );
      // Handle event...
      return Response.json({ received: true });
    }

    return new Response('Not found', { status: 404 });
  },
};
```

---

## 10. Fastify

```typescript
import Fastify from 'fastify';
import rawBody from 'fastify-raw-body';
import Stripe from 'stripe';

const fastify = Fastify({ logger: true });
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// Register raw body plugin (for webhooks only)
await fastify.register(rawBody, {
  field: 'rawBody',
  global: false,
  encoding: 'utf8',
  runFirst: true,
});

// Webhook route with raw body
fastify.post('/webhook', {
  config: { rawBody: true },
}, async (request, reply) => {
  const sig = request.headers['stripe-signature'] as string;
  const event = stripe.webhooks.constructEvent(
    request.rawBody!, sig, process.env.STRIPE_WEBHOOK_SECRET!
  );
  // Handle event...
  return { received: true };
});

// Regular route (JSON parsed normally)
fastify.post('/create-checkout-session', async (request, reply) => {
  const { priceId } = request.body as { priceId: string };
  const session = await stripe.checkout.sessions.create({
    line_items: [{ price: priceId, quantity: 1 }],
    mode: 'subscription',
    success_url: `${process.env.FRONTEND_URL}/success`,
    cancel_url: `${process.env.FRONTEND_URL}/pricing`,
  });
  return { url: session.url };
});

fastify.listen({ port: 3000 });
```

---

## 11. Gotchas & Cross-References

### Framework Gotchas

1. **Express middleware order** — Webhook `express.raw()` MUST come BEFORE `express.json()`.
2. **Next.js Edge Runtime** — Do NOT use `runtime: 'edge'` for Stripe server-side. Crypto operations require Node.js.
3. **Next.js Pages Router `bodyParser`** — Must disable for webhook routes: `export const config = { api: { bodyParser: false } }`.
4. **Django `request.body` vs `request.data`** — Use `request.body` (raw) for webhooks, NOT `request.data` (parsed by DRF).
5. **FastAPI `request.body()` vs Pydantic** — Webhook must use `await request.body()`, not a Pydantic model parameter.
6. **Fastify raw body** — Requires `fastify-raw-body` plugin with `global: false` and `config: { rawBody: true }` per route.
7. **Serverless cold starts** — Initialize Stripe at module level for warm invocation reuse.
8. **Cloudflare Workers** — Use `constructEventAsync` (async crypto) instead of `constructEvent`.
9. **Rails CSRF** — Must `skip_before_action :verify_authenticity_token` on webhook controller.
10. **Stripe singleton** — Always reuse the Stripe client instance. Creating per-request wastes connection pool.

### Cross-References

- For webhook event catalog → `webhooks.md`
- For frontend Elements setup → `elements-and-frontend.md`
- For error handling patterns → `error-handling-and-rate-limits.md`
- For payment flows → `payments-and-checkout.md`
- For subscription management → `subscriptions-and-billing.md`
- For Connect integration → `stripe-connect.md`
- For testing → `testing-and-tooling.md`
