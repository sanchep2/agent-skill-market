# Stripe Tax & Revenue — Complete Reference

Covers Stripe Tax, Adaptive Pricing, Revenue Recovery (Smart Retries, Smart Disputes, Smart Refunds), Optimized Checkout Suite, Stablecoin Accounts, Terminal / In-Person payments, and Organizations. API version `2026-01-28.clover`.

## Table of Contents

1. [Stripe Tax](#1-stripe-tax)
2. [Adaptive Pricing](#2-adaptive-pricing)
3. [Revenue Recovery](#3-revenue-recovery)
4. [Optimized Checkout Suite](#4-optimized-checkout-suite)
5. [Stablecoin Accounts](#5-stablecoin-accounts)
6. [Terminal / In-Person Payments](#6-terminal--in-person-payments)
7. [Organizations](#7-organizations)
8. [Gotchas & Cross-References](#8-gotchas--cross-references)

---

## 1. Stripe Tax

### 1.1 Overview

Automatic tax calculation, collection, and reporting for **102 countries**. Calculates the correct tax amount based on product type, customer location, and applicable tax rules.

### 1.2 Enabling Tax

```typescript
// On Checkout Sessions
const session = await stripe.checkout.sessions.create({
  mode: 'payment',
  line_items: [{ price: 'price_xxx', quantity: 1 }],
  automatic_tax: { enabled: true },
  success_url: 'https://example.com/success',
});

// On Subscriptions
const sub = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_xxx' }],
  automatic_tax: { enabled: true },
});

// On Invoices
const invoice = await stripe.invoices.create({
  customer: 'cus_xxx',
  automatic_tax: { enabled: true },
});

// On Payment Links
const link = await stripe.paymentLinks.create({
  line_items: [{ price: 'price_xxx', quantity: 1 }],
  automatic_tax: { enabled: true },
});
```

### 1.3 Tax Behavior on Prices

| Behavior | Description | Common Use |
|----------|-------------|------------|
| `exclusive` | Tax added on top of price | US, B2B ($100 + $8.75 tax = $108.75) |
| `inclusive` | Tax included in price | EU B2C, UK (€100 includes €16.81 VAT) |
| `unspecified` | No tax behavior (default) | Non-taxed items |

```typescript
// Create price with tax behavior
const price = await stripe.prices.create({
  product: 'prod_xxx',
  unit_amount: 2900,
  currency: 'usd',
  recurring: { interval: 'month' },
  tax_behavior: 'exclusive',
});
```

**Critical**: Cannot change `tax_behavior` after price creation — must create a new price.

### 1.4 Tax Codes

Stripe uses product tax codes to determine the applicable tax rate:

| Code | Category | Example |
|------|----------|---------|
| `txcd_10000000` | General — Tangible goods | Physical products |
| `txcd_10103001` | General — Electronically supplied services | SaaS, digital services |
| `txcd_10103000` | General — Software as a Service | SaaS subscriptions |
| `txcd_10201000` | General — Downloadable software | Software downloads |
| `txcd_10301000` | General — Digital content | E-books, music, video |
| `txcd_10502000` | General — Cloud computing | IaaS, PaaS |
| `txcd_99999999` | Non-taxable | Gifts, donations |

```typescript
// Set tax code on product
const product = await stripe.products.create({
  name: 'Pro Plan',
  tax_code: 'txcd_10103001',  // SaaS / digital service
});

// Or on price
const price = await stripe.prices.create({
  product: 'prod_xxx',
  unit_amount: 2900,
  currency: 'usd',
  tax_behavior: 'exclusive',
  // Tax code inherited from product, or override per price
});
```

### 1.5 Tax Registration

Register your tax obligations in Stripe Dashboard (Settings > Tax > Registrations):

```typescript
// Registrations determine where you collect tax
// Example: Register for US state sales tax, EU VAT, UK VAT

// Tax registrations are managed via Dashboard, not API
// Each registration includes:
// - Country/state
// - Tax type (VAT, GST, sales tax, etc.)
// - Registration number
// - Effective date
```

### 1.6 Tax Calculation API (Standalone)

Calculate tax without creating a payment:

```typescript
const calculation = await stripe.tax.calculations.create({
  currency: 'usd',
  line_items: [
    {
      amount: 10000,                     // $100.00
      reference: 'item_1',
      tax_behavior: 'exclusive',
      tax_code: 'txcd_10103001',         // SaaS
    },
    {
      amount: 5000,                      // $50.00
      reference: 'item_2',
      tax_behavior: 'exclusive',
      tax_code: 'txcd_10000000',         // Tangible goods
    },
  ],
  customer_details: {
    address: {
      country: 'US',
      state: 'CA',
      postal_code: '94110',
      city: 'San Francisco',
    },
    address_source: 'shipping',          // 'shipping' or 'billing'
  },
  // Optional: for B2B reverse charge
  // customer_details: {
  //   tax_ids: [{ type: 'eu_vat', value: 'DE123456789' }],
  // },
});

console.log(`Subtotal: $${calculation.amount_total / 100}`);
console.log(`Tax: $${calculation.tax_amount_exclusive / 100}`);
console.log(`Total: $${(calculation.amount_total + calculation.tax_amount_exclusive) / 100}`);

// Line-level tax breakdown
for (const item of calculation.line_items?.data ?? []) {
  console.log(`${item.reference}: tax $${item.amount_tax / 100}`);
}
```

### 1.7 Tax Reporting

```typescript
// Tax transactions (for reporting)
const transactions = await stripe.tax.transactions.list({
  created: {
    gte: Math.floor(new Date('2026-01-01').getTime() / 1000),
    lte: Math.floor(new Date('2026-02-01').getTime() / 1000),
  },
});

// Export via Dashboard: Tax > Reporting > Export
// Formats: CSV for accounting software, Stripe Tax summary
```

### 1.8 Tax ID Collection

```typescript
// Collect tax IDs in Checkout
const session = await stripe.checkout.sessions.create({
  mode: 'subscription',
  line_items: [{ price: 'price_xxx', quantity: 1 }],
  tax_id_collection: { enabled: true },
  automatic_tax: { enabled: true },
  success_url: 'https://example.com/success',
});

// Manage customer tax IDs
await stripe.customers.createTaxId('cus_xxx', {
  type: 'eu_vat',
  value: 'DE123456789',
});

const taxIds = await stripe.customers.listTaxIds('cus_xxx');
```

**Supported tax ID types**: `eu_vat`, `gb_vat`, `us_ein`, `au_abn`, `au_arn`, `br_cnpj`, `br_cpf`, `ca_bn`, `ca_gst_hst`, `ca_pst_bc`, `ca_pst_mb`, `ca_pst_sk`, `ca_qst`, `ch_vat`, `in_gst`, `jp_cn`, `jp_rn`, `kr_brn`, `mx_rfc`, `my_frp`, `my_itn`, `my_sst`, `nz_gst`, `sg_gst`, `sg_uen`, `za_vat`, and many more.

---

## 2. Adaptive Pricing

### 2.1 Overview

GA feature that auto-localizes prices in **150+ markets**. Shows customers prices in their local currency with contextually appropriate amounts (not just exchange rate conversion).

### 2.2 How It Works

```
Customer in Germany → sees €27/mo (not $29 USD converted to €26.73)
Customer in Japan → sees ¥4,300/mo (rounded to local convention)
Customer in Brazil → sees R$149/mo (adjusted for local purchasing power)
```

### 2.3 Enabling

```typescript
// Enable on Checkout Sessions
const session = await stripe.checkout.sessions.create({
  mode: 'subscription',
  line_items: [{
    price: 'price_xxx',                 // Base price in USD
    quantity: 1,
  }],
  currency_options: {
    eur: { unit_amount: 2700 },          // Override EUR price
    jpy: { unit_amount: 4300 },          // Override JPY price
  },
  success_url: 'https://example.com/success',
});

// Enable on Prices (Dashboard or API)
const price = await stripe.prices.create({
  product: 'prod_xxx',
  unit_amount: 2900,
  currency: 'usd',
  recurring: { interval: 'month' },
  currency_options: {
    eur: { unit_amount: 2700 },
    gbp: { unit_amount: 2300 },
    jpy: { unit_amount: 4300 },
    brl: { unit_amount: 14900 },
  },
});
```

### 2.4 Adaptive Pricing Rules

- **Automatic rounding**: Prices rounded to local conventions (e.g., ¥4,300 not ¥4,287)
- **Psychological pricing**: Maintains charm pricing where culturally appropriate
- **Override support**: Set specific prices per currency manually
- **Presentment currency**: Customer sees and pays in their local currency
- **Settlement**: You receive funds in your settlement currency

---

## 3. Revenue Recovery

### 3.1 Smart Retries

ML-powered payment retry optimization. Uses network signals across Stripe's $1.9T annual volume to choose optimal retry timing.

**Configuration** (Dashboard > Billing > Revenue Recovery):
- Default: **8 retries within 2 weeks**
- Does NOT retry hard declines (card canceled, doesn't exist)
- Optimizes retry timing based on: day of week, time of day, bank patterns, card network signals

```typescript
// Monitor Smart Retries via webhooks
switch (event.type) {
  case 'invoice.payment_failed':
    const invoice = event.data.object as Stripe.Invoice;
    console.log(`Attempt ${invoice.attempt_count} failed`);
    // Smart Retries will continue automatically
    break;
  case 'invoice.paid':
    // Smart Retry succeeded!
    console.log('Payment recovered');
    break;
}
```

### 3.2 Smart Disputes (Preview)

AI-powered automatic dispute response. Stripe auto-submits evidence for eligible disputes.

- **30% success fee** — only charged when dispute is won
- Analyzes dispute category and available evidence
- Auto-gathers: transaction data, delivery proof, customer history
- Available for select dispute categories (fraudulent, product_not_received)

### 3.3 Smart Refunds (GA)

AI proactively refunds transactions likely to be disputed, avoiding the $15 dispute fee and dispute rate impact.

- Analyzes transaction patterns for dispute risk
- Issues preemptive refund before customer disputes
- Reduces dispute rate (critical — Visa/Mastercard programs have dispute rate thresholds)
- Net cost savings: refund processing fee vs $15 dispute fee + dispute rate impact

### 3.4 Authorization Boost

AI-powered acceptance rate optimization. Stripe optimizes authorization requests to increase approval rates.

- Automatically selects optimal authorization parameters
- Retries soft declines with adjusted parameters
- Routes to optimal card network paths
- Average uplift: varies by merchant category and geography

---

## 4. Optimized Checkout Suite

### 4.1 Overview

Average **11.9% revenue uplift** with 100+ AI signals for checkout personalization.

### 4.2 Components

| Feature | Description | Impact |
|---------|-------------|--------|
| **Dynamic payment methods** | Auto-show relevant PMs by location/amount | Higher conversion |
| **Link integration** | One-click checkout for returning users | 14% conversion lift |
| **Address autocomplete** | Google Maps-powered address fill | Fewer form errors |
| **Optimized card form** | AI-ordered fields, smart validation | Faster completion |
| **Currency detection** | Auto-detect and show local currency | Fewer abandonments |
| **A/B testing** | Stripe auto-tests payment method ordering | Continuous optimization |

### 4.3 Enabling

Optimized Checkout Suite features are enabled by default when using:
- Checkout Sessions (hosted or embedded)
- Payment Element with `automatic_payment_methods: { enabled: true }`

No code changes needed — Stripe optimizes automatically.

---

## 5. Stablecoin Accounts

### 5.1 Overview

GA since May 2025. Hold USDC balances, convert between fiat and stablecoins, send/receive via crypto and fiat rails. Available in 100+ countries.

### 5.2 Capabilities

| Feature | Description |
|---------|-------------|
| **USDC balances** | Hold balances in USDC |
| **Fiat on-ramp** | Convert USD/EUR to USDC |
| **Fiat off-ramp** | Convert USDC to fiat currencies |
| **Crypto payouts** | Send USDC to external wallets |
| **Crypto pay-ins** | Accept USDC payments from customers |
| **Multi-chain** | Ethereum, Solana, Polygon, Base |

### 5.3 Accepting Stablecoin Payments

```typescript
// Accept USDC payments via Checkout
const session = await stripe.checkout.sessions.create({
  mode: 'payment',
  line_items: [{
    price_data: {
      currency: 'usd',
      product_data: { name: 'Digital Service' },
      unit_amount: 5000,
    },
    quantity: 1,
  }],
  payment_method_types: ['card', 'crypto'],  // Include crypto
  success_url: 'https://example.com/success',
});
```

### 5.4 Financial Accounts

```typescript
// Stablecoin financial accounts provide:
// - USDC balance management
// - Conversion between USDC and fiat
// - Transaction history
// - Programmatic transfers

// Managed via Dashboard: Balances > Financial accounts
// Or via Treasury API for programmatic access
```

---

## 6. Terminal / In-Person Payments

### 6.1 Hardware

| Reader | Key Features | Use Case |
|--------|-------------|----------|
| **Reader S700** | Android-based, custom POS apps, global | Full POS systems |
| **Reader S710** | Cellular connectivity, no Wi-Fi needed | Mobile merchants |
| **BBPOS WisePad 3** | Compact, Bluetooth | Mobile / events |
| **BBPOS Chipper 2X BT** | Smallest, Bluetooth | Tap-on-mobile |
| **Verifone P400** | Countertop, Ethernet/Wi-Fi | Retail counters |

### 6.2 Tap to Pay

| Platform | Availability |
|----------|-------------|
| **iPhone** | US, UK, AU, CA, FR, DE, IE, NL + more |
| **Android** | All Terminal-supported countries |

No additional hardware needed — uses device NFC.

### 6.3 Integration

```typescript
// Server: Create PaymentIntent for Terminal
const pi = await stripe.paymentIntents.create({
  amount: 1000,
  currency: 'usd',
  payment_method_types: ['card_present'],
  capture_method: 'automatic',
});

// Server: Create connection token for SDK
const token = await stripe.terminal.connectionTokens.create();

// Client-side: Use Terminal SDK (React Native, iOS, Android, JavaScript)
// to connect to reader and process payment
```

### 6.4 Offline Mode (GA)

Process payments without internet connectivity:
- Transactions queued locally on the reader
- Auto-sync when connectivity restored
- Configurable offline limits (amount, time, count)
- Risk managed by Stripe

---

## 7. Organizations

### 7.1 Overview

Manage multiple Stripe accounts under a unified organizational structure.

### 7.2 Features

| Feature | Description |
|---------|-------------|
| **Unified Dashboard** | Switch between accounts from one login |
| **Centralized user management** | Manage team access across accounts |
| **Consolidated reporting** | Cross-account analytics |
| **Shared settings** | Common configurations across accounts |
| **Role-based access** | Per-account permission control |

### 7.3 Use Cases

- **Multi-brand companies** — Separate Stripe account per brand
- **Multi-region** — Different account per region/entity
- **Staging/Production** — Organized by environment
- **Franchise models** — Parent company manages franchise accounts

---

## 8. Gotchas & Cross-References

### Tax & Revenue Gotchas

1. **tax_behavior is immutable on prices** — Cannot change after creation. Must create new price.
2. **Tax registrations needed first** — `automatic_tax` won't calculate tax unless you've registered in the relevant jurisdiction.
3. **Tax codes matter** — Wrong tax code = wrong tax rate. SaaS (`txcd_10103001`) ≠ physical goods (`txcd_10000000`).
4. **Adaptive Pricing ≠ currency conversion** — It's localized pricing, not just exchange rates.
5. **Smart Retries don't retry hard declines** — `expired_card`, `card_not_supported` are not retried.
6. **Stablecoin payments need explicit opt-in** — Add `'crypto'` to `payment_method_types`.
7. **Terminal readers need registration** — Register readers to your account via Dashboard or API before use.
8. **Offline mode has limits** — Configurable caps on amount, time, and transaction count.

### Cross-References

- For tax on subscriptions → `subscriptions-and-billing.md`
- For tax in Checkout Sessions → `payments-and-checkout.md`
- For revenue recovery webhooks → `webhooks.md`
- For testing tax flows → `testing-and-tooling.md`
- For payment method catalog → `payments-and-checkout.md`
