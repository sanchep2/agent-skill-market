---
name: stripe-skill
description: >
  Use this skill whenever the user needs to work with Stripe — both programmatically
  AND for payment/billing architecture decisions. This includes: writing TypeScript/Python/Ruby
  code that calls the Stripe API, creating or managing PaymentIntents, Checkout Sessions,
  subscriptions, invoices, or billing flows, setting up authentication (API keys, restricted keys,
  webhook secrets), implementing Stripe Elements or Payment Element in React/Next.js/Vue,
  building Connect platforms (Standard, Express, Custom accounts, direct/destination/separate
  charges), handling webhooks (signature verification, raw body, event processing),
  integrating with frameworks (Express, Next.js App Router, FastAPI, Django, Rails, Fastify,
  serverless), implementing Stripe Tax, Adaptive Pricing, or Revenue Recovery, working with
  the Meters API for usage-based billing, managing disputes with Radar, testing with
  test cards/Test Clocks/Stripe CLI/stripe-mock/Sandboxes, migrating between API versions
  (Acacia/Basil/Clover), or building agentic commerce with Stripe Agent Toolkit/MCP Server/ACP.
  ALSO trigger for payment architecture decisions: choosing between Checkout vs PaymentIntents,
  subscription billing models (flat/per-seat/metered/tiered), Connect charge types
  (direct/destination/separate), embedded vs hosted checkout, manual vs automatic capture,
  on-session vs off-session payments, SCA/3DS strategy, dunning and failed payment recovery,
  or multi-currency and zero-decimal currency handling.
  Trigger keywords: "Stripe", "PaymentIntent", "Checkout Session", "subscription", "billing",
  "Connect", "marketplace", "Payment Element", "stripe-js", "webhook", "stripe-signature",
  "Stripe MCP", "Agentic Commerce", "ACP", "Stripe Tax", "Invoice", "Customer Portal",
  "Radar", "dispute", "refund", "payout", "transfer", "destination charge", "direct charge",
  "application_fee", "Meters API", "usage-based billing", "tiered pricing", "per-seat",
  "metered", "proration", "billing_cycle_anchor", "coupon", "promotion code", "trial",
  "dunning", "Smart Retries", "Revenue Recovery", "Adaptive Pricing", "stripe npm",
  "stripe-python", "stripe-ruby", "@stripe/stripe-js", "@stripe/react-stripe-js",
  "Elements", "Appearance API", "Express Checkout Element", "Address Element", "Link",
  "Apple Pay", "Google Pay", "SEPA", "ACH", "iDEAL", "Klarna", "BNPL", "USDC",
  "stablecoin", "Terminal", "Tap to Pay", "test card", "Test Clock", "Sandbox",
  "Workbench", "stripe-mock", "Stripe CLI", "stripe listen", "stripe trigger",
  "Stripe Agent Toolkit", "Agent Commerce Protocol", "embedded component",
  "Account Link", "onboarding", "KYC", "payout schedule", "Instant Payout",
  "idempotency", "expand", "metadata", "auto-pagination", "Search API",
  "API version", "Clover", "Basil", "Acacia", "StripeClient", "DiscriminatedEvent",
  "dj-stripe", "Pay gem", "stripe_event", "PCI", "SAQ A", "CSP", "restricted key",
  "Sigma", "Payment Links", "SetupIntent", "off-session", "setup_future_usage",
  "customer portal", "credit grant", "Stripe Orchestration", "Smart Disputes",
  "Smart Refunds", "Authorization Boost", "Optimized Checkout Suite".
  Even if the user just asks "add payments", "set up billing", "charge a card",
  "create a subscription page", "handle webhooks", "connect marketplace",
  "usage-based pricing", or "accept Apple Pay", use this skill.
---

# Stripe API & SDK — State of the Art (February 2026)

## Quick Orientation

The Stripe API is at version **`2026-01-28.clover`** with biannual major releases
(Acacia → Basil → Clover) plus monthly backward-compatible updates. Base URL:
`https://api.stripe.com/v1/`. All monetary amounts are in **smallest currency unit**
(cents for USD/EUR — $20.00 = `2000`). API keys come in three types: **publishable**
(`pk_*` — client-safe), **secret** (`sk_*` — server only), and **restricted** (scoped
permissions). Object ID prefixes identify types: `pi_` (PaymentIntent), `sub_`
(Subscription), `cus_` (Customer), `pm_` (PaymentMethod), `cs_` (Checkout Session),
`acct_` (Connected Account), `in_` (Invoice), `price_` (Price), `prod_` (Product),
`ch_` (Charge), `re_` (Refund), `evt_` (Event), `whsec_` (Webhook Secret).

**All official SDKs** (Feb 2026):

| SDK | Latest Stable | API Version | Min Runtime |
|-----|--------------|-------------|-------------|
| stripe (Node.js/TS) | v20.3.1 | 2026-01-28.clover | Node 14+ |
| stripe (Python) | v14.3.0 | 2026-01-28.clover | Python 3.8+ |
| stripe (Ruby) | v18.3.0 | 2026-01-28.clover | Ruby 3.0+ |
| @stripe/stripe-js | v8.8.0 | — | Any browser |
| @stripe/react-stripe-js | latest | — | React ≥16.8 |

Stripe processes **$1.9T annually** (2025), serves 5M+ businesses, and maintains
**99.999% API uptime** (26 seconds downtime/month).

**For deeper topics, read the appropriate reference file before writing code:**

| Topic | Reference File | When to Read |
|-------|---------------|--------------|
| PaymentIntents, Checkout, Payment Methods, 3DS, Disputes, Radar, Refunds, Idempotency | `references/payments-and-checkout.md` | Creating payments, handling declines, managing disputes |
| Subscriptions, Products/Prices, Meters API, Invoices, Customer Portal, Trials, Dunning | `references/subscriptions-and-billing.md` | Any recurring billing, usage-based pricing, invoice management |
| Connect accounts, Onboarding, Charge types, Transfers, Payouts, Embedded Components | `references/stripe-connect.md` | Building marketplaces, platforms, or multi-party payments |
| Payment Element, Appearance API, Express Checkout, Address Element, React Stripe.js, Link | `references/elements-and-frontend.md` | Building payment UIs, customizing Elements, frontend integration |
| Webhook events, Signature verification, Framework handlers (10+), Event Destinations, Testing | `references/webhooks.md` | Setting up webhooks, verifying signatures, handling events |
| Node.js/TS, Express, Next.js App Router, Python/Django/FastAPI, Ruby/Rails, Serverless | `references/framework-integration.md` | Framework-specific integration patterns and code |
| Error types, Decline codes (~30), Rate limits, Retry patterns, Circuit breaker | `references/error-handling-and-rate-limits.md` | Handling errors, implementing retries, understanding limits |
| Test cards, Test Clocks, Stripe CLI, stripe-mock, Sandboxes, Workbench, MCP Server | `references/testing-and-tooling.md` | Testing, development workflow, CI/CD integration |
| ACP Protocol, Stripe Agent Toolkit, MCP Server, VS Code AI, Radar/Dashboard AI, LLMs.txt | `references/agentic-commerce-and-ai.md` | AI agent integration, agentic commerce, developer AI tools |
| PCI compliance, API key management, Webhook security, CSP, Metadata, Expanding, Pagination | `references/security-and-pci.md` | Security hardening, compliance, API optimization patterns |
| API versioning (Acacia/Basil/Clover), Breaking changes, Sources migration, Deprecations | `references/migration-and-versioning.md` | Upgrading API versions, migrating from deprecated APIs |
| Stripe Tax, Adaptive Pricing, Revenue Recovery, Stablecoin accounts, Terminal, Organizations | `references/stripe-tax-and-revenue.md` | Tax automation, pricing optimization, in-person payments |

## Node.js / TypeScript Quick Start

```bash
npm install stripe            # v20.3.1
npm install @stripe/stripe-js # v8.8.0 (frontend)
```

```typescript
import Stripe from 'stripe';

// Singleton — reuse across requests and warm invocations
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  maxNetworkRetries: 2,
  timeout: 30000,
});

// --- Create a PaymentIntent ---
const paymentIntent = await stripe.paymentIntents.create({
  amount: 2000,                              // $20.00 in cents
  currency: 'usd',
  customer: 'cus_abc123',
  payment_method: 'pm_card_visa',
  confirm: true,
  automatic_payment_methods: { enabled: true },
  metadata: { order_id: '6735' },
}, {
  idempotencyKey: 'order_6735_payment',
});

// --- Create a Checkout Session ---
const session = await stripe.checkout.sessions.create({
  mode: 'payment',
  line_items: [{
    price_data: {
      currency: 'usd',
      product_data: { name: 'T-shirt' },
      unit_amount: 2000,
    },
    quantity: 1,
  }],
  success_url: 'https://example.com/success?session_id={CHECKOUT_SESSION_ID}',
  cancel_url: 'https://example.com/cancel',
});

// --- Create a Subscription ---
const subscription = await stripe.subscriptions.create({
  customer: 'cus_xxx',
  items: [{ price: 'price_xxx' }],
  payment_behavior: 'default_incomplete',
  payment_settings: { save_default_payment_method: 'on_subscription' },
  expand: ['latest_invoice.payment_intent'],
});

// --- Error Handling ---
try {
  await stripe.paymentIntents.create({ amount: 2000, currency: 'usd' });
} catch (err) {
  if (err instanceof Stripe.errors.StripeError) {
    switch (err.type) {
      case 'StripeCardError':
        console.error(`Card declined: ${err.decline_code}`);
        break;
      case 'StripeRateLimitError':
        // Retry with exponential backoff
        break;
      case 'StripeInvalidRequestError':
        console.error(`Invalid request: ${err.message}`);
        break;
    }
    console.error(`Request ID: ${err.requestId}`);
  }
}

// --- Auto-pagination ---
for await (const customer of stripe.customers.list({ limit: 100 })) {
  console.log(customer.email);
}
```

## Python Quick Start

```bash
pip install stripe  # v14.3.0
```

```python
from stripe import StripeClient

# Modern StripeClient pattern (recommended)
client = StripeClient("sk_test_...")

# Create PaymentIntent
pi = client.v1.payment_intents.create(
    params={"amount": 2000, "currency": "usd", "confirm": True,
            "payment_method": "pm_card_visa",
            "automatic_payment_methods": {"enabled": True}}
)

# Async support (pip install stripe[async])
customer = await client.v1.customers.retrieve_async("cus_xyz")

# Auto-pagination
async for c in await stripe.Customer.list_async().auto_paging_iter():
    print(c.email)

# Error handling
import stripe
try:
    stripe.PaymentIntent.create(amount=1000, currency="usd")
except stripe.error.CardError as e:
    print(f"Code: {e.code}, Message: {e.user_message}")
except stripe.error.RateLimitError:
    pass  # Retry with backoff
except stripe.error.InvalidRequestError as e:
    print(f"Invalid: {e}")
```

## Essential Patterns Quick Reference

### PaymentIntent Lifecycle

```
requires_payment_method → requires_confirmation → requires_action → processing → requires_capture → succeeded
                                                                                                    ↘ canceled
On decline: reverts to requires_payment_method
```

### Subscription Status Flow

```
incomplete → (payment succeeds) → trialing / active
incomplete → (23h timeout) → incomplete_expired [terminal]

trialing → (trial ends) → active
active → (payment fails) → past_due → (retries exhausted) → canceled / unpaid
active → cancel_at_period_end → canceled [terminal — CANNOT reactivate]
active → pause_collection → paused → resume → active
```

### Connect Charge Type Decision Tree

```
Q: Does connected account own the customer relationship?
├── YES → Direct Charges (Stripe-Account header)
│         Best for: SaaS (Shopify-like)
└── NO → Q: Single seller per transaction?
         ├── YES → Destination Charges (transfer_data.destination)
         │         Best for: Marketplaces (Airbnb)
         └── NO → Separate Charges & Transfers (transfer_group)
                   Best for: Complex multi-party splits (DoorDash)
```

### Webhook Verification (Compact)

```typescript
// CRITICAL: Always use raw body, never parsed JSON
// Express: express.raw() BEFORE express.json()
// Next.js App Router: await req.text() NOT req.json()
// FastAPI: await request.body()
// Django: request.body NOT request.data
// Rails: request.body.read

const event = stripe.webhooks.constructEvent(rawBody, sig, secret);
// Return 200 immediately, process async
// Track event.id for idempotency
// Stripe retries for 3 days with exponential backoff
```

## Critical Gotchas

1. **Raw body for webhook verification** → Using parsed JSON causes signature mismatch. In Express, the webhook route with `express.raw()` MUST come BEFORE `express.json()` middleware. This is the #1 source of webhook bugs.

2. **Amounts in smallest currency unit** → `amount: 2000` = $20.00, NOT $2,000.00. Always multiply display amounts by 100 for USD/EUR. Never send floating-point amounts.

3. **Zero-decimal currencies** → JPY, KRW, BIF, CLP, DJF, GNF, KMF, MGA, PYG, RWF, UGX, VND, VUV, XAF, XOF, XPF use amounts directly (¥1000 = `amount: 1000`). HUF/TWD: two-decimal for charges, zero-decimal for payouts.

4. **Canceled subscriptions cannot be reactivated** → Once `status: 'canceled'`, you must create a new subscription. Use `cancel_at_period_end: true` for scheduled cancellation (reversible with `cancel_at_period_end: false`).

5. **Prices are immutable** → Cannot change amount, currency, or interval on an existing Price. Create a new Price and use `lookup_key` with `transfer_lookup_key: true` for zero-downtime price migration.

6. **Account Link URLs are single-use and expire** → Never email or store them. Generate fresh on each access. After linking a Standard account, KYC data becomes read-only — prefill BEFORE creating the link.

7. **Fulfill orders via webhook, never redirect** → The `success_url` redirect can fail (browser closes, network drops). Always use `checkout.session.completed` webhook as the source of truth for fulfillment.

8. **Cannot change Connect account type after creation** → The charge type (direct/destination/separate) is the hardest-to-reverse architectural decision. Plan carefully before implementation.

9. **loadStripe() outside component render** → Call `loadStripe('pk_...')` at module level or in a constant, never inside a React component body. Re-calling creates multiple Stripe.js instances and causes memory leaks.

10. **Idempotency keys retained only 24 hours** → Keys expire after 24h. For longer retry windows, implement your own deduplication. Parameter mismatches on same key return errors. Rate-limited (429) responses are NOT cached — safe to retry with same key.

11. **Webhook route BEFORE express.json() in Express** → Express middleware order matters. If `express.json()` parses the body first, the raw body is gone and webhook verification fails. Place webhook route first or use a path-specific middleware.

12. **Do NOT use Edge Runtime for Stripe server-side** → Stripe SDK requires Node.js runtime for crypto operations. In Next.js, keep Stripe API calls in `runtime: 'nodejs'` routes and Server Actions.

13. **invoice.created webhook failure delays finalization 72h** → Stripe waits ~1 hour after successful webhook, but delays up to 72 hours if the webhook endpoint fails. Ensure your webhook endpoint is reliable.

14. **Never reveal lost_card/stolen_card/fraudulent to the user** → These decline codes indicate potential fraud. Show a generic "Card declined" message. Log the actual code server-side for investigation.

## Cross-Skill Integration

### convex-skill
Stripe operations MUST run in Convex **actions** (not queries or mutations) because they make
external HTTP calls. Store Stripe customer IDs and subscription status in Convex tables.
Use webhooks to sync Stripe state back to Convex via HTTP actions.

```typescript
// convex/stripe.ts — Convex action
"use node";
import { action } from "./_generated/server";
import Stripe from "stripe";

export const createCheckoutSession = action({
  args: { priceId: v.string() },
  handler: async (ctx, args) => {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: args.priceId, quantity: 1 }],
      success_url: `${process.env.APP_URL}/success`,
    });
    return session.url;
  },
});
```

### nextjs-web
Use Server Actions for creating Checkout Sessions and PaymentIntents. Webhook handler
in `app/api/webhooks/stripe/route.ts` with `req.text()` for raw body. Pricing page can
use Server Components with cached `stripe.prices.list()`. Do NOT use Edge Runtime.

### supabase-skill
Stripe webhooks can target Supabase Edge Functions. Use `Deno.serve()` with
`request.text()` for raw body verification. Store subscription state in Supabase
tables with RLS policies.

## Next Steps

Read the reference files based on your task:
- **Accepting payments?** → `references/payments-and-checkout.md`
- **Building subscriptions or billing?** → `references/subscriptions-and-billing.md`
- **Building a marketplace or platform?** → `references/stripe-connect.md`
- **Building payment UI with Elements?** → `references/elements-and-frontend.md`
- **Setting up webhooks?** → `references/webhooks.md`
- **Integrating with a specific framework?** → `references/framework-integration.md`
- **Handling errors or rate limits?** → `references/error-handling-and-rate-limits.md`
- **Testing or setting up dev tools?** → `references/testing-and-tooling.md`
- **Building AI agent integrations?** → `references/agentic-commerce-and-ai.md`
- **Security, PCI, or API optimization?** → `references/security-and-pci.md`
- **Migrating or upgrading API versions?** → `references/migration-and-versioning.md`
- **Tax, pricing, revenue, or in-person payments?** → `references/stripe-tax-and-revenue.md`
