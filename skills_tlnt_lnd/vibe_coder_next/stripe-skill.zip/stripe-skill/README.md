# stripe-skill — Skill de Claude Code

Skill instalable para **Claude Code**: integración completa con **Stripe** — código y
decisiones de arquitectura de pagos. Cubre PaymentIntents, Checkout Sessions,
suscripciones y facturación, Stripe Elements / Payment Element en React/Next.js/Vue,
Connect (plataformas y marketplaces), webhooks (verificación de firma, raw body),
Stripe Tax y Revenue Recovery, seguridad y PCI, manejo de errores y rate limits,
testing y el nuevo comercio agéntico con IA. Autocontenida.

## Cómo instalar

1. Descomprime este ZIP. Obtendrás una carpeta `stripe-skill/`.
2. Cópiala a tu directorio de skills de Claude Code:
   - **Personal:** `~/.claude/skills/stripe-skill/`
   - **Solo un proyecto:** `<tu-proyecto>/.claude/skills/stripe-skill/`
3. Reinicia Claude Code. Se activará sola al trabajar con Stripe.

## Requisitos
- Una cuenta de Stripe y tus claves API (test/live). Nunca las pongas en el repo: usa variables de entorno.

## Contenido
- `SKILL.md` — guía principal (cuándo y cómo usar cada API).
- `references/` — payments-and-checkout, subscriptions-and-billing, stripe-connect,
  webhooks, elements-and-frontend, framework-integration, stripe-tax-and-revenue,
  security-and-pci, error-handling-and-rate-limits, migration-and-versioning,
  agentic-commerce-and-ai, testing-and-tooling.
- `scripts/stripe_helper.ts` — helper de ejemplos.

Cortesía de **Talent Academy · Vibe Coder**.
