#!/usr/bin/env npx tsx
/**
 * Supabase Helper Script — Reusable utilities for common Supabase patterns.
 *
 * Usage as module:
 *   Copy the functions you need into your project's lib/supabase/ directory.
 *   These are reference implementations, not an installable package.
 *
 * Usage as CLI:
 *   npx tsx supabase_helper.ts --action validate-env
 *   npx tsx supabase_helper.ts --action generate-migration --table posts --columns 'id:uuid:pk,user_id:uuid:ref:auth.users(id),title:text,created_at:timestamptz:default:now()'
 *   npx tsx supabase_helper.ts --action test-edge-function --function my-function --method POST --body '{"name":"test"}'
 */

import { createClient, type SupabaseClient } from "@supabase/supabase-js";

// ============================================================================
// §1 Typed Client Factory
// ============================================================================

/**
 * Creates a typed Supabase client with Database generics.
 * Use after generating types with `supabase gen types typescript`.
 *
 * @example
 * ```typescript
 * import type { Database } from './database.types';
 * const supabase = createTypedClient<Database>();
 * const { data } = await supabase.from('posts').select('*'); // fully typed
 * ```
 */
export function createTypedClient<T extends Record<string, any>>(options?: {
  url?: string;
  key?: string;
  serviceRole?: boolean;
}): SupabaseClient<T> {
  const url = options?.url ?? process.env.SUPABASE_URL ?? process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = options?.serviceRole
    ? (options?.key ?? process.env.SUPABASE_SERVICE_ROLE_KEY)
    : (options?.key ?? process.env.SUPABASE_ANON_KEY ?? process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY);

  if (!url || !key) {
    throw new Error(
      "Missing SUPABASE_URL or SUPABASE_ANON_KEY. " +
        "Set them in .env.local or pass explicitly.",
    );
  }

  return createClient<T>(url, key);
}

// ============================================================================
// §2 RLS Testing Helper
// ============================================================================

/**
 * Creates a client impersonating a specific user for RLS policy testing.
 * Uses the service_role key to set custom JWT claims.
 *
 * @example
 * ```typescript
 * const userClient = withRLS(serviceClient, 'user-uuid-123');
 * const { data } = await userClient.from('posts').select('*');
 * // Returns only rows visible to that user per RLS policies
 * ```
 */
export function withRLS<T extends Record<string, any>>(
  url: string,
  anonKey: string,
  accessToken: string,
): SupabaseClient<T> {
  return createClient<T>(url, anonKey, {
    global: {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    },
  });
}

// ============================================================================
// §3 Batch Upsert
// ============================================================================

/**
 * Upserts a large array of rows in chunks to respect Supabase payload limits.
 * Default chunk size of 500 keeps requests under ~1MB for typical rows.
 *
 * @example
 * ```typescript
 * await batchUpsert(supabase, 'products', products, {
 *   chunkSize: 500,
 *   onConflict: 'sku',
 * });
 * ```
 */
export async function batchUpsert<T extends Record<string, any>>(
  client: SupabaseClient,
  table: string,
  rows: T[],
  options: {
    chunkSize?: number;
    onConflict?: string;
    ignoreDuplicates?: boolean;
  } = {},
): Promise<{ inserted: number; errors: string[] }> {
  const { chunkSize = 500, onConflict, ignoreDuplicates = false } = options;
  let inserted = 0;
  const errors: string[] = [];

  for (let i = 0; i < rows.length; i += chunkSize) {
    const chunk = rows.slice(i, i + chunkSize);
    const query = client.from(table).upsert(chunk, {
      onConflict,
      ignoreDuplicates,
    });

    const { error, count } = await query;

    if (error) {
      errors.push(`Chunk ${Math.floor(i / chunkSize)}: ${error.message}`);
    } else {
      inserted += count ?? chunk.length;
    }
  }

  return { inserted, errors };
}

// ============================================================================
// §4 Migration Template Generator
// ============================================================================

/**
 * Generates a SQL migration string with RLS enabled by default.
 * Outputs a complete migration file content ready to save.
 *
 * @example
 * ```typescript
 * const sql = generateMigration('posts', [
 *   { name: 'id', type: 'uuid', default: 'gen_random_uuid()' },
 *   { name: 'user_id', type: 'uuid', references: 'auth.users(id)' },
 *   { name: 'title', type: 'text' },
 *   { name: 'created_at', type: 'timestamptz', default: 'now()' },
 * ]);
 * ```
 */
interface ColumnDef {
  name: string;
  type: string;
  primaryKey?: boolean;
  nullable?: boolean;
  default?: string;
  references?: string;
  unique?: boolean;
}

export function generateMigration(
  tableName: string,
  columns: ColumnDef[],
  options?: { ownerPolicy?: boolean },
): string {
  const colDefs = columns.map((col) => {
    let def = `  ${col.name} ${col.type}`;
    if (col.primaryKey) def += " PRIMARY KEY";
    if (!col.nullable && !col.primaryKey) def += " NOT NULL";
    if (col.default) def += ` DEFAULT ${col.default}`;
    if (col.unique) def += " UNIQUE";
    if (col.references) def += ` REFERENCES ${col.references} ON DELETE CASCADE`;
    return def;
  });

  const userIdCol = columns.find((c) => c.name === "user_id");
  const ownerPolicy =
    options?.ownerPolicy !== false && userIdCol
      ? `
-- RLS Policies
CREATE POLICY "${tableName}_select_own" ON public.${tableName}
  FOR SELECT TO authenticated
  USING ((SELECT auth.uid()) = user_id);

CREATE POLICY "${tableName}_insert_own" ON public.${tableName}
  FOR INSERT TO authenticated
  WITH CHECK ((SELECT auth.uid()) = user_id);

CREATE POLICY "${tableName}_update_own" ON public.${tableName}
  FOR UPDATE TO authenticated
  USING ((SELECT auth.uid()) = user_id)
  WITH CHECK ((SELECT auth.uid()) = user_id);

CREATE POLICY "${tableName}_delete_own" ON public.${tableName}
  FOR DELETE TO authenticated
  USING ((SELECT auth.uid()) = user_id);`
      : "";

  return `-- Migration: Create ${tableName} table
CREATE TABLE IF NOT EXISTS public.${tableName} (
${colDefs.join(",\n")}
);

-- ALWAYS enable RLS immediately after CREATE TABLE
ALTER TABLE public.${tableName} ENABLE ROW LEVEL SECURITY;
${ownerPolicy}

-- Indexes (add columns used in WHERE clauses and RLS policies)
${userIdCol ? `CREATE INDEX IF NOT EXISTS idx_${tableName}_user_id ON public.${tableName} (user_id);` : `-- CREATE INDEX IF NOT EXISTS idx_${tableName}_<column> ON public.${tableName} (<column>);`}
`;
}

// ============================================================================
// §5 Environment Variable Validation
// ============================================================================

/**
 * Validates that all required Supabase environment variables are set.
 * Call at application startup or in server-side code.
 *
 * @example
 * ```typescript
 * const env = validateEnv(); // throws if missing
 * console.log(env.SUPABASE_URL);
 * ```
 */
export function validateEnv(extra?: string[]): Record<string, string> {
  const required = [
    "SUPABASE_URL",
    "SUPABASE_ANON_KEY",
    ...(extra ?? []),
  ];

  // Also check NEXT_PUBLIC_ variants
  const aliases: Record<string, string[]> = {
    SUPABASE_URL: ["NEXT_PUBLIC_SUPABASE_URL"],
    SUPABASE_ANON_KEY: ["NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY", "NEXT_PUBLIC_SUPABASE_ANON_KEY"],
  };

  const result: Record<string, string> = {};
  const missing: string[] = [];

  for (const key of required) {
    const value = process.env[key];
    if (value) {
      result[key] = value;
      continue;
    }

    const alt = aliases[key]?.find((k) => process.env[k]);
    if (alt) {
      result[key] = process.env[alt]!;
      continue;
    }

    missing.push(key);
  }

  if (missing.length > 0) {
    throw new Error(
      `Missing required environment variables: ${missing.join(", ")}. ` +
        "Set them in .env.local or your deployment environment.",
    );
  }

  return result;
}

// ============================================================================
// §6 Edge Function Test Helper
// ============================================================================

/**
 * Invokes a Supabase Edge Function with proper auth headers for testing.
 *
 * @example
 * ```typescript
 * const result = await testEdgeFunction('my-function', {
 *   method: 'POST',
 *   body: { name: 'test' },
 *   accessToken: 'eyJ...',  // user JWT
 * });
 * console.log(result.status, result.data);
 * ```
 */
export async function testEdgeFunction(
  functionName: string,
  options: {
    method?: string;
    body?: unknown;
    accessToken?: string;
    supabaseUrl?: string;
    anonKey?: string;
  } = {},
): Promise<{ status: number; data: unknown; headers: Record<string, string> }> {
  const supabaseUrl = options.supabaseUrl ?? process.env.SUPABASE_URL ?? process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = options.anonKey ?? process.env.SUPABASE_ANON_KEY ?? process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

  if (!supabaseUrl || !anonKey) {
    throw new Error("Missing SUPABASE_URL or SUPABASE_ANON_KEY for Edge Function test.");
  }

  const url = `${supabaseUrl}/functions/v1/${functionName}`;
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    apikey: anonKey,
  };

  if (options.accessToken) {
    headers["Authorization"] = `Bearer ${options.accessToken}`;
  }

  const response = await fetch(url, {
    method: options.method ?? "POST",
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  const responseHeaders: Record<string, string> = {};
  response.headers.forEach((value, key) => {
    responseHeaders[key] = value;
  });

  const data = await response.json().catch(() => response.text());

  return {
    status: response.status,
    data,
    headers: responseHeaders,
  };
}

// ============================================================================
// §7 Circuit Breaker Pattern
// ============================================================================

/** Circuit breaker states. */
enum CircuitBreakerState {
  CLOSED = 'closed',       // Normal: calls pass through
  OPEN = 'open',           // Failing: calls rejected
  HALF_OPEN = 'half_open', // Testing recovery
}

interface CircuitBreakerOptions {
  failureThreshold: number;
  resetTimeoutMs: number;
  halfOpenMax: number;
}

interface CircuitBreakerStats {
  state: CircuitBreakerState;
  failureCount: number;
  successCount: number;
  halfOpenCalls: number;
  lastFailureTime: number;
  timeUntilRecoveryMs: number;
}

/** Thrown when the circuit breaker is open and rejecting calls. */
class CircuitBreakerOpenError extends Error {
  public readonly state: CircuitBreakerState;
  public readonly failureCount: number;
  public readonly timeUntilRecoveryMs: number;

  constructor(message: string, state: CircuitBreakerState, failureCount: number, timeUntilRecoveryMs: number) {
    super(message);
    this.name = 'CircuitBreakerOpenError';
    this.state = state;
    this.failureCount = failureCount;
    this.timeUntilRecoveryMs = timeUntilRecoveryMs;
  }
}

/**
 * Circuit Breaker implementation to protect against cascading failures
 * when calling external services from Supabase Edge Functions or server code.
 *
 * Flow: CLOSED -> (failures >= threshold) -> OPEN -> (timeout) -> HALF_OPEN -> (success) -> CLOSED
 *                                                                             -> (failure) -> OPEN
 *
 * @example
 * ```typescript
 * const cb = new CircuitBreaker({ failureThreshold: 5, resetTimeoutMs: 30000, halfOpenMax: 3 });
 * const result = await cb.execute(() => fetch('https://api.example.com/data'));
 * ```
 */
class CircuitBreaker {
  private state: CircuitBreakerState = CircuitBreakerState.CLOSED;
  private failureCount = 0;
  private successCount = 0;
  private halfOpenCalls = 0;
  private lastFailureTime = 0;
  private lastStateChange: number = Date.now();

  private readonly failureThreshold: number;
  private readonly resetTimeoutMs: number;
  private readonly halfOpenMax: number;

  constructor(options: CircuitBreakerOptions = { failureThreshold: 5, resetTimeoutMs: 30000, halfOpenMax: 3 }) {
    this.failureThreshold = options.failureThreshold;
    this.resetTimeoutMs = options.resetTimeoutMs;
    this.halfOpenMax = options.halfOpenMax;
  }

  /** Execute a function through the circuit breaker. */
  async execute<T>(fn: () => Promise<T>): Promise<T> {
    const currentState = this.getCurrentState();

    if (currentState === CircuitBreakerState.OPEN) {
      const remaining = this.timeUntilRecovery();
      throw new CircuitBreakerOpenError(
        `Circuit breaker OPEN. ${this.failureCount} consecutive failures. ` +
        `Retry in ${Math.ceil(remaining / 1000)}s`,
        currentState,
        this.failureCount,
        remaining,
      );
    }

    if (currentState === CircuitBreakerState.HALF_OPEN) {
      if (this.halfOpenCalls >= this.halfOpenMax) {
        this.transitionToOpen();
        throw new CircuitBreakerOpenError(
          `Circuit breaker re-opened: half-open call limit reached`,
          CircuitBreakerState.OPEN,
          this.failureCount,
          this.resetTimeoutMs,
        );
      }
      this.halfOpenCalls++;
    }

    try {
      const result = await fn();
      this.recordSuccess();
      return result;
    } catch (error) {
      this.recordFailure();
      throw error;
    }
  }

  private recordSuccess(): void {
    this.failureCount = 0;
    this.successCount++;
    if (this.state === CircuitBreakerState.HALF_OPEN) {
      if (this.successCount >= this.halfOpenMax) {
        this.transitionToClosed();
      }
    }
  }

  private recordFailure(): void {
    this.failureCount++;
    this.successCount = 0;
    this.lastFailureTime = Date.now();
    if (this.failureCount >= this.failureThreshold) {
      this.transitionToOpen();
    }
    if (this.state === CircuitBreakerState.HALF_OPEN) {
      this.transitionToOpen();
    }
  }

  private getCurrentState(): CircuitBreakerState {
    if (this.state === CircuitBreakerState.OPEN) {
      if (Date.now() - this.lastFailureTime >= this.resetTimeoutMs) {
        this.state = CircuitBreakerState.HALF_OPEN;
        this.halfOpenCalls = 0;
        this.successCount = 0;
        this.lastStateChange = Date.now();
      }
    }
    return this.state;
  }

  private transitionToOpen(): void {
    this.state = CircuitBreakerState.OPEN;
    this.lastStateChange = Date.now();
  }

  private transitionToClosed(): void {
    this.state = CircuitBreakerState.CLOSED;
    this.failureCount = 0;
    this.halfOpenCalls = 0;
    this.lastStateChange = Date.now();
  }

  private timeUntilRecovery(): number {
    if (this.state !== CircuitBreakerState.OPEN) return 0;
    const elapsed = Date.now() - this.lastFailureTime;
    return Math.max(0, this.resetTimeoutMs - elapsed);
  }

  getStats(): CircuitBreakerStats {
    return {
      state: this.getCurrentState(),
      failureCount: this.failureCount,
      successCount: this.successCount,
      halfOpenCalls: this.halfOpenCalls,
      lastFailureTime: this.lastFailureTime,
      timeUntilRecoveryMs: this.timeUntilRecovery(),
    };
  }
}


// ============================================================================
// §8 CLI Interface
// ============================================================================

/** Minimal argument parser -- no external dependencies. */
function parseArgs(argv: string[]): Record<string, string> {
  const parsed: Record<string, string> = {};
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg.startsWith('--')) {
      const key = arg.slice(2);
      const nextArg = argv[i + 1];
      if (nextArg !== undefined && !nextArg.startsWith('--')) {
        parsed[key] = nextArg;
        i++;
      } else {
        parsed[key] = 'true';
      }
    }
  }
  return parsed;
}

function printResult(data: unknown, format: 'json' | 'table' = 'json'): void {
  if (format === 'table' && typeof data === 'object' && data !== null) {
    if (Array.isArray(data)) {
      console.table(data);
    } else {
      const flat: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(data as Record<string, unknown>)) {
        flat[k] = typeof v === 'object' ? JSON.stringify(v) : v;
      }
      console.table(flat);
    }
  } else {
    console.log(JSON.stringify(data, null, 2));
  }
}

function printHelp(): void {
  const help = `
supabase_helper.ts -- Supabase utilities with circuit breaker and retry logic.

Usage:
  npx tsx supabase_helper.ts --action <action> [options]

Actions:
  validate-env             Validate required Supabase env vars
                           [--extra <comma-separated extra keys>]

  generate-migration       Generate a SQL migration with RLS
                           --table <name> --columns <col_specs>
                           Column spec format: name:type[:pk][:ref:target][:default:value][:unique][:nullable]
                           Example: --columns 'id:uuid:pk,user_id:uuid:ref:auth.users(id),title:text,created_at:timestamptz:default:now()'

  test-edge-function       Invoke a Supabase Edge Function
                           --function <name> [--method <POST>] [--body <json>] [--token <jwt>]

  diagnostics              Show circuit breaker stats

Global Options:
  --format <json|table>    Output format (default: json)
`.trim();
  console.log(help);
}

/** Parse a column spec string into ColumnDef objects. */
function parseColumnSpecs(spec: string): ColumnDef[] {
  return spec.split(',').map((col) => {
    const parts = col.trim().split(':');
    const def: ColumnDef = { name: parts[0], type: parts[1] || 'text' };
    for (let i = 2; i < parts.length; i++) {
      const flag = parts[i];
      if (flag === 'pk') def.primaryKey = true;
      else if (flag === 'unique') def.unique = true;
      else if (flag === 'nullable') def.nullable = true;
      else if (flag === 'ref' && parts[i + 1]) { def.references = parts[++i]; }
      else if (flag === 'default' && parts[i + 1]) { def.default = parts[++i]; }
    }
    return def;
  });
}

async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));

  if (!args.action) {
    printHelp();
    process.exit(0);
  }

  const format = (args.format as 'json' | 'table') || 'json';

  try {
    let result: unknown;

    switch (args.action) {
      case 'validate-env': {
        const extra = args.extra ? args.extra.split(',').filter(Boolean) : undefined;
        result = validateEnv(extra);
        break;
      }

      case 'generate-migration': {
        const table = args.table;
        const columnsSpec = args.columns;
        if (!table || !columnsSpec) {
          process.stderr.write('Error: --table and --columns required\n');
          process.exit(1);
        }
        const columns = parseColumnSpecs(columnsSpec);
        const sql = generateMigration(table, columns);
        // Output SQL directly, not as JSON
        process.stdout.write(sql + '\n');
        return;
      }

      case 'test-edge-function': {
        const functionName = args['function'];
        if (!functionName) {
          process.stderr.write('Error: --function required\n');
          process.exit(1);
        }
        let body: unknown = undefined;
        if (args.body) {
          try {
            body = JSON.parse(args.body);
          } catch {
            process.stderr.write('Error: --body must be valid JSON\n');
            process.exit(1);
          }
        }
        result = await testEdgeFunction(functionName, {
          method: args.method,
          body,
          accessToken: args.token,
        });
        break;
      }

      case 'diagnostics': {
        const cb = new CircuitBreaker();
        result = { circuitBreaker: cb.getStats() };
        break;
      }

      default:
        process.stderr.write(`Unknown action: ${args.action}\n`);
        process.stderr.write(`Run without --action to see help.\n`);
        process.exit(1);
    }

    printResult(result, format);
  } catch (err) {
    if (err instanceof CircuitBreakerOpenError) {
      process.stderr.write(JSON.stringify({
        error: true,
        type: 'CircuitBreakerOpen',
        message: err.message,
        state: err.state,
        failureCount: err.failureCount,
        timeUntilRecoveryMs: err.timeUntilRecoveryMs,
      }, null, 2) + '\n');
    } else {
      process.stderr.write(String(err) + '\n');
    }
    process.exit(1);
  }
}


// ============================================================================
// Exports
// ============================================================================

export {
  CircuitBreaker,
  CircuitBreakerOpenError,
  CircuitBreakerState,
};

export type { CircuitBreakerOptions, CircuitBreakerStats };

// Run CLI if invoked directly
if (
  typeof process !== 'undefined' &&
  process.argv[1] &&
  (process.argv[1].endsWith('supabase_helper.ts') || process.argv[1].endsWith('supabase_helper'))
) {
  main().catch((err) => {
    process.stderr.write(`Fatal: ${err}\n`);
    process.exit(1);
  });
}
