# supabase-skill — Skill de Claude Code

Skill instalable para **Claude Code**: dominio completo de Supabase — Auth (GoTrue),
Base de datos (PostgREST), RLS, Storage, Edge Functions (Deno), Realtime, Vector/AI
(pgvector), Cron (pg_cron) y Queues (pgmq). Autocontenida: sirve para cualquier
proyecto que use Supabase (web, React Native/Expo, Kotlin, Swift).

## Cómo instalar

1. Descomprime este ZIP. Obtendrás una carpeta `supabase-skill/`.
2. Cópiala a tu directorio de skills de Claude Code:
   - **Personal (todos tus proyectos):** `~/.claude/skills/supabase-skill/`
   - **Solo un proyecto:** `<tu-proyecto>/.claude/skills/supabase-skill/`
3. Reinicia Claude Code. Se activará sola al trabajar con Supabase, o invócala por su nombre.

## Contenido

- `SKILL.md` — guía principal.
- `references/` — auth, database, RLS, storage/functions, realtime/queues, ai/vectors, cli/ops, deployment/security, platform-integrations.
- `scripts/` — helper de operaciones.

Cortesía de **Talent Academy · Vibe Coder**.
