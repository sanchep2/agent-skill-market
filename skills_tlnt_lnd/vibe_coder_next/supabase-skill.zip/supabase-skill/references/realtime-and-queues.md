# Realtime & Queues

> Supabase Realtime (Broadcast, Presence, Postgres Changes) + background processing with pg_cron and Supabase Queues (pgmq).

## Table of Contents

1. [Realtime](#realtime)
2. [Cron & Queues](#cron--queues)

---

## Realtime

Supabase Realtime multiplexes three primitives over a single WebSocket connection per client. All three can coexist on the same channel.

### Broadcast

Low-latency ephemeral messaging between connected clients. No persistence by default.

**Three delivery paths:**

| Path | When to use |
|------|-------------|
| **WebSocket** (client libraries) | Client-to-client via `channel.send()` |
| **REST API** | Server-to-clients (`POST /realtime/v1/channels/{channel}/broadcast`) |
| **Database** (`realtime.send()`) | Trigger-based; fire broadcasts from SQL functions or triggers |

**Basic usage:**

```javascript
const channel = supabase.channel('room')

channel
  .on('broadcast', { event: 'cursor' }, (payload) => {
    console.log('Cursor moved:', payload)
  })
  .subscribe()

// Send from client
channel.send({
  type: 'broadcast',
  event: 'cursor',
  payload: { x: 100, y: 200 },
})
```

**Broadcast from database trigger (recommended for scale):**

The `realtime.broadcast_changes()` helper formats trigger-based broadcasts to look exactly like Postgres Changes payloads. This is the **recommended replacement** for direct Postgres Changes subscriptions at scale because each broadcast fans out via the Realtime multiplexer instead of running per-subscriber RLS checks.

```sql
CREATE OR REPLACE FUNCTION notify_message_insert()
RETURNS trigger AS $$
BEGIN
  PERFORM realtime.broadcast_changes(
    'db-changes',         -- channel topic
    TG_OP,                -- event type (INSERT/UPDATE/DELETE)
    TG_OP,                -- maps to event field
    TG_TABLE_NAME,
    TG_TABLE_SCHEMA,
    NEW,
    OLD
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER on_message_insert
  AFTER INSERT ON messages
  FOR EACH ROW EXECUTE FUNCTION notify_message_insert();
```

Clients subscribe identically to Postgres Changes — no client code changes needed.

**Broadcast Replay (public alpha):**

Private channels can replay earlier messages sent via the database broadcast path. Messages auto-deleted after 3 days.

```javascript
const channel = supabase.channel('chat-room', {
  config: {
    broadcast: {
      replay: { since: Date.now() - 60_000, limit: 25 }, // last 60s, max 25
    },
    private: true,
  },
})

channel
  .on('broadcast', { event: 'message' }, (payload) => {
    // Receives replayed messages first, then live messages
    console.log(payload)
  })
  .subscribe()
```

- Only works on **private** channels
- Only replays messages sent via **database broadcasts** (`realtime.send()`)
- Auto-deleted after **3 days**
- `limit` caps the number of replayed messages (default 25)

---

### Presence

CRDT-backed key-value store for tracking shared user state across a channel. New joiners receive the full current state immediately upon subscribing.

**Events:** `sync` (full state reconciliation), `join` (user entered), `leave` (user departed).

```javascript
const channel = supabase.channel('online-users')

channel
  .on('presence', { event: 'sync' }, () => {
    const state = channel.presenceState()
    console.log('Online:', Object.keys(state))
  })
  .on('presence', { event: 'join' }, ({ key, newPresences }) => {
    console.log('Joined:', key, newPresences)
  })
  .on('presence', { event: 'leave' }, ({ key, leftPresences }) => {
    console.log('Left:', key, leftPresences)
  })
  .subscribe(async (status) => {
    if (status === 'SUBSCRIBED') {
      await channel.track({
        user_id: userId,
        online_at: new Date().toISOString(),
      })
    }
  })
```

**Performance notes:**

- More expensive than Broadcast due to CRDT sync overhead
- Delta broadcast interval: **1500 ms** default (batches state deltas)
- State is held in-memory on the Realtime server — not persisted to disk
- Best for tens to low hundreds of users per channel, not thousands

---

### Postgres Changes

Listens to `INSERT`, `UPDATE`, `DELETE` events via WAL logical replication.

**Setup — add tables to publication:**

```sql
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
-- Or specific columns:
ALTER PUBLICATION supabase_realtime ADD TABLE messages (id, room_id, content, created_at);
```

**Subscribe with column-level filters:**

```javascript
const channel = supabase
  .channel('db-changes')
  .on(
    'postgres_changes',
    {
      event: 'INSERT',
      schema: 'public',
      table: 'messages',
      filter: 'room_id=eq.123',
    },
    (payload) => {
      console.log('New message:', payload.new)
    }
  )
  .subscribe()
```

**Supported filter operators:** `eq`, `neq`, `lt`, `lte`, `gt`, `gte`, `in`.

```javascript
// Multiple values with in
filter: 'status=in.(active,pending)'

// Numeric comparisons
filter: 'amount=gt.100'
```

**Scaling limitation (critical):**

Changes are processed on a **single thread**. Each change is checked against **each subscriber's RLS policies** individually. 100 subscribers = 100 policy evaluations ("reads") per single row change.

For high-scale use cases, **migrate to Broadcast from Database triggers** using `realtime.broadcast_changes()`. This shifts the fan-out to the Realtime multiplexer and eliminates per-subscriber RLS checks.

---

### Realtime Authorization

RLS policies on the `realtime.messages` table control access to Broadcast and Presence on private channels.

**Enable private channels:**

```javascript
const channel = supabase.channel('locked', {
  config: { private: true },
})
```

**RLS policy example — restrict to authenticated room members:**

```sql
CREATE POLICY "room members can use realtime"
  ON realtime.messages
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.room_members rm
      WHERE rm.user_id = (SELECT auth.uid())
        AND rm.room_id = (realtime.messages.extension ->> 'topic')::text
    )
  );
```

**Production recommendation:** Enable **Channel Restrictions** in Dashboard → Realtime → Settings to reject all non-private channel subscriptions. This prevents clients from creating unprotected public channels.

---

### Default Limits

| Resource | Default limit |
|----------|---------------|
| Max channels per client | 100 |
| Concurrent users per channel | 200 |
| Events per second (per client) | 100 |
| Bytes per second (per client) | 100,000 |
| Max message size | 1 MB |
| Channel join rate | 10/second |

Enterprise plans support custom limits. Contact Supabase for higher thresholds.

---

### When to Use Which Realtime Approach

| Use case | Approach | Why |
|----------|----------|-----|
| Chat cursors, typing indicators | **Broadcast** | Ephemeral, lowest latency, no persistence needed |
| Who's online / user status | **Presence** | CRDT state tracking, automatic join/leave detection |
| New row notifications (low scale, <50 subscribers) | **Postgres Changes** | Simple setup, direct from DB, no extra code |
| New row notifications (high scale, 50+ subscribers) | **Broadcast from DB trigger** | Scales horizontally, no per-subscriber RLS overhead |
| Message history needed (short-term) | **Broadcast Replay** | Stores for 3 days, private channels only |
| Multiplayer collaboration (positions, selections) | **Broadcast** | High frequency, ephemeral, low overhead |
| Form locking / resource claims | **Presence** | Track who holds what, auto-release on disconnect |

---

## Cron & Queues

### pg_cron

Postgres-native cron scheduler. Runs SQL statements on a schedule inside the database.

**Enable:**

```sql
CREATE EXTENSION IF NOT EXISTS pg_cron;
```

**Schedule jobs:**

```sql
-- Every minute: purge old events
SELECT cron.schedule(
  'cleanup',
  '* * * * *',
  $$DELETE FROM events WHERE event_time < now() - interval '1 week'$$
);

-- Every day at 3:00 AM UTC
SELECT cron.schedule(
  'daily-digest',
  '0 3 * * *',
  $$SELECT send_daily_digest()$$
);

-- Every 30 seconds (requires Postgres >= 15.1.1.61)
SELECT cron.schedule(
  'fast-poll',
  '30 seconds',
  $$SELECT process_queue()$$
);

-- Unschedule a job
SELECT cron.unschedule('cleanup');
```

**Dashboard UI:** Integrations → Cron → Create Job. Supports natural language input (e.g., "every 5 minutes") which converts to cron expression.

**Constraints:**

- Max **8 concurrent jobs** running at once
- Each job limited to **10 minutes** execution time
- Jobs run as `postgres` role by default
- Sub-minute scheduling (seconds) requires Postgres >= 15.1.1.61

**Monitoring:**

```sql
-- View all scheduled jobs
SELECT * FROM cron.job;

-- View run history (last 10 failures)
SELECT *
FROM cron.job_run_details
WHERE status = 'failed'
ORDER BY start_time DESC
LIMIT 10;

-- Clean up old run details
SELECT cron.schedule(
  'clean-cron-history',
  '0 0 * * *',
  $$DELETE FROM cron.job_run_details WHERE end_time < now() - interval '7 days'$$
);
```

Also viewable in Dashboard → Integrations → Cron.

---

### Supabase Queues (pgmq)

Postgres-native durable message queue built on the `pgmq` extension. Guaranteed delivery with exactly-once processing within visibility windows. Messages archived on completion.

**Core operations:**

```sql
-- Create a queue
SELECT pgmq.create('my_queue');

-- Send a message (returns message ID)
SELECT * FROM pgmq.send('my_queue', '{"task":"process_image","id":42}'::jsonb);

-- Read messages: queue, visibility_timeout_seconds, batch_size
SELECT * FROM pgmq.read('my_queue', 30, 5);

-- Long-poll: queue, visibility_timeout, batch_size, poll_timeout_seconds
SELECT * FROM pgmq.read_with_poll('my_queue', 30, 1, 60);

-- Delete after successful processing
SELECT pgmq.delete('my_queue', 1);  -- by msg_id

-- Archive instead of delete (keeps in archive table)
SELECT pgmq.archive('my_queue', 1);

-- Batch delete
SELECT pgmq.delete('my_queue', ARRAY[1, 2, 3]);

-- Queue metrics
SELECT * FROM pgmq.metrics('my_queue');

-- All queues metrics
SELECT * FROM pgmq.metrics_all();
```

**Visibility timeout:** When a message is read, it becomes invisible to other consumers for `visibility_timeout` seconds. If the consumer crashes or fails to delete, the message reappears automatically — built-in retry.

**Accessing from client via `pgmq_public` schema:**

```javascript
// Send a message from the client
const { data, error } = await supabase.rpc('send', {
  queue_name: 'my_queue',
  message: { task: 'process_image', id: 42 },
})

// Read messages (use from Edge Functions, not client)
const { data: messages } = await supabase.rpc('read', {
  queue_name: 'my_queue',
  sleep_seconds: 30,
  n: 5,
})
```

Secure with RLS on `pgmq_public` functions or restrict to service_role only.

**Dashboard:** Integrations → Queues for monitoring queue depth, message age, and throughput.

---

### Consumer Pattern: pg_cron + Edge Function

The standard pattern for background job processing in Supabase:

1. **pg_cron** invokes an Edge Function on a schedule
2. **Edge Function** reads messages from the queue via `pgmq_public` RPCs
3. Processes each message, deletes on success
4. Failed messages become visible again after visibility timeout (automatic retry)

**Schedule the consumer:**

```sql
SELECT cron.schedule(
  'process-queue',
  '10 seconds',
  $$
  SELECT net.http_post(
    url := 'https://<project-ref>.supabase.co/functions/v1/process-queue',
    headers := jsonb_build_object(
      'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key')
    ),
    body := '{}'::jsonb
  );
  $$
);
```

**Edge Function consumer:**

```typescript
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

serve(async (req) => {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  // Read up to 5 messages, 30s visibility timeout
  const { data: messages, error } = await supabase.schema('pgmq_public').rpc('read', {
    queue_name: 'tasks',
    sleep_seconds: 30,
    n: 5,
  })

  if (error || !messages?.length) {
    return new Response(JSON.stringify({ processed: 0 }), { status: 200 })
  }

  const results = await Promise.allSettled(
    messages.map(async (msg: any) => {
      try {
        // Process the message
        await processTask(msg.message)

        // Delete on success
        await supabase.schema('pgmq_public').rpc('delete', {
          queue_name: 'tasks',
          message_id: msg.msg_id,
        })

        return { id: msg.msg_id, status: 'ok' }
      } catch (err) {
        // Don't delete — message reappears after visibility timeout
        console.error(`Failed msg ${msg.msg_id}:`, err)
        return { id: msg.msg_id, status: 'failed', error: String(err) }
      }
    })
  )

  return new Response(JSON.stringify({ processed: results.length, results }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' },
  })
})

async function processTask(payload: Record<string, unknown>) {
  // Your business logic here
  const { task, id } = payload as { task: string; id: number }

  switch (task) {
    case 'process_image':
      // Call external API, resize, store in Storage, etc.
      break
    case 'send_email':
      // Compose and send via SES/Elastic Email
      break
    default:
      throw new Error(`Unknown task type: ${task}`)
  }
}
```

---

### Common Patterns: Cron + Queues

**Embedding pipeline (INSERT trigger → queue → batch process):**

```sql
-- 1. Trigger enqueues on INSERT
CREATE OR REPLACE FUNCTION enqueue_embedding()
RETURNS trigger AS $$
BEGIN
  PERFORM pgmq.send('embeddings', jsonb_build_object(
    'table', TG_TABLE_NAME,
    'id', NEW.id,
    'content', NEW.content
  ));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER on_doc_insert
  AFTER INSERT ON documents
  FOR EACH ROW EXECUTE FUNCTION enqueue_embedding();

-- 2. pg_cron polls every 10 seconds
SELECT cron.schedule('process-embeddings', '10 seconds', $$
  SELECT net.http_post(
    url := 'https://<ref>.supabase.co/functions/v1/generate-embeddings',
    headers := jsonb_build_object(
      'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key')
    ),
    body := '{}'::jsonb
  );
$$);
```

**Email digest (daily cron → aggregate → send):**

```sql
SELECT cron.schedule('daily-digest', '0 8 * * *', $$
  SELECT net.http_post(
    url := 'https://<ref>.supabase.co/functions/v1/send-digest',
    headers := jsonb_build_object(
      'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key')
    ),
    body := '{}'::jsonb
  );
$$);
```

**Direct SQL cleanup (no queue needed):**

```sql
-- Purge soft-deleted rows older than 30 days
SELECT cron.schedule('purge-deleted', '0 2 * * *', $$
  DELETE FROM documents
  WHERE deleted_at IS NOT NULL
    AND deleted_at < now() - interval '30 days';
$$);

-- Refresh materialized views every 15 minutes
SELECT cron.schedule('refresh-stats', '*/15 * * * *', $$
  REFRESH MATERIALIZED VIEW CONCURRENTLY dashboard_stats;
$$);

-- Expire unverified accounts after 48 hours
SELECT cron.schedule('expire-unverified', '0 * * * *', $$
  DELETE FROM auth.users
  WHERE email_confirmed_at IS NULL
    AND created_at < now() - interval '48 hours';
$$);
```

---

### Antipatterns

- **Do not** use Postgres Changes for high-fan-out notifications (100+ subscribers). Use Broadcast from DB triggers instead.
- **Do not** use Presence for large groups (1000+ users). Use Broadcast with a custom user-list approach.
- **Do not** process queue messages without a visibility timeout. Always set a reasonable timeout (30-120s) to handle consumer crashes.
- **Do not** schedule pg_cron jobs that exceed 10 minutes. Break long tasks into smaller queue messages.
- **Do not** use `pgmq.read` from client-side code with the anon key. Always use service_role or restrict via RLS.
- **Do not** forget to clean `cron.job_run_details` — it grows unbounded. Schedule a cleanup job.
