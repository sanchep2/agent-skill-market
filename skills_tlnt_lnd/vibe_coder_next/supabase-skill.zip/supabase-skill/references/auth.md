# Authentication and Authorization Reference

## Table of Contents
1. [Authentication Methods](#authentication-methods)
2. [PKCE Flow](#pkce-flow)
3. [MFA / TOTP](#mfa--totp)
4. [SSR Auth with @supabase/ssr](#ssr-auth-with-supabasessr)
5. [Custom Claims and RBAC](#custom-claims-and-rbac)
6. [Auth Hooks](#auth-hooks)
7. [Auth Admin API](#auth-admin-api)
8. [New Auth Features (2025-2026)](#new-auth-features-2025-2026)
9. [Common Auth Mistakes](#common-auth-mistakes)

---

## Authentication Methods

### Email / Password

Standard credential-based auth. Passwords are bcrypt-hashed server-side with configurable strength.

```typescript
// Sign up
const { data, error } = await supabase.auth.signUp({
  email: 'user@example.com',
  password: 'secure-password-123',
  options: {
    data: { full_name: 'Jane Doe' }, // stored in raw_user_meta_data
  },
})

// Sign in
const { data, error } = await supabase.auth.signInWithPassword({
  email: 'user@example.com',
  password: 'secure-password-123',
})
```

**Confirmation flow**: By default, Supabase sends a confirmation email. Disable in Dashboard > Auth > Settings if using a custom flow. The `data.user.identities` array will be empty if an existing user tries to sign up again with email confirmation enabled.

### Magic Links / Email OTP

`signInWithOtp` sends either a magic link or a 6-digit OTP depending on the email template configuration.

```typescript
const { data, error } = await supabase.auth.signInWithOtp({
  email: 'user@example.com',
  options: {
    shouldCreateUser: true, // false to restrict to existing users
    emailRedirectTo: 'https://myapp.com/auth/callback',
  },
})
```

**Template determines behavior**: If the email template uses `{{ .ConfirmationURL }}`, the user gets a magic link. If it uses `{{ .Token }}`, the user gets a 6-digit OTP code that must be verified:

```typescript
const { data, error } = await supabase.auth.verifyOtp({
  email: 'user@example.com',
  token: '123456',
  type: 'email',
})
```

### Phone OTP (SMS / WhatsApp)

Requires a configured SMS provider (Twilio, MessageBird, Vonage, or a custom HTTP endpoint).

```typescript
// Send OTP
const { data, error } = await supabase.auth.signInWithOtp({
  phone: '+1234567890',
})

// Verify OTP
const { data, error } = await supabase.auth.verifyOtp({
  phone: '+1234567890',
  token: '123456',
  type: 'sms',
})
```

WhatsApp channel is configured at the project level in Dashboard > Auth > Providers > Phone.

### OAuth Providers (20+)

| Provider | Key | Notes |
|----------|-----|-------|
| Google | `google` | Supports One Tap, ID token flow |
| GitHub | `github` | Scopes: `user`, `user:email`, `read:org` |
| Apple | `apple` | Requires Apple Developer account, private key relay |
| Azure AD | `azure` | Tenant-specific or multi-tenant |
| Twitter | `twitter` | OAuth 2.0 (not 1.0a) |
| Discord | `discord` | Scopes: `identify`, `email` |
| Facebook | `facebook` | Graph API v18+ |
| GitLab | `gitlab` | Self-hosted or gitlab.com |
| Bitbucket | `bitbucket` | Atlassian account |
| Figma | `figma` | Read-only user profile |
| Kakao | `kakao` | Korean market |
| Keycloak | `keycloak` | Self-hosted OIDC |
| LinkedIn (OIDC) | `linkedin_oidc` | Uses OpenID Connect |
| Notion | `notion` | Workspace access |
| Slack (OIDC) | `slack_oidc` | Uses OpenID Connect |
| Spotify | `spotify` | Scopes: `user-read-email` |
| Twitch | `twitch` | Scopes: `user:read:email` |
| WorkOS | `workos` | Enterprise SSO bridge |
| Zoom | `zoom` | Scopes: `user:read` |

**Standard pattern for all providers:**

```typescript
const { data, error } = await supabase.auth.signInWithOAuth({
  provider: 'google',
  options: {
    redirectTo: 'https://myapp.com/auth/callback',
    scopes: 'openid profile email',
    queryParams: {
      access_type: 'offline',   // Google: get refresh token
      prompt: 'consent',        // Force consent screen
    },
  },
})

// data.url contains the provider authorization URL
// Redirect the user to data.url (browser) or open in-app browser (mobile)
```

**Callback URL** (configure in each provider's developer console):
```
https://<project-ref>.supabase.co/auth/v1/callback
```

**Provider tokens**: The OAuth provider's access/refresh tokens are returned in the session but are NOT stored by Supabase. If you need them for API calls, persist them yourself:

```typescript
const { data: { session } } = await supabase.auth.getSession()
// session.provider_token  — provider access token (ephemeral)
// session.provider_refresh_token — provider refresh token (if granted)
```

### SAML SSO (Pro Plan+)

Enterprise SAML 2.0 support for Azure AD, Okta, Google Workspaces, PingIdentity, OneLogin, and any SAML 2.0 compliant IdP.

```typescript
const { data, error } = await supabase.auth.signInWithSSO({
  domain: 'company.com', // matches the SSO domain configured in dashboard
})

// data.url — redirect the user to this URL for IdP authentication
if (data?.url) {
  window.location.href = data.url
}
```

**CLI management:**

```bash
supabase sso add --type saml --domain company.com \
  --metadata-url "https://login.microsoftonline.com/.../federationmetadata/2007-06/federationmetadata.xml"

supabase sso list
supabase sso show <provider-id>
supabase sso update <provider-id> --metadata-url "..."
supabase sso remove <provider-id>
```

**Pricing**: Base SSO is included on Pro plan. Usage: $0.015 per SSO MAU beyond the plan's included MAUs.

### Anonymous Auth

Creates a temporary user with a real UUID. Useful for guest checkouts, try-before-signup flows.

```typescript
const { data, error } = await supabase.auth.signInAnonymously({
  options: {
    captchaToken: 'hcaptcha-token', // strongly recommended
  },
})

// data.user.is_anonymous === true
// data.user.id — preserved when converting to permanent account
```

**Converting anonymous users to permanent:**

```typescript
// Option A: Link email/password
const { data, error } = await supabase.auth.updateUser({
  email: 'real@example.com',
  password: 'new-password',
})

// Option B: Link OAuth identity
const { data, error } = await supabase.auth.linkIdentity({
  provider: 'google',
})
```

The user ID is preserved during conversion -- all existing data associations remain intact.

**RLS gate** -- restrict anonymous users from sensitive operations:

```sql
CREATE POLICY "Registered users only" ON sensitive_table
  FOR ALL
  USING (
    (SELECT (auth.jwt() ->> 'is_anonymous')::boolean) IS FALSE
  );
```

**Rate limiting**: Anonymous sign-ups are rate-limited to 30/hour/IP by default. Always enable CAPTCHA (hCaptcha or Turnstile) for anonymous auth to prevent abuse.

---

## PKCE Flow

PKCE (Proof Key for Code Exchange) is the default authorization flow in `@supabase/ssr`, replacing the implicit flow used in older `@supabase/auth-helpers-*` packages.

### Why PKCE matters

| Aspect | Implicit Flow | PKCE Flow |
|--------|--------------|-----------|
| Token delivery | URL fragment (`#access_token=...`) | Query parameter (`?code=...`) |
| Server-side access | Impossible (fragments never reach server) | Full access (codes are in the URL path) |
| Token exchange | Not needed | Required (`exchangeCodeForSession`) |
| Security | Vulnerable to token leakage via referrer/logs | Code is useless without verifier |

### How PKCE works in Supabase

1. Client generates a random `code_verifier` and derives `code_challenge` (SHA-256 hash)
2. Auth request includes `code_challenge` and `code_challenge_method=S256`
3. Auth server returns redirect with `?code=<auth_code>` (NOT a URL fragment)
4. Client exchanges the code using the original `code_verifier`

```typescript
// In your auth callback route (e.g., /auth/callback)
// The @supabase/ssr client handles PKCE automatically

import { NextResponse } from 'next/server'
import { createServerClient } from '@supabase/ssr'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const code = searchParams.get('code')
  const next = searchParams.get('next') ?? '/'

  if (code) {
    const supabase = createServerClient(/* ... */)
    // Exchanges the code using the stored code_verifier
    // Codes are valid for 5 minutes and are single-use
    const { error } = await supabase.auth.exchangeCodeForSession(code)
    if (!error) {
      return NextResponse.redirect(new URL(next, request.url))
    }
  }

  return NextResponse.redirect(new URL('/auth/error', request.url))
}
```

**Auth codes expire after 5 minutes and are single-use.** If the exchange fails, the user must restart the auth flow.

---

## MFA / TOTP

Multi-factor authentication using TOTP (Time-based One-Time Password). Compatible with any authenticator app (Google Authenticator, Authy, 1Password, etc.).

### Enrollment

```typescript
// Step 1: Enroll — returns QR code and secret
const { data, error } = await supabase.auth.mfa.enroll({
  factorType: 'totp',
  friendlyName: 'My Authenticator',
})

// data.id — factor ID (store this)
// data.totp.qr_code — data URI for QR code image
// data.totp.secret — manual entry key
// data.totp.uri — otpauth:// URI
```

### Challenge and Verify

```typescript
// Step 2: Create a challenge
const { data: challenge, error } = await supabase.auth.mfa.challenge({
  factorId: 'factor-uuid',
})

// Step 3: Verify the TOTP code
const { data, error } = await supabase.auth.mfa.verify({
  factorId: 'factor-uuid',
  challengeId: challenge.id,
  code: '123456', // from authenticator app
})
```

**Convenience method** -- combines challenge + verify into one call:

```typescript
const { data, error } = await supabase.auth.mfa.challengeAndVerify({
  factorId: 'factor-uuid',
  code: '123456',
})
```

### Assurance Levels

| Level | Meaning | JWT Claim |
|-------|---------|-----------|
| `aal1` | First factor verified (email/password, OAuth, etc.) | `"aal": "aal1"` |
| `aal2` | Second factor verified (TOTP code entered) | `"aal": "aal2"` |

### Enforcing MFA via RLS

Use a RESTRICTIVE policy to require MFA for sensitive tables:

```sql
-- RESTRICTIVE policies are AND-ed with PERMISSIVE policies
CREATE POLICY "Require MFA" ON sensitive_data
  AS RESTRICTIVE
  FOR ALL
  TO authenticated
  USING (
    (SELECT (auth.jwt() ->> 'aal')) = 'aal2'
  );
```

**Client-side check** -- prompt for MFA when needed:

```typescript
const { data: { currentLevel, nextLevel } } =
  await supabase.auth.mfa.getAuthenticatorAssuranceLevel()

if (currentLevel === 'aal1' && nextLevel === 'aal2') {
  // User has MFA enrolled but hasn't verified this session
  // Show MFA verification UI
}
```

### MFA Limits and Gotchas

- Maximum **10 factors** per user
- No native recovery codes -- implement your own backup strategy
- Phone-based MFA (SMS): available at $75/month add-on
- Unenroll a factor: `supabase.auth.mfa.unenroll({ factorId })`
- TOTP codes are valid for a 30-second window (with slight tolerance)

---

## SSR Auth with @supabase/ssr

`@supabase/ssr` is the unified SSR package that replaced all framework-specific `@supabase/auth-helpers-*` packages. It stores sessions in cookies instead of localStorage, making them accessible to server-side code.

### Browser Client

For Client Components (React, Vue, Svelte, etc.):

```typescript
// lib/supabase/client.ts
import { createBrowserClient } from '@supabase/ssr'

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}
```

Usage in a Client Component:

```tsx
'use client'
import { createClient } from '@/lib/supabase/client'

export default function LoginForm() {
  const supabase = createClient()

  const handleLogin = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) console.error(error)
  }

  return <form>{/* ... */}</form>
}
```

### Server Client

For Server Components, Server Actions, Route Handlers, and Middleware:

```typescript
// lib/supabase/server.ts
import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

export async function createClient() {
  const cookieStore = await cookies()

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            )
          } catch {
            // setAll is called from a Server Component
            // This can be ignored if middleware refreshes the session
          }
        },
      },
    }
  )
}
```

**Why the try/catch on `setAll`?** Server Components can only read cookies, not write them. The `setAll` call will throw when invoked from a Server Component. The middleware handles the actual cookie refresh, so this error is safe to ignore.

### Middleware (Session Refresh)

The middleware is the only place where cookies are reliably refreshed on every request:

```typescript
// middleware.ts
import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          )
          supabaseResponse = NextResponse.next({ request })
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  // IMPORTANT: Do not remove this line
  // It refreshes the auth token if expired
  const { data: { user } } = await supabase.auth.getUser()

  return supabaseResponse
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)'],
}
```

### Server-Side Session Validation

| Method | Network Call | Validates JWT | Use For |
|--------|-------------|---------------|---------|
| `getSession()` | No | No (reads cookie only) | Client-side display only |
| `getClaims()` | No | Yes (against public JWKs) | Fast server-side auth check |
| `getUser()` | Yes (Auth server) | Yes | Sensitive operations, account changes |

**Security rule**: Never trust `getSession()` on the server. It reads the cookie without validation. A tampered JWT will pass `getSession()` but fail `getClaims()` and `getUser()`.

```typescript
// WRONG -- do not use for authorization decisions
const { data: { session } } = await supabase.auth.getSession()

// CORRECT -- validates JWT signature against public keys (no network)
const { data: { claims }, error } = await supabase.auth.getClaims()

// CORRECT -- contacts Auth server (most secure, costs a network round trip)
const { data: { user }, error } = await supabase.auth.getUser()
```

**Refresh tokens are single-use.** If two tabs or SSR requests try to use the same refresh token concurrently, one will fail. The `@supabase/ssr` client handles this by coordinating cookie updates through the middleware.

---

## Custom Claims and RBAC

### Custom Access Token Hook

A Postgres function that runs before every JWT is issued, allowing you to inject custom claims (roles, permissions, tenant IDs) directly into the access token.

```sql
-- Step 1: Create the roles table
CREATE TYPE public.app_role AS ENUM ('admin', 'manager', 'member');

CREATE TABLE public.user_roles (
  id        BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
  user_id   UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role      public.app_role NOT NULL,
  UNIQUE (user_id, role)
);

-- Step 2: Create the hook function
CREATE OR REPLACE FUNCTION public.custom_access_token_hook(event jsonb)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
AS $$
DECLARE
  claims jsonb;
  user_role public.app_role;
BEGIN
  SELECT role INTO user_role
    FROM public.user_roles
   WHERE user_id = (event->>'user_id')::uuid;

  claims := event->'claims';

  IF user_role IS NOT NULL THEN
    claims := jsonb_set(claims, '{user_role}', to_jsonb(user_role));
  ELSE
    claims := jsonb_set(claims, '{user_role}', '"member"');
  END IF;

  event := jsonb_set(event, '{claims}', claims);
  RETURN event;
END;
$$;

-- Step 3: Grant/revoke permissions
GRANT USAGE ON SCHEMA public TO supabase_auth_admin;
GRANT EXECUTE ON FUNCTION public.custom_access_token_hook TO supabase_auth_admin;

REVOKE EXECUTE ON FUNCTION public.custom_access_token_hook FROM authenticated, anon, public;

-- Step 4: Secure the user_roles table
GRANT SELECT ON public.user_roles TO supabase_auth_admin;

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own role" ON public.user_roles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);
```

### Local config (config.toml)

```toml
[auth.hook.custom_access_token]
enabled = true
uri = "pg-functions://postgres/public/custom_access_token_hook"
```

### Using Custom Claims in RLS

```sql
-- Allow admins to read all rows, others only their own
CREATE POLICY "Role-based access" ON documents
  FOR SELECT
  TO authenticated
  USING (
    (SELECT (auth.jwt() ->> 'user_role')) = 'admin'
    OR auth.uid() = owner_id
  );
```

### app_metadata vs user_metadata: Critical Distinction

| Field | DB Column | User-Writable | Safe for RLS |
|-------|-----------|---------------|--------------|
| `app_metadata` | `raw_app_meta_data` | NO -- only Admin API can modify | YES |
| `user_metadata` | `raw_user_meta_data` | YES -- `updateUser()` can modify | NEVER |

```sql
-- SAFE: app_metadata is not user-writable
CREATE POLICY "Admin only" ON admin_table
  FOR ALL
  USING (
    (SELECT (auth.jwt() -> 'app_metadata' ->> 'role')) = 'admin'
  );

-- DANGEROUS: user_metadata IS user-writable -- any user can set their own role
-- DO NOT DO THIS:
CREATE POLICY "Broken admin check" ON admin_table
  FOR ALL
  USING (
    (SELECT (auth.jwt() -> 'user_metadata' ->> 'role')) = 'admin'
  );
```

---

## Auth Hooks

Six hook types that let you customize auth behavior at key lifecycle points.

| Hook | Trigger | Execution | Timeout |
|------|---------|-----------|---------|
| Before User Created | Before `auth.users` INSERT | Postgres function | 2 seconds |
| Custom Access Token | Before JWT issuance | Postgres function | 2 seconds |
| Send SMS | Instead of default SMS provider | HTTP endpoint | 5 seconds |
| Send Email | Instead of default email provider | HTTP endpoint | 5 seconds |
| MFA Verification | During TOTP verify | Postgres function | 2 seconds |
| Password Verification | During password check | Postgres function | 2 seconds |

**MFA Verification** and **Password Verification** hooks require Teams or Enterprise plan.

### Postgres Function Hooks

```sql
-- Example: Block disposable email domains at signup
CREATE OR REPLACE FUNCTION public.before_user_created_hook(event jsonb)
RETURNS jsonb
LANGUAGE plpgsql
AS $$
DECLARE
  email_domain TEXT;
BEGIN
  email_domain := split_part(event->'record'->>'email', '@', 2);

  IF email_domain = ANY(ARRAY['tempmail.com', 'throwaway.email', 'guerrillamail.com']) THEN
    RETURN jsonb_build_object(
      'decision', 'reject',
      'message', 'Disposable email addresses are not allowed'
    );
  END IF;

  RETURN jsonb_build_object('decision', 'continue');
END;
$$;
```

### HTTP Endpoint Hooks

HTTP hooks are signed using the Standard Webhooks specification. Verify the signature with the `svix` library:

```typescript
import { Webhook } from 'svix'

export async function POST(req: Request) {
  const body = await req.text()
  const headers = Object.fromEntries(req.headers)

  const wh = new Webhook(process.env.AUTH_HOOK_SECRET!)
  const payload = wh.verify(body, headers) as AuthHookPayload

  // Process the hook (e.g., send SMS via custom provider)
  return Response.json({ /* response */ })
}
```

---

## Auth Admin API

Server-side user management using the `service_role` key. These methods bypass RLS entirely.

```typescript
import { createClient } from '@supabase/supabase-js'

const supabaseAdmin = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!, // Never expose to client
  { auth: { autoRefreshToken: false, persistSession: false } }
)
```

### Available Methods

```typescript
// Create a user (skips email confirmation)
const { data, error } = await supabaseAdmin.auth.admin.createUser({
  email: 'user@example.com',
  password: 'initial-password',
  email_confirm: true,
  user_metadata: { full_name: 'Jane Doe' },
  app_metadata: { role: 'admin' }, // safe for RLS
})

// Invite user by email (sends invite link)
const { data, error } = await supabaseAdmin.auth.admin.inviteUserByEmail(
  'newuser@example.com',
  { redirectTo: 'https://myapp.com/welcome' }
)

// Update user by ID
const { data, error } = await supabaseAdmin.auth.admin.updateUserById(userId, {
  email: 'newemail@example.com',
  app_metadata: { role: 'manager' },
})

// Delete user (hard delete by default)
const { data, error } = await supabaseAdmin.auth.admin.deleteUser(userId)

// Soft delete (marks as deleted, preserves data)
const { data, error } = await supabaseAdmin.auth.admin.deleteUser(userId, {
  shouldSoftDelete: true,
})

// List users (paginated)
const { data: { users }, error } = await supabaseAdmin.auth.admin.listUsers({
  page: 1,
  perPage: 50,
})

// Get a single user
const { data, error } = await supabaseAdmin.auth.admin.getUserById(userId)

// Generate various links programmatically
const { data, error } = await supabaseAdmin.auth.admin.generateLink({
  type: 'magiclink', // 'signup', 'invite', 'recovery', 'email_change_new'
  email: 'user@example.com',
  options: { redirectTo: 'https://myapp.com/welcome' },
})
```

---

## New Auth Features (2025-2026)

### Asymmetric JWT (RS256)

Since May 2025, Supabase signs JWTs with RS256 (asymmetric) by default instead of HS256 (symmetric). This means JWTs can be verified using public keys without exposing the signing secret.

**Public JWKs endpoint:**
```
https://<project-ref>.supabase.co/auth/v1/.well-known/jwks.json
```

Third-party services can verify Supabase JWTs independently using this endpoint. Existing HS256 projects continue to work -- RS256 is the default for new projects.

### Supabase as OAuth 2.1 / OIDC Identity Provider

Supabase can act as an OAuth 2.1 and OpenID Connect provider, enabling "Sign in with [Your App]" for external services.

Use cases:
- Let third-party apps authenticate against your Supabase user base
- Authenticate AI agents via MCP (Model Context Protocol) using OAuth 2.1
- Federate identity across multiple internal services

### New API Key Format

New projects use a clearer key naming convention:

| Old Format | New Format | Purpose |
|-----------|-----------|---------|
| `eyJhbGciOi...` (anon) | `sb_publishable_...` | Client-side, safe to expose |
| `eyJhbGciOi...` (service_role) | `sb_secret_...` | Server-side only, never expose |

Both old and new formats continue to work. The new format makes it immediately obvious which key is which.

### Third-Party Auth Integration

Supabase can validate JWTs from external auth providers, enabling RLS to work with third-party auth systems:

| Provider | Configuration |
|----------|--------------|
| Clerk | JWKS URL from Clerk dashboard |
| Firebase Auth | Firebase project's public keys |
| Auth0 | Auth0 tenant's JWKS endpoint |
| AWS Cognito | Cognito User Pool's JWKS URL |
| WorkOS | WorkOS environment's JWKS |

Configure in Dashboard > Auth > Third-Party Auth, or in `config.toml`:

```toml
[auth.third_party.auth0]
enabled = true
```

This lets you keep your existing auth provider while using Supabase for the database and RLS.

---

## Common Auth Mistakes

### 1. Using user_metadata in RLS policies

`raw_user_meta_data` is writable by any authenticated user via `supabase.auth.updateUser()`. Never use it for authorization:

```sql
-- BUG: Any user can call updateUser({ data: { role: 'admin' } })
USING ((auth.jwt() -> 'user_metadata' ->> 'role') = 'admin')

-- FIX: Use app_metadata (only Admin API can write) or custom claims hook
USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
```

### 2. Trusting getSession() on the server

`getSession()` reads the cookie as-is without validating the JWT signature. A crafted cookie with a forged JWT will pass:

```typescript
// INSECURE
const { data: { session } } = await supabase.auth.getSession()
if (session) { /* user could be forged */ }

// SECURE
const { data: { user } } = await supabase.auth.getUser()
if (user) { /* validated against Auth server */ }
```

### 3. Not handling concurrent refresh token use

Refresh tokens are single-use. When multiple browser tabs or SSR requests fire simultaneously, only the first refresh succeeds. Solutions:
- Use `@supabase/ssr` middleware to centralize refresh
- On the client, the SDK includes a lock mechanism -- do not disable it
- If using a custom setup, serialize refresh token operations

### 4. Missing detectSessionInUrl for React Native

React Native does not have URL fragment parsing. Without this flag, OAuth callbacks silently fail:

```typescript
const supabase = createClient(url, anonKey, {
  auth: {
    detectSessionInUrl: false,  // Required for React Native
    storage: AsyncStorage,       // Use AsyncStorage, not localStorage
    flowType: 'pkce',           // Always use PKCE on mobile
  },
})
```

### 5. Not configuring the PKCE callback route

PKCE requires a server-side route to exchange the auth code. If you switch from implicit to PKCE flow (e.g., by adopting `@supabase/ssr`) without adding the callback route, all auth redirects will fail silently.

Required route:
```typescript
// app/auth/callback/route.ts (Next.js App Router)
import { createClient } from '@/lib/supabase/server'
import { NextResponse } from 'next/server'

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get('code')
  const next = searchParams.get('next') ?? '/'

  if (code) {
    const supabase = await createClient()
    const { error } = await supabase.auth.exchangeCodeForSession(code)
    if (!error) {
      return NextResponse.redirect(`${origin}${next}`)
    }
  }

  return NextResponse.redirect(`${origin}/auth/error`)
}
```

### 6. Missing try/catch in setAll for Server Components

Server Components cannot set cookies. Without the try/catch, the entire render crashes:

```typescript
// This will throw in Server Components:
setAll(cookiesToSet) {
  cookiesToSet.forEach(({ name, value, options }) =>
    cookieStore.set(name, value, options)  // Throws in RSC!
  )
}

// Always wrap in try/catch:
setAll(cookiesToSet) {
  try {
    cookiesToSet.forEach(({ name, value, options }) =>
      cookieStore.set(name, value, options)
    )
  } catch {
    // Called from Server Component -- middleware handles refresh
  }
}
```

### 7. Forgetting to secure service_role key

The `service_role` key bypasses all RLS. If it leaks to the client, your entire database is exposed:

```typescript
// NEVER do this in client code:
const supabase = createClient(url, process.env.SUPABASE_SERVICE_ROLE_KEY!)

// Only use service_role in:
// - Server-side API routes
// - Background jobs / cron
// - Admin scripts
// Prefix with SUPABASE_ (not NEXT_PUBLIC_) so it stays server-only
```
