# Storage & Edge Functions

> Supabase Storage for file management + Edge Functions for serverless compute. Both integrate tightly with Postgres RLS and the Supabase client SDK.

## Table of Contents

1. [Storage](#storage)
2. [Edge Functions](#edge-functions)

---

## Storage

### Architecture

- **Metadata layer**: Postgres tables `storage.buckets` (bucket config) and `storage.objects` (file metadata, ownership, MIME types). All policy enforcement happens here via RLS.
- **File layer**: S3-compatible object store backend. Files are never stored in Postgres itself.
- **Organization hierarchy**: Files -> Folders -> Buckets. Folders are virtual (path prefixes on object names).
- **Bucket visibility**:
  - **Private** (default) — all operations require authentication + passing RLS policies
  - **Public** — unrestricted read access via public URL; writes still require auth + policies
- **Upload protocols**:
  - **REST API** — standard multipart, up to 5GB per file
  - **TUS resumable** — chunked uploads, up to 50GB (500GB as of LW15), mandatory 6MB chunk size
  - **S3 protocol** (public alpha) — AWS Signature V4 compatible, use any S3 SDK or tool (aws-cli, boto3, Cyberduck)
- **New bucket types** (alpha):
  - **Analytics Buckets** — Apache Iceberg table format, query files with SQL via `iceberg_scan()`
  - **Vector Buckets** — Amazon S3 Vectors, store and retrieve embeddings alongside objects

### Storage Policies (RLS)

By default **no uploads are allowed** — you must create policies on `storage.objects`. Policies use standard Postgres RLS syntax with helper functions.

**Helper functions:**
- `storage.foldername(name)` — returns text array of folder path segments
- `storage.filename(name)` — returns the file name portion
- `storage.extension(name)` — returns the file extension without dot

**Public read access:**

```sql
CREATE POLICY "public read" ON storage.objects FOR SELECT
USING (bucket_id = 'public-assets');
```

**Authenticated upload (any logged-in user):**

```sql
CREATE POLICY "auth upload" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'uploads' AND storage.extension(name) IN ('png', 'jpg', 'webp', 'pdf'));
```

**Per-user folder pattern** (most common — each user owns a folder named by their UID):

```sql
CREATE POLICY "user folder select" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'user-files' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "user folder insert" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'user-files' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "user folder update" ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'user-files' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "user folder delete" ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'user-files' AND (storage.foldername(name))[1] = auth.uid()::text);
```

**Admin-only delete** (service role or users with admin claim):

```sql
CREATE POLICY "admin delete" ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'protected'
  AND (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
);
```

### Image Transformations

Requires **Pro plan or higher**. Powered by Imgproxy under the hood.

- **Dimensions**: width and height 1–2500px
- **Quality**: 20–100 (default 80)
- **Resize modes**: `cover` (crop to fill), `contain` (fit within bounds), `fill` (stretch)
- **Format**: auto WebP conversion when browser supports it
- **Limits**: max 25MB source file, max 50 megapixels

```typescript
// Public URL with transforms
const { data } = supabase.storage
  .from('products')
  .getPublicUrl('hero.jpg', {
    transform: {
      width: 500,
      height: 600,
      resize: 'cover',
      quality: 75,
      format: 'origin', // or 'auto' for WebP
    },
  })

// Signed URL with locked transforms (user cannot alter params)
const { data, error } = await supabase.storage
  .from('private-images')
  .createSignedUrl('report/chart.png', 3600, {
    transform: { width: 800, height: 400, resize: 'contain' },
  })
```

Transformed images are cached at the CDN edge. Different transform params = different cache entries.

### Resumable Uploads

Use the **TUS protocol** for files larger than 6MB or when network reliability is a concern.

- Mandatory **6MB chunk size** (Supabase enforced)
- Uploads expire after **24 hours** if not completed
- Standard uploads: up to **5GB**. Resumable: up to **50GB** (increased to **500GB** as of LW15)
- Use the `tus-js-client` library

```typescript
import * as tus from 'tus-js-client'

const file = event.target.files[0] // from <input type="file">
const bucketName = 'large-files'
const objectPath = `${userId}/${file.name}`

const { data: { session } } = await supabase.auth.getSession()

const upload = new tus.Upload(file, {
  endpoint: `${SUPABASE_URL}/storage/v1/upload/resumable`,
  retryDelays: [0, 3000, 5000, 10000, 20000],
  chunkSize: 6 * 1024 * 1024, // 6MB — required
  headers: {
    authorization: `Bearer ${session.access_token}`,
    'x-upsert': 'true', // overwrite if exists
  },
  uploadDataDuringCreation: true, // send first chunk with CREATE request
  removeFingerprintOnSuccess: true,
  metadata: {
    bucketName,
    objectName: objectPath,
    contentType: file.type,
    cacheControl: '3600',
  },
  onError(error) {
    console.error('Upload failed:', error)
  },
  onProgress(bytesUploaded, bytesTotal) {
    const pct = ((bytesUploaded / bytesTotal) * 100).toFixed(1)
    console.log(`${pct}%`)
  },
  onSuccess() {
    console.log('Upload complete:', upload.url)
  },
})

// Check for previous incomplete uploads, then start
const previousUploads = await upload.findPreviousUploads()
if (previousUploads.length > 0) {
  upload.resumeFromPreviousUpload(previousUploads[0])
}
upload.start()
```

### Signed URLs and CDN

**Signed download URLs** — bypass RLS, grant time-limited access:

```typescript
// Single file
const { data, error } = await supabase.storage
  .from('private')
  .createSignedUrl('reports/q4.pdf', 60 * 60) // 1 hour

// Batch (up to 100)
const { data, error } = await supabase.storage
  .from('private')
  .createSignedUrls(['file1.pdf', 'file2.pdf', 'file3.pdf'], 3600)
```

**Signed upload URLs** — let clients upload without a session (e.g., from a backend-generated link):

```typescript
const { data, error } = await supabase.storage
  .from('uploads')
  .createSignedUploadUrl('invoices/inv-001.pdf')

// Client uses data.signedUrl to PUT the file
// Token is single-use, path is locked
```

**CDN details:**
- **285+ edge cities** worldwide
- **Smart CDN** (Pro plan+) — automatically invalidates cached objects on update/delete, propagation up to 60 seconds
- Browser cache controlled via `cacheControl` option (seconds) when uploading:
  ```typescript
  await supabase.storage.from('assets').upload('logo.svg', file, {
    cacheControl: '31536000', // 1 year
    upsert: true,
  })
  ```

### Storage Limits and Pricing

| Resource | Free | Pro ($25/mo) |
|----------|------|-------------|
| Storage | 1 GB | 100 GB |
| Egress / month | 5 GB | 250 GB |
| Max file (standard) | 5 GB | 5 GB |
| Max file (resumable) | 50 GB | 50 GB (500 GB LW15) |
| Image transforms | N/A | 100 origin images free |

**Overage (Pro):**
- Storage: **$0.021/GB/month**
- Egress: **$0.09/GB**
- Image transforms: **$5 per 1,000 origin images** beyond the 100 included

---

## Edge Functions

### Runtime and Capabilities

- **Custom open-source Deno-compatible runtime** (not stock Deno Deploy)
- **Language support**: TypeScript, JavaScript, WASM
- **API surface**: Web standard APIs (Fetch, Request, Response, Streams, Crypto, WebSockets, URL, TextEncoder/Decoder), Deno core APIs (`Deno.serve`, `Deno.env`, `Deno.readFile`), Node built-in APIs via `node:` prefix
- **Distribution**: globally distributed via Fly.io
- **Bundle format**: ESZip — self-contained bundle, no `npm install` at deploy time, no `node_modules`
- **Max bundle size**: 20MB
- **Cold starts**: millisecond-range due to ESZip pre-bundling

### Creating and Deploying

**File structure:**

```
supabase/
  functions/
    my-function/
      index.ts        # entry point (required)
    _shared/          # shared code (prefix with _ to exclude from deployment)
      cors.ts
      supabase-client.ts
```

**Minimal function:**

```typescript
// supabase/functions/my-function/index.ts
Deno.serve(async (req: Request) => {
  const { name } = await req.json()
  return new Response(JSON.stringify({ message: `Hello ${name}!` }), {
    headers: { 'Content-Type': 'application/json' },
  })
})
```

**CLI commands:**

```bash
# Scaffold a new function
supabase functions new my-function

# Local dev with hot reload (all functions)
supabase functions serve

# Serve a single function
supabase functions serve my-function --env-file ./supabase/.env.local

# Deploy a single function
supabase functions deploy my-function

# Deploy all functions
supabase functions deploy

# Deploy with import map
supabase functions deploy my-function --import-map ./supabase/functions/import_map.json
```

### NPM Compatibility

Use the `npm:` specifier directly — no install step, no `package.json` required:

```typescript
import Stripe from 'npm:stripe@17'
import { Resend } from 'npm:resend@4'
import { z } from 'npm:zod@3'
```

**Specifier priority** (prefer in this order):
1. `npm:package@version` — NPM packages, version pinning recommended
2. `jsr:@scope/package` — JSR registry (Deno-native)
3. `node:fs`, `node:crypto` — Node built-in modules
4. `https://esm.sh/package` — URL imports (last resort)

**Private registries**: configure via `.npmrc` in project root.

**Restriction**: no native binary addons (Sharp, libvips, canvas). Use WASM alternatives instead (e.g., `@cf-wasm/photon`, `resvg-wasm`).

### Secrets and Environment Variables

**Setting secrets:**

```bash
# Set one or more
supabase secrets set MY_API_KEY=sk-abc123 WEBHOOK_SECRET=whsec-xyz

# List (names only, values hidden)
supabase secrets list

# Unset
supabase secrets unset MY_API_KEY
```

**Accessing in code:**

```typescript
const apiKey = Deno.env.get('MY_API_KEY')
```

**Auto-injected variables** (available in every function without setting):
- `SUPABASE_URL` — project API URL
- `SUPABASE_ANON_KEY` — anon/public key
- `SUPABASE_SERVICE_ROLE_KEY` — service role key (bypasses RLS)
- `SUPABASE_DB_URL` — direct Postgres connection string
- `SB_REGION` — region where the function is executing

**Limit**: 100 secrets per project.

### CORS Pattern

Edge Functions run on a different origin than your frontend. Use this standard pattern:

```typescript
// supabase/functions/_shared/cors.ts
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE',
}
```

```typescript
// supabase/functions/my-function/index.ts
import { corsHeaders } from '../_shared/cors.ts'

Deno.serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const data = await req.json()

    return new Response(JSON.stringify({ result: data }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400,
    })
  }
})
```

**Note**: OPTIONS preflight requests are **not billed** against invocation limits.

### Streaming and Scheduling

**Streaming responses** (SSE pattern for LLM proxies, real-time progress):

```typescript
Deno.serve(async (req: Request) => {
  const stream = new ReadableStream({
    async start(controller) {
      const encoder = new TextEncoder()
      for (const chunk of ['Hello', ' ', 'World', '!']) {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ text: chunk })}\n\n`))
        await new Promise((r) => setTimeout(r, 100))
      }
      controller.enqueue(encoder.encode('data: [DONE]\n\n'))
      controller.close()
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  })
})
```

**Scheduled invocations** via `pg_cron` + `pg_net`:

```sql
-- Enable extensions (once)
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Schedule: run every day at 3 AM UTC
SELECT cron.schedule(
  'daily-cleanup',
  '0 3 * * *',
  $$
  SELECT net.http_post(
    url := 'https://<project-ref>.supabase.co/functions/v1/daily-cleanup',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key')
    ),
    body := '{"source": "cron"}'::jsonb
  ) AS request_id;
  $$
);
```

Store the service role key in **Supabase Vault** and reference via `current_setting()` rather than hardcoding.

**Regional invocations** — force execution in a specific region:

```typescript
// Client-side: force function to run in eu-west-1
const { data, error } = await supabase.functions.invoke('process-data', {
  body: { items: [1, 2, 3] },
  headers: { 'x-region': 'eu-west-1' },
})
```

### Background Work and Database Access

**`EdgeRuntime.waitUntil()`** — run async work after the response is sent (logging, analytics, webhooks):

```typescript
import { createClient } from 'npm:@supabase/supabase-js@2'

Deno.serve(async (req: Request) => {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  const body = await req.json()

  // Respond immediately
  const response = new Response(JSON.stringify({ status: 'accepted' }), {
    headers: { 'Content-Type': 'application/json' },
    status: 202,
  })

  // Background work — runs after response is sent
  EdgeRuntime.waitUntil(
    (async () => {
      // Heavy processing
      const result = await processItems(body.items)

      // Log to database
      await supabase.from('job_logs').insert({
        job_type: 'process-items',
        result_count: result.length,
        completed_at: new Date().toISOString(),
      })
    })()
  )

  return response
})
```

**Database access patterns:**

1. **supabase-js** (recommended) — handles auth context, respects RLS:
   ```typescript
   // With user's JWT (respects RLS)
   const supabase = createClient(
     Deno.env.get('SUPABASE_URL')!,
     Deno.env.get('SUPABASE_ANON_KEY')!,
     { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
   )

   // With service role (bypasses RLS — use for admin operations)
   const adminClient = createClient(
     Deno.env.get('SUPABASE_URL')!,
     Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
   )
   ```

2. **Direct Postgres** — for complex queries, transactions, or bulk operations:
   ```typescript
   import postgres from 'npm:postgres@3'
   // Use transaction pooler (port 6543), NOT session pooler
   const sql = postgres(Deno.env.get('SUPABASE_DB_URL')!)
   const rows = await sql`SELECT * FROM profiles WHERE active = true`
   ```

### Edge Function Limits

| Resource | Free | Paid |
|----------|------|------|
| Wall clock time | 150s | 400s |
| CPU time / request | 2s | 2s |
| Memory | 256 MB | 256 MB |
| Functions / project | 100 | 500–1,000 |
| Invocations / month | 500K | 2M |
| Bundle size | 20 MB | 20 MB |
| Concurrency | 50 | 200–500 |

**Overage (Paid):** $2 per 1M invocations beyond the included 2M.

**Not billed:** OPTIONS preflight requests, health checks.

**Tip:** CPU time is the binding constraint, not wall clock. Network I/O (awaiting fetch, DB queries) does not count toward the 2s CPU limit. A function that waits 30s for an external API but only does 50ms of CPU work is fine.
