# Platform Integrations

> Supabase client setup, auth flows, data access, and realtime patterns for Next.js SSR, React Native/Expo, Kotlin Android, and Swift iOS.

## Table of Contents

1. [Next.js SSR (`@supabase/ssr`)](#nextjs-ssr-supabasessr)
2. [React Native / Expo](#react-native--expo)
3. [Kotlin Android (`supabase-kt`)](#kotlin-android-supabase-kt)
4. [Swift iOS (`supabase-swift`)](#swift-ios-supabase-swift)
5. [Cross-platform considerations](#cross-platform-considerations)

---

## Next.js SSR (`@supabase/ssr`)

The `@supabase/ssr` package replaces the deprecated `@supabase/auth-helpers-nextjs`. It provides cookie-based session management that works across Server Components, Server Actions, Route Handlers, and Middleware.

### Client setup

Two client factories are required: one for browser (Client Components) and one for server (Server Components, Actions, Route Handlers).

**`lib/supabase/client.ts`** — Client Components:

```typescript
import { createBrowserClient } from '@supabase/ssr'

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!
  )
}
```

**`lib/supabase/server.ts`** — Server Components, Actions, Route Handlers:

```typescript
import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

export async function createClient() {
  const cookieStore = await cookies()

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll()
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            )
          } catch {
            // Called from a Server Component — cookie writes are ignored.
            // The Middleware `updateSession` handles the actual refresh.
          }
        },
      },
    }
  )
}
```

### Middleware auth pattern

Middleware refreshes auth tokens **before** Server Components render. Without it, a user's session can expire mid-request and Server Components will see a logged-out state.

**`lib/supabase/middleware.ts`**:

```typescript
import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

export async function updateSession(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          )
          supabaseResponse = NextResponse.next({ request })
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  // IMPORTANT: Do NOT use getSession() here. Only getUser() sends a request
  // to the Supabase Auth server to revalidate the token. getSession() reads
  // from local storage/cookies and can be spoofed.
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Route protection (optional — NOT a substitute for RLS or server-side checks)
  if (
    !user &&
    !request.nextUrl.pathname.startsWith('/login') &&
    !request.nextUrl.pathname.startsWith('/auth') &&
    !request.nextUrl.pathname.startsWith('/signup')
  ) {
    const url = request.nextUrl.clone()
    url.pathname = '/login'
    return NextResponse.redirect(url)
  }

  // CRITICAL: return the supabaseResponse, not a new NextResponse.
  // Failing to do so strips the refreshed auth cookies from the response.
  return supabaseResponse
}
```

**`middleware.ts`** (root):

```typescript
import { type NextRequest } from 'next/server'
import { updateSession } from '@/lib/supabase/middleware'

export async function middleware(request: NextRequest) {
  return await updateSession(request)
}

export const config = {
  matcher: [
    // Match all routes except static files, images, and favicon
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
```

- Middleware runs on **every matched request** — keep it fast
- Route protection in middleware is a UX convenience, not a security boundary
- Always enforce authorization at the data access layer (RLS policies, server-side checks)

### Auth callback route

Handles OAuth redirects, email confirmations, magic links, and password resets.

```typescript
// app/auth/callback/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url)
  const code = searchParams.get('code')
  const token_hash = searchParams.get('token_hash')
  const type = searchParams.get('type') as
    | 'signup'
    | 'recovery'
    | 'invite'
    | 'magiclink'
    | 'email'
    | null
  const next = searchParams.get('next') ?? '/'

  const supabase = await createClient()

  // Email OTP verification (magic links, email confirmations)
  if (token_hash && type) {
    await supabase.auth.verifyOtp({ type, token_hash })
  }

  // OAuth PKCE flow — exchange code for session
  if (code) {
    await supabase.auth.exchangeCodeForSession(code)
  }

  redirect(next)
}
```

### Server Actions

```typescript
'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'

export async function login(formData: FormData) {
  const supabase = await createClient()

  const { error } = await supabase.auth.signInWithPassword({
    email: formData.get('email') as string,
    password: formData.get('password') as string,
  })

  if (error) redirect('/error')

  revalidatePath('/', 'layout')
  redirect('/dashboard')
}

export async function signup(formData: FormData) {
  const supabase = await createClient()

  const { error } = await supabase.auth.signUp({
    email: formData.get('email') as string,
    password: formData.get('password') as string,
    options: {
      emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback`,
    },
  })

  if (error) redirect('/error')

  // User receives a confirmation email — redirect to a "check your inbox" page
  redirect('/auth/check-email')
}

export async function signInWithOAuth(provider: 'google' | 'github' | 'apple') {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.signInWithOAuth({
    provider,
    options: {
      redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback`,
    },
  })

  if (error) redirect('/error')
  if (data.url) redirect(data.url)
}

export async function logout() {
  const supabase = await createClient()
  await supabase.auth.signOut()
  revalidatePath('/', 'layout')
  redirect('/login')
}
```

### Realtime in Client Components

Pattern: fetch initial data server-side, pass as props, subscribe to changes client-side.

```typescript
// app/chat/page.tsx (Server Component)
import { createClient } from '@/lib/supabase/server'
import { RealtimeMessages } from './realtime-messages'

export default async function ChatPage() {
  const supabase = await createClient()
  const { data: messages } = await supabase
    .from('messages')
    .select('*')
    .order('created_at', { ascending: true })

  return <RealtimeMessages serverMessages={messages ?? []} />
}
```

```typescript
// app/chat/realtime-messages.tsx (Client Component)
'use client'

import { useEffect, useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import type { Message } from '@/types/database'

export function RealtimeMessages({ serverMessages }: { serverMessages: Message[] }) {
  const [messages, setMessages] = useState(serverMessages)
  const supabase = createClient()

  useEffect(() => {
    setMessages(serverMessages)
  }, [serverMessages])

  useEffect(() => {
    const channel = supabase
      .channel('realtime-messages')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'messages' },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            setMessages((prev) => [...prev, payload.new as Message])
          }
          if (payload.eventType === 'UPDATE') {
            setMessages((prev) =>
              prev.map((msg) =>
                msg.id === (payload.new as Message).id ? (payload.new as Message) : msg
              )
            )
          }
          if (payload.eventType === 'DELETE') {
            setMessages((prev) =>
              prev.filter((msg) => msg.id !== payload.old.id)
            )
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [supabase])

  return (
    <ul>
      {messages.map((msg) => (
        <li key={msg.id}>{msg.content}</li>
      ))}
    </ul>
  )
}
```

### ISR and static generation

- **Time-based revalidation**: `export const revalidate = 60` at the page or layout level
- **On-demand revalidation**: call `revalidatePath('/path')` or `revalidateTag('tag')` inside Server Actions or Route Handlers after mutations
- **Static generation at build time**: use the service role key (server-side only, never expose to client) to fetch data that bypasses RLS for public content
- **Streaming**: combine `<Suspense>` boundaries with Supabase queries in async Server Components for progressive rendering

```typescript
// Route Handler for on-demand revalidation via webhook
// app/api/revalidate/route.ts
import { revalidateTag } from 'next/cache'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  const secret = request.headers.get('x-webhook-secret')
  if (secret !== process.env.REVALIDATION_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await request.json()
  revalidateTag(body.tag)
  return NextResponse.json({ revalidated: true })
}
```

---

## React Native / Expo

### Client setup

```typescript
import 'react-native-url-polyfill/auto'
import AsyncStorage from '@react-native-async-storage/async-storage'
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY!

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false, // REQUIRED: prevents supabase-js from parsing the URL on native
  },
})
```

### Storage options

| Storage | When to use | Notes |
|---------|-------------|-------|
| `AsyncStorage` | Default, unencrypted | Simple key-value, good for most apps |
| `expo-secure-store` | Encrypted storage | 2KB value limit — tokens fit, large payloads do not |
| `LargeSecureStore` | Encrypted + large values | AES-encrypts data in AsyncStorage, stores AES key in SecureStore |
| `expo-sqlite` localStorage polyfill | SDK 50+ | SQLite-backed, synchronous API, good performance |

**LargeSecureStore adapter** (recommended for production):

```typescript
import * as SecureStore from 'expo-secure-store'
import * as aesjs from 'aes-js'
import AsyncStorage from '@react-native-async-storage/async-storage'

class LargeSecureStore {
  private async _encrypt(key: string, value: string) {
    const encryptionKey = crypto.getRandomValues(new Uint8Array(256 / 8))
    const cipher = new aesjs.ModeOfOperation.ctr(encryptionKey)
    const encryptedBytes = cipher.encrypt(aesjs.utils.utf8.toBytes(value))
    await SecureStore.setItemAsync(key, aesjs.utils.hex.fromBytes(encryptionKey))
    return aesjs.utils.hex.fromBytes(encryptedBytes)
  }

  private async _decrypt(key: string, value: string) {
    const encryptionKeyHex = await SecureStore.getItemAsync(key)
    if (!encryptionKeyHex) return null
    const cipher = new aesjs.ModeOfOperation.ctr(aesjs.utils.hex.toBytes(encryptionKeyHex))
    const decryptedBytes = cipher.decrypt(aesjs.utils.hex.toBytes(value))
    return aesjs.utils.utf8.fromBytes(decryptedBytes)
  }

  async getItem(key: string) {
    const encrypted = await AsyncStorage.getItem(key)
    if (!encrypted) return null
    return await this._decrypt(key, encrypted)
  }

  async setItem(key: string, value: string) {
    const encrypted = await this._encrypt(key, value)
    await AsyncStorage.setItem(key, encrypted)
  }

  async removeItem(key: string) {
    await AsyncStorage.removeItem(key)
    await SecureStore.deleteItemAsync(key)
  }
}
```

### OAuth with deep linking

```typescript
import { makeRedirectUri } from 'expo-auth-session'
import * as QueryParams from 'expo-auth-session/build/QueryParams'
import * as WebBrowser from 'expo-web-browser'

const redirectTo = makeRedirectUri()

async function signInWithOAuth(provider: 'google' | 'github' | 'apple') {
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider,
    options: {
      redirectTo,
      skipBrowserRedirect: true, // REQUIRED: we handle the redirect manually
    },
  })

  if (error || !data.url) throw error ?? new Error('No URL returned')

  const res = await WebBrowser.openAuthSessionAsync(data.url, redirectTo)

  if (res.type === 'success') {
    const { params } = QueryParams.getQueryParams(res.url)
    const { access_token, refresh_token } = params

    if (access_token && refresh_token) {
      await supabase.auth.setSession({ access_token, refresh_token })
    }
  }
}
```

**URL scheme** in `app.json`:

```json
{
  "expo": {
    "scheme": "com.yourapp",
    "plugins": [
      [
        "expo-build-properties",
        { "android": { "compileSdkVersion": 35, "targetSdkVersion": 35 } }
      ]
    ]
  }
}
```

**Native Google Sign-In** (better UX than web-based OAuth):

```typescript
import { GoogleSignin } from '@react-native-google-signin/google-signin'

GoogleSignin.configure({
  scopes: ['email', 'profile'],
  webClientId: 'YOUR_WEB_CLIENT_ID.apps.googleusercontent.com',
})

async function signInWithNativeGoogle() {
  await GoogleSignin.hasPlayServices()
  const userInfo = await GoogleSignin.signIn()
  const idToken = userInfo.data?.idToken

  if (!idToken) throw new Error('No ID token')

  const { data, error } = await supabase.auth.signInWithIdToken({
    provider: 'google',
    token: idToken,
  })

  return data
}
```

### AppState token refresh

Supabase auto-refresh runs on a timer, but mobile apps are frequently backgrounded. Pause and resume to avoid unnecessary network calls and ensure the token is fresh when returning.

```typescript
import { AppState } from 'react-native'

AppState.addEventListener('change', (state) => {
  if (state === 'active') {
    supabase.auth.startAutoRefresh()
  } else {
    supabase.auth.stopAutoRefresh()
  }
})
```

### Offline-first options

Supabase has **no built-in offline support**. For apps that must work without connectivity, pair Supabase with a local-first sync layer.

| Solution | Approach | Pros | Cons |
|----------|----------|------|------|
| **PowerSync** | WAL-based sync to SQLite | Plug-and-play with Supabase, conflict resolution included | Additional service cost, vendor dependency |
| **WatermelonDB** | Local SQLite + sync via Supabase RPC | Fast local reads, mature library | Complex sync logic you must write, schema drift risk |
| **Legend-State** | Observable state with `syncedSupabase` plugin | Simple API, fine-grained reactivity | Less mature sync, limited conflict handling |
| **RxDB** | Supabase replication plugin | Flexible replication protocol, multi-tab support | Larger bundle size, learning curve |
| **expo-sqlite + custom sync** | Manual queue + batch upsert | Full control, no extra dependencies | Must build conflict resolution, retry logic, queue management |

Recommended approach for most apps: **PowerSync** for true offline-first, or a simple **optimistic UI + retry queue** if you only need to handle brief connectivity gaps.

---

## Kotlin Android (`supabase-kt`)

Community-maintained SDK (`io.github.jan-tennert.supabase`) with full Kotlin Multiplatform support: Android, iOS, JVM, JS, Wasm. Latest stable: 3.x series.

### Gradle setup

```kotlin
// build.gradle.kts (module)
plugins {
    kotlin("plugin.serialization") version "2.1.0"
}

dependencies {
    // BOM for consistent versions
    implementation(platform("io.github.jan-tennert.supabase:bom:3.1.1"))
    implementation("io.github.jan-tennert.supabase:postgrest-kt")
    implementation("io.github.jan-tennert.supabase:auth-kt")
    implementation("io.github.jan-tennert.supabase:realtime-kt")
    implementation("io.github.jan-tennert.supabase:storage-kt")
    implementation("io.github.jan-tennert.supabase:functions-kt")

    // Ktor engine (pick one)
    implementation("io.ktor:ktor-client-okhttp:3.1.1")
}
```

### Client initialization

```kotlin
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.FlowType
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.realtime.Realtime
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.functions.Functions

val supabase = createSupabaseClient(
    supabaseUrl = BuildConfig.SUPABASE_URL,
    supabaseKey = BuildConfig.SUPABASE_KEY
) {
    install(Auth) {
        flowType = FlowType.PKCE
        scheme = "your-app"
        host = "callback"
    }
    install(Postgrest)
    install(Realtime)
    install(Storage)
    install(Functions)
}
```

### Data models with KotlinX Serialization

```kotlin
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName

@Serializable
data class Item(
    val id: String,
    val name: String,
    @SerialName("created_at") val createdAt: String,
    @SerialName("user_id") val userId: String? = null,
)
```

### Auth

```kotlin
// Email/password
suspend fun signIn(email: String, password: String) {
    supabase.auth.signInWith(Email) {
        this.email = email
        this.password = password
    }
}

suspend fun signUp(email: String, password: String) {
    supabase.auth.signUpWith(Email) {
        this.email = email
        this.password = password
    }
}

// OAuth (opens Chrome Custom Tab)
suspend fun signInWithGoogle() {
    supabase.auth.signInWith(Google)
}

// Observe session state
val sessionStatus: Flow<SessionStatus> = supabase.auth.sessionStatus
// SessionStatus values: Authenticated, NotAuthenticated, LoadingFromStorage, NetworkError
```

**Session status in Compose**:

```kotlin
@Composable
fun AuthGate() {
    val sessionStatus by supabase.auth.sessionStatus.collectAsState()

    when (sessionStatus) {
        is SessionStatus.Authenticated -> MainScreen()
        is SessionStatus.NotAuthenticated -> LoginScreen()
        is SessionStatus.LoadingFromStorage -> LoadingIndicator()
        is SessionStatus.NetworkError -> OfflineScreen()
    }
}
```

### Database CRUD

```kotlin
// Select all
val items: List<Item> = supabase.from("items")
    .select()
    .decodeList<Item>()

// Select with filters
val activeItems: List<Item> = supabase.from("items")
    .select {
        filter {
            eq("status", "active")
            gte("created_at", "2026-01-01")
        }
        order("created_at", Order.DESCENDING)
        limit(20)
    }
    .decodeList<Item>()

// Select single
val item: Item = supabase.from("items")
    .select { filter { eq("id", itemId) } }
    .decodeSingle<Item>()

// Insert
supabase.from("items").insert(item)

// Upsert
supabase.from("items").upsert(item)

// Update
supabase.from("items").update({
    set("name", "updated name")
    set("status", "archived")
}) {
    filter { eq("id", itemId) }
}

// Delete
supabase.from("items").delete {
    filter { eq("id", itemId) }
}
```

### Realtime

```kotlin
// Realtime via Kotlin Flow (recommended for Compose)
val messagesFlow: Flow<List<Message>> = supabase.from("messages")
    .selectAsFlow(Message::id)

// Manual channel subscription
val channel = supabase.channel("room-1")
val changeFlow = channel.postgresChangeFlow<PostgresAction.Insert>(schema = "public") {
    table = "messages"
}

// Collect in a coroutine
scope.launch {
    changeFlow.collect { change ->
        val message = change.decodeRecord<Message>()
        // Handle new message
    }
}
channel.subscribe()
```

### Compose Auth plugin

```kotlin
// One-tap Google sign-in composable
@Composable
fun GoogleSignInButton() {
    val action = supabase.composeAuth.rememberSignInWithGoogle(
        onResult = { result ->
            when (result) {
                is NativeSignInResult.Success -> { /* Navigate */ }
                is NativeSignInResult.Error -> { /* Show error */ }
                is NativeSignInResult.ClosedByUser -> { /* Dismissed */ }
                else -> {}
            }
        }
    )

    Button(onClick = { action.startFlow() }) {
        Text("Sign in with Google")
    }
}
```

### Coil3 integration for Storage images

```kotlin
// Authenticated image loading from Supabase Storage
AsyncImage(
    model = supabase.storage
        .from("avatars")
        .authenticatedUrl("user-avatar.png"),
    contentDescription = "Avatar",
    modifier = Modifier.size(48.dp)
)
```

---

## Swift iOS (`supabase-swift`)

Officially maintained by Supabase. Latest: v2.x series. Supports iOS 13+, macOS 10.15+, tvOS 13+, watchOS 6+, visionOS 1+.

### Setup

**Swift Package Manager** (recommended):

```
https://github.com/supabase/supabase-swift
```

Add to `Package.swift` or via Xcode > File > Add Package Dependencies.

```swift
import Supabase

let supabase = SupabaseClient(
    supabaseURL: URL(string: "https://xyzcompany.supabase.co")!,
    supabaseKey: "public-anon-key"
)
```

- Session is stored in **Keychain** by default (encrypted, persists across app launches)
- The client is thread-safe and should be created once (singleton or environment object)

### Auth

```swift
// Sign up
try await supabase.auth.signUp(
    email: "user@example.com",
    password: "securepassword"
)

// Sign in with email/password
try await supabase.auth.signIn(
    email: "user@example.com",
    password: "securepassword"
)

// OAuth (opens ASWebAuthenticationSession)
try await supabase.auth.signInWithOAuth(.google) {
    $0.redirectTo = URL(string: "your-app://callback")
}

// Native Apple Sign-In
import AuthenticationServices

func handleAppleSignIn(_ authorization: ASAuthorization) async throws {
    guard let credential = authorization.credential as? ASAuthorizationAppleIDCredential,
          let idToken = credential.identityToken.flatMap({ String(data: $0, encoding: .utf8) })
    else { throw AuthError.missingToken }

    try await supabase.auth.signInWithIdToken(
        credentials: .init(
            provider: .apple,
            idToken: idToken
        )
    )
}

// Sign out
try await supabase.auth.signOut()
```

### Auth state observation

```swift
// AsyncSequence-based (recommended)
Task {
    for await (event, session) in supabase.auth.authStateChanges {
        switch event {
        case .initialSession:
            // App launch — session may be nil (logged out) or valid (logged in)
            updateUI(session: session)
        case .signedIn:
            navigateToDashboard()
        case .signedOut:
            navigateToLogin()
        case .tokenRefreshed:
            break // Usually no UI change needed
        case .userUpdated:
            refreshProfile()
        default:
            break
        }
    }
}
```

### Deep link handling (SwiftUI)

```swift
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .onOpenURL { url in
                    Task {
                        try await supabase.auth.session(from: url)
                    }
                }
        }
    }
}
```

- Register your URL scheme in Xcode > Target > Info > URL Types
- For universal links, configure the associated domains entitlement and `apple-app-site-association` file

### Database CRUD

```swift
// Define Codable models matching your table schema
struct Item: Codable, Identifiable, Sendable {
    let id: UUID
    var name: String
    let createdAt: Date

    enum CodingKeys: String, CodingKey {
        case id, name
        case createdAt = "created_at"
    }
}

// Select all
let items: [Item] = try await supabase
    .from("items")
    .select()
    .execute()
    .value

// Select with filters
let activeItems: [Item] = try await supabase
    .from("items")
    .select()
    .eq("status", value: "active")
    .gte("created_at", value: "2026-01-01")
    .order("created_at", ascending: false)
    .limit(20)
    .execute()
    .value

// Select single
let item: Item = try await supabase
    .from("items")
    .select()
    .eq("id", value: itemId)
    .single()
    .execute()
    .value

// Insert
try await supabase
    .from("items")
    .insert(item)
    .execute()

// Upsert
try await supabase
    .from("items")
    .upsert(item)
    .execute()

// Update
try await supabase
    .from("items")
    .update(["name": "updated name"])
    .eq("id", value: itemId)
    .execute()

// Delete
try await supabase
    .from("items")
    .delete()
    .eq("id", value: itemId)
    .execute()
```

### Realtime

```swift
// Subscribe to INSERT events on a table
let channel = supabase.channel("public:messages")

let changes = channel.postgresChange(
    InsertAction.self,
    schema: "public",
    table: "messages"
)

await channel.subscribe()

for await change in changes {
    let message = try change.decodeRecord(as: Message.self, decoder: JSONDecoder())
    print("New message: \(message.content)")
}

// Subscribe to all change types
let allChanges = channel.postgresChange(
    AnyAction.self,
    schema: "public",
    table: "messages"
)

for await change in allChanges {
    switch change {
    case let action as InsertAction:
        let record = try action.decodeRecord(as: Message.self, decoder: JSONDecoder())
        messages.append(record)
    case let action as UpdateAction:
        let record = try action.decodeRecord(as: Message.self, decoder: JSONDecoder())
        if let idx = messages.firstIndex(where: { $0.id == record.id }) {
            messages[idx] = record
        }
    case let action as DeleteAction:
        let oldRecord = try action.decodeOldRecord(as: Message.self, decoder: JSONDecoder())
        messages.removeAll { $0.id == oldRecord.id }
    default:
        break
    }
}
```

### SwiftUI integration pattern

```swift
@Observable
final class MessagesViewModel {
    var messages: [Message] = []
    var isLoading = false
    private var channelTask: Task<Void, Never>?

    func load() async {
        isLoading = true
        defer { isLoading = false }

        do {
            messages = try await supabase
                .from("messages")
                .select()
                .order("created_at")
                .execute()
                .value
        } catch {
            // Handle error
        }
    }

    func startRealtime() {
        channelTask = Task {
            let channel = supabase.channel("messages-feed")
            let inserts = channel.postgresChange(InsertAction.self, schema: "public", table: "messages")

            await channel.subscribe()

            for await change in inserts {
                if let message = try? change.decodeRecord(as: Message.self, decoder: JSONDecoder()) {
                    await MainActor.run {
                        messages.append(message)
                    }
                }
            }
        }
    }

    func stopRealtime() {
        channelTask?.cancel()
        channelTask = nil
    }
}
```

---

## Cross-platform considerations

- **Environment variables**: each platform has its own convention (`NEXT_PUBLIC_` for Next.js, `EXPO_PUBLIC_` for Expo, `BuildConfig` for Android, xcconfig/Info.plist for iOS). Never hardcode keys.
- **RLS is your security boundary**: client-side route guards, middleware redirects, and native auth gates are UX features, not security. Always rely on Row Level Security policies and `auth.uid()` in Postgres.
- **Token refresh**: Next.js handles it in Middleware, Expo via AppState listener, supabase-kt and supabase-swift handle it automatically but verify behavior when apps resume from background.
- **Realtime across platforms**: enable the Realtime publication on your tables (`alter publication supabase_realtime add table messages`). Each platform's channel API is similar but uses language-idiomatic patterns (callbacks in JS, Flows in Kotlin, AsyncSequence in Swift).
- **Type generation**: use `supabase gen types typescript` for TS projects. For Kotlin/Swift, manually define `@Serializable`/`Codable` models matching your schema, or use tooling to generate them from the OpenAPI spec.
