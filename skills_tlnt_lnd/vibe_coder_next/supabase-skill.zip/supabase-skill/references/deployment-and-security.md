# Deployment, Security & Ecosystem

> Supabase deployment options, CI/CD pipelines, security hardening, pricing, breaking changes, and ecosystem positioning.

## Table of Contents

1. [Cloud Plans (Hosted)](#cloud-plans-hosted)
2. [Self-Hosted (Docker Compose)](#self-hosted-docker-compose)
3. [CI/CD with GitHub Actions](#cicd-with-github-actions)
4. [Security Hardening](#security-hardening)
5. [Launch Weeks Timeline](#launch-weeks-timeline)
6. [Breaking Changes to Watch](#breaking-changes-to-watch)
7. [Ecosystem Positioning](#ecosystem-positioning)

---

## Cloud Plans (Hosted)

| Plan       | Price     | Database | Storage | MAUs    | Egress  |
|------------|-----------|----------|---------|---------|---------|
| Free       | $0        | 500 MB   | 1 GB    | 50K     | 5 GB    |
| Pro        | $25/mo    | 8 GB     | 100 GB  | 100K    | 250 GB  |
| Team       | $599/mo   | Enhanced | Enhanced| Enhanced| Enhanced|
| Enterprise | Custom    | Custom   | Custom  | Custom  | Custom  |

- Free tier pauses after **1 week of inactivity** — connections drop, data retained
- Pro includes **$10 compute credit** (covers Micro instance: 2-core ARM, 1 GB RAM)
- **17 AWS regions** available; select at project creation (cannot change later)
- Custom domains available on paid plans (`your-domain.com` instead of `*.supabase.co`)
- IPv4 add-on: **$4/month** per project (IPv6 is default)
- PITR (Point-in-Time Recovery): Pro = 7 days, Team = 28 days
- Management API: `https://api.supabase.com/v1/` — 120 requests/minute rate limit
- Database add-ons: compute upgrades ($25–$2,570/mo), disk IOPS/throughput scaling
- Free tier limit: **2 active projects** per organization, 0.5 GB database per project

---

## Self-Hosted (Docker Compose)

```bash
git clone --depth 1 https://github.com/supabase/supabase
cd supabase/docker
cp .env.example .env

# CRITICAL: Replace ALL default secrets before starting
# Generate secure values:
#   openssl rand -hex 32          → POSTGRES_PASSWORD
#   supabase gen keys --experimental → JWT_SECRET, ANON_KEY, SERVICE_ROLE_KEY

docker compose up -d
```

### Minimum Requirements

- **8 GB RAM**, **25 GB SSD**, **2 vCPUs** (bare minimum for all services)
- Production recommendation: 16 GB RAM, 100 GB SSD, 4 vCPUs

### Service Architecture

| Service       | Default Port | Description                        |
|---------------|--------------|------------------------------------|
| Studio        | 3000         | Dashboard UI                       |
| Kong          | 8000         | API Gateway (routes to services)   |
| GoTrue        | 9999         | Auth service (JWT issuer)          |
| PostgREST     | 3000 (internal) | Auto-generated REST API         |
| Realtime      | 4000         | WebSocket channels + Presence      |
| Storage       | 5000         | S3-compatible object storage       |
| imgproxy      | 5001         | Image transformation               |
| pg_meta       | 8080         | Postgres metadata API (for Studio) |
| PostgreSQL    | 5432         | Database                           |
| Edge Runtime  | 8081         | Deno-based Edge Functions           |
| Analytics     | 4000 (logflare) | Log ingestion (BigQuery/Postgres) |
| Supavisor     | 6543         | Connection pooler (transaction mode)|

### Production Hardening

```bash
# 1. Reverse proxy with SSL (Caddy example)
# Caddyfile
your-domain.com {
    reverse_proxy localhost:8000
}

# 2. SMTP configuration (in .env)
SMTP_HOST=email-smtp.us-east-1.amazonaws.com
SMTP_PORT=587
SMTP_USER=AKIA...
SMTP_PASS=...
SMTP_SENDER_NAME=YourApp
SMTP_ADMIN_EMAIL=admin@your-domain.com

# 3. S3-compatible storage backend (in .env)
STORAGE_BACKEND=s3
GLOBAL_S3_BUCKET=your-bucket
GLOBAL_S3_ENDPOINT=https://s3.amazonaws.com
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
```

### Limitations vs Cloud

- No automatic scaling or burst capacity
- No database branching (preview environments)
- No Log Explorer (must configure analytics separately)
- Manual backup management (pg_dump/pg_basebackup)
- No automatic security patches — you manage upgrades
- No Supabase support SLA

---

## CI/CD with GitHub Actions

### Basic Deploy Pipeline

```yaml
name: Deploy Supabase
on:
  push:
    branches: [main]

env:
  SUPABASE_ACCESS_TOKEN: ${{ secrets.SUPABASE_ACCESS_TOKEN }}
  SUPABASE_DB_PASSWORD: ${{ secrets.SUPABASE_DB_PASSWORD }}

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: supabase/setup-cli@v1
        with:
          version: latest

      - name: Link project
        run: supabase link --project-ref ${{ secrets.SUPABASE_PROJECT_ID }}

      - name: Push migrations
        run: supabase db push

      - name: Deploy Edge Functions
        run: supabase functions deploy
```

### Full CI/CD Pipeline (Lint, Test, Type Gen, Deploy)

```yaml
name: Supabase CI/CD
on:
  push:
    branches: [main, staging]
  pull_request:
    branches: [main]

env:
  SUPABASE_ACCESS_TOKEN: ${{ secrets.SUPABASE_ACCESS_TOKEN }}

jobs:
  lint-and-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: supabase/setup-cli@v1

      - name: Start local Supabase
        run: supabase start

      - name: Lint migrations
        run: supabase db lint --level warning

      - name: Run pgTAP tests
        run: supabase test db

      - name: Run Edge Function tests
        run: |
          deno test --allow-all supabase/functions/tests/

      - name: Generate TypeScript types
        run: |
          supabase gen types typescript --local > src/lib/database.types.ts

      - name: Check types unchanged
        run: |
          git diff --exit-code src/lib/database.types.ts || \
            (echo "ERROR: Generated types differ from committed. Run 'supabase gen types' locally." && exit 1)

      - name: Stop local Supabase
        run: supabase stop

  deploy-staging:
    needs: lint-and-test
    if: github.ref == 'refs/heads/staging'
    runs-on: ubuntu-latest
    environment: staging
    steps:
      - uses: actions/checkout@v4
      - uses: supabase/setup-cli@v1
      - run: supabase link --project-ref ${{ secrets.STAGING_PROJECT_ID }}
      - run: supabase db push
      - run: supabase functions deploy

  deploy-production:
    needs: lint-and-test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production
    steps:
      - uses: actions/checkout@v4
      - uses: supabase/setup-cli@v1
      - run: supabase link --project-ref ${{ secrets.PRODUCTION_PROJECT_ID }}
      - run: supabase db push
      - run: supabase functions deploy
```

### Preview Branches with Supabase Branching

```yaml
name: Preview Branch
on:
  pull_request:
    types: [opened, synchronize, reopened]

env:
  SUPABASE_ACCESS_TOKEN: ${{ secrets.SUPABASE_ACCESS_TOKEN }}

jobs:
  preview:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: supabase/setup-cli@v1

      # Branching is built-in via GitHub integration
      # Each PR automatically gets a preview branch with:
      # - Isolated database with migrations applied
      # - Separate API URL and keys
      # Enable in Dashboard > Settings > Integrations > GitHub

      - name: Wait for preview branch
        run: |
          # The GitHub integration handles branch creation automatically
          # PR comments show: preview URL, anon key, status
          echo "Preview branch created by Supabase GitHub integration"

      - name: Run tests against preview
        run: |
          PREVIEW_URL=$(supabase branches get --project-ref ${{ secrets.PROJECT_ID }} \
            --name pr-${{ github.event.number }} --output json | jq -r '.api_url')
          echo "SUPABASE_URL=$PREVIEW_URL" >> $GITHUB_ENV
```

- **Branching requirements**: Pro plan or higher, GitHub integration enabled
- Each PR gets an isolated Postgres branch with migrations applied
- Auto-merged on PR merge, auto-deleted on PR close
- PR comments include preview URL, status, and migration diff

---

## Security Hardening

### API Key Management

```
anon key (sb_publishable_...)
├── Safe for client-side code (browsers, mobile apps)
├── Acts as project identifier + RLS policy subject
├── All requests go through RLS — key alone grants nothing
└── Rotate: Dashboard > Settings > API > Regenerate

service_role key (sb_secret_...)
├── Bypasses ALL Row Level Security
├── NEVER expose in client code, bundle, or version control
├── Server-side only: API routes, Edge Functions, cron jobs
└── Treat as database root password
```

```typescript
// CORRECT: Client uses anon key (RLS enforced)
import { createClient } from '@supabase/supabase-js';
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!   // publishable — safe
);

// CORRECT: Server uses service_role (RLS bypassed)
const supabaseAdmin = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,       // secret — server only
  { auth: { autoRefreshToken: false, persistSession: false } }
);
```

### RLS as the Security Layer

**Rule: Enable RLS on EVERY table in the `public` schema. No exceptions.**

```sql
-- Dashboard-created tables: RLS auto-enabled
-- SQL Editor tables: NOT auto-enabled — you MUST do this:
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Without RLS + anon key = full public read/write access
-- This is the #1 Supabase security mistake

-- Views: use security_invoker (Postgres 15+)
CREATE VIEW public.active_users
  WITH (security_invoker = true) AS
  SELECT id, display_name FROM profiles WHERE active = true;

-- Sensitive tables: put in non-exposed schemas
CREATE SCHEMA private;
CREATE TABLE private.internal_config (...);
-- PostgREST only exposes schemas listed in PGRST_DB_SCHEMAS (default: public)
```

### Multi-Tenant Architecture (Shared Tables Pattern)

```sql
-- 1. Add tenant_id to all tenant-scoped tables
CREATE TABLE public.documents (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id  uuid NOT NULL REFERENCES public.tenants(id),
  title      text NOT NULL,
  content    text,
  created_by uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

-- 2. Index for performance (every tenant query filters on this)
CREATE INDEX idx_documents_tenant ON public.documents (tenant_id);

-- 3. Store tenant_id in app_metadata (NOT user_metadata — users can edit that)
-- Set on signup or invite via service_role:
-- supabaseAdmin.auth.admin.updateUserById(userId, {
--   app_metadata: { tenant_id: 'abc-123' }
-- })

-- 4. RLS policy using JWT claim
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "tenant_isolation" ON public.documents
  FOR ALL
  USING (
    tenant_id = (
      (SELECT auth.jwt()) -> 'app_metadata' ->> 'tenant_id'
    )::uuid
  )
  WITH CHECK (
    tenant_id = (
      (SELECT auth.jwt()) -> 'app_metadata' ->> 'tenant_id'
    )::uuid
  );

-- 5. Helper function to avoid repetition
CREATE OR REPLACE FUNCTION public.current_tenant_id()
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  SELECT ((SELECT auth.jwt()) -> 'app_metadata' ->> 'tenant_id')::uuid;
$$;

-- Simplified policy using helper:
CREATE POLICY "tenant_isolation_v2" ON public.documents
  FOR ALL
  USING (tenant_id = public.current_tenant_id())
  WITH CHECK (tenant_id = public.current_tenant_id());
```

**Other multi-tenant strategies**:
- **Schema-per-tenant**: Maximum compliance isolation, higher operational overhead
- **Project-per-tenant**: Via Management API, ultimate isolation, highest cost

### pgTAP Test: Multi-Tenant RLS

```sql
-- supabase/tests/tenant_isolation_test.sql
BEGIN;
SELECT plan(4);

-- Create test tenants and users
SELECT tests.create_supabase_user('user_a', 'a@test.com',
  '{"tenant_id": "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"}');
SELECT tests.create_supabase_user('user_b', 'b@test.com',
  '{"tenant_id": "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"}');

-- Insert as user_a
SELECT tests.authenticate_as('user_a');

INSERT INTO public.documents (tenant_id, title, created_by)
VALUES (
  'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
  'Tenant A Doc',
  tests.get_supabase_uid('user_a')
);

SELECT results_eq(
  $$ SELECT count(*)::int FROM public.documents $$,
  $$ SELECT 1 $$,
  'User A sees their own document'
);

-- Switch to user_b
SELECT tests.authenticate_as('user_b');

SELECT results_eq(
  $$ SELECT count(*)::int FROM public.documents $$,
  $$ SELECT 0 $$,
  'User B sees no documents from Tenant A'
);

-- User B cannot insert into Tenant A
SELECT throws_ok(
  $$ INSERT INTO public.documents (tenant_id, title, created_by)
     VALUES ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'Hack', tests.get_supabase_uid('user_b')) $$,
  'new row violates row-level security policy',
  'User B cannot write to Tenant A'
);

-- User B can insert into their own tenant
SELECT lives_ok(
  $$ INSERT INTO public.documents (tenant_id, title, created_by)
     VALUES ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'Tenant B Doc', tests.get_supabase_uid('user_b')) $$,
  'User B can write to their own tenant'
);

SELECT tests.clear_authentication();
SELECT * FROM finish();
ROLLBACK;
```

### Additional Security Measures

- **Network restrictions**: Database accessible only via Supabase API by default; direct connections require explicit allow-listing
- **SSL enforcement**: Always enabled on cloud; enforce `sslmode=verify-full` for direct connections
- **MFA**: Enable in Dashboard > Auth > MFA; supports TOTP, SMS, WhatsApp (phone requires Twilio)
- **Leaked key detection**: Supabase partners with GitHub secret scanning; rotate immediately if notified
- **Security Advisor**: Dashboard > Advisors > Security — checks for missing RLS, weak auth config, exposed keys

---

## Launch Weeks Timeline

| Event           | Date             | Key Features                                                                                  |
|-----------------|------------------|-----------------------------------------------------------------------------------------------|
| GA Week         | April 2024       | General availability, branching on Pro, index_advisor, anonymous sign-ins, Swift SDK official  |
| Launch Week 12  | August 2024      | postgres.new, Realtime Authorization, Python SDK, third-party auth, MFA SMS/WhatsApp          |
| Launch Week 13  | Late 2024        | CLI v2 (config as code), Supabase Modules (Cron/Queues), pgmq                                |
| Launch Week 14  | March-April 2025 | MCP Server, UI Library (shadcn), Postgres Language Server, Clerk integration, Deno 2.1        |
| Launch Week 15  | July 2025        | Search, 500 GB uploads, S3 mounts in Edge Functions, Security Center, Stripe Sync Engine, RS256 default |
| Late 2025       | Late 2025        | Supabase as Identity Provider (OAuth 2.1 + OIDC), PostgREST v14, pg_graphql disabled by default |

---

## Breaking Changes to Watch

1. **`current_setting('app.settings.jwt_secret')` removed** (Nov 2024) — use `auth.jwt()` helper or Vault instead
2. **pg_graphql disabled by default** on new projects (late 2025) — enable manually if needed: `ALTER SYSTEM SET pgrst.db_schemas = 'public, graphql_public';`
3. **Asymmetric JWT keys (RS256) default** from May 2025 — existing HS256 projects unaffected, new projects use RS256; update JWT verification logic
4. **New API key format**: `sb_publishable_xxx` / `sb_secret_xxx` replacing legacy format — transition period active, both formats work
5. **Free tier restrictions**: 0.5 GB per project, pauses after 1 week inactivity, 2 active projects max
6. **Supavisor connection pooler**: port `5432` = session mode (for migrations), port `6543` = transaction mode (for application queries) — do not use prepared statements in transaction mode

---

## Ecosystem Positioning

### Strengths

- Full SQL power (PostgreSQL with extensions, not a proprietary query language)
- Open source (MIT license for client libs, Apache 2.0 for platform)
- Self-hostable with Docker Compose (no vendor lock-in)
- Integrated AI/vector search (pgvector, pg_embedding) without external services
- Growing enterprise features: SOC 2 Type II, HIPAA BAA (Enterprise plan)
- RLS is more granular and auditable than Firebase Security Rules
- Row-level computed policies vs Firebase's path-based rules

### Limitations

- No built-in horizontal sharding (vs PlanetScale/CockroachDB/Citus)
- Less mature mobile SDKs (vs Firebase's decade of mobile-first development)
- No scale-to-zero compute (vs Neon's auto-suspend, Turso's embedded replicas)
- Edge Functions are TypeScript/Deno only (vs Appwrite's multi-language runtimes)
- Realtime has connection limits (200 concurrent on Free, 500 on Pro per project)
- No built-in full-text search UI (must build on top of `tsvector` or pg_search)

### Comparison Table

| Feature        | Supabase                  | Firebase                 | Convex                   | Neon                  | Appwrite               |
|----------------|---------------------------|--------------------------|--------------------------|-----------------------|-------------------------|
| Database       | PostgreSQL (relational)   | Firestore (NoSQL)        | Document-relational      | PostgreSQL            | MariaDB                 |
| Auth           | Built-in (GoTrue)         | Built-in                 | Clerk / built-in         | External              | Built-in                |
| Realtime       | Channels + Broadcast      | Snapshots + Listeners    | Live queries (automatic) | External (logical replication) | Channels       |
| Functions      | Deno Edge Functions       | Cloud Functions (Node)   | Queries / mutations      | External              | Multiple runtimes       |
| File storage   | S3-compatible + transforms| Cloud Storage + CDN      | Built-in                 | External              | Built-in                |
| Self-host      | Yes (Docker Compose)      | No                       | No                       | No                    | Yes (Docker)            |
| Open source    | Yes (Apache 2.0)          | No                       | Partial (client libs)    | Yes (Apache 2.0)      | Yes (BSD-3)             |
| Vector / AI    | pgvector native           | Vertex AI integration    | Built-in search          | pgvector native       | No native               |
| Scale-to-zero  | No                        | Yes (Firestore)          | Yes                      | Yes                   | No                      |
| Pricing model  | Per-project + usage       | Pay-as-you-go            | Per-project + usage      | Compute + storage     | Per-project + usage     |

### Market Position

- Raised **$80M Series C** (total funding: $196M)
- Enterprise customers include Mozilla, 1Password, PwC, Krea AI
- 75,000+ active databases, 300M+ API requests/day (as of mid-2025)
- Positioned as the **open-source Firebase alternative** with full SQL capabilities
- Key differentiator: PostgreSQL ecosystem (30+ years of extensions, tooling, talent pool)
