# AI & Vectors

## Table of Contents

1. [pgvector Setup](#pgvector-setup)
2. [Indexing Strategies](#indexing-strategies)
3. [Similarity Search Function](#similarity-search-function)
4. [RAG Patterns](#rag-patterns)
5. [Automatic Embeddings Pipeline](#automatic-embeddings-pipeline)
6. [Hybrid Search](#hybrid-search)
7. [AI Dashboard Features](#ai-dashboard-features)
8. [Choosing Embedding Models](#choosing-embedding-models)
9. [Performance Tips](#performance-tips)

---

## pgvector Setup

Enable the `vector` extension and create a table with an embedding column:

```sql
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE documents (
  id bigserial PRIMARY KEY,
  content text,
  metadata jsonb,
  embedding vector(1536)
);
```

Use `halfvec(1536)` instead of `vector(1536)` for half-precision storage (50% less disk, minimal quality loss).

### Distance Operators

| Operator | Distance Metric | Index Ops Class | Use When |
|----------|----------------|-----------------|----------|
| `<->` | L2 / Euclidean | `vector_l2_ops` | Embeddings are NOT normalized; you care about absolute magnitude differences |
| `<=>` | Cosine | `vector_cosine_ops` | Default choice; works with any embeddings regardless of normalization |
| `<#>` | Inner Product (negative) | `vector_ip_ops` | Embeddings are pre-normalized (equivalent to cosine but slightly faster) |

Cosine distance (`<=>`) is the safest default. Use inner product only when you control normalization. L2 is useful for image embeddings or when magnitude carries meaning.

---

## Indexing Strategies

### HNSW (Recommended)

```sql
CREATE INDEX ON documents USING hnsw (embedding vector_cosine_ops)
WITH (m = 16, ef_construction = 64);
```

- **Auto-updates** as rows are inserted/updated/deleted -- no manual rebuilds needed
- Max dimensions: 2000 for `vector`, 4000 for `halfvec`
- `m` controls graph connectivity: higher = better recall but more memory (default 16, range 2-100)
- `ef_construction` controls build-time search depth: higher = better index quality but slower builds (default 64, range 4-1000)
- Query-time tuning for recall vs speed:

```sql
SET hnsw.ef_search = 100;  -- default 40; increase for better recall, decrease for speed
```

HNSW is preferred for most workloads: good recall, reasonable build time, and automatic maintenance.

### IVFFlat

```sql
CREATE INDEX ON documents USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 100);
```

- **Build AFTER data exists** -- needs representative data to create good cluster centroids
- Rule of thumb: `lists` = `rows / 1000` for up to 1M rows, `sqrt(rows)` for more
- Query-time tuning:

```sql
SET ivfflat.probes = 10;  -- default 1; higher = better recall, slower queries
```

**When to use IVFFlat over HNSW**: IVFFlat uses less memory and builds faster on very large datasets (10M+ rows). Use HNSW for everything else -- it provides better recall at the same speed and does not require rebuilding after significant data changes.

---

## Similarity Search Function

```sql
CREATE OR REPLACE FUNCTION match_documents(
  query_embedding vector(1536),
  match_threshold float DEFAULT 0.78,
  match_count int DEFAULT 10
)
RETURNS SETOF documents
LANGUAGE sql
STABLE
AS $$
  SELECT *
  FROM documents
  WHERE embedding <=> query_embedding < 1 - match_threshold
  ORDER BY embedding <=> query_embedding
  LIMIT match_count;
$$;
```

The threshold is a similarity score (0 to 1). Cosine distance = `1 - similarity`, so `< 1 - match_threshold` filters to results above the similarity threshold.

Call from the client SDK:

```typescript
const { data, error } = await supabase.rpc('match_documents', {
  query_embedding: embedding,  // float[] from your embedding model
  match_threshold: 0.78,
  match_count: 10,
});
```

This function is `SECURITY INVOKER` by default, which means RLS policies on `documents` are enforced automatically. Users only see documents they have access to -- no extra filtering needed.

---

## RAG Patterns

### Standard RAG Workflow

1. **Chunk** source documents into passages (500-1000 tokens each, with overlap)
2. **Embed** each chunk via your embedding model and store in the `embedding` column
3. **On query**: embed the user's question with the same model
4. **Search**: call `match_documents()` to retrieve the top-k relevant chunks
5. **Generate**: pass retrieved chunks as context to your LLM

RLS applies to vector tables, so RAG is automatically permission-scoped -- a user's query only retrieves documents they can access.

### Complete RAG Edge Function

```typescript
import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

const openai = new OpenAI({ apiKey: Deno.env.get('OPENAI_API_KEY')! });

Deno.serve(async (req) => {
  const { query } = await req.json();

  // 1. Generate embedding for the user query
  const embeddingResponse = await openai.embeddings.create({
    model: 'text-embedding-3-small',
    input: query,
  });
  const queryEmbedding = embeddingResponse.data[0].embedding;

  // 2. Retrieve relevant documents via similarity search
  const { data: documents, error } = await supabase.rpc('match_documents', {
    query_embedding: queryEmbedding,
    match_threshold: 0.78,
    match_count: 5,
  });

  if (error) throw error;

  // 3. Build context from retrieved documents
  const context = documents
    .map((doc: { content: string }) => doc.content)
    .join('\n\n---\n\n');

  // 4. Generate answer with LLM
  const completion = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [
      {
        role: 'system',
        content: `You are a helpful assistant. Answer based on the provided context only. If the context doesn't contain the answer, say so.\n\nContext:\n${context}`,
      },
      { role: 'user', content: query },
    ],
  });

  return new Response(
    JSON.stringify({ answer: completion.choices[0].message.content }),
    { headers: { 'Content-Type': 'application/json' } }
  );
});
```

---

## Automatic Embeddings Pipeline

Use a database trigger + `pgmq` message queue + Edge Function to embed documents automatically on insert or update.

### 1. Queue Trigger

```sql
-- Enable pgmq
CREATE EXTENSION IF NOT EXISTS pgmq;
SELECT pgmq.create('embedding_jobs');

-- Trigger function: queue a job whenever content changes
CREATE OR REPLACE FUNCTION queue_embedding_job()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  PERFORM pgmq.send('embedding_jobs', jsonb_build_object(
    'id', NEW.id,
    'content', NEW.content
  ));
  RETURN NEW;
END;
$$;

CREATE TRIGGER embed_on_insert
  AFTER INSERT OR UPDATE OF content ON documents
  FOR EACH ROW
  EXECUTE FUNCTION queue_embedding_job();
```

### 2. Batch Processor (Edge Function)

```typescript
import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);
const openai = new OpenAI({ apiKey: Deno.env.get('OPENAI_API_KEY')! });

Deno.serve(async () => {
  // Read batch of jobs (visibility timeout = 30s for auto-retry on failure)
  const { data: jobs } = await supabase.rpc('pgmq_read', {
    queue_name: 'embedding_jobs',
    qty: 50,
    sleep_seconds: 30,
  });

  if (!jobs?.length) {
    return new Response(JSON.stringify({ processed: 0 }));
  }

  // Batch embed all content in one API call
  const contents = jobs.map((j: { message: { content: string } }) => j.message.content);
  const embeddingResponse = await openai.embeddings.create({
    model: 'text-embedding-3-small',
    input: contents,
  });

  // Update each document with its embedding
  for (let i = 0; i < jobs.length; i++) {
    const { error } = await supabase
      .from('documents')
      .update({ embedding: embeddingResponse.data[i].embedding })
      .eq('id', jobs[i].message.id);

    if (!error) {
      // Archive processed job
      await supabase.rpc('pgmq_archive', {
        queue_name: 'embedding_jobs',
        msg_id: jobs[i].msg_id,
      });
    }
    // Failed jobs auto-retry after visibility timeout expires
  }

  return new Response(JSON.stringify({ processed: jobs.length }));
});
```

### 3. Schedule with pg_cron

```sql
SELECT cron.schedule(
  'process-embeddings',
  '*/10 * * * * *',  -- every 10 seconds (pg_cron v1.6+ supports seconds)
  $$SELECT net.http_post(
    url := current_setting('app.settings.edge_function_url') || '/embed-batch',
    headers := jsonb_build_object(
      'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key')
    )
  );$$
);
```

---

## Hybrid Search

Combine full-text search (keyword matching via tsvector/GIN) with semantic search (meaning matching via pgvector/HNSW) using Reciprocal Rank Fusion (RRF) for the best of both approaches.

### Setup

```sql
-- Add full-text search column (auto-generated, auto-indexed)
ALTER TABLE documents ADD COLUMN fts tsvector
  GENERATED ALWAYS AS (to_tsvector('english', content)) STORED;

CREATE INDEX ON documents USING gin(fts);
```

### Hybrid Search Function with RRF

```sql
CREATE OR REPLACE FUNCTION hybrid_search(
  query_text text,
  query_embedding vector(1536),
  match_count int DEFAULT 10,
  full_text_weight float DEFAULT 1.0,
  semantic_weight float DEFAULT 1.0,
  rrf_k int DEFAULT 60
)
RETURNS TABLE (id bigint, content text, score float)
LANGUAGE sql
STABLE
AS $$
  WITH full_text AS (
    SELECT
      d.id,
      d.content,
      ROW_NUMBER() OVER (ORDER BY ts_rank_cd(d.fts, websearch_to_tsquery(query_text)) DESC) AS rank
    FROM documents d
    WHERE d.fts @@ websearch_to_tsquery(query_text)
    ORDER BY rank
    LIMIT match_count * 2
  ),
  semantic AS (
    SELECT
      d.id,
      d.content,
      ROW_NUMBER() OVER (ORDER BY d.embedding <=> query_embedding) AS rank
    FROM documents d
    ORDER BY d.embedding <=> query_embedding
    LIMIT match_count * 2
  )
  SELECT
    COALESCE(ft.id, sm.id) AS id,
    COALESCE(ft.content, sm.content) AS content,
    (
      COALESCE(full_text_weight / (rrf_k + ft.rank), 0.0) +
      COALESCE(semantic_weight / (rrf_k + sm.rank), 0.0)
    )::float AS score
  FROM full_text ft
  FULL OUTER JOIN semantic sm ON ft.id = sm.id
  ORDER BY score DESC
  LIMIT match_count;
$$;
```

Call from client:

```typescript
const { data } = await supabase.rpc('hybrid_search', {
  query_text: 'authentication best practices',
  query_embedding: embedding,
  match_count: 10,
  full_text_weight: 1.0,
  semantic_weight: 1.0,
});
```

Adjust `full_text_weight` vs `semantic_weight` to bias toward keyword precision or semantic understanding. The `rrf_k` constant (default 60) dampens the influence of high-rank items.

---

## AI Dashboard Features

- **AI Assistant**: schema design suggestions, SQL query writing, error debugging, RLS policy creation, natural language to SQL
- **CMD+K**: inline SQL editing -- select a query, press CMD+K, describe the change in natural language
- **postgres.new**: in-browser Postgres sandbox with AI assistance for prototyping schemas and queries
- **Supabase MCP Server**: official Model Context Protocol server for AI IDE integrations (Cursor, Claude Code, etc.) -- provides schema introspection, query execution, and management operations

### Built-in Embedding Model

Edge Functions include the `gte-small` model (384 dimensions) with no external API key required:

```typescript
const pipe = await pipeline('feature-extraction', 'Supabase/gte-small');
const output = await pipe(text, { pooling: 'mean', normalize: true });
const embedding = Array.from(output.data);
```

Use for prototyping or low-volume workloads. Switch to OpenAI or Cohere for production-scale quality.

---

## Choosing Embedding Models

| Model | Dimensions | Provider | Best For |
|-------|-----------|----------|----------|
| `text-embedding-3-small` | 1536 | OpenAI | General purpose, strong quality/cost ratio |
| `text-embedding-3-large` | 3072 | OpenAI | Maximum quality, long documents |
| `gte-small` (built-in) | 384 | Supabase | Prototyping, no API key needed |
| `embed-v3` | 1024 | Cohere | Multilingual content, 100+ languages |
| `voyage-3` | 1024 | Voyage AI | Code search, technical documentation |

Match the `vector(N)` column dimension to your chosen model. Changing models requires re-embedding all data.

---

## Performance Tips

- **Use `halfvec`** for 50% storage reduction with negligible recall loss:
  ```sql
  ALTER TABLE documents ALTER COLUMN embedding TYPE halfvec(1536);
  ```
- **Batch embedding generation**: process 100+ texts per API call to reduce latency and cost
- **Pre-filter before vector search** to reduce the scan space:
  ```sql
  SELECT * FROM documents
  WHERE metadata->>'category' = 'engineering'
  ORDER BY embedding <=> query_embedding
  LIMIT 10;
  ```
  Create a partial index for frequent filters:
  ```sql
  CREATE INDEX ON documents USING hnsw (embedding vector_cosine_ops)
  WHERE metadata->>'category' = 'engineering';
  ```
- **Monitor with EXPLAIN**:
  ```sql
  EXPLAIN (ANALYZE, BUFFERS) SELECT * FROM documents
  ORDER BY embedding <=> '[...]'::vector LIMIT 10;
  ```
  Verify the index scan appears in the plan. If you see a sequential scan, the planner decided the table is too small or `ef_search` is too high.
- **For 1M+ vectors**: partition tables by tenant or category, each partition with its own HNSW index. This keeps individual indexes small and enables partition pruning.
- **Quantize large models**: use `binary_quantize()` for 32x compression as a coarse first pass, then re-rank with full vectors:
  ```sql
  CREATE INDEX ON documents USING hnsw (
    binary_quantize(embedding)::bit(1536) bit_hamming_ops
  );
  ```
