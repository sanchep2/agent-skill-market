# Database Reference

> Supabase wraps PostgreSQL with auto-generated APIs, connection pooling, Row Level Security, branching, and type generation. This reference covers every database-facing feature with production patterns.

## Table of Contents

1. [PostgREST API (v14)](#postgrest-api-v14)
2. [pg_graphql](#pg_graphql)
3. [Row Level Security (RLS) — Complete Guide](#row-level-security-rls--complete-guide)
4. [Database Functions and Triggers](#database-functions-and-triggers)
5. [Connection Pooling — Supavisor](#connection-pooling--supavisor)
6. [Foreign Data Wrappers (FDW)](#foreign-data-wrappers-fdw)
7. [Query Optimization](#query-optimization)
8. [Type Generation](#type-generation)
9. [Database Branching](#database-branching)
10. [Gotchas and Troubleshooting](#gotchas-and-troubleshooting)

---

## PostgREST API (v14)

PostgREST auto-generates a RESTful API from your PostgreSQL schema. v14 brings ~20% more RPS via JWT caching and schema cache loading improved from 7 minutes to 2 seconds. Default maximum: **1,000 rows per request** (configurable via `PGRST_MAX_ROWS`).

### CRUD operations

```typescript
import { createClient } from '@supabase/supabase-js'
import type { Database } from './database.types'

const supabase = createClient<Database>(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_ANON_KEY!
)

// SELECT — fetch rows with column selection
const { data, error } = await supabase
  .from('products')
  .select('id, name, price, category:categories(name)')
  .eq('active', true)
  .order('created_at', { ascending: false })
  .range(0, 49) // pagination: rows 0-49

// INSERT — single row
const { data, error } = await supabase
  .from('products')
  .insert({ name: 'Widget', price: 29.99, active: true })
  .select() // return the inserted row

// INSERT — bulk (array)
const { data, error } = await supabase
  .from('products')
  .insert([
    { name: 'Widget A', price: 19.99 },
    { name: 'Widget B', price: 39.99 },
  ])
  .select()

// UPDATE — partial update with filter
const { data, error } = await supabase
  .from('products')
  .update({ price: 24.99 })
  .eq('id', productId)
  .select()

// UPSERT — insert or update on conflict
const { data, error } = await supabase
  .from('products')
  .upsert(
    { id: existingId, name: 'Widget V2', price: 34.99 },
    { onConflict: 'id' }
  )
  .select()

// DELETE — remove with filter
const { error } = await supabase
  .from('products')
  .delete()
  .eq('id', productId)
```

### Filtering operators

```typescript
// Comparison
.eq('status', 'active')           // =
.neq('status', 'archived')        // !=
.gt('price', 100)                 // >
.gte('price', 100)                // >=
.lt('price', 50)                  // <
.lte('price', 50)                 // <=

// Pattern matching
.like('name', '%widget%')         // LIKE (case-sensitive)
.ilike('name', '%widget%')        // ILIKE (case-insensitive)

// Null checks
.is('deleted_at', null)           // IS NULL
.not('deleted_at', 'is', null)    // IS NOT NULL

// Arrays and sets
.in('status', ['active', 'pending'])        // IN
.contains('tags', ['featured'])             // @> (array contains)
.containedBy('tags', ['featured', 'new'])   // <@ (contained by)
.overlaps('tags', ['sale', 'clearance'])    // && (arrays overlap)

// Full-text search
.textSearch('content', 'supabase & database', {
  type: 'websearch',    // or 'plain', 'phrase'
  config: 'english'
})

// Logical combinators
.or('price.gt.100,featured.eq.true')
.not('status', 'eq', 'archived')

// Raw PostgREST filter (escape hatch)
.filter('price', 'gte', 50)
```

### Resource embedding (joins via foreign keys)

```typescript
// One-to-many: fetch posts with their comments
const { data } = await supabase
  .from('posts')
  .select(`
    id,
    title,
    comments (
      id,
      body,
      author:profiles (username, avatar_url)
    )
  `)

// Inner join — only return posts that have comments
const { data } = await supabase
  .from('posts')
  .select(`
    id,
    title,
    comments!inner (id, body)
  `)
  .gt('comments.created_at', '2026-01-01')

// Many-to-many through junction table
const { data } = await supabase
  .from('products')
  .select(`
    id,
    name,
    categories:product_categories!inner (
      category:categories (id, name)
    )
  `)

// Aliased relation (disambiguate multiple FKs to same table)
const { data } = await supabase
  .from('messages')
  .select(`
    id,
    content,
    sender:profiles!sender_id (username),
    receiver:profiles!receiver_id (username)
  `)
```

### RPC — calling database functions

```typescript
// Simple function call
const { data, error } = await supabase.rpc('get_user_stats', {
  target_user_id: userId,
})

// Function returning a set (table)
const { data, error } = await supabase
  .rpc('search_products', { search_term: 'widget' })
  .select('id, name, price')
  .limit(20)

// Aggregate / scalar function
const { data, error } = await supabase.rpc('calculate_order_total', {
  order_id: orderId,
})
// data is the scalar return value
```

---

## pg_graphql

PostgreSQL extension that reflects your schema into a GraphQL API. Tables become pageable collections with **Relay-style cursor pagination**. Auto-generates queries, mutations, and subscriptions.

**Endpoint**: `https://<project-ref>.supabase.co/graphql/v1`

> **Note**: pg_graphql is **disabled by default on new projects** as of late 2025. Enable it from the Dashboard under Database > Extensions.

### Setup and configuration

```sql
-- Enable the extension
CREATE EXTENSION IF NOT EXISTS pg_graphql;

-- Enable inflected names (camelCase instead of snake_case)
COMMENT ON SCHEMA public IS e'@graphql({"inflect_names": true})';

-- Exclude a table from the GraphQL schema
COMMENT ON TABLE internal_logs IS e'@graphql({"totalCount": {"enabled": true}})';
```

### Query example

```graphql
query GetProducts($first: Int!, $after: Cursor) {
  productsCollection(
    first: $first
    after: $after
    filter: { active: { eq: true } }
    orderBy: [{ created_at: DescNullsLast }]
  ) {
    edges {
      node {
        id
        name
        price
        category {
          name
        }
      }
      cursor
    }
    pageInfo {
      hasNextPage
      endCursor
    }
  }
}
```

### Calling from the client

```typescript
const { data, error } = await supabase.graphql({
  query: `
    query GetProduct($id: UUID!) {
      productsCollection(filter: { id: { eq: $id } }) {
        edges {
          node { id, name, price }
        }
      }
    }
  `,
  variables: { id: productId },
})
```

---

## Row Level Security (RLS) — Complete Guide

RLS adds an implicit `WHERE` clause to every query. The JWT maps to `anon` (unauthenticated) or `authenticated` (logged in) PostgreSQL roles.

### Critical rule

**Enable RLS on every table exposed to the public schema.** The Dashboard auto-enables RLS when creating tables. The SQL Editor does **NOT** — you must do it manually.

```sql
-- Always do this for any table created via SQL
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
-- Force RLS even for table owners (prevents accidental bypass)
ALTER TABLE public.products FORCE ROW LEVEL SECURITY;
```

### Pattern 1 — Owner-based access

```sql
-- Users can only read/write their own data
CREATE POLICY "Users manage own profiles"
  ON public.profiles
  FOR ALL
  TO authenticated
  USING ((SELECT auth.uid()) = id)
  WITH CHECK ((SELECT auth.uid()) = id);

-- Separate policies per operation (recommended for clarity)
CREATE POLICY "Users read own orders"
  ON public.orders FOR SELECT
  TO authenticated
  USING ((SELECT auth.uid()) = user_id);

CREATE POLICY "Users create own orders"
  ON public.orders FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT auth.uid()) = user_id);

CREATE POLICY "Users update own orders"
  ON public.orders FOR UPDATE
  TO authenticated
  USING ((SELECT auth.uid()) = user_id)
  WITH CHECK ((SELECT auth.uid()) = user_id);

CREATE POLICY "Users delete own orders"
  ON public.orders FOR DELETE
  TO authenticated
  USING ((SELECT auth.uid()) = user_id);
```

### Pattern 2 — Team/org-based access

```sql
-- SECURITY DEFINER function to check membership (bypasses RLS to query memberships table)
CREATE OR REPLACE FUNCTION public.is_member_of(_org_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = ''
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.org_members
    WHERE org_id = _org_id
      AND user_id = (SELECT auth.uid())
  );
$$;

-- Policy using the membership check
CREATE POLICY "Org members access projects"
  ON public.projects FOR SELECT
  TO authenticated
  USING (public.is_member_of(org_id));

CREATE POLICY "Org members create projects"
  ON public.projects FOR INSERT
  TO authenticated
  WITH CHECK (public.is_member_of(org_id));
```

### Pattern 3 — RBAC via custom claims

```sql
-- Store role in app_metadata (only writable server-side)
-- Set via: supabase.auth.admin.updateUserById(userId, { app_metadata: { user_role: 'admin' } })

CREATE POLICY "Admins have full access"
  ON public.settings FOR ALL
  TO authenticated
  USING (
    (SELECT auth.jwt()) ->> 'user_role' = 'admin'
  );

CREATE POLICY "Moderators can read and update"
  ON public.posts FOR SELECT
  TO authenticated
  USING (
    (SELECT auth.jwt()) ->> 'user_role' IN ('admin', 'moderator')
  );

CREATE POLICY "Moderators can update"
  ON public.posts FOR UPDATE
  TO authenticated
  USING (
    (SELECT auth.jwt()) ->> 'user_role' IN ('admin', 'moderator')
  )
  WITH CHECK (
    (SELECT auth.jwt()) ->> 'user_role' IN ('admin', 'moderator')
  );
```

### Performance optimization — 5 rules

| Rule | Why | Example |
|------|-----|---------|
| 1. Index policy columns | RLS adds WHERE to every query — unindexed = full scan | `CREATE INDEX idx_orders_user_id ON orders(user_id);` |
| 2. Wrap auth functions in SELECT | Triggers PostgreSQL initPlan optimization — **100x+ improvement** | `(SELECT auth.uid())` instead of `auth.uid()` |
| 3. Add application-level filters | Helps the query planner even though RLS already filters | `.from('orders').select('*').eq('user_id', userId)` |
| 4. Use SECURITY DEFINER for complex checks | Avoids nested RLS evaluation on joined tables | See team-based pattern above |
| 5. Separate policies per operation | PostgreSQL OR-combines `FOR ALL` policies — splits are more optimizable | One policy per SELECT/INSERT/UPDATE/DELETE |

```sql
-- BAD: auth.uid() without SELECT wrapper — evaluated per row
CREATE POLICY "slow_policy" ON orders
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

-- GOOD: (SELECT auth.uid()) — evaluated once via initPlan
CREATE POLICY "fast_policy" ON orders
  FOR SELECT TO authenticated
  USING ((SELECT auth.uid()) = user_id);
```

### Common RLS mistakes

| Mistake | Consequence | Fix |
|---------|-------------|-----|
| Using `user_metadata` in policies | Users can modify their own `user_metadata` client-side | Use `app_metadata` (server-writable only) or custom claims |
| Forgetting RLS on SQL-created tables | Table is wide open to `anon` and `authenticated` | Always `ALTER TABLE ... ENABLE ROW LEVEL SECURITY` |
| Missing SELECT policy for UPDATE | UPDATE with `RETURNING` or `.select()` fails silently | Add a SELECT policy alongside UPDATE |
| Not specifying `TO authenticated`/`TO anon` | Policy applies to both roles — anon gets access | Always specify the target role |
| RLS silent failures | SELECT returns empty set, INSERT returns 0 rows — **no error thrown** | Test policies explicitly; check for empty results |
| Using mutable functions in policies | `now()` or `random()` in policies can cause caching issues | Use `STABLE` or `IMMUTABLE` functions only |

### Testing RLS with pgTAP

```sql
BEGIN;

-- Create test users
SELECT tests.create_supabase_user('owner', 'owner@test.com');
SELECT tests.create_supabase_user('outsider', 'outsider@test.com');

-- Set up test data as service role
SET ROLE service_role;
INSERT INTO public.accounts (id, slug, owner_id)
VALUES ('11111111-1111-1111-1111-111111111111', 'test', tests.get_supabase_uid('owner'));
RESET ROLE;

-- Test: owner CAN see their account
SELECT tests.authenticate_as('owner');
SELECT isnt_empty(
  $$ SELECT * FROM accounts WHERE slug = 'test' $$,
  'Owner can see their own account'
);

-- Test: outsider CANNOT see the account
SELECT tests.authenticate_as('outsider');
SELECT is_empty(
  $$ SELECT * FROM accounts WHERE slug = 'test' $$,
  'Outsider is blocked from seeing the account'
);

-- Test: anonymous CANNOT see the account
SELECT tests.authenticate_as_anon();
SELECT is_empty(
  $$ SELECT * FROM accounts WHERE slug = 'test' $$,
  'Anonymous user cannot see the account'
);

ROLLBACK;
```

---

## Database Functions and Triggers

### Creating functions

```sql
-- PL/pgSQL function with SECURITY INVOKER (default, recommended)
CREATE OR REPLACE FUNCTION public.get_user_stats(target_user_id uuid)
RETURNS json
LANGUAGE plpgsql
SECURITY INVOKER  -- runs with caller's permissions, respects RLS
SET search_path = ''
AS $$
DECLARE
  result json;
BEGIN
  SELECT json_build_object(
    'total_orders', COUNT(*),
    'total_spent', COALESCE(SUM(amount), 0),
    'last_order', MAX(created_at)
  ) INTO result
  FROM public.orders
  WHERE user_id = target_user_id;

  RETURN result;
END;
$$;

-- SECURITY DEFINER — bypasses RLS. Use sparingly, always set search_path.
CREATE OR REPLACE FUNCTION public.admin_get_all_users()
RETURNS SETOF public.profiles
LANGUAGE sql
SECURITY DEFINER
SET search_path = ''  -- CRITICAL: prevents search_path injection
STABLE
AS $$
  SELECT * FROM public.profiles ORDER BY created_at DESC;
$$;
```

### Permission management

```sql
-- Revoke default public execute (best practice)
REVOKE EXECUTE ON ALL FUNCTIONS IN SCHEMA public FROM PUBLIC;

-- Grant to specific roles
GRANT EXECUTE ON FUNCTION public.get_user_stats TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_get_all_users TO service_role;

-- For new functions created in the future
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;
```

### Calling functions via RPC

```typescript
// Simple call
const { data, error } = await supabase.rpc('get_user_stats', {
  target_user_id: userId,
})

// Function returning rows — chain PostgREST operators
const { data, error } = await supabase
  .rpc('search_products', { query: 'widget' })
  .gte('price', 10)
  .order('relevance', { ascending: false })
  .limit(20)
```

### Common trigger patterns

```sql
-- 1. Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, username, avatar_url)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'username', split_part(NEW.email, '@', 1)),
    NEW.raw_user_meta_data ->> 'avatar_url'
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- 2. Auto-update timestamps (uses moddatetime extension)
CREATE EXTENSION IF NOT EXISTS moddatetime;

CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON public.products
  FOR EACH ROW
  EXECUTE FUNCTION moddatetime(updated_at);

-- 3. Queue embedding generation via pg_net
CREATE OR REPLACE FUNCTION public.queue_embedding_job()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  PERFORM net.http_post(
    url := 'https://your-app.com/api/embeddings',
    body := jsonb_build_object('id', NEW.id, 'content', NEW.content),
    headers := jsonb_build_object('Authorization', 'Bearer ' || current_setting('app.settings.service_key'))
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_content_change
  AFTER INSERT OR UPDATE OF content ON public.documents
  FOR EACH ROW
  EXECUTE FUNCTION public.queue_embedding_job();
```

---

## Connection Pooling — Supavisor

Supabase migrated from PgBouncer to **Supavisor** (Elixir-based, multi-tenant connection pooler).

### Connection types

| Mode | Port | Use case | Features |
|------|------|----------|----------|
| **Direct** | 5432 | Migrations, full Postgres features | IPv6, all PG features, no pooling |
| **Transaction** | 6543 | Serverless, Edge Functions, short-lived | Shares connections, highest throughput |
| **Session** | 5432 (pooler host) | Long-lived connections, prepared statements | IPv4, dedicated session per client |

### Connection strings

```bash
# Direct connection (migrations, admin tasks)
postgresql://postgres.[ref]:[password]@db.[ref].supabase.co:5432/postgres

# Transaction pooler (application default)
postgresql://postgres.[ref]:[password]@[ref].pooler.supabase.com:6543/postgres

# Session pooler (prepared statements needed)
postgresql://postgres.[ref]:[password]@[ref].pooler.supabase.com:5432/postgres
```

### Best practices

- **Keep pooler utilization under 40%** if also using the REST API (REST uses its own pool)
- Use transaction mode for serverless/edge workloads
- Use session mode only when you need prepared statements
- Dedicated poolers available on Pro plan and above

### Prisma configuration

```prisma
// schema.prisma
datasource db {
  provider  = "postgresql"
  url       = env("DATABASE_URL")        // Transaction pooler for queries
  directUrl = env("DIRECT_URL")          // Direct connection for migrations
}
```

```env
# .env
DATABASE_URL="postgresql://postgres.[ref]:[pw]@[ref].pooler.supabase.com:6543/postgres?pgbouncer=true"
DIRECT_URL="postgresql://postgres.[ref]:[pw]@db.[ref].supabase.co:5432/postgres"
```

### Drizzle configuration

```typescript
// drizzle.config.ts
import { defineConfig } from 'drizzle-kit'

export default defineConfig({
  schema: './src/db/schema.ts',
  out: './supabase/migrations',
  dialect: 'postgresql',
  dbCredentials: {
    url: process.env.DIRECT_URL!, // Direct for migrations
  },
})
```

---

## Foreign Data Wrappers (FDW)

Query external data sources directly from PostgreSQL. Supabase provides wrappers for:

| Category | Services |
|----------|----------|
| **Databases** | PostgreSQL (postgres_fdw), ClickHouse, MSSQL, DuckDB, Redis, Iceberg |
| **Cloud warehouses** | BigQuery, Snowflake, S3 |
| **SaaS** | Stripe, Firebase, Airtable, Notion, Paddle |
| **Auth providers** | Auth0, Cognito, Clerk |

### Example: Stripe FDW

```sql
CREATE EXTENSION IF NOT EXISTS wrappers;

CREATE FOREIGN DATA WRAPPER stripe_wrapper
  HANDLER stripe_fdw_handler
  VALIDATOR stripe_fdw_validator;

CREATE SERVER stripe_server
  FOREIGN DATA WRAPPER stripe_wrapper
  OPTIONS (api_key_id '<vault_secret_id>');

CREATE FOREIGN TABLE public.stripe_customers (
  id text,
  email text,
  name text,
  created bigint
)
SERVER stripe_server
OPTIONS (object 'customers');

-- Query Stripe data like a regular table
SELECT id, email, name
FROM stripe_customers
WHERE email ILIKE '%@company.com';
```

### Security with FDWs

FDWs do **NOT** provide Row Level Security. Always:

1. Store foreign tables in a **private schema** (not `public`)
2. Expose data through **SECURITY DEFINER views or functions**

```sql
-- Store in private schema
CREATE SCHEMA IF NOT EXISTS private;
-- (create foreign table in private schema)

-- Expose via security definer function
CREATE OR REPLACE FUNCTION public.get_my_stripe_customer()
RETURNS json
LANGUAGE sql
SECURITY DEFINER
SET search_path = ''
STABLE
AS $$
  SELECT json_build_object('id', sc.id, 'email', sc.email)
  FROM private.stripe_customers sc
  JOIN public.profiles p ON p.stripe_customer_id = sc.id
  WHERE p.id = (SELECT auth.uid());
$$;
```

### Wasm FDWs

Build custom FDWs using WebAssembly for sources without a built-in wrapper. Write in Rust, compile to Wasm, deploy as an extension.

---

## Query Optimization

### Index types

| Type | Use case | Example |
|------|----------|---------|
| **B-tree** (default) | Equality, range, sorting | `CREATE INDEX idx_orders_date ON orders(created_at);` |
| **Hash** | Equality only (rare) | `CREATE INDEX idx_users_email ON users USING hash(email);` |
| **GIN** | Arrays, JSONB, full-text search | `CREATE INDEX idx_posts_tags ON posts USING gin(tags);` |
| **GiST** | Geometric, range types, nearest-neighbor | `CREATE INDEX idx_locations_geo ON locations USING gist(coordinates);` |
| **BRIN** | Naturally ordered data (timestamps, sequences) | `CREATE INDEX idx_logs_created ON logs USING brin(created_at);` |
| **HNSW** | Vector similarity search (pgvector) | `CREATE INDEX idx_embeddings ON docs USING hnsw(embedding vector_cosine_ops);` |

### Diagnosing slow queries

```sql
-- Always use ANALYZE and BUFFERS for real execution stats
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT *
FROM orders
WHERE user_id = '550e8400-e29b-41d4-a716-446655440000'
  AND status = 'pending'
ORDER BY created_at DESC
LIMIT 20;

-- Look for:
-- Seq Scan (should be Index Scan for filtered queries)
-- high "actual rows" vs "rows removed by filter" (missing index)
-- Buffers: shared read (high = not cached, check cache hit rate)
```

### index_advisor extension

```sql
-- Get index recommendations for a query
SELECT * FROM index_advisor($$
  SELECT * FROM orders
  WHERE user_id = '550e8400-e29b-41d4-a716-446655440000'
    AND status = 'pending'
  ORDER BY created_at DESC
$$);
-- Returns: CREATE INDEX ON orders (user_id, status, created_at DESC);
```

### CLI inspection commands

```bash
# Check cache hit rate — target 99%+
supabase inspect db cache-hit

# Find unused indexes (wasting write performance)
supabase inspect db unused-indexes

# Find slowest queries
supabase inspect db outliers

# Table sizes
supabase inspect db table-sizes

# Index sizes
supabase inspect db index-sizes

# Active locks
supabase inspect db locks
```

### Composite index strategy

```sql
-- Put equality columns first, range/sort columns last
CREATE INDEX idx_orders_user_status_date
  ON orders (user_id, status, created_at DESC);

-- Partial index for common filters
CREATE INDEX idx_active_products
  ON products (category_id, price)
  WHERE active = true;

-- Expression index for computed lookups
CREATE INDEX idx_users_lower_email
  ON users (lower(email));
```

---

## Type Generation

### Generating types

```bash
# From local development database
supabase gen types typescript --local > src/lib/database.types.ts

# From linked remote project
supabase gen types typescript --linked > src/lib/database.types.ts

# From project ref directly
supabase gen types typescript --project-id <ref> > src/lib/database.types.ts
```

### Using generated types

```typescript
import { createClient } from '@supabase/supabase-js'
import type { Database } from '@/lib/database.types'

// Typed client — all queries get full autocompletion
const supabase = createClient<Database>(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

// Extract table types for use in your app
type Product = Database['public']['Tables']['products']['Row']
type ProductInsert = Database['public']['Tables']['products']['Insert']
type ProductUpdate = Database['public']['Tables']['products']['Update']

// Views, functions, enums also typed
type OrderStatus = Database['public']['Enums']['order_status']
type SearchResult = Database['public']['Functions']['search_products']['Returns']
```

### Automate in CI

```yaml
# .github/workflows/types.yml
name: Update DB Types
on:
  push:
    branches: [main]
    paths: ['supabase/migrations/**']

jobs:
  generate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: supabase/setup-cli@v1
      - run: supabase gen types typescript --project-id ${{ secrets.SUPABASE_PROJECT_ID }} > src/lib/database.types.ts
        env:
          SUPABASE_ACCESS_TOKEN: ${{ secrets.SUPABASE_ACCESS_TOKEN }}
      - uses: peter-evans/create-pull-request@v6
        with:
          commit-message: 'chore: update database types'
          title: 'Update database types'
          branch: update-db-types
```

---

## Database Branching

Each branch creates a **complete isolated Supabase environment**: database, Auth, Storage, Edge Functions, and Realtime.

### Branch types

| Type | Lifecycle | Compute | Use case |
|------|-----------|---------|----------|
| **Preview** | Ephemeral — auto-pauses, deleted on PR merge | Shared | Feature development, PR reviews |
| **Persistent** | Remains active until manually deleted | Configurable | Staging, QA environments |

### Branching 2.0

Dashboard-based branching (no Git integration required):

```bash
# CLI: create a preview branch
supabase branches create feat-payments --project-ref <ref>

# List branches
supabase branches list --project-ref <ref>

# Delete a branch
supabase branches delete <branch-id> --project-ref <ref>
```

### Git integration (optional)

```bash
# Enable Git-based branching
supabase branches enable --project-ref <ref> --git-provider github

# Every PR automatically gets a preview branch
# Migrations in supabase/migrations/ are applied to the branch
# Branch is deleted when PR is merged or closed
```

### Branch environment variables

Each branch gets its own credentials. Use in CI:

```bash
# Get branch-specific connection info
BRANCH_URL=$(supabase branches get <branch-id> --project-ref <ref> --format json | jq -r '.api_url')
BRANCH_ANON_KEY=$(supabase branches get <branch-id> --project-ref <ref> --format json | jq -r '.anon_key')
```

### Cost considerations

Branches are billed per:
- **Compute**: based on instance size and uptime
- **Disk**: storage used by the branch database
- **Egress**: network transfer from the branch

Preview branches auto-pause after inactivity to reduce costs. Persistent branches run continuously unless manually paused.

### Seeding branch data

```sql
-- supabase/seed.sql — runs automatically on branch creation
INSERT INTO public.categories (name, slug) VALUES
  ('Electronics', 'electronics'),
  ('Clothing', 'clothing'),
  ('Books', 'books');

-- Use SECURITY DEFINER or service_role for seeding auth.users
-- Never put real credentials in seed files
```

---

## Gotchas and Troubleshooting

| Issue | Cause | Solution |
|-------|-------|----------|
| Query returns empty array (no error) | RLS policy blocking access | Check policies with `SELECT * FROM pg_policies WHERE tablename = 'your_table'` |
| `permission denied for table` | Missing GRANT or wrong role | `GRANT SELECT, INSERT, UPDATE, DELETE ON public.table TO authenticated;` |
| `could not find a relationship` in joins | Missing or ambiguous foreign key | Check FKs: `SELECT * FROM information_schema.table_constraints WHERE constraint_type = 'FOREIGN KEY'` |
| Connection timeout on serverless | Too many connections or wrong mode | Use transaction pooler (port 6543), not direct |
| `prepared statement already exists` | Transaction mode with prepared statements | Switch to session mode or use `?pgbouncer=true` |
| Slow RLS queries | Missing indexes or un-wrapped auth functions | Apply the 5 performance rules above |
| Type mismatch after migration | Stale generated types | Re-run `supabase gen types typescript` |
| `max_rows` exceeded | Default 1,000 row limit | Use pagination (`.range()`) or increase `PGRST_MAX_ROWS` |
