# CLI and Operations Reference

> Complete CLI reference and operational workflows for Supabase local development, migrations, Edge Functions, inspection, branching, and production management.

## Table of Contents

1. [Installation and Project Setup](#installation-and-project-setup)
2. [Local Development](#local-development)
3. [Database Commands — Complete Reference](#database-commands--complete-reference)
4. [Two Migration Workflows](#two-migration-workflows)
5. [Edge Functions CLI](#edge-functions-cli)
6. [Type Generation](#type-generation)
7. [Testing with pgTAP](#testing-with-pgtap)
8. [Remote Management](#remote-management)
9. [Inspection Commands](#inspection-commands)
10. [Branching CLI](#branching-cli)
11. [config.toml Key Sections](#configtoml-key-sections)
12. [Common CLI Workflows](#common-cli-workflows)
13. [Antipatterns](#antipatterns)

---

## Installation and Project Setup

### Install the CLI

```bash
# macOS / Linux (Homebrew)
brew install supabase/tap/supabase

# npm (requires Node.js 20+)
npm install -g supabase

# Verify installation
supabase --version
```

### Initialize a project

```bash
supabase init
```

This creates the following directory structure:

```
supabase/
├── config.toml          # Project configuration (API, auth, DB, storage, etc.)
├── migrations/          # Timestamped SQL migration files
├── functions/           # Edge Functions (Deno runtime)
├── tests/               # pgTAP database tests
└── seed.sql             # Seed data (runs after migrations on reset)
```

---

## Local Development

### Core commands

```bash
supabase start           # Start full local stack (first run pulls Docker images ~3 GB)
supabase stop            # Stop stack (preserves data by default)
supabase stop --no-backup # Stop and delete all local data
supabase status          # Show running services, URLs, and credentials
supabase status -o env   # Output as KEY=VALUE for .env files
```

### Local service ports

| Service | Port | URL |
|---------|------|-----|
| API (PostgREST) | 54321 | `http://localhost:54321` |
| Database (Postgres) | 54322 | `postgresql://postgres:postgres@localhost:54322/postgres` |
| Studio (Dashboard) | 54323 | `http://localhost:54323` |
| Inbucket (Email) | 54324 | `http://localhost:54324` |
| Auth (GoTrue) | 54321 | `http://localhost:54321/auth/v1` |
| Storage | 54321 | `http://localhost:54321/storage/v1` |
| Realtime | 54321 | `ws://localhost:54321/realtime/v1` |
| Edge Functions | 54321 | `http://localhost:54321/functions/v1/<name>` |
| Analytics (Logflare) | 54327 | `http://localhost:54327` |
| pgBouncer (pooler) | 54329 | `postgresql://postgres:postgres@localhost:54329/postgres` |

Studio at `http://localhost:54323` provides a full dashboard for browsing tables, running SQL, managing auth users, and testing RLS policies locally.

---

## Database Commands -- Complete Reference

| Command | Purpose |
|---------|---------|
| `supabase db push` | Push local migrations to linked remote project |
| `supabase db push --dry-run` | Preview what would be pushed without applying |
| `supabase db pull` | Pull remote schema changes as a new migration file |
| `supabase db pull --schema auth,storage` | Pull specific schemas |
| `supabase db diff -f <name>` | Diff local DB state against migrations, save as new migration |
| `supabase db diff --use-migra` | Use migra engine for diff (more accurate for some cases) |
| `supabase db reset` | Drop and recreate local DB from migrations + seed.sql |
| `supabase db dump --data-only` | Dump remote data as SQL |
| `supabase db dump -f schema.sql` | Dump remote schema to file |
| `supabase db dump --role-only` | Dump role definitions |
| `supabase db lint` | Lint schema using plpgsql_check and codesearch |
| `supabase db lint --level warning` | Set minimum lint severity (error, warning, info) |
| `supabase db seed` | Run `supabase/seed.sql` against local database |
| `supabase migration new <name>` | Create empty timestamped migration file |
| `supabase migration list` | Show migration status (local vs. remote applied) |
| `supabase migration squash` | Squash pending migrations into one |
| `supabase migration squash --version <ts>` | Squash up to specific version |
| `supabase migration repair --status applied <ts>` | Mark a migration as applied without running it |
| `supabase migration repair --status reverted <ts>` | Mark a migration as reverted |

---

## Two Migration Workflows

### Code-first (recommended)

Write SQL migrations by hand for full control and reviewability.

```bash
# 1. Create a new migration file
supabase migration new add_profiles_table

# 2. Edit the generated file
# supabase/migrations/20260224120000_add_profiles_table.sql
```

```sql
-- supabase/migrations/20260224120000_add_profiles_table.sql
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text,
  avatar_url text,
  created_at timestamptz default now() not null,
  updated_at timestamptz default now() not null
);

alter table public.profiles enable row level security;

create policy "Users can read any profile"
  on public.profiles for select
  using (true);

create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id)
  with check (auth.uid() = id);
```

```bash
# 3. Test locally — drops and recreates DB, runs all migrations + seed
supabase db reset

# 4. Push to remote when ready
supabase db push
```

### Dashboard-first

Make changes via Studio, then capture them as migrations.

```bash
# 1. Make changes in local Studio (http://localhost:54323)
#    — create tables, add columns, set up RLS, etc.

# 2. Capture changes as a migration
supabase db diff -f describe_your_changes

# 3. Review the generated migration file
#    supabase/migrations/20260224130000_describe_your_changes.sql

# 4. Test by resetting (ensures migration is reproducible)
supabase db reset

# 5. Push to remote
supabase db push
```

**Critical rule**: Always test with `supabase db reset` before pushing. If reset fails, the migration is not reproducible and will cause drift.

---

## Edge Functions CLI

### Lifecycle commands

```bash
supabase functions new my-function         # Scaffold function in supabase/functions/my-function/
supabase functions serve                   # Local serve with hot reload (all functions)
supabase functions serve my-function       # Serve a single function
supabase functions deploy                  # Deploy all functions to remote
supabase functions deploy my-function      # Deploy a single function
supabase functions delete my-function      # Delete function from remote
```

### Deploy flags

```bash
# Skip JWT verification (use for webhooks, cron triggers, public endpoints)
supabase functions deploy my-webhook --no-verify-jwt

# Remove remote functions not present locally
supabase functions deploy --prune

# Import map for shared dependencies
supabase functions deploy --import-map supabase/functions/import_map.json
```

### Local function development

```bash
# Serve with environment variables
supabase functions serve --env-file supabase/.env.local

# Test locally with curl
curl -i --location --request POST 'http://localhost:54321/functions/v1/my-function' \
  --header 'Authorization: Bearer <anon-key>' \
  --header 'Content-Type: application/json' \
  --data '{"name":"test"}'
```

Edge Functions run on Deno. Entry point is `supabase/functions/<name>/index.ts`.

---

## Type Generation

### Generate TypeScript types from schema

```bash
# From local database
supabase gen types typescript --local > src/types/database.types.ts

# From linked remote project
supabase gen types typescript --linked > src/types/database.types.ts

# From specific schemas
supabase gen types typescript --local --schema public,auth > src/types/database.types.ts
```

### Automate in CI (GitHub Actions)

```yaml
# .github/workflows/typegen.yml
name: Generate Types
on:
  push:
    branches: [main]
    paths: ['supabase/migrations/**']

jobs:
  typegen:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: supabase/setup-cli@v1
        with:
          version: latest

      - run: supabase link --project-ref ${{ secrets.SUPABASE_PROJECT_REF }}
        env:
          SUPABASE_ACCESS_TOKEN: ${{ secrets.SUPABASE_ACCESS_TOKEN }}

      - run: supabase gen types typescript --linked > src/types/database.types.ts

      - uses: peter-evans/create-pull-request@v7
        with:
          title: 'chore: update database types'
          commit-message: 'chore: regenerate database.types.ts'
          branch: chore/update-db-types
```

---

## Testing with pgTAP

### Run tests

```bash
supabase test db                          # Run all pgTAP tests in supabase/tests/
supabase test db --linked                 # Run tests against remote database
```

### Test file structure

Tests live in `supabase/tests/` with a `.sql` extension:

```sql
-- supabase/tests/profiles_rls_test.sql
begin;

-- Load test helpers
select plan(3);

-- Create test users
select tests.create_supabase_user('user_a', 'usera@test.com');
select tests.create_supabase_user('user_b', 'userb@test.com');

-- Insert test data
insert into public.profiles (id, username, display_name)
values
  (tests.get_supabase_uid('user_a'), 'alice', 'Alice'),
  (tests.get_supabase_uid('user_b'), 'bob', 'Bob');

-- Test 1: Anyone can read profiles
select tests.authenticate_as('user_a');
select results_eq(
  $$ select count(*)::int from public.profiles $$,
  2,
  'Authenticated user can read all profiles'
);

-- Test 2: User can update own profile
select tests.authenticate_as('user_a');
update public.profiles set display_name = 'Alice Updated'
  where id = tests.get_supabase_uid('user_a');
select results_eq(
  $$ select display_name from public.profiles where username = 'alice' $$,
  'Alice Updated',
  'User can update own profile'
);

-- Test 3: User cannot update another user profile
select tests.authenticate_as('user_b');
select throws_ok(
  $$ update public.profiles set display_name = 'Hacked' where username = 'alice' $$,
  'new row violates row-level security policy',
  'User cannot update other profiles'
);

select * from finish();
rollback;
```

Install `supabase-test-helpers` by adding the migration:

```bash
supabase migration new install_test_helpers
```

```sql
-- Download from https://github.com/usebasejump/supabase-test-helpers
-- Provides: tests.create_supabase_user(), tests.authenticate_as(), tests.get_supabase_uid()
create schema if not exists tests;
-- (paste the full helper SQL from the repo)
```

---

## Remote Management

### Authentication and linking

```bash
supabase login                              # Authenticate with Personal Access Token
supabase link --project-ref <project-id>    # Link local project to remote
supabase projects list                      # List all projects in your org
supabase orgs list                          # List organizations
```

### Configuration management

```bash
supabase config push                        # Push config.toml settings to remote
supabase config pull                        # Pull remote config to local config.toml
```

### Secrets management (Edge Functions)

```bash
supabase secrets set MY_API_KEY=sk-abc123   # Set a single secret
supabase secrets set --env-file .env.prod   # Set from env file
supabase secrets list                       # List all secret names (values hidden)
supabase secrets unset MY_API_KEY           # Remove a secret
```

---

## Inspection Commands

All inspection commands target the linked remote database by default. Use `--local` for local.

```bash
supabase inspect db <subcommand> [--local]
```

| Subcommand | Purpose | Key Insight |
|------------|---------|-------------|
| `table-sizes` | Disk space per table | Identify large tables for partitioning |
| `index-sizes` | Disk space per index | Find bloated or oversized indexes |
| `cache-hit` | Buffer cache and index hit ratios | Target 99%+ hit rate; below = need more RAM |
| `unused-indexes` | Indexes never scanned | Remove to save write overhead and storage |
| `outliers` | Slowest queries by total execution time | Top optimization targets |
| `calls` | Most frequently executed queries | High-call queries worth micro-optimizing |
| `long-running-queries` | Currently executing queries > 5 min | Kill or investigate stuck queries |
| `locks` | Current lock activity | Diagnose lock contention |
| `blocking` | Blocked queries and their blockers | Resolve cascading lock chains |
| `bloat` | Table and index bloat estimates | Schedule VACUUM when bloat > 20% |
| `vacuum-stats` | Last vacuum/analyze per table | Ensure autovacuum is running regularly |
| `role-connections` | Active connections per role | Identify connection leaks or pool exhaustion |
| `seq-scans` | Tables with most sequential scans | Candidates for new indexes |
| `total-index-size` | Total index size across database | Monitor index growth over time |
| `total-table-sizes` | Total table sizes including indexes | Overall database size tracking |
| `replication-slots` | Active replication slots | Detect abandoned slots causing WAL growth |

### Example: production health check

```bash
# Quick health check script
supabase inspect db cache-hit        # Expect index_hit > 0.99 and table_hit > 0.99
supabase inspect db outliers         # Review top 10 slow queries
supabase inspect db unused-indexes   # Drop unused indexes to save write cost
supabase inspect db bloat            # Check for table/index bloat
supabase inspect db role-connections # Verify connections within limits
```

---

## Branching CLI

Database branching creates isolated Supabase environments for feature development and PR previews.

```bash
supabase branches create feature-auth            # Create preview branch
supabase branches create staging --persistent     # Persistent branch (not auto-deleted)
supabase branches list                            # List all branches
supabase branches get feature-auth                # Get branch details
supabase branches delete feature-auth             # Delete a branch
```

### Branch behavior

- **Preview branches**: Auto-created from Git branches, auto-pause when idle, auto-deleted when PR merges
- **Persistent branches**: Stay active indefinitely, useful for staging/QA environments
- Each branch is a **complete isolated Supabase environment** (own DB, Auth, Storage, Edge Functions)
- Migrations from the branch's Git ref are applied automatically
- `seed.sql` runs on branch creation

### Git integration

```bash
# Enable branching for a project
supabase branches enable

# Branches map to Git branches:
# git branch feature/auth → supabase branch feature/auth
# PR merge → branch auto-deleted (preview) or kept (persistent)
```

---

## config.toml Key Sections

### Project

```toml
[project]
id = "your-project-ref"
```

### API (PostgREST)

```toml
[api]
enabled = true
port = 54321
schemas = ["public", "graphql_public"]
extra_search_path = ["public", "extensions"]
max_rows = 1000
```

### Database

```toml
[db]
port = 54322
major_version = 15
```

### Auth

```toml
[auth]
enabled = true
site_url = "http://localhost:3000"
additional_redirect_urls = ["https://localhost:3000"]

[auth.email]
enable_signup = true
double_confirm_changes = true
enable_confirmations = false  # Set true in production

[auth.external.google]
enabled = true
client_id = "env(GOOGLE_CLIENT_ID)"
secret = "env(GOOGLE_CLIENT_SECRET)"
redirect_uri = "http://localhost:54321/auth/v1/callback"

[auth.external.apple]
enabled = true
client_id = "env(APPLE_CLIENT_ID)"
secret = "env(APPLE_CLIENT_SECRET)"
redirect_uri = "http://localhost:54321/auth/v1/callback"

[auth.hook.custom_access_token]
enabled = true
uri = "pg-functions://public/custom_access_token_hook"
```

### Storage

```toml
[storage]
enabled = true
file_size_limit = "50MiB"

[storage.buckets.avatars]
public = true
file_size_limit = "5MiB"
allowed_mime_types = ["image/png", "image/jpeg", "image/webp"]
```

### Realtime

```toml
[realtime]
enabled = true
```

### Edge Runtime

```toml
[edge_runtime]
enabled = true
policy = "per_worker"  # "per_worker" or "oneshot"
inspector_port = 8083
```

---

## Common CLI Workflows

### 1. New project setup

```bash
supabase init                                    # Create project structure
supabase start                                   # Start local stack
supabase migration new create_initial_schema     # Create first migration
# Edit migration file with your schema
supabase db reset                                # Apply migrations + seed
supabase test db                                 # Run pgTAP tests
supabase login                                   # Authenticate
supabase link --project-ref <id>                 # Link to remote
supabase db push                                 # Push migrations to remote
supabase functions deploy                        # Deploy Edge Functions
```

### 2. Daily development cycle

```bash
supabase start                                   # Start local stack
# Code changes...
supabase migration new describe_changes          # Create migration (or use db diff)
supabase db reset                                # Test migration reproducibility
supabase test db                                 # Run tests
supabase gen types typescript --local > src/types/database.types.ts
# Commit migration + types
supabase db push                                 # Push to remote
```

### 3. Adding an Edge Function

```bash
supabase functions new process-payment           # Scaffold function
# Edit supabase/functions/process-payment/index.ts
supabase functions serve process-payment         # Local dev with hot reload
# Test with curl or client
supabase secrets set STRIPE_KEY=sk_live_xxx      # Set production secrets
supabase functions deploy process-payment        # Deploy to remote
```

### 4. Debugging production performance

```bash
supabase inspect db cache-hit                    # Check cache ratios (want 99%+)
supabase inspect db outliers                     # Find slowest queries
supabase inspect db calls                        # Find most called queries
supabase inspect db table-sizes                  # Identify largest tables
supabase inspect db unused-indexes               # Clean up unused indexes
supabase inspect db bloat                        # Check for table bloat
supabase inspect db long-running-queries         # Kill stuck queries
```

### 5. CI/CD migration pipeline

```yaml
# .github/workflows/migrate.yml
name: Push Migrations
on:
  push:
    branches: [main]
    paths: ['supabase/migrations/**']

jobs:
  migrate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: supabase/setup-cli@v1
        with:
          version: latest

      - run: supabase link --project-ref ${{ secrets.SUPABASE_PROJECT_REF }}
        env:
          SUPABASE_ACCESS_TOKEN: ${{ secrets.SUPABASE_ACCESS_TOKEN }}

      - run: supabase db push
        env:
          SUPABASE_ACCESS_TOKEN: ${{ secrets.SUPABASE_ACCESS_TOKEN }}
```

---

## Antipatterns

| Antipattern | Correct approach |
|-------------|-----------------|
| Editing remote DB directly without migration | Always capture changes with `db diff` or write migrations manually |
| Pushing without testing `db reset` first | Reset locally before every push to verify reproducibility |
| Storing secrets in `config.toml` | Use `supabase secrets set` or `env()` references |
| Skipping type generation after schema changes | Automate `gen types` in CI or pre-commit hook |
| Using `supabase db push` without `--dry-run` first on critical projects | Always dry-run on production-linked projects |
| Not running `supabase db lint` before push | Lint catches plpgsql errors, security issues, and naming violations |
| Manual Edge Function JWT verification | Use `--no-verify-jwt` flag for webhooks; default JWT check for user-facing functions |
