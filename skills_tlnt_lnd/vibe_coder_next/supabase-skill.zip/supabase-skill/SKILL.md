---
name: supabase
description: >
  Comprehensive mastery of Supabase — the open-source PostgreSQL BaaS providing Auth (GoTrue),
  Database (PostgREST), Storage (S3-compatible), Edge Functions (Deno), Realtime (WebSocket),
  Vector/AI (pgvector), Cron (pg_cron), and Queues (pgmq). Use this skill for ANY task involving
  Supabase: writing RLS policies, configuring auth flows (email, OAuth, MFA, SSO, anonymous),
  setting up @supabase/ssr for Next.js, integrating with React Native/Expo, Kotlin (supabase-kt),
  or Swift (supabase-swift), designing database schemas and migrations, creating Edge Functions,
  configuring Realtime subscriptions, implementing vector search/RAG, running CLI workflows,
  deploying to cloud or self-hosting, or optimizing query performance. Trigger whenever the user
  mentions "supabase", supabase imports (e.g. "@supabase/supabase-js", "@supabase/ssr",
  "supabase-kt", "supabase-swift"), RLS policies, supabase CLI commands, PostgREST patterns,
  GoTrue auth, or any PostgreSQL BaaS work. Also trigger for questions about Supabase architecture,
  security hardening, multi-tenant patterns, or comparison with Firebase/Convex/Neon/Appwrite.
  If in doubt, trigger — this skill covers the entire Supabase ecosystem as of February 2026.
---

# Supabase Mastery — Complete Skill for Claude Code

## §1 Architecture (internalize this — it drives every decision)

Supabase is a **PostgreSQL-first BaaS**: your database IS the backend. Every service wraps PostgreSQL:

- **Auth (GoTrue)** → issues JWTs, stores users in `auth.users`, integrates directly with RLS policies
- **PostgREST API** → auto-generates REST endpoints from your schema (v14, ~20% more RPS with JWT caching)
- **Storage** → metadata in `storage.objects` table, files on S3-compatible backend, RLS-protected
- **Edge Functions** → Deno runtime, globally distributed (Fly.io), ESZip bundles, no npm install
- **Realtime** → WebSocket server: Broadcast (ephemeral), Presence (CRDT), Postgres Changes (WAL)
- **pgvector** → vector similarity search, HNSW/IVFFlat indexes, RAG patterns
- **pg_cron + pgmq** → scheduled jobs and durable message queues, all in Postgres

**Security model**: Row Level Security (RLS) is THE security layer. Every query goes through PostgREST which applies the caller's role (`anon` or `authenticated`). RLS policies add implicit WHERE clauses. Without RLS, the `anon` key gives full public access.

**JWT flow**: Client authenticates → GoTrue issues JWT with `sub` (user ID), `role`, custom claims → PostgREST reads JWT → applies matching RLS policies → returns filtered data.

**Connection types** (all available simultaneously):
| Type | Port | Use case |
|------|------|----------|
| PostgREST API | 443 (HTTPS) | Standard CRUD, RLS-protected, recommended for most use |
| Direct | 5432 | Long-lived connections, full Postgres features (IPv6 only) |
| Transaction pooler | 6543 | Serverless/edge, auto-scaling, shares connections |
| Session pooler | 5432 (pooler) | IPv4 compatibility, prepared statements |

**Feb 2026 status**: 1M+ databases, 2,500+ launched daily, PostgREST v14, supabase-js v2, RS256 asymmetric JWTs default, 17 AWS regions.

---

## §2 Decision Trees (use these BEFORE writing any code)

### Which auth method?

```
Simple email/password app?           → signInWithPassword + signUp
Passwordless experience?             → signInWithOtp (magic link or OTP code)
Social login?                        → signInWithOAuth (20+ providers)
Enterprise SSO?                      → signInWithSSO (SAML 2.0, Pro plan+)
Guest/try-before-signup?             → signInAnonymously + linkIdentity later
Need second factor?                  → MFA TOTP enrollment after first factor
Native mobile (Google/Apple)?        → signInWithIdToken (ID token from native SDK)
Existing auth provider (Clerk/Auth0)?→ Third-party auth (validate external JWTs)
```

### Where to put logic?

```
Data access with permission checks?      → RLS policy (runs in Postgres, fastest)
Complex multi-table permission?           → SECURITY DEFINER function called from RLS
Simple computed field / validation?       → Database function + trigger
External API call / webhook?              → Edge Function
Scheduled background job?                 → pg_cron (SQL) or pg_cron → Edge Function
Async processing with retries?            → pgmq queue + consumer Edge Function
Business logic with external dependencies?→ Edge Function + service_role client
```

### Which connection for my use case?

```
Next.js API route / Server Action?       → PostgREST via @supabase/ssr (createServerClient)
Client-side React / Expo?                → PostgREST via supabase-js (createClient)
Edge Function accessing DB?              → PostgREST via supabase-js OR transaction pooler (6543)
Prisma / Drizzle ORM?                    → Transaction pooler (6543) + DIRECT_URL for migrations
Long-running script / migration?         → Direct connection (5432)
Legacy app needing IPv4?                 → Session pooler (5432 via pooler host)
```

### Realtime approach?

```
Ephemeral messages between clients?      → Broadcast (WebSocket, lowest latency)
Track who's online / user cursors?       → Presence (CRDT-backed, sync/join/leave)
React to database INSERT/UPDATE/DELETE?  → Postgres Changes (WAL, simpler) OR
                                           Broadcast from Database trigger (scales better)
Need message history / replay?           → Broadcast Replay (private channels, alpha)
```

---

## §3 The 10 Commandments of Supabase (NEVER violate these)

1. **Enable RLS on EVERY public table — no exceptions.** Dashboard auto-enables; SQL Editor does NOT. Without RLS, anyone with the anon key has full access.

2. **Never use `user_metadata` in RLS policies.** Users can modify it via `supabase.auth.update()`. Use `app_metadata` (server-writable only) or custom claims via the Custom Access Token Hook.

3. **Never trust `getSession()` on the server.** Cookies can be spoofed. Use `getClaims()` (validates JWT signature, no network call) or `getUser()` (contacts Auth server, authoritative).

4. **Wrap auth functions in SELECT for RLS performance.** `(SELECT auth.uid()) = user_id` triggers initPlan caching — **100x+ improvement** vs bare `auth.uid() = user_id` which re-evaluates per row.

5. **Use `@supabase/ssr` for Next.js** — not the deprecated `@supabase/auth-helpers-*` packages. Two functions: `createBrowserClient()` for client, `createServerClient()` for server.

6. **Set `detectSessionInUrl: false` for React Native.** The default (`true`) causes the client to parse the URL on launch, which breaks deep link handling in mobile apps.

7. **Use transaction mode pooler (port 6543) for serverless/edge.** Direct connections (5432) exhaust the pool fast. Keep pooler usage under 40% if also using REST API.

8. **Index every column used in RLS policies.** Without indexes, every policy check does a sequential scan. Also create separate policies per operation instead of `FOR ALL`.

9. **Use `SECURITY DEFINER` + `SET search_path = ''` for complex permission functions.** DEFINER bypasses caller's RLS (needed for cross-table checks). Empty search_path prevents schema injection.

10. **The `service_role` key = god mode — NEVER expose in client code.** It bypasses all RLS. Store in environment variables only. The anon/publishable key IS safe for clients.

---

## §4 Core Code Patterns (quick reference)

### Client setup — Browser

```typescript
import { createClient } from '@supabase/supabase-js'
import type { Database } from './database.types'

export const supabase = createClient<Database>(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!
)
```

### Client setup — Next.js Server (SSR)

```typescript
import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

export async function createClient() {
  const cookieStore = await cookies()
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {
      cookies: {
        getAll() { return cookieStore.getAll() },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options))
          } catch { /* Server Component — ignored */ }
        },
      },
    }
  )
}
```

### Client setup — React Native / Expo

```typescript
import AsyncStorage from '@react-native-async-storage/async-storage'
import { createClient } from '@supabase/supabase-js'

export const supabase = createClient(url, anonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false, // REQUIRED for React Native
  },
})
```

### RLS policy patterns

```sql
-- Owner-based (most common)
CREATE POLICY "Users read own data" ON documents
FOR SELECT TO authenticated
USING ((SELECT auth.uid()) = user_id);

-- Team/org-based (multi-tenant)
CREATE OR REPLACE FUNCTION public.has_role_on_account(account_id uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER SET search_path = '' AS $$
  SELECT EXISTS(SELECT 1 FROM public.accounts_memberships
    WHERE user_id = (SELECT auth.uid())
    AND account_id = has_role_on_account.account_id);
$$;

CREATE POLICY "Team members read" ON documents
FOR SELECT TO authenticated
USING ((SELECT public.has_role_on_account(account_id)));

-- RBAC via custom claims
CREATE POLICY "Admin only" ON admin_data
FOR ALL TO authenticated
USING ((SELECT auth.jwt() ->> 'user_role') = 'admin');

-- Anonymous user restriction
CREATE POLICY "No anonymous access" ON sensitive_data
FOR ALL TO authenticated
USING ((SELECT auth.jwt() ->> 'is_anonymous')::boolean IS FALSE);

-- MFA enforcement
CREATE POLICY "Require MFA" ON financial_data AS RESTRICTIVE
FOR ALL TO authenticated
USING ((SELECT auth.jwt() ->> 'aal') = 'aal2');
```

### Edge Function skeleton

```typescript
// supabase/functions/my-function/index.ts
import { createClient } from 'jsr:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_ANON_KEY')!,
    { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
  )

  const { data, error } = await supabase.from('my_table').select('*')
  return new Response(JSON.stringify({ data, error }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
})
```

### Realtime subscription

```typescript
const channel = supabase
  .channel('room-1')
  .on('broadcast', { event: 'cursor' }, (payload) => {
    console.log('Cursor moved:', payload)
  })
  .on('presence', { event: 'sync' }, () => {
    const state = channel.presenceState()
    console.log('Online users:', state)
  })
  .on('postgres_changes', {
    event: 'INSERT', schema: 'public', table: 'messages',
  }, (payload) => {
    console.log('New message:', payload.new)
  })
  .subscribe()

// Send broadcast
channel.send({ type: 'broadcast', event: 'cursor', payload: { x: 100, y: 200 } })

// Track presence
channel.track({ user_id: 'abc', online_at: new Date().toISOString() })

// Cleanup
supabase.removeChannel(channel)
```

### Vector similarity search

```sql
CREATE OR REPLACE FUNCTION match_documents(
  query_embedding vector(1536),
  match_threshold float DEFAULT 0.78,
  match_count int DEFAULT 10
) RETURNS SETOF documents LANGUAGE sql STABLE AS $$
  SELECT * FROM documents
  WHERE embedding <=> query_embedding < 1 - match_threshold
  ORDER BY embedding <=> query_embedding
  LIMIT match_count;
$$;
```

### CRUD with supabase-js

```typescript
// SELECT with filters and joins
const { data } = await supabase
  .from('posts')
  .select('id, title, author:profiles(username, avatar_url)')
  .eq('published', true)
  .order('created_at', { ascending: false })
  .limit(20)

// INSERT
const { data, error } = await supabase
  .from('posts')
  .insert({ title: 'Hello', content: 'World', user_id: userId })
  .select()
  .single()

// UPDATE
const { error } = await supabase
  .from('posts')
  .update({ title: 'Updated' })
  .eq('id', postId)

// DELETE
const { error } = await supabase
  .from('posts')
  .delete()
  .eq('id', postId)

// RPC (database function)
const { data } = await supabase.rpc('match_documents', {
  query_embedding: embedding,
  match_threshold: 0.78,
  match_count: 10,
})
```

---

## §5 Project Structure

```
project-root/
├── supabase/
│   ├── config.toml              # Project configuration (auth, storage, edge functions)
│   ├── migrations/              # SQL migrations (timestamped, sequential)
│   │   ├── 20260101000000_initial_schema.sql
│   │   └── 20260102000000_add_rls_policies.sql
│   ├── functions/               # Edge Functions (Deno)
│   │   └── my-function/
│   │       └── index.ts
│   ├── tests/                   # pgTAP database tests
│   │   └── rls_test.sql
│   └── seed.sql                 # Seed data for local development
├── lib/
│   └── supabase/
│       ├── client.ts            # Browser client (createBrowserClient)
│       ├── server.ts            # Server client (createServerClient)
│       └── middleware.ts        # Auth middleware (updateSession)
├── database.types.ts            # Generated types (supabase gen types)
└── .env.local
    # NEXT_PUBLIC_SUPABASE_URL=https://<ref>.supabase.co
    # NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
    # SUPABASE_SERVICE_ROLE_KEY=sb_secret_... (server-only!)
```

---

## §6 Reference Files — read the appropriate one BEFORE writing code

Each reference covers a domain in depth. Read the relevant file(s) for the task at hand:

| Topic | Reference File | When to Read |
|-------|---------------|--------------|
| Auth, sessions, PKCE, MFA, SSO, RBAC | `references/auth.md` | Setting up auth, debugging token issues, adding social providers, custom claims |
| Tables, RLS, migrations, PostgREST, indexes | `references/database.md` | Schema design, writing RLS policies, optimizing queries, connection pooling |
| File uploads, image transforms, Edge Functions | `references/storage-and-functions.md` | Implementing file storage, CORS setup, writing Edge Functions, managing secrets |
| Broadcast, Presence, Postgres Changes, Queues | `references/realtime-and-queues.md` | Adding real-time features, pg_cron jobs, durable message queues with pgmq |
| pgvector, embeddings, RAG, hybrid search | `references/ai-and-vectors.md` | Building AI features, vector similarity search, automatic embedding pipelines |
| CLI, local dev, branching, migrations, types | `references/cli-and-ops.md` | Running CLI workflows, local development, database branching, CI/CD setup |
| Next.js SSR, Expo/RN, Kotlin, Swift | `references/platform-integrations.md` | Wiring up client apps, SSR cookie handling, mobile auth, native SDK setup |
| Deploy, CI/CD, security, pricing, breaking changes | `references/deployment-and-security.md` | Going to production, self-hosting, hardening security, understanding pricing |

**When in doubt, read the reference.** These files contain the complete patterns, edge cases, and gotchas that the quick reference above omits.

---

## §7 Version Lock (February 2026)

| Component | Version | Status |
|-----------|---------|--------|
| PostgREST | v14 | Current (~20% more RPS with JWT caching) |
| supabase-js | v2 | Stable |
| @supabase/ssr | latest | Stable (PKCE flow) |
| Edge Functions | Deno 2.1 | Stable (npm: imports supported) |
| pg_cron | v1.6+ | Required for Queues |
| Auth JWT | RS256 | Default (asymmetric, since May 2025) |
| Supavisor | latest | Connection pooling (replaces PgBouncer) |
| Node.js | ≥ 20 | Required for @supabase/ssr and CLI |

> **API key transition**: New format `sb_publishable_...` / `sb_secret_...` replacing `anon` / `service_role`. Both formats work during transition.

---

## §8 Common Gotchas

1. **RLS disabled on new tables**: Tables created via SQL Editor have RLS disabled by default. Dashboard auto-enables it, but SQL does NOT.
   → Always run `ALTER TABLE x ENABLE ROW LEVEL SECURITY;` immediately after `CREATE TABLE`.

2. **Service role key in client**: Using `service_role` key in browser code bypasses ALL RLS policies.
   → Only use anon/publishable key in client apps; `service_role` only in Edge Functions or server-side code.

3. **`user_metadata` in RLS policies**: Users can modify their own `user_metadata` via `supabase.auth.update()`, enabling privilege escalation.
   → Use `app_metadata` (server-writable only) or custom JWT claims via the Custom Access Token Hook.

4. **Trusting `getSession()` on server**: Cookies can be tampered with. The session from cookies is NOT verified cryptographically.
   → Use `getClaims()` (validates JWT signature, no network call) or `getUser()` (contacts Auth server, authoritative).

5. **Missing SELECT wrapper in RLS**: `auth.uid() = user_id` re-evaluates the function call for EVERY row scanned.
   → Wrap as `(SELECT auth.uid()) = user_id` to trigger initPlan caching — documented 100x+ improvement.

6. **Concurrent refresh token use**: Refresh tokens are single-use. Two tabs refreshing simultaneously with the same token causes one to fail.
   → Use `@supabase/ssr` which manages token refresh locking, or implement manual locking.

7. **Port confusion**: `5432` = direct connection (IPv6 only) or session pooler (via pooler host). `6543` = transaction pooler.
   → Use port 6543 for serverless/edge. Use direct 5432 only for long-lived scripts/migrations.

8. **Storage policies forgotten**: By default, NO uploads are allowed even on public buckets. RLS on `storage.objects` must be explicitly created.
   → Create INSERT/SELECT/DELETE policies on `storage.objects` matching your bucket and auth requirements.

9. **Edge Function native binaries**: No Sharp, libvips, or native Node.js modules in Deno runtime.
   → Use WASM alternatives or Supabase's image transformation service (Imgproxy on Pro plan).

10. **Postgres Changes scaling**: Each change is checked against EACH subscriber's RLS policies (100 subscribers = 100 RLS evaluations per change).
    → For high-throughput scenarios, use Broadcast from Database triggers instead of Postgres Changes.

---

## §9 Decision Workflows

### "I need to set up auth for my app"

1. Read `references/auth.md` → choose auth method (email, OAuth, magic link, SSO, anonymous)
2. For web (Next.js): install `@supabase/ssr`, create `createBrowserClient()` and `createServerClient()` helpers
3. For React Native: configure `createClient()` with `AsyncStorage` and `detectSessionInUrl: false`
4. Set up auth middleware to refresh sessions on every request
5. Create RLS policies using `(SELECT auth.uid())` for row-level access control

### "I need to design a database schema"

1. Read `references/database.md` → PostgREST API, RLS guide, query optimization
2. Create tables via SQL migrations in `supabase/migrations/` (never via Dashboard in production)
3. Enable RLS on every table: `ALTER TABLE x ENABLE ROW LEVEL SECURITY;`
4. Write separate policies per operation (SELECT, INSERT, UPDATE, DELETE) — not `FOR ALL`
5. Index every column used in RLS policies and common WHERE clauses
6. Generate types: `supabase gen types typescript --project-id <ref> > database.types.ts`

### "I need real-time subscriptions"

1. Read `references/realtime-and-queues.md` → choose: Broadcast, Presence, or Postgres Changes
2. **Broadcast**: ephemeral messages between clients (lowest latency, no persistence)
3. **Presence**: track who's online, cursors, typing indicators (CRDT-backed sync)
4. **Postgres Changes**: react to INSERT/UPDATE/DELETE on tables (WAL-based, RLS-filtered)
5. For high-throughput, prefer Broadcast from Database triggers over Postgres Changes

### "I need file uploads with access control"

1. Read `references/storage-and-functions.md` → Storage section
2. Create a bucket (public or private) via Dashboard or SQL
3. Create RLS policies on `storage.objects` for INSERT, SELECT, DELETE
4. Upload from client: `supabase.storage.from('bucket').upload(path, file)`
5. For image transforms: use `supabase.storage.from('bucket').getPublicUrl(path, { transform: { width: 200 } })`

### "I need to run server-side logic"

1. Read `references/storage-and-functions.md` → Edge Functions section
2. Create function: `supabase functions new my-function`
3. Use `Deno.serve()` pattern with CORS headers
4. Access DB via `createClient()` with the Authorization header from the request
5. For scheduled tasks: use `pg_cron` (SQL) or `pg_cron` calling an Edge Function via `net.http_post()`

### "I need vector search / AI features"

1. Read `references/ai-and-vectors.md` → pgvector setup, indexing, RAG patterns
2. Enable pgvector: `CREATE EXTENSION IF NOT EXISTS vector;`
3. Add `vector(dimensions)` column to your table
4. Create HNSW index for fast similarity search (or IVFFlat for very large datasets)
5. Write `match_documents()` function using `<=>` (cosine distance) operator
6. For automatic embeddings: use the AI Dashboard pipeline or Edge Functions with OpenAI/Voyage

### "I need to deploy to production"

1. Read `references/deployment-and-security.md` → Cloud plans, security hardening
2. Run `supabase db push` or set up CI/CD with GitHub Actions
3. Enable Point-in-Time Recovery (Pro plan) for backup
4. Harden: enforce MFA, rotate API keys, review RLS policies, enable network restrictions
5. Set up monitoring: pg_stat_statements, Prometheus/Grafana integration

### "I need to debug RLS policy issues"

1. Read `references/database.md` → RLS guide, gotchas and troubleshooting
2. Test policies with `SET ROLE authenticated; SET request.jwt.claims = '{"sub": "user-id"}';`
3. Use `EXPLAIN ANALYZE` to check if policies cause sequential scans (missing indexes)
4. Check that SELECT wrapper `(SELECT auth.uid())` is used (not bare `auth.uid()`)
5. Verify policies exist for each operation type (SELECT, INSERT, UPDATE, DELETE separately)

---

## §10 Helper Script

**File**: `scripts/supabase_helper.ts`

Reusable TypeScript utilities for common Supabase patterns:

- `createTypedClient()` — Create a typed Supabase client with Database generics
- `withRLS()` — Helper for testing RLS policies with specific user roles
- `batchUpsert()` — Upsert in chunks respecting payload size limits
- `generateMigration()` — Template for SQL migration with RLS enabled
- `validateEnv()` — Verify SUPABASE_URL, SUPABASE_ANON_KEY, etc.
- `testEdgeFunction()` — Invoke an Edge Function with auth header for testing

```typescript
import { createTypedClient, withRLS, batchUpsert, validateEnv } from "./scripts/supabase_helper";
```

---

## Key Differences from Convex

| Aspect | Supabase | Convex |
|--------|----------|--------|
| Database | PostgreSQL (relational, SQL) | Document-relational (custom query language) |
| Security | RLS policies (SQL, server-side) | Function-level auth checks |
| Reactivity | Realtime channels (opt-in) | Every query is live by default |
| Functions | Edge Functions (Deno, separate deploy) | Queries/mutations/actions (co-deployed) |
| Type safety | Generated types from schema | Schema-driven validators + codegen |
| Auth | Built-in GoTrue (20+ providers) | Clerk integration or Convex Auth |
| Hosting | Self-hostable (Docker) | Cloud-only |
| Pricing | Per-resource (compute, storage, egress) | Per-function call + bandwidth |

Choose Supabase when: you need full SQL, self-hosting option, existing PostgreSQL ecosystem, or maximum flexibility. Choose Convex when: you want zero-config reactivity, automatic caching, and a fully managed TypeScript backend.

---

## Cross-Skill Integration

### convex-skill
Supabase and Convex are alternative backends — choose one per project. Supabase excels at full SQL power, RLS security policies, self-hosting, and the PostgreSQL ecosystem. Convex excels at zero-config reactivity and TypeScript-native server functions. If migrating from Convex to Supabase, replace reactive queries with Realtime channels, function-level auth with RLS policies, and Convex actions with Edge Functions.

### stripe-skill
Stripe webhooks can target Supabase Edge Functions. Use `Deno.serve()` with `request.text()` for raw body verification. Store subscription state and customer IDs in Supabase tables protected by RLS policies. Use `pg_cron` to periodically reconcile Stripe subscription status with your database.

```typescript
// supabase/functions/stripe-webhook/index.ts
import Stripe from "npm:stripe@^20";

Deno.serve(async (req) => {
  const body = await req.text();
  const sig = req.headers.get("stripe-signature")!;
  const event = Stripe.webhooks.constructEvent(body, sig, Deno.env.get("STRIPE_WEBHOOK_SECRET")!);
  // Process event, update supabase tables...
});
```

### nextjs-web
Use `@supabase/ssr` for cookie-based auth in Next.js. Create `createBrowserClient()` for client components and `createServerClient()` for server components/actions. Auth middleware in `proxy.ts` (Next.js 16) refreshes sessions on every request. Server Components can query Supabase directly — no need for API routes for simple reads.

### elastic-email / ses-manager
Trigger email sends from Supabase Edge Functions or database triggers. For event-driven emails (e.g., send welcome email on user signup), use a database trigger on `auth.users` that calls `pg_net.http_post()` to invoke an Edge Function, which then sends via SES or Elastic Email. Store email delivery events in a Supabase table via webhook Edge Functions.

---

This skill reflects Supabase as of February 2026, including PostgREST v14, @supabase/ssr with PKCE, RS256 asymmetric JWTs, Edge Functions on Deno with npm: support, Supavisor connection pooling, Queues/pgmq, and all current best practices.
