#!/usr/bin/env npx tsx
/**
 * resend_helper_test.ts — Autotest de comportamiento (sin red real) de `../resend_helper.ts`.
 *
 * Stubea `globalThis.fetch` (excepto donde se prueban funciones puras/inyectables) para cubrir:
 * envio, clasificacion de errores + reintentos, honrar `retry-after`, circuit breaker (con reloj
 * inyectado), verificacion de firma de webhooks, el seam `RESEND_BASE_URL`, limites locales
 * (destinatarios/batch/attachments) y `--dry-run`.
 *
 * Run:  npx tsx .claude/skills/resend-skill/scripts/tests/resend_helper_test.ts
 * Exit: 0 = todo pasa
 */
import { createHmac } from 'node:crypto';
import {
  ResendHelper,
  ResendApiError,
  CircuitBreaker,
  CircuitBreakerOpenError,
  CircuitBreakerState,
  retryWithBackoff,
  resolveBaseUrl,
  verifyWebhookSignature,
  parseCliArgs,
  buildDryRunPreview,
} from '../resend_helper.ts';

let passes = 0;
let failures = 0;
function assert(cond: boolean, msg: string): void {
  if (cond) {
    passes++;
    console.log('  PASS:', msg);
  } else {
    failures++;
    console.log('  FAIL:', msg);
  }
}

const jsonResponse = (body: unknown, status = 200): Response => new Response(JSON.stringify(body), { status });

async function main(): Promise<void> {
  // Aislar el seam del entorno heredado: un RESEND_BASE_URL o NODE_ENV=production exportados en la
  // shell cambiarian el resultado de los casos de abajo. Se guardan, se fijan y se restauran SIEMPRE.
  const inheritedBaseUrl = process.env.RESEND_BASE_URL;
  const inheritedNodeEnv = process.env.NODE_ENV;
  delete process.env.RESEND_BASE_URL;
  process.env.NODE_ENV = 'test';
  try {
    await runTests();
  } finally {
    if (inheritedBaseUrl === undefined) delete process.env.RESEND_BASE_URL;
    else process.env.RESEND_BASE_URL = inheritedBaseUrl;
    if (inheritedNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = inheritedNodeEnv;
  }
  console.log(`\n${passes} PASS / ${failures} FAIL`);
  process.exit(failures === 0 ? 0 : 1);
}

async function runTests(): Promise<void> {
  // 1. send hace POST /emails con Authorization, User-Agent e Idempotency-Key autogenerada.
  {
    let calls = 0;
    let method = '';
    let path = '';
    let headers: Record<string, string> = {};
    globalThis.fetch = (async (url: unknown, opts: RequestInit = {}) => {
      calls++;
      method = String(opts.method);
      path = String(url);
      headers = (opts.headers ?? {}) as Record<string, string>;
      return jsonResponse({ id: 'email_123' });
    }) as typeof fetch;

    const helper = new ResendHelper({ apiKey: 're_test' });
    const result = await helper.send({ from: 'a@x.com', to: 'delivered@resend.dev', subject: 'hola', text: 'cuerpo' });

    assert(calls === 1, 'send hace exactamente 1 peticion');
    assert(method === 'POST' && path.endsWith('/emails'), 'send hace POST a /emails');
    assert(headers.Authorization === 'Bearer re_test', 'incluye Authorization: Bearer <apiKey>');
    assert(typeof headers['User-Agent'] === 'string' && headers['User-Agent'].length > 0, 'incluye User-Agent');
    assert(/^resend-helper\/[0-9a-f-]{36}$/i.test(headers['Idempotency-Key'] ?? ''), 'genera Idempotency-Key automatica');
    assert(result.id === 'email_123', 'devuelve { id } del body de exito');
  }

  // 2. retryWithBackoff honra retry-after (delay >= 1000ms) y reintenta exactamente una vez.
  {
    let attempts = 0;
    const sleepCalls: number[] = [];
    const fakeSleep = (ms: number): Promise<void> => {
      sleepCalls.push(ms);
      return Promise.resolve();
    };
    const fn = (): Promise<string> => {
      attempts++;
      if (attempts === 1) {
        return Promise.reject(new ResendApiError('rate limited', 'rate_limit_exceeded', 429, { retryAfterSeconds: 1 }));
      }
      return Promise.resolve('ok');
    };
    const result = await retryWithBackoff(fn, { maxRetries: 3, baseDelayMs: 500, maxDelayMs: 30_000, jitter: true }, () => true, fakeSleep);
    assert(attempts === 2, '429 rate_limit_exceeded con retry-after -> exactamente 2 intentos');
    assert(sleepCalls.length === 1 && sleepCalls[0] >= 1000, 'sleep se invoca con >= 1000ms (retry-after honrado sobre el jitter)');
    assert(result === 'ok', 'el segundo intento tiene exito y se propaga el resultado');
  }

  // 3. 429 daily_quota_exceeded -> NO retryable -> 1 sola peticion, error con su code.
  {
    let calls = 0;
    globalThis.fetch = (async () => {
      calls++;
      return jsonResponse({ name: 'daily_quota_exceeded', message: 'quota exceeded' }, 429);
    }) as typeof fetch;
    const helper = new ResendHelper({ apiKey: 're_test' });
    let caught: unknown;
    try {
      await helper.send({ from: 'a@x.com', to: 'b@x.com', subject: 's' });
    } catch (e) {
      caught = e;
    }
    assert(calls === 1, 'daily_quota_exceeded no se reintenta (1 peticion)');
    assert(caught instanceof ResendApiError && caught.code === 'daily_quota_exceeded', 'error clasificado con su code');
  }

  // 4. 422 validation_error -> 1 sola peticion.
  {
    let calls = 0;
    globalThis.fetch = (async () => {
      calls++;
      return jsonResponse({ name: 'validation_error', message: 'campo invalido' }, 422);
    }) as typeof fetch;
    const helper = new ResendHelper({ apiKey: 're_test' });
    let caught: unknown;
    try {
      await helper.send({ from: 'a@x.com', to: 'b@x.com', subject: 's' });
    } catch (e) {
      caught = e;
    }
    assert(calls === 1, 'validation_error (4xx) no se reintenta (1 peticion)');
    assert(caught instanceof ResendApiError && caught.code === 'validation_error', 'code validation_error preservado');
  }

  // 5. 409 concurrent_idempotent_requests -> SI reintenta y termina con exito.
  {
    let calls = 0;
    globalThis.fetch = (async () => {
      calls++;
      if (calls === 1) return jsonResponse({ name: 'concurrent_idempotent_requests', message: 'en curso' }, 409);
      return jsonResponse({ id: 'email_456' });
    }) as typeof fetch;
    const helper = new ResendHelper({ apiKey: 're_test' });
    const result = await helper.send({ from: 'a@x.com', to: 'b@x.com', subject: 's' });
    assert(calls === 2, 'concurrent_idempotent_requests se reintenta (2 peticiones)');
    assert(result.id === 'email_456', 'resultado final correcto tras el reintento');
  }

  // 6. Circuit breaker: 5 fallos -> OPEN (rechaza sin llamar a fn); con el reloj avanzado -> HALF_OPEN
  //    -> un exito -> CLOSED. Reloj y `fn` inyectados: sin red y sin esperas reales.
  {
    let currentTime = 0;
    const now = (): number => currentTime;
    const cb = new CircuitBreaker({ failureThreshold: 5, resetTimeoutMs: 30_000, halfOpenMax: 1 }, now);
    let fnCalls = 0;
    const failingFn = (): Promise<never> => {
      fnCalls++;
      return Promise.reject(new ResendApiError('down', 'service_unavailable', 503));
    };

    for (let i = 0; i < 5; i++) {
      try {
        await cb.execute(failingFn);
      } catch {
        /* fallo esperado mientras se acumulan los 5 */
      }
    }
    assert(cb.getState() === CircuitBreakerState.OPEN, 'breaker abre tras 5 fallos consecutivos');
    assert(fnCalls === 5, 'fn se llamo exactamente 5 veces (una por fallo)');

    let openRejected = false;
    try {
      await cb.execute(failingFn);
    } catch (e) {
      openRejected = e instanceof CircuitBreakerOpenError;
    }
    assert(openRejected, 'breaker OPEN rechaza con CircuitBreakerOpenError');
    assert(fnCalls === 5, 'breaker OPEN no invoca fn (sin peticion real)');

    currentTime += 30_000; // avanza el reloj inyectado mas alla de resetTimeoutMs
    const recovered = await cb.execute(() => Promise.resolve('recovered'));
    assert(recovered === 'recovered', 'reloj avanzado -> HALF_OPEN permite una prueba, que tiene exito');
    assert(cb.getState() === CircuitBreakerState.CLOSED, 'exito en HALF_OPEN (halfOpenMax=1) cierra el breaker');

    // HALF_OPEN con la prueba en vuelo: una segunda llamada se rechaza SIN cambiar el estado; es la
    // prueba admitida la que decide (aqui: exito -> CLOSED).
    const cb2 = new CircuitBreaker({ failureThreshold: 1, resetTimeoutMs: 1_000, halfOpenMax: 1 }, now);
    try {
      await cb2.execute(failingFn);
    } catch {
      /* primer fallo -> OPEN */
    }
    currentTime += 1_000;
    let releaseProbe: (v: string) => void = () => {};
    const probe = cb2.execute(() => new Promise<string>((resolve) => { releaseProbe = resolve; }));
    let halfOpenRejected = false;
    try {
      await cb2.execute(() => Promise.resolve('extra'));
    } catch (e) {
      halfOpenRejected = e instanceof CircuitBreakerOpenError && (e as CircuitBreakerOpenError).state === CircuitBreakerState.HALF_OPEN;
    }
    assert(halfOpenRejected, 'HALF_OPEN con halfOpenMax alcanzado rechaza con estado HALF_OPEN (no re-abre)');
    assert(cb2.getState() === CircuitBreakerState.HALF_OPEN, 'el rechazo por cupo half-open no cambia el estado');
    releaseProbe('ok');
    assert((await probe) === 'ok' && cb2.getState() === CircuitBreakerState.CLOSED, 'la prueba admitida decide: exito -> CLOSED');

    // HALF_OPEN + error NO reintentable (4xx): el servicio respondio -> el breaker cierra y libera el
    // slot; nunca queda bloqueado en HALF_OPEN.
    const cb3 = new CircuitBreaker({ failureThreshold: 1, resetTimeoutMs: 1_000, halfOpenMax: 1 }, now);
    try {
      await cb3.execute(failingFn);
    } catch {
      /* -> OPEN */
    }
    currentTime += 1_000;
    try {
      await cb3.execute(() => Promise.reject(new ResendApiError('bad', 'validation_error', 422)));
    } catch {
      /* error de validacion, no reintentable */
    }
    assert(cb3.getState() === CircuitBreakerState.CLOSED, 'HALF_OPEN + error no reintentable -> CLOSED (slot liberado)');
    assert((await cb3.execute(() => Promise.resolve('next'))) === 'next', 'la siguiente llamada se admite tras el cierre');
  }

  // 7. verifyWebhookSignature: firma valida / body alterado / timestamp fuera de tolerancia / firmas
  //    multiples separadas por espacio (rotacion de secreto).
  {
    const secret = 'whsec_' + Buffer.from('clave-secreta-de-prueba-hmac').toString('base64');
    const key = Buffer.from(secret.slice('whsec_'.length), 'base64');
    const id = 'msg_test_123';
    const nowSeconds = Math.floor(Date.now() / 1000);
    const timestamp = String(nowSeconds);
    const rawBody = JSON.stringify({ type: 'email.sent', created_at: new Date().toISOString(), data: { email_id: 'evt-1' } });

    const sign = (signedId: string, signedTimestamp: string, signedBody: string): string =>
      'v1,' + createHmac('sha256', key).update(`${signedId}.${signedTimestamp}.${signedBody}`).digest('base64');

    const goodSig = sign(id, timestamp, rawBody);
    const valid = verifyWebhookSignature({ secret, id, timestamp, signature: goodSig, rawBody });
    assert(valid.valid === true, 'firma generada con la misma formula HMAC se acepta');

    const tampered = verifyWebhookSignature({ secret, id, timestamp, signature: goodSig, rawBody: rawBody + 'x' });
    assert(tampered.valid === false, 'body alterado invalida la firma');

    const staleTimestamp = String(nowSeconds - 600);
    const staleSig = sign(id, staleTimestamp, rawBody);
    const stale = verifyWebhookSignature({ secret, id, timestamp: staleTimestamp, signature: staleSig, rawBody });
    assert(stale.valid === false, 'timestamp 600s en el pasado excede la tolerancia por defecto (300s)');

    const nanTol = verifyWebhookSignature({ secret, id, timestamp, signature: goodSig, rawBody, toleranceSeconds: Number.NaN });
    assert(nanTol.valid === false, 'toleranceSeconds NaN se rechaza (no se compara contra NaN)');
    const negTol = verifyWebhookSignature({ secret, id, timestamp, signature: goodSig, rawBody, toleranceSeconds: -1 });
    assert(negTol.valid === false, 'toleranceSeconds negativo se rechaza');

    const multiHeader = `v1,esta-firma-es-invalida ${goodSig}`;
    const multi = verifyWebhookSignature({ secret, id, timestamp, signature: multiHeader, rawBody });
    assert(multi.valid === true, 'firma valida entre varias separadas por espacio (v1,mala v1,buena) se acepta');
  }

  // 8. resolveBaseUrl: ausente / produccion+loopback (ignorado) / no-produccion+override / invalido.
  {
    const absent = resolveBaseUrl({});
    assert(absent.kind === 'absent', 'sin RESEND_BASE_URL -> absent');

    const prodIgnored = resolveBaseUrl({ NODE_ENV: 'production', RESEND_BASE_URL: 'http://127.0.0.1:9999' });
    assert(prodIgnored.kind === 'ignored-prod', 'produccion + RESEND_BASE_URL presente -> ignored-prod');

    const override = resolveBaseUrl({ NODE_ENV: 'test', RESEND_BASE_URL: 'http://127.0.0.1:1234' });
    assert(override.kind === 'override' && (override as { url: string }).url === 'http://127.0.0.1:1234', 'no-produccion + host loopback -> override');

    const invalid = resolveBaseUrl({ NODE_ENV: 'test', RESEND_BASE_URL: 'https://evil.example' });
    assert(invalid.kind === 'invalid', 'host no-loopback -> invalid');

    const prevBaseUrl = process.env.RESEND_BASE_URL;
    const prevNodeEnv = process.env.NODE_ENV;
    process.env.NODE_ENV = 'test';
    process.env.RESEND_BASE_URL = 'https://evil.example';
    let threw = false;
    try {
      new ResendHelper({ apiKey: 're_test' });
    } catch {
      threw = true;
    }
    if (prevBaseUrl === undefined) delete process.env.RESEND_BASE_URL;
    else process.env.RESEND_BASE_URL = prevBaseUrl;
    if (prevNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = prevNodeEnv;
    assert(threw, 'el constructor de ResendHelper lanza ante RESEND_BASE_URL invalida (antes de cualquier request)');
  }

  // 9. Limites locales (validados sin red): sendBatch > 100 items / con attachments; send > 50 destinatarios.
  {
    let calls = 0;
    globalThis.fetch = (async () => {
      calls++;
      return jsonResponse({});
    }) as typeof fetch;
    const helper = new ResendHelper({ apiKey: 're_test' });

    const items101 = Array.from({ length: 101 }, (_, i) => ({ from: 'a@x.com', to: `u${i}@x.com`, subject: 's' }));
    let threw101 = false;
    try {
      await helper.sendBatch(items101);
    } catch {
      threw101 = true;
    }
    assert(threw101 && calls === 0, 'sendBatch rechaza 101 elementos sin llamar a fetch');

    const withAttachment = [{ from: 'a@x.com', to: 'b@x.com', subject: 's', attachments: [{ filename: 'x.txt', content: 'aGVsbG8=' }] }];
    let threwAttachment = false;
    try {
      await helper.sendBatch(withAttachment);
    } catch {
      threwAttachment = true;
    }
    assert(threwAttachment && calls === 0, 'sendBatch rechaza attachments sin llamar a fetch');

    const to51 = Array.from({ length: 51 }, (_, i) => `u${i}@x.com`);
    let threw51 = false;
    try {
      await helper.send({ from: 'a@x.com', to: to51, subject: 's' });
    } catch {
      threw51 = true;
    }
    assert(threw51 && calls === 0, 'send rechaza 51 destinatarios sin llamar a fetch');
  }

  // 10. --dry-run: parseCliArgs + buildDryRunPreview no hacen ninguna peticion de red.
  {
    let calls = 0;
    globalThis.fetch = (async () => {
      calls++;
      return jsonResponse({});
    }) as typeof fetch;

    const args = parseCliArgs(['--action', 'send', '--to', 'delivered@resend.dev', '--subject', 'hola', '--text', 'cuerpo', '--dry-run']);
    assert(args.dryRun === true, 'parseCliArgs reconoce --dry-run');
    assert(args.action === 'send', 'parseCliArgs reconoce --action send');

    const preview = buildDryRunPreview(args, 're_test');
    assert(preview.dryRun === true, 'buildDryRunPreview marca dryRun:true');
    assert(preview.method === 'POST' && preview.path === '/emails', 'buildDryRunPreview arma metodo/ruta de send');
    assert((preview.headers as Record<string, string>).Authorization === 'Bearer <redacted>', 'cabecera Authorization redactada en el preview');
    assert(calls === 0, 'construir el preview de --dry-run no hace ninguna peticion de red');
  }

  // 12. baseUrl explicito en config: misma allowlist loopback que RESEND_BASE_URL.
  {
    let threwNonLoopback = false;
    try {
      new ResendHelper({ apiKey: 're_test', baseUrl: 'https://evil.example' });
    } catch {
      threwNonLoopback = true;
    }
    assert(threwNonLoopback, 'config.baseUrl con host no-loopback lanza en el constructor');

    let threwLoopback = false;
    try {
      new ResendHelper({ apiKey: 're_test', baseUrl: 'http://127.0.0.1:4010' });
    } catch {
      threwLoopback = true;
    }
    assert(!threwLoopback, 'config.baseUrl loopback se acepta');

    process.env.NODE_ENV = 'production';
    let threwProd = false;
    try {
      new ResendHelper({ apiKey: 're_test', baseUrl: 'http://127.0.0.1:4010' });
    } catch {
      threwProd = true;
    }
    process.env.NODE_ENV = 'test';
    assert(threwProd, 'config.baseUrl (aunque sea loopback) se rechaza con NODE_ENV=production');
  }
}

main();
