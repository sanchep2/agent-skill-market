#!/usr/bin/env npx tsx
/**
 * resend_helper.ts — Reusable helper for Resend (transactional email) API operations.
 *
 * ZERO npm dependencies: uses native `fetch` (Node >= 20), `node:crypto` (HMAC/timing-safe
 * compare) and `node:util` (`parseArgs`, only in the CLI entry point). No SDK required.
 *
 * Usage as module:
 *   import { ResendHelper, verifyWebhookSignature } from './resend_helper';
 *   const helper = new ResendHelper({ apiKey: process.env.RESEND_API_KEY! });
 *   const result = await helper.send({
 *     from: process.env.EMAIL_FROM_ADDRESS!,
 *     to: 'delivered@resend.dev',
 *     subject: 'Hola',
 *     text: 'Cuerpo del mensaje',
 *   });
 *
 * Usage as CLI:
 *   npx tsx resend_helper.ts --action send --to delivered@resend.dev --subject Hola --text Cuerpo
 *   npx tsx resend_helper.ts --action batch --file ./batch.json
 *   npx tsx resend_helper.ts --action get --id 49a3999c-...
 *   npx tsx resend_helper.ts --action domains-list
 *   npx tsx resend_helper.ts --action verify-webhook --webhook-id msg_1 --timestamp 1700000000 --signature "v1,base64==" --payload-file ./event.json
 *   npx tsx resend_helper.ts --action diagnostics --format json
 *
 * Env vars:
 *   RESEND_API_KEY          API key (Bearer). UNICA via: nunca por argv (queda en ps/historial).
 *   RESEND_WEBHOOK_SECRET   Secreto `whsec_...` para verify-webhook / smoke.
 *   RESEND_BASE_URL         SOLO test: override del host base. Ignorado en produccion (ver resolveBaseUrl).
 *   EMAIL_FROM_ADDRESS      Direccion `from` por defecto para --action send/batch/smoke.
 *
 * Requires: Node >= 20, sin dependencias
 * API: REST de Resend sin version en ruta (https://api.resend.com) - referencia SDK resend 6.26.0 - verificado 2026-09-04
 */

import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { parseArgs } from 'node:util';

// =============================================================================
// Types & Interfaces
// =============================================================================

interface ResendHelperConfig {
  apiKey: string;
  baseUrl?: string;
  userAgent?: string;
  timeoutMs?: number;
}

interface RetryOptions {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
  jitter: boolean;
}

interface CircuitBreakerOptions {
  failureThreshold: number;
  resetTimeoutMs: number;
  halfOpenMax: number;
}

interface CircuitBreakerStats {
  state: CircuitBreakerState;
  failureCount: number;
  successCount: number;
  halfOpenCalls: number;
  lastFailureTime: number;
  timeUntilRecoveryMs: number;
}

// ─── Resend-specific types ──────────────────────────────────────────────────────

/** Adjunto de email: contenido local en base64/buffer, o `path` remoto (Resend hace el fetch). */
interface EmailAttachment {
  content?: string;
  path?: string;
  filename: string;
  content_type?: string;
  content_id?: string;
}

/** Tag `{name, value}`: solo ASCII+digitos+`_`/`-`, maximo 256 caracteres cada uno. */
interface EmailTag {
  name: string;
  value: string;
}

/** Plantilla publicada (`template.id` es el id o el alias); no combinable con html/text/react. */
interface EmailTemplate {
  id: string;
  variables?: Record<string, string | number>;
}

/** Body de `POST /emails` (y, sin `attachments`, de cada item de `POST /emails/batch`). */
interface SendEmailParams {
  from: string;
  to: string | string[];
  subject: string;
  html?: string;
  text?: string;
  cc?: string | string[];
  bcc?: string | string[];
  reply_to?: string | string[];
  headers?: Record<string, string>;
  tags?: EmailTag[];
  attachments?: EmailAttachment[];
  scheduled_at?: string;
  template?: EmailTemplate;
}

/** `strict` (default, all-or-nothing) o `permissive` (best-effort, no documentado en la referencia
 * oficial de API pero presente en tipos de SDK/CLI — usar con cautela, ver reference del skill). */
interface BatchSendOptions {
  validation?: 'strict' | 'permissive';
}

/** Metadata de rate limit devuelta en headers de CUALQUIER respuesta (10 req/s por team). */
interface RateLimitInfo {
  limit?: number;
  remaining?: number;
  reset?: number;
  retryAfterSeconds?: number;
}

/**
 * Los 24 codigos de error oficiales de la API de Resend (referencia de errores del skill), mas
 * `unknown` para cuerpos de error que no traen `name`/`code` reconocible (proxy/WAF, HTML, texto plano).
 */
type ResendErrorName =
  | 'invalid_idempotency_key'
  | 'validation_error'
  | 'missing_api_key'
  | 'restricted_api_key'
  | 'invalid_api_key'
  | 'email_above_quota'
  | 'invalid_permission'
  | 'suspended_api_key'
  | 'not_found'
  | 'method_not_allowed'
  | 'concurrent_idempotent_requests'
  | 'invalid_idempotent_request'
  | 'resource_locked'
  | 'invalid_attachment'
  | 'invalid_parameter'
  | 'missing_required_field'
  | 'missing_required_parameter'
  | 'daily_quota_exceeded'
  | 'monthly_quota_exceeded'
  | 'rate_limit_exceeded'
  | 'application_error'
  | 'service_unavailable'
  | 'internal_server_error'
  | 'security_error'
  | 'unknown';

/**
 * Resultado de resolver el seam de base URL para tests locales (`RESEND_BASE_URL`).
 * - `absent`: variable no definida, se usa el host oficial.
 * - `override`: no-produccion + host loopback valido -> se usa la URL dada.
 * - `ignored-prod`: `NODE_ENV=production` con la variable presente -> se IGNORA (aviso a stderr).
 * - `invalid`: valor malformado o host no permitido -> el constructor LANZA antes de cualquier request.
 */
type SeamDecision =
  | { kind: 'absent' }
  | { kind: 'override'; url: string }
  | { kind: 'ignored-prod' }
  | { kind: 'invalid'; reason: string };

/** Acciones soportadas por el CLI. */
enum ResendAction {
  Send = 'send',
  Batch = 'batch',
  Get = 'get',
  Cancel = 'cancel',
  DomainsList = 'domains-list',
  DomainVerify = 'domain-verify',
  WebhooksList = 'webhooks-list',
  SuppressionsList = 'suppressions-list',
  VerifyWebhook = 'verify-webhook',
  Smoke = 'smoke',
  Diagnostics = 'diagnostics',
}

/** Error de la API de Resend: envuelve status, codigo clasificado y metadata de rate limit. */
class ResendApiError extends Error {
  public readonly code: ResendErrorName;
  public readonly statusCode: number | null;
  public readonly retryAfterSeconds?: number;
  public readonly rateLimit?: RateLimitInfo;

  constructor(
    message: string,
    code: ResendErrorName,
    statusCode: number | null,
    opts?: { retryAfterSeconds?: number; rateLimit?: RateLimitInfo },
  ) {
    super(message);
    this.name = 'ResendApiError';
    this.code = code;
    this.statusCode = statusCode;
    this.retryAfterSeconds = opts?.retryAfterSeconds;
    this.rateLimit = opts?.rateLimit;
  }
}

// =============================================================================
// CircuitBreaker Pattern
// =============================================================================

/** Estados del circuit breaker. */
enum CircuitBreakerState {
  CLOSED = 'closed', // Normal: llamadas pasan
  OPEN = 'open', // Fallando: llamadas rechazadas
  HALF_OPEN = 'half_open', // Probando recuperacion
}

/** Se lanza cuando el circuit breaker esta abierto y rechaza llamadas. */
class CircuitBreakerOpenError extends Error {
  public readonly state: CircuitBreakerState;
  public readonly failureCount: number;
  public readonly timeUntilRecoveryMs: number;

  constructor(message: string, state: CircuitBreakerState, failureCount: number, timeUntilRecoveryMs: number) {
    super(message);
    this.name = 'CircuitBreakerOpenError';
    this.state = state;
    this.failureCount = failureCount;
    this.timeUntilRecoveryMs = timeUntilRecoveryMs;
  }
}

/**
 * Implementacion del patron Circuit Breaker para proteger contra fallos en cascada.
 *
 * Flujo: CLOSED -> (fallos >= threshold) -> OPEN -> (timeout) -> HALF_OPEN -> (exito) -> CLOSED
 *                                                                            -> (fallo) -> OPEN
 *
 * Uso standalone:
 *   const cb = new CircuitBreaker({ failureThreshold: 5, resetTimeoutMs: 30000, halfOpenMax: 3 });
 *   const result = await cb.execute(() => apiCall());
 *
 * Integrado en ResendHelper:
 *   Todas las llamadas API pasan automaticamente por el circuit breaker.
 */
class CircuitBreaker {
  private state: CircuitBreakerState = CircuitBreakerState.CLOSED;
  private failureCount = 0;
  private successCount = 0;
  private halfOpenCalls = 0;
  private lastFailureTime = 0;
  private lastStateChange: number = Date.now();

  private readonly failureThreshold: number;
  private readonly resetTimeoutMs: number;
  private readonly halfOpenMax: number;
  private readonly now: () => number;

  constructor(
    options: CircuitBreakerOptions = { failureThreshold: 5, resetTimeoutMs: 30000, halfOpenMax: 3 },
    now: () => number = Date.now,
  ) {
    this.failureThreshold = options.failureThreshold;
    this.resetTimeoutMs = options.resetTimeoutMs;
    this.halfOpenMax = options.halfOpenMax;
    this.now = now;
  }

  /** Ejecuta la funcion a traves del circuit breaker. */
  async execute<T>(fn: () => Promise<T>): Promise<T> {
    const currentState = this.getCurrentState();

    if (currentState === CircuitBreakerState.OPEN) {
      const remaining = this.timeUntilRecovery();
      throw new CircuitBreakerOpenError(
        `Circuit breaker OPEN. ${this.failureCount} fallos consecutivos. ` +
          `Reintento en ${Math.ceil(remaining / 1000)}s`,
        currentState,
        this.failureCount,
        remaining,
      );
    }

    if (currentState === CircuitBreakerState.HALF_OPEN) {
      if (this.halfOpenCalls >= this.halfOpenMax) {
        // Ya hay pruebas en vuelo: rechazar SIN tocar el estado. Son esas pruebas (recordSuccess /
        // recordFailure) las que deciden si el circuito cierra o vuelve a abrir; una llamada de mas
        // no es evidencia de fallo del servicio.
        throw new CircuitBreakerOpenError(
          `Circuit breaker HALF_OPEN: maximo de pruebas concurrentes (${this.halfOpenMax}) en vuelo`,
          CircuitBreakerState.HALF_OPEN,
          this.failureCount,
          0,
        );
      }
      this.halfOpenCalls++;
    }

    try {
      const result = await fn();
      this.recordSuccess();
      return result;
    } catch (error) {
      if (this.isRetryable(error)) {
        this.recordFailure();
      } else {
        // Un error NO reintentable (4xx de validacion/auth/cuota) prueba que el servicio respondio:
        // para el breaker es una senal de salud. Sin esto, en HALF_OPEN el slot consumido por esta
        // llamada nunca se liberaria y el breaker quedaria bloqueado para siempre.
        this.recordSuccess();
      }
      throw error;
    }
  }

  private recordSuccess(): void {
    this.failureCount = 0;
    this.successCount++;
    if (this.state === CircuitBreakerState.HALF_OPEN) {
      if (this.successCount >= this.halfOpenMax) {
        this.transitionToClosed();
      }
    }
  }

  private recordFailure(): void {
    this.failureCount++;
    this.successCount = 0;
    this.lastFailureTime = this.now();
    if (this.failureCount >= this.failureThreshold) {
      this.transitionToOpen();
    }
    if (this.state === CircuitBreakerState.HALF_OPEN) {
      this.transitionToOpen();
    }
  }

  /**
   * Clasifica si un error de Resend es transitorio (retryable).
   *
   * Retryable: errores de red (fetch failed / ECONNRESET / ECONNREFUSED / ETIMEDOUT / AbortError),
   * codigos `rate_limit_exceeded`, `concurrent_idempotent_requests`, `application_error`,
   * `service_unavailable`, `internal_server_error`, `resource_locked`, y cualquier 5xx sin codigo
   * reconocible. NO retryable: `daily_quota_exceeded`, `monthly_quota_exceeded`,
   * `invalid_idempotent_request` y el resto de 4xx (validacion, auth, not found, etc.).
   */
  isRetryable(error: unknown): boolean {
    if (error instanceof Error) {
      if (
        error.name === 'AbortError' ||
        error.message.includes('fetch failed') ||
        error.message.includes('ECONNRESET') ||
        error.message.includes('ECONNREFUSED') ||
        error.message.includes('ETIMEDOUT')
      ) {
        return true;
      }
    }
    if (error instanceof ResendApiError) {
      const retryableCodes: ResendErrorName[] = [
        'rate_limit_exceeded',
        'concurrent_idempotent_requests',
        'application_error',
        'service_unavailable',
        'internal_server_error',
        'resource_locked',
      ];
      if (retryableCodes.includes(error.code)) return true;
      const nonRetryableCodes: ResendErrorName[] = ['daily_quota_exceeded', 'monthly_quota_exceeded', 'invalid_idempotent_request'];
      if (nonRetryableCodes.includes(error.code)) return false;
      // Fallback SOLO cuando el codigo no se pudo clasificar (unknown): cualquier 5xx se trata
      // como transitorio; 4xx sin codigo reconocido no se reintenta.
      if (error.code === 'unknown' && error.statusCode !== null && error.statusCode >= 500) return true;
      return false;
    }
    return false;
  }

  private getCurrentState(): CircuitBreakerState {
    if (this.state === CircuitBreakerState.OPEN) {
      if (this.now() - this.lastFailureTime >= this.resetTimeoutMs) {
        this.tryRecovery();
      }
    }
    return this.state;
  }

  private transitionToOpen(): void {
    this.state = CircuitBreakerState.OPEN;
    this.lastStateChange = this.now();
    process.stderr.write(`[CircuitBreaker] OPEN (fallos=${this.failureCount})\n`);
  }

  private transitionToClosed(): void {
    this.state = CircuitBreakerState.CLOSED;
    this.failureCount = 0;
    this.successCount = 0;
    this.halfOpenCalls = 0;
    this.lastStateChange = this.now();
    process.stderr.write(`[CircuitBreaker] CLOSED (recuperado)\n`);
  }

  private tryRecovery(): void {
    this.state = CircuitBreakerState.HALF_OPEN;
    this.halfOpenCalls = 0;
    this.successCount = 0;
    this.lastStateChange = this.now();
    process.stderr.write(`[CircuitBreaker] HALF_OPEN (probando recuperacion)\n`);
  }

  private timeUntilRecovery(): number {
    const elapsed = this.now() - this.lastFailureTime;
    return Math.max(0, this.resetTimeoutMs - elapsed);
  }

  getState(): CircuitBreakerState {
    return this.getCurrentState();
  }

  getStats(): CircuitBreakerStats {
    return {
      state: this.getCurrentState(),
      failureCount: this.failureCount,
      successCount: this.successCount,
      halfOpenCalls: this.halfOpenCalls,
      lastFailureTime: this.lastFailureTime,
      timeUntilRecoveryMs: this.state === CircuitBreakerState.OPEN ? this.timeUntilRecovery() : 0,
    };
  }
}

// =============================================================================
// Retry with Exponential Backoff + Jitter
// =============================================================================

/**
 * Ejecuta una funcion con reintentos y backoff exponencial con full jitter.
 *
 * Full jitter: delay = random(0, min(maxDelay, baseDelay * 2^attempt)).
 * Si el error trae `retryAfterSeconds` (header `retry-after`), el delay efectivo es
 * `max(fullJitter, retryAfterSeconds * 1000)` — respetar el servidor sin bajar por debajo de lo
 * que pide. Si `retryAfterSeconds * 1000` excede `maxDelayMs`, NO se reintenta (se propaga el error):
 * esperar mas que el tope configurado no tiene sentido para un caller sincrono.
 *
 * `sleep` y `now` son inyectables para hacer el backoff determinista en tests.
 */
async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  options: RetryOptions = { maxRetries: 3, baseDelayMs: 500, maxDelayMs: 30000, jitter: true },
  isRetryable: (error: unknown) => boolean = () => true,
  sleep: (ms: number) => Promise<void> = (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
): Promise<T> {
  let lastError: unknown;

  for (let attempt = 0; attempt <= options.maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;

      if (attempt === options.maxRetries || !isRetryable(error)) {
        throw error;
      }

      const exponentialDelay = options.baseDelayMs * Math.pow(2, attempt);
      const cappedDelay = Math.min(exponentialDelay, options.maxDelayMs);
      const fullJitterDelay = options.jitter ? Math.random() * cappedDelay : cappedDelay;

      let delay = fullJitterDelay;
      const retryAfterSeconds = error instanceof ResendApiError ? error.retryAfterSeconds : undefined;
      if (retryAfterSeconds !== undefined) {
        const retryAfterMs = retryAfterSeconds * 1000;
        if (retryAfterMs > options.maxDelayMs) {
          // El servidor pide esperar mas de lo que el caller esta dispuesto a tolerar: no reintentar.
          throw error;
        }
        delay = Math.max(fullJitterDelay, retryAfterMs);
      }

      process.stderr.write(
        `[Retry] Intento ${attempt + 1}/${options.maxRetries} fallido. ` + `Reintentando en ${Math.round(delay)}ms...\n`,
      );

      await sleep(delay);
    }
  }

  throw lastError;
}

// =============================================================================
// Seam de base URL (RESEND_BASE_URL — SOLO test/desarrollo)
// =============================================================================

const LOOPBACK_HOSTNAMES = new Set(['127.0.0.1', 'localhost', '::1', '[::1]']);

/** Unica allowlist de hosts para CUALQUIER override de base URL (env var o config explicita). */
function isLoopbackHostname(hostname: string): boolean {
  const bracketed = hostname === '::1' ? '[::1]' : hostname;
  return LOOPBACK_HOSTNAMES.has(hostname) || LOOPBACK_HOSTNAMES.has(bracketed);
}

/**
 * Resuelve si `RESEND_BASE_URL` debe usarse como override del host oficial.
 *
 * Reglas (fail-closed):
 * - Variable ausente -> `absent` (se usa el host oficial `https://api.resend.com`).
 * - `NODE_ENV=production` + variable presente -> `ignored-prod` (se avisa por stderr y se IGNORA:
 *   nunca se apunta produccion a un host arbitrario por una env var).
 * - No-produccion + URL http(s) valida cuyo hostname es EXACTAMENTE uno de
 *   `127.0.0.1` / `localhost` / `::1` / `[::1]` -> `override`.
 * - Cualquier otro caso (URL malformada, esquema no http(s), host que no es loopback) -> `invalid`.
 *   El constructor de `ResendHelper` LANZA inmediatamente ante `invalid`, antes de cualquier request.
 */
function resolveBaseUrl(env: NodeJS.ProcessEnv = process.env): SeamDecision {
  const raw = env.RESEND_BASE_URL;
  if (!raw) return { kind: 'absent' };

  if (env.NODE_ENV === 'production') {
    process.stderr.write('[resend_helper] RESEND_BASE_URL ignorada en produccion (NODE_ENV=production)\n');
    return { kind: 'ignored-prod' };
  }

  let parsed: URL;
  try {
    parsed = new URL(raw);
  } catch {
    return { kind: 'invalid', reason: `RESEND_BASE_URL no es una URL valida: ${raw}` };
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return { kind: 'invalid', reason: `RESEND_BASE_URL debe usar http(s), recibido: ${parsed.protocol}` };
  }

  const hostname = parsed.hostname;
  if (!isLoopbackHostname(hostname)) {
    return { kind: 'invalid', reason: `RESEND_BASE_URL debe apuntar a un host loopback (127.0.0.1/localhost/::1), recibido: ${hostname}` };
  }

  return { kind: 'override', url: raw };
}

// =============================================================================
// Verificacion de firma de webhooks (Standard Webhooks / Svix)
// =============================================================================

interface VerifyWebhookSignatureParams {
  secret: string;
  id: string;
  timestamp: string;
  signature: string;
  rawBody: string;
  toleranceSeconds?: number;
  now?: () => number;
}

interface VerifyWebhookSignatureResult {
  valid: boolean;
  reason?: string;
}

/**
 * Verifica la firma Standard Webhooks (Svix) de un evento de Resend.
 *
 * Esquema:
 *   1. clave = base64decode(secret sin el prefijo `whsec_`)
 *   2. contenido = `${id}.${timestamp}.${rawBody}`
 *   3. firma esperada = "v1," + base64(HMAC_SHA256(clave, contenido))
 *   4. `signature` puede traer VARIAS firmas separadas por espacio (rotacion de secreto):
 *      valida si CUALQUIERA coincide.
 *   5. Comparacion en tiempo constante (`timingSafeEqual`), nunca `===`.
 *
 * `rawBody` DEBE ser el body crudo tal como llego (sin re-serializar JSON): la firma es sensible
 * a cualquier cambio de formato. `toleranceSeconds` (default 300 = 5 min) rechaza timestamps
 * fuera de ventana en cualquier direccion.
 */
function verifyWebhookSignature(params: VerifyWebhookSignatureParams): VerifyWebhookSignatureResult {
  const { secret, id, timestamp, signature, rawBody, toleranceSeconds = 300, now = Date.now } = params;
  // El default solo cubre `undefined`: un NaN o un negativo explicitos pasarian a la comparacion temporal.
  if (!Number.isFinite(toleranceSeconds) || toleranceSeconds < 0) {
    return { valid: false, reason: 'toleranceSeconds debe ser un numero finito y no negativo' };
  }

  if (!secret.startsWith('whsec_')) {
    return { valid: false, reason: 'el secreto debe tener el prefijo whsec_' };
  }
  const encodedKey = secret.slice('whsec_'.length);
  // Buffer.from(..., 'base64') no lanza ante entrada corrupta: se valida el alfabeto y la longitud a mano
  if (!/^[A-Za-z0-9+/=]+$/.test(encodedKey)) {
    return { valid: false, reason: 'secreto con base64 invalido' };
  }
  const key = Buffer.from(encodedKey, 'base64');
  if (key.length === 0) {
    return { valid: false, reason: 'secreto con base64 invalido' };
  }

  const timestampNum = Number(timestamp);
  if (!Number.isFinite(timestampNum)) {
    return { valid: false, reason: 'timestamp invalido' };
  }
  const nowSeconds = Math.floor(now() / 1000);
  if (Math.abs(nowSeconds - timestampNum) > toleranceSeconds) {
    return { valid: false, reason: 'timestamp fuera de tolerancia' };
  }

  const signedContent = `${id}.${timestamp}.${rawBody}`;
  const expected = createHmac('sha256', key).update(signedContent).digest('base64');
  const expectedToken = `v1,${expected}`;
  const expectedBuf = Buffer.from(expectedToken, 'utf8');

  const candidates = signature.split(' ').map((s) => s.trim()).filter(Boolean);
  if (candidates.length === 0) {
    return { valid: false, reason: 'cabecera de firma vacia' };
  }

  for (const candidate of candidates) {
    const candidateBuf = Buffer.from(candidate, 'utf8');
    if (candidateBuf.length !== expectedBuf.length) continue;
    try {
      if (timingSafeEqual(expectedBuf, candidateBuf)) {
        return { valid: true };
      }
    } catch {
      // Longitud ya igualada arriba; timingSafeEqual no deberia lanzar aqui, pero por si acaso
      // se trata como "no coincide" en vez de propagar.
      continue;
    }
  }

  return { valid: false, reason: 'ninguna firma coincide' };
}

// =============================================================================
// ResendHelper
// =============================================================================

interface RequestResult<T> {
  data: T;
  rateLimit: RateLimitInfo;
}

/**
 * Helper class providing typed, circuit-breaker-protected access to the Resend REST API.
 *
 * Todas las llamadas de red pasan por CircuitBreaker + retryWithBackoff (incluye la
 * regla `retry-after` sobre 429). ZERO dependencias npm — usa fetch nativo + node:crypto.
 */
class ResendHelper {
  private readonly apiKey: string;
  private readonly baseUrl: string;
  private readonly userAgent: string;
  private readonly timeoutMs: number;
  private readonly circuitBreaker: CircuitBreaker;
  private readonly seam: SeamDecision;

  constructor(config: ResendHelperConfig) {
    this.apiKey = config.apiKey;
    this.userAgent = config.userAgent ?? 'resend-skill-helper/1.0';
    this.timeoutMs = config.timeoutMs ?? 15_000;
    this.circuitBreaker = new CircuitBreaker();

    if (config.baseUrl !== undefined) {
      // baseUrl explicito en config: misma politica fail-closed que el seam de env var. En
      // produccion NO existe override (ni loopback): la API key solo viaja a api.resend.com.
      if (process.env.NODE_ENV === 'production') {
        throw new Error('baseUrl explicito no permitido con NODE_ENV=production: en produccion solo https://api.resend.com');
      }
      const validated = validateExplicitBaseUrl(config.baseUrl);
      this.seam = { kind: 'override', url: validated };
      this.baseUrl = validated;
    } else {
      const seam = resolveBaseUrl();
      if (seam.kind === 'invalid') {
        throw new Error(`RESEND_BASE_URL invalida: ${seam.reason}`);
      }
      this.seam = seam;
      this.baseUrl = seam.kind === 'override' ? seam.url : 'https://api.resend.com';
    }
  }

  // ---------------------------------------------------------------------------
  // Peticion HTTP interna
  // ---------------------------------------------------------------------------

  private async request<T>(
    method: string,
    path: string,
    body?: unknown,
    extraHeaders?: Record<string, string>,
  ): Promise<RequestResult<T>> {
    return this.execute(async () => {
      const headers: Record<string, string> = {
        Authorization: `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
        'User-Agent': this.userAgent,
        ...extraHeaders,
      };

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

      let response: Response;
      let rawBody: string;
      try {
        response = await fetch(`${this.baseUrl}${path}`, {
          method,
          headers,
          body: body !== undefined ? JSON.stringify(body) : undefined,
          signal: controller.signal,
        });
        // El timeout sigue armado mientras se lee el body: un servidor que responde cabeceras y
        // luego gotea el cuerpo no puede colgar la llamada indefinidamente.
        rawBody = await response.text();
      } finally {
        clearTimeout(timeout);
      }

      const rateLimit = parseRateLimitHeaders(response.headers);

      if (!response.ok) {
        throw parseErrorResponse(response.status, rawBody, rateLimit);
      }

      const data = (rawBody ? JSON.parse(rawBody) : {}) as T;
      return { data, rateLimit };
    });
  }

  /** Circuit breaker + retry (con soporte de `retry-after`) alrededor de una llamada de red. */
  private async execute<T>(fn: () => Promise<T>): Promise<T> {
    return this.circuitBreaker.execute(() =>
      retryWithBackoff(fn, { maxRetries: 3, baseDelayMs: 500, maxDelayMs: 30_000, jitter: true }, (error) =>
        this.circuitBreaker.isRetryable(error),
      ),
    );
  }

  // ─── Envio ───────────────────────────────────────────────────────────────

  /**
   * Envia un email (`POST /emails`).
   *
   * Si no se pasa `idempotencyKey`, se genera una `resend-helper/<uuid>` automatica para que los
   * reintentos in-process (circuit breaker + backoff) del MISMO send no dupliquen el envio.
   * Rechaza `to` con mas de 50 destinatarios (limite documentado de la API).
   */
  async send(params: SendEmailParams, opts?: { idempotencyKey?: string }): Promise<{ id: string }> {
    const toCount = Array.isArray(params.to) ? params.to.length : 1;
    if (toCount > 50) {
      throw new Error(`send: maximo 50 destinatarios en "to", recibidos ${toCount}`);
    }
    const idempotencyKey = opts?.idempotencyKey ?? `resend-helper/${randomUUID()}`;
    const { data } = await this.request<{ id: string }>('POST', '/emails', params, {
      'Idempotency-Key': idempotencyKey,
    });
    return data;
  }

  /**
   * Envia un lote de hasta 100 emails (`POST /emails/batch`). Falla de forma atomica
   * (all-or-nothing) salvo `validation: 'permissive'` (no documentado oficialmente, ver reference).
   * `attachments` NO esta soportado en batch: se rechaza localmente antes de la llamada.
   */
  async sendBatch(
    items: SendEmailParams[],
    opts?: { idempotencyKey?: string } & BatchSendOptions,
  ): Promise<{ data: { id: string }[] }> {
    if (items.length > 100) {
      throw new Error(`sendBatch: maximo 100 emails por lote, recibidos ${items.length}`);
    }
    if (items.some((item) => item.attachments && item.attachments.length > 0)) {
      throw new Error('sendBatch: "attachments" no esta soportado en /emails/batch');
    }
    // Misma politica que send(): sin clave explicita se genera UNA por invocacion, de modo que los
    // reintentos in-process (breaker + backoff) del MISMO lote reutilicen la clave y no dupliquen
    // el envio; una clave explicita permite coordinar reintentos entre procesos.
    const idempotencyKey = opts?.idempotencyKey || `resend-helper-batch/${randomUUID()}`;
    const headers: Record<string, string> = { 'Idempotency-Key': idempotencyKey };
    if (opts?.validation) headers['x-batch-validation'] = opts.validation;
    const { data } = await this.request<{ data: { id: string }[] }>('POST', '/emails/batch', items, headers);
    return data;
  }

  /** Recupera un email enviado (`GET /emails/{id}`). */
  async getEmail(id: string): Promise<Record<string, unknown>> {
    const { data } = await this.request<Record<string, unknown>>('GET', `/emails/${encodeURIComponent(id)}`);
    return data;
  }

  /** Cancela un email programado (`POST /emails/{id}/cancel`). */
  async cancelEmail(id: string): Promise<Record<string, unknown>> {
    const { data } = await this.request<Record<string, unknown>>('POST', `/emails/${encodeURIComponent(id)}/cancel`);
    return data;
  }

  // ─── Dominios ────────────────────────────────────────────────────────────

  /** Lista los dominios del team (`GET /domains`). */
  async listDomains(): Promise<{ data: Record<string, unknown>[] }> {
    const { data } = await this.request<{ data: Record<string, unknown>[] }>('GET', '/domains');
    return data;
  }

  /** Dispara la verificacion de un dominio (`POST /domains/{id}/verify`). */
  async verifyDomain(id: string): Promise<Record<string, unknown>> {
    const { data } = await this.request<Record<string, unknown>>('POST', `/domains/${encodeURIComponent(id)}/verify`);
    return data;
  }

  // ─── Webhooks ────────────────────────────────────────────────────────────

  /**
   * Lista los webhooks configurados (`GET /webhooks`). Aviso: `signing_secret` NO esta garantizado
   * en el listado (si difiere de create/get, no lo asumas presente aqui).
   */
  async listWebhooks(): Promise<{ data: Record<string, unknown>[] }> {
    const { data } = await this.request<{ data: Record<string, unknown>[] }>('GET', '/webhooks');
    return data;
  }

  // ─── Suppressions ────────────────────────────────────────────────────────

  /** Lista la suppression list de la cuenta (`GET /suppressions`), filtrable por `origin`. */
  async listSuppressions(opts?: { origin?: string }): Promise<{ data: Record<string, unknown>[] }> {
    const qs = opts?.origin ? `?origin=${encodeURIComponent(opts.origin)}` : '';
    const { data } = await this.request<{ data: Record<string, unknown>[] }>('GET', `/suppressions${qs}`);
    return data;
  }

  // ─── Verificacion de webhooks (instancia) ───────────────────────────────

  /** Igual que `verifyWebhookSignature()`, usando `RESEND_WEBHOOK_SECRET` si no se pasa `secret`. */
  verifyWebhook(params: Omit<VerifyWebhookSignatureParams, 'secret'> & { secret?: string }): VerifyWebhookSignatureResult {
    const secret = params.secret ?? process.env.RESEND_WEBHOOK_SECRET;
    if (!secret) {
      return { valid: false, reason: 'falta RESEND_WEBHOOK_SECRET (env)' };
    }
    return verifyWebhookSignature({ ...params, secret });
  }

  // ─── Smoke test ──────────────────────────────────────────────────────────

  /**
   * Envia un email de smoke test a `to` (default `delivered@resend.dev`, direccion oficial de
   * prueba que siempre acepta y nunca entrega de verdad) y consulta su `last_event`.
   */
  async smoke(opts: { from: string; to?: string; label?: string }): Promise<{ id: string; last_event: unknown }> {
    const to = opts.to ?? 'delivered@resend.dev';
    const idempotencyKey = `smoke/${randomUUID()}`;
    const sent = await this.send(
      {
        from: opts.from,
        to,
        subject: opts.label ? `Smoke test: ${opts.label}` : 'Smoke test',
        text: 'Mensaje de prueba generado por resend_helper --action smoke.',
      },
      { idempotencyKey },
    );
    const email = await this.getEmail(sent.id);
    return { id: sent.id, last_event: email.last_event };
  }

  // ─── Diagnostico ─────────────────────────────────────────────────────────

  /** Estado del helper sin exponer la API key: seam de base URL, host efectivo y circuit breaker. */
  diagnostics(): {
    apiKeyConfigured: boolean;
    seam: SeamDecision;
    baseUrl: string;
    breaker: CircuitBreakerStats;
  } {
    return {
      apiKeyConfigured: Boolean(this.apiKey),
      seam: this.seam,
      baseUrl: this.baseUrl,
      breaker: this.circuitBreaker.getStats(),
    };
  }
}

// ─── Helpers internos de parsing HTTP ────────────────────────────────────────

function validateExplicitBaseUrl(baseUrl: string): string {
  let parsed: URL;
  try {
    parsed = new URL(baseUrl);
  } catch {
    throw new Error(`baseUrl no es una URL valida: ${baseUrl}`);
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error(`baseUrl debe usar http(s), recibido: ${parsed.protocol}`);
  }
  // Misma allowlist que RESEND_BASE_URL: un baseUrl explicito NO es una via para sacar la key
  // real hacia un host arbitrario (typo, config heredada, inyeccion por argumento).
  if (!isLoopbackHostname(parsed.hostname)) {
    throw new Error(`baseUrl debe apuntar a un host loopback (127.0.0.1/localhost/::1), recibido: ${parsed.hostname}`);
  }
  return baseUrl;
}

function parseRateLimitHeaders(headers: Headers): RateLimitInfo {
  const limit = headers.get('ratelimit-limit');
  const remaining = headers.get('ratelimit-remaining');
  const reset = headers.get('ratelimit-reset');
  const retryAfter = headers.get('retry-after');
  const info: RateLimitInfo = {};
  // Solo se aceptan valores numéricos finitos: `retry-after` puede llegar como fecha HTTP
  // (RFC 7231) y `Number(fecha)` daría NaN, que rompería el cálculo del backoff.
  const finite = (v: string | null): number | undefined => {
    if (v === null) return undefined;
    const n = Number(v);
    return Number.isFinite(n) ? n : undefined;
  };
  const l = finite(limit); if (l !== undefined) info.limit = l;
  const r = finite(remaining); if (r !== undefined) info.remaining = r;
  const rs = finite(reset); if (rs !== undefined) info.reset = rs;
  const ra = finite(retryAfter); if (ra !== undefined) info.retryAfterSeconds = ra;
  return info;
}

/** Parsea un cuerpo de error de Resend, aceptando `{name, message}` y `{error: {...}}`. */
function parseErrorResponse(statusCode: number, rawBody: string, rateLimit: RateLimitInfo): ResendApiError {
  let parsed: unknown;
  try {
    parsed = rawBody ? JSON.parse(rawBody) : undefined;
  } catch {
    parsed = undefined;
  }

  let name: string | undefined;
  let message: string | undefined;

  if (parsed && typeof parsed === 'object') {
    const obj = parsed as Record<string, unknown>;
    if (typeof obj.name === 'string') name = obj.name;
    if (typeof obj.message === 'string') message = obj.message;
    if (!name && obj.error && typeof obj.error === 'object') {
      const nested = obj.error as Record<string, unknown>;
      if (typeof nested.name === 'string') name = nested.name;
      else if (typeof nested.code === 'string') name = nested.code; // formato {error:{message,code}} (p. ej. el CLI)
      if (typeof nested.message === 'string') message = nested.message;
    }
  }

  const code = isKnownErrorName(name) ? name : 'unknown';
  const finalMessage = message ?? (rawBody ? rawBody.slice(0, 500) : `HTTP ${statusCode}`);

  return new ResendApiError(finalMessage, code, statusCode, {
    retryAfterSeconds: rateLimit.retryAfterSeconds,
    rateLimit,
  });
}

const KNOWN_ERROR_NAMES: ReadonlySet<string> = new Set<ResendErrorName>([
  'invalid_idempotency_key',
  'validation_error',
  'missing_api_key',
  'restricted_api_key',
  'invalid_api_key',
  'email_above_quota',
  'invalid_permission',
  'suspended_api_key',
  'not_found',
  'method_not_allowed',
  'concurrent_idempotent_requests',
  'invalid_idempotent_request',
  'resource_locked',
  'invalid_attachment',
  'invalid_parameter',
  'missing_required_field',
  'missing_required_parameter',
  'daily_quota_exceeded',
  'monthly_quota_exceeded',
  'rate_limit_exceeded',
  'application_error',
  'service_unavailable',
  'internal_server_error',
  'security_error',
]);

function isKnownErrorName(name: string | undefined): name is ResendErrorName {
  return name !== undefined && KNOWN_ERROR_NAMES.has(name);
}

// =============================================================================
// CLI
// =============================================================================

const CLI_ACTIONS: readonly string[] = Object.values(ResendAction);

function printHelp(): void {
  const help = `
resend_helper.ts — CLI para operaciones de la API de Resend

USO:
  npx tsx resend_helper.ts --action <accion> [opciones]

ACCIONES:
  send                Envia un email (--to, --subject, [--from], [--text], [--html])
  batch               Envia un lote (--file <json>|- para stdin, [--validation strict|permissive])
  get                 Recupera un email enviado (--id)
  cancel              Cancela un email programado (--id)
  domains-list        Lista los dominios del team
  domain-verify       Dispara la verificacion de un dominio (--id)
  webhooks-list       Lista los webhooks configurados
  suppressions-list   Lista la suppression list ([--origin])
  verify-webhook      Verifica una firma Standard Webhooks (--webhook-id, --timestamp, --signature, --payload|--payload-file, [--tolerance])
  smoke               Envia un email de prueba y consulta su estado ([--from], [--to], [--label])
  diagnostics         Muestra el estado del helper (seam, base URL, circuit breaker)

CREDENCIALES: SOLO por entorno (RESEND_API_KEY, RESEND_WEBHOOK_SECRET); no existen flags --key/--secret
  porque cualquier valor en argv queda en el historial de la shell y en la lista de procesos (ps).

OPCIONES: --from --to --subject --text --html --idempotency-key --scheduled-at --id --file
  --validation --origin --label --webhook-id --timestamp --signature --payload
  --payload-file --tolerance --dry-run --format json|pretty --help
  --from <email>          Remitente (default: env EMAIL_FROM_ADDRESS)
  --to <email>            Destinatario, repetible o separado por comas (send/smoke)
  --file <ruta|->         JSON del batch (- = stdin)
  --dry-run               Imprime metodo/ruta/cabeceras/body sin red y sale 0

EJEMPLOS:
  npx tsx resend_helper.ts --action send --to delivered@resend.dev --subject Hola --text Cuerpo
  npx tsx resend_helper.ts --action batch --file ./batch.json
  npx tsx resend_helper.ts --action get --id 49a3999c-0ce7-4981-ac2b-4f70d5abc123
  npx tsx resend_helper.ts --action verify-webhook --webhook-id msg_1 --timestamp 1700000000 --signature "v1,base64==" --payload-file ./event.json
  npx tsx resend_helper.ts --action diagnostics --format json
`;
  process.stdout.write(help);
}

interface ParsedCliArgs {
  action?: string;
  from?: string;
  to: string[];
  subject?: string;
  text?: string;
  html?: string;
  idempotencyKey?: string;
  scheduledAt?: string;
  id?: string;
  file?: string;
  validation?: string;
  origin?: string;
  label?: string;
  webhookId?: string;
  timestamp?: string;
  signature?: string;
  payload?: string;
  payloadFile?: string;
  tolerance?: string;
  dryRun: boolean;
  format: string;
  help: boolean;
}

const CLI_STRING_FLAGS = [
  'action', 'from', 'subject', 'text', 'html', 'idempotency-key', 'scheduled-at', 'id', 'file',
  'validation', 'origin', 'label', 'webhook-id', 'timestamp', 'signature', 'payload',
  'payload-file', 'tolerance', 'format',
] as const;

/** Parsea `argv` con `node:util.parseArgs` (strict:false) a un shape tipado del CLI. */
function parseCliArgs(argv: string[]): ParsedCliArgs {
  const options: Record<string, { type: 'string' | 'boolean'; multiple?: boolean; default?: boolean; short?: string }> = {
    to: { type: 'string', multiple: true },
    'dry-run': { type: 'boolean', default: false },
    help: { type: 'boolean', short: 'h', default: false },
  };
  for (const flag of CLI_STRING_FLAGS) options[flag] = { type: 'string' };

  const { values } = parseArgs({ args: argv, options, strict: false, allowPositionals: true });

  const toRaw = (values.to as string[] | undefined) ?? [];
  const to = toRaw.flatMap((v) => v.split(',').map((s) => s.trim()).filter(Boolean));
  const camel = (flag: string): string => flag.replace(/-([a-z])/g, (_, c: string) => c.toUpperCase());

  const parsed: Record<string, unknown> = { to, dryRun: Boolean(values['dry-run']), help: Boolean(values.help) };
  for (const flag of CLI_STRING_FLAGS) parsed[camel(flag)] = values[flag];
  parsed.format = (parsed.format as string | undefined) ?? 'pretty';

  return parsed as unknown as ParsedCliArgs;
}

/** Redacta secretos antes de imprimir: nunca la API key completa ni `signing_secret` completo. */
function redact(value: unknown): unknown {
  if (typeof value === 'string') {
    if (value.startsWith('re_') && value.length > 8) return `${value.slice(0, 6)}...(redacted)`;
    if (value.startsWith('whsec_') && value.length > 10) return `${value.slice(0, 9)}...(redacted)`;
    return value;
  }
  if (Array.isArray(value)) return value.map(redact);
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = k === 'signing_secret' || k === 'Authorization' ? '(redacted)' : redact(v);
    }
    return out;
  }
  return value;
}

function printResult(data: unknown, format: string): void {
  const safe = redact(data);
  process.stdout.write((format === 'json' ? JSON.stringify(safe) : JSON.stringify(safe, null, 2)) + '\n');
}

function readPayloadFile(path: string): string {
  return path === '-' ? readFileSync(0, 'utf8') : readFileSync(path, 'utf8');
}

/** Escribe un error a stderr y termina el proceso (nunca retorna). */
class CliExitError extends Error {
  constructor(public readonly code: number, message: string) {
    super(message);
    this.name = 'CliExitError';
  }
}

/** Termina el flujo del CLI con codigo 1 SIN process.exit(): stdout/stderr se vacian antes de salir. */
function failWith(message: string): never {
  process.stderr.write(`Error: ${message}
`);
  throw new CliExitError(1, message);
}

/** Exige que `value` este presente; si falta, termina el proceso via `failWith`. */
function requireArg<T>(value: T | undefined, message: string): T {
  if (value === undefined || value === '') failWith(message);
  return value as T;
}

/** Cuerpo base de `send`/`smoke`, compartido entre la ejecucion real y `--dry-run`. */
function buildSendBody(args: ParsedCliArgs): Partial<SendEmailParams> {
  return {
    from: args.from ?? process.env.EMAIL_FROM_ADDRESS,
    to: args.to.length === 1 ? args.to[0] : args.to,
    subject: args.subject,
    text: args.text,
    html: args.html,
    scheduled_at: args.scheduledAt,
  };
}

async function main(): Promise<void> {
  const args = parseCliArgs(process.argv.slice(2));

  if (args.help || !args.action) {
    printHelp();
    process.exitCode = args.help ? 0 : 1;
    return;
  }
  if (!CLI_ACTIONS.includes(args.action)) {
    failWith(`accion desconocida: ${args.action}. Ejecuta --help para ver acciones disponibles.`);
  }
  const format = args.format;

  // verify-webhook no requiere API key: se resuelve antes de exigirla.
  if (args.action === ResendAction.VerifyWebhook) {
    const secret = process.env.RESEND_WEBHOOK_SECRET; // solo por entorno, nunca por argv
    if (!secret || !args.webhookId || !args.timestamp || !args.signature) {
      failWith('env RESEND_WEBHOOK_SECRET, --webhook-id, --timestamp y --signature son requeridos');
    }
    const rawBody = args.payloadFile ? readPayloadFile(args.payloadFile) : args.payload ?? '';
    const result = verifyWebhookSignature({
      secret,
      id: args.webhookId,
      timestamp: args.timestamp,
      signature: args.signature,
      rawBody,
      toleranceSeconds: args.tolerance ? Number(args.tolerance) : undefined,
    });
    printResult(result, format);
    process.exitCode = result.valid ? 0 : 1;
    return;
    return;
  }

  // diagnostics tampoco requiere API key: es introspeccion local (informa si hay una configurada).
  if (args.action === ResendAction.Diagnostics) {
    const helper = new ResendHelper({ apiKey: process.env.RESEND_API_KEY ?? '' });
    printResult(helper.diagnostics(), format);
    return;
    return;
  }

  const apiKey = requireArg(process.env.RESEND_API_KEY, 'RESEND_API_KEY (env) requerida; las credenciales nunca viajan por argv');

  if (args.dryRun) {
    printResult(buildDryRunPreview(args, apiKey), format);
    return;
    return;
  }

  const helper = new ResendHelper({ apiKey });

  try {
    let result: unknown;

    switch (args.action) {
      case ResendAction.Send: {
        const body = buildSendBody(args);
        const from = requireArg(body.from, '--from (o env EMAIL_FROM_ADDRESS) es requerido para send');
        if (args.to.length === 0) failWith('--to es requerido para send');
        const subject = requireArg(body.subject, '--subject es requerido para send');
        result = await helper.send({ ...body, from, subject } as SendEmailParams, { idempotencyKey: args.idempotencyKey });
        break;
      }
      case ResendAction.Batch: {
        const file = requireArg(args.file, '--file (ruta o "-" para stdin) es requerido para batch');
        const items = JSON.parse(readPayloadFile(file)) as SendEmailParams[];
        result = await helper.sendBatch(items, {
          idempotencyKey: args.idempotencyKey,
          validation: args.validation as 'strict' | 'permissive' | undefined,
        });
        break;
      }
      case ResendAction.Get: {
        result = await helper.getEmail(requireArg(args.id, '--id es requerido para get'));
        break;
      }
      case ResendAction.Cancel: {
        result = await helper.cancelEmail(requireArg(args.id, '--id es requerido para cancel'));
        break;
      }
      case ResendAction.DomainsList: {
        result = await helper.listDomains();
        break;
      }
      case ResendAction.DomainVerify: {
        result = await helper.verifyDomain(requireArg(args.id, '--id es requerido para domain-verify'));
        break;
      }
      case ResendAction.WebhooksList: {
        result = await helper.listWebhooks();
        break;
      }
      case ResendAction.SuppressionsList: {
        result = await helper.listSuppressions({ origin: args.origin });
        break;
      }
      case ResendAction.Smoke: {
        const from = requireArg(args.from ?? process.env.EMAIL_FROM_ADDRESS, '--from (o env EMAIL_FROM_ADDRESS) es requerido para smoke');
        result = await helper.smoke({ from, to: args.to[0], label: args.label });
        break;
      }
      default: {
        failWith(`accion no implementada: ${args.action}`);
      }
    }

    printResult(result, format);
  } catch (err) {
    if (err instanceof CircuitBreakerOpenError) {
      process.stderr.write(
        JSON.stringify({ error: { type: 'CircuitBreakerOpen', message: err.message, state: err.state, failureCount: err.failureCount } }, null, 2) + '\n',
      );
    } else if (err instanceof ResendApiError) {
      process.stderr.write(JSON.stringify({ error: { code: err.code, message: err.message, statusCode: err.statusCode } }, null, 2) + '\n');
    } else {
      process.stderr.write(JSON.stringify({ error: { code: 'unknown', message: String(err), statusCode: null } }, null, 2) + '\n');
    }
    process.exitCode = 1;
    return;
  }
}

/** Construye la previsualizacion de `--dry-run`: metodo, ruta, cabeceras (key redactada) y body. Sin red. */
function buildDryRunPreview(args: ParsedCliArgs, apiKey: string): Record<string, unknown> {
  const headers: Record<string, string> = {
    Authorization: 'Bearer <redacted>',
    'Content-Type': 'application/json',
    'User-Agent': 'resend-skill-helper/1.0',
  };
  let method = 'GET';
  let path = '/';
  let body: unknown;

  switch (args.action) {
    case ResendAction.Send: {
      method = 'POST';
      path = '/emails';
      headers['Idempotency-Key'] = args.idempotencyKey ?? 'resend-helper/<uuid generado en runtime>';
      body = buildSendBody(args);
      break;
    }
    case ResendAction.Batch: {
      method = 'POST';
      path = '/emails/batch';
      body = args.file ? `<contenido de ${args.file}>` : undefined;
      break;
    }
    case ResendAction.Get: path = `/emails/${args.id ?? '<id>'}`; break;
    case ResendAction.Cancel: {
      method = 'POST';
      path = `/emails/${args.id ?? '<id>'}/cancel`;
      break;
    }
    case ResendAction.DomainsList: path = '/domains'; break;
    case ResendAction.DomainVerify: {
      method = 'POST';
      path = `/domains/${args.id ?? '<id>'}/verify`;
      break;
    }
    case ResendAction.WebhooksList: path = '/webhooks'; break;
    case ResendAction.SuppressionsList: {
      path = args.origin ? `/suppressions?origin=${encodeURIComponent(args.origin)}` : '/suppressions';
      break;
    }
    case ResendAction.Smoke: {
      method = 'POST';
      path = '/emails';
      headers['Idempotency-Key'] = 'smoke/<uuid generado en runtime>';
      body = { from: args.from ?? process.env.EMAIL_FROM_ADDRESS, to: args.to[0] ?? 'delivered@resend.dev', subject: 'Smoke test' };
      break;
    }
    case ResendAction.Diagnostics: path = '(sin red: diagnostics es local)'; break;
    default: path = '(desconocido)';
  }

  return { dryRun: true, method, path, headers, body, apiKeyConfigured: Boolean(apiKey) };
}

// =============================================================================
// Exports
// =============================================================================

export {
  ResendHelper,
  ResendApiError,
  CircuitBreaker,
  CircuitBreakerOpenError,
  CircuitBreakerState,
  ResendAction,
  retryWithBackoff,
  resolveBaseUrl,
  verifyWebhookSignature,
  parseCliArgs,
  // Extra: expuesta para poder probar `--dry-run` sin invocar el proceso completo.
  buildDryRunPreview,
};

export type {
  ResendHelperConfig,
  SendEmailParams,
  EmailAttachment,
  EmailTag,
  EmailTemplate,
  BatchSendOptions,
  RateLimitInfo,
  ResendErrorName,
  SeamDecision,
  RetryOptions,
  CircuitBreakerOptions,
  CircuitBreakerStats,
  VerifyWebhookSignatureParams,
  VerifyWebhookSignatureResult,
  ParsedCliArgs,
};

// Ejecutar CLI solo si se invoca directamente (no como import)
if (typeof process !== 'undefined' && process.argv[1] && (process.argv[1].endsWith('resend_helper.ts') || process.argv[1].endsWith('resend_helper'))) {
  main().catch((err) => {
    if (err instanceof CliExitError) {
      process.exitCode = err.code; // mensaje ya escrito por failWith; sin process.exit(): deja vaciar stdout/stderr
      return;
    }
    process.stderr.write(`Fatal: ${err}
`);
    process.exitCode = 1;
  });
}
