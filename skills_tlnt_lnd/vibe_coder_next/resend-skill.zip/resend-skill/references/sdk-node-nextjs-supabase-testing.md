# SDK Node, Next.js, Supabase y testing — Referencia completa

Cubre el SDK oficial `resend` para Node.js/TypeScript (constructor, contrato de respuesta, superficie completa), el SDK Python, integración con Next.js App Router, las tres rutas de integración con Supabase, otros runtimes (Railway, SMTP genérico, NextAuth, Better Auth, Deno, Bun, Cloudflare Workers) y los patrones de testing que no gastan cuota real de envío. SDK Node `resend` 6.26.0 · SDK Python `resend` 2.43.0 · API REST de Resend sin versión de ruta. `last_verified: 2026-09-04`.

## Table of Contents

1. [Instalación y versiones](#1-instalación-y-versiones)
2. [El cliente Node y su contrato de respuesta](#2-el-cliente-node-y-su-contrato-de-respuesta)
3. [React y React Email](#3-react-y-react-email)
4. [Next.js App Router](#4-nextjs-app-router)
5. [Supabase](#5-supabase)
6. [Otros runtimes e integraciones](#6-otros-runtimes-e-integraciones)
7. [Testing](#7-testing)
8. [Errores comunes y referencias cruzadas](#8-errores-comunes-y-referencias-cruzadas)

---

## 1. Instalación y versiones

### 1.1 Paquete Node resend

```bash
npm install resend@6.26.0
```

Requisitos y dependencias declaradas por el paquete (verificado 2026-09-04):

| Campo | Valor | Nota |
|---|---|---|
| `engines.node` | `>=20` | El repo consumidor puede exigir un mínimo mayor; no es un límite impuesto por Resend |
| `dependencies.postal-mime` | `2.7.5` | Parseo MIME de correo entrante, usado por `emails.receiving.forward` |
| `dependencies.standardwebhooks` | `1.0.0` | Verificación de firma de webhooks (protocolo Standard Webhooks, compatible Svix) |
| `peerDependencies["@react-email/render"]` | `*` (opcional) | Solo hace falta instalarla si se usa la prop `react` en `emails.send()` |

El SDK ya **no** depende del paquete `svix`: la migración a `standardwebhooks` (mergeada 2026-05-25) redujo el tamaño instalado de ~5.0 MB a un valor cercano al original sin cambiar la API publica `resend.webhooks.verify()`.

### 1.2 Paquete Python resend

```bash
pip install resend==2.43.0
```

`requires_python >= 3.7`. Para usar los métodos `_async` (por ejemplo `Emails.send_async`, pensados para `async def` de FastAPI) hace falta el extra `httpx`:

```bash
pip install resend[async]
```

### 1.3 Política de versión fija

Fijar la versión exacta (`resend@6.26.0`, `resend==2.43.0`), nunca un rango (`^`, `~`, `latest`). Antes de subir de versión, revisar los releases de GitHub (`resend/resend-node` y `resend/resend-python`) en busca de `BREAKING CHANGE` en el changelog de cada minor — la tabla de la seccion 1.4 confirma que ninguna de las últimas 8 minors del SDK Node lo trae, pero esa comprobacion se repite en cada bump, no se asume.

### 1.4 Releases sin cambios incompatibles 6.19 a 6.26

Historial de minors del SDK Node (todas retrocompatibles, verificado contra los releases de GitHub 2026-09-04):

| Versión | Fecha | Que añade |
|---|---|---|
| `6.19.0` | 2026-08-10 | `message_id` en los payloads de webhook de email; `broadcasts.cancel()` |
| `6.20.0` | 2026-08-20 | Endpoint de duplicado para `automations` |
| `6.21.0` | 2026-08-20 | `apiKeys.update()` (renombrar una API key); `emails.share()` |
| `6.22.1` | 2026-08-24 | Fix: permite `first_name`/`last_name` nulos en eventos de contacto |
| `6.23.0` | 2026-08-26 | `segments.update()` |
| `6.24.0` | 2026-08-26 | Endpoints de `webhooks` y `events` promovidos de preview a estables |
| `6.25.0` | 2026-08-28 | Soporte de registro CNAME en el SPF de un dominio |
| `6.26.0` | 2026-09-03 | `events.replay()` |

Ninguna introduce un `BREAKING CHANGE` documentado. Si el repositorio consumidor esta en una versión anterior a `6.19.0`, tratar el bump como mantenimiento rutinario de "última versión estable", no como una migración de riesgo.

---

## 2. El cliente Node y su contrato de respuesta

### 2.1 Constructor new Resend

```typescript
import { Resend } from "resend";

// options.baseUrl y options.userAgent son opcionales; ver seccion 7.2 para el uso de baseUrl en tests
const resend = new Resend(process.env.RESEND_API_KEY);
```

```typescript
interface ResendOptions {
  baseUrl?: string; // default: process.env.RESEND_BASE_URL || "https://api.resend.com"
  userAgent?: string; // default: process.env.RESEND_USER_AGENT || `resend-node:${version}`
}
```

El constructor **lanza sincronamente** si no hay API key (ni en el argumento ni en `RESEND_API_KEY`):

```text
Error: Missing API key. Pass it to the constructor `new Resend("re_xxxxxxxxx")`
```

Esto es relevante en Next.js: instanciar `new Resend(...)` a nivel de módulo (top-level, fuera de una función) puede reventar `next build` si la env var no esta presente en tiempo de build en el entorno de CI/deploy — no solo en runtime. La mitigacion es un **init perezoso**: construir el cliente dentro de la función que lo usa, no al importar el archivo (ver seccion 4.1).

### 2.2 Contrato data error headers

`emails.send()` (y el resto de métodos del SDK) **nunca lanza** por errores de dominio de la API ni por fallos de red — los normaliza siempre a una union discriminada:

```typescript
type Response<T> =
  ({ data: T; error: null } | { data: null; error: ErrorResponse })
  & { headers: Record<string, string> | null };
```

Confirmado por un co-founder de Resend en un issue público: *"The error is not thrown, it's returned by the function."* Un `try/catch` que asuma que un `error` truthy implica excepción produce un falso exito silencioso — es el gotcha más repetido de todo el SDK (ver seccion 8).

Los **dos únicos puntos** del SDK que si lanzan son:

1. El constructor de `Resend` sin API key (seccion 2.1).
2. El `render()` interno de la prop `react`, si falta `@react-email/render` (seccion 3.1).

`logError()` (log interno a `console.error`) solo se dispara si `process.env.NODE_ENV !== "production"` — en producción los errores del SDK no aparecen en consola por defecto; el consumidor debe loguearlos el mismo.

### 2.3 ErrorResponse y clasificación por name

```typescript
type ErrorResponse = {
  message: string;
  statusCode: number | null;
  name: RESEND_ERROR_CODE_KEY;
};
```

Valores documentados de `RESEND_ERROR_CODE_KEY` (verificado en el código fuente del SDK y en la página oficial de errores, 2026-09-04):

> Nota: la página oficial de errores (`/api-reference/errors`) documenta un conjunto **parcialmente distinto** (incluye `email_above_quota`, `suspended_api_key`, `resource_locked`, `missing_required_parameter` y `service_unavailable`, que no están en este tipo, y no lista `invalid_api_key`, `invalid_from_address`, `invalid_access`, `invalid_region`, `security_error` ni `internal_server_error`). Programa contra la unión de ambos y un `default`; la tabla completa con status y mensajes está en `sending-and-errors.md` §8.

| name | Nota |
|---|---|
| `validation_error` | El más frecuente; aparece con 400, 403 o 422 según el campo que falle — **no confiar en un `statusCode` fijo para este `name`** |
| `missing_api_key` | Sin `Authorization` o vacio |
| `restricted_api_key` | La API key no tiene permiso para la operación (por ejemplo, `sending_access` intentando gestionar dominios) |
| `invalid_api_key` | Key revocada, mal formada o inexistente |
| `not_found` | Recurso inexistente (id de email, dominio, template, etc.) |
| `method_not_allowed` | Verbo HTTP incorrecto para la ruta |
| `invalid_idempotency_key` | Formato inválido (longitud o caracteres) |
| `invalid_idempotent_request` | Misma `Idempotency-Key`, payload distinto |
| `concurrent_idempotent_requests` | Dos requests simultaneas con la misma key — reintentable más tarde |
| `invalid_attachment` | Adjunto inválido o excede el límite tras Base64 |
| `invalid_from_address` | Dominio no verificado o remitente mal formado |
| `invalid_access` | Región o recurso no accesible con el plan actual |
| `invalid_parameter` | Parámetro fuera de rango o tipo incorrecto |
| `invalid_region` | Región de envío no soportada |
| `missing_required_field` | Falta un campo obligatorio (`from`, `to`, `subject` sin `template`) |
| `monthly_quota_exceeded` | Cuota mensual del plan agotada |
| `daily_quota_exceeded` | Cuota diaria (solo aplica en el plan Free) |
| `rate_limit_exceeded` | Se supero el límite de requests por segundo |
| `security_error` | Contenido o remitente bloqueado por política anti-abuso |
| `application_error` | Error interno o de red normalizado por el SDK — incluye fallos de `fetch` |
| `internal_server_error` | Error 5xx del lado de Resend |

**Regla práctica**: clasificar por `error.name`, usar `statusCode` solo como dato secundario. No existe hoy un export público `RESEND_ERROR_CODES_BY_KEY` (mapa nombre-a-status) en el SDK Node — no asumir su existencia al escribir código generado.

### 2.4 Superficie completa por namespace

Namespaces disponibles en el cliente `Resend` a partir de 6.26.0:

| Namespace | Métodos principales | Nota |
|---|---|---|
| `emails` | `send`/`create`, `get`, `list`, `update`, `cancel`, `share`, `metrics`, `attachments`, `receiving` | `receiving` cubre correo entrante; `share`/`metrics` son adiciones recientes (seccion 1.4) |
| `batch` | `send` | Hasta 100 emails por request; sin adjuntos |
| `domains` | `create`, `get`, `list`, `update`, `verify`, `delete`, `claims` | `claims` gestiona el reclamo de un dominio verificado en otra cuenta |
| `apiKeys` | `create`, `list`, `remove`, `update` | `update` solo renombra la key (6.21.0) |
| `webhooks` | `create`, `get`, `list`, `update`, `remove`, `verify`, `events` | `verify` es síncrono y lanza (seccion 5 del fichero de webhooks del skill); `events` (`list`/`get`/`replay`) es estable desde 6.24.0 |
| `suppressions` | `list`, `get`, `create`, `remove` | Lista de supresión de envío |
| `contacts` | `create`, `get`, `list`, `update`, `remove` | Modelo global por email |
| `segments` | `create`, `get`, `list`, `update`, `remove`, `contacts` | Reemplaza a `audiences` (marcado `@deprecated` en el código fuente, sigue funcionando como alias) |
| `topics` | `create`, `get`, `list`, `update`, `remove` | Gestión de opt-in/opt-out por tipo de contenido |
| `templates` | `create`, `get`, `list`, `update`, `publish`, `duplicate`, `remove` | Solo templates publicados se pueden usar al enviar |
| `broadcasts` | `create`, `get`, `list`, `update`, `send`, `remove`, `cancel` | `cancel` es adicion de 6.19.0 |
| `automations` | `create`, `get`, `list`, `update`, `remove`, `duplicate` | `duplicate` es adicion de 6.20.0 |
| `events` | `create`, `send` | Dispara pasos `wait_for_event` de una automation |
| `contactProperties` | `create`, `get`, `list`, `update`, `remove` | Propiedades custom tipadas por contacto |
| `logs` | `list`, `get` | Incluye cuerpo completo de request/response |

No asumir que un método listado en un ejemplo de terceros existe tal cual: verificar contra `src/index.ts` del repositorio `resend/resend-node` (rama `main`) cuando la firma sea crítica para producción.

---

## 3. React y React Email

### 3.1 Render interno y peer dependency

Cuando `emails.send()` recibe la prop `react`, el SDK renderiza internamente antes de construir el request — no hace falta llamar `render()` a mano:

```typescript
// dentro del SDK (resend/src/render.ts), resumen del comportamiento
export async function render(node: unknown) {
  try {
    const { render } = await import("@react-email/render");
    return render(node as never);
  } catch {
    throw new Error(
      "Failed to render React component. Make sure to install `@react-email/render` or `@react-email/components`.",
    );
  }
}
```

`@react-email/render` es una **peer dependency opcional** (`peerDependenciesMeta.optional: true`): el paquete solo hace falta si se usa `react` en el payload. En la versión fijada por el brief, `@react-email/render@2.1.0`.

### 3.2 Gotcha de bundlers Cloudflare Workers y Turbopack

El `import()` de `@react-email/render` es dinámico, pero varios bundlers estaticos lo resuelven de forma eager y fallan **aunque el código nunca use `react`**:

- **Cloudflare Workers** (`wrangler`/esbuild): build falla con `Could not resolve "@react-email/render"` incluso enviando solo `html`. Mitigacion confirmada por un mantenedor: instalar `@react-email/render` igualmente (es liviano) o marcarla `external` si se controla la configuración del bundler propio.
- **Turbopack + Next.js**: una regresion introducida en `resend@6.1.0` (import movido a un helper compartido) hizo que Turbopack resolviera el import de forma eager y fallará con "Module not found" sin usar `react`. Workaround: añadir `"render"` a `serverExternalPackages` en `next.config`, o instalar `@react-email/render` como dependencia directa. **Fix definitivo en `resend@6.2.2`** — usar esa versión como mínimo recomendado si el proyecto usa Turbopack.

```typescript
// next.config.ts — workaround si no se puede subir de version todavia
const nextConfig = {
  serverExternalPackages: ["render"],
};
export default nextConfig;
```

### 3.3 create-email y CLI de React Email

```bash
npx create-email@latest          # scaffold de un proyecto React Email (carpeta emails/, preview server)
npx react-email@latest dev       # preview server con hot reload
npx react-email@latest resend setup   # conecta el CLI con la API de Resend para subir Templates
npx react-email@latest resend reset   # revierte la conexion
```

`react-email` 6.9.3 re-exporta componentes (`Body`, `Button`, `Tailwind`, `Text`, etc.) desde el paquete "todo en uno" — coexiste con el paquete granular `@react-email/components`; no hay una declaracion oficial de cual es "el" recomendado hacia adelante, ambos siguen activos.

Al pasar un componente como `react` en un archivo `.ts` (sin transpilacion JSX), invocarlo como función, no como JSX:

```typescript
// archivo .ts, sin JSX
react: WelcomeEmail({ firstName: "Ana" }), // funcion invocada, NO <WelcomeEmail firstName="Ana" />
```

### 3.4 Truncado UTF-8 corregido

Versiones antiguas de `@react-email/render` (con React 18) truncaban contenido antes de caracteres UTF-8 multibyte (diacriticos, emoji) por un fallo de `TextDecoder` durante el streaming. Mitigado al pasar a React 19, **resuelto de forma definitiva en `@react-email/render@1.0.2`**. La versión fijada en este skill (`2.1.0`) ya lo incluye — no es una acción pendiente, solo contexto si se audita una versión histórica.

---

## 4. Next.js App Router

### 4.1 Route Handler

```typescript
// app/api/notifications/send/route.ts
import { Resend } from "resend";

export const runtime = "nodejs"; // el SDK usa fetch nativo pero no hay garantia oficial de paridad edge

export async function POST(request: Request) {
  // 1. Autenticar, autorizar y limitar ANTES de leer el body y de gastar cuota: un handler que
  //    envia a partir de lo que llega en el body es un relay abierto con tu API key
  const session = await getSession(request); // helper propio del proyecto (cookie/JWT)
  if (!session) return Response.json({ ok: false }, { status: 401 });
  if (!session.can("notifications:send")) return Response.json({ ok: false }, { status: 403 });
  if (!(await rateLimit.allow(`notify:${session.userId}`))) return Response.json({ ok: false }, { status: 429 });

  // 2. El destinatario y la identidad salen de la sesion, nunca del body; el body solo aporta datos de presentacion
  const { name } = await request.json();
  const userId = session.userId;

  // init perezoso: evita romper `next build` si RESEND_API_KEY falta en build-time
  const resend = new Resend(process.env.RESEND_API_KEY);

  const { data, error } = await resend.emails.send(
    {
      from: process.env.EMAIL_FROM_ADDRESS!,
      to: [session.email],
      subject: "Bienvenida",
      html: `<p>Hola ${name}, tu cuenta esta lista.</p>`,
    },
    { idempotencyKey: `welcome-email/${userId}` }, // SEGUNDO argumento, nunca dentro del payload
  );

  if (error) {
    console.error("resend.emails.send failed", { name: error.name, message: error.message });
    return Response.json({ ok: false, code: error.name }, { status: 502 });
  }
  return Response.json({ ok: true, id: data.id });
}
```

### 4.2 Server Action

```typescript
// app/actions/send-notification.ts
"use server";

import "server-only"; // el bundler falla en build si un componente cliente lo importa
import { Resend } from "resend";

export async function sendNotificationAction(userId: string, name: string) {
  const resend = new Resend(process.env.RESEND_API_KEY);
  const { data, error } = await resend.emails.send(
    { from: process.env.EMAIL_FROM_ADDRESS!, to: ["usuario@tu-dominio.com"], subject: "Bienvenida", html: `<p>Hola ${name}, tu cuenta esta lista.</p>` },
    { idempotencyKey: `welcome-email/${userId}` },
  );
  if (error) return { ok: false as const, code: error.name };
  return { ok: true as const, id: data.id };
}
```

### 4.3 idempotencyKey como segundo argumento

Varias páginas oficiales de quickstart (send-with-nodejs, send-with-nextjs, send-with-vercel-functions) muestran `idempotencyKey` **dentro** del primer objeto (`resend.emails.send({ ..., idempotencyKey: "..." })`). Esa forma es incorrecta: en TypeScript no compila (el tipo `CreateEmailOptions` no tiene ese campo); en JavaScript compila pero la key se descarta en silencio antes de construir el request. El SDK la busca **solo** en el segundo argumento (`options: CreateEmailRequestOptions`). Un agente que copie el snippet de la quickstart literalmente puede terminar enviando emails duplicados en reintentos creyendo que esta protegido por idempotencia — ver tabla de la seccion 8.

Formato recomendado de la key: `<scope>/<id>` (`welcome-user/123456789`, `batch-orders/batch-456`); expira a las 24 horas; máximo 256 caracteres.

### 4.4 CORS y frontera server-only

Llamar a `api.resend.com` directamente desde el navegador siempre falla: Resend no envia cabecera `Access-Control-Allow-Origin`. Es una barrera de diseño, no un bug a reportar — el patron correcto es enviar siempre desde el servidor (Route Handler o Server Action) y que el cliente llame a esa ruta propia.

```text
Navegador                    api.resend.com
   |  POST /emails                 ^
   |  (fetch directo)              |
   X-------- bloqueado por CORS ---+   (sin Access-Control-Allow-Origin)

Navegador          Route Handler / Server Action        Resend API
   |  fetch same-origin   |   runtime = "nodejs"          ^
   |---------------------->|   RESEND_API_KEY (env)       |
   |                       |------------------------------>|  HTTPS + Bearer
   |                       |<------------------------------|  { data, error, headers }
   |<----------------------|
```

La API key **nunca** debe llegar al bundle de cliente: no importar `resend` en un archivo `"use client"`, no exponer `RESEND_API_KEY` con el prefijo `NEXT_PUBLIC_`.

### 4.5 waitUntil y envío sin await patron Better Auth

Better Auth recomienda explicitamente, para hooks de auth (`sendResetPassword`, `sendVerificationEmail`, `magicLink.sendMagicLink`), llamar al envío **sin `await`**:

```typescript
// dentro de un hook de auth (reset password, magic link, verificacion)
export function sendResetPassword({ user, url }: { user: { email: string }; url: string }): Promise<void> {
  const resend = new Resend(process.env.RESEND_API_KEY);

  // El hook NO espera el envio: el tiempo de respuesta del endpoint de auth no debe filtrar si
  // la cuenta existe (timing attack). Pero el resultado SI se observa: un fallo de envio se
  // registra y se mide, nunca se descarta con `void promesa`.
  return resend.emails
    .send({
      from: process.env.EMAIL_FROM_ADDRESS!,
      to: [user.email],
      subject: "Restablecer contrasena",
      html: `<p>Abre este enlace para continuar: ${url}</p>`,
    })
    .then(({ error }) => {
      if (error) logger.error({ msg: "auth_email_failed", kind: "reset_password", name: error.name });
    });
}

// En el hook de auth: sin await, pero la promesa queda REGISTRADA en el runtime para que una
// plataforma serverless no termine el proceso antes de que el fetch complete:
//   Next.js:            after(() => sendResetPassword({ user, url }))   // import { after } from "next/server"
//   Vercel / Cloudflare: waitUntil(sendResetPassword({ user, url }))
//   Node persistente:   void sendResetPassword({ user, url })            // el .then() ya registra el error
```

En plataformas serverless (Vercel Functions, Cloudflare Workers, Next.js en Vercel), registrar SIEMPRE esa promesa con `waitUntil(...)` / `after(...)` — si no, la función puede terminar y congelar el proceso antes de que el `fetch` interno del SDK complete la llamada HTTP, y el error registrado en el `.then()` nunca llega a escribirse.

---

## 5. Supabase

### 5.1 Tres rutas de integración

| Ruta | Control | Cuando usarla |
|---|---|---|
| Integración nativa (Dashboard de Resend a 1 clic) | Bajo — plantillas de Auth menos personalizables | Prototipo rápido, MVP sin requisitos de branding en los emails de Auth |
| Auth Hooks + función custom | Total — permite usar templates propios (React Email o el motor de templates del proyecto) | Producción: control de idioma, marca, tracking desactivado |
| SMTP genérico apuntando a Resend | Medio — usa el flujo SMTP interno de Supabase Auth | Setups self-hosted o cuando no se quiere escribir una función custom |

### 5.2 SMTP puertos y límites de Auth

```text
Host:     smtp.resend.com
Usuario:  resend
Password: <RESEND_API_KEY>
Puertos:  25   (STARTTLS)
          465  (SMTPS implicito)   <- el que documentan las guias de Supabase
          587  (STARTTLS)
          2465 (SMTPS implicito)
          2587 (STARTTLS)
```

Límites de envío de Supabase Auth (verificado 2026-09-04, dos fuentes oficiales independientes coinciden en la cifra):

- **Sin proveedor SMTP custom**: el límite del servicio de correo interno de Supabase es de **2 emails por hora** por proyecto, para confirmación, magic link, reset de password e invitaciones **combinados**. No hay error visible en el cliente cuando se excede: la llamada `signUp`/`resetPasswordForEmail` "tiene exito" pero el correo nunca llega.
- **Con Resend configurado como SMTP custom**: el límite sube a **25 emails por hora por defecto**, configurable en la seccion de Authentication del proyecto.

Idempotencia por SMTP: header de mensaje `Resend-Idempotency-Key` (equivalente al header HTTP `Idempotency-Key` de la API REST).

### 5.3 Auth Hooks con función custom

Patron recomendado para control total: un Auth Hook (`send_email` hook o equivalente en la configuración de Auth) invoca una función propia que construye el email (con el motor de templates del proyecto o React Email) y llama a `resend.emails.send()`:

```typescript
// funcion invocada por el Auth Hook de "send email" (runtime Node, no Edge Function)
import { Resend } from "resend";

interface AuthEmailHookPayload {
  user: { email: string };
  email_data: { token_hash: string; redirect_to: string; email_action_type: string };
}

export async function handleAuthEmailHook({ user, email_data }: AuthEmailHookPayload) {
  const confirmUrl = `${email_data.redirect_to}?token_hash=${email_data.token_hash}&type=${email_data.email_action_type}`;
  const { error } = await new Resend(process.env.RESEND_API_KEY).emails.send({
    from: process.env.EMAIL_FROM_ADDRESS!,
    to: [user.email],
    subject: "Confirma tu cuenta",
    html: `<p>Confirma tu cuenta: <a href="${confirmUrl}">${confirmUrl}</a></p>`,
  });
  if (error) throw new Error(`auth email hook failed: ${error.name}`);
}
```

Recomendaciones de entregabilidad específicas para emails de Auth (fuente oficial de Resend):

1. Dominio propio en el `from` en vez de `*.supabase.co`, para que el remitente y los links del correo compartan dominio.
2. Subdominio dedicado para auth/transaccional (aisla la reputación del dominio raíz).
3. **Desactivar el tracking de open/click en el dominio usado para Auth** — el link tracking reescribe URLs y puede corromper magic links de un solo uso.
4. Preparar el flujo para "link scanners" corporativos que hacen `GET` automático sobre links de un solo uso (mitigacion: página intermedia con boton explícito "Confirmar" que redirige al link real, en vez de auto-redirigir).
5. Configurar DMARC (al menos `p=none` con `rua` para monitoreo).

### 5.4 Edge Functions Deno sin el SDK npm

El patron oficial para Supabase Edge Functions **no usa el SDK Node** — usa `fetch` nativo, evitando problemas de resolución de paquetes npm en Deno:

```typescript
// supabase/functions/send-notification/index.ts (Deno)
import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (req: Request): Promise<Response> => {
  // 1. Autenticar al llamador por su JWT (la anon key es pública: no autoriza nada por sí sola)
  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
  });
  const { data: { user } } = await supabase.auth.getUser();
  if (!user?.email) return new Response("Unauthorized", { status: 401 });

  // 2. Cuota por usuario antes de gastar envíos; el destinatario lo decide el servidor (el propio
  //    usuario o una lista autorizada), NUNCA el body — si no, la función es un relay abierto
  const { data: allowed } = await supabase.rpc("consume_email_quota", { p_user_id: user.id });
  if (!allowed) return new Response("Too many requests", { status: 429 });
  const { subject, html } = await req.json();
  if (typeof subject !== "string" || subject.length > 200 || typeof html !== "string" || html.length > 100_000) {
    return new Response("Bad request", { status: 400 });
  }

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${Deno.env.get("RESEND_API_KEY")}`,
      "User-Agent": "mi-app/1.0", // obligatorio con fetch directo: sin User-Agent la API responde 403
      "Idempotency-Key": `notify/${user.id}/${crypto.randomUUID()}`,
    },
    body: JSON.stringify({ from: Deno.env.get("EMAIL_FROM_ADDRESS"), to: [user.email], subject, html }),
  });
  return new Response(await res.text(), { status: res.status, headers: { "Content-Type": "application/json" } });
});
```

Deploy y desarrollo local:

```bash
supabase functions deploy send-notification
supabase functions serve send-notification --no-verify-jwt
```

### 5.5 Tabla genérica de eventos de webhook con RLS deny-all

Patron recomendado para persistir eventos de webhook de Resend (bounces, quejas, entregas retrasadas) sin depender de la retención de 30 días de Resend: una tabla genérica de eventos, con RLS habilitada y **sin ninguna política de lectura para el cliente** — solo el `service_role` (usado por el handler del webhook, server-only) puede escribir y leer.

```sql
create table if not exists public.email_events (
  id uuid primary key default gen_random_uuid(),
  provider_event_id text not null,      -- cabecera svix-id: identifica ESTA entrega (clave de dedupe)
  provider_message_id text,             -- data.email_id: se repite entre eventos del mismo email
  event_type text not null,
  payload jsonb not null,               -- solo los campos de la allow-list, nunca cabeceras de firma
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  unique (provider_event_id)
);

create index if not exists email_events_message_type_idx
  on public.email_events (provider_message_id, event_type);

alter table public.email_events enable row level security;
-- deny-all: ninguna politica para anon/authenticated; solo el service_role
-- (usado exclusivamente por el handler server-only del webhook) puede leer/escribir.
```

El `unique (provider_event_id)` (el `svix-id` de cada entrega) hace el `insert` idempotente ante reintentos del webhook; el índice `(provider_message_id, event_type)` sirve para consultar el historial de un email (Resend no garantiza entrega exactamente-una-vez ni orden — ver la referencia de webhooks del skill): un `on conflict do nothing` en el insert evita duplicados sin necesitar deduplicación en memoria.

---

## 6. Otros runtimes e integraciones

### 6.1 Railway

Railway no impone nada específico al SDK de Resend: se declara `RESEND_API_KEY` como variable de entorno del servicio y el código Node funciona igual que en cualquier otro host. Resend publica una plantilla de onboarding para Railway pensada solo como introduccion (envia un email cada vez que se visita la URL del deploy) — no es un patron de producción, no reutilizar tal cual.

### 6.2 SMTP genérico y Nodemailer

```typescript
import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  host: "smtp.resend.com",
  port: 465,
  secure: true, // true para 465/2465 (SMTPS implicito); false + STARTTLS para 25/587/2587
  auth: { user: "resend", pass: process.env.RESEND_API_KEY! },
});

await transporter.sendMail({
  from: process.env.EMAIL_FROM_ADDRESS!,
  to: "usuario@tu-dominio.com",
  subject: "Hola",
  html: "<p>Enviado via SMTP</p>",
  headers: { "Resend-Idempotency-Key": "welcome-user/123456789" },
});
```

Resend no expone logs de servidor SMTP para debug: cualquier diagnostico de un envío por SMTP se revisa en el dashboard (tabla de emails), no en un log de sesión SMTP.

### 6.3 NextAuth EmailProvider

```typescript
import EmailProvider from "next-auth/providers/email";

EmailProvider({
  server: {
    host: "smtp.resend.com",
    port: 465,
    auth: { user: "resend", pass: process.env.RESEND_API_KEY },
  },
  from: process.env.EMAIL_FROM_ADDRESS,
});
```

Variables equivalentes si se usa la convencion de env vars de Auth.js: `EMAIL_SERVER_HOST=smtp.resend.com`, `EMAIL_SERVER_PORT=465`, `EMAIL_SERVER_USER=resend`, `EMAIL_SERVER_PASSWORD=<RESEND_API_KEY>`, `EMAIL_FROM=<remitente>`.

### 6.4 Better Auth hooks

Además del patrón de envío sin `await` de la seccion 4.5, Better Auth expone hooks equivalentes para OTP y magic link. Misma regla: el hook no espera, pero el resultado `{ data, error }` se observa y la promesa se registra en el runtime (`waitUntil`/`after`), nunca se descarta con `void`:

```typescript
emailOTP: {
  async sendVerificationOTP({ email, otp }: { email: string; otp: string }) {
    const resend = new Resend(process.env.RESEND_API_KEY);
    const pending = resend.emails
      .send({
        from: process.env.EMAIL_FROM_ADDRESS!,
        to: [email],
        subject: "Tu codigo de verificacion",
        html: `<p>Tu codigo es <strong>${otp}</strong></p>`,
      })
      .then(({ error }) => {
        if (error) logger.error({ msg: "auth_email_failed", kind: "otp", name: error.name });
      });
    waitUntil(pending); // Vercel/Cloudflare; en Next.js: after(() => pending)
  },
},
```

### 6.5 Deno y Bun con fetch

El SDK usa `fetch` global nativo (sin `node-fetch`/axios), por lo que en principio funciona en cualquier runtime con `fetch`/`Headers`/`FormData` estándar. Sin embargo, el patron **recomendado y verificado oficialmente** para Deno (Supabase Edge Functions) es `fetch` directo sin el SDK npm (seccion 5.4) — evita el problema de resolución de paquetes npm en Deno. Para Bun no hay documentación oficial detallada más alla de una guia genérica de "enviar con Bun"; verificar comportamiento propio antes de depender de paridad total con Node en producción.

```typescript
// Deno o Bun, fetch nativo, sin el SDK npm
const res = await fetch("https://api.resend.com/emails", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    Authorization: `Bearer ${Deno.env.get("RESEND_API_KEY")}`, // Bun: process.env
    "User-Agent": "mi-app/1.0", // obligatorio con fetch directo: sin User-Agent la API responde 403
  },
  body: JSON.stringify({ from: Deno.env.get("EMAIL_FROM_ADDRESS"), to: ["usuario@tu-dominio.com"], subject: "hola", html: "<strong>funciona</strong>" }),
});
```

### 6.6 Cloudflare Workers

Instalar `@react-email/render` como dependencia explícita del proyecto **aunque no se use `react`** (seccion 3.2), para evitar que `wrangler`/esbuild falle resolviendo el import dinámico interno del SDK: `npm install resend @react-email/render`.

```typescript
// src/index.ts (Cloudflare Worker)
export default {
  async fetch(_req: Request, env: { RESEND_API_KEY: string; EMAIL_FROM_ADDRESS: string }) {
    const { Resend } = await import("resend");
    const { data, error } = await new Resend(env.RESEND_API_KEY).emails.send({
      from: env.EMAIL_FROM_ADDRESS,
      to: ["usuario@tu-dominio.com"],
      subject: "Desde un Worker",
      html: "<p>Enviado desde Cloudflare Workers</p>",
    });
    return Response.json(error ? { ok: false, code: error.name } : { ok: true, id: data!.id });
  },
};
```

---

## 7. Testing

### 7.1 Direcciones de prueba resend dev

| Dirección | Simula | Soporta +label |
|---|---|---|
| `delivered@resend.dev` | Entrega exitosa | Si |
| `bounced@resend.dev` | Bounce | Si |
| `complained@resend.dev` | Queja de spam | Si |
| `suppressed@resend.dev` | Supresión | No |

Estas direcciones cuentan contra la cuota de la cuenta. Enviar a `@example.com`/`@test.com` devuelve **422** (Resend los bloquea activamente para proteger reputación). El remitente sandbox `onboarding@resend.dev` **solo puede enviar a la propia dirección de la cuenta** de Resend — cualquier flujo de demo/onboarding que intente mandarle un correo a un destinatario distinto del dueno de la cuenta falla con `validation_error` hasta que se verifique un dominio propio.

### 7.2 Seam de base URL máquina de 4 estados

El único mecanismo soportado por el propio SDK para redirigir el `fetch` interno a un servidor de test propio es el `baseUrl` del constructor (o la env var `RESEND_BASE_URL`, que el constructor lee por defecto). Ese seam es potente y peligroso a la vez: si algo más en el proceso setea `RESEND_BASE_URL` a un host arbitrario (por ejemplo, otra libreria que reutiliza el mismo nombre de variable), el SDK puede terminar mandando la **API key real** a un host que no es Resend. La mitigacion es una guarda fail-closed de 4 estados que decide, en cada arranque, si el override se respeta o se ignora:

```text
                    ┌────────────────────────────┐
                    │ RESEND_BASE_URL definida ?  │
                    └──────────────┬─────────────┘
                    NO             │             SI
          ┌───────────────────────┘             └───────────────────────┐
          v                                                              v
 ┌──────────────────────┐                          ┌──────────────────────────────┐
 │ ESTADO 1: ausente     │                          │ NODE_ENV === "production" ?  │
 │ -> usar               │                          └───────────┬───────────────────┘
 │ https://api.resend.com│                    SI                │              NO
 │ (comportamiento real) │          ┌──────────────────────────┘              │
 └──────────────────────┘           v                                        v
                          ┌───────────────────────┐         ┌──────────────────────────┐
                          │ ESTADO 2: produccion   │         │ host es loopback         │
                          │ + presente             │         │ (127.0.0.1/localhost/::1)?│
                          │ -> IGNORAR el override,│         └───────────┬────────────────┘
                          │ log de aviso, usar la  │             SI     │      NO
                          │ URL real de todos modos│      ┌─────────────┘      │
                          └───────────────────────┘       v                    v
                                                ┌──────────────────────┐  ┌──────────────────────┐
                                                │ ESTADO 3: no-prod     │  │ ESTADO 4: no-prod      │
                                                │ + loopback            │  │ + otro host            │
                                                │ -> OVERRIDE: usar el  │  │ -> ABORTAR (throw);    │
                                                │ baseUrl de test       │  │ nunca mandar la key    │
                                                └──────────────────────┘  │ real a un host arbitrario│
                                                                          └──────────────────────┘
```

```typescript
// resolveResendBaseUrl(): implementacion de referencia de la guarda de 4 estados
function resolveResendBaseUrl(): string | undefined {
  const raw = process.env.RESEND_BASE_URL;
  if (!raw) return undefined; // Estado 1: ausente -> real

  if (process.env.NODE_ENV === "production") {
    console.warn("RESEND_BASE_URL ignorado en produccion");
    return undefined; // Estado 2: produccion + presente -> ignorar
  }

  const host = new URL(raw).hostname;
  const isLoopback = ["127.0.0.1", "localhost", "::1", "[::1]"].includes(host);
  if (isLoopback) return raw; // Estado 3: no-prod + loopback -> override

  throw new Error(`RESEND_BASE_URL apunta a un host no-loopback fuera de produccion: ${host}`); // Estado 4: abortar
}

const resend = new Resend(process.env.RESEND_API_KEY, { baseUrl: resolveResendBaseUrl() });
```

### 7.3 Servidor HTTP real en loopback

Patron de test recomendado para verificar el contrato exacto que el SDK envia (headers, body, traduccion de errores) sin mockear a nivel de libreria: levantar un servidor `node:http` real en un puerto efimero (`0`) y apuntar el `baseUrl` del cliente de test ahí.

```typescript
import { createServer } from "node:http";
import { Resend } from "resend";
import { describe, expect, it, afterEach, beforeEach } from "vitest";

describe("integracion con Resend", () => {
  let server: ReturnType<typeof createServer>;
  let baseUrl: string;
  let lastRequest: { path: string; headers: Record<string, string>; body: unknown } | undefined;

  beforeEach(async () => {
    lastRequest = undefined;
    server = createServer((req, res) => {
      let raw = "";
      req.on("data", (chunk) => (raw += chunk));
      req.on("end", () => {
        lastRequest = { path: req.url!, headers: req.headers as Record<string, string>, body: raw ? JSON.parse(raw) : undefined };
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ id: "test-email-id" }));
      });
    });
    await new Promise<void>((resolve) => server.listen(0, resolve));
    const port = (server.address() as { port: number }).port;
    baseUrl = `http://127.0.0.1:${port}`;
  });

  afterEach(() => new Promise<void>((resolve) => server.close(() => resolve())));

  it("envia POST /emails con Idempotency-Key", async () => {
    const resend = new Resend("re_test_key", { baseUrl });
    const { data, error } = await resend.emails.send(
      { from: process.env.EMAIL_FROM_ADDRESS!, to: ["usuario@tu-dominio.com"], subject: "Test", html: "<p>hola</p>" },
      { idempotencyKey: "test/1" },
    );
    expect(error).toBeNull();
    expect(data?.id).toBe("test-email-id");
    expect(lastRequest?.path).toBe("/emails");
    expect(lastRequest?.headers["idempotency-key"]).toBe("test/1");
  });
});
```

Este patron también sirve para probar la traduccion de errores propia (por ejemplo, mapear `error.name === "rate_limit_exceeded"` a un reintento con backoff): el servidor de test responde con el status y el `name` que se quiera reproducir, sin depender de la red real ni gastar cuota.

### 7.4 Playwright page.route

Para tests end-to-end de UI que disparan un envío de correo, mockear la ruta propia del servidor (nunca `api.resend.com` directamente, por la barrera de CORS de la seccion 4.4):

```typescript
import { test, expect } from "@playwright/test";

test("muestra confirmacion tras enviar la notificacion", async ({ page }) => {
  await page.route("**/api/notifications/send", async (route) => {
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({ ok: true, id: "621f3ecf-test" }),
    });
  });

  await page.goto("/dashboard");
  await page.getByRole("button", { name: /enviar notificacion/i }).click();
  await expect(page.getByText(/notificacion enviada/i)).toBeVisible();
});
```

Este mock no gasta cuota de envío ni depende de que `RESEND_API_KEY` este configurada en el entorno de CI.

### 7.5 Emulador emulators resend

`@emulators/resend` (npm, versión `0.11.0`, licencia Apache-2.0) es un runtime en memoria (Hono) que expone un subconjunto de la API de Resend para tests locales sin red real:

```bash
npx emulate --service resend   # levanta un servidor en http://localhost:4000
```

```typescript
// apuntar el SDK al emulador via el mismo seam de baseUrl de la seccion 7.2
const resend = new Resend("re_emulated_key", { baseUrl: "http://localhost:4000" });
```

Límites confirmados leyendo el código fuente del emulador (usar con estas advertencias explícitas, no como sustituto de los tests de la seccion 7.3 para lógica de seguridad):

- Cubre aproximadamente el **15% de la superficie** de la API real: solo `emails` (envío, batch, list, get, cancel — sin `share`/`metrics`/`receiving`), `domains` (sin verificación DNS real: `verify` marca todo como verificado al instante), `api-keys` y contactos.
- Usa el vocabulario **legado `audiences`**, no `segments`/`topics` — cualquier código escrito contra el modelo nuevo de Segments/Topics no tiene equivalente en el emulador.
- **No verifica firmas de webhook reales**: no expone `POST /webhooks` ni valida `svix-signature`; cualquier token con prefijo `re_` es aceptado por el middleware de auth interno. No usar el emulador para probar el código de verificación de firma — usar el patron de la seccion 7.3 con un secreto real de prueba.
- Sin persistencia entre reinicios (estado en memoria, por diseño, pensado para CI y sandboxes sin red).

Es una opción valida para tests de flujo de UI que solo necesitan que "el envío funcione" (por ejemplo, un formulario de contacto), nunca para validar lógica de seguridad, cuotas, rate limiting o el contrato exacto de errores — para eso, el servidor real en loopback de la seccion 7.3.

---

## 8. Errores comunes y referencias cruzadas

| # | Error | Síntoma | Corrección |
|---|---|---|---|
| 1 | Tratar `{ data, error }` como si lanzará | `try/catch` vacio que nunca captura nada; un envío fallido se reporta como exitoso | Comprobar siempre `if (error)` explicitamente; reservar `try/catch` para el `render()` de `react` y para errores de inicializacion |
| 2 | `idempotencyKey` dentro del payload | En TS no compila; en JS compila pero la key se descarta en silencio y los reintentos duplican el envío | Pasarla siempre como **segundo argumento**: `send(payload, { idempotencyKey })` |
| 3 | `new Resend(...)` a nivel de módulo en Next.js | `next build` falla si `RESEND_API_KEY` falta en el entorno de build | Instanciar el cliente dentro de la función (Route Handler/Server Action), no al importar el archivo |
| 4 | Clasificar errores por `statusCode` | El mismo `name` (`validation_error`) aparece con distintos `statusCode` según el caso; la lógica de reintento falla | Clasificar siempre por `error.name`, usar `statusCode` solo como dato secundario |
| 5 | Enviar `react` en Cloudflare Workers sin `@react-email/render` instalado | Build falla con `Could not resolve "@react-email/render"` aunque no se use `react` en ese archivo | Instalar `@react-email/render` como dependencia directa del proyecto, no solo confiar en el peer opcional |
| 6 | Confundir el SDK Python con el contrato de Node | Un `except ResendError` ausente deja una excepción sin capturar que tumba el proceso; o, al reves, comprobar `result.error` en Python (no existe) | El SDK Python **lanza** `resend.exceptions.ResendError` (o subclases como `RateLimitError`, `ValidationError`) — envolver siempre en `try/except`, nunca esperar `{data, error}` |
| 7 | Enviar a `onboarding@resend.dev` como remitente de demo hacia un destinatario cualquiera | `validation_error` 403/422: "solo puedes enviar a tu propia dirección" | Verificar un dominio propio antes de cualquier demo que envie a un tercero |
| 8 | Enviar a `@example.com`/`@test.com` en tests | `422 Unprocessable Entity` | Usar las direcciones oficiales `*.resend.dev` (seccion 7.1) |
| 9 | Auth de Supabase sin proveedor SMTP custom en producción | Signup/reset "funciona" pero el correo nunca llega tras 2 envíos/hora; sin error visible en el cliente | Configurar Resend como SMTP custom (seccion 5.2) antes de lanzar a producción |
| 10 | Tracking de click/open activado en el dominio de Auth | Los magic links de un solo uso de Supabase dejan de funcionar (la URL fue reescrita por el tracking) | Desactivar tracking en el dominio usado para emails transaccionales/auth |
| 11 | Dejar `RESEND_BASE_URL` sin guardas en el proceso de producción | Un valor accidental (typo, variable de otra libreria) puede redirigir la API key real a un host arbitrario | Aplicar la guarda fail-closed de 4 estados de la seccion 7.2 antes de leer la variable en cualquier entorno |
| 12 | Usar el emulador `@emulators/resend` para validar seguridad de webhooks | Falso sentido de cobertura: el emulador acepta cualquier token `re_` y no implementa verificación de firma | Usar el emulador solo para flujo de UI; validar firma con un servidor real en loopback (seccion 7.3) |

**Referencias relacionadas:**

- Para el contrato completo de `POST /emails` y `POST /emails/batch`, códigos de error y rate limit por equipo -> `sending-and-errors.md`
- Para el esquema de firma, los 19 eventos y la recepción de correo entrante -> `webhooks-and-inbound.md`
- Para DNS, regiones, tracking y planes -> `domains-deliverability-and-plans.md`
- Para Contact/Segment/Topic, Broadcasts, Templates y OAuth -> `marketing-templates-automations-oauth.md`
- Para el CLI oficial, el MCP server y los skills instalables para agentes -> `cli-mcp-and-agents.md`
- Para patrones de producción end-to-end (adapter único, outbox, tabla de eventos) -> `production-patterns.md`
