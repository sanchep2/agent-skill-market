# Webhooks e Inbound — Referencia completa

Cubre webhooks salientes de Resend (firma, eventos, entrega, reintentos, gestión por API) y recepción de email (inbound). API REST de Resend (sin versión de ruta) · SDK Node `resend` 6.26.0 · SDK Python `resend` 2.43.0 · `last_verified: 2026-09-04`.

## Table of Contents

1. [Como firma Resend: esquema Standard Webhooks compatible Svix](#1-como-firma-resend-esquema-standard-webhooks-compatible-svix)
2. [Verificar la firma: tres vías](#2-verificar-la-firma-tres-vías)
3. [Garantías de entrega, orden y reintentos](#3-garantías-de-entrega-orden-y-reintentos)
4. [Los 19 eventos con payload literal](#4-los-19-eventos-con-payload-literal)
5. [Gestión de webhooks por API](#5-gestión-de-webhooks-por-api)
6. [Handler fail-closed completo](#6-handler-fail-closed-completo)
7. [Webhook Ingester oficial](#7-webhook-ingester-oficial)
8. [Recepción de email inbound](#8-recepción-de-email-inbound)
9. [Bandeja de entrada para agentes de IA](#9-bandeja-de-entrada-para-agentes-de-ia)
10. [Errores comunes y referencias cruzadas](#10-errores-comunes-y-referencias-cruzadas)

---

## 1. Como firma Resend: esquema Standard Webhooks compatible Svix

Todo webhook saliente de Resend (`email.*`, `domain.*`, `contact.*`, `suppression.*`) llega firmado con el esquema **Standard Webhooks** (el mismo diseño que usan Svix y Clerk, no una firma propietaria de Resend). Tres cabeceras HTTP acompañan siempre el POST:

| Cabecera | Contenido | Ejemplo |
|---|---|---|
| `svix-id` | Identificador único de ESTA entrega (no del evento de negocio) | `msg_p5jXN8AQM9LWM0D4loKWxJek` |
| `svix-timestamp` | Unix timestamp (segundos) de cuando se envío el intento | `1614265330` |
| `svix-signature` | Una o más firmas separadas por espacio, formato `v1,<base64>` | `v1,g0hM9SsE+OTPJTGt/tmIKtSyZlE3uFJELVlNIOLJ1OE=` |

El secreto de firma tiene el formato `whsec_<base64>` y se genera uno por webhook (endpoint) registrado, no uno global de cuenta. El algoritmo es HMAC-SHA256:

1. Clave = decodificar en base64 la parte del secreto que sigue al prefijo `whsec_`.
2. Contenido firmado = concatenar con puntos: `"{svix-id}.{svix-timestamp}.{raw_body}"` (los VALORES de las cabeceras, no sus nombres, y el body tal cual llego por la red, byte a byte).
3. Firma esperada = `"v1," + base64(HMAC_SHA256(clave, contenido_firmado))`.
4. Durante una **rotación de secreto**, `svix-signature` puede traer varios tokens separados por espacio (uno por secreto vigente); basta con que **cualquiera** coincida.
5. La comparación se hace en **tiempo constante** (`crypto.timingSafeEqual` en Node, `hmac.compare_digest` en Python) — nunca con `===`/`==`, que filtra tiempo de ejecucion y habilita ataques de temporizacion.

```text
raw_body + svix-id + svix-timestamp
              |
              v
   "{svix-id}.{svix-timestamp}.{raw_body}"
              |
              v
     HMAC-SHA256(clave_del_secreto, ese_string)
              |
              v
        "v1," + base64(...)  ==  algun token de svix-signature ?
              |                              |
             si                             no
              v                              v
      evento autentico                firma invalida -> rechazar
```

La **tolerancia de timestamp** habitual (ventana de ±5 minutos, en ambas direcciones, para rechazar reintentos de ataque con un payload capturado hace horas) es un comportamiento heredado de la libreria Svix/Standard Webhooks subyacente, **no una cifra documentada por Resend en su referencia oficial**. Implementarla de todos modos es la práctica prudente (protege contra replay attacks), pero no se puede afirmar como contrato garantizado por Resend — tratarla como "recomendado por la libreria, no prometido por el vendor" (verificado 2026-09-04).

El SDK Node (`resend` ≥ 6.13, y por tanto la versión fijada de este skill, 6.26.0) ya no depende del paquete `svix` para esta verificación: desde el 2026-05-25 usa `standardwebhooks@1.0.0` como dependencia transitiva (mismo algoritmo, instalación ~13 KB en vez de los ~4-5 MB de `svix`). Internamente el SDK traduce las cabeceras que llegan por la red (`svix-id`/`svix-timestamp`/`svix-signature`) a la nomenclatura del protocolo Standard Webhooks (`webhook-id`/`webhook-timestamp`/`webhook-signature`) antes de delegar en la libreria — esto es un detalle interno, en el wire (lo que Resend realmente envia) siguen siendo las cabeceras `svix-*`.

---

## 2. Verificar la firma: tres vías

### 2.1 Vía A — SDK oficial (`resend.webhooks.verify`)

Es la vía recomendada si el proyecto ya usa el SDK de Resend para enviar correo. La función es **síncrona** y **LANZA excepción** en vez de devolver el contrato `{ data, error }` que usa el resto del SDK — es la única función del SDK con ese comportamiento distinto, y hay que envolverla siempre en `try/catch`. Exige el **body crudo** (`await req.text()`), nunca el resultado de parsear JSON.

```typescript
// ---------------------------------------------------------------------------
// Nucleo de la verificacion con el SDK (el Route Handler completo, con las
// cabeceras extraidas de un NextRequest real, esta en la seccion 2.4)
// ---------------------------------------------------------------------------
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);
// body CRUDO (jamas req.json()) leido en streaming y con cota: readBodyWithCap() esta en la seccion 6
const payload = await readBodyWithCap(req, MAX_BODY_BYTES);
if (payload === null) return new Response("Payload too large", { status: 413 });

try {
  // verify() es SINCRONO y LANZA — nunca devuelve { data, error }
  const event = resend.webhooks.verify({
    payload,
    headers: { id, timestamp, signature }, // valores de svix-id/svix-timestamp/svix-signature
    webhookSecret: process.env.RESEND_WEBHOOK_SECRET!, // campo: webhookSecret, no "secret"
  });
  // event.type, event.created_at, event.data ya estan verificados y parseados
} catch {
  // firma invalida o timestamp fuera de rango
}
```

Nota de nomenclatura: circula un ejemplo con el campo `secret` en vez de `webhookSecret` (aparece incluso en documentación semioficial de terceros) — el nombre correcto, confirmado en el código fuente del SDK, es **`webhookSecret`**.

### 2.2 Vía B — paquete `standardwebhooks` o `svix` a mano

Útil cuando el proyecto NO usa el SDK de Resend para nada más (por ejemplo, un microservicio que solo consume webhooks), o cuando se quiere verificar en un lenguaje sin SDK oficial de Resend.

```bash
# Elegir UNO. No instalar ambos ni instalar svix si ya se usa el SDK de Resend
# (el SDK >= 6.13 ya trae standardwebhooks de forma transitiva).
npm install standardwebhooks   # 1.1.1 (npm, verificado 2026-09-04) — nombre alineado con el protocolo
npm install svix                # 2.3.0 (npm, verificado 2026-09-04) — mismo esquema, nombre historico
```

```typescript
// ---------------------------------------------------------------------------
// Verificacion manual con el paquete "svix" (mismo esquema que standardwebhooks)
// ---------------------------------------------------------------------------
import { Webhook } from "svix";

async function handleWebhook(req: Request): Promise<Response> {
  const secret = process.env.RESEND_WEBHOOK_SECRET; // "whsec_..."
  if (!secret) return new Response("Server misconfigured", { status: 500 }); // 5xx: que el proveedor reintente
  const wh = new Webhook(secret);
  const raw = await readBodyWithCap(req, MAX_BODY_BYTES); // streaming + cota (seccion 6)
  if (raw === null) return new Response("Payload too large", { status: 413 });
  const headers = {
    "svix-id": req.headers.get("svix-id") ?? "",
    "svix-timestamp": req.headers.get("svix-timestamp") ?? "",
    "svix-signature": req.headers.get("svix-signature") ?? "",
  };

  try {
    const event = wh.verify(raw, headers); // lanza en fallo; devuelve el payload parseado si es valido
    return new Response("ok", { status: 200 });
  } catch {
    return new Response("invalid signature", { status: 401 });
  }
}
```

### 2.3 Vía C — `node:crypto` / `hmac` sin ninguna dependencia

Para runtimes edge sin acceso a paquetes npm nativos, o para lenguajes sin libreria Standard Webhooks madura. Implementa el algoritmo de la seccion 1 directamente.

```typescript
// ---------------------------------------------------------------------------
// Verificacion nativa sin dependencias (TypeScript, node:crypto)
// ---------------------------------------------------------------------------
import crypto from "node:crypto";

// 5 minutos: comportamiento heredado de la libreria Standard Webhooks/Svix,
// NO es una cifra documentada como contrato por Resend (ver seccion 1).
const TOLERANCE_SECONDS = 5 * 60;

function verifyResendWebhookSignature(
  secret: string,           // "whsec_xxxxxxxxx"
  id: string,                // cabecera svix-id
  timestamp: string,         // cabecera svix-timestamp (segundos unix, string)
  signatureHeader: string,   // cabecera svix-signature: "v1,aaa v1,bbb" (rotacion)
  rawBody: string,           // body crudo, EXACTO como llego por la red
): boolean {
  const now = Math.floor(Date.now() / 1000);
  if (Math.abs(now - Number(timestamp)) > TOLERANCE_SECONDS) return false;

  const key = Buffer.from(secret.split("_").slice(1).join("_"), "base64");
  const signedContent = `${id}.${timestamp}.${rawBody}`;
  const expected = crypto.createHmac("sha256", key).update(signedContent).digest("base64");

  return signatureHeader.split(" ").some((token) => {
    const [version, sig] = token.split(",");
    if (version !== "v1" || !sig) return false;
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  });
}
```

```python
# ---------------------------------------------------------------------------
# Verificacion nativa sin dependencias (Python, hmac + hashlib)
# ---------------------------------------------------------------------------
import base64
import hashlib
import hmac
import time

TOLERANCE_SECONDS = 5 * 60  # heredado de Standard Webhooks/Svix, no contrato de Resend

def verify_resend_webhook_signature(
    secret: str,             # "whsec_xxxxxxxxx"
    event_id: str,           # cabecera svix-id
    timestamp: str,          # cabecera svix-timestamp (segundos unix, string)
    signature_header: str,   # cabecera svix-signature: "v1,aaa v1,bbb"
    raw_body: bytes,         # body crudo, EXACTO como llego por la red
) -> bool:
    now = int(time.time())
    if abs(now - int(timestamp)) > TOLERANCE_SECONDS:
        return False

    key = base64.b64decode(secret.split("_", 1)[1])
    signed_content = f"{event_id}.{timestamp}.".encode() + raw_body
    expected = base64.b64encode(
        hmac.new(key, signed_content, hashlib.sha256).digest()
    ).decode()

    for token in signature_header.split(" "):
        version, _, sig = token.partition(",")
        if version == "v1" and sig and hmac.compare_digest(sig, expected):
            return True
    return False
```

### 2.4 Route Handler genérico (Next.js, cualquier stack equivalente) y Python Flask/FastAPI

```typescript
// ---------------------------------------------------------------------------
// Route Handler generico — patron aplicable a cualquier framework con
// acceso al body crudo antes de que algo lo parsee como JSON
// ---------------------------------------------------------------------------
import { Resend } from "resend";
import { NextResponse, type NextRequest } from "next/server";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req: NextRequest) {
  // 1. Cabeceras (barato, antes de leer el body)
  const id = req.headers.get("svix-id");
  const timestamp = req.headers.get("svix-timestamp");
  const signature = req.headers.get("svix-signature");
  if (!id || !timestamp || !signature) {
    return new NextResponse("Missing headers", { status: 400 });
  }

  // 2. Secreto presente en ESTE servidor: si falta es fallo propio -> 5xx (el proveedor reintenta)
  const webhookSecret = process.env.RESEND_WEBHOOK_SECRET;
  if (!webhookSecret) {
    return new NextResponse("Server misconfigured", { status: 500 });
  }

  // 3. Body CRUDO en streaming y con cota (NUNCA req.json() antes de verificar); helper en seccion 6
  const payload = await readBodyWithCap(req, MAX_BODY_BYTES);
  if (payload === null) {
    return new NextResponse("Payload too large", { status: 413 });
  }

  try {
    const event = resend.webhooks.verify({
      payload,
      headers: { id, timestamp, signature },
      webhookSecret,
    });
    // ... procesar event.type / event.data (ver seccion 6 para el patron completo) ...
    return NextResponse.json({ ok: true });
  } catch {
    return new NextResponse("Invalid webhook", { status: 401 });
  }
}
```

```python
# ---------------------------------------------------------------------------
# Flask/FastAPI con el paquete "standardwebhooks"
# NOTA: import verificado contra PyPI standardwebhooks 1.1.0 — si el nombre
# del modulo difiere en la version instalada, confirmar en
# https://pypi.org/project/standardwebhooks/ antes de fijarlo en produccion.
# ---------------------------------------------------------------------------
import os
from standardwebhooks.webhooks import Webhook  # verificar import exacto en PyPI

wh = Webhook(os.environ["RESEND_WEBHOOK_SECRET"])  # "whsec_..."

# --- Flask ---
from flask import Flask, request, Response

app = Flask(__name__)

@app.post("/webhooks/resend")
def resend_webhook():
    raw_body = request.get_data()  # bytes crudos, antes de cualquier parseo
    headers = {
        "svix-id": request.headers.get("svix-id", ""),
        "svix-timestamp": request.headers.get("svix-timestamp", ""),
        "svix-signature": request.headers.get("svix-signature", ""),
    }
    try:
        event = wh.verify(raw_body, headers)  # lanza en fallo
    except Exception:
        return Response(status=401)
    return Response(status=200)

# --- FastAPI (equivalente async) ---
from fastapi import FastAPI, Request, Response

api = FastAPI()

@api.post("/webhooks/resend")
async def resend_webhook_fastapi(request: Request):
    raw_body = await request.body()
    headers = {
        "svix-id": request.headers.get("svix-id", ""),
        "svix-timestamp": request.headers.get("svix-timestamp", ""),
        "svix-signature": request.headers.get("svix-signature", ""),
    }
    try:
        event = wh.verify(raw_body, headers)
    except Exception:
        return Response(status_code=401)
    return Response(status_code=200)
```

---

## 3. Garantías de entrega, orden y reintentos

### 3.1 At-least-once, sin orden

Resend garantiza entrega **at-least-once**: cada evento llega al menos una vez, pero puede llegar **más de una vez** en casos raros (timeouts de red donde el handler proceso el evento pero el ack se perdio). No hay campo `id` en el body del evento — el identificador único de CADA entrega (no del evento de negocio) es la cabecera `svix-id`; ahí es donde debe apoyarse la deduplicación.

La entrega **no garantiza orden**: la documentación oficial da el ejemplo literal de que un `email.opened` puede llegar antes que el `email.delivered` del mismo email. Si el orden importa para la lógica de negocio, hay que ordenar explicitamente por el campo `created_at` del payload, nunca asumir que "llego después" significa "paso después".

```typescript
// Dedupe minimo — en produccion usar tabla/Redis con TTL >= ventana de reintentos
const seen = new Set<string>();

async function processOnce(svixId: string, event: unknown) {
  if (seen.has(svixId)) return; // reintento duplicado: no reprocesar
  seen.add(svixId);
  // ... efectos secundarios IDEMPOTENTES (upsert, jamas insert puro) ...
}
```

### 3.2 Schedule de reintentos (referencia, sin cifra única confiable)

La cuenta exacta de reintentos varia según la página que se consulte dentro del propio ecosistema de Resend — se encontraron **cuatro versiones distintas** entre fuentes oficiales/semioficiales (introduccion general: 6 pasos; página dedicada a reintentos: 8 pasos; FAQ de otra página: "hasta 24 horas" como ventana total, sin desglose; repositorio de skills del propio vendor: 7 pasos). La tabla siguiente usa el schedule de la página específicamente dedicada al tema como referencia principal — **no** como número contractual fijo:

| Intento | Retraso desde el intento anterior |
|---|---|
| 1 | Inmediato |
| 2 | 5 segundos |
| 3 | 5 minutos |
| 4 | 30 minutos |
| 5 | 2 horas |
| 6 | 5 horas |
| 7 | 10 horas |
| 8 | 10 horas adicionales |

```text
intento:   1    2      3        4         5       6       7        8
retraso:   0s   5s     5min     30min     2h      5h      10h      10h
           |----|------|--------|---------|-------|-------|--------|----> tiempo
           inmediato                                        puede superar 24h
```

**Diseñar el handler de forma idempotente e independiente del número exacto de intentos** — no fijar lógica de negocio ("al tercer fallo, dar por perdido el evento") sobre esta tabla, porque la propia documentación del vendor no es consistente consigo misma en este punto.

### 3.3 Replays manuales, IPs de origen y desactivación automática

- **Replays manuales**: desde el dashboard se puede reintentar tanto eventos que fallaron como eventos que ya tuvieron exito — casos de uso oficiales: backfill tras una caida del endpoint propio, reprocesar con lógica de handler actualizada, o reenviar a un endpoint distinto para pruebas.
- **IPs de origen** (para allowlist de firewall/proxy, no como sustituto de la verificación de firma):

| Tipo | Valor |
|---|---|
| IPv4 | `44.228.126.217` |
| IPv4 | `50.112.21.217` |
| IPv4 | `52.24.126.164` |
| IPv4 | `54.148.139.208` |
| IPv6 | `2600:1f24:64:8000::/52` |

- **Desactivación automática de endpoints que fallan**: si un endpoint empieza a fallar de forma persistente, Resend envia un email de aviso con la URL, la hora del último fallo y el código HTTP recibido; si el fallo continua, Resend **deshabilita el endpoint automáticamente** y envia una segunda notificación — se reactiva a mano desde el dashboard. El número exacto de días hasta la desactivación automática no aparece documentado en ninguna página oficial fetcheada; tratar como "no confirmado, monitorizar el endpoint proactivamente" en vez de fiarse de una cifra concreta.
- **Regla dura para el propio handler — "config propia ausente, nunca 4xx"**: si el fallo es del LADO del receptor (por ejemplo, el secreto de verificación no esta configurado en el servidor, o hay un error transitorio de base de datos al persistir el evento), responder con **5xx**, nunca con 4xx. Un 4xx (fuera de la firma invalida, que es un rechazo legítimo) puede leerse como "petición permanentemente invalida" y no vale la pena seguir reintentando; un 5xx mantiene viva la ventana de reintentos hasta que el problema propio se resuelva.

---

## 4. Los 19 eventos con payload literal

Hay 19 tipos de evento en 4 familias. Todos comparten el mismo sobre: `{ "type": string, "created_at": ISO8601, "data": {...} }`. El `created_at` de nivel superior (cuando se genero el evento del webhook) es distinto del `data.created_at` (cuando se creo el recurso de negocio) — en los ejemplos oficiales difieren en milisegundos.

| # | Evento | Familia | Campo(s) extra en `data` | Nota clave |
|---|---|---|---|---|
| 1 | `email.sent` | email | — | Confirma que la API acepto la solicitud; **no** es confirmación de entrega |
| 2 | `email.delivered` | email | — | Entregado al servidor del destinatario |
| 3 | `email.delivery_delayed` | email | — | Problema temporal en destino (buzon lleno, servidor lento) |
| 4 | `email.bounced` | email | `bounce.{message,subType,type}` | Solo `type === "Permanent"` cuenta como hard bounce (ver 4.2) |
| 5 | `email.complained` | email | — | El destinatario marco el correo como spam |
| 6 | `email.opened` | email | — | Requiere tracking de apertura activo en el dominio; no siempre fiable |
| 7 | `email.clicked` | email | `click.{ipAddress,link,timestamp,userAgent}` | Único evento con campos en **camelCase** (ver 4.3) |
| 8 | `email.failed` | email | `failed.{reason}` | Fallo del LADO DE ENVIO (p. ej. `reached_daily_quota`), distinto de un bounce |
| 9 | `email.scheduled` | email | — | El envío programado fue aceptado |
| 10 | `email.suppressed` | email | `suppressed.{message,type}` | No cuenta contra la tasa de bounce de la cuenta |
| 11 | `email.received` | email | ver seccion 8 | Evento propio de inbound; **solo metadata** |
| 12 | `domain.created` | domain | `id,name,status,region,capabilities,records[]` | — |
| 13 | `domain.updated` | domain | igual que `domain.created` | Puede incluir un registro MX de recepción nuevo |
| 14 | `domain.deleted` | domain | igual que `domain.created` | — |
| 15 | `contact.created` | contact | `id,audience_id,segment_ids[],email,first_name,last_name,unsubscribed` | **La importacion CSV NO dispara este evento** |
| 16 | `contact.updated` | contact | igual que `contact.created` | `first_name`/`last_name` pueden estar ausentes |
| 17 | `contact.deleted` | contact | igual que `contact.created` | — |
| 18 | `suppression.added` | suppression | `id,email,origin,source_id` | `origin`: `bounce` \| `complaint` \| `manual` |
| 19 | `suppression.removed` | suppression | igual que `suppression.added` | — |

### 4.1 Campos comunes y ejemplo literal (`email.bounced`)

Casi todos los eventos `email.*` de salida (no `received`) comparten: `broadcast_id` (si aplica), `created_at`, `email_id`, `message_id` (header RFC `Message-ID`), `from`, `to[]`, `subject`, `template_id` (si aplica), `tags{}`.

```json
{
  "type": "email.bounced",
  "created_at": "2026-11-22T23:41:12.126Z",
  "data": {
    "broadcast_id": "8b146471-e88e-4322-86af-016cd36fd216",
    "created_at": "2026-11-22T23:41:11.894Z",
    "email_id": "56761188-7520-42d8-8898-ff6fc54ce618",
    "message_id": "<111-222-333@email.example.com>",
    "from": "Notificaciones <notificaciones@tu-dominio.com>",
    "to": ["delivered@resend.dev"],
    "subject": "Sending this example",
    "template_id": "43f68331-0622-4e15-8202-246a0388854b",
    "bounce": {
      "message": "The recipient's email address is on the suppression list because it has a recent history of producing hard bounces.",
      "subType": "Suppressed",
      "type": "Permanent"
    },
    "tags": { "category": "confirm_email" }
  }
}
```

### 4.2 Regla robusta para `bounce.type`/`subType`

La prosa oficial da como ejemplo `"e.g., Permanent, Temporary"`, pero varias fuentes que auditaron ejemplos reales de la API usan **`Transient`**, no `Temporary`, como valor no-permanente — ninguna muestra JSON oficial disponible confirma el string literal exacto del caso no-permanente. `bounce.subType` tampoco es un enum cerrado (aparecen valores como `Suppressed`, `MessageRejected`, y en muestras comunitarias `General`, `NoEmail`, `MailboxFull`, `MessageTooLarge`, `ContentRejected`, `AttachmentRejected`, sin lista exhaustiva documentada).

**Regla robusta (evita depender de un string incierto)**: tratar como hard bounce (candidato a supresión permanente) **solo** cuando `bounce.type === "Permanent"`; cualquier otro valor de `type` se trata como no-permanente por defecto, sin hacer match contra un literal específico del caso transitorio.

### 4.3 Otras particularidades de payload

- **`click.ipAddress` / `click.userAgent` en camelCase**: único rincon de la API en camelCase; el resto es snake_case (`created_at`, `email_id`). Si se tipa el payload con un validador (Zod/Pydantic), este es el campo que rompe la convencion por accidente si se copia y pega el shape de otro evento.
- **`email.failed.reason`**: ejemplo oficial `"reached_daily_quota"`. Se dispara por errores del lado de ENVIO (destinatarios inválidos, problema de API key, dominio no verificado, cuota alcanzada) — es un evento distinto de `email.bounced`, que ocurre del lado del servidor RECEPTOR.
- **`email.suppressed.type`**: ejemplo oficial `"OnAccountSuppressionList"`, con mensaje explicativo de que **no** cuenta contra la métrica de tasa de bounce de la cuenta.
- **`email.sent` no es entrega**: solo confirma que la petición a la API fue aceptada y que Resend intentara la entrega. Cualquier lógica de "correo confirmado" debe esperar `email.delivered`, nunca `email.sent`.
- **`from` cambia de forma según la dirección**: en eventos de ENVIO, `from` conserva el display name tal como se paso al enviar (`Nombre <email@dominio>`); en eventos de RECEPCION, `from` es la dirección pelada (sin display name) — el display name original de un correo recibido se recupera vía `headers.from` en el endpoint de retrieve (seccion 8).
- **CSV import no dispara `contact.created`**: cualquier lógica de sincronización de audiencias que dependa de ese evento se saltara las importaciones masivas — hay que reconciliar por otra vía (polling, o el propio resultado de la llamada de import).

---

## 5. Gestión de webhooks por API

```bash
# Crear — devuelve el signing_secret SOLO en este momento y en el GET individual
curl -X POST 'https://api.resend.com/webhooks' \
  -H 'Authorization: Bearer re_xxxxxxxxx' \
  -H 'Content-Type: application/json' \
  -d '{
    "endpoint": "https://tu-dominio.com/webhooks/resend",
    "events": ["email.sent", "email.delivered", "email.bounced", "email.received"]
  }'
# -> {"object":"webhook","id":"4dd369bc-...","signing_secret":"whsec_xxxxxxxxxx"}
```

```typescript
// SDK — create/get/list/update, y .remove() para borrar (NO .delete())
const { data, error } = await resend.webhooks.create({
  endpoint: "https://tu-dominio.com/webhooks/resend",
  events: ["email.sent", "email.delivered", "email.bounced", "email.received"],
});
// data.signing_secret solo llega en create() y en get() individual: guardarlo de inmediato

await resend.webhooks.update(webhookId, { status: "disabled" }); // "enabled" | "disabled"
await resend.webhooks.remove(webhookId);                          // NO .delete()
```

| Operación | Método REST | Método SDK | Nota |
|---|---|---|---|
| Crear | `POST /webhooks` | `webhooks.create()` | Devuelve `signing_secret` |
| Obtener | `GET /webhooks/:id` | `webhooks.get()` | Devuelve `signing_secret` |
| Listar | `GET /webhooks` | `webhooks.list()` | El `signing_secret` **no** aparece garantizado en el ejemplo de esta llamada — no depender de `list` para recuperarlo, guardarlo en el momento de `create`/`get` |
| Actualizar | `PATCH /webhooks/:id` | `webhooks.update()` | `endpoint`, `events`, `status` |
| Borrar | `DELETE /webhooks/:id` | `webhooks.remove()` | El SDK usa `.remove()`, no `.delete()` |

**Introspeccion de eventos/intentos** (`events.list`, `events.get`, `events.replay`, `attempts.list`) es estable en el SDK desde la versión 6.24.0 (26-ago-2026) según el changelog de releases, aunque algunas páginas de la documentación todavía la describan como "private beta" — la incoherencia entre releases y documentación es real; **verificar en vivo** el estado exacto antes de construir lógica crítica sobre esta superficie. Uso típico: reconstruir el historial de intentos de un evento concreto para depurar por que un handler nunca vio cierto webhook.

```typescript
// Introspeccion (estable desde 6.24.0 segun releases; confirmar estado GA en vivo)
const attempts = await resend.webhooks.events.list(webhookId);
const detail = await resend.webhooks.events.get(webhookId, eventId); // incluye el payload completo
await resend.webhooks.events.replay(webhookId, eventId);              // reenvia manualmente
```

CLI oficial para desarrollo local: `resend webhooks listen --url <url-publica> [--events ...] [--forward-to <url-local>]` monta un servidor temporal, registra un webhook de prueba en Resend, imprime cada evento como JSON en la terminal, reenvia (opcional) a un endpoint local con las cabeceras `svix-*` originales, y borra el webhook temporal al salir — requiere un tunel público (algo tipo ngrok o equivalente) para exponer el puerto local.

---

## 6. Handler fail-closed completo

El orden de los checks importa: los baratos primero, los caros después, para no gastar ciclos de CPU/DB en una petición que se va a rechazar de todos modos.

```text
Webhook recibido
       |
       v
 ¿estan svix-id / svix-timestamp / svix-signature presentes? ---no--> 400 (cabeceras ausentes)
       | si
       v
 ¿esta configurado el secreto de verificacion en ESTE server? ---no--> 500 (config propia: que reintente)
       | si
       v
 ¿body <= cota maxima, leido en streaming? -------------------- no--> 413 (payload demasiado grande)
       | si
       v
 ¿alguna firma de svix-signature verifica contra el secreto? -- no--> 401 (firma invalida)
       | si
       v
 ¿el tipo de evento esta en la allow-list que este handler maneja? -- no --> 200 { ignored: true }
       | si
       v
 ¿el payload trae los campos requeridos para ESE tipo de evento? --- no --> 400 (payload incompleto)
       | si
       v
 dedupe por svix-id (unique provider_event_id) ---------------------------> 200 { processed: true }
```

```typescript
// ---------------------------------------------------------------------------
// Handler fail-closed completo — patron generico, aplicable a cualquier
// framework con acceso al body crudo y a las cabeceras de la peticion.
// ---------------------------------------------------------------------------
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);
const MAX_BODY_BYTES = 1 * 1024 * 1024; // 1 MiB — ajustar segun el trafico esperado

// Allow-list explicita: solo estos tipos se persisten y procesan
const HANDLED_EVENTS = new Set([
  "email.bounced",
  "email.complained",
  "email.delivery_delayed",
  "email.delivered",
]);

export async function POST(req: Request): Promise<Response> {
  // 1. Cabeceras ausentes -> 400 (barato, ni siquiera hace falta leer el body)
  const id = req.headers.get("svix-id");
  const timestamp = req.headers.get("svix-timestamp");
  const signature = req.headers.get("svix-signature");
  if (!id || !timestamp || !signature) {
    return new Response("Missing signature headers", { status: 400 });
  }

  // 2. Secreto ausente en ESTE server -> 500 (fallo propio: que Resend reintente
  //    hasta que se corrija la configuracion, nunca 4xx por un error nuestro)
  const webhookSecret = process.env.RESEND_WEBHOOK_SECRET;
  if (!webhookSecret) {
    return new Response("Server misconfigured", { status: 500 });
  }

  // 3. Body > cota -> 413. Content-Length es solo un atajo barato (puede faltar o mentir):
  //    la cota real se aplica DURANTE la lectura en streaming, sin materializar nunca un
  //    string mayor que MAX_BODY_BYTES (un `await req.text()` sin cota lo materializaria entero).
  const contentLength = Number(req.headers.get("content-length") ?? "0");
  if (contentLength > MAX_BODY_BYTES) {
    return new Response("Payload too large", { status: 413 });
  }
  const payload = await readBodyWithCap(req, MAX_BODY_BYTES);
  if (payload === null) {
    return new Response("Payload too large", { status: 413 });
  }

  // 4. Firma invalida -> 401
  let event: { type: string; created_at: string; data: Record<string, unknown> };
  try {
    event = resend.webhooks.verify({
      payload,
      headers: { id, timestamp, signature },
      webhookSecret,
    }) as typeof event;
  } catch {
    return new Response("Invalid signature", { status: 401 });
  }

  // 5. Evento no mapeado -> 200 ignored (no es un error, es "no nos interesa este tipo")
  if (!HANDLED_EVENTS.has(event.type)) {
    return new Response(JSON.stringify({ ignored: true }), { status: 200 });
  }

  // 6. Campos ausentes para ese tipo -> 400
  const emailId = event.data.email_id as string | undefined;
  if (!emailId) {
    return new Response("Missing required field: email_id", { status: 400 });
  }

  // 7. Allow-list de campos persistidos: NUNCA guardar las cabeceras de firma,
  //    solo los campos de negocio que este handler realmente necesita
  const record = {
    provider_event_id: id,          // svix-id: unico por ENTREGA
    event_type: event.type,
    provider_message_id: emailId,   // puede repetirse entre varios eventos del mismo email
    payload: {
      created_at: event.data.created_at,
      to: event.data.to,
      subject: event.data.subject,
      bounce: event.data.bounce,
      suppressed: event.data.suppressed,
    },
  };

  // 8. Dedupe SOLO por svix-id (unique provider_event_id): un mismo email puede generar varios
  //    eventos legitimos del mismo tipo, asi que (provider_message_id, event_type) NO es clave -> 200
  await upsertEmailEvent(record); // implementacion propia: INSERT ... ON CONFLICT DO NOTHING/UPDATE

  // Responder rapido; cualquier trabajo pesado (recalcular metricas, notificar,
  // disparar automatizaciones) va a una cola, nunca await aqui dentro
  return new Response(JSON.stringify({ processed: true }), { status: 200 });
}

async function upsertEmailEvent(record: unknown): Promise<void> {
  // placeholder: la implementacion real vive en la capa de datos del proyecto
}

// Lee el body crudo en streaming y corta en cuanto se supera la cota: null = demasiado grande.
// Devuelve el string EXACTO recibido (la firma se calcula sobre los bytes originales).
async function readBodyWithCap(req: Request, capBytes: number): Promise<string | null> {
  const reader = req.body?.getReader();
  if (!reader) return "";
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > capBytes) {
      await reader.cancel();
      return null; // cota aplicada durante la LECTURA, no despues
    }
    chunks.push(value);
  }
  return Buffer.concat(chunks).toString("utf8");
}
```

Esquema SQL genérico de una tabla de eventos, con la única clave que garantiza idempotencia sin depender de que el body traiga un `id` propio (no lo trae, ver seccion 3.1):

```sql
create table email_events (
  id                  bigint generated always as identity primary key,
  provider_event_id   text not null,          -- svix-id: identificador de ESTA entrega
  event_type          text not null,          -- "email.bounced", "email.delivered", ...
  provider_message_id text,                   -- data.email_id; puede repetirse entre eventos
  payload             jsonb not null,          -- SOLO los campos de la allow-list, nunca cabeceras
  received_at         timestamptz not null default now(),
  processed_at        timestamptz,
  unique (provider_event_id)
);

create index email_events_message_type_idx
  on email_events (provider_message_id, event_type);
```

Si esta tabla vive en una base con row-level security (por ejemplo Postgres gestionado con RLS), el patron genérico correcto es: RLS habilitada, sin políticas para roles de cliente, y escritura solo desde el rol de servicio que atiende el webhook — el evento nunca debe ser visible ni escribible desde un cliente autenticado normal.

---

## 7. Webhook Ingester oficial

Resend publica una aplicacion open-source, autohospedable, para no tener que construir el receptor de eventos desde cero: imagen Docker `ghcr.io/resend/resend-webhooks-ingester`, desplegable con un clic en plataformas comunes de hosting de Node.js.

- **9 conectores de base de datos**, cada uno con su propio endpoint: Postgres genérico, Supabase, Neon, MySQL, PlanetScale, MongoDB, Snowflake, BigQuery, ClickHouse. El endpoint a registrar como webhook en Resend es `https://tu-despliegue/{connector}` (p. ej. `/postgresql`, `/supabase`).
- **3 tablas** creadas automáticamente: una para eventos de email, una para eventos de contacto y una para eventos de dominio — cada fila incluye `svix_id` (clave de dedupe), `event_type`, `event_created_at` y `webhook_received_at`, además de los campos propios de cada evento.
- **Idempotencia garantizada por `svix_id`**: si Resend reintenta una entrega (por un fallo temporal del lado receptor), el Ingester ignora el duplicado sin crear una fila repetida.
- Variables de entorno: `RESEND_WEBHOOK_SECRET` (obligatoria) + la variable de conexión especifica de la base elegida (por ejemplo `POSTGRESQL_URL`, `MONGODB_URI`).
- **Un solo tipo de base de datos por despliegue** — para enviar los eventos a más de un destino hace falta desplegar varias instancias, o construir el handler propio de la seccion 6.
- Retención por defecto: indefinida (no hay purga automática); la limpieza periodica (por ejemplo, borrar filas de más de 90 días) es responsabilidad de quien despliega el Ingester.

Es una buena opción de "no lo reconstruyas tu mismo" cuando el único objetivo es tener los eventos crudos en una tabla propia sin lógica de negocio adicional; para cualquier procesamiento a medida (disparar automatizaciones, actualizar estado de negocio) el patron de la seccion 6 sigue siendo el punto de partida.

---

## 8. Recepción de email inbound

### 8.1 Como llegan los correos entrantes

Dos formas de recibir correo con Resend:

- **Dominio gestionado por Resend**: `lo-que-sea@<tu-id>.resend.app` — cero configuración DNS, listo de inmediato.
- **Dominio propio**: requiere añadir un registro **MX** adicional en el proveedor DNS. Recomendación oficial fuerte: usar un **subdominio** dedicado a recepción (`inbound.tu-dominio.com`), no el dominio raíz, sobre todo si ya existen registros MX propios para otro proveedor de correo.

Regla dura: en DNS, **a menor número de prioridad, mayor preferencia**. El MX de Resend debe llevar un **número de prioridad estrictamente menor** que cualquier otro MX del (sub)dominio; si otro MX tiene un número menor, el correo se entrega ahí y **no llega** a Resend. Con empate de número entre dos MX, el servidor de entrega se elige al azar en cada intento — evitarlo siempre: el MX que deba recibir lleva el número más bajo y sin repetir.

### 8.2 `email.received` trae solo metadata

```json
{
  "type": "email.received",
  "created_at": "2026-02-22T23:41:12.126Z",
  "data": {
    "email_id": "56761188-7520-42d8-8898-ff6fc54ce618",
    "created_at": "2026-02-22T23:41:11.894Z",
    "from": "usuario@tu-dominio.com",
    "to": ["delivered@resend.dev"],
    "bcc": [],
    "cc": [],
    "received_for": ["forwarded@example.com"],
    "message_id": "<111-222-333@email.example.com>",
    "subject": "Sending this example",
    "attachments": [
      {
        "id": "2a0c9ce0-3112-4728-976e-47ddcd16a318",
        "filename": "avatar.png",
        "content_type": "image/png",
        "content_disposition": "inline",
        "content_id": "img001"
      }
    ]
  }
}
```

El webhook **nunca** trae el cuerpo del correo, las cabeceras completas ni los bytes de los adjuntos — solo metadata. El contenido real se pide aparte, en cadena:

```text
email.received (solo metadata) -> GET /emails/receiving/:id (html/text/raw.download_url)
  -> GET .../attachments (lista) -> GET .../attachments/:id (download_url, expira en 1h)
  -> descargar YA y re-subir a almacenamiento propio antes de que expire la ventana
```

### 8.3 Obtener el contenido completo

`GET /emails/receiving/:id`: parámetro `html_format` — `data_uri` (por defecto) incrusta las imagenes inline como `data:` URIs base64 dentro del `html`; `cid` conserva las referencias originales `cid:...` (correlacionables con `content_id` de cada adjunto). La respuesta incluye `headers{}` (por ejemplo `from` con el display name original, `return-path`, `mime-version`), `text`, `bcc`, `cc`, `reply_to`, `received_for`, `message_id`, y `raw: { download_url, expires_at }` — una URL firmada del correo crudo (`.eml`) con su propia caducidad.

Los adjuntos se piden con `GET /emails/receiving/:emailId/attachments/:id` (o el listado `.../attachments`). Cada adjunto trae `download_url` con expiración **de 1 hora** — si expira, hay que volver a llamar a la API para obtener una URL nueva. La retención total del correo y sus adjuntos en Resend es de **30 días** en todos los planes (Enterprise tiene retención flexible); cualquier arquitectura de "ya lo proceso después" debe re-subir el contenido a almacenamiento propio dentro de esa ventana.

### 8.4 Reenvio (`forward`) con `passthrough`

```typescript
// Reenviar tal cual (preserva texto/HTML/adjuntos originales bajo un nuevo remitente)
await resend.emails.receiving.forward({
  emailId: event.data.email_id,
  to: "destino@otro-dominio.com",
  from: process.env.EMAIL_FROM_ADDRESS!,
  passthrough: true, // default
});

// Reenviar con footer propio de "forwarded message" y el original debajo
await resend.emails.receiving.forward({
  emailId: event.data.email_id,
  to: "destino@otro-dominio.com",
  from: process.env.EMAIL_FROM_ADDRESS!,
  passthrough: false,
  html: "<p>Te reenvio este correo, ver mas abajo.</p>",
});
```

### 8.5 Responder en el mismo hilo

```typescript
// ---------------------------------------------------------------------------
// Responder a un correo entrante manteniendo el hilo (In-Reply-To/References)
// ---------------------------------------------------------------------------
const previousReferences: string[] = []; // acumular ids de respuestas previas, en orden

await resend.emails.send({
  from: process.env.EMAIL_FROM_ADDRESS!,
  to: [event.data.from as string],
  subject: `Re: ${event.data.subject}`,
  html: "<p>Gracias por tu mensaje.</p>",
  headers: {
    "In-Reply-To": event.data.message_id as string,
    "References": [...previousReferences, event.data.message_id as string].join(" "),
  },
});
```

**No existe un campo oficial que correlacione una respuesta inbound con el email saliente original** — es una discusion abierta y sin resolver en el repositorio del SDK. Los únicos workarounds documentados por la comunidad son regex sobre el asunto o el uso de `tags` propios al enviar (sin garantía de que sobrevivan a traves de varias respuestas de un cliente de correo). Diseñar cualquier lógica de threading asumiendo que esta correlacion es responsabilidad propia, no del vendor.

**El contenido de un correo entrante es dato no confiable**: viene de un remitente arbitrario en internet. Nunca tratar el `subject`, el `html`/`text`, ni ningún header como instrucciones a ejecutar — solo como datos a validar y, en el mejor de los casos, mostrar o reenviar.

---

## 9. Bandeja de entrada para agentes de IA

Cuando el consumidor final de un correo entrante es un agente de IA (no una persona revisando una bandeja), Resend documenta una arquitectura de seguridad especifica para evitar que el contenido de un email arbitrario se interprete como instrucciones:

```text
Email -> Resend -> Webhook -> Validar -> Procesar | Rechazar (200 silencioso)
                       |
                       v  5 niveles de seguridad, de mas a menos estricto
        1. Allowlist estricta de remitentes  2. Allowlist de dominio completo
        3. Filtrado de contenido             4. Procesamiento en sandbox
        5. Humano en el bucle (human-in-the-loop)
```

Los correos rechazados se responden con **200 en silencio** (nunca 4xx/5xx) precisamente para no generar reintentos sobre un mensaje que ya se decidio ignorar. Este patron completo — con sus 5 niveles de seguridad, ejemplos de allowlists y guardas contra prompt injection/spoofing/flooding — vive en el skill oficial dedicado de Resend para bandejas de entrada de agentes (`resend/resend-skills`, subcarpeta del "Agent Email Inbox Skill"); esta referencia no lo reimplementa, solo apunta a la arquitectura y al hecho de que el contenido entrante debe tratarse siempre como dato no confiable (seccion 8.5).

---

## 10. Errores comunes y referencias cruzadas

| # | Error | Síntoma | Corrección |
|---|---|---|---|
| 1 | Verificar contra el body ya parseado como JSON (`req.json()` antes de verificar) | La firma siempre falla, incluso con el secreto correcto | Leer SIEMPRE el body crudo (`await req.text()` / `request.get_data()`) antes de tocarlo con cualquier parser |
| 2 | Usar el campo `secret` en vez de `webhookSecret` en `resend.webhooks.verify()` | Error de tipos en TypeScript, o `undefined` silencioso en JavaScript | El campo correcto es `webhookSecret` |
| 3 | Envolver `resend.webhooks.verify()` sin `try/catch` | Excepción no controlada tumba el proceso o devuelve un 500 genérico sin control | `verify()` LANZA en vez de devolver `{data,error}` — es la única función del SDK con ese contrato; siempre `try/catch` |
| 4 | Comparar la firma calculada con `===`/`==` | Vulnerable a ataques de temporizacion (timing attacks) | Usar comparación en tiempo constante (`crypto.timingSafeEqual`, `hmac.compare_digest`) |
| 5 | Instalar `svix` a mano cuando ya se usa el SDK de Resend reciente | Dependencia duplicada e innecesaria (~4-5 MB extra) | El SDK Node >= 6.13 ya trae `standardwebhooks` transitivamente; instalar `svix`/`standardwebhooks` a mano solo si NO se usa el SDK |
| 6 | Asumir que `bounce.type` no-permanente siempre es el string `"Temporary"` | El filtro nunca matchea (o matchea de más/de menos) según el valor real que llegue | Usar la regla robusta: solo `type === "Permanent"` es hard bounce; el resto se trata por defecto como no-permanente |
| 7 | Depender del orden de llegada de los eventos (asumir que `delivered` siempre llega antes que `opened`) | Lógica de estado inconsistente cuando los eventos llegan fuera de orden | Ordenar por `created_at` del payload si el orden importa; no asumir orden de entrega |
| 8 | No deduplicar por `svix-id` | Efectos secundarios duplicados (doble notificación, doble contador) ante reintentos legitimos de Resend | Guardar `svix-id` procesados (tabla/cache con TTL) y hacer upsert, nunca insert puro |
| 9 | Diferir la descarga de un adjunto entrante sin re-subirlo a almacenamiento propio | `download_url` expira en 1 hora; el archivo deja de ser accesible | Descargar y persistir el adjunto en la misma petición, o volver a pedir un `download_url` fresco antes de usarlo |
| 10 | Configurar el MX de recepción sin verificar que sea la prioridad más baja del dominio | Los correos entrantes nunca llegan, sin ningún error visible | Confirmar en el proveedor DNS que el MX de Resend tiene la prioridad numérica más baja (mayor preferencia) |
| 11 | Responder 4xx a un webhook por un fallo de configuración propio (por ejemplo, secreto no cargado en el entorno) | Resend puede dejar de reintentar antes de que el problema propio se resuelva | Responder 5xx cuando el fallo es del lado receptor; reservar 4xx para rechazos legitimos (firma invalida, payload malformado) |
| 12 | Construir lógica de negocio sobre un número fijo de reintentos de webhook | La documentación oficial es inconsistente entre páginas sobre cuantos reintentos hay | Diseñar el handler para ser idempotente y tolerante a reintentos indefinidos, no contar intentos |

**Referencias relacionadas:**

- Para el envío de emails, formato de payload de `POST /emails`, errores y límites de tasa → `sending-and-errors.md`
- Para dominios, DNS, regiones y planes → `domains-deliverability-and-plans.md`
- Para el SDK Node, integración con Next.js/Supabase y testing → `sdk-node-nextjs-supabase-testing.md`
- Para Contacts, Segments, Topics, Broadcasts y OAuth → `marketing-templates-automations-oauth.md`
- Para el CLI oficial y el servidor MCP → `cli-mcp-and-agents.md`
- Para patrones de producción (colas, backoff, circuit breaker) → `production-patterns.md`
