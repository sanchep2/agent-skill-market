# Domains, Deliverability y Planes — Referencia completa

Cubre alta y verificación de dominios, registros DNS (esquema estable y variantes CNAME), return-path/tracking/TLS/DMARC/BIMI, regiones y residencia de datos, domain claim, warm-up, requisitos de entregabilidad por proveedor de bandeja, planes/precios/cuotas y patrones multi-tenant. API REST de Resend (sin versión de ruta) · SDK Node `resend` 6.26.0 · SDK Python `resend` 2.43.0 · CLI `resend-cli` 2.19.0 · `last_verified: 2026-09-04`.

## Table of Contents

1. [Alta y verificación de un dominio](#1-alta-y-verificación-de-un-dominio)
2. [Registros DNS](#2-registros-dns)
3. [Return-path, tracking, TLS, DMARC y BIMI](#3-return-path-tracking-tls-dmarc-y-bimi)
4. [Regiones y residencia de datos](#4-regiones-y-residencia-de-datos)
5. [Domain claim](#5-domain-claim)
6. [Warm-up](#6-warm-up)
7. [Requisitos por proveedor de bandeja](#7-requisitos-por-proveedor-de-bandeja)
8. [Planes, precios y cuotas](#8-planes-precios-y-cuotas)
9. [Multi-tenant](#9-multi-tenant)
10. [Seguridad de cuenta y anti-abuso](#10-seguridad-de-cuenta-y-anti-abuso)
11. [Diagnóstico de DNS](#11-diagnóstico-de-dns)
12. [Errores comunes y referencias cruzadas](#12-errores-comunes-y-referencias-cruzadas)

---

## 1. Alta y verificación de un dominio

Un dominio se puede dar de alta por Dashboard, API, CLI o MCP server. Resend recomienda de forma enfática enviar desde un **subdominio** (`updates.tu-dominio.com`, `send.tu-dominio.com`) y no desde el apex (`tu-dominio.com`): aísla la reputación de envío del resto del tráfico del dominio (web, otro proveedor de correo) y deja claro a los filtros anti-spam la intención del tráfico. Al crear el dominio se elige nombre, **región** (fija de por vida salvo borrar y recrear, ver §4) y, opcionalmente, un Return-Path custom y las opciones de tracking.

### 1.1 Tiempos de verificación

- Caso típico: el dominio queda `verified` en **~15 minutos** tras añadir los registros DNS correctos.
- Caso general (peor caso, documentado explícitamente por Resend): la propagación DNS puede tardar **hasta 72 horas** (verificado 2026-09-04).
- Existe un botón/endpoint "Restart verification" (`domains.verify`) para forzar un nuevo chequeo tras corregir el DNS — no hace falta esperar a un poll automático.
- Herramienta pública `dns.email` para comprobar qué ve realmente el mundo exterior de un registro antes de reintentar.

### 1.2 Campos de alta

| Campo | Tipo | Requerido | Notas |
|---|---|---|---|
| `name` | string | Sí | idealmente subdominio, p. ej. `updates.tu-dominio.com` |
| `region` | enum | Sí | `us-east-1` \| `eu-west-1` \| `sa-east-1` \| `ap-northeast-1` — fija para siempre salvo recrear (§4) |
| `customReturnPath` | string | No | default `send`; máx. 63 caracteres (§3) |
| `openTracking` | boolean | No | default `false` |
| `clickTracking` | boolean | No | default `false` |
| `trackingSubdomain` | string | No | default `links`; una vez creado no se puede borrar, solo cambiar (§3) |

### 1.3 Estados y capacidades

Estados de dominio confirmados por aparición real en ejemplos y prosa de la documentación: `not_started`, `pending` (tras llamar a `verify`), `verified`, `partially_verified` (esquema de 2 CNAME donde uno de los dos ya verificó y el otro no) y `failed`. La documentación de la API remite repetidamente a "see all available domain status types" sin desplegar en el texto plano la lista cerrada y completa de valores posibles — **no asumas que este es el conjunto exhaustivo**: trata cualquier valor no reconocido de `status` como un caso a loggear y revisar, nunca como un default silencioso.

`capabilities.sending` y `capabilities.receiving` son `enabled`/`disabled` de forma independiente; al menos una de las dos debe estar activa para que el dominio sirva de algo.

```text
                    resend.domains.create({ name, region })
                                  │
                                  ▼
                            not_started ─────────────────┐
                                  │                       │
                     añadir registros DNS (§2)            │ (ya verificado
                                  │                       │  en otra cuenta)
                                  ▼                       ▼
                    resend.domains.verify(id)      "domain already
                                  │                   registered"
                                  ▼                       │
                              pending                     ▼
                                  │                 ir a domain claim (§5)
                   (poll get-domain; propagación
                    DNS hasta 72 h en el peor caso)
                                  │
                 ┌────────────────┼──────────────────┐
                 ▼                ▼                   ▼
             verified     partially_verified       failed
      (sending/receiving   (falta un registro,   revisar DNS y volver
       listos)              envía sin MX de       a llamar a verify
                             respaldo)             ("Restart verification")
```

### 1.4 Crear y verificar (TypeScript)

```typescript
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY!);

// --- Crear el dominio ---
const { data: domain, error: createError } = await resend.domains.create({
  name: "updates.tu-dominio.com",
  region: "us-east-1", // 'us-east-1' | 'eu-west-1' | 'sa-east-1' | 'ap-northeast-1'
});

if (createError) {
  console.error({ createError });
  throw createError;
}

// --- Leer los registros exactos a publicar ---
console.log(domain?.records);

// --- Tras publicar el DNS, forzar la verificación ---
const { data: verified, error: verifyError } = await resend.domains.verify(domain!.id);

// --- Consultar el estado en cualquier momento ---
const { data: current } = await resend.domains.get(domain!.id);
console.log(current?.status); // 'not_started' | 'pending' | 'verified' | 'partially_verified' | 'failed'
```

### 1.5 Python, curl y CLI

```python
import os
import resend

resend.api_key = os.environ["RESEND_API_KEY"]

domain = resend.Domains.create({"name": "updates.tu-dominio.com", "region": "us-east-1"})
print(domain["records"])          # registros exactos a publicar
resend.Domains.verify(domain["id"])
print(resend.Domains.get(domain["id"])["status"])
```

```bash
# curl
curl -X POST 'https://api.resend.com/domains' \
  -H "Authorization: Bearer $RESEND_API_KEY" -H 'Content-Type: application/json' \
  -d '{"name": "updates.tu-dominio.com", "region": "eu-west-1"}'
curl -X POST "https://api.resend.com/domains/$DOMAIN_ID/verify" -H "Authorization: Bearer $RESEND_API_KEY"

# CLI (resend-cli 2.19.0)
resend domains create --name updates.tu-dominio.com --region us-east-1
resend domains list && resend domains get "$DOMAIN_ID" && resend domains verify "$DOMAIN_ID"
```

Si el dominio ya está verificado por otra cuenta, la API responde con un mensaje del tipo "The tu-dominio.com domain has been registered already" — no es un fallo de configuración propia, es un dominio reclamado por otro team: pasa a domain claim (§5).

---

## 2. Registros DNS

**No existe un esquema DNS único y permanente.** Resend documenta un esquema estable (MX+TXT), pero la propia documentación oficial también muestra, sin explicar el criterio de cuándo aplica cada uno, variantes con CNAME. La regla operativa es: **lee siempre la pestaña "Records" real del dominio (o la respuesta de `get-domain`) antes de publicar instrucciones de DNS a un cliente o a un equipo de infraestructura** — nunca copies un esquema de una sesión anterior o de un ejemplo de esta referencia como si fuera universal.

### 2.1 Esquema estable (el más extendido en la documentación y en las guías de proveedor DNS)

```json
{
  "records": [
    { "record": "SPF", "name": "send", "type": "MX", "value": "feedback-smtp.us-east-1.amazonses.com", "priority": 10, "ttl": "Auto" },
    { "record": "SPF", "name": "send", "type": "TXT", "value": "\"v=spf1 include:amazonses.com ~all\"", "ttl": "Auto" },
    { "record": "DKIM", "name": "resend._domainkey", "type": "TXT", "value": "p=<clave publica DKIM, 1024 bits>", "ttl": "Auto" }
  ]
}
```

- El valor del MX de retorno sigue el patrón `feedback-smtp.<region>.amazonses.com`, prioridad `10`.
- El TXT SPF en `send.<dominio>` es literalmente `v=spf1 include:amazonses.com ~all`.
- El TXT DKIM vive en `resend._domainkey.<dominio>` con un valor `p=<clave pública>`.
- La clave DKIM es de **1024 bits por decisión explícita de producto**, no por descuido: la documentación afirma literalmente que Resend no soporta claves DKIM de 2048 bits (verificado 2026-09-04). RFC 8301 §3.2 fija 1024 bits como mínimo aceptado, y ni Google ni Yahoo ni Microsoft exigen una longitud mayor en sus requisitos de bulk sender 2024. Si una política de seguridad interna exige 2048 bits, no hay self-serve: hay que escalar a soporte.

### 2.2 Variante: 2 CNAME para SPF (dominios creados después de agosto de 2026)

Dominios dados de alta después de agosto de 2026 pueden mostrar, en lugar del par MX+TXT tradicional, **dos registros CNAME** para el envío. Cada CNAME verifica de forma **independiente**: si solo uno de los dos propaga a tiempo, el dominio puede quedar en estado `partially_verified` — puede enviar, pero sin el servidor de respaldo del segundo registro.

### 2.3 Variante: 3 CNAME para DKIM (esquema "Easy DKIM" nativo de AWS SES)

El ejemplo de respuesta que la documentación oficial de `create-domain` muestra en algunos casos no es el TXT único de la sección 2.1, sino **3 registros DKIM tipo CNAME**, cada uno apuntando a `*.dkim.amazonses.com` con un nombre aleatorio de 32 caracteres (patrón `<32-hex>._domainkey`). Ninguna página de la documentación explica el criterio exacto de cuándo se usa un esquema u otro (¿fecha de creación del dominio, análoga al cambio de agosto-2026 en SPF? ¿región? ¿un flag de cuenta?). Tratar esto como una decisión que toma el backend de Resend en el momento de crear el dominio, no como algo configurable — y volver siempre a leer la respuesta real de `get-domain`.

### 2.4 Reglas de convivencia y trampas de proveedor DNS

- Un `CNAME` **no puede coexistir** con ningún otro registro en el mismo subdominio. Si `send.<dominio>` ya tiene un TXT o MX de otro proveedor (por ejemplo, otro servicio de email marketing), la verificación nunca completa; la solución es usar un Return-Path custom en otro subdominio (§3.1) o borrar el registro existente.
- Algunos proveedores de DNS **auto-anexan el dominio** al final de un valor MX/CNAME, produciendo un valor roto del tipo `feedback-smtp.eu-west-1.amazonses.com.tu-dominio.com`. La solución es forzar un FQDN añadiendo un punto final: `feedback-smtp.eu-west-1.amazonses.com.`.
- Si el dominio tiene registros **CAA**, Resend exige añadir uno adicional para poder emitir el certificado TLS del subdominio de tracking; sin ese CAA, la verificación del tracking falla en silencio.
- La prioridad MX no puede repetirse en el mismo subdominio; si `10` ya está ocupado por otro MX, usar `20` o `30`.
- Registros MX con la misma prioridad **no reparten tráfico**: ante cada intento de entrega se elige un único servidor al azar.

### 2.5 Guías por proveedor

| Proveedor | Método de alta | Tiempo típico de propagación | Nota específica |
|---|---|---|---|
| Cloudflare | Auto-configure vía Domain Connect | Minutos a unas horas | El proxy naranja ("orange cloud") debe estar en modo **DNS only** en el CNAME de tracking, o la verificación nunca completa |
| GoDaddy | Auto-configure vía Domain Connect | Minutos a unas horas | Mismo flujo guiado que Cloudflare |
| Amazon Route 53 | Alta manual, sin auto-configure | Hasta 5 horas (guía oficial) | Cada registro se crea a mano en la hosted zone |
| Namecheap | Alta manual | Hasta 72 horas (guía más conservadora) | Vigilar el TTL heredado del template por defecto |
| Vercel / otros genéricos | Alta manual | Hasta 72 horas (caso general documentado) | Sin Domain Connect; seguir el esquema literal de `get-domain` |

### 2.6 Mapa de registros del dominio (diagrama de referencia)

```text
tu-dominio.com
│
├── send.tu-dominio.com
│     MX   10  feedback-smtp.<region>.amazonses.com
│     TXT      "v=spf1 include:amazonses.com ~all"
│     (dominios creados post-ago-2026: puede aparecer como
│      2x CNAME de envio en su lugar — leer SIEMPRE la
│      pestaña Records real antes de publicar el esquema)
│
├── resend._domainkey.tu-dominio.com
│     TXT   "p=<clave publica DKIM, 1024 bits>"
│     (variante AWS SES "Easy DKIM": 3x CNAME a
│      *.dkim.amazonses.com con nombres aleatorios de 32
│      caracteres — mismo criterio de "leer el real")
│
├── _dmarc.tu-dominio.com
│     TXT   "v=DMARC1; p=none; rua=mailto:dmarc@tu-dominio.com;"
│
├── links.tu-dominio.com            (solo si openTracking/clickTracking = true)
│     CNAME  links1.resend-dns.com
│     (subdominio indeleble una vez creado, ver §3.2)
│
└── inbound.tu-dominio.com          (solo si Receiving = enabled)
      MX   10  <valor de recepcion devuelto por create-domain>
      (numero de prioridad MAS BAJO = mayor preferencia que
       cualquier otro MX del subdominio; convivencia en §2.7)
```

### 2.7 Recepción de correo y conflictos con MX existentes

Activar "Receiving" en un dominio hace que Resend reciba **todos** los correos entrantes de ese dominio según la prioridad MX — por eso se recomienda encarecidamente usar un subdominio también para inbound, nunca el apex si ya hay un proveedor de correo en producción (Google Workspace, Microsoft 365, etc.). Para convivir con un proveedor existente hay dos opciones: mantener el MX del apex en el proveedor actual y dar de alta Resend **solo en un subdominio dedicado** (`inbound.tu-dominio.com`), o hacer un **corte planificado** de la recepción (en una ventana acordada, el MX del dominio pasa a Resend con el número de prioridad más bajo). No existe una «migración gradual» por prioridades: el correo entrante va siempre al MX de menor número que responda, nunca se reparte entre varios.

### 2.8 Checklist pre-vuelo de un dominio nuevo

```text
[ ] Nombre elegido: subdominio, NUNCA el apex (updates. / send. / notifications.)
[ ] Region elegida a proposito y para siempre (borrar+recrear es la unica migracion)
[ ] send.<dominio> libre de TXT/MX previos, o Return-Path custom definido
[ ] Registros publicados EXACTAMENTE como los devuelve create-domain / la pestana Records
[ ] Punto final "." anadido si el proveedor DNS auto-anexa el dominio
[ ] CAA revisado: si existe, se anadio el CAA adicional que exige el certificado de tracking
[ ] DMARC en _dmarc.<dominio> desde el dia 1 (aunque sea p=none + rua)
[ ] Verificacion forzada (verify-domain) DESPUES de confirmar propagacion en dns.email
[ ] Si Receiving = enabled: MX de prioridad correcta, sin pisar un proveedor de correo existente
```

---

## 3. Return-path, tracking, TLS, DMARC y BIMI

### 3.1 Return-Path custom

El Return-Path por defecto es `send.<dominio>`. Se puede personalizar con `custom_return_path` al crear o actualizar el dominio: máximo 63 caracteres, debe empezar con una letra, terminar en letra o número, y solo admite letras, números y guiones. Evitar valores genéricos como `testing` que puedan confundirse con un dominio de prueba. Un Return-Path custom es la salida habitual cuando `send.<dominio>` ya tiene registros de otro proveedor (§2.4).

### 3.2 Tracking de apertura y clic

El tracking de apertura (`openTracking`) y clic (`clickTracking`) es una configuración **por dominio**, no por mensaje individual, y viene **desactivado por defecto** en todo dominio nuevo. Activarlo requiere un `trackingSubdomain` verificado (default `links`), que genera un CNAME `links.tu-dominio.com -> links1.resend-dns.com`.

Puntos operativos clave:

- El subdominio de tracking, **una vez creado, no se puede eliminar** — solo se puede cambiar por otro. Esto preserva los enlaces ya enviados en correos anteriores; si se borra el dominio completo con tracking activo, esos enlaces se rompen de forma permanente salvo que se monte un proxy propio antes de borrar.
- **Recomendación explícita de Resend: desactivar el tracking en dominios transaccionales/de autenticación.** El tracking de clic reescribe cada URL del correo para pasar por el dominio de tracking; en un enlace de un solo uso (verificación de email, magic link, reset de contraseña) esa reescritura puede romper el flujo si el destinatario pre-visualiza el enlace (algunos clientes de correo lo hacen automáticamente) y consume el token antes de que el usuario haga clic de verdad. Además, los proveedores de bandeja tratan la presencia de tracking como señal de que el correo es marketing, lo cual no ayuda a la reputación de un dominio puramente transaccional.
- Emails en texto plano puro no pueden trackear aperturas: el pixel de tracking requiere una parte HTML.
- Gmail no cuenta como "open" un mensaje que supere **102 KB** salvo que se vea completo (el mensaje queda "clipeado") — afecta directamente a la métrica de open rate en correos con mucho HTML/imágenes inline.

```typescript
// Actualizar tracking y TLS de un dominio existente
await resend.domains.update({
  id: domainId,
  openTracking: false, // recomendado: false en dominios de auth/transaccional
  clickTracking: false,
  tls: "enforced", // 'opportunistic' | 'enforced'
});
```

### 3.3 TLS

- `opportunistic` (default): intenta TLS y cae a texto plano si el servidor receptor no lo soporta. Recomendado para marketing/broadcast, porque algunos servidores antiguos aún no soportan TLS y forzar `enforced` puede subir el bounce rate.
- `enforced`: bloquea el envío por completo si no hay TLS disponible. Recomendado para correo sensible (autenticación, contraseñas, datos personales).
- Resend soporta TLS 1.0, 1.1 y 1.2 en el transporte hacia el servidor receptor.

### 3.4 DMARC

Registro TXT en `_dmarc.<dominio>`. Progresión recomendada: empezar en modo de solo observación y escalar a bloqueo una vez confirmado que el propio tráfico legítimo pasa SPF/DKIM.

```text
# Fase 1 (dia 1) — solo observacion       v=DMARC1; p=none; rua=mailto:dmarc-reports@tu-dominio.com;
# Fase 2 — cuarentena tras validar SPF/DKIM  v=DMARC1; p=quarantine; pct=100; rua=mailto:dmarc-reports@tu-dominio.com;
# Fase 3 — rechazo total (requisito de BIMI) v=DMARC1; p=reject; pct=100; rua=mailto:dmarc-reports@tu-dominio.com;
```

Parámetros: `v`, `p` (`none`/`quarantine`/`reject`), `pct`, `rua` (reporte agregado), `ruf` (reporte forense), `sp` (política de subdominios), `adkim`, `aspf`. Nota operativa: **`pct` y `ruf` no son ampliamente respetados** por todos los proveedores de bandeja — no depender de ellos para el control fino del rollout.

### 3.5 BIMI

BIMI requiere DMARC en `p=quarantine` o `p=reject` con `pct=100`. Dos vías de certificado:

- **VMC** (Verified Mark Certificate): requiere marca registrada; habilita el checkmark azul verificado en Gmail.
- **CMC** (Common Mark Certificate): uso probado durante más de un año, sin necesidad de marca registrada; solo reconocido por Gmail/Yahoo.

```text
default._bimi.tu-dominio.com   TXT   "v=BIMI1; l=https://tu-dominio.com/logo.svg; a=https://tu-dominio.com/vmc-or-cmc.pem;"
```

Nota relacionada: mostrar un logo/avatar en la bandeja de entrada (vía Gmail/Outlook/Yahoo Sender Avatar, BIMI, o Apple Branded Mail con Apple Business Connect) se asocia en estudios citados por Resend a mejoras notables de reconocimiento de marca y de tasa de apertura — pero el avatar de Gmail/Outlook/Yahoo se configura en la **cuenta personal del remitente** en esos proveedores, no en Resend.

---

## 4. Regiones y residencia de datos

| Región | Ubicación AWS | Uso típico |
|---|---|---|
| `us-east-1` | Norte de Virginia, EE. UU. | Default, mayor cercanía a la mayoría de proveedores de bandeja de EE. UU. |
| `eu-west-1` | Irlanda | Envío con salida desde infraestructura europea |
| `sa-east-1` | São Paulo, Brasil | Envío con salida desde Sudamérica |
| `ap-northeast-1` | Tokio, Japón | Envío con salida desde Asia-Pacífico |

### 4.1 Callout de residencia de datos (crítico para cualquier argumento de cumplimiento)

> **La región solo controla desde dónde se enrutan y envían los correos. No controla dónde se almacenan los datos del cliente.** Toda la metadata de cuenta —logs, registros de la API, historial de eventos— se almacena **siempre en EE. UU.**, sin importar la región de envío elegida (verificado 2026-09-04). Elegir `eu-west-1` **no** saca los metadatos/logs de EE. UU.: no uses esa elección como única base de un argumento de residencia de datos GDPR sin leer también el DPA (Data Processing Agreement) vigente de Resend.

Fuentes de comunidad (competidores de Resend, con sesgo comercial evidente pero coincidentes en el hecho verificable) añaden que Resend corre por debajo sobre **Amazon SES** — consistente con que todos los valores DNS observados siguen el patrón `amazonses.com`. Esto no está confirmado en un texto oficial literal de Resend en esta referencia, pero explica por qué las IPs de envío y la reputación subyacente son las de AWS SES, y por qué no hay un listado propio de IPs para allowlisting (ver Dedicated IPs, §6.2).

### 4.2 Multi-región para el mismo dominio raíz

Se puede tener presencia en varias regiones para el mismo dominio raíz usando **subdominios distintos por región** (`us.tu-dominio.com` en `us-east-1`, `eu.tu-dominio.com` en `eu-west-1`), cada uno verificado de forma independiente como un dominio propio.

### 4.3 Cambiar de región

**No existe un endpoint de migración in-place.** Cambiar la región de un dominio ya verificado exige borrarlo y volver a crearlo desde cero en la región nueva, lo que implica:

1. Planificar una ventana de interrupción del envío desde ese dominio.
2. Volver a publicar el DNS completo (los valores de MX/DKIM cambian con la región).
3. Re-verificar desde `not_started`.

---

## 5. Domain claim

Domain claim es el mecanismo para reclamar un dominio que **ya está verificado en otra cuenta** de Resend (por ejemplo, al comprar un negocio que ya usaba Resend, o al migrar de una cuenta de agencia a la cuenta propia del cliente).

### 5.1 Flujo y estados

`POST /domains/claim` crea un dominio placeholder en la cuenta que reclama y devuelve un objeto `domain_claim` con un registro TXT de verificación (`resend-domain-verification=<hash>`) que hay que publicar en el dominio.

Estados del claim: `pending` → `verified` → `completed`; o terminaciones alternativas `blocked` (con razón: `grace_period`, `recent_owner_activity` o `pending_scheduled_emails`), `expired`, `superseded`, `canceled`, `failed`.

- El claim **expira en 7 días** desde su creación.
- Cancelar un claim pendiente equivale a borrar el dominio placeholder con `delete-domain` usando su `domain_id`.

### 5.2 Consecuencia crítica tras completar el claim

**El dominio se transfiere como si fuera completamente nuevo, con sus propias claves DKIM.** Los registros DNS que existían en la cuenta de origen **no se pueden reutilizar** en la cuenta que reclama. El flujo obligatorio tras `completed` es:

1. Releer `get-domain` para obtener el nuevo esquema de registros (DKIM incluido).
2. Actualizar el DNS público con esos valores nuevos.
3. Llamar a `verify-domain` antes de poder enviar o recibir desde la cuenta que reclamó.

Hasta que ese ciclo termine, el dominio no puede usarse para envío ni recepción — planificar la ventana de corte igual que en un cambio de región (§4.3).

```typescript
// --- Iniciar el claim, publicar el TXT devuelto, verificar y consultar estado ---
const { data: claim } = await resend.domains.claims.create({ name: "tu-dominio.com" });
// -> { object: 'domain_claim', id, status: 'pending', domain_id, record: {type,name,value}, expires_at }
await resend.domains.claims.verify(claim!.domain_id);
const { data: current } = await resend.domains.claims.get(claim!.domain_id);
console.log(current?.status);
```

```bash
# Equivalente CLI
resend domains claim create --name tu-dominio.com
resend domains claim verify "$DOMAIN_ID" && resend domains claim get "$DOMAIN_ID"
```

La disponibilidad de `domains.claims` en el SDK Python no está confirmada en esta referencia — verifica en la versión instalada (`python -c "import resend; print(dir(resend.Domains))"`) antes de depender de ella; si no existe, usa el `curl` directo contra `POST /domains/claim`.

---

## 6. Warm-up

Un dominio o IP nuevos no tienen reputación de envío: enviar volumen alto desde el primer día dispara filtros de spam. Resend documenta dos tablas de ramp-up y ofrece una calculadora de warm-up personalizada en el dashboard.

### 6.1 Dominio existente con reputación ya establecida

| Día | Emails/día (máx.) | Emails/hora (máx.) |
|---|---|---|
| 1 | hasta 1.000 | 100 |
| 2 | hasta 2.500 | 300 |
| 3 | hasta 5.000 | 600 |
| 4 | hasta 5.000 | 800 |
| 5 | hasta 7.500 | 1.000 |
| 6 | hasta 7.500 | 1.500 |
| 7 | hasta 10.000 | 2.000 |

### 6.2 Dominio completamente nuevo

| Día | Emails/día (máx.) | Emails/hora (máx.) |
|---|---|---|
| 1 | hasta 150 | — |
| 2 | hasta 250 | — |
| 3 | hasta 400 | — |
| 4 | hasta 700 | 50 |
| 5 | hasta 1.000 | 75 |
| 6 | hasta 1.500 | 100 |
| 7 | hasta 2.000 | 150 |

Durante todo el ramp-up hay que monitorizar el bounce rate (mantenerlo **por debajo de 4 %**) y el spam/complaint rate (**por debajo de 0,08 %**, ver §8.4): si cualquiera de los dos sube, frenar el ritmo de warm-up en vez de seguir la tabla a ciegas. Resend advierte explícitamente contra servicios de terceros que prometen "acelerar" el warm-up manipulando artificialmente filtros anti-spam — el ramp-up gradual real es la única vía sostenible.

### 6.3 IP dedicada

La IP dedicada de Resend es un **pool gestionado** ("Managed Dedicated IP Pool"): Resend se encarga del warmup automático, el autoscaling y el aislamiento de "noisy neighbors" — no expone la lista de IPs del pool, así que **no sirve para IP allowlisting** de terceros.

Requisitos para solicitarla:

- Todos los dominios que la usarán deben estar en la **misma región** (se provisiona por región) y ya **verificados**.
- Volumen: **más de 3.000 emails/día** (verificado 2026-09-04).
- Suscripción activa **Scale** (transaccional) o **Pro** (marketing).
- Coste: **$30/mes** como add-on (verificado 2026-09-04, re-verificar en `resend.com/pricing`).

**Cuándo NO conviene**: volumen bajo (por debajo de aproximadamente **90.000 emails/mes** la IP no se mantiene lo bastante caliente y puede ser contraproducente), envío inconsistente en picos, malas prácticas de envío ya existentes, o remitente nuevo sin historial — en esos casos, una IP compartida bien gestionada por Resend suele entregar mejor que una IP dedicada fría.

---

## 7. Requisitos por proveedor de bandeja

| Proveedor | SPF / DKIM | DMARC | Umbral de queja/spam | One-click unsubscribe | Notas propias |
|---|---|---|---|---|---|
| Gmail | Automático con dominio verificado en Resend | Recomendado; obligatorio de facto si se envían más de 5.000 emails/día | Objetivo interno de Resend: **< 0,08 %**; Gmail exige **< 0,10 %** para remitentes masivos (bulk senders) | Sí, obligatorio para correo de marketing (RFC 8058) | Clipea mensajes de más de **102 KB** (no cuenta el "open" del pixel de tracking) |
| Outlook / Microsoft 365 | Recomendado para todos, obligatorio de facto por encima de 5.000/día | Recomendado; obligatorio de facto para bulk | Mantener quejas **< 0,3 %** | Recomendado (RFC 8058) | Requisitos de bulk sender de Microsoft vigentes desde 2025 |
| Yahoo (incluye AOL) | Obligatorio (mínimo SPF o DKIM) | Obligatorio para bulk senders, mínimo `p=none` + `rua` | **< 0,3 %**, medido contra el correo que sí llega a la bandeja (no contra el total enviado) | Obligatorio para bulk vía header `List-Unsubscribe` (RFC 8058 recomendado; `mailto:` también aceptable); debe procesarse en **menos de 2 días** | Exige un registro **SOA resoluble** en el subdominio de envío — su ausencia da error `451` (temporal) o `554` (permanente); enforcement vigente desde 2024, one-click desde 2024 |
| iCloud / Apple Mail | Obligatorio para bulk (SPF+DKIM automático con Resend) | Obligatorio para bulk | Sin umbral público fijo; sin allowlist ni feedback loop documentado | Obligatorio para bulk, recomendado one-click | — |
| Apple Private Relay (`@privaterelay.appleid.com`) | Hereda del dominio de envío | Hereda del dominio de envío | N/A | N/A | Límite de **100 emails/día** por dirección Hide My Email; hay que registrar el dominio de envío, el dominio de return-path y todas las direcciones `from` en el Apple Developer Portal |

### 7.1 Regla general de cuenta (todos los proveedores)

La Acceptable Use Policy de Resend fija su propio umbral, independiente del de cada proveedor de bandeja: **bounce rate < 4 %** y **complaint/spam rate < 0,08 %** para **toda la cuenta**, no por campaña aislada. Superarlos puede suspender la cuenta **sin previo aviso** (§10.4). Los tres números de la tabla (Resend interno 0,08 %, Gmail 0,10 %, Yahoo/Outlook 0,3 %) son umbrales de **actores distintos** que se aplican en capas — no son versiones contradictorias de la misma cifra.

### 7.2 Cabeceras de one-click unsubscribe (RFC 8058)

```typescript
await resend.emails.send({
  from: process.env.EMAIL_FROM_ADDRESS!,
  to: "usuario@tu-dominio.com",
  subject: "Resumen semanal",
  html: "<p>Contenido del boletin...</p>",
  headers: {
    "List-Unsubscribe": "<https://tu-dominio.com/unsubscribe?token=abc123>, <mailto:unsubscribe@tu-dominio.com>",
    "List-Unsubscribe-Post": "List-Unsubscribe=One-Click",
  },
});
```

Con Broadcasts/Automations gestionados por Resend, el propio producto añade el unsubscribe automáticamente si el template incluye el placeholder `{{{RESEND_UNSUBSCRIBE_URL}}}` — no hace falta construir las cabeceras a mano en ese flujo.

### 7.3 Higiene de audiencia

- Doble opt-in recomendado para reducir bounces y para compliance CAN-SPAM/CASL.
- Filtrar por engagement: excluir de sends no-transaccionales a contactos sin apertura/clic en los últimos **6 meses** (umbral recomendado).
- Consentimiento válido bajo GDPR (Resend lo exige globalmente, no solo para tráfico UE): libre, específico, informado e inequívoco — checkbox de opt-in activo, nunca premarcado; una cláusula genérica en el ToS no cuenta como consentimiento.
- El unsubscribe está exento en correo puramente transaccional (confirmación de cuenta, reset de contraseña, confirmación de pedido); es obligatorio en todo lo demás.

---

## 8. Planes, precios y cuotas

> **Verificado 2026-09-04 en <https://resend.com/pricing> — re-verificar antes de citar cualquiera de estas cifras a un cliente o en una decisión de arquitectura.** Los precios y cuotas de Resend cambian con el tiempo (el propio historial de cambios incluye, por ejemplo, la subida de dominios en el plan Free de 1 a 3 — ver §8.6).

### 8.1 Transactional Email

| Plan | Precio/mes | Emails/mes incluidos | Overage por 1.000 emails |
|---|---|---|---|
| Free | $0 | 3.000 (tope adicional de 100/día) | — |
| Pro | $20 | 50.000 | $0,90 |
| Pro | $35 | 100.000 | $0,90 |
| Scale | $90 | 100.000 | $0,90 |
| Scale | $160 | 200.000 | $0,80 |
| Scale | $350 | 500.000 | $0,70 |
| Scale | $650 | 1.000.000 | $0,65 |
| Scale | $825 | 1.500.000 | $0,52 |
| Scale | $1.150 | 2.500.000 | $0,46 |
| Enterprise | A medida | A medida (rango típico 3M-500M+/mes) | A medida |

### 8.2 Marketing Email (por número de contactos, no por emails enviados)

| Plan | Precio/mes | Contactos incluidos |
|---|---|---|
| Free | $0 | 1.000 |
| Pro marketing | $40 | 5.000 |
| Pro marketing | $80 | 10.000 |
| Pro marketing | $120 | 15.000 |
| Pro marketing | $180 | 25.000 |
| Pro marketing | $250 | 50.000 |
| Pro marketing | $450 | 100.000 |
| Pro marketing | $650 | 150.000 |
| Enterprise | A medida | A medida |

Los Broadcasts de marketing solo se envían a contactos ya existentes en la cuenta; el coste escala con el tamaño de la base de contactos, no con el volumen de envíos.

### 8.3 Add-ons y consumo por uso

| Add-on / consumo | Precio | Requisitos / notas |
|---|---|---|
| +100 dominios | $20/mes | Disponible en Pro y Scale; on/off en cualquier momento desde Settings > Usage; en Enterprise es por contrato |
| IP dedicada | $30/mes | Solo Scale (transaccional) o Pro (marketing); requiere > 3.000 emails/día (§6.3) |
| SSO | $150/mes | Add-on en Scale; incluido sin coste adicional en Enterprise |
| No almacenar contenido de mensajes | $50/mes | Requiere cuenta Pro/Scale con ≥ 1 mes de antigüedad, dominio con sitio web activo y > 3.000 emails enviados con < 5 % de bounce rate — no es autoservicio inmediato |
| Automations (pay-as-you-go) | $0,0015/run tras el incluido | 10.000 runs/mes incluidos en TODOS los planes, Free incluido (sin overage en Free) |

### 8.4 Umbrales duros de cuenta y cuotas

| Umbral | Valor | Consecuencia |
|---|---|---|
| Rate limit | **10 req/s por TEAM** (no por API key ni por dominio; todas las API keys de un mismo team comparten el pool) | `429 rate_limit_exceeded` al superarlo; ampliable bajo petición a soporte |
| Overage (planes de pago) | Hard cap de **5×** la cuota mensual del plan | Al alcanzarlo, el envío se **pausa** hasta el siguiente ciclo de facturación |
| Bounce rate máximo | **4 %** | Riesgo de suspensión de cuenta sin aviso previo |
| Spam/complaint rate máximo | **0,08 %** | Riesgo de suspensión de cuenta sin aviso previo (coincide con la Acceptable Use Policy legal) |
| Retención de datos | **30 días** en Free/Pro/Scale; flexible en Enterprise | Eventos y contenido de mensajes no son recuperables pasado ese plazo — persistir lo que importe en tu propia base de datos |
| Dominios verificados | Free 3 · Pro 10 · Scale 1.000 · Enterprise por contrato | Ver add-on de +100 dominios (§8.3) |
| Contactos marketing | Free 1.000 · escalado por plan Pro marketing | Ver §8.2 |
| Webhook endpoints | Pro 5 · Scale 10 | Por team |
| AI Credits | Free 5/mes · Pro 100/mes · Scale 500/mes · Enterprise flexible | **No acumulables** (sin rollover al mes siguiente) |

**Producción sin aprobación**: toda cuenta, incluida Free, tiene acceso de producción inmediato desde el alta — no existe modo sandbox ni proceso de aprobación previo.

### 8.5 Lo que incluyen todos los planes

REST API, SMTP relay, SDKs oficiales, recepción de correo (inbound), envío por lotes (batch), tracking de apertura/clic, React Email, soporte multi-región, DKIM/SPF/DMARC, webhooks, cumplimiento SOC 2 Type II y GDPR, MFA y permisos por API key.

### 8.6 Nota de coherencia y de historial

Al 2026-09-04, la tabla de `resend.com/pricing` (consultada en vivo) coincide exactamente con las páginas de la base de conocimiento sobre cuotas y precios, sin discrepancias entre esas fuentes oficiales. El plan Free subió de 1 a **3 dominios verificados** en un cambio de producto documentado en el changelog oficial ("More Domains on the Free Tier") — cualquier fuente de terceros que cite "1 dominio" en Free está desactualizada.

---

## 9. Multi-tenant

Resend documenta oficialmente dos patrones para servir a múltiples tenants (clientes finales de una plataforma) desde una sola integración, con una tabla comparativa de trade-offs.

### 9.1 Tabla oficial: Opción A vs Opción B

| Factor | Opción A: cuenta única | Opción B: cuentas separadas (BYOK) |
|---|---|---|
| Complejidad de setup | Baja: 100 % vía API | Alta: alta manual por tenant, sin creación de team vía API |
| Aislamiento de envío | Compartido: un mal actor puede afectar a todos los tenants | Total: cada tenant queda aislado en su propia cuenta |
| Billing | Un solo plan cubre a todos los tenants | Cada tenant gestiona y paga su propio plan |
| Analytics por tenant | No disponible de forma nativa | Cada tenant tiene su propio dashboard completo |
| Enrutado de webhooks | Vía `tags` o por dominio `from` | Cada cuenta tiene sus propios webhooks independientes |
| Deliverability | Reputación de envío compartida entre tenants | Reputación de envío independiente por tenant |
| Rate limits | Volumen agregado de todos los tenants contra el mismo pool — probablemente exige pedir una subida | Cada tenant usa su propio límite de 10 req/s |

### 9.2 Riesgo explícito de la Opción A

> Si un tenant tiene malas prácticas de envío (spam, bounce rate alto), puede afectar la entregabilidad de **todos** los demás tenants de la misma cuenta. En casos severos, la cuenta entera puede quedar suspendida.

### 9.3 Opción A — API key con scope de dominio por tenant

```typescript
// --- Alta de un tenant nuevo: dominio propio + API key con scope de dominio ---
const domain = await resend.domains.create({
  name: "correo.tenant-a.com",
  region: "us-east-1", // explícita: la región es INMUTABLE tras crear el dominio (sección 2)
});
await resend.domains.verify(domain.data!.id);

const apiKey = await resend.apiKeys.create({
  name: `Tenant: correo.tenant-a.com`,
  permission: "sending_access",
  domain_id: domain.data!.id,
}); // el token solo se devuelve una vez: persistirlo cifrado en la plataforma

// --- Enrutado de webhooks por tenant via tags ---
await resend.emails.send({
  from: process.env.EMAIL_FROM_ADDRESS!,
  to: "usuario@tenant-a.com",
  subject: "Bienvenido",
  html: "<p>Gracias por registrarte.</p>",
  tags: [{ name: "tenant_id", value: "tenant_a" }],
}); // el webhook handler central lee event.data.tags para enrutar al tenant correcto
```

### 9.4 Opción B — BYOK (Bring Your Own Key)

```typescript
// Cada tenant aporta su propia API key; la plataforma solo la reenvía
const resend = new Resend(tenantApiKey);

await resend.emails.send({
  from: process.env.EMAIL_FROM_ADDRESS!,
  to: "usuario@example.com",
  subject: "Tu pedido se ha enviado",
  html: "<p>Tu pedido #1234 va en camino.</p>",
});
```

**"Team creation is not currently available vía the API"**: no hay forma de automatizar la Opción B por completo — cada tenant debe crear su propia cuenta de Resend manualmente en el dashboard antes de entregar su API key a la plataforma.

### 9.5 Migración entre opciones

La migración está documentada en ambos sentidos (A→B y B→A). Mover un dominio de una cuenta a otra exige **borrarlo de la cuenta de origen antes de poder re-verificarlo** en la cuenta de destino — planificar una ventana de interrupción de envío, igual que en un domain claim (§5) o un cambio de región (§4.3). Cada dominio de tenant cuenta contra el límite de dominios del plan de la cuenta que lo aloja (§8.4); si se llega al tope, aplica el add-on de +100 dominios (§8.3).

---

## 10. Seguridad de cuenta y anti-abuso

### 10.1 MFA

Autenticación de doble factor vía TOTP (código QR desde el perfil de usuario). Se desactiva desde la propia cuenta con la opción "Revoke Access".

### 10.2 SSO

Disponible como add-on en Scale (**$150/mes**) o incluido sin coste adicional en Enterprise. Requiere ser **Admin** del team y tener el propio email en el dominio de la organización. Flujo: publicar un TXT de verificación en el apex del dominio → conectar el Identity Provider → los usuarios nuevos vía SSO se añaden automáticamente con rol **Member**. "Enforce SSO" (opcional) fuerza el login solo vía el IdP conectado — mantener **al menos una cuenta Admin fuera del dominio SSO** como vía de escape si el IdP cae. Restricción adicional no autoservicio (requiere ticket de soporte): impedir que cuentas del dominio SSO creen o se unan a teams fuera de la organización.

### 10.3 Roles y billing de team

| Rol | Permisos |
|---|---|
| Member | Gestionar emails, dominios y webhooks |
| Admin | Todo lo de Member + invitar miembros, gestionar pagos, borrar el team |

- Un usuario puede pertenecer a **múltiples teams** con un único email de login; cada team tiene sus propias API keys, billing y consumo independientes.
- Solo se admite **un billing email** por team (workaround si se necesitan varios destinatarios: alias de distribución, o invitar a más miembros con acceso de facturación).
- Si el último miembro de un team abandona la cuenta, **el team y todos sus datos se borran permanentemente** (requiere confirmación tecleando literalmente `DELETE`).

### 10.4 Anti-abuso y suspensión de cuenta

La Acceptable Use Policy permite a Resend terminar una cuenta **en cualquier momento** por violaciones, **sin reembolso** ni siquiera de la cuota mensual parcialmente consumida. Superar los umbrales de bounce (4 %) o de spam/complaint (0,08 %) documentados en §8.4 puede disparar una suspensión **sin previo aviso**.

Patrón real documentado de comunidad (confirmado por un empleado de Resend respondiendo públicamente): una cuenta se suspendió un fin de semana sin aviso previo; **el soporte solo opera de lunes a viernes**, así que quedó sin respuesta hasta el lunes; crear una **segunda cuenta con el mismo dominio** mientras la primera estaba bajo revisión **agravó el problema** (el sistema anti-abuso lo detectó como intento de evasión y suspendió también la segunda cuenta); la resolución llegó solo tras escalar directamente a un empleado de Resend.

**Regla operativa**: ante una suspensión inesperada, escalar por el canal de soporte oficial y esperar — nunca crear una cuenta nueva con el mismo dominio como "solución rápida".

### 10.5 Incidentes de entrega a Microsoft (verificados en la status page oficial)

- **17-18 de marzo de 2026**: incidente "Deliverability Issues to Outlook Emails", específico de la región `eu-west-1`, resuelto en aproximadamente 23 horas; Resend escaló directamente con Microsoft.
- **20-21 de julio de 2026**: incidente "Delivery Delayed Events to Microsoft Hosted Domains", aproximadamente 26 horas, mismo patrón de coordinación directa con Microsoft; los correos nuevos se entregaban con normalidad mientras los ya encolados se resolvían por reintento.

Antes de escalar a soporte un problema de entrega puntual hacia dominios `outlook.com`/`hotmail.com`/`live.com`/Microsoft 365, **consultar primero la status page oficial de Resend** (y agregadores de terceros tipo IsDown) — ambos incidentes históricos fueron problemas de infraestructura del lado de Microsoft/Resend, no de configuración del cliente.

### 10.6 Datos sensibles

El add-on de "no almacenar contenido de mensajes" ($50/mes, §8.3) reduce lo que Resend retiene, pero **no es inmediato ni autoservicio total**: exige antigüedad de cuenta, plan Pro/Scale, dominio con sitio activo y un historial mínimo de envío con bajo bounce rate.

---

## 11. Diagnóstico de DNS

Antes de escalar a soporte un dominio que no verifica, comprobar con herramientas independientes de la caché de tu propio resolvedor local.

### 11.1 Comandos `dig`

```bash
DOMAIN="tu-dominio.com"

dig +short MX "send.$DOMAIN"                    # esperado: 10 feedback-smtp.<region>.amazonses.com.
dig +short TXT "send.$DOMAIN"                   # esperado: "v=spf1 include:amazonses.com ~all"
dig +short TXT "resend._domainkey.$DOMAIN"      # esperado: "p=<clave publica>" (o 3x CNAME, §2.3)
dig +short TXT "_dmarc.$DOMAIN"                 # esperado: "v=DMARC1; p=none; rua=mailto:..."
dig +short CNAME "links.$DOMAIN"                # esperado: links1.resend-dns.com. (solo si tracking on)

# Contra un resolvedor publico distinto al local, para descartar cache propia
dig @8.8.8.8 +short TXT "resend._domainkey.$DOMAIN"
dig @1.1.1.1 +short TXT "resend._domainkey.$DOMAIN"
```

### 11.2 Equivalente `nslookup`

```bash
nslookup -type=MX "send.$DOMAIN"
nslookup -type=TXT "send.$DOMAIN"
nslookup -type=TXT "resend._domainkey.$DOMAIN"
nslookup -type=TXT "_dmarc.$DOMAIN"
nslookup -type=CNAME "links.$DOMAIN"
```

### 11.3 Herramienta pública

`dns.email` permite comprobar qué registros ve el mundo exterior para un dominio, sin depender del resolvedor local — útil para confirmar que la propagación ya llegó antes de forzar `verify-domain` de nuevo.

### 11.4 Qué revisar antes de escalar a soporte

```text
[ ] dig contra 8.8.8.8 Y 1.1.1.1 devuelven el MISMO valor (no es solo cache local)
[ ] El valor MX/CNAME no quedo con el dominio duplicado al final (falta el "." final)
[ ] send.<dominio> no tiene un TXT/MX previo de OTRO proveedor pisando el registro
[ ] TTL del registro ya vencio desde la ultima edicion (no sigue sirviendo el valor viejo)
[ ] CAA (si existe) permite emitir el certificado del subdominio de tracking
[ ] El esquema leido es el de LA RESPUESTA REAL de get-domain, no uno copiado de otra sesion
[ ] Se probo "Restart verification" / domains.verify DESPUES de confirmar propagacion
```

Si todo lo anterior está correcto y el dominio sigue sin verificar pasadas las 72 horas documentadas como peor caso, ese es el punto en el que corresponde abrir un ticket de soporte con la salida de los comandos anteriores adjunta.

---

## 12. Errores comunes y referencias cruzadas

| # | Error | Síntoma | Corrección |
|---|---|---|---|
| 1 | Asumir que el DKIM debe ser de 2048 bits | Una auditoría de seguridad interna marca el DKIM como "débil" | Es una decisión de producto documentada (1024 bits, cumple RFC 8301); no hay upgrade self-serve, solo escalando a soporte |
| 2 | Hardcodear el esquema DNS de una sesión anterior | El dominio nuevo no verifica porque el esquema real es distinto (CNAME en vez de MX+TXT) | Leer siempre la respuesta real de `get-domain` / la pestaña Records antes de publicar instrucciones |
| 3 | Publicar `send.<dominio>` sobre un TXT/MX ya existente de otro proveedor | La verificación nunca completa, sin error explícito | Usar un Return-Path custom en otro subdominio, o borrar el registro en conflicto |
| 4 | No añadir el punto final en proveedores que auto-anexan el dominio | El valor MX/CNAME queda duplicado (`....amazonses.com.tu-dominio.com`) | Forzar FQDN con un `.` final en el valor publicado |
| 5 | Activar tracking de clic en un dominio de autenticación | Los magic links / enlaces de reset de contraseña de un solo uso dejan de funcionar tras la reescritura | Desactivar `openTracking`/`clickTracking` en cualquier dominio que envíe enlaces de un solo uso |
| 6 | Borrar un dominio con tracking ya usado en correos enviados | Todos los enlaces de esos correos antiguos dejan de resolver, sin aviso | Migrar antes a un proxy propio, o aceptar la pérdida de forma consciente antes de borrar |
| 7 | Asumir que `region: eu-west-1` mantiene los datos en la UE | Un argumento de cumplimiento GDPR se apoya solo en la región elegida | La región solo define desde dónde se envía; metadata y logs viven siempre en EE. UU. |
| 8 | Intentar cambiar la región de un dominio ya verificado con un `update` | No existe ese campo actualizable; el intento falla o se ignora | Borrar el dominio y recrearlo en la región nueva, con ventana de corte planificada |
| 9 | Solicitar IP dedicada con volumen bajo | La IP nunca se calienta del todo, la entregabilidad no mejora o incluso empeora | Solo pedirla por encima del umbral documentado (> 3.000/día, idealmente cerca de ~90.000/mes) |
| 10 | Crear una segunda cuenta con el mismo dominio tras una suspensión | El sistema anti-abuso detecta evasión y suspende también la cuenta nueva | Escalar por soporte con la cuenta original y esperar respuesta (L-V) |
| 11 | Citar "Free = 1 dominio" de una fuente de terceros desactualizada | Se subestima la cuota real disponible en Free | Free incluye 3 dominios verificados (dato oficial, verificado 2026-09-04) |
| 12 | Usar el patrón multi-tenant Opción A sin monitorizar por tenant | Un tenant con malas prácticas de envío degrada la reputación de todos los demás | Etiquetar cada envío con `tags` por tenant y vigilar bounce/complaint por esa dimensión |

**Referencias relacionadas:**

- Para el detalle de errores de envío, rate limit y códigos HTTP → `sending-and-errors.md`
- Para el esquema de eventos, firma y reintentos de webhooks → `webhooks-and-inbound.md`
- Para instalación, inicialización y patrones de framework del SDK → `sdk-node-nextjs-supabase-testing.md`
- Para Broadcasts, Segments, Topics, Templates y Automations → `marketing-templates-automations-oauth.md`
- Para el CLI oficial y el servidor MCP → `cli-mcp-and-agents.md`
- Para patrones de producción end-to-end (colas, idempotencia, observabilidad) → `production-patterns.md`
