# Marketing, Templates, Automations y OAuth — Referencia completa

Cubre el modelo de datos Contact/Segment/Topic, Broadcasts, Templates, Automations, Events y OAuth para apps de terceros · API REST de Resend (sin versión de ruta) · SDK Node `resend` 6.26.0 · `last_verified: 2026-09-04`.

## Table of Contents

1. [Modelo de datos: Contact, Segment y Topic](#1-modelo-de-datos-contact-segment-y-topic)
2. [Contacts](#2-contacts)
3. [Contact properties](#3-contact-properties)
4. [Segments](#4-segments)
5. [Topics](#5-topics)
6. [Broadcasts](#6-broadcasts)
7. [Templates](#7-templates)
8. [Automations](#8-automations)
9. [Events](#9-events)
10. [OAuth para apps de terceros](#10-oauth-para-apps-de-terceros)
11. [Errores comunes y referencias cruzadas](#11-errores-comunes-y-referencias-cruzadas)

---

## 1. Modelo de datos: Contact, Segment y Topic

Resend tiene dos superficies de envío: **transaccional** (`/emails`, `/emails/batch` — ver `sending-and-errors.md`) y **marketing** (Broadcasts + Automations, este fichero). Ambas comparten un modelo de datos de tres capas que es el punto de más friccion para quien viene de otra plataforma (Mailchimp, Audiences legacy de la propia Resend): un **Contact** global, agrupado en **Segments** internos y suscrito (o no) a **Topics** visibles.

```text
        ┌───────────────────────────────────────────┐
        │ CONTACT (global) — email, unsubscribed=switch GLOBAL, properties │
        └─────────────────┬──────────────┬───────────┘
             pertenece a 0..N      opt_in/opt_out en 0..N
                           v              v
              ┌────────────────────┐  ┌────────────────────┐
              │ SEGMENT (interno)   │  │ TOPIC (visible)      │
              │ "a quien" se envia  │  │ "que" recibe          │
              │ antes: Audience     │  │ pagina de unsubscribe │
              └──────────┬──────────┘  └──────────┬───────────┘
                         v                         v
              Broadcast.segment_id        Broadcast.topic_id
              (obligatorio)               (recomendado)
```

### 1.1 Contact: identidad global

Un `Contact` es una entidad global ligada a un único email: `email`, `first_name`, `last_name`, `unsubscribed` (booleano — baja de TODOS los Broadcasts, sin importar el Topic), `properties` (mapa de propiedades custom) y `created_at`. Puede pertenecer a cero, uno o varios Segments, y estar opt-in u opt-out en cero, uno o varios Topics.

Hasta el 30/31 de octubre de 2025 cada Contact vivia dentro de una Audience y el mismo email en dos Audiences contaba como dos Contacts distintos. Con la migración a Segments el Contact paso a ser global: el mismo email cuenta **una sola vez** para la cuota de contactos aunque pertenezca a varios Segments. El parámetro legacy `audience_id` se sigue aceptando en Contacts y Broadcasts por compatibilidad hacia atras, pero todo código nuevo debe usar `segment_id`; `GET /broadcasts/:id` sigue devolviendo ambos campos en la respuesta.

### 1.2 Segment: agrupacion interna ("a quien")

Un Segment es una herramienta de segmentacion interna, invisible para el Contact, que tu equipo usa para decidir a quien enviar un Broadcast. Solo tiene `name`; no aparece nunca en la página de preferencias del destinatario.

### 1.3 Topic: preferencia visible ("que")

Un Topic es la contraparte de cara al usuario: una categoría de contenido (`"Newsletter semanal"`, `"Alertas de producto"`) con una suscripción `opt_in` u `opt_out` que el propio Contact puede cambiar desde la página de baja. Un Topic tiene `default_subscription` fijado al crearlo (no editable después) y `visibility` `public` o `private`.

### 1.4 Topics vs Segments (tabla oficial)

| Aspecto | Topic | Segment |
|---|---|---|
| Quien controla | El destinatario (se suscribe o se da de baja) | El remitente (tu equipo) |
| Visibilidad | En la página de unsubscribe si `visibility` es `public` | Interno; el Contact nunca lo ve |
| Propósito | Gestionar preferencias de contenido | Organizar a quien se envia un Broadcast |
| Editable tras crear | Solo `name`, `description`, `visibility` (`default_subscription` es fijo) | `name` (rename libre) |
| Ejemplo | "Newsletter semanal", "Ofertas" | "Clientes activos LATAM", "Trial mayor a 14 días" |

Recomendación oficial: **3 a 5 Topics como máximo**, con nombres claros. Si un Broadcast no lleva `topic_id`, la baja que genere es **global** (equivale a `unsubscribed = true`), lo cual suele ser más agresivo de lo que el negocio quiere — por eso el checklist de la seccion 6.6 exige verificar el `topic_id` antes de enviar.

### 1.5 El interruptor global y la página de unsubscribe

`unsubscribed = true` en un Contact es un interruptor global independiente de los Topics: si esta activo, ese Contact no recibe ningún Broadcast aunque siga `opt_in` en algún Topic. Con `unsubscribed = false`, lo que recibe depende de su suscripción por Topic.

La página de baja es hospedada por Resend y personalizable (título, descripción, logo, colores de fondo/texto/acento) desde la configuración de la cuenta; aplica a todo el equipo y todos los dominios. El pie de página "Powered by Resend" **solo se puede quitar en el plan Pro o superior** (verificar vigencia en `resend.com/pricing`).

---

## 2. Contacts

### 2.1 CRUD por id o por email

Un Contact se identifica indistintamente por su `id` (UUID) o por su `email` en el mismo parámetro de ruta (`:id_or_email`). Al crear se pueden pasar de una vez `properties`, `segments` (array de `{id}`) y `topics` (array de `{id, subscription}`).

```typescript
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

const { data } = await resend.contacts.create({
  email: "usuario@tu-dominio.com",
  firstName: "Steve",
  unsubscribed: false,
  segments: [{ id: "78261eea-8f8b-4381-83c6-79fa7120f1cf" }],
  topics: [{ id: "b6d24b8e-af0b-4c3c-be0c-359bbd97381e", subscription: "opt_in" }],
});

await resend.contacts.get({ email: "usuario@tu-dominio.com" }); // en el SDK Node `id` y `email` son keys DISTINTAS (el path REST acepta ambos)
await resend.contacts.update({ email: "usuario@tu-dominio.com", firstName: "Ana" });
await resend.contacts.remove({ email: "usuario@tu-dominio.com" });
```

```python
import os
import resend

resend.api_key = os.environ["RESEND_API_KEY"]

resend.Contacts.create({
    "email": "usuario@tu-dominio.com",
    "first_name": "Steve",
    "unsubscribed": False,
    "segments": [{"id": "78261eea-8f8b-4381-83c6-79fa7120f1cf"}],
    "topics": [{"id": "b6d24b8e-af0b-4c3c-be0c-359bbd97381e", "subscription": "opt_in"}],
})

resend.Contacts.remove(email="usuario@tu-dominio.com")

# suscripciones de un contact a Topics (confirmado contra la doc oficial)
resend.Contacts.Topics.list(email="usuario@tu-dominio.com")
resend.Contacts.Topics.update({
    "id": "e169aa45-1ecf-4183-9955-b1499d5701d3",
    "topics": [{"id": "b6d24b8e-af0b-4c3c-be0c-359bbd97381e", "subscription": "opt_out"}],
})
```

`GET /contacts` acepta un `segment_id` opcional para filtrar (equivalente a `GET /segments/:id/contacts`, seccion 4). Gestión de la pertenencia a un Segment: `POST /contacts/:id_or_email/segments/:segment_id` (add), `GET /contacts/:id_or_email/segments` (list), `DELETE /contacts/:id_or_email/segments/:segment_id` (remove). Gestión de Topics de un Contact: `GET /contacts/:id_or_email/topics` (devuelve cada Topic con su `subscription`), `PATCH /contacts/:id_or_email/topics` con un array `[{id, subscription}]`.

### 2.2 Import masivo por CSV

`POST /contacts/imports` acepta `multipart/form-data`. El archivo va en el campo `file`, **máximo 200 MB** (verificado 2026-09-04; una cifra de 100 MB circula en fuentes de comunidad desactualizadas — usar siempre 200 MB). `column_map`, `segments` y `topics` viajan como strings JSON-encoded dentro del mismo form-data.

```python
import resend

resend.api_key = "re_xxxxxxxxx"

with open("contacts.csv", "rb") as f:
    resend.Contacts.Imports.create({
        "file": f.read(),
        "column_map": {"email": "Email", "first_name": "First Name"},
        "on_conflict": "upsert",
        "segments": [{"id": "78e7a5c6-9a91-4c63-9d1f-3b9c0b5b9ab6"}],
    })
```

`on_conflict` es `upsert` (default) o `skip`. El estado se consulta con `GET /contacts/imports/:id`, que devuelve `status` y `counts: {total, created, updated, skipped, failed}`; `GET /contacts/imports` lista con `limit` (default 10, máximo 100) y filtro `status`.

**El import por CSV NO dispara el evento de webhook `contact.created`** (ver `webhooks-and-inbound.md`) — si necesitas reaccionar a contactos importados, procesa el resultado de `counts` o dispara tu propio Event tras el import.

### 2.3 Creación automática de Contacts

Un Contact también se crea automáticamente, sin llamada explícita a `POST /contacts`, en dos casos:

1. Un Automation se dispara con un email que aun no es Contact (seccion 8): el Contact se crea al arrancar el run.
2. `events.send` usa `email` en vez de `contact_id` (seccion 9) y ese email no existe todavía como Contact.

---

## 3. Contact properties

Una `ContactProperty` define un campo custom tipado que después se rellena por Contact (vía `properties` en create/update de un Contact, o vía `column_map.properties` en un import CSV).

```typescript
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

const { data } = await resend.contactProperties.create({
  key: "plan_tier",
  type: "string",
  fallbackValue: "free",
});
```

```python
resend.ContactProperties.create({
    "key": "plan_tier",
    "type": "string",
    "fallback_value": "free",
})
```

| Campo | Regla |
|---|---|
| `key` | Máximo 50 caracteres, solo alfanumérico y guion bajo; **case-sensitive** (`plan_tier` distinto de `Plan_Tier`) |
| `type` | `string` o `number`; **inmutable tras crear** |
| `fallback_value` | Debe coincidir con `type`; único campo editable vía `PATCH /contact-properties/:id` |

`GET /contact-properties/:id`, `GET /contact-properties` (list) y `DELETE /contact-properties/:id` completan el CRUD. Comportamiento al usar `properties` en un Contact: si la key no existe como ContactProperty, **la llamada completa falla** (no ignora el campo desconocido, no crea la property sobre la marcha); si el valor no coincide con el `type` declarado, también falla.

Para cambiar el `type` de una property ya en uso, hay que borrarla y recrearla — la doc oficial no especifica que ocurre con los valores ya asignados a Contacts existentes al hacerlo (tratar como perdida de datos hasta comprobar en un entorno de prueba).

---

## 4. Segments

```typescript
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

const { data } = await resend.segments.create({ name: "Registered Users" });

await resend.segments.update(data!.id, { name: "Active Users" });

const contacts = await resend.contacts.list({ segmentId: data!.id });
// equivalente a GET /segments/:id/contacts
```

```python
import resend

resend.api_key = "re_xxxxxxxxx"

segment = resend.Segments.create({"name": "Registered Users"})
resend.Segments.update(segment["id"], {"name": "Active Users"})
resend.Segments.remove(id=segment["id"])
```

CRUD completo: `POST /segments` (solo `name`), `GET /segments/:id`, `GET /segments` (list), `PATCH /segments/:id` (rename), `DELETE /segments/:id`. `GET /segments/:id/contacts` es un atajo de `GET /contacts?segment_id=...`. Los Segments no son visibles al Contact bajo ninguna circunstancia — son puramente organizativos.

### 4.1 Segment metrics — beta privada

`GET /segments/metrics` (conteo de `all_contacts`, `subscribers`, `unsubscribers` por Segment) esta en **beta privada**: hay que pedir acceso a Resend y actualizar a una versión SDK **preview** (`resend@6.19.0-preview-headless-dashboard.7` a la fecha de esta referencia). `totals` cuenta cada Contact una vez; `data` (desglose por segmento) cuenta un Contact en cada Segment al que pertenece. Cache de hasta 15 minutos. No usar como solucion por defecto sin confirmar acceso — el shape de la respuesta puede cambiar antes de la disponibilidad general.

---

## 5. Topics

Los Topics («Unsubscribe Topics») se lanzaron el 6 de noviembre de 2025 (verificado 2026-09-04).

```typescript
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

const { data } = await resend.topics.create({
  name: "Weekly Newsletter",
  defaultSubscription: "opt_in",
  description: "Actualizaciones semanales del producto",
  visibility: "public",
});
```

```python
import resend

resend.api_key = "re_xxxxxxxxx"

resend.Topics.create({
    "name": "Weekly Newsletter",
    "default_subscription": "opt_in",
    "description": "Actualizaciones semanales del producto",
})
```

| Campo | Límite / regla |
|---|---|
| `name` | Máximo 50 caracteres |
| `description` | Máximo 200 caracteres |
| `default_subscription` | `opt_in` o `opt_out`, **inmutable tras crear** |
| `visibility` | `public` o `private` (default `private`) |

Semántica de `default_subscription`: `opt_in` significa que TODOS los Contacts reciben ese Topic salvo que se den de baja explicitamente de el (retroactivo a Contacts ya existentes en el momento de crear el Topic); `opt_out` significa que NADIE recibe ese Topic salvo suscripción explícita. `visibility: private` solo lo ven en la página de preferencias los Contacts que ya están opt-in; `public` lo ven todos.

`PATCH /topics/:id` solo permite cambiar `name`, `description` y `visibility` — nunca `default_subscription`. Si el valor inicial fue el equivocado, la única salida es borrar el Topic y crear uno nuevo.

### 5.1 Envío transaccional y Topics: que aplica y que no

`segment_id` es exclusivo de **Broadcasts** (`POST /broadcasts`). `topic_id`, en cambio, existe en **ambas** superficies: en Broadcasts (obligatorio para que la baja sea por Topic y no global) y como parámetro **opcional de `POST /emails`** (verificado en la referencia oficial de Send Email el 2026-09-04), para que un envío transaccional respete las preferencias por Topic del destinatario:

- Broadcast: si el Contact está `opt_in` en el Topic (o el Topic es `opt_out` y el Contact se suscribió explícitamente), recibe el envío; si está `opt_out` de ESE Topic, no recibe ese Broadcast pero sí los de otros Topics o sin Topic.
- Si `unsubscribed = true` a nivel Contact (interruptor global), no recibe absolutamente ningún Broadcast, sin importar sus suscripciones por Topic.
- `POST /emails` **con** `topic_id`: Contact con opt-in → se envía; Contact con opt-out → **no se envía y queda `failed`**; no-Contact → se envía solo si el Topic tiene `default_subscription = opt_in`. Cada dirección (`to`/`cc`/`bcc`) se evalúa por separado.
- `POST /emails` **sin** `topic_id`: se entrega siempre, independientemente de `unsubscribed` o de cualquier Topic — la supresión por preferencias solo actúa cuando el envío declara un Topic.

---

## 6. Broadcasts

Un Broadcast es el envío masivo, creado por el editor no-code del Dashboard o por API. Requiere dominio verificado y se dirige siempre a un `segment_id`.

```text
  create ──► draft ──send:true+scheduled_at──► scheduled ──llega la hora──► queued ──► sent
               │                                    │ /cancel: scheduled->draft   │
               │ send:true sin fecha                │ (nada se envio, reprogramable)
               └──────────────► queued ◄────────────┘
                                   │ /cancel: queued->canceled (detiene la cola,
                                   │  lo ya entregado NO se recupera)
                                   v
                               canceled
  (una vez "sent" solo se edita "name"; borrable solo en draft/scheduled)
```

### 6.1 Crear, enviar, programar

```typescript
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

// crear un borrador con Topic asignado (checklist 6.6)
const { data } = await resend.broadcasts.create({
  segmentId: "78261eea-8f8b-4381-83c6-79fa7120f1cf",
  from: process.env.EMAIL_FROM_ADDRESS as string,
  subject: "Novedades de esta semana",
  topicId: "b6d24b8e-af0b-4c3c-be0c-359bbd97381e",
  html:
    "Hola {{{contact.first_name|ahi}}}, puedes darte de baja aqui: {{{RESEND_UNSUBSCRIBE_URL}}}",
});

// enviar un broadcast que ya existia en draft (solo si se creo por API)
await resend.broadcasts.send(data!.id, { scheduledAt: "in 1 hour" });
// Cancelar mientras siga en `scheduled` o `queued` (SDK >= 6.19):
await resend.broadcasts.cancel(data!.id);
```

```python
import os
import resend

resend.api_key = os.environ["RESEND_API_KEY"]

resend.Broadcasts.create({
    "segment_id": "78261eea-8f8b-4381-83c6-79fa7120f1cf",
    "from": os.environ["EMAIL_FROM_ADDRESS"],
    "subject": "Novedades de esta semana",
    "html": "Hola {{{contact.first_name|ahi}}}, puedes darte de baja aqui: {{{RESEND_UNSUBSCRIBE_URL}}}",
    "send": True,
    "scheduled_at": "in 1 hour",
})
```

### 6.2 Reglas de envío y cancelación

- `POST /broadcasts/:id/send` solo funciona sobre Broadcasts **creados por API**; los creados en el editor no-code del Dashboard no se pueden mandar por esta ruta.
- `POST /broadcasts/:id/cancel` solo actua sobre `queued` o `scheduled`. Transiciones: `scheduled -> draft` (nada se envío, se puede reprogramar) o `queued -> canceled` (lo ya entregado sigue entregado; solo se detiene el resto de la cola).
- `DELETE /broadcasts/:id` solo borra en `draft` o `scheduled`. Un Broadcast `sent` o `queued` no tiene endpoint de borrado.
- Una vez `sent`, `PATCH /broadcasts/:id` solo permite actualizar `name` (referencia interna); todo lo demas queda congelado.

### 6.3 Placeholders de personalizacion

| Placeholder | Uso |
|---|---|
| `{{{contact.first_name\|fallback}}}` | Nombre con valor de respaldo si esta vacio |
| `{{{contact.last_name\|fallback}}}` | Apellido con valor de respaldo |
| `{{{contact.email}}}` | Email del destinatario |
| `{{{RESEND_UNSUBSCRIBE_URL}}}` | Enlace de baja único por destinatario y por Broadcast (obligatorio incluir uno) |

### 6.4 Consultar destinatarios y clicks

`GET /broadcasts/:id/recipients` filtra por `type` (`sent`, `delivered`, `opened`, `clicked`, `bounced`, `complained`, `unsubscribed`, `suppressed`), con `limit` (1-100, default 20), paginacion cursor `after`/`before`, filtro `email` por substring y `bounce_type` (`permanent`, `transient`, `undetermined`, solo junto a `type=bounced`). `GET /broadcasts/:id/clicked-links` ordena por clicks descendente con `clicks` (total) y `unique_clicks` (destinatarios distintos). **Ambos endpoints cachean su respuesta hasta 15 minutos.**

### 6.5 Cuota de contactos y envío

Se pueden seguir agregando Contacts por encima del límite del plan, pero **no se pueden enviar Broadcasts** hasta hacer upgrade: la llamada de envío devuelve `403` `validation_error` con el mensaje "You have reached your contacts quota. Please upgrade your plan to send more emails." (verificar cifras exactas de cuota en `resend.com/pricing`).

### 6.6 Checklist antes de mandar un Broadcast

- [ ] `topic_id` asignado — si se omite, cualquier baja de ese envío será global.
- [ ] `segment_id` apunta a un Segment con contactos reales (no vacio).
- [ ] Se corrio "Send test" desde el editor (no incluye `reply_to` custom en modo test).
- [ ] Se paso el "Review" del editor (detecta errores comunes antes de enviar).
- [ ] El HTML incluye `{{{RESEND_UNSUBSCRIBE_URL}}}` visible.
- [ ] Cuota de contactos del plan verificada (evitar el `403` de la seccion 6.5).

---

## 7. Templates

Un Template es un recurso reutilizable (HTML, texto o React — React solo en el SDK de Node.js), con hasta 50 variables tipadas (verificado 2026-09-04) y un ciclo de vida draft/publish independiente de los Broadcasts o los emails transaccionales que lo usan.

```text
  create (status=draft) ──autoguardado──► draft ──POST .../publish──► published
       ^                                                                  │
       └──── revert de una version (crea un NUEVO draft) ─────────────────┤
                                                                           v
                                          emails.send({ template: { id, variables } })
                                          o broadcasts.create({ ... })  (siempre la
                                          version PUBLISHED, nunca el draft en curso)
```

### 7.1 Crear y publicar

```typescript
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

// crear y publicar encadenado
await resend.templates
  .create({
    name: "order-confirmation",
    alias: "order-confirmation",
    html: "<p>Producto: {{{PRODUCT}}}</p><p>Total: {{{PRICE}}}</p>",
    variables: [
      { key: "PRODUCT", type: "string", fallbackValue: "articulo" },
      { key: "PRICE", type: "number", fallbackValue: 0 },
    ],
  })
  .publish();

// usar el template al enviar (mutuamente excluyente con html/text/react)
await resend.emails.send({
  from: process.env.EMAIL_FROM_ADDRESS as string,
  to: ["delivered@resend.dev"],
  template: {
    id: "f3b9756c-f4f4-44da-bc00-9f7903c8a83f",
    variables: { PRODUCT: "Laptop", PRICE: 899 },
  },
});
```

```python
import os
import resend

resend.api_key = os.environ["RESEND_API_KEY"]

template = resend.Templates.create({
    "name": "order-confirmation",
    "html": "<p>Producto: {{{PRODUCT}}}</p><p>Total: {{{PRICE}}}</p>",
    "variables": [
        {"key": "PRODUCT", "type": "string", "fallback_value": "articulo"},
        {"key": "PRICE", "type": "number", "fallback_value": 0},
    ],
})
resend.Templates.publish(template["id"])
resend.Templates.duplicate(template["id"])  # p. ej. "Clone as Template" desde codigo
```

CRUD completo: `GET /templates/:id_or_alias`, `GET /templates` (list), `PATCH /templates/:id_or_alias`, `DELETE /templates/:id_or_alias`, `POST /templates/:id_or_alias/publish`, `POST /templates/:id_or_alias/duplicate` (también útil para clonar "Clone as Template" desde un Broadcast ya enviado). Un Template debe estar **publicado** antes de poder usarse en un envío; editar un Template publicado no afecta los envíos en curso — siguen usando la versión publicada hasta la próxima publicacion. El historial de versiones permite revertir: revertir crea un nuevo *draft* basado en la versión elegida, sin tocar la versión publicada.

### 7.2 Nombres de variable reservados (discrepancia entre dos páginas oficiales)

| Fuente | Nombres reservados literales |
|---|---|
| API (`create-template`, `update-template`) | `FIRST_NAME`, `LAST_NAME`, `EMAIL`, `RESEND_UNSUBSCRIBE_URL`, `contact`, `this` |
| Dashboard (`template-variables`) | `FIRST_NAME`, `LAST_NAME`, `EMAIL`, `UNSUBSCRIBE_URL`, `contact`, `this` |

Ambas páginas son oficiales y están vigentes a la fecha de verificación. **Tratar ambos nombres, `RESEND_UNSUBSCRIBE_URL` y `UNSUBSCRIBE_URL`, como reservados** (no usarlos como `key` de una variable custom) y usar `{{{RESEND_UNSUBSCRIBE_URL}}}` como placeholder de baja en el HTML — es el que aparece en los ejemplos reales de la API para Broadcasts y Automations.

### 7.3 Reglas de uso al enviar

- `template: { id, variables }` es **mutuamente excluyente** con `html`, `text` y `react` en el mismo payload — combinarlos produce un error de validación.
- `from`, `subject` y `reply_to` del payload de envío **tienen precedencia** sobre los valores por defecto del Template.
- Si una variable no tiene `fallback_value` y no se provee su valor al enviar, **el email no se envia** (error de validación, no un hueco vacio en el HTML).
- Ambos endpoints, `/emails` y `/emails/batch`, aceptan `template`.
- Formas de crear un Template: editor no-code del Dashboard, API, subir un archivo HTML, pegar código React Email (solo imports de componentes oficiales, sin imports locales ni de terceros) o clonar un Broadcast enviado.

### 7.4 Bug conocido con variables en `href` (verificar vigencia)

Se reporto que enviar un Template vía `template: { id, variables }` por la ruta REST puede **romper el atributo `href`** de un `<a>` cuando una variable resuelve una URL: el enlace queda como texto plano y el boton corrupto. El bug **no** ocurre con "Send test" desde el Dashboard, solo por la API REST directa; se reporto en abril de 2026 y el issue se cerro semanas después, pero no se confirmo si el cierre fue una corrección o un "wontfix" documentado. Mientras no se confirme el estado exacto contra la versión actual, el workaround seguro es **construir el `href` del boton sin variables de Template** (URL fija o resuelta en tu propio backend antes de renderizar el HTML).

---

## 8. Automations

Lanzadas el 13 de abril de 2026: una Automation es un grafo de `steps` conectados por `connections`, disparado por un Event custom. Soporte simultaneo desde el lanzamiento en Dashboard, API, SDKs y CLI.

```text
   trigger: user.created
          │
          v
   condition: event.plan eq "pro"
          │
   ┌──────┴───────┐
   │ condition_met │ condition_not_met
   v               v
 send_email     delay: 3 days
 (plan pro)          │
                     v
                send_email
                (plan free)
```

### 8.1 Tipos de step

| `type` | `config` | Notas |
|---|---|---|
| `trigger` | `{ event_name }` (Node.js: `eventName`) | No puede empezar con el prefijo `resend:`, reservado a eventos de sistema |
| `send_email` | `{ template: { id, variables }, from, subject, reply_to }` | Solo Templates **publicados**; NO agrega baja automática, el placeholder debe ir en el propio Template |
| `delay` | `{ duration }` en lenguaje natural (`"1 hour"`, `"3 days"`) | Máximo **30 días** |
| `wait_for_event` | `{ event_name, timeout, filter_rule? }` | Timeout máximo **30 días**; produce conexión `event_received` o `timeout` |
| `condition` | `{ type: "rule" \| "and" \| "or", ... }` | Ver operadores en 8.2 |
| `contact_update` | `{ first_name, last_name, unsubscribed, properties }` | Cada valor puede ser literal o una referencia dinámica |
| `contact_delete` | `{}` (sin campos) | Borra el Contact de forma permanente; los steps restantes del run se saltan |
| `add_to_segment` | `{ segment_id }` | Agrega el Contact del run a ese Segment |

Referencias dinamicas de valor en `send_email`, `contact_update` y `condition`: `{ var: "event.<campo>" }`, `{ var: "contact.<campo>" }` (incluye `contact.properties.<key>`) o `{ var: "wait_events.<event_name>.<campo>" }` (dato capturado por un `wait_for_event` anterior; si hay dos `wait_for_event` con la misma clave en la misma rama, se usa el dato del **último** evento recibido antes del step actual).

### 8.2 Condition: operadores

`type: "rule"` usa `field` (prefijo obligatorio `event.` o `contact.`), `operator` y `value`; `type: "and"` / `"or"` anida un array `rules[]`. Los **11 operadores** disponibles: `eq`, `neq`, `gt`, `gte`, `lt`, `lte`, `contains`, `starts_with`, `ends_with`, `exists`, `is_empty` (los dos últimos no llevan `value`).

### 8.3 Tipos de connection

`{ from, to, type }` con `type`: `default` (la mayoria de casos), `condition_met` / `condition_not_met` (desde un step `condition`), `event_received` / `timeout` (desde un `wait_for_event`).

### 8.4 Snippet completo: trigger, condition, send_email y delay

```typescript
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

await resend.automations.create({
  name: "Bienvenida por plan",
  status: "disabled",
  steps: [
    { key: "start", type: "trigger", config: { eventName: "user.created" } },
    { key: "check_plan", type: "condition", config: { type: "rule", field: "event.plan", operator: "eq", value: "pro" } },
    { key: "send_pro_email", type: "send_email", config: { template: { id: "pro-welcome-template-id", variables: { name: { var: "event.firstName" } } } } },
    { key: "wait_before_free", type: "delay", config: { duration: "3 days" } },
    { key: "send_free_email", type: "send_email", config: { template: { id: "free-welcome-template-id" } } },
  ],
  connections: [
    { from: "start", to: "check_plan", type: "default" },
    { from: "check_plan", to: "send_pro_email", type: "condition_met" },
    { from: "check_plan", to: "wait_before_free", type: "condition_not_met" },
    { from: "wait_before_free", to: "send_free_email", type: "default" },
  ],
});

// disparar el run
await resend.events.send({ event: "user.created", email: "usuario@tu-dominio.com", payload: { plan: "pro" } });
```

```python
import os
import resend

resend.api_key = os.environ["RESEND_API_KEY"]

# mismo grafo que arriba: en Python/REST los campos de "config" van en snake_case
# ("event_name" en vez de "eventName") — el resto de la forma es identica
resend.Automations.create({
    "name": "Bienvenida por plan",
    "status": "disabled",
    "steps": [
        {"key": "start", "type": "trigger", "config": {"event_name": "user.created"}},
        # ... el resto de steps y connections es idéntico al ejemplo TypeScript, con las claves en snake_case
    ],
    "connections": [{"from": "start", "to": "check_plan", "type": "default"}],  # etc.
})
```

### 8.5 Ciclo de vida, runs y límites

Mientras una Automation esta `enabled`, sus `steps`/`connections` **no se pueden editar** — hay que duplicarla (`POST /automations/:id/duplicate`), editar la copia y conmutar (`stop` en la original, `enabled` en la copia); las runs ya en vuelo terminan con la versión con la que empezaron. El skill oficial `resend/resend-skills` cita un máximo de **150 steps** por grafo; la cifra no aparece en `resend.com/docs` (verificar antes de diseñar grafos grandes).

Estados de un `run` (`GET /automations/:id/runs`, filtro por lista separada por comas): `running`, `completed`, `failed`, `cancelled`, y **`skipped`** — un step se salta si el Contact se dio de baja (los `send_email` restantes se saltan automáticamente; `delay`, `condition` y `contact_update` siguen ejecutandose con normalidad) o si el run siguio otra rama del grafo. `GET /automations/:id/runs/:run_id` devuelve, por step, `key`, `type`, `status`, `started_at`, `completed_at`, `output` y `error`.

Todos los planes, **incluido Free, incluyen 10.000 Automation Runs por mes** (verificado 2026-09-04 en `resend.com/pricing`). En los planes de pago el exceso se factura a **USD 0,0015 por run**; en Free no hay overage: al agotar los 10.000 runs, las automations se detienen hasta el siguiente ciclo. Cifras de precio: re-verificar vigencia antes de presupuestar.

---

## 9. Events

Un Event es el disparador custom de una Automation: se define una vez (`events.create`) y se envia cuantas veces haga falta (`events.send`).

```typescript
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

// definir el evento con un schema opcional (validado al enviar)
await resend.events.create({
  name: "user.created",
  schema: { plan: "string", trial: "boolean" },
});

// disparar por contact_id o por email (exactamente uno de los dos)
await resend.events.send({
  event: "user.created",
  email: "usuario@tu-dominio.com",
  payload: { plan: "pro", trial: false },
});
```

```python
import os
import resend

resend.api_key = os.environ["RESEND_API_KEY"]

resend.Events.create({
    "name": "user.created",
    "schema": {"plan": "string", "trial": "boolean"},
})

resend.Events.send({
    "event": "user.created",
    "email": "usuario@tu-dominio.com",
    "payload": {"plan": "pro", "trial": False},
})
```

```bash
curl -X POST 'https://api.resend.com/events/send' \
  -H 'Authorization: Bearer re_xxxxxxxxx' -H 'Content-Type: application/json' \
  -d '{"event":"user.created","email":"usuario@tu-dominio.com","payload":{"plan":"pro"}}'
```

`name` es libre (se recomienda notacion de puntos, ej. `user.created`), pero **no puede empezar con el prefijo `resend:`**, reservado a eventos de sistema. El `schema` es opcional: un objeto plano `{campo: tipo}` con cuatro tipos soportados (`string`, `number`, `boolean`, `date`). Si esta definido, el payload se valida al enviar — un campo que no matchee el tipo se rechaza con **`422`** y el evento **no se entrega**.

`events.send` acepta exactamente uno de `contact_id` o `email`; si se usa `email` y el Contact no existe, **se crea automáticamente** al arrancar el run. Devuelve **`202 Accepted`** (aceptado para procesar, no confirmación síncrona de ejecucion). Si **varios Automations habilitados** escuchan el mismo nombre de evento, **todos se disparan** — usar nombres únicos si el objetivo es apuntar a una sola Automation. CRUD restante: `GET /events/:id_or_name`, `GET /events` (list), `PATCH /events/:id_or_name` (actualiza o limpia el `schema`; `null` lo borra), `DELETE /events/:id_or_name`.

---

## 10. OAuth para apps de terceros

OAuth permite que una aplicacion de terceros envie o gestione recursos en nombre de un usuario de Resend sin compartir su API key. Implementa **OAuth 2.0 y 2.1**, con **PKCE obligatorio** en todo intercambio de authorization code, sin excepción.

### 10.1 Obtener un `client_id`

| Método | Descripción | Cuando usarlo |
|---|---|---|
| Pre-registro manual | Resend registra la app a mano; puede emitir `client_secret` si hay backend | Integraciones oficiales/partners |
| **CIMD** (Client ID Metadata Document) | El `client_id` ES la URL HTTPS de un JSON que la propia app hospeda; Resend lo consulta en cada `/oauth/authorize` | **Recomendado** — identidad estable, el consent screen muestra el host verificado |
| DCR (Dynamic Client Registration) | `POST /oauth/register`, sin autenticación previa | Apps con muchas instalaciones automatizadas que no pueden pre-registrar; limitado a **20 registros/hora/IP** (429 si se excede) |

Reglas del documento CIMD: accesible por HTTPS sin redirects, **máximo 5 KB**, **timeout de 5 segundos**; `cache-control: max-age` se respeta con un clamp entre 5 minutos y 24 horas (incluso con `no-store` hay un piso de 5 minutos); solo `/oauth/authorize` hace fetch del documento (token/refresh/revoke usan la copia ya cacheada); si el fetch falla o el documento no valida, la respuesta es `invalid_client` **sin fallback** a una copia vieja; la URL se compara carácter por carácter y debe ser permanente — moverla equivale a "cliente distinto" y obliga a que todos los usuarios re-autoricen.

### 10.2 Scopes, clientes publicos y confidenciales

Solo existen **dos scopes**: `emails:send` (rutas de envío: `POST /emails`, `POST /email`, `POST /emails/sending`, `POST /email/sending`, `POST /broadcasts/:id/send`) y `full_access` (todo lo demas; también satisface cualquier chequeo de `emails:send`). Si se omite `scope` al registrar o autorizar, el cliente recibe **ambos por defecto** — se recomienda pasarlo siempre explícito.

Clientes **publicos** (`token_endpoint_auth_method: "none"`, default): solo PKCE, para apps nativas, CLIs, SPAs o CIMD (un cliente CIMD es siempre público, su documento es legible por cualquiera). Clientes **confidenciales** (`client_secret_basic` o `client_secret_post`): reciben un `client_secret` que se muestra **una única vez** y no se puede recuperar — si se pierde, hay que registrar un cliente nuevo. Solo apropiado con backend que pueda proteger el secreto.

### 10.3 Redirect URIs permitidas y prohibidas

| Regla | Detalle |
|---|---|
| `https://` | Permitido sin restriccion |
| `http://` | Solo loopback: `127.0.0.1`, `localhost`, `[::1]` |
| Esquemas de uso privado | Permitidos (`cursor://`, `vscode://` y equivalentes) |
| Prohibidos | `file`, `ftp`, `data`, `javascript`, `blob`, `about`, `vbscript` |
| Fragmentos | Ninguna redirect URI puede llevar `#fragment` |
| Cantidad y longitud | Máximo **10** redirect URIs, cada una hasta **2048** caracteres |

### 10.4 Flujo de autorizacion y tokens

`GET /oauth/authorize` es un redirect de navegador (no una llamada JSON): `client_id`, `response_type=code`, `redirect_uri`, `scope`, `state` (recomendado, máximo 1024 caracteres), `code_challenge`, `code_challenge_method=S256` (único método soportado; `plain` no existe). El parámetro `resource` de RFC 8707 se acepta pero **se ignora**.

`POST /oauth/token` soporta dos `grant_type`: `authorization_code` (con `code`, `redirect_uri`, `code_verifier`) y `refresh_token` (con `refresh_token`, `scope` opcional que solo puede **reducir**, nunca escalar). Acepta JSON y `application/x-www-form-urlencoded`.

| Elemento | Vigencia |
|---|---|
| `code` de autorizacion | Un solo uso, expira a los **10 minutos** |
| Access token | JWT firmado **ES256**, válido **900 segundos** (verificado 2026-09-04) |
| Refresh token | String opaco, válido **60 días** (verificado 2026-09-04) desde la última emisión, **rota en cada uso** (reutilizar uno ya rotado revoca todo el grant — detección de reuso) |

`POST /oauth/revoke` revoca el refresh token completo (y con el, todos los access/refresh tokens de ese grant); no se pueden revocar access tokens individuales; **siempre devuelve `200` con cuerpo vacio** (RFC 7009). `GET /oauth/grants` lista grants (incluye revocados con `revoked_at`/`revoked_reason`); `DELETE /oauth/grants/:id` revoca cualquier grant del team; `404` si no existe o ya esta revocado.

### 10.5 Flujo completo con PKCE en Node.js

```javascript
import { createHash, randomBytes } from "node:crypto";

const RESEND_OAUTH_BASE = "https://api.resend.com/oauth";
const base64url = (buf) => buf.toString("base64url");

function buildAuthorizationRequest({ clientId, redirectUri, scope }) {
  const codeVerifier = base64url(randomBytes(64)); // 43-128 chars, guardar en sesion
  const codeChallenge = base64url(createHash("sha256").update(codeVerifier).digest());
  const state = base64url(randomBytes(24));

  const url = new URL(`${RESEND_OAUTH_BASE}/authorize`);
  url.searchParams.set("client_id", clientId);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("scope", scope); // "emails:send" o "full_access", nunca omitir
  url.searchParams.set("state", state);
  url.searchParams.set("code_challenge", codeChallenge);
  url.searchParams.set("code_challenge_method", "S256");

  // persistir codeVerifier + state junto al usuario (sesion/cookie firmada)
  // antes de redirigir al navegador a url.toString()
  return { authorizationUrl: url.toString(), codeVerifier, state };
}

// cliente confidencial: HTTP Basic con client_id:client_secret. Publico: sin secret, solo PKCE.
function authHeaders({ clientId, clientSecret, body }) {
  const headers = { "Content-Type": "application/x-www-form-urlencoded" };
  if (clientSecret) headers.Authorization = `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString("base64")}`;
  else body.set("client_id", clientId);
  return headers;
}

async function exchangeCodeForTokens({ code, redirectUri, codeVerifier, clientId, clientSecret }) {
  const body = new URLSearchParams({ grant_type: "authorization_code", code, redirect_uri: redirectUri, code_verifier: codeVerifier });
  const headers = authHeaders({ clientId, clientSecret, body });
  const response = await fetch(`${RESEND_OAUTH_BASE}/token`, { method: "POST", headers, body });
  if (!response.ok) throw new Error(`token exchange failed: ${response.status} ${await response.text()}`);
  return response.json(); // { access_token, refresh_token, expires_in, token_type, scope }
}

async function refreshAccessToken({ refreshToken, clientId, clientSecret }) {
  const body = new URLSearchParams({ grant_type: "refresh_token", refresh_token: refreshToken });
  const headers = authHeaders({ clientId, clientSecret, body });
  const response = await fetch(`${RESEND_OAUTH_BASE}/token`, { method: "POST", headers, body });
  if (!response.ok) throw new Error(`token refresh failed: ${response.status} ${await response.text()}`); // un 4xx/5xx NO trae tokens
  return response.json(); // el refresh_token devuelto es NUEVO: descartar el anterior tras usarlo
}
```

```bash
# Registro dinamico (DCR) — 20/hora/IP, preferir CIMD si tu app tiene muchas instalaciones
curl -X POST 'https://api.resend.com/oauth/register' -H 'Content-Type: application/json' \
  -d '{"redirect_uris":["https://tu-app.com/oauth/callback"],"token_endpoint_auth_method":"none"}'

# Intercambio de code por tokens (cliente confidencial, HTTP Basic) y revocacion del grant
curl -X POST 'https://api.resend.com/oauth/token' -u 'CLIENT_ID:CLIENT_SECRET' \
  -d 'grant_type=authorization_code&code=CODE&redirect_uri=https://tu-app.com/oauth/callback&code_verifier=CODE_VERIFIER'
curl -X POST 'https://api.resend.com/oauth/revoke' -u 'CLIENT_ID:CLIENT_SECRET' -d 'token=REFRESH_TOKEN'
```

### 10.6 Vercel Marketplace

Resend se integra directamente en Vercel Marketplace: `vc i resend -m domain=tu-dominio.com -m region=eu-west-1` (`vc i` es el alias de `vc integration add`) (regiones: `us-east-1` default, `eu-west-1`, `sa-east-1`, `ap-northeast-1`). La facturacion la gestiona Vercel; descuentos, promo codes y creditos de Resend **no aplican** a planes contratados vía Marketplace (verificar el comando exacto vigente en la doc del integrador antes de instruir a un usuario).

---

## 11. Errores comunes y referencias cruzadas

| # | Error | Síntoma | Corrección |
|---|---|---|---|
| 1 | Enviar por API un Broadcast creado en el editor del Dashboard | `POST /broadcasts/:id/send` falla o no aplica | Crea el Broadcast por API si necesitas dispararlo por `/send`, o usa `send: true` en el `create` |
| 2 | Suponer que cancelar un Broadcast `queued` recupera lo ya entregado | Los destinatarios que ya recibieron el email lo mantienen | `cancel` solo detiene el resto de la cola; no hay "recall" de emails ya enviados |
| 3 | Confundir `RESEND_UNSUBSCRIBE_URL` con `UNSUBSCRIBE_URL` como nombre de variable custom | La variable no se resuelve o la creación del Template falla | Tratar ambos nombres como reservados; usar `{{{RESEND_UNSUBSCRIBE_URL}}}` en el HTML |
| 4 | Poner una variable de Template dentro de un `href` enviando por REST | El link llega roto o como texto plano | Construir el `href` del boton sin variables de Template hasta confirmar que el bug esta corregido |
| 5 | Combinar `template` con `html`, `text` o `react` en el mismo envío | `validation_error` al enviar | Usar solo una de las cuatro formas de contenido por envío |
| 6 | Omitir `fallback_value` en una variable de Template y no pasar el valor al enviar | El email no se envia (no llega con un hueco vacio) | Declarar siempre `fallback_value` o garantizar el valor en el payload |
| 7 | Editar los `steps` de una Automation mientras esta `enabled` | La actualizacion es rechazada | Duplicar la Automation, editar la copia y conmutar (`stop` en la original) |
| 8 | Un step `send_email` de una Automation sin `{{{RESEND_UNSUBSCRIBE_URL}}}` en su Template | El Contact no tiene forma de darse de baja de esos emails | Incluir siempre el placeholder de baja en el HTML del Template referenciado |
| 9 | Intentar cambiar el `type` de una Contact Property ya en uso vía `PATCH` | El campo se ignora silenciosamente (`type` es inmutable) | Borrar y recrear la property; validar el impacto en Contacts existentes antes de hacerlo |
| 10 | Registrar un cliente OAuth por DCR en bucle para muchas instalaciones | `429 too_many_requests` (límite 20/hora/IP) | Usar CIMD en vez de DCR para apps con muchas instalaciones automatizadas |
| 11 | Perder el `client_secret` de un cliente OAuth confidencial | No hay endpoint de recuperacion | Registrar un cliente nuevo; tratar el secret como si fuera una API key |
| 12 | Esperar que un import CSV de Contacts dispare `contact.created` | Ninguna Automation ni webhook reacciona al import | Usar los `counts` de `GET /contacts/imports/:id`, o disparar un Event propio tras el import |
| 13 | Seguir usando `audience_id` en integraciones nuevas | Funciona, pero el código queda atado a un modelo deprecado | Migrar a `segment_id` / `topic_id`; `audience_id` solo se mantiene por compatibilidad hacia atras |

**Referencias relacionadas:**

- Envío transaccional, adjuntos, batch e idempotencia: `sending-and-errors.md`
- Firma de webhooks, eventos `email.*`/`domain.*`/`contact.*` y recepción inbound: `webhooks-and-inbound.md`
- Dominios, DNS, regiones y planes: `domains-deliverability-and-plans.md`
- Uso del SDK Node en frameworks, testing y seams de entorno: `sdk-node-nextjs-supabase-testing.md`
- CLI oficial y servidor MCP: `cli-mcp-and-agents.md`
- Patrones de adapter, outbox y webhook fail-closed en producción: `production-patterns.md`
