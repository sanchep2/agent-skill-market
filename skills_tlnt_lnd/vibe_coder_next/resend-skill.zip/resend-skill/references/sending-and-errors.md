# Envío y errores — Referencia completa

Cubre `POST /emails`, `POST /emails/batch`, el ciclo de vida de un email (programar/reprogramar/cancelar/compartir), adjuntos e imagenes inline, templates al enviar, idempotencia, la tabla completa de errores, rate limit/cuotas/overage, API keys, supresiones/rebotes, logs/métricas y direcciones de prueba. API REST de Resend (sin versión de ruta) · SDK Node `resend` 6.26.0 · SDK Python `resend` 2.43.0 · `last_verified: 2026-09-04`.

## Table of Contents

1. [Autenticación y cabeceras obligatorias](#1-autenticación-y-cabeceras-obligatorias)
2. [Envío individual: POST /emails](#2-envío-individual-post-emails)
3. [Batch de hasta 100 emails](#3-batch-de-hasta-100-emails)
4. [Programar, reprogramar, cancelar y compartir](#4-programar-reprogramar-cancelar-y-compartir)
5. [Adjuntos e imagenes inline](#5-adjuntos-e-imagenes-inline)
6. [Templates al enviar](#6-templates-al-enviar)
7. [Idempotencia](#7-idempotencia)
8. [Errores: tabla completa y clasificación por name](#8-errores-tabla-completa-y-clasificación-por-name)
9. [Rate limit, cuotas y overage](#9-rate-limit-cuotas-y-overage)
10. [API keys](#10-api-keys)
11. [Supresiones y rebotes](#11-supresiones-y-rebotes)
12. [Logs y métricas](#12-logs-y-métricas)
13. [Direcciones de prueba](#13-direcciones-de-prueba)
14. [Errores comunes y referencias cruzadas](#14-errores-comunes-y-referencias-cruzadas)

---

## 1. Autenticación y cabeceras obligatorias

La API vive en una única base URL, **sin versión en la ruta**: `https://api.resend.com`. Solo HTTPS; no existe un esquema de versionado hoy (Resend documenta que en el futuro podría añadir headers de versión por calendario, sin fecha comprometida, verificado 2026-09-04).

Dos cabeceras son obligatorias en cualquier petición HTTP directa (los SDKs oficiales ya las ponen por ti):

- `Authorization: Bearer re_xxxxxxxxx` — la API key. Sin ella: `401 missing_api_key`.
- `User-Agent: <tu-app>/<version>` — **obligatorio**. Si falta, la petición se rechaza con **403 y `error code 1010`**, incluso con una API key perfectamente valida. Es la causa más probable de un 403 "imposible" cuando la key es correcta (verificado 2026-09-04).

No hay separacion sandbox/producción: **toda cuenta, incluida Free, tiene acceso de producción desde el alta**, sin aprobacion previa. Lo que sí existe es la restriccion de dominio no verificado: sin un dominio propio verificado, `onboarding@resend.dev` como `from` **solo puede enviar a la dirección de la propia cuenta** (ver seccion 13 para las direcciones de prueba correctas).

Códigos de respuesta HTTP generales: `200` exito · `400` parámetros incorrectos · `401` API key ausente · `403` API key invalida/restringida o dominio no autorizado · `404` recurso no encontrado · `429` rate limit o cuota · `5xx` error de infraestructura de Resend.

```bash
# Peticion minima correcta: Authorization + User-Agent + Content-Type
curl -X POST 'https://api.resend.com/emails' \
  -H "Authorization: Bearer ${RESEND_API_KEY}" \
  -H 'User-Agent: mi-servicio/1.0' \
  -H 'Content-Type: application/json' \
  -d "$(cat <<EOF
{
  "from": "${EMAIL_FROM_ADDRESS}",
  "to": ["delivered@resend.dev"],
  "subject": "hello world",
  "html": "<p>it works!</p>"
}
EOF
)"
```

```typescript
import { Resend } from "resend";

// Ambos SDKs (Node y Python, seccion 2) setean User-Agent y Authorization por ti.
const resend = new Resend(process.env.RESEND_API_KEY);
```

**Gotcha de arranque**: si usas la API REST cruda (curl, `fetch`, `requests` sin el SDK) y ves un `403` con una key que juras que es correcta, revisa primero si estas mandando `User-Agent`. Es el error de arranque más común al saltarse el SDK (verificado 2026-09-04).

---

## 2. Envío individual: POST /emails

`POST https://api.resend.com/emails` es el endpoint principal de envío. La tabla siguiente recoge todos los parámetros documentados oficialmente (verificado 2026-09-04):

| Parámetro | Tipo | Notas |
|---|---|---|
| `from` | string, requerido | Formato `"Nombre <email@dominio>"` soportado. En código, siempre desde una variable de entorno — nunca literal. |
| `to` | string \| array | **Máximo 50** destinatarios. |
| `subject` | string | Asunto del email. |
| `bcc` | string \| array | Sin máximo explícito documentado (a diferencia de `to`); verificar si aplica el límite implícito de 50 total. |
| `cc` | string \| array | Sin máximo explícito documentado. |
| `reply_to` | string \| array | Uno o varios destinatarios de respuesta. |
| `html` | string | Cuerpo HTML. |
| `text` | string | Si se omite, se **autogenera desde `html`**. Para desactivar esa autogeneracion (forzar texto plano vacio o controlado a mano), pasar `text: ""` explícito. |
| `react` | componente React | **Solo disponible en el SDK Node.js.** |
| `headers` | object | Headers custom (`X-Entity-Ref-ID`, `List-Unsubscribe`, etc.). |
| `topic_id` | string (id del Topic) | Respeta las preferencias por Topic también en transaccional: si el destinatario es Contact con opt-in, se envía; si tiene opt-out, el email **no se envía y queda `failed`**; si no es Contact, se envía solo si el Topic tiene suscripción por defecto `opt-in`. Cada dirección (`to`/`cc`/`bcc`) se evalúa por separado. Detalle en `marketing-templates-automations-oauth.md` §5.1. |
| `tags` | array `{name, value}` | `name`/`value`: solo ASCII+`_`+`-`, **máximo 256 caracteres cada uno**; **hasta 75 tags por email**. Viajan en los webhooks del envío. |
| `attachments` | array | Ver seccion 5. |
| `template` | object `{id, variables}` | Ver seccion 6. Excluyente con `html`/`text`/`react`. |
| `scheduled_at` | string | Ver seccion 4. |
| Header `Idempotency-Key` | string, 1-256 chars | Ver seccion 7. |

Respuesta de exito: `{"id": "49a3999c-..."}`.

```typescript
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

const { data, error } = await resend.emails.send({
  from: process.env.EMAIL_FROM_ADDRESS!,
  to: ["delivered@resend.dev"],
  subject: "hello world",
  html: "<p>it works!</p>",
  tags: [{ name: "category", value: "confirm_email" }],
});

// El SDK Node NUNCA lanza excepcion por un error de la API: revisa `error` a mano.
if (error) {
  console.error(error.name, error.message);
} else {
  console.log(data.id);
}
```

```python
import os
import resend
from resend.exceptions import ResendError

resend.api_key = os.environ["RESEND_API_KEY"]

params: resend.Emails.SendParams = {
    "from": os.environ["EMAIL_FROM_ADDRESS"],
    "to": ["delivered@resend.dev"],
    "subject": "hello world",
    "html": "<p>it works!</p>",
}

try:
    # El SDK Python es lo OPUESTO al de Node: LANZA en vez de devolver {data, error}.
    email = resend.Emails.send(params)
    print(email)  # {"id": "49a3999c-..."}
except ResendError as error:
    print(error.error_type, error.message)
```

**Gotchas de esta seccion**:

- `to` tiene tope explícito (50); `bcc`/`cc` no lo tienen documentado — no asumas que comparten el mismo tope sin verificarlo en vivo.
- `text: ""` es distinto de omitir `text`: omitir autogenera desde `html`; `""` desactiva la autogeneracion.
- `react` solo existe en el SDK Node — en Python/Go/PHP/etc. hay que renderizar el HTML antes de llamar a `send`.

---

## 3. Batch de hasta 100 emails

`POST https://api.resend.com/emails/batch` envia un array de hasta **100** objetos con la misma forma que `POST /emails`, en una sola llamada que cuenta como **UNA sola petición** contra el rate limit (útil para reducir presión de tráfico alto — ver seccion 9).

> Más de 100 destinatarios: **parte la lista en lotes de ≤ 100** y llama a `batch.send` una vez por lote (cada lote con su propia `Idempotency-Key`, p. ej. `campaign-abc/chunk-0`), con una pausa corta entre lotes para no tocar el rate limit. No vuelvas a envíos individuales: 150 `send` son 150 peticiones contra el límite; 2 batches son 2.

Límites y comportamiento (verificado 2026-09-04):

- **Sin adjuntos**: `attachments` no esta soportado en batch, ni siquiera para imagenes inline vía `cid:` (una imagen inline es técnicamente un adjunto).
- **`scheduled_at` SI esta soportado, por email**: cada entrada del array puede llevar su propio `scheduled_at` (lenguaje natural o ISO 8601). La guia oficial de programación de envíos (`dashboard/emails/schedule-email`) muestra un ejemplo completo de `batch.send([...])` con `scheduledAt` en cada entrada — documentación vigente a la fecha de esta referencia, aunque varias guias de terceros de 2025-2026 siguen afirmando lo contrario: si construyes sobre este skill, no repitas "batch no soporta scheduling" sin volver a comprobarlo.
- **Atómico por defecto**: si una sola entrada del array es invalida, la petición completa falla — no hay respuesta parcial de exitos+fallos en la referencia REST publica. La cabecera `x-batch-validation: strict` describe este modo por defecto; existe una variante `permissive` (devuelve un array `errors[]` en vez de tumbar el batch entero) mencionada en guias de comunidad y en algunos SDK/CLI, pero **no aparece en la referencia REST oficial de este endpoint a la fecha de esta consulta** — trata `permissive` como "verificar en vivo" antes de depender de el.
- `tags` si es soportado por email dentro del batch, con las mismas reglas que en single.
- Idempotencia si soportada, pero se recomienda una key que represente el **batch completo** (p. ej. `<batch>/<id-del-lote>`), no una por email individual — ver seccion 7.
- Respuesta de exito: `{"data": [{"id": "..."}, {"id": "..."}]}`, donde **cada entrada de `data` corresponde a la posición (0-based) de la misma entrada en el payload enviado**.
- Los emails de un batch aparecen en el listado junto a los enviados individualmente, con estado inicial `queued`.

```text
                    Cuanto tengo que enviar?
                              |
              +---------------+----------------+
              |                                |
           1 email                       2-100 emails
              |                                |
              v                                v
   Necesita adjuntos o imagenes         Necesita adjuntos o
   inline (cid:)?                       imagenes inline?
        |          |                          |          |
       si          no                        si          no
        |          |                          |          |
        v          v                          v          v
   POST /emails  POST /emails         Partir en lotes    POST /emails/batch
   (unico envio,  (unico, o                 <=100 y        (1 sola peticion
    permite        agrupar en             enviar cada       contra el rate
    attachments)   batch si no             uno via           limit; SIN
                   hay adjunto)            POST /emails      adjuntos)

  scheduled_at (natural o ISO 8601, hasta 30 dias) funciona en AMBOS
  caminos, por email. Ver seccion 4 para reprogramar/cancelar.
```

| Caracteristica | `POST /emails` (single) | `POST /emails/batch` |
|---|---|---|
| Emails por llamada | 1 | 2-100 |
| Adjuntos / imagenes inline | Si | **No** |
| `scheduled_at` por entrada | Si | Si |
| Cuenta contra el rate limit | 1 petición | 1 petición (aunque lleve 100 emails) |
| Fallo de una entrada invalida | Falla solo ese envío | Falla el batch entero (modo `strict`, por defecto) |
| `template` | Si | Si |
| Idempotencia | Por email | Por batch completo (recomendado) |

```typescript
const { data, error } = await resend.batch.send(
  [
    {
      from: process.env.EMAIL_FROM_ADDRESS!,
      to: ["delivered@resend.dev"],
      subject: "hello world",
      html: "<h1>it works!</h1>",
      scheduledAt: "in 1 min",
    },
    {
      from: process.env.EMAIL_FROM_ADDRESS!,
      to: ["delivered+segundo@resend.dev"],
      subject: "world hello",
      html: "<p>it works!</p>",
      scheduledAt: "in 5 min",
    },
  ],
  { idempotencyKey: "newsletter-lote/2026-09-04" }, // representa el batch entero
);

if (error) {
  // atomico: si UNA entrada es invalida, esto trae el error de TODO el batch
  console.error(error.name, error.message);
} else {
  data.data.forEach((item, i) => console.log(`posicion ${i} -> id ${item.id}`));
}
```

```python
import os
import resend
from resend.exceptions import ResendError
from typing import List

resend.api_key = os.environ["RESEND_API_KEY"]

params: List[resend.Emails.SendParams] = [
    {
        "from": os.environ["EMAIL_FROM_ADDRESS"],
        "to": ["delivered@resend.dev"],
        "subject": "hello world",
        "html": "<h1>it works!</h1>",
    },
    {
        "from": os.environ["EMAIL_FROM_ADDRESS"],
        "to": ["delivered+segundo@resend.dev"],
        "subject": "world hello",
        "html": "<p>it works!</p>",
    },
]

try:
    result = resend.Batch.send(params)  # lanza ResendError si el batch entero es invalido
except ResendError as error:
    print(error.error_type, error.message)
```

---

## 4. Programar, reprogramar, cancelar y compartir

`scheduled_at` acepta lenguaje natural (`"in 1 min"`) o ISO 8601 (`"2026-08-05T11:52:01.858Z"`), con un horizonte máximo de **30 días**. El ciclo de vida completo de un email programado:

| Operación | Endpoint | Notas |
|---|---|---|
| Programar | `scheduled_at` dentro de `POST /emails` o `POST /emails/batch` | Ver secciones 2 y 3. |
| Reprogramar | `PATCH /emails/{id}` | **El único campo actualizable es `scheduled_at`** — no se puede editar `subject`/`html`/etc. de un email ya creado, ni siquiera en estado `scheduled`. |
| Cancelar | `POST /emails/{id}/cancel` | Solo aplica a emails en estado `scheduled`. Respuesta: `{"object": "email", "id": "..."}`. |
| Consultar | `GET /emails/{id}` | Devuelve `id`, `message_id`, `to`, `from`, `subject`, `html`, `text`, `bcc`, `cc`, `reply_to`, `last_event`, `scheduled_at`, `tags`. |
| Listar enviados | `GET /emails` (paginado) | Solo emails **enviados** por el team (no inbound). |
| Compartir | `POST /emails/{id}/share` | Body `{expires_in}` (`"10m"`, `"2 hours"`, `"1 day"`). **Default y máximo 48 horas, sin mecanismo de revocación.** Devuelve un `url` con token firmado que cualquiera puede abrir sin autenticarse mientras dure la ventana. |
| Descargar un adjunto recibido en un envío | `GET /emails/{id}/attachments/{attachmentId}` | Devuelve metadata + `download_url` firmado con `expires_at` (no un binario directo). |
| Listar adjuntos de un email | `GET /emails/{id}/attachments` | Paginado (`limit`/`after`/`before`). |

**Un email cancelado no se puede volver a programar** — hay que crear un envío nuevo.

```typescript
// Reprogramar
const { data, error } = await resend.emails.update({
  id: "49a3999c-0ce7-4531-91cb-055d1f7b9b58",
  scheduledAt: "2026-09-05T09:00:00.000Z",
});

// Cancelar
const { data: cancelData, error: cancelError } = await resend.emails.cancel(
  "49a3999c-0ce7-4531-91cb-055d1f7b9b58",
);

// Compartir por 48h (maximo permitido)
const { data: shareData, error: shareError } = await resend.emails.share(
  "49a3999c-0ce7-4531-91cb-055d1f7b9b58",
  { expiresIn: "48 hours" },
);
```

```bash
# Cancelar un email programado
curl -X POST 'https://api.resend.com/emails/49a3999c-0ce7-4531-91cb-055d1f7b9b58/cancel' \
  -H "Authorization: Bearer ${RESEND_API_KEY}" \
  -H 'User-Agent: mi-servicio/1.0'
```

---

## 5. Adjuntos e imagenes inline

Un adjunto se manda con `content` (Buffer o string Base64, para ficheros locales) o `path` (URL remota que Resend descarga por ti — preferible para ficheros grandes). Falta ambos campos: `422 invalid_attachment`.

- **Límite: 40 MB por email, medidos DESPUES de la codificacion Base64** — un binario de ~30 MB en disco puede superar el límite tras la expansion de ~33% que produce Base64. Calcula siempre contra el tamaño codificado, no el tamaño en disco (verificado 2026-09-04).
- `content_id`: string arbitrario de **menos de 128 caracteres**, usado para embeber imagenes inline vía `<img src="cid:mi-id">` en el HTML.
- **Al ENVIAR**, Resend bloquea una lista cerrada de ~90 extensiones (mayormente ejecutables/scripts). **Al RECIBIR** (inbound) no hay ninguna restriccion de tipo de archivo.

```text
.adp .app .asp .bas .bat .cer .chm .cmd .com .cpl .crt .csh .der .exe .fxp
.gadget .hlp .hta .inf .ins .isp .its .js .jse .ksh .lib .lnk .mad .maf
.mag .mam .maq .mar .mas .mat .mau .mav .maw .mda .mdb .mde .mdt .mdw
.mdz .msc .msh .msh1 .msh2 .mshxml .msh1xml .msh2xml .msi .msp .mst .ops
.pcd .pif .plg .prf .prg .reg .scf .scr .sct .shb .shs .sys .ps1 .ps1xml
.ps2 .ps2xml .psc1 .psc2 .tmp .url .vb .vbe .vbs .vps .vsmacros .vss
.vst .vsw .vxd .ws .wsc .wsf .wsh .xnk
```

```typescript
const { data, error } = await resend.emails.send({
  from: process.env.EMAIL_FROM_ADDRESS!,
  to: ["delivered@resend.dev"],
  subject: "Gracias por contactarnos",
  html: '<p>Aqui va nuestro <img src="cid:logo-inline"/> logo</p>',
  attachments: [
    {
      // adjunto remoto: Resend hace el fetch, no hace falta Base64 a mano
      path: "https://tu-dominio.com/static/logo.png",
      filename: "logo.png",
      contentId: "logo-inline", // < 128 caracteres, referenciado como cid:logo-inline
    },
  ],
});

if (error) console.error(error.name, error.message);
```

**Gotchas de esta seccion**:

- Adjuntos e imagenes inline **no funcionan en `POST /emails/batch`** (seccion 3) — si tu flujo necesita adjuntos, usa siempre single.
- Las imagenes inline aumentan el peso del email y algunos clientes de webmail las rechazan o las muestran solo bajo confirmación del usuario.
- La lista de extensiones bloqueadas aplica solo a lo que TU envias; recibir un `.exe` por inbound es perfectamente posible (tratalo como dato no confiable, nunca lo ejecutes automáticamente).

---

## 6. Templates al enviar

`template: { id, variables }` permite enviar sin construir el HTML en cada request. Reglas (verificado 2026-09-04):

- **Mutuamente excluyente** con `html`, `text` y `react` en el mismo payload — si mandas ambos, error de validación.
- **Solo plantillas publicadas** se pueden usar al enviar; `template.id` acepta el id o el **alias** de la plantilla.
- Si el payload trae `from`, `subject` o `reply_to`, **esos valores pisan** los defaults de la plantilla. Si la plantilla no tiene default para esos campos, hay que proveerlos en el payload.
- `variables`: objeto clave/valor. Nombre de variable: solo ASCII+digitos+`_`, máximo 50 caracteres. Valor string: máximo 2000 caracteres; valor number: no mayor que `2^53 - 1`.
- Si el HTML de la plantilla usa una variable que **no llega en el payload y no tiene `fallback_value`**, la llamada entera lanza `validation_error` — el email no se envia.
- **Nombres de variable reservados** (no se pueden usar como variable propia): `FIRST_NAME`, `LAST_NAME`, `EMAIL`, `UNSUBSCRIBE_URL`. La propia documentación de Resend es ambigua entre `UNSUBSCRIBE_URL` (páginas de envío/dashboard) y `RESEND_UNSUBSCRIBE_URL` (páginas de creación de plantilla; el editor de Broadcasts inserta el placeholder `{{{RESEND_UNSUBSCRIBE_URL}}}`). **Trata ambos nombres como reservados** y usa `{{{RESEND_UNSUBSCRIBE_URL}}}` como placeholder por defecto; confirma cual resuelve tu cuenta antes de depender del literal exacto — verificar en vivo.

```typescript
const { data, error } = await resend.emails.send({
  from: process.env.EMAIL_FROM_ADDRESS!,
  to: ["delivered@resend.dev"],
  template: {
    id: "bienvenida-usuario", // id o alias de una plantilla PUBLICADA
    variables: {
      FIRST_NAME: "Ana",
      CTA_LINK: "https://tu-dominio.com/siguiente-paso",
    },
  },
});

if (error) {
  // p. ej. validation_error si falta una variable usada en el HTML sin fallback
  console.error(error.name, error.message);
}
```

El ciclo completo de una plantilla (draft, publish, versionado, alias) vive en `marketing-templates-automations-oauth.md`; esta seccion cubre solo el contrato de `POST /emails` al usarla.

---

## 7. Idempotencia

Header `Idempotency-Key` (equivalente SMTP: `Resend-Idempotency-Key`). Soportado **solo** en `POST /emails` y `POST /emails/batch`.

- Longitud: **1-256 caracteres**, debe ser único por petición.
- **TTL: 24 horas** — pasado ese plazo, la misma key ya no se recuerda y una petición repetida se trata como nueva.
- Formato recomendado: `<evento>/<id-entidad>` para envíos individuales (p. ej. `welcome-user/123456789`); `<batch>/<id-del-lote>` para batch (p. ej. `team-quota/123456789`), representando el lote entero, no cada email dentro de el.
- Colisiones:
  - Misma key + mismo payload dentro de 24h -> Resend devuelve la **misma respuesta original sin reenviar** el email.
  - Misma key + payload **distinto** -> `409 invalid_idempotent_request`.
  - Misma key, petición **todavía en curso** -> `409 concurrent_idempotent_requests` (seguro reintentar más tarde).
  - Key fuera de 1-256 caracteres -> `400 invalid_idempotency_key`.

```text
              POST /emails con Idempotency-Key: K
                            |
                            v
          Existe un registro previo con K
          en las ultimas 24h?
                            |
            +---------------+----------------+
            | no                              | si
            v                                 v
       procesar el envio               el payload es
       normalmente y guardar           byte-a-byte igual
       (K, payload, respuesta)         al original?
       durante 24h                            |
                              +----------------+----------------+
                              | si                                | no
                              v                                    v
                    la peticion original              409 invalid_idempotent_request
                    sigue en curso?                   (cambia la key o el payload)
                              |
                    +----------+-----------+
                    | si                    | no
                    v                        v
        409 concurrent_idempotent_    200/201 con la MISMA
        requests (reintenta mas       respuesta original
        tarde; el resultado final     (no se reenvia el email)
        no cambia)
```

**El gotcha más repetido de la comunidad**: al menos tres quickstarts oficiales (PHP, Ruby, ejemplos antiguos) sugieren pasar `idempotencyKey` **dentro** del mismo objeto de payload. En el SDK Node, el contrato correcto es como **segundo argumento independiente** de `send()`/`batch.send()` — meterlo dentro del payload se descarta en silencio en JavaScript o no compila en TypeScript (V5, verificado contra el código fuente del SDK y la página oficial de idempotency keys, 2026-09-04).

```typescript
// INCORRECTO: dentro del payload, se descarta en silencio (o no compila en TS)
await resend.emails.send({
  from: process.env.EMAIL_FROM_ADDRESS!,
  to: ["delivered@resend.dev"],
  subject: "hello world",
  html: "<p>it works!</p>",
  // idempotencyKey: "welcome-user/123456789",  <-- NO funciona aqui
});

// CORRECTO: segundo argumento de send()
await resend.emails.send(
  {
    from: process.env.EMAIL_FROM_ADDRESS!,
    to: ["delivered@resend.dev"],
    subject: "hello world",
    html: "<p>it works!</p>",
  },
  { idempotencyKey: "welcome-user/123456789" },
);
```

```python
import os
import resend

resend.api_key = os.environ["RESEND_API_KEY"]

params: resend.Emails.SendParams = {
    "from": os.environ["EMAIL_FROM_ADDRESS"],
    "to": ["delivered@resend.dev"],
    "subject": "hello world",
    "html": "<p>it works!</p>",
}

# Python tambien recibe la idempotencia como un SEGUNDO argumento, pero como
# un dict separado con snake_case (`idempotency_key`), no camelCase como en Node.
options: resend.Emails.SendOptions = {"idempotency_key": "welcome-user/123456789"}

email = resend.Emails.send(params, options)
```

---

## 8. Errores: tabla completa y clasificación por name

La referencia oficial de errores documenta **25 combinaciones `name` + `status` + mensaje sobre 21 nombres de error distintos** (algunos `name` como `validation_error` o `restricted_api_key` aparecen más de una vez, con status y mensaje distintos según el caso — por eso algunas fuentes redondean a "24 errores"). Tabla literal (verificado 2026-09-04):

> Nota: el tipo TypeScript `RESEND_ERROR_CODE_KEY` del SDK 6.26 declara un conjunto **parcialmente distinto** (añade `invalid_api_key`, `invalid_from_address`, `invalid_access`, `invalid_region`, `security_error` e `internal_server_error`, y omite `email_above_quota`, `suspended_api_key`, `resource_locked`, `missing_required_parameter` y `service_unavailable`). Al programar un `switch (error.name)`, contempla la unión de ambos conjuntos y un `default`. La vista del SDK está en `sdk-node-nextjs-supabase-testing.md` §2.3.

| `name` | Status | Mensaje | Acción sugerida |
|---|---|---|---|
| `invalid_idempotency_key` | 400 | Idempotency keys, if present, must have between 1 and 256 characters. | Reintentar con una idempotency key valida. |
| `validation_error` | 400 | An error was found with one or more fields in the request. | El mensaje detalla el campo con el problema. |
| `missing_api_key` | 401 | Missing API key in the authorization header. | Incluir `Authorization: Bearer YOUR_API_KEY`. |
| `restricted_api_key` | 401 | This API key is restricted to only send emails. | Usar una key con `Full access` para acciones que no sean enviar. |
| `email_above_quota` | 403 | You can't retrieve this email's content because it was above quota when received. | Subir de plan para aumentar la cuota. |
| `invalid_permission` | 403 | Access token is missing required scopes. | Pedir un access token con los scopes requeridos. |
| `restricted_api_key` | 403 | API key is not active | Revisar la key en la página de API Keys; crear una nueva si hace falta. |
| `suspended_api_key` | 403 | This API key is suspended | Contactar soporte si se cree un error. |
| `validation_error` | 403 | You can only send testing emails to your own email address (...). | Verificar un dominio propio y cambiar el `from` a ese dominio. |
| `validation_error` | 403 | The `domain.com` domain is not verified. | Hacer que el `from` coincida con un dominio verificado. |
| `validation_error` | 403 | The `example.com` domain has been registered already. | Confirmar la cuenta correcta o contactar soporte. |
| `not_found` | 404 | The requested endpoint does not exist. | Corregir la URL de la petición. |
| `method_not_allowed` | 405 | Method is not allowed for the requested path. | Usar un método HTTP válido. |
| `concurrent_idempotent_requests` | 409 | There is another request in progress with the same idempotency key. | Reintentar más tarde. |
| `invalid_idempotent_request` | 409 | Idempotency key usada en las últimas 24h con un body distinto. | Cambiar la idempotency key o el payload. |
| `resource_locked` | 409 | Another request is already updating this resource. | Reintentar tras un breve delay. |
| `invalid_attachment` | 422 | Attachment must have either a `content` or `path`. | Usar `content` (string/Buffer/Stream) o `path` (URL remota). |
| `invalid_parameter` | 422 | The `parameter` must be a valid UUID. | Validar el valor enviado. |
| `missing_required_field` | 422 | The request body is missing one or more required fields. | Ver el mensaje para la lista de campos faltantes. |
| `missing_required_parameter` | 422 | The request is missing one or more required parameters. | Ver el mensaje para la lista de parámetros faltantes. |
| `daily_quota_exceeded` | 429 | You have exceeded your daily email sending quota. | Subir de plan o esperar 24h. Enviados+recibidos cuentan juntos. |
| `monthly_quota_exceeded` | 429 | You have exceeded your monthly email sending quota. | Subir de plan. Enviados+recibidos cuentan juntos. |
| `rate_limit_exceeded` | 429 | Too many requests. Please limit the number of requests per second... | Leer los headers de rate limit y reducir la tasa (ver seccion 9). |
| `application_error` | 500 | An unexpected error occurred. | Reintentar; revisar la status page si persiste. |
| `service_unavailable` | 503 | API is temporarily unavailable | Reintentar; revisar la status page. |

**Regla de oro: clasifica por `name`, nunca solo por `statusCode`.** La comunidad reporta de forma consistente (issue público del SDK Node, activo durante meses con múltiples reportes independientes) que el `statusCode` real observado no siempre coincide con esta tabla para el mismo `name` — por ejemplo `validation_error` visto indistintamente con 400, 403 y 422 según el campo que falle. El objeto de error del SDK Node tampoco tiene shape estable: a veces trae `.message`, a veces `.error` en su lugar — comprueba ambos (`error.message ?? error.error`) hasta que se resuelva.

**Contraste importante entre SDKs**: el SDK **Node nunca lanza** por errores de la API (siempre `{ data, error }`); el SDK **Python SI lanza** — `resend.Emails.send()` levanta `resend.exceptions.ResendError` (o una subclase más especifica: `ValidationError`, `RateLimitError`, `InvalidApiKeyError`, etc.) en vez de devolver un valor de error. Un `try/except` vacio en Python silencia el fallo igual que un `try/catch` vacio en Node deja pasar un `{data: null, error: {...}}` sin revisar — ambos contratos exigen manejo explícito, pero **son contratos opuestos**: no copies el patron de un lenguaje al otro sin adaptarlo.

```typescript
const { data, error } = await resend.emails.send(params);

if (error) {
  switch (error.name) {
    case "rate_limit_exceeded":
      // leer ratelimit-reset / retry-after y reintentar con backoff (seccion 9)
      break;
    case "concurrent_idempotent_requests":
      // seguro reintentar mas tarde
      break;
    case "invalid_idempotent_request":
      // inutil reintentar sin cambiar key o payload
      break;
    case "daily_quota_exceeded":
    case "monthly_quota_exceeded":
      // fatal para este envio: no reintentar, alertar/subir de plan
      break;
    default:
      // clasificar por NAME, nunca confiar ciegamente en statusCode
      console.error(error.name, error.message ?? (error as any).error);
  }
}
```

```python
from resend.exceptions import (
    ResendError,
    ValidationError,
    RateLimitError,
    InvalidApiKeyError,
)

try:
    email = resend.Emails.send(params)
except RateLimitError as error:
    ...  # backoff y reintento (seccion 9)
except ValidationError as error:
    ...  # corregir los parametros del payload
except ResendError as error:
    ...  # catch-all: error.code, error.message, error.error_type
```

---

## 9. Rate limit, cuotas y overage

**Rate limit por defecto: 10 peticiones/segundo por TEAM** (no por API key ni por dominio) — todas las keys de un mismo team comparten el mismo cupo, y es una **ventana estricta de 1 segundo sin margen de rafaga**: una undecima petición en el mismo segundo recibe `429` aunque el promedio del minuto sea bajo (verificado 2026-09-04 en `api-reference/rate-limit` y `send-with-python.md`, que coinciden en el mismo número). **Nota histórica**: varias fuentes de comunidad de 2024-2025 (y al menos un skill de terceros presentado como "oficial" que sigue circulando en 2026) citan **2 req/s** como default — no hay evidencia de que ese valor haya sido oficial en algún momento documentado; trata "2 req/s" como dato obsoleto/propagado y confia en el valor vigente verificado en la fecha de uso, no en este número fosilizado.

Headers presentes en TODA respuesta (formato IETF): `ratelimit-limit`, `ratelimit-remaining`, `ratelimit-reset` (segundos hasta el reset) y `retry-after` (segundos a esperar tras un 429). El límite es ampliable contactando soporte para "remitentes de confianza" (un caso de comunidad reporta que se lo subieron a 250 req/s bajo petición).

Cuotas de envío (independientes del rate limit):

| Plan | Cuota diaria | Cuota mensual | Notas |
|---|---|---|---|
| Free | 100/día | 3.000/mes | Enviados **y** recibidos cuentan juntos; cada destinatario en to/cc/bcc cuenta por separado. |
| Pro / Scale / Enterprise | Sin tope diario documentado | Según el tier contratado (verificar en vivo el número exacto: precios y cuotas exactas viven en `domains-deliverability-and-plans.md`) | Mismo criterio: sent+received juntos, multi-destinatario por separado. |

- **Overage en planes pagos**: pay-as-you-go por defecto, con **tope duro de 5x la cuota mensual del plan**; al llegar ahí, el envío se pausa hasta el siguiente ciclo de facturacion (ajustable contactando soporte).
- Headers de cuota en cada respuesta: `x-resend-daily-quota` (**solo se envia a cuentas Free**) y `x-resend-monthly-quota`.
- `429 daily_quota_exceeded` / `429 monthly_quota_exceeded` — ver tabla de la seccion 8.
- **Umbrales de cuenta** (Acceptable Use Policy): mantener **bounce rate < 4%** y **spam/complaint rate < 0,08%**. Superarlos puede pausar o suspender la cuenta **sin previo aviso**. Estos son umbrales propios de Resend — no los confundas con los que exigen Gmail (bulk < 0,10%) o Yahoo/Outlook (< 0,3%): son actores distintos con números distintos, no versiones del mismo dato.
- Retención de datos/logs/métricas: **30 días** en Free/Pro/Scale (Enterprise flexible por contrato). Si necesitas histórico más largo, guarda los eventos de webhook en tu propia base de datos.

`POST /emails/batch` (seccion 3) cuenta como **una sola petición** aunque lleve 100 emails — es la mitigacion recomendada oficialmente y por la comunidad frente a un rate limit ajustado.

```typescript
async function sendWithBackoff(params: Parameters<typeof resend.emails.send>[0], attempt = 0) {
  const { data, error } = await resend.emails.send(params);

  if (error?.name === "rate_limit_exceeded" && attempt < 3) {
    // honra retry-after si el cliente HTTP lo expone; si no, backoff exponencial simple
    const waitMs = 1000 * 2 ** attempt;
    await new Promise((r) => setTimeout(r, waitMs));
    return sendWithBackoff(params, attempt + 1);
  }

  if (error) throw new Error(`${error.name}: ${error.message}`);
  return data;
}
```

---

## 10. API keys

Dos niveles de permiso:

| Capacidad | `full_access` | `sending_access` |
|---|---|---|
| Enviar emails | Si | Si |
| Gestionar dominios (crear/editar/borrar) | Si | No |
| Gestionar API keys (crear/borrar) | Si | No |
| Leer/gestionar otros recursos de cuenta | Si | No |
| Restringir a un solo dominio (`domain_id`) | No aplica | Si (opcional, solo al crear) |
| Uso recomendado | Tooling admin / automatizacion | Runtime de la aplicacion |

- `POST /api-keys`: body `{name (maximo 50 caracteres), permission: "full_access"|"sending_access", domain_id}`. `domain_id` **solo aplica con `permission: "sending_access"`**; pasarlo con `full_access` no tiene efecto.
- Respuesta: `{"id": "...", "object": "api_key", "token": "re_..."}` — **el token completo solo se muestra una vez, en la respuesta de creación**. No hay endpoint para recuperarlo después; perderlo obliga a rotar.
- `PATCH /api-keys/{id}` **solo actualiza `name`** — permiso y restriccion de dominio son inmutables vía API, solo editables desde el Dashboard.
- `DELETE /api-keys/{id}` revoca la key de inmediato — no existe un "revoke" separado de "delete".
- Rotación recomendada: **cada 90 días**, o de inmediato ante sospecha de compromiso. No hay expiración automática ni rotación integrada: las keys viven hasta que se borran a mano.
- Flujo de rotación seguro: crear key nueva con el mismo scope -> desplegar en todos los servicios -> confirmar en Logs que la nueva esta activa en todas partes -> borrar la vieja **solo después**.
- Ante una fuga: borrar la key (revocación inmediata), auditar por Logs (filtrando por esa key) durante la ventana de retención de 30 días, y preferir siempre `sending_access` sobre `full_access` en runtime.
- **Desde el 16-jul-2026, Resend es partner de GitHub Secret Scanning** (verificado): una key filtrada en un repositorio público se detecta y revoca automáticamente, con notificación a los admins del team. El evento que motivo la integración fue una filtracion masiva reportada por el propio equipo de Resend (969 keys detectadas en 3 días). Esta proteccion **no sustituye** la práctica básica: nunca comitear ni publicar una API key real en código, documentación o ficheros de ejemplo — un skill o repositorio público con una key real hardcodeada es un incidente de seguridad, no un detalle menor.

```typescript
const { data, error } = await resend.apiKeys.create({
  name: "runtime-produccion",
  permission: "sending_access",
  domain_id: "d91cd9bd-1176-453e-8fc1-35364d380206",
});

if (error) console.error(error.name, error.message);
// data.token solo aparece AQUI; guardalo en tu gestor de secretos ahora mismo
```

```bash
# Solo se puede renombrar via API; permiso y dominio se cambian desde el Dashboard
curl -X PATCH 'https://api.resend.com/api-keys/71cdfe68-c294-4d33-a616-be0e6a55c0e8' \
  -H "Authorization: Bearer ${RESEND_API_KEY}" \
  -H 'User-Agent: mi-servicio/1.0' \
  -H 'Content-Type: application/json' \
  -d '{"name": "runtime-produccion-v2"}'
```

---

## 11. Supresiones y rebotes

La suppression list tiene tres origenes: `bounce` (hard-bounce automático), `complaint` (marcado como spam) y `manual` (añadido a mano). Aplica a **todo el team**: bloquea el envío a esa dirección en todos los dominios/subdominios, tanto transaccional como Broadcasts.

| Endpoint | Notas |
|---|---|
| `POST /suppressions` | Body `{email}`. |
| `GET /suppressions/{idOrEmail}` | **Busqueda dual**: acepta el ID de la supresión o la dirección de email directamente. Incluye `source_id` (el email que la disparo; `null` si `origin = manual`). |
| `GET /suppressions` | Lista paginada, filtrable por `origin`. |
| `DELETE /suppressions/{idOrEmail}` | También dual (ID o email). |
| `POST /suppressions/batch/add` | `{emails: [...]}`, **1 a 100** direcciones. |
| `POST /suppressions/batch/remove` | `{emails: [...]}` **o** `{ids: [...]}` (uno u otro, no ambos), 1-100 elementos. |

Notas de comportamiento:

- **Gmail/Google Workspace no siempre emite el evento `complained`** — no interpretes ausencia de complaints como "no hubo quejas".
- **Quitar una dirección de la lista no garantiza entrega futura**: si vuelve a rebotar o se marca como spam, se re-suprime sola y puede dañar más la reputación.
- Webhooks dedicados `suppression.added`/`suppression.removed` para sincronizar con tu propia base de datos (detalle de firma/eventos en `webhooks-and-inbound.md`).

Tipos de bounce y subtipos:

| Tipo | Subtipos | Significado |
|---|---|---|
| `Permanent` (hard) | `General`, `NoEmail` | Rechazo definitivo; candidato sólido a supresión. |
| `Transient` (soft) | `General`, `MailboxFull`, `MessageTooLarge`, `ContentRejected`, `AttachmentRejected` | Puede entregarse en el futuro (a veces refleja un autoresponder, no un fallo real). |
| `Undetermined` | — | El mensaje de bounce no traia información suficiente para clasificar la causa. |

Los subtipos de la tabla son los documentados en la página de rebotes, pero **`bounce.subType` no es un enum cerrado**: en payloads reales del webhook aparecen además `Suppressed` y `MessageRejected` (ver el ejemplo oficial de `email.bounced` en `webhooks-and-inbound.md`). No tomes decisiones por subtipo; decide solo por `bounce.type`.

**Regla de robustez (verificada en producción)**: suprime solo cuando `bounce.type === "Permanent"`. La redaccion oficial de las páginas de bounce/webhooks usa a veces el término de forma laxa (ej. "e.g. Permanent, Temporary" en una página de webhook frente a `Transient` en la del dashboard) — no hagas match de un literal exacto para el caso "no permanente"; en su lugar, actua solo sobre el valor `Permanent` confirmado y deja pasar cualquier otra cosa como no-supresión automática.

```typescript
// Handler de webhook de bounce: solo suprimir en Permanent, nunca en Transient/Undetermined
function shouldSuppress(bounceType: string): boolean {
  return bounceType === "Permanent";
}
```

```bash
curl -X POST 'https://api.resend.com/suppressions/batch/add' \
  -H "Authorization: Bearer ${RESEND_API_KEY}" \
  -H 'User-Agent: mi-servicio/1.0' \
  -H 'Content-Type: application/json' \
  -d '{"emails": ["baja1@tu-dominio.com", "baja2@tu-dominio.com"]}'
```

---

## 12. Logs y métricas

`GET /logs` (lista, paginado) y `GET /logs/{id}` (detalle) exponen `endpoint`, `method`, `response_status`, `user_agent` (detección automática del SDK y versión) y el `request_body`/`response_body` completos de cada llamada — retenidos durante la misma ventana de 30 días que el resto de datos de cuenta.

`GET /emails/metrics` da una vista de cuenta con dimensiones:

- Parámetros: `start_date`/`end_date` (ISO 8601; sin ninguno, cubre los últimos 7 días), `timezone` (IANA), `granularity` (solo afecta si `period` esta en `dimensions`; el rango no puede producir más de 10.000 períodos), `metrics` (lista; omitir = todas), `dimensions` (combinación de `period`, `domain`, `email`, `broadcast` — `email` no combina con `broadcast`), `domain_ids`/`email_ids`/`broadcast_ids` (hasta 100 cada uno).
- Respuesta **cacheada hasta 15 minutos** — un rango repetido puede traer datos ligeramente desfasados dentro de esa ventana.
- Las métricas de apertura/click **requieren tracking activo en el dominio de envío**; sin el, esas métricas quedan en cero (ver la nota sobre tracking y magic links en `domains-deliverability-and-plans.md`).

Las 22 métricas documentadas: `received`, `sent`, `delivered`, `delivery_delayed`, `failed`, `suppressed`, `bounced` (suma de las 3 siguientes), `bounced_transient`, `bounced_permanent`, `bounced_undetermined`, `opened`, `unique_opened`, `clicked`, `unique_clicked`, `complained`, `unsubscribed`, `delivery_rate`, `open_rate`, `click_rate`, `bounce_rate`, `complaint_rate`, `unsubscribe_rate`.

```typescript
const { data, error } = await resend.emails.metrics({
  startDate: "2026-08-01",
  endDate: "2026-09-04",
  metrics: ["sent", "delivered", "bounce_rate", "complaint_rate"],
  dimensions: ["period", "domain"],
});

if (error) console.error(error.name, error.message);
```

---

## 13. Direcciones de prueba

Cuatro direcciones oficiales simulan eventos sin tocar entrega real — **todas cuentan contra tu cuota de envío** (verificado 2026-09-04):

| Dirección | Evento simulado | Soporta `+label` |
|---|---|---|
| `delivered@resend.dev` | Entrega exitosa | Si (`delivered+caso1@resend.dev`) |
| `bounced@resend.dev` | Bounce (SMTP `550 5.1.1`) | Si |
| `complained@resend.dev` | Marcado como spam | Si |
| `suppressed@resend.dev` | Supresión (razón: "previamente rebotado") | **No** |

- Enviar a dominios de ejemplo genéricos (`@example.com`, `@test.com`) **no simula nada**: Resend los bloquea activamente y devuelve **`422 Unprocessable Entity`**.
- Sin dominio propio verificado, `onboarding@resend.dev` como `from` solo puede enviar a la dirección de tu propia cuenta (ver seccion 1).

```typescript
// Sanity check de integracion: no requiere dominio verificado, pero SI cuenta contra la cuota
const { data, error } = await resend.emails.send({
  from: process.env.EMAIL_FROM_ADDRESS!,
  to: ["delivered@resend.dev"],
  subject: "smoke test",
  html: "<p>ok</p>",
});
```

---

## 14. Errores comunes y referencias cruzadas

| # | Error | Síntoma | Corrección |
|---|---|---|---|
| 1 | `try/catch` a secas alrededor de `resend.emails.send()` en Node | El envío "parece" exitoso pero nunca llega, sin excepción capturada | El SDK Node no lanza por errores de API: comprobar siempre `if (error)` de forma explícita. |
| 2 | Copiar el patron `try/except` de Python al código Node (o al reves) | En Node, un fallo real pasa desapercibido; en Python, un `except` vacio traga la excepción sin log | Node = `{data, error}` sin excepción; Python = excepción (`ResendError`) sin retorno de error. Son contratos opuestos. |
| 3 | `idempotencyKey` dentro del objeto de payload (Node) | La key se ignora en silencio (JS) o el código no compila (TS); reintentos generan emails duplicados | Pasarla como segundo argumento de `send()`/`batch.send()`. |
| 4 | Reintentar en bucle sin mirar `retry-after` | Cascada de `429 rate_limit_exceeded` en envíos masivos | Usar backoff que honre `retry-after`, o migrar a `POST /emails/batch`. |
| 5 | Repartir el tráfico entre varias API keys para esquivar el rate limit | Sigue llegando `429`: el límite es por TEAM, no por key | Coordinar TODOS los servicios que comparten team bajo el mismo presupuesto de 10 req/s. |
| 6 | Enviar adjuntos o imagenes inline vía `POST /emails/batch` | La petición falla o el adjunto se ignora | Los adjuntos solo funcionan en `POST /emails` (single); batch nunca los soporta. |
| 7 | Confiar en `statusCode` para decidir lógica de reintento | Un mismo `name` (p. ej. `validation_error`) aparece con distintos `statusCode` según el caso | Clasificar siempre por `error.name`, tratar `statusCode` como dato secundario. |
| 8 | Enviar pruebas a `@example.com`/`@test.com` esperando simular un bounce | `422 Unprocessable Entity` inmediato, sin simulacion | Usar las direcciones oficiales `*@resend.dev` (seccion 13). |
| 9 | Suprimir en base al literal exacto de un bounce "no permanente" | La lógica de supresión falla silenciosamente porque el wording varia entre páginas de la documentación oficial | Suprimir solo cuando `bounce.type === "Permanent"`; dejar pasar cualquier otro valor. |
| 10 | Asumir que `PATCH /emails/{id}` puede editar `subject`/`html` de un email programado | La API ignora esos campos o responde con error de validación | `PATCH` solo actualiza `scheduled_at`; para cambiar contenido, cancelar y reenviar. |
| 11 | Guardar una API key real en un fichero de ejemplo, skill o repositorio público | Filtracion de credenciales; revocación automática vía GitHub Secret Scanning si el repo es público (desde 2026-07-16), pero el daño de reputación de dominio ya esta hecho | Usar siempre placeholders (`re_xxxxxxxxx`) en ejemplos; nunca commitear una key real. |
| 12 | Depender del modo `permissive` de batch sin haberlo verificado | El comportamiento observado no coincide con lo esperado porque no esta en la referencia REST oficial | Tratar `permissive` como no confirmado; diseñar para el modo `strict` (atómico) por defecto. |

**Referencias relacionadas**:

- Firma y verificación de webhooks, eventos de entrega/rebote/queja, recepción de correo entrante -> `webhooks-and-inbound.md`
- DNS, regiones, tracking de apertura/click, precios y límites por plan, multi-tenant -> `domains-deliverability-and-plans.md`
- Integración con Next.js/Supabase Auth SMTP, testing con seam de `baseUrl`, comportamiento del SDK Node en detalle -> `sdk-node-nextjs-supabase-testing.md`
- Contactos, Segments/Topics, Broadcasts, ciclo de vida de Templates, Automations, OAuth -> `marketing-templates-automations-oauth.md`
- CLI oficial, MCP y plugins para agentes de IA -> `cli-mcp-and-agents.md`
- Patrones de producción (adapter único, outbox, colas, tests de round-trip) -> `production-patterns.md`
