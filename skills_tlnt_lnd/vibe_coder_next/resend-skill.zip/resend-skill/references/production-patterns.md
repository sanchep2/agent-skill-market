# Patrones de producción endurecidos — Referencia completa

Principios de arquitectura para operar un proveedor de email transaccional (API REST +
SDK Node) en producción real: adapter único, seam de test fail-closed, cola con
idempotencia física, gates de entrega, webhook fail-closed, supresión de rebotes,
neutralidad de tenant y rotación de secretos · API REST de Resend (sin versión de
ruta) · SDK Node `resend` 6.26.0 · `last_verified: 2026-09-04`.

## Table of Contents

1. [Un adapter único de transporte](#1-un-adapter-único-de-transporte)
2. [Seam de base URL fail-closed para tests](#2-seam-de-base-url-fail-closed-para-tests)
3. [Cola outbox con idempotencia física](#3-cola-outbox-con-idempotencia-física)
4. [Gates antes de entregar](#4-gates-antes-de-entregar)
5. [Webhook fail-closed y persistencia de eventos](#5-webhook-fail-closed-y-persistencia-de-eventos)
6. [Clasificación de rebotes y supresión](#6-clasificación-de-rebotes-y-supresión)
7. [Neutralidad de tenant y marca](#7-neutralidad-de-tenant-y-marca)
8. [Secretos, rotación y observabilidad](#8-secretos-rotación-y-observabilidad)
9. [Migrar desde otro vendor](#9-migrar-desde-otro-vendor)
10. [Testing y smoke en producción](#10-testing-y-smoke-en-producción)
11. [Errores comunes y referencias cruzadas](#11-errores-comunes-y-referencias-cruzadas)

---

## 1. Un adapter único de transporte

Un solo módulo del proyecto importa el SDK del proveedor; todo lo demás (colas,
plantillas, wrappers de negocio, tests) importa **ese módulo propio**, nunca el
paquete del vendor directamente. Es lo que permite cambiar de proveedor tocando un
solo fichero, y por eso este documento habla de "el adapter" como pieza singular.

```text
plantilla (config/DB)
      |
      v
[ resolver de contenido + variables ]
      |
      v
[ ADAPTER DE TRANSPORTE ]   <- unico punto de import del SDK (esta seccion)
      |  POST /emails  (Idempotency-Key: outbox:<id>)
      v
+----------------------+
|  proveedor de email  |
+----------------------+
      |  eventos asincronos (bounced, complained, delivered, ...)
      v
[ webhook fail-closed ] --> [ tabla de eventos ] --> [ supresion ] --> [ gate de envio ]
   (seccion 5)                                                          (secciones 4 y 6)
```

**El contrato del adapter, no el del SDK crudo.** La mayoría de SDKs de proveedores de
email devuelven una unión discriminada `{ data, error }` y **nunca lanzan** por un
error de dominio de la API (solo por fallos de red/infraestructura). Es cómodo de
olvidar en un código base que usa `try/catch` en todas partes. El adapter invierte ese
contrato una sola vez: **lanza en fallo, resolve = aceptado**.

**Nunca fabricar un id sintético.** Si el proveedor no devuelve un identificador de
mensaje utilizable, la extracción debe devolver `undefined`, nunca un UUID generado
localmente. Ese id es la prueba de que el mensaje fue aceptado; su ausencia es lo que
permite a un caller (típicamente una cola, §3) tratar el envío como una anomalía en
vez de darlo por acreditado.

**Tipos vendor-neutral re-exportados.** El adapter re-exporta con alias propio los
tipos que los consumidores necesitan (adjuntos, opciones de envío), para que ningún
otro fichero importe tipos directamente del paquete del vendor.

```typescript
// email/transport.ts — unico punto de import del SDK del proveedor en todo el proyecto
import { Resend } from "resend"
import type { Attachment as EmailAttachment, CreateEmailOptions } from "resend"

export type { EmailAttachment } // alias vendor-neutral para los consumidores

export interface EmailMessage {
  from: string
  to: string[]
  subject: string
  html?: string
  text?: string
  headers?: Record<string, string>
  attachments?: EmailAttachment[]
}

let cachedClient: { client: Resend; apiKey: string; baseUrl: string | undefined } | undefined

function getClient(): Resend {
  const apiKey = process.env.RESEND_API_KEY
  if (!apiKey) throw new Error("RESEND_API_KEY no configurada")
  const baseUrl = resolveBaseUrlOverride() // maquina de 4 estados, seccion 2
  if (!cachedClient || cachedClient.apiKey !== apiKey || cachedClient.baseUrl !== baseUrl) {
    cachedClient = { client: new Resend(apiKey, baseUrl ? { baseUrl } : {}), apiKey, baseUrl }
  }
  return cachedClient.client
}

/**
 * Contrato del adapter: LANZA en fallo, resolve = aceptado por el proveedor.
 * El SDK crudo devuelve { data, error } y no lanza por errores de dominio de
 * la API — este adapter invierte el contrato para que el resto del proyecto
 * use try/catch estandar sin inspeccionar un campo `error`.
 */
export async function sendEmailMessage(
  message: EmailMessage,
  options: { idempotencyKey?: string } = {},
): Promise<{ id: string | undefined }> {
  const payload: CreateEmailOptions = {
    from: message.from,
    to: message.to,
    subject: message.subject,
    ...(message.html ? { html: message.html } : {}),
    ...(message.text !== undefined ? { text: message.text } : {}), // "" es significativo: desactiva el texto autogenerado
    ...(message.headers ? { headers: message.headers } : {}),
    ...(message.attachments?.length ? { attachments: message.attachments } : {}),
  }

  const client = getClient()
  const { data, error } = options.idempotencyKey
    ? await client.emails.send(payload, { idempotencyKey: options.idempotencyKey })
    : await client.emails.send(payload)

  if (error) {
    // Clasificar SIEMPRE por error.name, nunca por statusCode (seccion 11, fila 3)
    throw new Error(`email-provider ${error.name}: ${error.message}`)
  }
  return { id: extractMessageId(data) }
}

/** Nunca fabrica un id sintetico: `undefined` = "el proveedor no dio ninguno". */
export function extractMessageId(data: unknown): string | undefined {
  if (data && typeof data === "object" && "id" in data) {
    const id = (data as { id: unknown }).id
    if (typeof id === "string" && id.length > 0) return id
  }
  return undefined
}
```

---

## 2. Seam de base URL fail-closed para tests

Cuando el SDK acepta una URL base configurable, ese parámetro es una superficie real
de fuga de credenciales: la API key viaja en cada request, así que un host equivocado
en producción se la lleva. El patrón correcto es una máquina de **4 estados**:

| Estado | Condición | Decisión |
|---|---|---|
| `absent` | Variable ausente | Usar el proveedor real (default) |
| `ignored-prod` | Producción + variable presente | Ignorarla con `warn`, seguir con el real |
| `override` | No-producción + host **exactamente** loopback (`127.0.0.1`, `localhost`, `::1`, `[::1]`) | Usar el override |
| `invalid` | No-producción + cualquier otra cosa (host remoto, URL malformada, esquema no-http) | **Abortar** (lanzar) |

**Por qué NO basta un `null`/`undefined` de dos estados.** Un diseño ingenuo de
"presente vs. ausente" colapsa "no hay override" (normal) con "hay un override roto o
apuntando a un host que no es de test" (bug) en la misma rama. Si esa rama decide
"cuando no puedo usar el override, caigo al proveedor real", una URL de test mal
escrita en no-producción también termina enviando la key real al proveedor real, sin
que nadie note que el seam nunca se activó. La máquina de 4 estados hace ese fallo
imposible: lo inválido tiene su propia rama, que lanza — nunca un fallback disfrazado
de éxito.

**Reevaluar en cada llamada, no memorizar la decisión una sola vez.** Si el cliente se
cachea, el guard debe re-evaluarse en cada envío: un override que se corrompe después
de construir el cliente debe abortar el siguiente intento, no seguir usando la
decisión antigua.

```typescript
// email/base-url-seam.ts
export type BaseUrlDecision =
  | { kind: "absent" }
  | { kind: "ignored-prod" }
  | { kind: "override"; url: string }
  | { kind: "invalid"; reason: "malformed_url" | "non_http_protocol" | "non_loopback_host" }

const LOOPBACK_HOSTS = new Set(["127.0.0.1", "localhost", "::1", "[::1]"])

export function resolveBaseUrlDecision(): BaseUrlDecision {
  const raw = process.env.RESEND_BASE_URL
  if (!raw) return { kind: "absent" }
  if (process.env.NODE_ENV === "production") return { kind: "ignored-prod" }

  let parsed: URL
  try {
    parsed = new URL(raw)
  } catch {
    return { kind: "invalid", reason: "malformed_url" }
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    return { kind: "invalid", reason: "non_http_protocol" }
  }
  return LOOPBACK_HOSTS.has(parsed.hostname)
    ? { kind: "override", url: raw }
    : { kind: "invalid", reason: "non_loopback_host" }
}

export function resolveBaseUrlOverride(logger: { warn: (msg: string) => void } = console): string | undefined {
  const decision = resolveBaseUrlDecision()
  switch (decision.kind) {
    case "absent":
      return undefined
    case "ignored-prod":
      logger.warn("RESEND_BASE_URL presente en produccion: se ignora")
      return undefined
    case "override":
      return decision.url
    case "invalid":
      throw new Error(`RESEND_BASE_URL invalida (${decision.reason})`) // NUNCA caer al proveedor real
  }
}
```

El patrón de test recomendado es un **servidor HTTP real en loopback**
(`node:http`, puerto efímero), no un mock del módulo del SDK: ejercita la
serialización real del payload y la propagación de cabeceras (`Idempotency-Key`
incluida), en vez de solo verificar que "se llamó a una función".

```typescript
// email/base-url-seam.test.ts
import { createServer } from "node:http"
import { describe, it, expect, afterEach, vi } from "vitest"
import { resolveBaseUrlOverride } from "./base-url-seam"

describe("resolveBaseUrlOverride", () => {
  afterEach(() => vi.unstubAllEnvs())

  it("acepta el override cuando el host es loopback fuera de produccion", async () => {
    const server = createServer((_req, res) => res.writeHead(200).end('{"id":"test"}'))
    await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve))
    const port = (server.address() as { port: number }).port

    vi.stubEnv("NODE_ENV", "test")
    vi.stubEnv("RESEND_BASE_URL", `http://127.0.0.1:${port}`)
    expect(resolveBaseUrlOverride({ warn: () => {} })).toBe(`http://127.0.0.1:${port}`)
    server.close()
  })

  it("aborta si el host no es loopback fuera de produccion", () => {
    vi.stubEnv("NODE_ENV", "test")
    vi.stubEnv("RESEND_BASE_URL", "http://mail-catcher.interno.ejemplo.com")
    expect(() => resolveBaseUrlOverride({ warn: () => {} })).toThrow(/invalida/)
  })

  it("ignora la variable en produccion sin abortar, y avisa", () => {
    vi.stubEnv("NODE_ENV", "production")
    vi.stubEnv("RESEND_BASE_URL", "http://127.0.0.1:9999")
    const warn = vi.fn()
    expect(resolveBaseUrlOverride({ warn })).toBeUndefined()
    expect(warn).toHaveBeenCalledOnce()
  })
})
```

---

## 3. Cola outbox con idempotencia física

Cuando un envío no puede ser síncrono con la petición que lo origina, o debe
sobrevivir a un timeout HTTP sin duplicarse, la herramienta correcta es una **cola
transaccional** respaldada por una tabla — nunca un `setTimeout`/reintento
improvisado dentro del propio manejador de la petición original.

### 3.1 Tabla y máquina de estados

```sql
create type message_outbox_status as enum ('queued', 'sending', 'sent', 'failed', 'dead', 'skipped');

create table message_outbox (
  id uuid primary key default gen_random_uuid(),
  channel text not null,
  dedupe_key text not null,
  payload jsonb not null,
  status message_outbox_status not null default 'queued',
  attempts int not null default 0,
  max_attempts int not null default 5,
  next_attempt_at timestamptz not null default now(),
  lease_until timestamptz,
  lease_token uuid,            -- token del claim vigente: toda completion debe presentarlo
  provider_ref text,
  last_error text,
  created_at timestamptz not null default now(),
  unique (channel, dedupe_key)
);

alter table message_outbox enable row level security;
-- deny-all: la tabla solo se toca via RPCs SECURITY DEFINER (service-role)
```

```text
   enqueue (dedupe_key unique)
            |
            v
       +---------+  retry: next_attempt_at con backoff exponencial
       | queued  |<---------------------------------------------+
       +---------+                                               |
            | claim (FOR UPDATE SKIP LOCKED + lease)              |
            v                                                     |
       +---------+                                                |
       | sending |---------------+                                |
       +---------+               |                                |
        /        \               |  2xx sin id (anomalia)         |
   sent/          \falla         v                                |
      v             v        +------+                             |
  +------+     +---------+   | dead |                             |
  | sent |     | failed  |---+------+                             |
  +------+     +---------+        attempts >= max_attempts        |
                    |                        |                    |
                    +--------- reintentar ---+--------------------+

  "skipped": decision del gate de negocio (seccion 4), ANTES de intentar el
  envio fisico — nunca compite por lease, nunca reintenta.
```

`failed` es reintentable; `dead` y `skipped` son terminales pero distintos: `dead`
agotó reintentos o recibió un error determinista del proveedor (reintentar daría el
mismo resultado); `skipped` es una decisión de negocio (consentimiento, supresión,
preferencia apagada), nunca un fallo técnico.

### 3.2 Lease y backoff en SQL

`FOR UPDATE SKIP LOCKED` permite que varios workers compitan por el mismo lote sin
bloquearse: cada uno solo se lleva filas que nadie más tiene en mano, y un lease
vencido vuelve a estar disponible sin intervención manual.

```sql
create or replace function outbox_claim_batch(p_channel text, p_batch_size int, p_lease_seconds int)
returns setof public.message_outbox language sql security definer set search_path = '' as $$
  update public.message_outbox
  set status = 'sending', attempts = attempts + 1,
      lease_until = now() + make_interval(secs => p_lease_seconds),
      lease_token = gen_random_uuid()
  where id in (
    select id from public.message_outbox
    where channel = p_channel
      and (
        (status in ('queued', 'failed') and next_attempt_at <= now())
        or (status = 'sending' and lease_until < now()) -- worker muerto: lease vencido, se re-reclama
      )
    order by next_attempt_at limit p_batch_size
    for update skip locked
  )
  returning *;
$$;
```

Con `set search_path = ''` (obligatorio en `security definer`) **toda tabla va con su
esquema explícito** (`public.message_outbox`): un nombre sin cualificar no resuelve. Y toda
función `security definer` nace con `EXECUTE` para `public`: **revocar y conceder solo al rol
del worker** (`service_role` en Supabase; el rol de la app en cualquier otro Postgres), o la
cola queda operable por cualquier cliente anónimo a través de la API REST.

**El claim devuelve un `lease_token` y toda completion lo presenta.** Sin token, un
worker lento cuyo lease caducó podría marcar `sent`/`failed` una fila que otro worker
ya re-reclamó y está enviando: el segundo envío quedaría mal contabilizado. Con el
token, cada `update` de completion filtra por `id AND lease_token`; **0 filas
actualizadas = completion stale, se ignora en silencio** (el dueño vigente del lease
es quien decide el estado final).

```sql
create or replace function outbox_mark_sent(p_id uuid, p_lease_token uuid, p_provider_ref text)
returns boolean language sql security definer set search_path = '' as $$
  with done as (
    update public.message_outbox
    set status = 'sent', provider_ref = p_provider_ref, lease_token = null, lease_until = null
    where id = p_id and lease_token = p_lease_token and status = 'sending'
    returning 1
  )
  select exists (select 1 from done); -- false = lease caducado y re-reclamado: completion stale
$$;

-- "Aceptado sin id" es TERMINAL (seccion 3.3): nunca vuelve a la cola de reintentos.
create or replace function outbox_mark_dead(p_id uuid, p_lease_token uuid, p_error text)
returns boolean language sql security definer set search_path = '' as $$
  with done as (
    update public.message_outbox
    set status = 'dead', last_error = p_error, lease_token = null, lease_until = null
    where id = p_id and lease_token = p_lease_token and status = 'sending'
    returning 1
  )
  select exists (select 1 from done);
$$;
```

Backoff: primer fallo un retraso corto fijo; los siguientes crecen exponencialmente
con **tope de 1 hora**. Un `retry-after` explícito del proveedor (típico de un 429)
manda sobre el backoff propio, acotado a un rango razonable.

```sql
create or replace function outbox_mark_failed(p_id uuid, p_lease_token uuid, p_error text, p_retry_after_seconds int default null)
returns boolean language plpgsql security definer set search_path = '' as $$
declare v_attempts int; v_max int; v_delay int; v_rows int;
begin
  select attempts, max_attempts into v_attempts, v_max from public.message_outbox
    where id = p_id and lease_token = p_lease_token and status = 'sending';
  if not found then
    return false; -- lease caducado y re-reclamado por otro worker: completion stale, ignorada
  end if;
  if v_attempts >= v_max then
    update public.message_outbox set status = 'dead', last_error = p_error, lease_token = null, lease_until = null
      where id = p_id and lease_token = p_lease_token;
    get diagnostics v_rows = row_count;
    return v_rows = 1;
  end if;
  v_delay := case
    when p_retry_after_seconds is not null then least(greatest(p_retry_after_seconds, 1), 3600)
    when v_attempts <= 1 then 30
    else least((120 * power(2, v_attempts - 2))::int, 3600)
  end;
  update public.message_outbox set status = 'failed', last_error = p_error, lease_token = null, lease_until = null,
    next_attempt_at = now() + make_interval(secs => v_delay)
    where id = p_id and lease_token = p_lease_token; -- 0 filas = otro worker ya tiene el lease
  get diagnostics v_rows = row_count;
  return v_rows = 1;
end;
$$;

-- Superficie CERRADA (va DESPUES de las cuatro definiciones: cada firma debe existir ya): Postgres concede EXECUTE a public por defecto y PostgREST expone public.*
-- a anon/authenticated. Sin estos REVOKE, cualquier cliente con la anon key podria reclamar o
-- cerrar filas de la cola. Solo el worker (service_role) ejecuta estas RPCs.
revoke execute on function outbox_claim_batch(text, int, int) from public, anon, authenticated;
revoke execute on function outbox_mark_sent(uuid, uuid, text) from public, anon, authenticated;
revoke execute on function outbox_mark_failed(uuid, uuid, text, int) from public, anon, authenticated;
revoke execute on function outbox_mark_dead(uuid, uuid, text) from public, anon, authenticated;
grant execute on function outbox_claim_batch(text, int, int), outbox_mark_sent(uuid, uuid, text),
  outbox_mark_failed(uuid, uuid, text, int), outbox_mark_dead(uuid, uuid, text) to service_role;
```

### 3.3 Idempotencia física y la cadena de deadlines

Usar el **id de la propia fila** de la cola como clave de idempotencia del proveedor
(`outbox:<id>`). La ventana de idempotencia típica (24 h) cubre el peor caso real: un
timeout de red en el intento N no duplica el envío si el intento N+1 llega dentro de
esa ventana con la misma clave y el mismo payload.

**"Aceptado sin id" es terminal, nunca se reintenta**: si el proveedor responde éxito
pero no se puede extraer un id de mensaje, el envío físico puede haber ocurrido ya —
reintentar arriesga un duplicado real. Esa fila se marca `dead` con motivo explícito.

**La cadena de deadlines debe cumplirse siempre**: timeout del manejador de un lote <
timeout del disparador que lo invoca (cron, cola externa, webhook interno) < duración
del lease de las filas en `sending`. Si se rompe, dos ejecuciones pueden reclamar y
enviar la misma fila. Conviene verificarla al cargar el módulo, para fallar rápido y
ruidoso en vez de silenciosamente bajo carga.

```typescript
// email/outbox-drain.ts
const HANDLER_DEADLINE_MS = 90_000
const TRIGGER_TIMEOUT_MS = 120_000
const LEASE_SECONDS = 180

if (HANDLER_DEADLINE_MS >= TRIGGER_TIMEOUT_MS || TRIGGER_TIMEOUT_MS >= LEASE_SECONDS * 1000) {
  throw new Error("cadena de deadlines invalida: handler < trigger < lease")
}

async function drainEmailBatch(db: AdminClient): Promise<void> {
  const rows = await db.rpc("outbox_claim_batch", { p_channel: "email", p_batch_size: 20, p_lease_seconds: LEASE_SECONDS })
  for (const row of rows) {
    try {
      const { id } = await sendEmailMessage(row.payload, { idempotencyKey: `outbox:${row.id}` })
      if (!id) {
        await db.rpc("outbox_mark_dead", { p_id: row.id, p_lease_token: row.lease_token, p_error: "accepted_no_message_id" })
        continue
      }
      // Toda completion lleva el lease_token del claim: si devuelve false, el lease caduco y
      // otro worker re-reclamo la fila — esta completion es stale y NO decide el estado final.
      const acked = await db.rpc("outbox_mark_sent", { p_id: row.id, p_lease_token: row.lease_token, p_provider_ref: `provider:msg:${id}` })
      if (!acked) logger.warn({ msg: "outbox_completion_stale", outboxId: row.id })
    } catch (err) {
      await db.rpc("outbox_mark_failed", { p_id: row.id, p_lease_token: row.lease_token, p_error: String(err), p_retry_after_seconds: extractRetryAfterSeconds(err) })
    }
  }
}
```

---

## 4. Gates antes de entregar

Antes de que un mensaje salga físicamente, atraviesa comprobaciones de negocio
independientes del transporte — todas **fail-closed**: un error de lectura bloquea el
envío, nunca lo deja pasar por defecto.

1. **Consentimiento.** Transaccional no requiere opt-in; marketing sí.
2. **Lista de supresión propia**, alimentada por los webhooks del proveedor (§5-§6) —
   más auditable que confiar solo en el estado interno del proveedor.
3. **Preferencias evaluadas en tiempo de envío, no de encolado**: el destinatario pudo
   cambiarlas entre que se generó el evento y que un worker lo procesó.
4. **Marketing exige una URL de baja construible**; si no se puede construir, el
   resultado correcto es `skipped` con motivo explícito, nunca enviar sin baja.
5. **Las excepciones de supresión existen solo por decisión explícita de negocio**,
   documentada y de alcance mínimo — nunca un criterio decidido sobre la marcha.
6. **El kill-switch de pausa se lee fail-closed**: un error de lectura del flag se
   trata como "pausado", nunca como "no pausado por defecto".

```typescript
// email/send-gate.ts
type GateResult =
  | { allow: true }
  | { allow: false; reason: "channel_paused" | "suppressed" | "consent_missing" | "unsubscribe_unavailable" | "pref_disabled" }

// Solo plantillas selladas por una decision de negocio explicita, con fecha y motivo.
const SUPPRESSION_EXEMPT_TEMPLATES = new Set<string>([])

async function evaluateSendGate(ctx: GateContext, deps: GateDeps): Promise<GateResult> {
  const paused = await deps.isChannelPaused().catch(() => true) // fail-closed
  if (paused) return { allow: false, reason: "channel_paused" }

  if (SUPPRESSION_EXEMPT_TEMPLATES.has(ctx.templateCode)) return { allow: true } // exencion sellada

  if (await deps.isSuppressed(ctx.recipientEmail)) return { allow: false, reason: "suppressed" }

  if (ctx.category === "marketing") {
    if (!(await deps.hasMarketingConsent(ctx.recipientEmail))) return { allow: false, reason: "consent_missing" }
    const unsubscribeUrl = await deps.buildUnsubscribeUrl(ctx.recipientEmail).catch(() => null)
    if (!unsubscribeUrl) return { allow: false, reason: "unsubscribe_unavailable" }
  }

  if (ctx.notificationPrefKey && !(await deps.isPreferenceEnabled(ctx.recipientEmail, ctx.notificationPrefKey))) {
    return { allow: false, reason: "pref_disabled" }
  }
  return { allow: true }
}
```

---

## 5. Webhook fail-closed y persistencia de eventos

El manejador de webhooks entrantes es la superficie más peligrosa del pipeline: recibe
tráfico de una IP ajena con un body que se va a persistir. El orden de comprobaciones
va de la más barata a la más cara, cada una fail-closed:

```text
faltan cabeceras de firma        -> 400  (ni siquiera lee el body)
falta el secreto de verificacion -> 500  (NUNCA 4xx: el proveedor reintenta con
                                           backoff; el evento no se pierde mientras
                                           se repara la configuracion)
body excede la cota (streaming)  -> 413  (nunca confiar en Content-Length)
firma invalida                   -> 401
evento no mapeado                -> 200  {status:"ignored"}
faltan campos de negocio         -> 400
----------------------------------------
persistir (idempotente) + intentar supresion -> 200
```

**Allow-list explícita de lo que se persiste.** El payload crudo guardado debe ser un
subconjunto explícito de campos de negocio (vendor, tipo de evento, id de mensaje,
destinatario, tipo de rebote, fecha) — **nunca** las cabeceras de firma.

**Dedupe por índice único, no por lógica de aplicación.** `unique
(provider_event_id)` — el `svix-id` de cada entrega — + `insert ... on conflict do
nothing` soporta reintentos del proveedor (entrega at-least-once) sin duplicar fila y
sin una carrera de "¿ya existe?" previa al insert. La pareja `(provider_message_id,
event_type)` NO sirve como clave única: un mismo email puede generar legítimamente
varios eventos del mismo tipo (p. ej. dos `delivery_delayed`); queda como índice de
consulta, no como restricción.

**Un fallo de supresión no bloquea el 200.** Si falla el paso de apuntar la supresión,
se loggea pero no se propaga como error HTTP — de lo contrario el proveedor reintenta
un evento que ya se persistió correctamente.

**Logs sin PII ni cabeceras de firma.**

```typescript
// api/webhooks/email-events/route.ts
const MAX_BODY_BYTES = 1 * 1024 * 1024 // 1 MiB — cota propia, no confiar en Content-Length

export async function POST(req: Request): Promise<Response> {
  const signatureId = req.headers.get("svix-id")
  const timestamp = req.headers.get("svix-timestamp")
  const signature = req.headers.get("svix-signature")
  if (!signatureId || !timestamp || !signature) {
    return Response.json({ status: "missing_signature" }, { status: 400 })
  }

  const secret = process.env.RESEND_WEBHOOK_SECRET
  if (!secret) {
    logger.error({ msg: "webhook_config_error" })
    return Response.json({ status: "config_error" }, { status: 500 }) // NUNCA 4xx aqui
  }

  const rawBody = await readBodyWithCap(req, MAX_BODY_BYTES)
  if (rawBody === "too_large") return Response.json({ status: "payload_too_large" }, { status: 413 })

  let verifiedEvent: unknown
  try {
    verifiedEvent = verifySignature(rawBody, { id: signatureId, timestamp, signature }, secret)
  } catch {
    return Response.json({ status: "invalid_signature" }, { status: 401 })
  }

  const parsed = parseKnownEvent(verifiedEvent)
  if (!parsed) return Response.json({ status: "ignored" }, { status: 200 })

  await persistEvent(parsed, signatureId) // idempotente: unique(provider_event_id) = svix-id de ESTA entrega
  await applySuppressionIfNeeded(parsed).catch((err) =>
    logger.warn({ msg: "suppression_write_failed", type: parsed.eventType, reason: String(err) }),
  )
  return Response.json({ status: "processed" }, { status: 200 })
}

async function readBodyWithCap(req: Request, capBytes: number): Promise<string | "too_large"> {
  const reader = req.body?.getReader()
  if (!reader) return ""
  const chunks: Uint8Array[] = []
  let total = 0
  for (;;) {
    const { done, value } = await reader.read()
    if (done) break
    total += value.byteLength
    if (total > capBytes) {
      await reader.cancel() // liberar el resto del cuerpo antes de responder
      return "too_large" // cota durante la LECTURA
    }
    chunks.push(value)
  }
  return Buffer.concat(chunks).toString("utf8")
}
```

```sql
create table email_events (
  id bigint generated always as identity primary key,
  vendor text not null,
  provider_event_id text not null,  -- svix-id: identifica ESTA entrega (clave de dedupe)
  provider_message_id text not null,
  event_type text not null,
  recipient text,
  bounce_type text,
  raw_payload jsonb not null, -- allow-list explicito, NUNCA cabeceras de firma
  created_at timestamptz not null default now(),
  unique (provider_event_id)
);
-- indice NO unico: historial de un email (varios eventos del mismo tipo son legitimos)
create index email_events_message_type_idx on email_events (provider_message_id, event_type);

alter table email_events enable row level security;
create policy "admin_can_read_email_events" on email_events for select using (is_admin());

create or replace function record_email_event(
  p_vendor text, p_provider_event_id text, p_provider_message_id text, p_event_type text,
  p_recipient text, p_bounce_type text, p_raw_payload jsonb
) returns void language sql security definer set search_path = '' as $$
  insert into public.email_events (vendor, provider_event_id, provider_message_id, event_type, recipient, bounce_type, raw_payload)
  values (p_vendor, p_provider_event_id, p_provider_message_id, p_event_type, p_recipient, p_bounce_type, p_raw_payload)
  on conflict (provider_event_id) do nothing;
$$;

-- Solo el handler del webhook (service_role) escribe eventos: cerrar la superficie por defecto.
revoke execute on function record_email_event(text, text, text, text, text, text, jsonb) from public, anon, authenticated;
grant execute on function record_email_event(text, text, text, text, text, text, jsonb) to service_role;
```

---

## 6. Clasificación de rebotes y supresión

**Solo dos motivos suprimen de verdad**: una queja de spam (`complained`), siempre; y
un rebote con tipo `Permanent`. Un rebote `Transient`, `Undetermined` o un evento de
`delivery_delayed` **no** suprimen — es un fallo temporal (buzón lleno, greylisting),
y suprimir por eso penaliza a un destinatario válido por algo que ya puede haberse
resuelto.

**No mezclar vocabularios de rebote entre proveedores.** Muchos adoptan una semántica
tipo `Permanent`/`Transient`/`Undetermined`; otros usan taxonomías propias de texto
libre. Un clasificador escrito para un vocabulario no se reutiliza tal cual para otro:
mantener una función por vendor y unificar solo en la decisión booleana final
(`suppress: true|false`), nunca en las cadenas de categoría crudas.

**Quitar de la supresión no garantiza entrega futura** — solo que se reintentará; la
causa raíz (dominio inexistente, buzón cerrado) puede seguir vigente.

```typescript
// email/bounce-classification.ts
export interface BounceSuppressionDecision { suppress: boolean; reason: string }

/** Vocabulario tipo Permanent | Transient | Undetermined. */
export function classifyBounceForSuppression(
  eventType: "bounced" | "complained" | "delivery_delayed",
  bounceType: string | undefined,
): BounceSuppressionDecision {
  if (eventType === "complained") return { suppress: true, reason: "complaint" }
  if (eventType === "bounced" && bounceType === "Permanent") return { suppress: true, reason: "hard_bounce" }
  return { suppress: false, reason: bounceType ?? "non_permanent" } // Transient/Undetermined/delayed: NO suprime
}
```

---

## 7. Neutralidad de tenant y marca

**El remitente se compone desde configuración, nunca literal.** El local-part puede
venir de una fila de plantilla; el dominio **siempre** de una variable de entorno por
despliegue (`EMAIL_FROM_ADDRESS`). Nunca al revés, y nunca un literal de marca/dominio
en código, SQL o migración: si el dominio se hardcodea, un segundo tenant desplegado
con el mismo código enviaría emails con el dominio del primero.

```typescript
// email/tenant-from-address.ts
export function resolveFromAddress(templateLocalPart: string, displayName: string): string {
  const domain = extractDomain(process.env.EMAIL_FROM_ADDRESS)
  if (!domain) throw new Error("EMAIL_FROM_ADDRESS sin dominio configurado")
  return `${quoteDisplayName(displayName)} <${templateLocalPart}@${domain}>` // local-part de config, dominio de env
}

// EMAIL_FROM_ADDRESS puede venir como `usuario@dominio` o como `"Nombre" <usuario@dominio>`:
// normalizar ANTES de partir por "@", o el dominio saldria con el ">" final pegado.
function extractDomain(raw: string | undefined): string | undefined {
  if (!raw) return undefined
  const address = (raw.match(/<([^<>]+)>/)?.[1] ?? raw).trim()
  const at = address.lastIndexOf("@")
  if (at <= 0 || at === address.length - 1) return undefined
  return address.slice(at + 1).toLowerCase()
}

function quoteDisplayName(name: string): string {
  return `"${name.replace(/"/g, '\\"')}"` // RFC 5322 quoted-string: evita inyeccion via coma/angulos
}
```

```bash
# .env.local (ejemplo de valor, nunca literal en codigo)
EMAIL_FROM_ADDRESS=notificaciones@tu-dominio.com
EMAIL_FROM_NAME=Notificaciones
```

**El branding del layout también viene de configuración**, no de un helper que
concatena un nombre de marca fijo en el header/footer del HTML — un segundo tenant
vería literalmente el nombre del primero en sus correos.

**Tracking de apertura/clic apagado en dominios transaccionales y de autenticación.**
En muchos proveedores el tracking es una opción **por dominio**, no por mensaje: si se
activa en un dominio que envía enlaces de un solo uso (verificación, enlace mágico,
reset de password), el proveedor los reescribe y puede romper su semántica de un solo
uso. Mantenerlo encendido solo en un dominio dedicado a marketing.

**Dos patrones válidos de multi-tenant sobre la cuenta del proveedor:**

- **(A) Cuenta única + un dominio y una API key de solo-envío por tenant.** Simple,
  pero reputación y rate limit se comparten — un tenant que se comporta mal perjudica
  la entregabilidad de los demás.
- **(B) Credenciales propias por tenant.** Aísla reputación y cuota por completo, a
  cambio de dar de alta credenciales por cada tenant nuevo.

Elegir (A) para tenants internos/de confianza y (B) cuando son terceros arbitrarios.

---

## 8. Secretos, rotación y observabilidad

**Las credenciales viven solo en variables de entorno o un gestor de secretos** —
nunca en código, fixtures de test committeados ni ficheros de documentación.

**Rotación de la API key en dos pasos, nunca "revocar primero":**

```bash
# 1. Crear la key nueva en el panel del proveedor (NO revocar la vieja todavia)
# 2. Desplegar la key nueva en TODOS los consumidores (app + SMTP de auth si aplica)
# 3. Verificar un envio real de smoke con la key nueva (seccion 10)
# 4. Revocar la key vieja SOLO despues de que (3) salga en verde
```

**Recrear un webhook equivale a rotar su secreto.** El secreto de firma suele
mostrarse una única vez, al crear (o leer inmediatamente) el endpoint. Borrar y
recrearlo emite un secreto nuevo — hay que actualizar la variable del receptor en el
mismo cambio, o la verificación de firma empezará a fallar.

**Un partner de escaneo de secretos (tipo GitHub Secret Scanning) es una red de
seguridad, no una política.** Que el proveedor detecte y revoque automáticamente una
key filtrada en un repo público es una mitigación real de daño, no un sustituto de la
disciplina de no comprometerla nunca.

**Logs estructurados sin variables de plantilla**: id de mensaje, código de plantilla
y motivo — nunca el contenido interpolado (una URL de enlace mágico en un log es una
fuga con otro nombre).

```typescript
logger.info({
  msg: "email_send_failed",
  templateCode: "order_confirmation",
  reason: "vendor_send_failed",
  // NUNCA: variables interpoladas de la plantilla, tokens, URLs firmadas
})
```

**Métricas de la API del proveedor antes que un dashboard propio desde cero**, y **la
página de estado pública antes de asumir un bug propio** — un incidente de entrega
puntual hacia un proveedor de bandeja de entrada concreto, ya reconocido y resuelto
por el vendor coordinando con ese proveedor, es un caso frecuente de "falso bug
propio" que una revisión de 30 segundos habría descartado.

---

## 9. Migrar desde otro vendor

**Convivencia con dos webhooks escribiendo en la misma tabla**, discriminados por un
campo `vendor` — evita bifurcar reportes y supresión en dos tablas que luego habría
que unir a mano.

```sql
alter table email_events add column if not exists vendor text not null default 'unknown';
-- discriminador: 'proveedor-nuevo' | 'proveedor-legado' — ambos webhooks
-- insertan en LA MISMA tabla de eventos
```

```typescript
const bounceClassifiers: Record<string, (eventType: string, raw: unknown) => BounceSuppressionDecision> = {
  "proveedor-nuevo": (eventType, raw) => classifyBounceForSuppression(eventType as never, (raw as { bounceType?: string })?.bounceType),
  "proveedor-legado": (eventType, raw) => classifyLegacyBounceForSuppression(eventType, raw),
}
```

**El SDK del proveedor anterior queda solo como dependencia de desarrollo** una vez
retirada su capacidad real de envío — cero import en rutas de código de producción.

**Retirada diferida con criterio explícito, no oportunista.** Es razonable dejar
preparada la eliminación completa sin fusionarla de inmediato, pero la fusión debe
condicionarse a un criterio decidido de antemano ("N días de estabilidad del nuevo Y
cero eventos en tránsito del anterior"), no a "parece que ya no hace falta".

**No normalizar el vocabulario de rebote de ambos proveedores en un único enum**: como
en §6, un clasificador por vendor, unificado solo en la decisión booleana.

---

## 10. Testing y smoke en producción

**Direcciones de prueba dedicadas del proveedor** (tipo `entregado@dominio-de-pruebas.dev`,
`rebotado@dominio-de-pruebas.dev`) ejercitan la ruta HTTP real sin tocar un buzón real
— pero **siguen consumiendo cuota de envío**, no son gratis ni ilimitadas.

**Endpoint interno de smoke con dos modos, protegido por token interno:**

- `mode=security_test`, con `dryRun: true` siempre: corre un catálogo amplio de
  payloads adversariales (inyección en cabeceras, XSS, URLs no-http) ejercitando solo
  la validación/escapado, sin llamada de red al proveedor. Seguro en cada cambio.
- `mode=smoke`, sin `dryRun`: envía un catálogo pequeño y fijo de mensajes **reales**.
  Gasta cuota real y puede llegar a un buzón real — requiere aprobación humana
  explícita, nunca automático en cada commit.

```typescript
// api/internal/smoke-email/route.ts
import { timingSafeEqual } from "node:crypto"

export async function POST(req: Request): Promise<Response> {
  // Sin token configurado el endpoint NO existe operativamente: jamas comparar contra
  // undefined/"" (una cabecera vacia "coincidiria" con un secreto ausente).
  const expected = process.env.SMOKE_EMAIL_INTERNAL_TOKEN
  if (!expected) {
    return Response.json({ error: "smoke_disabled" }, { status: 503 })
  }
  const token = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? ""
  if (!token || !safeEqual(token, expected)) {
    return Response.json({ error: "unauthorized" }, { status: 401 })
  }
  const { mode } = await req.json()
  if (mode === "security_test") return Response.json(await runSecurityFixtures({ dryRun: true }))
  if (mode === "smoke") return Response.json(await runSmokeFixtures({ recipient: process.env.SMOKE_RECIPIENT_EMAIL! }))
  return Response.json({ error: "unknown_mode" }, { status: 400 })
}

function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a)
  const bb = Buffer.from(b)
  return ab.length === bb.length && timingSafeEqual(ab, bb) // comparacion en tiempo constante
}
```

---

## 11. Errores comunes y referencias cruzadas

| # | Error | Síntoma | Corrección |
|---|---|---|---|
| 1 | Envolver en `try/catch` un SDK que devuelve `{ data, error }` sin lanzar | Falso éxito: el `catch` nunca se dispara aunque el envío falle | Adapter único que revisa `error` y lanza (sección 1) |
| 2 | Pasar la clave de idempotencia dentro del payload en vez de como opción aparte | Se ignora en silencio; un reintento duplica el envío | Verificar en la doc del SDK vigente dónde va la clave antes de copiar un ejemplo |
| 3 | Clasificar errores por `statusCode` en vez de por el código/nombre de error | El mismo error llega con distinto código HTTP según el campo que falle | Clasificar siempre por el campo estable del proveedor (`name`/`code`) |
| 4 | Override de URL base sin guardas de entorno/host | Una URL mal escrita en no-producción filtra la key real | Máquina de 4 estados fail-closed (sección 2) |
| 5 | Asumir envío parcial en un batch atómico | Una entrada inválida tumba el lote entero; el código sigue como si el resto se hubiera enviado | Tratar el batch como todo-o-nada salvo modo permisivo explícito |
| 6 | Tracking de apertura/clic activado en el dominio de autenticación | Enlaces de un solo uso dejan de funcionar tras ser reescritos | Tracking apagado en dominios con enlaces de un solo uso (sección 7) |
| 7 | Sin dedupe en la persistencia de eventos de webhook | Reintentos duplican filas y pueden duplicar efectos de negocio | Índice único + `on conflict do nothing` (sección 5) |
| 8 | Confiar en `Content-Length` para limitar el body del webhook | Un body más grande de lo esperado pasa sin control | Cota aplicada durante la lectura en streaming (sección 5) |
| 9 | Un único enum de categorías de rebote compartido entre proveedores | Una categoría de un vendor se interpreta con la semántica de otro | Un clasificador por vocabulario de vendor (secciones 6 y 9) |
| 10 | Revocar la credencial vieja antes de confirmar la nueva | Ventana de outage de envío mientras se propaga la nueva | Rotación en dos pasos (sección 8) |
| 11 | Loggear las variables interpoladas de una plantilla | Fuga de PII, tokens o URLs firmadas en los logs | Loggear solo metadatos de negocio (sección 8) |
| 12 | Asumir que quitar de la supresión garantiza entrega futura | El dominio/buzón puede seguir muerto; vuelve a rebotar | Tratarlo como "no reintentar por ahora", no como veredicto permanente (sección 6) |

**Referencias relacionadas** (otros ficheros de este skill):

- `sending-and-errors.md` — catálogo de errores por código, límites de envío y batch.
- `webhooks-and-inbound.md` — esquema de eventos y verificación de firma en detalle.
- `domains-deliverability-and-plans.md` — DNS, autenticación de dominio, planes y cuotas.
- `sdk-node-nextjs-supabase-testing.md` — integración del SDK con frameworks concretos.
- `marketing-templates-automations-oauth.md` — broadcasts, plantillas y automatizaciones.
- `cli-mcp-and-agents.md` — CLI oficial, MCP y agentes de IA sobre el proveedor.
