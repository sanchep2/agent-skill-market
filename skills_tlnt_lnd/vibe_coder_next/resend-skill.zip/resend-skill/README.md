# resend-skill — skill de Resend para Claude Code

Skill de conocimiento sobre **Resend** (API de email transaccional y de marketing) para usarlo con
Claude Code en cualquier proyecto: envío y errores, webhooks y recepción de email, dominios y
entregabilidad, planes y cuotas, SDK de Node y Python, Next.js y Supabase, Broadcasts, Templates,
Automations, OAuth, CLI y MCP oficiales, y patrones de producción endurecidos. Incluye un helper
sin dependencias con circuit breaker y un autotest.

Todas las cifras (precios, límites, versiones) llevan la fecha en que se verificaron
(`last_verified: 2026-09-04`). Antes de prometer una cifra en producción, vuelve a comprobarla en
<https://resend.com/docs>.

## Instalación

Opción A — solo para un proyecto (recomendada):

```bash
# desde la raíz de tu repositorio
mkdir -p .claude/skills
cp -r /ruta/al/zip-descomprimido/resend-skill .claude/skills/resend-skill
```

Opción B — para todos tus proyectos (skill de usuario):

```bash
mkdir -p ~/.claude/skills
cp -r /ruta/al/zip-descomprimido/resend-skill ~/.claude/skills/resend-skill
```

Claude Code descubre el skill desde disco en la siguiente sesión. Compruébalo pidiendo, por
ejemplo, «¿cómo verifico la firma de un webhook de Resend?»: debe cargar `resend-skill`.

## Requisitos

- Claude Code con soporte de skills (directorio `.claude/skills/`).
- Para el helper y el autotest: Node.js 20 o superior y `npx` (usa `tsx` bajo demanda). No hace
  falta instalar el SDK de Resend ni ninguna otra dependencia.

## Credenciales

- `RESEND_API_KEY`: clave de API (prefijo `re_`). Ponla en una variable de entorno o en tu gestor
  de secretos. Nunca en un fichero del repositorio ni en la línea de comandos.
- `RESEND_WEBHOOK_SECRET`: secreto de firma del webhook (prefijo `whsec_`), solo si verificas
  webhooks.
- `EMAIL_FROM_ADDRESS`: remitente por defecto del helper, por ejemplo
  `Notificaciones <notificaciones@tu-dominio.com>` (el dominio debe estar verificado en Resend).

## Probar el helper

```bash
npx tsx .claude/skills/resend-skill/scripts/resend_helper.ts --help
npx tsx .claude/skills/resend-skill/scripts/resend_helper.ts --action diagnostics --format json
# RESEND_API_KEY debe estar YA en el entorno (exportada por tu gestor de secretos o tu shell de
# desarrollo); nunca se escribe en la linea de comandos ni se pasa por argumento
EMAIL_FROM_ADDRESS="Pruebas <pruebas@tu-dominio.com>" \
  npx tsx .claude/skills/resend-skill/scripts/resend_helper.ts \
  --action send --to delivered@resend.dev --subject "Prueba" --text "Hola" --dry-run
npx tsx .claude/skills/resend-skill/scripts/tests/resend_helper_test.ts
```

`--dry-run` no hace ninguna petición de red. El autotest tampoco: levanta un servidor local. Las
acciones reales (`send`, `smoke`, etc.) consumen cuota de tu cuenta de Resend; la dirección
`delivered@resend.dev` es la oficial para pruebas.

## Contenido

| Fichero | Qué cubre |
|---|---|
| `SKILL.md` | Punto de entrada: orientación, arranque rápido, patrones esenciales, errores críticos |
| `references/sending-and-errors.md` | Envío, batch, idempotencia, tabla de errores, límites, cuotas, supresiones |
| `references/webhooks-and-inbound.md` | Firma, eventos, reintentos, handler fail-closed, recepción de email |
| `references/domains-deliverability-and-plans.md` | DNS, regiones, entregabilidad, warm-up, planes y precios, multi-tenant |
| `references/sdk-node-nextjs-supabase-testing.md` | SDK Node y Python, Next.js, Supabase, otros runtimes, testing |
| `references/marketing-templates-automations-oauth.md` | Contacts, Segments, Topics, Broadcasts, Templates, Automations, Events, OAuth |
| `references/cli-mcp-and-agents.md` | CLI y MCP oficiales, skills del vendor, bandeja de entrada para agentes |
| `references/production-patterns.md` | Adapter único, seam de test, outbox, webhook fail-closed, supresión, multi-tenant |
| `scripts/resend_helper.ts` | Helper CLI y módulo sin dependencias (circuit breaker, reintentos, verificación de firma) |
| `scripts/tests/resend_helper_test.ts` | Autotest del helper, sin red |
| `evals/` | Escenarios de evaluación del skill y metodología de baseline |

## Origen

Contenido elaborado a partir de la documentación oficial de Resend, el código fuente de sus SDK y
fuentes de la comunidad, verificado el 2026-09-04. Resend es marca de su titular; este material no
está afiliado a Resend.
