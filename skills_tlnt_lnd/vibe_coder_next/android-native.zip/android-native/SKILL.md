---
name: android-native
description: >
  Build a modern, standalone native Android app in Kotlin — the whole stack, not just the UI. Use this
  skill for any native Android work: Jetpack Compose UI and Material 3 theming, MVVM/MVI architecture with
  ViewModels and StateFlow, Navigation Compose, Coroutines and Flow, networking with Retrofit/OkHttp and
  kotlinx.serialization, local persistence with Room and DataStore, dependency injection with Hilt, image
  loading with Coil, CameraX, WorkManager, edge-to-edge, and testing (JUnit, Compose UI tests, screenshot
  tests). Also use it to set up an Android project's Gradle/version-catalog toolchain, fix build or
  KSP/Hilt/Room configuration, or debug recomposition, navigation, and state issues. Trigger whenever the
  user mentions "Android app", "Jetpack Compose", "Kotlin Android", "Material 3", "ViewModel", "Room",
  "Hilt", "Retrofit", "Compose screen", or scaffolding a native Android application from scratch.
---

# Native Android (Kotlin + Jetpack Compose)

Everything you need to build a production-quality native Android app on your own: UI, architecture, data,
dependency injection, and tests. This skill is self-contained — it does not assume any shared or external
module. Your app owns its full stack.

> **Verified compilable on 2026-07-05.** The toolchain and every dependency version in this skill were
> validated by building a project that exercises the whole risk surface (Hilt + Room annotation processing,
> the Compose and serialization compiler plugins, Retrofit/OkHttp/Coil) with `./gradlew :app:assembleDebug`
> → BUILD SUCCESSFUL. When you change a version, re-run `assembleDebug` — that build is the source of truth.

## Stack & versions

| Area | Choice | Version |
|---|---|---|
| Build | Android Gradle Plugin (built-in Kotlin) | `9.2.1` (Kotlin `2.3.10`, Gradle `9.4.1`, JDK `17`) |
| SDK | compileSdk / targetSdk / minSdk | `37 / 37 / 24` |
| UI | Jetpack Compose (BOM) + Material 3 | BOM `2026.06.01` |
| Annotation processing | KSP | `2.3.9` |
| DI | Hilt | `2.60` (+ hilt-navigation-compose `1.4.0`) |
| Navigation | Navigation Compose | `2.9.8` |
| Async | Coroutines + Flow | `1.11.0` |
| Networking | Retrofit / OkHttp | `3.0.0` / `5.4.0` |
| Serialization | kotlinx.serialization (runtime) | `1.11.0` |
| Persistence | Room / DataStore | `2.8.4` / `1.2.1` |
| Lifecycle | lifecycle-*-compose | `2.11.0` |
| Images | Coil | `3.5.0` |
| Background | WorkManager | `2.11.2` |
| Camera | CameraX | `1.6.1` |

Three things about AGP's built-in Kotlin that cause most first-build failures — the full explanation and the
copy-pasteable Gradle files are in **`references/project-setup.md`**:

1. **Do not apply `org.jetbrains.kotlin.android`.** AGP 9.x bundles the Kotlin compiler; applying the
   standalone Kotlin plugin conflicts with it.
2. **The Compose compiler plugin is required.** Apply `org.jetbrains.kotlin.plugin.compose` at the Kotlin
   version (`2.3.10`); `buildFeatures { compose = true }` alone does not enable Compose.
3. **Align both Java and Kotlin to JVM 17**, or AGP fails with an "Inconsistent JVM targets" error.

## Quick start — a Compose screen backed by a Hilt ViewModel

```kotlin
// UI state is an immutable snapshot the screen renders.
data class ItemsUiState(
    val loading: Boolean = false,
    val items: List<Item> = emptyList(),
    val error: String? = null,
)

@HiltViewModel
class ItemsViewModel @Inject constructor(
    private val repository: CatalogRepository,
) : ViewModel() {
    val uiState: StateFlow<ItemsUiState> = repository.items
        .map { ItemsUiState(items = it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ItemsUiState(loading = true))

    fun refresh() = viewModelScope.launch { repository.refresh() }
}

@Composable
fun ItemsScreen(viewModel: ItemsViewModel = hiltViewModel()) {   // from androidx.hilt.lifecycle.viewmodel.compose
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    LazyColumn {
        items(state.items, key = { it.id }) { item ->
            ListItem(headlineContent = { Text(item.name) })
        }
    }
}
```

> `hiltViewModel()` now lives in **`androidx.hilt.lifecycle.viewmodel.compose`** (artifact
> `hilt-lifecycle-viewmodel-compose`); the old import in `androidx.hilt.navigation.compose` is deprecated.

## Architecture at a glance

Use **MVVM with a unidirectional data flow** (scale up to full MVI for complex, event-heavy screens):

```
Composable  ──user events──▶  ViewModel  ──calls──▶  Repository  ──▶  Retrofit API + Room DAO
    ▲                             │
    └────  StateFlow<UiState> ────┘   (collectAsStateWithLifecycle)
```

- **Composables are stateless** and render a `UiState`; they raise events to the ViewModel.
- **The ViewModel** holds a `StateFlow<UiState>`, runs work in `viewModelScope`, and never touches Android UI
  types.
- **The repository** is the single source of truth; the UI observes the database, the network refreshes it
  (offline-first).

Full patterns in `references/architecture.md` and `references/data-layer.md`.

## Suggested project structure

```
app/src/main/kotlin/com/example/app/
├── App.kt                      # @HiltAndroidApp Application
├── MainActivity.kt             # @AndroidEntryPoint, setContent { AppTheme { AppNavHost() } }
├── core/                       # theme, design system, common UI, Result helpers
├── data/
│   ├── remote/                 # Retrofit APIs + @Serializable DTOs
│   ├── local/                  # Room entities, DAOs, database, DataStore
│   └── *Repository.kt          # offline-first repositories
├── di/                         # Hilt @Module @InstallIn objects
└── feature/<name>/             # per-feature: UiState, ViewModel, screen, navigation
```

## Workflow — adding a feature

1. Define the domain model and the `UiState` for the screen.
2. Add the remote DTOs + API methods and/or the Room entity + DAO (`references/data-layer.md`).
3. Write the repository (offline-first: expose a DB-backed `Flow`, refresh from network).
4. Provide new dependencies from a Hilt `@Module` (`references/architecture.md`).
5. Build the `@HiltViewModel` with a `StateFlow<UiState>`.
6. Build the Composable screen; collect state with `collectAsStateWithLifecycle` (`references/compose.md`).
7. Register the destination in the nav graph (`references/navigation.md`).
8. Test the ViewModel and, where it earns it, the screen (`references/testing.md`).
9. `./gradlew :app:assembleDebug` and run.

## Antipatterns to avoid

- **AP-1 — State in the Composable instead of the ViewModel.** Survivable UI state (lists, form data, loading)
  belongs in the ViewModel's `StateFlow`; `remember` is only for transient UI-only state.
- **AP-2 — `collectAsState()` instead of `collectAsStateWithLifecycle()`.** The latter stops collecting when
  the screen is not visible; the former leaks work in the background.
- **AP-3 — Network or database calls from a Composable.** All data access goes through ViewModel → repository.
- **AP-4 — Unstable lambdas / unkeyed lists.** Give `LazyColumn` items a stable `key`; hoist callbacks so
  recomposition stays cheap.
- **AP-5 — Blocking the main thread.** Suspend functions must run on an appropriate dispatcher; never
  `runBlocking` on the UI.
- **AP-6 — Hardcoded strings/dimens.** Use string resources and the Material theme, not literals.
- **AP-7 — Ignoring window insets.** Call `enableEdgeToEdge()` and consume insets with `Scaffold`/`Modifier`.

## Reference files

| File | Read it when |
|---|---|
| `references/project-setup.md` | Setting up Gradle, the version catalog, the toolchain, or fixing a build |
| `references/architecture.md` | Structuring ViewModels, state, events, Hilt DI, error handling |
| `references/data-layer.md` | Networking, Room, DataStore, repositories, offline-first |
| `references/compose.md` | Building UI: theming, lists, animations, images, camera, adaptive layouts |
| `references/coroutines.md` | Flow operators, StateFlow vs SharedFlow, WorkManager background work |
| `references/navigation.md` | Type-safe Navigation Compose, nested graphs, deep links |
| `references/testing.md` | ViewModel unit tests, Compose UI tests, screenshot tests |
