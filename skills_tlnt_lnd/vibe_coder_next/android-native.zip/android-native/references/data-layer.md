# Data layer — networking, persistence, and the repository

A native app owns its whole data stack: an HTTP client, a local database, a small key–value store, and a
repository that ties them together and decides what the UI observes. All of it is wired with Hilt.

The stack: **Retrofit + OkHttp** for HTTP, **kotlinx.serialization** for JSON, **Room** for the relational
database, **DataStore (Preferences)** for lightweight settings. Every snippet here comes from a project that
compiles with the versions in `project-setup.md`.

## 1. Networking — Retrofit + OkHttp + kotlinx.serialization

Model the wire types as `@Serializable` data classes and the endpoints as a `suspend` interface. Retrofit 3
ships an official kotlinx.serialization converter (`converter-kotlinx-serialization`), so you no longer need a
third-party one.

```kotlin
// data/remote/ItemDto.kt
@Serializable
data class ItemDto(
    val id: Long,
    val name: String,
    @SerialName("image_url") val imageUrl: String? = null,
)

// data/remote/CatalogApi.kt
interface CatalogApi {
    @GET("items")
    suspend fun items(@Query("page") page: Int = 0): List<ItemDto>

    @GET("items/{id}")
    suspend fun item(@Path("id") id: Long): ItemDto
}
```

Provide the client, the `Json`, and the API from a Hilt module. Configure `OkHttpClient` with timeouts and a
logging interceptor (debug only), and register the serialization converter:

```kotlin
// di/NetworkModule.kt
@Module
@InstallIn(SingletonComponent::class)
internal object NetworkModule {

    @Provides
    @Singleton
    internal fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
    }

    @Provides
    @Singleton
    internal fun provideOkHttp(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY
                    else HttpLoggingInterceptor.Level.NONE
        })
        .build()

    @Provides
    @Singleton
    internal fun provideRetrofit(client: OkHttpClient, json: Json): Retrofit =
        Retrofit.Builder()
            .baseUrl("https://api.example.com/")
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()

    @Provides
    @Singleton
    internal fun provideCatalogApi(retrofit: Retrofit): CatalogApi =
        retrofit.create(CatalogApi::class.java)
}
```

Never call a suspend Retrofit method from the main thread without a dispatcher: they suspend, but do the JSON
parse on the caller's context. Wrap network + parse work in `withContext(Dispatchers.IO)` inside the
repository (or rely on Retrofit's own IO dispatch and keep the mapping cheap).

## 2. Persistence — Room (native, KSP)

Room 2.x with the KSP compiler is the native database. Room 3.0 exists but targets a different scope and is
still pre-stable — stay on `androidx.room` 2.8.x.

### Entities, DAOs, database

DAOs return `Flow` for reactive reads (the UI recomposes automatically when a row changes) and `suspend` for
writes. You almost never touch a raw result set — Room maps rows to your entity types for you.

```kotlin
// data/local/ItemEntity.kt
@Entity(tableName = "item")
data class ItemEntity(
    @PrimaryKey val id: Long,
    val name: String,
    @ColumnInfo(name = "image_url") val imageUrl: String?,
    val tags: List<String>,          // stored via a TypeConverter, see below
)

// data/local/ItemDao.kt
@Dao
interface ItemDao {
    @Query("SELECT * FROM item ORDER BY name")
    fun observeAll(): Flow<List<ItemEntity>>

    @Query("SELECT * FROM item WHERE id = :id")
    fun observe(id: Long): Flow<ItemEntity?>

    @Upsert
    suspend fun upsertAll(items: List<ItemEntity>)

    @Query("DELETE FROM item")
    suspend fun clear()
}

// data/local/Converters.kt — persist a List<String> as JSON text (no manual row iteration needed)
class Converters(private val json: Json) {
    @TypeConverter
    fun fromTags(value: List<String>): String = json.encodeToString(value)

    @TypeConverter
    fun toTags(value: String): List<String> = json.decodeFromString(value)
}

// data/local/AppDatabase.kt
@Database(entities = [ItemEntity::class], version = 1, exportSchema = true)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun itemDao(): ItemDao
}
```

Provide the database from a Hilt module with a single `databaseBuilder` — there is no per-platform builder to
juggle:

```kotlin
// di/DatabaseModule.kt
@Module
@InstallIn(SingletonComponent::class)
internal object DatabaseModule {

    @Provides
    @Singleton
    internal fun provideDatabase(
        @ApplicationContext context: Context,
        json: Json,
    ): AppDatabase = Room.databaseBuilder(context, AppDatabase::class.java, "app.db")
        .addTypeConverter(Converters(json))
        .fallbackToDestructiveMigrationOnDowngrade(dropAllTables = true)
        .build()

    @Provides
    internal fun provideItemDao(db: AppDatabase): ItemDao = db.itemDao()
}
```

### Migrations

Bump `version` and add a `Migration` (or an `@AutoMigration` with a spec) for every schema change. Enable
schema export so migrations are testable:

```kotlin
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(connection: SQLiteConnection) {
        connection.execSQL("ALTER TABLE item ADD COLUMN favorite INTEGER NOT NULL DEFAULT 0")
    }
}
// ...databaseBuilder(...).addMigrations(MIGRATION_1_2)
```

Point the KSP schema directory at your source tree so the exported JSON is version-controlled:

```kotlin
// app/build.gradle.kts
ksp { arg("room.schemaLocation", "$projectDir/schemas") }
android { sourceSets["androidTest"].assets.srcDir("$projectDir/schemas") }
```

## 3. Preferences — DataStore

DataStore replaces `SharedPreferences`. It is coroutine/Flow based and safe to read on any dispatcher.

```kotlin
private val Context.dataStore by preferencesDataStore(name = "settings")

class SettingsStore(private val context: Context) {
    private val darkModeKey = booleanPreferencesKey("dark_mode")

    val darkMode: Flow<Boolean> = context.dataStore.data.map { it[darkModeKey] ?: false }

    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { it[darkModeKey] = enabled }
    }
}
```

Provide it as a `@Singleton` from a Hilt module the same way as the others.

## 4. Repository — offline-first

The repository is the single entry point for a feature's data. The offline-first pattern: **the UI observes
the database; the network only refreshes it.** Reads never block on the network, and the screen shows cached
data instantly.

```kotlin
// data/CatalogRepository.kt
@Singleton
class CatalogRepository @Inject constructor(
    private val api: CatalogApi,
    private val dao: ItemDao,
) {
    // The UI collects this. It emits cached rows immediately and again after any refresh.
    val items: Flow<List<Item>> =
        dao.observeAll().map { rows -> rows.map(ItemEntity::toDomain) }

    // Fire-and-forget refresh; result surfaces through the Flow above.
    suspend fun refresh(): Result<Unit> = runCatching {
        val remote = withContext(Dispatchers.IO) { api.items() }
        dao.upsertAll(remote.map(ItemDto::toEntity))
    }
}
```

Map explicitly between the three shapes — DTO (wire), entity (storage), and domain (what the ViewModel uses) —
with small extension functions. Keeping them separate means a backend rename never ripples into your UI:

```kotlin
fun ItemDto.toEntity() = ItemEntity(id, name, imageUrl, tags = emptyList())
fun ItemEntity.toDomain() = Item(id = id, name = name, imageUrl = imageUrl)
```

### Error mapping

Turn transport failures into a domain-level result the UI can render. Do not leak `HttpException`/`IOException`
into the UI layer:

```kotlin
fun Throwable.toUserMessage(): String = when (this) {
    is IOException -> "No connection. Check your network and try again."
    is HttpException -> when (code()) {
        401, 403 -> "Your session expired. Sign in again."
        in 500..599 -> "The server had a problem. Try again shortly."
        else -> "Something went wrong."
    }
    else -> "Something went wrong."
}

fun Throwable.isRetryable(): Boolean = this is IOException || (this is HttpException && code() >= 500)
```

## Checklist

- [ ] Wire models are `@Serializable`; endpoints are a `suspend` interface.
- [ ] `OkHttpClient` has timeouts; logging interceptor is debug-only.
- [ ] DAO reads return `Flow`; writes are `suspend`.
- [ ] Schema export is on and migrations exist for every `version` bump.
- [ ] The repository exposes a database-backed `Flow`; the network only refreshes it.
- [ ] Transport exceptions are mapped to domain messages before reaching the UI.
