# Navigation Compose — Type-Safe Routes (2.9.8)

Type-safe navigation for a native Android app: `@Serializable` routes, `NavHost`, nested graphs, per-tab back stacks, deep links, argument passing, custom `NavType`, animated transitions, and Hilt-scoped `ViewModel`s.

## Table of Contents

1. [Setup & Versions](#1-setup--versions)
2. [Route Definitions](#2-route-definitions)
3. [NavHost Setup](#3-navhost-setup)
4. [Nested Navigation Graphs](#4-nested-navigation-graphs)
5. [Bottom Navigation with Per-Tab Back Stack](#5-bottom-navigation-with-per-tab-back-stack)
6. [Deep Linking](#6-deep-linking)
7. [Argument Passing & SavedStateHandle](#7-argument-passing--savedstatehandle)
8. [Custom NavType](#8-custom-navtype)
9. [Animated Transitions](#9-animated-transitions)
10. [Integrating with a Hilt ViewModel](#10-integrating-with-a-hilt-viewmodel)

---

## 1. Setup & Versions

Build-verified 2026-07-05.

```kotlin
// build.gradle.kts (app module)
plugins {
    id("org.jetbrains.kotlin.plugin.serialization") version "2.3.10"
    // ... android, kotlin.android, kotlin.compose, hilt, ksp
}

dependencies {
    implementation("androidx.navigation:navigation-compose:2.9.8")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.11.0")
    implementation("androidx.hilt:hilt-navigation-compose:1.4.0")
    // Compose BOM supplies animation + material3 artifacts
}
```

Kotlin 2.3.10. The serialization plugin generates the `KSerializer` that Navigation
Compose reads at runtime to encode/decode routes to and from bundle arguments.

---

## 2. Route Definitions

Routes are plain Kotlin types annotated with `@Serializable`. No string route
constants, no manual argument keys.

```kotlin
package com.example.app.navigation

import kotlinx.serialization.Serializable

// Destinations without arguments → @Serializable object
@Serializable object Home
@Serializable object ItemList
@Serializable object Settings

// Destinations with arguments → @Serializable data class
@Serializable data class ItemDetail(val id: Long)

// Optional arguments carry a default → they become query parameters in deep links
@Serializable data class ItemSearch(val query: String = "", val sortBy: String = "recent")

// Graph markers → @Serializable object
@Serializable object CatalogGraph
@Serializable object SettingsGraph
```

Rules:

- Required fields (no default) become **path parameters** in deep links.
- Optional fields (with a default) become **query parameters**.
- Primitives, enums, and `Serializable` types work out of the box; anything else
  needs a custom `NavType` (see §8).

---

## 3. NavHost Setup

A single `NavHost` owns the graph. Default transitions declared here apply to every
destination that does not override them.

```kotlin
package com.example.app.navigation

import androidx.compose.animation.*
import androidx.compose.animation.AnimatedContentTransitionScope.SlideDirection
import androidx.compose.animation.core.tween
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
// + NavHostController, Composable, Modifier

@Composable
fun AppNavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier,
) {
    NavHost(
        navController = navController,
        startDestination = CatalogGraph,
        modifier = modifier,
        enterTransition = { fadeIn(tween(300)) + slideIntoContainer(SlideDirection.Start, tween(300)) },
        exitTransition = { fadeOut(tween(300)) + slideOutOfContainer(SlideDirection.Start, tween(300)) },
        popEnterTransition = { fadeIn(tween(300)) + slideIntoContainer(SlideDirection.End, tween(300)) },
        popExitTransition = { fadeOut(tween(300)) + slideOutOfContainer(SlideDirection.End, tween(300)) },
    ) {
        // Nested graphs contributed by extension functions (§4)
        catalogGraph(navController)
        settingsGraph(navController)
    }
}
```

Wire it into the activity with a remembered controller:

```kotlin
package com.example.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.rememberNavController
import com.example.app.navigation.AppScaffold
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                val navController = rememberNavController()
                AppScaffold(navController)
                // The NavHost resolves any launch/deep-link intent automatically.
            }
        }
    }
}
```

---

## 4. Nested Navigation Graphs

Group related destinations under a graph with `navigation<T>()`. Expose each graph
as a `NavGraphBuilder` extension so the root `NavHost` stays small and each feature
owns its wiring.

```kotlin
package com.example.app.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import androidx.navigation.compose.navigation
import androidx.navigation.toRoute
import com.example.app.feature.catalog.ItemDetailScreen
import com.example.app.feature.catalog.ItemListScreen

fun NavGraphBuilder.catalogGraph(navController: NavHostController) {
    navigation<CatalogGraph>(startDestination = ItemList) {
        composable<ItemList> {
            ItemListScreen(
                onItemClick = { id -> navController.navigate(ItemDetail(id)) },
            )
        }
        composable<ItemDetail> { backStackEntry ->
            val route = backStackEntry.toRoute<ItemDetail>()
            ItemDetailScreen(
                itemId = route.id,
                onBack = { navController.navigateUp() },
            )
        }
    }
}

fun NavGraphBuilder.settingsGraph(navController: NavHostController) {
    navigation<SettingsGraph>(startDestination = Settings) {
        composable<Settings> {
            SettingsScreen(onBack = { navController.navigateUp() })
        }
    }
}
```

`toRoute<T>()` on the `NavBackStackEntry` decodes the typed route back from bundle
arguments — the counterpart to `navigate(ItemDetail(id))`.

---

## 5. Bottom Navigation with Per-Tab Back Stack

Each tab keeps its own independent back stack. The `saveState` / `restoreState` /
`launchSingleTop` trio is what makes tab switching feel native.

```kotlin
package com.example.app.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
// + Composable, getValue

enum class TopLevelDestination(
    val route: Any,          // an @Serializable route or graph marker
    val icon: ImageVector,
    val label: String,
) {
    HOME(CatalogGraph, Icons.Filled.Home, "Home"),
    ITEMS(ItemList, Icons.Filled.List, "Items"),
    SETTINGS(SettingsGraph, Icons.Filled.Settings, "Settings"),
}

@Composable
fun BottomNavBar(navController: NavHostController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    NavigationBar {
        TopLevelDestination.entries.forEach { dest ->
            val selected = currentDestination
                ?.hierarchy
                ?.any { it.hasRoute(dest.route::class) } == true
            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(dest.route) {
                        // Pop back to the graph's start so tabs don't stack on each other.
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true    // save the outgoing tab's back stack
                        }
                        launchSingleTop = true  // no duplicate copies of the same tab
                        restoreState = true     // restore the incoming tab's back stack
                    }
                },
                icon = { Icon(dest.icon, contentDescription = dest.label) },
                label = { Text(dest.label) },
            )
        }
    }
}
```

Compose the scaffold around it:

```kotlin
package com.example.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController

@Composable
fun AppScaffold(navController: NavHostController) {
    Scaffold(
        bottomBar = { BottomNavBar(navController) },
    ) { innerPadding ->
        AppNavGraph(
            navController = navController,
            modifier = androidx.compose.ui.Modifier.padding(innerPadding),
        )
    }
}
```

Selecting against `currentDestination.hierarchy` (instead of only the leaf) keeps the
correct tab highlighted even after navigating deeper into that tab's graph.

---

## 6. Deep Linking

### Manifest declaration

```xml
<activity
    android:name=".MainActivity"
    android:exported="true">
    <intent-filter android:autoVerify="true">
        <action android:name="android.intent.action.VIEW" />
        <category android:name="android.intent.category.DEFAULT" />
        <category android:name="android.intent.category.BROWSABLE" />
        <data android:scheme="https" android:host="app.example.com" />
        <data android:scheme="exampleapp" android:host="items" />
    </intent-filter>
</activity>
```

### Route-based deep links

Attach `navDeepLink<T>()` to the destination. The route's field names drive the URI
shape — no separate pattern strings to keep in sync.

```kotlin
import androidx.navigation.navDeepLink

composable<ItemDetail>(
    deepLinks = listOf(
        navDeepLink<ItemDetail>(basePath = "https://app.example.com/items"),
        navDeepLink<ItemDetail>(basePath = "exampleapp://items"),
    ),
) { backStackEntry ->
    val route = backStackEntry.toRoute<ItemDetail>()
    ItemDetailScreen(itemId = route.id, onBack = { /* ... */ })
}
```

With `@Serializable data class ItemDetail(val id: Long)`:

- `exampleapp://items/42` → `ItemDetail(id = 42)` — `id` is a required path parameter.
- `https://app.example.com/items/42` → the same route.

Optional fields map to query parameters:

```kotlin
composable<ItemSearch>(
    deepLinks = listOf(navDeepLink<ItemSearch>(basePath = "exampleapp://search")),
) { backStackEntry ->
    val route = backStackEntry.toRoute<ItemSearch>()
    ItemSearchScreen(query = route.query, sortBy = route.sortBy)
}
// exampleapp://search?query=kotlin&sortBy=newest → ItemSearch("kotlin", "newest")
```

A destination is only reachable by deep link if it declares explicit `deepLinks`,
which prevents unintended entry into arbitrary screens. To trigger one in-process,
fire an `ACTION_VIEW` intent scoped to the app package:

```kotlin
import android.content.Intent
import androidx.core.net.toUri

startActivity(Intent(Intent.ACTION_VIEW, "exampleapp://items/42".toUri()).apply {
    setPackage(packageName)
})
```

---

## 7. Argument Passing & SavedStateHandle

Inside a `ViewModel`, decode the route straight from `SavedStateHandle` — no manual
key lookups, and it survives process death.

```kotlin
package com.example.app.feature.catalog

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.navigation.toRoute
import com.example.app.navigation.ItemDetail

class ItemDetailViewModel(
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    private val route: ItemDetail = savedStateHandle.toRoute<ItemDetail>()
    val itemId: Long = route.id

    init {
        loadItem(itemId)
    }

    private fun loadItem(id: Long) { /* ... */ }
}
```

`savedStateHandle.toRoute<ItemDetail>()` reads the exact arguments that
`navigate(ItemDetail(id))` encoded — the route type is the single source of truth for
both directions.

---

## 8. Custom NavType

Primitives and `Serializable` types are handled automatically. For a structured
argument that Navigation cannot serialize by default, register a `NavType` and pass it
through `typeMap`.

```kotlin
package com.example.app.navigation

import android.os.Bundle
import androidx.core.os.BundleCompat
import androidx.navigation.NavType
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class ItemFilter(val categories: List<String>, val minRating: Float)

val ItemFilterNavType = object : NavType<ItemFilter>(isNullableAllowed = false) {
    override fun get(bundle: Bundle, key: String): ItemFilter? =
        bundle.getString(key)?.let { Json.decodeFromString(it) }

    override fun parseValue(value: String): ItemFilter =
        Json.decodeFromString(value)

    override fun serializeAsValue(value: ItemFilter): String =
        Json.encodeToString(value)

    override fun put(bundle: Bundle, key: String, value: ItemFilter) {
        bundle.putString(key, Json.encodeToString(value))
    }
}

@Serializable
data class FilteredItems(val filter: ItemFilter)
```

Register it wherever the route is declared:

```kotlin
import kotlin.reflect.typeOf

composable<FilteredItems>(
    typeMap = mapOf(typeOf<ItemFilter>() to ItemFilterNavType),
) { backStackEntry ->
    val route = backStackEntry.toRoute<FilteredItems>()
    FilteredItemsScreen(filter = route.filter)
}
```

The same `typeMap` must be supplied to any `navDeepLink<FilteredItems>()` that targets
this destination so deep links can decode the custom argument.

---

## 9. Animated Transitions

Transitions are native to Navigation Compose. Declare defaults on the `NavHost` (§3)
and override per destination when a screen deserves a different motion.

```kotlin
composable<ItemDetail>(
    enterTransition = { slideIntoContainer(SlideDirection.Up, tween(400)) },
    exitTransition = { slideOutOfContainer(SlideDirection.Down, tween(400)) },
    popEnterTransition = { fadeIn(tween(250)) },
    popExitTransition = { slideOutOfContainer(SlideDirection.Down, tween(400)) },
) { /* ... */ }
```

Resolution order (first match wins):

1. Composable-level transition, if defined.
2. Enclosing graph-level transition.
3. Root `NavHost`-level transition.
4. Default fade, if nothing above is defined.

Common patterns:

```kotlin
// Horizontal slide — typical forward/back
enterTransition = { slideIntoContainer(SlideDirection.Start, tween(300)) }
popExitTransition = { slideOutOfContainer(SlideDirection.End, tween(300)) }

// Vertical slide — modal-like
enterTransition = { slideIntoContainer(SlideDirection.Up, tween(400)) }
popExitTransition = { slideOutOfContainer(SlideDirection.Down, tween(400)) }

// Fade only
enterTransition = { fadeIn(tween(300)) }
exitTransition = { fadeOut(tween(300)) }

// Scale + fade — zoom in/out
enterTransition = { scaleIn(initialScale = 0.9f, animationSpec = tween(300)) + fadeIn(tween(300)) }
exitTransition = { scaleOut(targetScale = 1.1f, animationSpec = tween(300)) + fadeOut(tween(300)) }
```

---

## 10. Integrating with a Hilt ViewModel

Annotate the `ViewModel` with `@HiltViewModel` and inject `SavedStateHandle` (Hilt
provides it) alongside your dependencies. In the composable, obtain it with
`hiltViewModel()` — the instance is scoped to the destination's `NavBackStackEntry`, so
it survives configuration changes and is cleared when the destination leaves the stack.

```kotlin
package com.example.app.feature.catalog

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.example.app.domain.Item
import com.example.app.domain.ItemRepository
import com.example.app.navigation.ItemDetail
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ItemDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: ItemRepository,
) : ViewModel() {

    private val itemId: Long = savedStateHandle.toRoute<ItemDetail>().id

    private val _item = MutableStateFlow<Item?>(null)
    val item: StateFlow<Item?> = _item.asStateFlow()

    init {
        viewModelScope.launch {
            _item.value = repository.getItem(itemId)
        }
    }
}
```

Collect it in the screen:

```kotlin
package com.example.app.feature.catalog

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel

@Composable
fun ItemDetailScreen(
    itemId: Long,
    onBack: () -> Unit,
    viewModel: ItemDetailViewModel = hiltViewModel(),
) {
    val item by viewModel.item.collectAsState()
    // Render `item`; call onBack() from the top app bar navigation icon.
}
```

Notes:

- `hiltViewModel()` is imported from `androidx.hilt.lifecycle.viewmodel.compose`.
- No factory boilerplate: Hilt reads the route arguments through the injected
  `SavedStateHandle`, so the screen only needs the `id` for display and can otherwise
  rely on the `ViewModel` for its state.
- The activity hosting the graph must be annotated `@AndroidEntryPoint` (see §3) for
  `hiltViewModel()` to resolve.
```
