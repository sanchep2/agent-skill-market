# Project Setup — Gradle, toolchain, and dependency catalog

> Verified compilable: this exact configuration was built end-to-end with
> `./gradlew :app:assembleDebug` → **BUILD SUCCESSFUL** on **2026-07-05** (JDK 17, Gradle 9.4.1,
> Android SDK platform 37, build-tools 37.0.0). Every version below is the one that actually compiled,
> not a guess. If you bump a version, re-run `assembleDebug` before trusting it.

## The toolchain, and why these versions lock together

Modern AGP (9.x) ships **built-in Kotlin**: the Kotlin compiler is bundled with the Android Gradle
Plugin. You **do not** apply `org.jetbrains.kotlin.android`, and you **do not** pin a standalone Kotlin
Gradle Plugin version — AGP owns it. This removes a whole class of "which Kotlin works with which AGP"
breakage, but it has three consequences that trip people up:

1. **AGP fixes the effective Kotlin version.** AGP **9.2.x** bundles Kotlin **2.3.10**. Any Kotlin
   *compiler plugin* you add (Compose, serialization, kapt-replacements) **must be applied at that same
   version (2.3.10)** or the build fails with a compiler-version mismatch.
2. **The Compose compiler plugin is still required.** `buildFeatures { compose = true }` alone is **not**
   enough. You must also apply `org.jetbrains.kotlin.plugin.compose` at the Kotlin version.
3. **KSP must be built-in-Kotlin-aware.** Use a KSP release that supports AGP built-in Kotlin (2.3.6+).
   KSP drives Hilt and Room annotation processing.

| Piece | Version | Notes |
|---|---|---|
| Android Gradle Plugin | `9.2.1` | built-in Kotlin; min & default Gradle **9.4.1**; **JDK 17**; max compileSdk **37** |
| Kotlin (effective, via AGP) | `2.3.10` | do **not** apply `org.jetbrains.kotlin.android` |
| Compose compiler plugin | `2.3.10` | `org.jetbrains.kotlin.plugin.compose`, pinned to the Kotlin version |
| Kotlin serialization plugin | `2.3.10` | `org.jetbrains.kotlin.plugin.serialization`, pinned to the Kotlin version |
| KSP | `2.3.9` | `com.google.devtools.ksp`; built-in-Kotlin aware (2.3.6+) |
| Gradle | `9.4.1` | wrapper distribution |
| JDK | `17` | required by AGP 9.2 |
| compileSdk / targetSdk / minSdk | `37 / 37 / 24` | API 37 is the current finalized platform |

> On overriding Kotlin: you *can* force a newer Kotlin than AGP's built-in, but it is unsupported by the
> AGP↔Kotlin compatibility table and, at the time of writing, a newer Kotlin regressed annotation-processor
> code generation for dependency-injection modules (colon-in-module-name codegen bug). Stay on the
> AGP-provided Kotlin unless you have a concrete reason and have re-run the full build.

## `gradle/libs.versions.toml` (version catalog — single source of truth)

```toml
[versions]
agp = "9.2.1"
kotlin = "2.3.10"          # AGP 9.2 built-in Kotlin; compose/serialization plugins pin to this
ksp = "2.3.9"
hilt = "2.60"
room = "2.8.4"
coroutines = "1.11.0"
serializationRuntime = "1.11.0"
composeBom = "2026.06.01"
activityCompose = "1.13.0"
coreKtx = "1.19.0"
lifecycle = "2.11.0"
navigationCompose = "2.9.8"
hiltNavigationCompose = "1.4.0"
datastore = "1.2.1"
work = "2.11.2"
camerax = "1.6.1"
adaptive = "1.2.0"        # androidx.compose.material3.adaptive.* (own version line, not in the BOM)
retrofit = "3.0.0"
okhttp = "5.4.0"
coil = "3.5.0"

[libraries]
# Compose (versions come from the BOM)
compose-bom               = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }
compose-ui                = { group = "androidx.compose.ui", name = "ui" }
compose-ui-tooling-preview= { group = "androidx.compose.ui", name = "ui-tooling-preview" }
compose-ui-tooling        = { group = "androidx.compose.ui", name = "ui-tooling" }
compose-material3         = { group = "androidx.compose.material3", name = "material3" }
compose-material3-adaptive-nav = { group = "androidx.compose.material3", name = "material3-adaptive-navigation-suite" }
compose-material3-adaptive        = { group = "androidx.compose.material3.adaptive", name = "adaptive", version.ref = "adaptive" }
compose-material3-adaptive-layout = { group = "androidx.compose.material3.adaptive", name = "adaptive-layout", version.ref = "adaptive" }
compose-material3-adaptive-navigation = { group = "androidx.compose.material3.adaptive", name = "adaptive-navigation", version.ref = "adaptive" }

androidx-core-ktx         = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-activity-compose  = { group = "androidx.activity", name = "activity-compose", version.ref = "activityCompose" }
androidx-lifecycle-runtime-compose = { group = "androidx.lifecycle", name = "lifecycle-runtime-compose", version.ref = "lifecycle" }
androidx-lifecycle-viewmodel-compose = { group = "androidx.lifecycle", name = "lifecycle-viewmodel-compose", version.ref = "lifecycle" }
androidx-navigation-compose = { group = "androidx.navigation", name = "navigation-compose", version.ref = "navigationCompose" }

hilt-android              = { group = "com.google.dagger", name = "hilt-android", version.ref = "hilt" }
hilt-compiler             = { group = "com.google.dagger", name = "hilt-compiler", version.ref = "hilt" }
hilt-navigation-compose   = { group = "androidx.hilt", name = "hilt-navigation-compose", version.ref = "hiltNavigationCompose" }
hilt-lifecycle-viewmodel-compose = { group = "androidx.hilt", name = "hilt-lifecycle-viewmodel-compose", version.ref = "hiltNavigationCompose" }

room-runtime              = { group = "androidx.room", name = "room-runtime", version.ref = "room" }
room-ktx                  = { group = "androidx.room", name = "room-ktx", version.ref = "room" }
room-compiler             = { group = "androidx.room", name = "room-compiler", version.ref = "room" }

datastore-preferences     = { group = "androidx.datastore", name = "datastore-preferences", version.ref = "datastore" }
work-runtime-ktx          = { group = "androidx.work", name = "work-runtime-ktx", version.ref = "work" }
camera-camera2            = { group = "androidx.camera", name = "camera-camera2", version.ref = "camerax" }
camera-lifecycle          = { group = "androidx.camera", name = "camera-lifecycle", version.ref = "camerax" }
camera-view               = { group = "androidx.camera", name = "camera-view", version.ref = "camerax" }
camera-compose            = { group = "androidx.camera", name = "camera-compose", version.ref = "camerax" }

kotlinx-coroutines-android = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-android", version.ref = "coroutines" }
kotlinx-serialization-json = { group = "org.jetbrains.kotlinx", name = "kotlinx-serialization-json", version.ref = "serializationRuntime" }

retrofit                  = { group = "com.squareup.retrofit2", name = "retrofit", version.ref = "retrofit" }
retrofit-serialization    = { group = "com.squareup.retrofit2", name = "converter-kotlinx-serialization", version.ref = "retrofit" }
okhttp                    = { group = "com.squareup.okhttp3", name = "okhttp", version.ref = "okhttp" }
okhttp-logging            = { group = "com.squareup.okhttp3", name = "logging-interceptor", version.ref = "okhttp" }

coil-compose              = { group = "io.coil-kt.coil3", name = "coil-compose", version.ref = "coil" }
coil-network-okhttp       = { group = "io.coil-kt.coil3", name = "coil-network-okhttp", version.ref = "coil" }

# Test
junit                     = { group = "junit", name = "junit", version = "4.13.2" }
kotlinx-coroutines-test   = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-test", version.ref = "coroutines" }
turbine                   = { group = "app.cash.turbine", name = "turbine", version = "1.2.1" }
androidx-ui-test-junit4   = { group = "androidx.compose.ui", name = "ui-test-junit4" }
androidx-ui-test-manifest = { group = "androidx.compose.ui", name = "ui-test-manifest" }
hilt-android-testing      = { group = "com.google.dagger", name = "hilt-android-testing", version.ref = "hilt" }

[plugins]
android-application   = { id = "com.android.application", version.ref = "agp" }
ksp                   = { id = "com.google.devtools.ksp", version.ref = "ksp" }
hilt                  = { id = "com.google.dagger.hilt.android", version.ref = "hilt" }
compose-compiler      = { id = "org.jetbrains.kotlin.plugin.compose", version.ref = "kotlin" }
kotlin-serialization  = { id = "org.jetbrains.kotlin.plugin.serialization", version.ref = "kotlin" }
```

## `settings.gradle.kts`

```kotlin
pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositories { google(); mavenCentral() }
}
rootProject.name = "app"
include(":app")
```

## Root `build.gradle.kts`

```kotlin
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.ksp) apply false
    alias(libs.plugins.hilt) apply false
    alias(libs.plugins.compose.compiler) apply false
    alias(libs.plugins.kotlin.serialization) apply false
}
```

> Catalog accessors turn `-` into `.`: an alias named `android-application` is referenced as
> `libs.plugins.android.application`. Getting this wrong yields a cryptic "Unresolved reference 'minus'".

## `app/build.gradle.kts`

```kotlin
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.compose.compiler)      // REQUIRED for Compose (not optional under Kotlin 2.0+)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
    // NOTE: no org.jetbrains.kotlin.android — AGP provides built-in Kotlin
}

android {
    namespace = "com.example.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.example.app"
        minSdk = 24
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures { compose = true }

    // Align BOTH Java and Kotlin to JVM 17, or AGP fails with
    // "Inconsistent JVM targets between Java and Kotlin compile tasks: 11 and 17".
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

dependencies {
    val composeBom = platform(libs.compose.bom)
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.tooling.preview)
    debugImplementation(libs.compose.ui.tooling)
    implementation(libs.compose.material3)
    implementation(libs.compose.material3.adaptive.nav)
    implementation(libs.compose.material3.adaptive)          // ListDetailPaneScaffold, etc.
    implementation(libs.compose.material3.adaptive.layout)
    implementation(libs.compose.material3.adaptive.navigation)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.navigation.compose)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)
    implementation(libs.hilt.lifecycle.viewmodel.compose)

    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)

    implementation(libs.datastore.preferences)
    implementation(libs.work.runtime.ktx)
    implementation(libs.camera.camera2)
    implementation(libs.camera.lifecycle)
    implementation(libs.camera.view)
    implementation(libs.camera.compose)

    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.serialization.json)

    implementation(libs.retrofit)
    implementation(libs.retrofit.serialization)
    implementation(libs.okhttp)
    implementation(libs.okhttp.logging)

    implementation(libs.coil.compose)
    implementation(libs.coil.network.okhttp)

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    testImplementation(libs.turbine)
    androidTestImplementation(libs.androidx.ui.test.junit4)
    debugImplementation(libs.androidx.ui.test.manifest)
    androidTestImplementation(libs.hilt.android.testing)
    kspAndroidTest(libs.hilt.compiler)
}
```

## `gradle.properties`

```properties
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
org.gradle.caching=true
org.gradle.configuration-cache=true
kotlin.code.style=official
```

## Gradle wrapper — `gradle/wrapper/gradle-wrapper.properties`

```properties
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-9.4.1-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
```

## Application class (Hilt entry point)

```kotlin
// App.kt
package com.example.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class App : Application()
```

Register it in `AndroidManifest.xml` with `android:name=".App"`. Every screen that resolves a
`@HiltViewModel` must live under an `@AndroidEntryPoint` activity.

## Verify the setup

```bash
./gradlew :app:assembleDebug     # full compile + KSP (Hilt/Room) + dex + package
./gradlew :app:testDebugUnitTest # JVM unit tests
```

A green `assembleDebug` proves the plugin/compiler/KSP interlock is intact. Treat it as the gate whenever
you change a version in the catalog.
