# App Architecture — MVVM with Unidirectional Data Flow (scaling to MVI)

A single, self-contained Android app: UI → ViewModel → Repository → Retrofit + Room, all in one module, wired with Hilt.

> Build-verified 2026-07-05 · Kotlin 2.3.10 (AGP 9.2.1 built-in) · Coroutines 1.11.0 · Hilt 2.60 · Room 2.8.4 · Lifecycle 2.11.0 · Compose BOM 2026.06.01

## Table of Contents

1. [The layered picture](#1-the-layered-picture)
2. [Immutable UiState](#2-immutable-uistate)
3. [One-off UI events via Channel](#3-one-off-ui-events-via-channel)
4. [The ViewModel as a reducer](#4-the-viewmodel-as-a-reducer)
5. [Optimistic updates with rollback](#5-optimistic-updates-with-rollback)
6. [Debounced search with flatMapLatest](#6-debounced-search-with-flatmaplatest)
7. [Pagination](#7-pagination)
8. [Offline-first wiring](#8-offline-first-wiring)
9. [The Compose screen](#9-the-compose-screen)
10. [Hilt dependency injection](#10-hilt-dependency-injection)
11. [Error mapping helpers](#11-error-mapping-helpers)
12. [When to reach for full MVI](#12-when-to-reach-for-full-mvi)

---

## 1. The layered picture

Everything below lives in this one app module. There is no external library holding the
business logic — the repository, the Retrofit service, and the Room DAO are all local
classes you own and can open in the same project.

```
┌─────────────────────────────────────────────────────────┐
│  UI  ·  @Composable ItemsScreen                          │
│        collectAsStateWithLifecycle() + hiltViewModel()   │
│        renders UiState, forwards user intent via onEvent │
└───────────────▲───────────────────────┬─────────────────┘
        StateFlow<UiState>          onEvent(UiEvent)
                │                        ▼
┌─────────────────────────────────────────────────────────┐
│  ViewModel  ·  ItemsViewModel (@HiltViewModel)           │
│        reducer: holds StateFlow, maps events to state    │
│        one-off effects via Channel.receiveAsFlow()       │
└───────────────▲───────────────────────┬─────────────────┘
         Flow<List<Item>>          suspend calls
         Result<Unit>                    ▼
┌─────────────────────────────────────────────────────────┐
│  Repository  ·  CatalogRepository (interface + impl)     │
│        single source of truth; decides cache vs network  │
└──────────┬──────────────────────────────┬───────────────┘
           ▼                               ▼
┌──────────────────────┐        ┌──────────────────────────┐
│  Room  ·  ItemDao     │        │  Retrofit ·  CatalogApi   │
│  observe() → Flow     │        │  suspend fun fetchItems() │
│  upsert(...)          │        │  returns DTOs             │
└──────────────────────┘        └──────────────────────────┘
```

Data flows **one way**: Room and Retrofit feed the repository, the repository feeds the
ViewModel, the ViewModel exposes an immutable `StateFlow<UiState>`, and the UI reads it.
User intent travels back as discrete events through a single `onEvent` funnel — never as
direct mutations of state from the UI. The domain model is deliberately tiny:

```kotlin
package com.example.app.catalog.domain

data class Item(
    val id: Long,
    val name: String,
    val imageUrl: String?,
)
```

---

## 2. Immutable UiState

Model the whole screen as one immutable value. A `sealed interface` captures the
mutually-exclusive top-level modes (loading / content / error); the content case carries
an `@Immutable data class` so Compose can skip recomposition when the reference is stable.

```kotlin
package com.example.app.catalog.ui

import androidx.compose.runtime.Immutable
import com.example.app.catalog.domain.Item

@Immutable
sealed interface ItemsUiState {

    data object Loading : ItemsUiState

    @Immutable
    data class Content(
        val items: List<Item>,
        val query: String = "",
        val favorites: Set<Long> = emptySet(),
        val isRefreshing: Boolean = false,
        val isAppending: Boolean = false,
        val hasMorePages: Boolean = true,
    ) : ItemsUiState

    data class Error(
        val message: String,
        val canRetry: Boolean = true,
    ) : ItemsUiState
}
```

Rules that keep this honest:

- **Never expose a `MutableStateFlow` or mutable collections.** The public property is
  `StateFlow<ItemsUiState>`; the lists inside are read-only `List`/`Set`.
- **`copy()` is the only way to advance state.** Each event produces a brand-new value, so
  the previous state is always available for rollback (see §5).
- **One state, one source of truth.** No parallel `LiveData`, no scattered booleans in the
  UI. If it affects the screen, it lives in `ItemsUiState`.

---

## 3. One-off UI events via Channel

State describes *what the screen looks like*. Some things are not state — navigating once,
showing a single snackbar, scrolling to top. These are **events**: they fire once and must
not replay. Model them with a `Channel(BUFFERED).receiveAsFlow()`.

```kotlin
sealed interface ItemsEffect {
    data class NavigateToDetail(val id: Long) : ItemsEffect
    data class ShowSnackbar(val message: String) : ItemsEffect
    data object ScrollToTop : ItemsEffect
}
```

```kotlin
// inside the ViewModel
private val _effects = Channel<ItemsEffect>(Channel.BUFFERED)
val effects: Flow<ItemsEffect> = _effects.receiveAsFlow()
```

**Why a Channel and not a `SharedFlow`?**

- A `MutableSharedFlow(replay = 0)` is *hot* and only delivers to collectors that are
  active at emit time. During a configuration change the collector detaches for a beat, and
  any effect emitted in that window is **dropped** — a navigation that silently never
  happens, the worst kind of bug to reproduce.
- A `Channel(Channel.BUFFERED)` **buffers** emissions while no one is collecting and
  hands them over the moment the collector reconnects. Nothing is lost across rotation.
- `receiveAsFlow()` gives **exactly-once** delivery: each element is received by a single
  collector, so a buffered `NavigateToDetail` cannot fire twice.
- If you gave a `SharedFlow` a `replay` cache to avoid the drop, you'd trade the drop for a
  *duplicate* — the cached effect re-emits on every new subscription (e.g. it navigates
  again after returning to the screen). Channels sidestep both failure modes.

Collect them in a lifecycle-aware `LaunchedEffect` on the screen (see §9).

---

## 4. The ViewModel as a reducer

The ViewModel is the single place that turns events into new state. It holds a private
`MutableStateFlow`, exposes it as a read-only `StateFlow`, and offers exactly one entry
point for the UI: `onEvent`.

```kotlin
package com.example.app.catalog.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.app.catalog.data.CatalogRepository
import com.example.app.core.error.isRetryable
import com.example.app.core.error.toUserMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

sealed interface ItemsEvent {
    data class QueryChanged(val query: String) : ItemsEvent
    data class ToggleFavorite(val id: Long) : ItemsEvent
    data class ItemClicked(val id: Long) : ItemsEvent
    data object Refresh : ItemsEvent
    data object LoadNextPage : ItemsEvent
    data object Retry : ItemsEvent
}

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel
class ItemsViewModel @Inject constructor(
    private val repository: CatalogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow<ItemsUiState>(ItemsUiState.Loading)

    private val _effects = Channel<ItemsEffect>(Channel.BUFFERED)
    val effects: Flow<ItemsEffect> = _effects.receiveAsFlow()

    private val query = MutableStateFlow("")
    private var nextPage = 0

    // Single, lifecycle-scoped, cold-until-subscribed state stream.
    val state: StateFlow<ItemsUiState> = _state
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = ItemsUiState.Loading,
        )

    init {
        observeCache()
        observeSearch()
        refresh()
    }

    /** The one funnel the UI calls. Every user intent routes through here. */
    fun onEvent(event: ItemsEvent) {
        when (event) {
            is ItemsEvent.QueryChanged   -> query.value = event.query
            is ItemsEvent.ToggleFavorite -> toggleFavorite(event.id)
            is ItemsEvent.ItemClicked    -> emit(ItemsEffect.NavigateToDetail(event.id))
            is ItemsEvent.Refresh        -> refresh()
            is ItemsEvent.LoadNextPage   -> loadNextPage()
            is ItemsEvent.Retry          -> refresh()
        }
    }

    private fun emit(effect: ItemsEffect) {
        viewModelScope.launch { _effects.send(effect) }
    }

    // ... reducers below (§5–§8) ...
}
```

Why `stateIn(viewModelScope, WhileSubscribed(5_000), initial)`:

- **`viewModelScope`** ties every coroutine to the ViewModel's lifetime — no manual
  cancellation, no leaks when the screen goes away.
- **`WhileSubscribed(5_000)`** keeps the upstream (the Room `Flow`, the search pipeline)
  alive for 5 seconds after the last collector leaves. A rotation reconnects within that
  window, so you don't re-query the database on every configuration change, yet a real exit
  eventually tears the stream down.
- **`initialValue`** gives the UI something to render on the very first frame, before any
  emission.

---

## 5. Optimistic updates with rollback

For actions the user expects to feel instant (toggling a favorite), update state
immediately, then persist in the background. If the write fails, restore the exact previous
state and surface a one-off snackbar — because state is immutable, "the previous state" is
just the value we captured before mutating.

```kotlin
private fun toggleFavorite(id: Long) {
    val current = _state.value as? ItemsUiState.Content ?: return

    // 1. Optimistic: flip locally and render at once.
    val optimistic = current.copy(
        favorites = if (id in current.favorites) current.favorites - id
                    else current.favorites + id,
    )
    _state.value = optimistic

    // 2. Persist. On failure, roll back to the captured snapshot.
    viewModelScope.launch {
        repository.setFavorite(id, isFavorite = id in optimistic.favorites)
            .onFailure { error ->
                _state.value = current // exact rollback
                _effects.send(ItemsEffect.ShowSnackbar(error.toUserMessage()))
            }
    }
}
```

The repository returns `kotlin.Result<Unit>` for one-shot writes, so the ViewModel never
sees a raw exception here — it decides the UX (rollback + toast) from the `Result`.

---

## 6. Debounced search with flatMapLatest

Search should not fire a request per keystroke, and a slow response for an old query must
never overwrite a fresh one. `debounce` waits for the user to pause; `distinctUntilChanged`
drops no-op re-emissions; `flatMapLatest` **cancels the in-flight request** the instant a
newer query arrives, guaranteeing last-write-wins.

```kotlin
private fun observeSearch() {
    viewModelScope.launch {
        query
            .debounce(300)                 // wait for a typing pause
            .distinctUntilChanged()        // ignore identical successive queries
            .flatMapLatest { q ->          // cancel the previous search when q changes
                repository.observeItems(query = q)
            }
            .catch { error ->
                _state.value = ItemsUiState.Error(
                    message = error.toUserMessage(),
                    canRetry = error.isRetryable(),
                )
            }
            .collect { items ->
                val current = _state.value
                _state.value = when (current) {
                    is ItemsUiState.Content -> current.copy(items = items)
                    else -> ItemsUiState.Content(items = items, query = query.value)
                }
            }
    }
}
```

Because `observeItems` reads from Room, an empty query returns the full cached catalog and
a typed query filters it — the pipeline is identical either way. That is the observe-cache
wiring from §8, driven by the debounced query.

---

## 7. Pagination

Track the next page and an `isAppending` flag so the list can show a footer spinner without
blocking the visible content. Appended results extend the existing list; when the network
returns fewer than a full page, flip `hasMorePages` off so the trigger stops firing.

```kotlin
private fun loadNextPage() {
    val current = _state.value as? ItemsUiState.Content ?: return
    if (current.isAppending || !current.hasMorePages) return

    _state.value = current.copy(isAppending = true)
    viewModelScope.launch {
        repository.loadPage(page = nextPage)
            // Room emits the appended rows through observeItems(); here we only
            // clear the footer and learn whether more pages remain.
            .onSuccess { pageWasFull ->
                nextPage += 1
                _state.value = (_state.value as? ItemsUiState.Content ?: current)
                    .copy(isAppending = false, hasMorePages = pageWasFull)
            }
            .onFailure { error ->
                _state.value = (_state.value as? ItemsUiState.Content ?: current)
                    .copy(isAppending = false)
                _effects.send(ItemsEffect.ShowSnackbar(error.toUserMessage()))
            }
    }
}

private fun refresh() {
    val current = _state.value as? ItemsUiState.Content
    _state.value = current?.copy(isRefreshing = true) ?: ItemsUiState.Loading
    nextPage = 0
    viewModelScope.launch {
        repository.refresh()
            .onSuccess {
                nextPage = 1
                _state.value = (_state.value as? ItemsUiState.Content)
                    ?.copy(isRefreshing = false, hasMorePages = true) ?: ItemsUiState.Loading
            }
            .onFailure { error ->
                val c = _state.value as? ItemsUiState.Content
                if (c != null) {
                    _state.value = c.copy(isRefreshing = false)
                    _effects.send(ItemsEffect.ShowSnackbar(error.toUserMessage()))
                } else {
                    _state.value = ItemsUiState.Error(error.toUserMessage(), error.isRetryable())
                }
            }
    }
}
```

Note the pattern: **network writes to Room, the UI reads from Room.** `refresh()` and
`loadPage()` never hand items to the ViewModel directly — they persist to the database and
let the observed `Flow` (§8) push the new rows into state. This keeps one source of truth.

---

## 8. Offline-first wiring

The screen is always driven by the local cache, so it renders instantly and works with no
network. The network's only job is to *update the cache* in the background; the UI reacts
to that automatically because it observes a Room `Flow`.

```kotlin
private fun observeCache() {
    viewModelScope.launch {
        repository.observeItems(query = "")
            .catch { emit(emptyList()) }           // degrade to empty, never crash
            .collect { items ->
                val current = _state.value
                if (current is ItemsUiState.Content) {
                    _state.value = current.copy(items = items)
                } else if (items.isNotEmpty()) {
                    _state.value = ItemsUiState.Content(items = items)
                }
            }
    }
    // A background refresh fills/updates the cache; failures are non-blocking
    // because the cache already has something to show.
}
```

The repository owns the cache-vs-network decision. The DAO exposes a reactive `Flow`; the
API returns DTOs the repository maps to entities and upserts.

```kotlin
package com.example.app.catalog.data

import androidx.room.*
import com.example.app.catalog.domain.Item
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "items")
data class ItemEntity(
    @PrimaryKey val id: Long,
    val name: String,
    val imageUrl: String?,
    val isFavorite: Boolean = false,
)

@Dao
interface ItemDao {
    @Query(
        "SELECT * FROM items " +
        "WHERE :query = '' OR name LIKE '%' || :query || '%' " +
        "ORDER BY name",
    )
    fun observe(query: String): Flow<List<ItemEntity>>

    @Upsert
    suspend fun upsertAll(items: List<ItemEntity>)

    @Query("UPDATE items SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun setFavorite(id: Long, isFavorite: Boolean)
}

interface CatalogRepository {
    fun observeItems(query: String): Flow<List<Item>>
    suspend fun refresh(): Result<Unit>
    suspend fun loadPage(page: Int): Result<Boolean>            // true = full page
    suspend fun setFavorite(id: Long, isFavorite: Boolean): Result<Unit>
}

class DefaultCatalogRepository @Inject constructor(
    private val api: CatalogApi,
    private val dao: ItemDao,
) : CatalogRepository {

    override fun observeItems(query: String): Flow<List<Item>> =
        dao.observe(query).map { rows -> rows.map { it.toDomain() } }

    override suspend fun refresh(): Result<Unit> = runCatching {
        val dtos = api.fetchItems(page = 0)
        dao.upsertAll(dtos.map { it.toEntity() })
    }

    override suspend fun loadPage(page: Int): Result<Boolean> = runCatching {
        val dtos = api.fetchItems(page = page)
        dao.upsertAll(dtos.map { it.toEntity() })
        dtos.size >= PAGE_SIZE
    }

    override suspend fun setFavorite(id: Long, isFavorite: Boolean): Result<Unit> =
        runCatching {
            dao.setFavorite(id, isFavorite)                    // optimistic write to cache
            api.setFavorite(id, isFavorite)                    // sync to server
        }

    private companion object { const val PAGE_SIZE = 20 }
}
```

```kotlin
package com.example.app.catalog.data

import retrofit2.http.*

data class ItemDto(val id: Long, val name: String, val image: String?)

interface CatalogApi {
    @GET("items")
    suspend fun fetchItems(@Query("page") page: Int): List<ItemDto>

    @PUT("items/{id}/favorite")
    suspend fun setFavorite(@Path("id") id: Long, @Query("on") on: Boolean)
}
```

Mapping stays trivial and centralized:

```kotlin
private fun ItemEntity.toDomain() = Item(id = id, name = name, imageUrl = imageUrl)
private fun ItemDto.toEntity() = ItemEntity(id = id, name = name, imageUrl = image)
```

---

## 9. The Compose screen

The UI reads state with `collectAsStateWithLifecycle()`, obtains the ViewModel with
`hiltViewModel()`, and drains one-off effects in a `LaunchedEffect`. It only ever renders
state and forwards intent through `onEvent` — no business logic here.

```kotlin
package com.example.app.catalog.ui

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun ItemsScreen(
    onNavigateToDetail: (Long) -> Unit,
    viewModel: ItemsViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    // Drain one-off effects. Keyed on Unit so it survives recomposition and
    // is cancelled when the screen leaves the composition.
    LaunchedEffect(Unit) {
        viewModel.effects.collect { effect ->
            when (effect) {
                is ItemsEffect.NavigateToDetail -> onNavigateToDetail(effect.id)
                is ItemsEffect.ShowSnackbar -> snackbarHostState.showSnackbar(effect.message)
                is ItemsEffect.ScrollToTop -> { /* list.animateScrollToItem(0) */ }
            }
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
        when (val s = state) {
            is ItemsUiState.Loading -> LoadingIndicator(Modifier.padding(padding))
            is ItemsUiState.Error -> ErrorPane(
                message = s.message,
                canRetry = s.canRetry,
                onRetry = { viewModel.onEvent(ItemsEvent.Retry) },
                modifier = Modifier.padding(padding),
            )
            is ItemsUiState.Content -> LazyColumn(Modifier.padding(padding)) {
                items(s.items, key = { it.id }) { item ->
                    ItemRow(
                        item = item,
                        isFavorite = item.id in s.favorites,
                        onFavorite = { viewModel.onEvent(ItemsEvent.ToggleFavorite(item.id)) },
                        onClick = { viewModel.onEvent(ItemsEvent.ItemClicked(item.id)) },
                    )
                }
                if (s.hasMorePages) item {
                    // Fire once when the footer scrolls into view.
                    LaunchedEffect(s.items.size) { viewModel.onEvent(ItemsEvent.LoadNextPage) }
                    if (s.isAppending) LoadingIndicator()
                }
            }
        }
    }
}
```

---

## 10. Hilt dependency injection

Hilt supplies the graph: constructor injection everywhere, one `@Module` that binds the
interfaces and provides the framework singletons, and `@HiltViewModel` so the ViewModel is
built with its dependencies.

The entry points are annotated once: `@HiltAndroidApp class MainApplication : Application()`
bootstraps the graph, and `@AndroidEntryPoint class MainActivity : ComponentActivity()`
lets composed screens resolve `hiltViewModel()`.

App-wide singletons — Retrofit and Room — go in one module installed in the app-lifetime
component:

```kotlin
package com.example.app.di

import android.content.Context
import androidx.room.Room
import com.example.app.catalog.data.*
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DataModule {

    @Provides
    @Singleton
    fun provideRetrofit(): Retrofit {
        val json = Json { ignoreUnknownKeys = true }
        return Retrofit.Builder()
            .baseUrl("https://api.example.com/")
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
    }

    @Provides
    @Singleton
    fun provideCatalogApi(retrofit: Retrofit): CatalogApi =
        retrofit.create(CatalogApi::class.java)

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "app.db").build()

    @Provides
    fun provideItemDao(db: AppDatabase): ItemDao = db.itemDao()
}
```

Binding the repository interface to its implementation (a `@Binds` module is cheaper than a
`@Provides` factory when you already use constructor injection):

```kotlin
package com.example.app.di

import com.example.app.catalog.data.CatalogRepository
import com.example.app.catalog.data.DefaultCatalogRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds
    @Singleton
    abstract fun bindCatalogRepository(
        impl: DefaultCatalogRepository,
    ): CatalogRepository
}
```

The Room database class (`@Database(entities = [ItemEntity::class], version = 1)`) just
exposes `abstract fun itemDao(): ItemDao`.

That is the whole graph: `ItemsViewModel` asks for a `CatalogRepository`, Hilt supplies
`DefaultCatalogRepository`, which asks for `CatalogApi` and `ItemDao`, which Hilt builds
from the singletons above. No manual wiring, no service locator.

---

## 11. Error mapping helpers

Repositories return `kotlin.Result<T>`; the ViewModel turns a `Throwable` into a
user-facing string and a retry decision through two small extensions kept in a shared
`core.error` package so every screen maps failures identically.

```kotlin
package com.example.app.core.error

import retrofit2.HttpException
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

fun Throwable.toUserMessage(): String = when (this) {
    is UnknownHostException -> "No internet connection."
    is SocketTimeoutException -> "The request timed out. Try again."
    is HttpException -> when (code()) {
        401 -> "Your session expired. Please sign in again."
        403 -> "You don't have access to this."
        404 -> "We couldn't find that."
        in 500..599 -> "The server had a problem. Try again shortly."
        else -> "Something went wrong (${code()})."
    }
    is IOException -> "Network error. Check your connection."
    else -> "Something went wrong. Try again."
}

fun Throwable.isRetryable(): Boolean = when (this) {
    is UnknownHostException, is SocketTimeoutException, is IOException -> true
    is HttpException -> code() in 500..599 || code() == 429
    else -> false
}
```

`isRetryable()` drives whether the `Error` state shows a retry button, and it is also the
right predicate for a repository-level retry-with-backoff around a network call.

---

## 12. When to reach for full MVI

The pattern above is MVVM with strict unidirectional flow: an immutable `UiState`, a single
`onEvent`, one-off effects over a Channel. That is enough for most screens. Formal MVI is
the same shape with two extra constraints, and you scale up to it only when a screen earns
the ceremony.

| Signal on a screen | Stay MVVM-UDF | Scale to MVI |
|---|---|---|
| A handful of independent events | ✅ | |
| Complex, interdependent state transitions you want to unit-test in isolation | | ✅ |
| Many events that must be processed strictly in order | | ✅ |
| You want a single pure `reduce(state, event) -> state` function, no side effects inside | | ✅ |

Scaling up means: (1) make the reducer a **pure function** you can test without a
ViewModel, and (2) keep side effects (network, database) out of the reducer, in the
ViewModel around it.

```kotlin
// Pure, synchronous, trivially testable — no coroutines, no I/O.
fun reduce(state: ItemsUiState, event: ItemsEvent): ItemsUiState = when (event) {
    is ItemsEvent.QueryChanged ->
        (state as? ItemsUiState.Content)?.copy(query = event.query) ?: state
    is ItemsEvent.Refresh ->
        (state as? ItemsUiState.Content)?.copy(isRefreshing = true) ?: ItemsUiState.Loading
    else -> state
}

// The ViewModel advances state purely, then runs the impure work.
fun onEvent(event: ItemsEvent) {
    _state.update { reduce(it, event) }
    if (event is ItemsEvent.Refresh) viewModelScope.launch {
        repository.refresh().onFailure { emit(ItemsEffect.ShowSnackbar(it.toUserMessage())) }
    }
}
```

The public surface — `StateFlow<ItemsUiState>`, `onEvent`, the effects `Channel` — is
unchanged, so the UI in §9 works against either style. Start with plain MVVM-UDF; promote a
screen to a pure reducer only when its state machine is hairy enough that testing the
transitions in isolation pays for the extra indirection.
