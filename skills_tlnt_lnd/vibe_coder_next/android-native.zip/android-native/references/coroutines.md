# Coroutines & Flow on Android

Reactive UI patterns with Kotlin coroutines and Flow: state holders, Compose collection, operators, error handling, structured concurrency, and background sync — all wired with Hilt.

Verified 2026-07-05 · Coroutines 1.11.0 · WorkManager 2.11.2 · Hilt 2.60 · Lifecycle 2.11.0 · Kotlin 2.3.10

## Table of Contents

1. [StateFlow vs SharedFlow](#1-stateflow-vs-sharedflow)
2. [Collecting Flows in Compose](#2-collecting-flows-in-compose)
3. [Flow Operators for Reactive UI](#3-flow-operators-for-reactive-ui)
4. [Debounce & Throttle for Search](#4-debounce--throttle-for-search)
5. [Error Handling in Flows](#5-error-handling-in-flows)
6. [Dispatchers & withContext](#6-dispatchers--withcontext)
7. [Cancellation & Structured Concurrency](#7-cancellation--structured-concurrency)
8. [Background Sync with WorkManager](#8-background-sync-with-workmanager)

---

## 1. StateFlow vs SharedFlow

| Feature | StateFlow | SharedFlow |
|---|---|---|
| **Has current value** | Yes — always (`.value`) | No |
| **Replays on new collector** | Last value, always | Configurable (`replay = n`) |
| **Conflation** | Yes — equal consecutive values skipped | No — every emission delivered |
| **Initial value** | Required | None |
| **Emits when no collector** | Holds latest silently | Suspends or drops per `onBufferOverflow` |
| **Primary use case** | UI state (screen state that always has a "now") | Events / signals (streams without a "current") |

Rule of thumb: **screen state → `StateFlow`**; **one-shot events (navigate, show snackbar) → `Channel` + `receiveAsFlow()`** (see below).

### In an `ItemsViewModel`

```kotlin
package com.example.app.feature.items

@HiltViewModel
class ItemsViewModel @Inject constructor(
    private val repository: CatalogRepository,
) : ViewModel() {

    // UI state → StateFlow (always has a value, conflates, replays last)
    private val _uiState = MutableStateFlow<ItemsUiState>(ItemsUiState.Loading)
    val uiState: StateFlow<ItemsUiState> = _uiState.asStateFlow()

    // One-shot events → Channel (buffered, delivered exactly once)
    private val _events = Channel<ItemsEvent>(Channel.BUFFERED)
    val events: Flow<ItemsEvent> = _events.receiveAsFlow()
}

sealed interface ItemsUiState {
    data object Loading : ItemsUiState
    data class Success(
        val items: List<Item>,
        val isRefreshing: Boolean = false,
    ) : ItemsUiState
    data class Error(val message: String) : ItemsUiState
}

sealed interface ItemsEvent {
    data class ShowSnackbar(val message: String) : ItemsEvent
    data class NavigateToDetail(val itemId: String) : ItemsEvent
}
```

**Why a `Channel` over `SharedFlow` for events**: `MutableSharedFlow(replay = 0)` drops emissions when no collector is active (e.g. during a configuration change), so a snackbar signal can vanish. `Channel(BUFFERED)` queues events and delivers them when a collector reconnects, and `receiveAsFlow()` guarantees each event is consumed exactly once — no duplicate navigation on rotation.

---

## 2. Collecting Flows in Compose

### `collectAsStateWithLifecycle` — the default

```kotlin
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun ItemsScreen(
    viewModel: ItemsViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    // Recomposes on new state; collection pauses when the lifecycle
    // falls below STARTED (screen backgrounded), then resumes.
}
```

### `collectAsState` vs `collectAsStateWithLifecycle`

`collectAsState()` keeps collecting even while the app is in the background — it never observes the lifecycle. That wastes work and can push updates to a UI nobody is looking at. `collectAsStateWithLifecycle()` binds collection to the `STARTED` state: it stops when the screen leaves the foreground and restarts when it returns. **Prefer `collectAsStateWithLifecycle()` for anything from a `ViewModel`.** Reach for `collectAsState()` only for a purely in-composition flow that has no lifecycle relevance (rare).

### Consuming one-shot events

Events are not state — collect them in an effect and act on each, never render them:

```kotlin
@Composable
fun ItemsRoute(
    viewModel: ItemsViewModel = hiltViewModel(),
    onOpenDetail: (String) -> Unit,
    snackbarHostState: SnackbarHostState,
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(viewModel, lifecycleOwner) {
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
            viewModel.events.collect { event ->
                when (event) {
                    is ItemsEvent.ShowSnackbar ->
                        snackbarHostState.showSnackbar(event.message)
                    is ItemsEvent.NavigateToDetail -> onOpenDetail(event.itemId)
                }
            }
        }
    }
    ItemsScreen(viewModel = viewModel)
}
```

### Custom lifecycle threshold

```kotlin
// Collect only while RESUMED — useful for sensors or location
val position by positionFlow.collectAsStateWithLifecycle(
    initialValue = null,
    minActiveState = Lifecycle.State.RESUMED,
)
```

Dependency: `androidx.lifecycle:lifecycle-runtime-compose:2.11.0`.

---

## 3. Flow Operators for Reactive UI

### `combine` — reactive filters

Merge several input flows into one derived state. Any input change recomputes the result:

```kotlin
@HiltViewModel
class ItemsViewModel @Inject constructor(
    private val repository: CatalogRepository,
) : ViewModel() {

    private val selectedCategory = MutableStateFlow<Category?>(null)
    private val searchQuery = MutableStateFlow("")
    private val sortOrder = MutableStateFlow(SortOrder.RECENT)

    val uiState: StateFlow<ItemsUiState> = combine(
        repository.observeItems(),   // Flow<List<Item>> backed by the local store
        selectedCategory,
        searchQuery,
        sortOrder,
    ) { items, category, query, sort ->
        val visible = items
            .filter { category == null || it.category == category }
            .filter { query.isBlank() || it.title.contains(query, ignoreCase = true) }
            .sortedWith(sort.comparator)
        ItemsUiState.Success(items = visible)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ItemsUiState.Loading,
    )

    fun setCategory(category: Category?) { selectedCategory.value = category }
    fun setQuery(query: String) { searchQuery.value = query }
    fun setSort(order: SortOrder) { sortOrder.value = order }
}
```

### `flatMapLatest` — search-then-fetch

When each new query supersedes the previous request, `flatMapLatest` cancels the in-flight inner flow and switches to the newest one — no stale results race to the screen:

```kotlin
@OptIn(ExperimentalCoroutinesApi::class)
val searchResults: StateFlow<List<Item>> = searchQuery
    .debounce(300)
    .distinctUntilChanged()
    .flatMapLatest { query ->
        if (query.length < 2) flowOf(emptyList())
        else repository.search(query) // Flow<List<Item>>
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
```

### `stateIn` + `SharingStarted.WhileSubscribed(5000)`

`SharingStarted.WhileSubscribed(5_000)` keeps the upstream hot for 5 seconds after the last collector disappears. That window covers a configuration change (rotation): the screen briefly disconnects and reconnects while the flow stays warm, so there is no re-fetch. Longer than a rotation, but short enough that a genuinely backgrounded screen releases the upstream. Use it as the default policy for `ViewModel` state derived from cold flows.

---

## 4. Debounce & Throttle for Search

`debounce(ms)` waits for a pause in input before emitting the latest value — the classic "wait until the user stops typing" gate. Pair it with `distinctUntilChanged()` to skip re-issuing an identical query, and `flatMapLatest` to cancel the previous fetch.

```kotlin
@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel
class ItemSearchViewModel @Inject constructor(
    private val repository: CatalogRepository,
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    val results: StateFlow<SearchState> = _query
        .debounce(300)               // wait 300ms of inactivity
        .distinctUntilChanged()      // skip if the query is unchanged
        .flatMapLatest { query ->
            when {
                query.length < 2 -> flowOf(SearchState.Idle)
                else -> flow {
                    emit(SearchState.Loading)
                    val outcome = repository.search(query)
                        .map<List<Item>, SearchState> { SearchState.Results(it) }
                        .catch { emit(SearchState.Error(it.toUserMessage())) }
                    emitAll(outcome)
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SearchState.Idle)

    fun onQueryChange(newQuery: String) { _query.value = newQuery }
}

sealed interface SearchState {
    data object Idle : SearchState
    data object Loading : SearchState
    data class Results(val items: List<Item>) : SearchState
    data class Error(val message: String) : SearchState
}
```

To **throttle** instead (emit at most once per window regardless of activity — e.g. a live-updating counter), use `sample(period)`: it takes the newest value each interval rather than waiting for silence.

---

## 5. Error Handling in Flows

### `retry` on transient failures

`retry(n) { predicate }` re-subscribes to the upstream when the predicate is true. Keep it to transient causes (I/O) so a genuine bug doesn't loop forever:

```kotlin
repository.observeItems()
    .retry(3) { cause ->
        (cause is IOException).also { if (it) delay(1_000) }
    }
    .catch { cause -> _uiState.value = ItemsUiState.Error(cause.toUserMessage()) }
    .collect { items -> _uiState.value = ItemsUiState.Success(items) }
```

### `retryWhen` with exponential backoff

`retryWhen` exposes the attempt count, so you can grow the delay between tries and cap it:

```kotlin
import kotlin.math.min
import kotlin.math.pow

fun <T> Flow<T>.retryWithBackoff(
    maxRetries: Int = 3,
    initialDelayMs: Long = 1_000,
    maxDelayMs: Long = 10_000,
): Flow<T> = retryWhen { cause, attempt ->
    if (attempt < maxRetries && cause is IOException) {
        val backoff = (initialDelayMs * 2.0.pow(attempt.toInt())).toLong()
        delay(min(backoff, maxDelayMs))
        true
    } else {
        false
    }
}
```

### Surfacing errors to a snackbar without blocking

A refresh that fails should not wipe the content already on screen. Keep the current `Success` state, drop the loading flag, and push the failure as a one-shot event:

```kotlin
fun refresh() {
    val current = _uiState.value as? ItemsUiState.Success ?: return
    viewModelScope.launch {
        _uiState.value = current.copy(isRefreshing = true)
        repository.fetchItems()
            .onSuccess { items ->
                _uiState.value = current.copy(items = items, isRefreshing = false)
            }
            .onFailure { cause ->
                _uiState.value = current.copy(isRefreshing = false)
                _events.send(
                    ItemsEvent.ShowSnackbar("Refresh failed: ${cause.toUserMessage()}"),
                )
            }
    }
}
```

The screen keeps rendering the last good list; the snackbar reports the error non-destructively.

---

## 6. Dispatchers & withContext

Coroutine dispatchers decide which thread pool runs a block:

- **`Dispatchers.Main`** — UI thread; `viewModelScope` launches here by default. Update state here.
- **`Dispatchers.IO`** — blocking I/O (disk, network, database drivers). Offload anything that blocks.
- **`Dispatchers.Default`** — CPU-bound work (sorting large lists, parsing, image math).

`withContext(dispatcher)` switches context for a block and switches back when it returns — it does **not** launch a new coroutine, so the caller suspends until it completes:

```kotlin
suspend fun loadReport(): Report = withContext(Dispatchers.IO) {
    val raw = api.fetchReport()          // blocking network — safe on IO
    withContext(Dispatchers.Default) {
        raw.rows.parseAndAggregate()     // CPU-bound — hop to Default
    }
}
```

Prefer confining the dispatcher choice to the lowest layer (repository / data source), so a `ViewModel` can call `repository.fetchItems()` from `viewModelScope` (Main) without thinking about threads. Inject the dispatcher rather than hardcoding it, which keeps the code testable:

```kotlin
class CatalogRepositoryImpl @Inject constructor(
    private val api: CatalogApi,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher,
) : CatalogRepository {

    override suspend fun fetchItems(): Result<List<Item>> =
        withContext(ioDispatcher) {
            runCatching { api.fetchItems().map { it.toDomain() } }
        }
}
```

```kotlin
// Hilt qualifier + provider
@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class IoDispatcher

@Module
@InstallIn(SingletonComponent::class)
object DispatchersModule {
    @Provides @IoDispatcher
    fun provideIoDispatcher(): CoroutineDispatcher = Dispatchers.IO
}
```

---

## 7. Cancellation & Structured Concurrency

### `viewModelScope`

Every coroutine launched in `viewModelScope` is cancelled automatically when the `ViewModel` is cleared — no manual teardown:

```kotlin
@HiltViewModel
class ItemsViewModel @Inject constructor(
    private val repository: CatalogRepository,
) : ViewModel() {
    init {
        viewModelScope.launch {
            repository.observeItems().collect { /* cancelled on clear */ }
        }
    }
}
```

### `supervisorScope` for independent tasks

Under a plain `coroutineScope`, one child failure cancels its siblings. `supervisorScope` isolates children so each can fail on its own — ideal for a dashboard assembled from several sources:

```kotlin
fun loadDashboard() {
    viewModelScope.launch {
        supervisorScope {
            val items = async { repository.fetchItems() }
            val profile = async { repository.fetchProfile() }
            val badges = async { repository.fetchBadgeCount() }

            _uiState.value = DashboardUiState(
                items = items.await().getOrDefault(emptyList()),
                profile = profile.await().getOrNull(),
                badgeCount = badges.await().getOrDefault(0),
            )
        }
    }
}
```

### `LaunchedEffect` — keyed cancellation in Compose

`LaunchedEffect` starts a coroutine tied to composition; it cancels and restarts when a key changes, and cancels when the composable leaves the tree:

```kotlin
@Composable
fun CountdownScreen(itemId: String) {
    // Cancelled and restarted whenever itemId changes
    LaunchedEffect(itemId) {
        while (isActive) {   // isActive reflects cancellation
            delay(1_000)
            // tick
        }
    }
}
```

### `DisposableEffect` — non-coroutine cleanup

For resources that need explicit release (listeners, callbacks), `DisposableEffect` gives an `onDispose` block that runs when keys change or the composable leaves composition:

```kotlin
@Composable
fun ConnectivityScreen(onStatus: (Boolean) -> Unit) {
    val context = LocalContext.current
    DisposableEffect(Unit) {
        val manager = context.getSystemService<ConnectivityManager>()
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = onStatus(true)
            override fun onLost(network: Network) = onStatus(false)
        }
        manager?.registerDefaultNetworkCallback(callback)
        onDispose { manager?.unregisterNetworkCallback(callback) }
    }
}
```

---

## 8. Background Sync with WorkManager

`CoroutineWorker.doWork()` is a suspend function running off the main thread — perfect for coroutine-based sync. With Hilt, annotate the worker `@HiltWorker` and let `HiltWorkerFactory` inject its dependencies.

### Gradle & manifest

```kotlin
// build.gradle.kts (module)
implementation("androidx.work:work-runtime-ktx:2.11.2")
implementation("androidx.hilt:hilt-work:1.4.0")
ksp("androidx.hilt:hilt-compiler:1.4.0")
```

Disable the default initializer so Hilt supplies the factory (otherwise WorkManager builds its own and cannot inject):

```xml
<!-- AndroidManifest.xml, inside <application> -->
<provider
    android:name="androidx.startup.InitializationProvider"
    android:authorities="${applicationId}.androidx-startup"
    android:exported="false"
    tools:node="merge">
    <meta-data
        android:name="androidx.work.WorkManagerInitializer"
        android:value="androidx.startup"
        tools:node="remove" />
</provider>
```

### The `Application` wires the factory

```kotlin
package com.example.app

@HiltAndroidApp
class MainApplication : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()
}
```

### The injected `CoroutineWorker`

```kotlin
package com.example.app.sync

@HiltWorker
class SyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val repository: CatalogRepository,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = try {
        repository.sync()
        Result.success()
    } catch (e: IOException) {
        if (runAttemptCount < 3) Result.retry() else Result.failure()
    } catch (e: Exception) {
        Result.failure()
    }
}
```

`@Assisted` marks the two runtime arguments WorkManager supplies (`Context`, `WorkerParameters`); everything else is injected by Hilt.

### Periodic sync

```kotlin
fun schedulePeriodicSync(context: Context) {
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .setRequiresBatteryNotLow(true)
        .build()

    val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
        .setConstraints(constraints)
        .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
        .build()

    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
        uniqueWorkName = "periodic_sync",
        existingPeriodicWorkPolicy = ExistingPeriodicWorkPolicy.KEEP,
        request = request,
    )
}
```

`15, TimeUnit.MINUTES` is the platform minimum for periodic work. `KEEP` leaves an already-scheduled instance untouched (use `UPDATE` to replace constraints).

### One-time sync with result observation

```kotlin
fun triggerSync() {
    viewModelScope.launch {
        val request = OneTimeWorkRequestBuilder<SyncWorker>()
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .build()

        val workManager = WorkManager.getInstance(context)
        workManager.enqueue(request)

        val info = workManager.getWorkInfoByIdFlow(request.id)
            .filterNotNull()
            .first { it.state.isFinished }

        when (info.state) {
            WorkInfo.State.SUCCEEDED -> _events.send(ItemsEvent.ShowSnackbar("Sync complete"))
            WorkInfo.State.FAILED -> _events.send(ItemsEvent.ShowSnackbar("Sync failed"))
            else -> Unit
        }
    }
}
```

`getWorkInfoByIdFlow` returns a cold `Flow<WorkInfo?>`; `first { it.state.isFinished }` suspends until the worker terminates, then the result is reported as a one-shot event — same non-blocking event channel from Section 1.
