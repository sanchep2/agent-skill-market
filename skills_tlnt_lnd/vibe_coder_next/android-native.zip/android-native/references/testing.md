# Testing a Native Android App

A code-heavy guide to testing an Android app: fast JVM unit tests for ViewModels, Compose UI tests, navigation tests, Roborazzi screenshots, and Hilt test wiring — all in one app module (`com.example.app`).

## Table of Contents

1. [The Testing Pyramid](#1-the-testing-pyramid)
2. [ViewModel Unit Tests on the JVM](#2-viewmodel-unit-tests-on-the-jvm)
3. [Compose UI Tests](#3-compose-ui-tests)
4. [Navigation Tests](#4-navigation-tests)
5. [Screenshot Testing with Roborazzi](#5-screenshot-testing-with-roborazzi)
6. [Hilt in Tests](#6-hilt-in-tests)
7. [Fakes vs Mocks](#7-fakes-vs-mocks)
8. [CI Integration](#8-ci-integration)

---

## 1. The Testing Pyramid

Push the bulk of your coverage down to fast, hermetic JVM tests. Reserve slow device
tests for the few things a JVM cannot reproduce.

| Layer | What it covers | Tools | Runs on | Source set |
|---|---|---|---|---|
| **Unit** (ViewModel, state logic) | ~70% | JUnit4 + kotlinx-coroutines-test + Turbine + fakes | JVM | `src/test` |
| **Compose UI** (composables, semantics) | ~20% | Compose UI test + Robolectric | JVM or device | `src/test` / `src/androidTest` |
| **Screenshot** (visual regression) | pixel diffs | Roborazzi + Robolectric | JVM (Robolectric) | `src/test` |
| **Instrumented / E2E** | ~10% (smoke) | Compose UI test + Hilt on device | Emulator/device | `src/androidTest` |

Two source sets do all the work:

- **`src/test`** — plain JVM tests. JUnit4, coroutines-test, Turbine, and Robolectric for
  anything that needs a fake Android runtime (Compose, screenshots). Run on every push;
  they finish in seconds.
- **`src/androidTest`** — instrumented tests that need a device or emulator: true hardware
  (camera, biometrics, sensors) or the full Hilt graph against the framework itself.

### Dependencies

```kotlin
// app/build.gradle.kts
dependencies {
    // ---- JVM unit tests (src/test) ----
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.11.0")
    testImplementation("app.cash.turbine:turbine:1.2.1")
    testImplementation("com.google.truth:truth:1.4.4")

    // Compose UI tests on the JVM (Robolectric-backed)
    testImplementation(platform("androidx.compose:compose-bom:2026.06.01"))
    testImplementation("androidx.compose.ui:ui-test-junit4")

    // Robolectric + Roborazzi — verify the latest stable version before pinning
    testImplementation("org.robolectric:robolectric:4.16")
    testImplementation("io.github.takahirom.roborazzi:roborazzi:1.53.0")
    testImplementation("io.github.takahirom.roborazzi:roborazzi-compose:1.53.0")
    testImplementation("io.github.takahirom.roborazzi:roborazzi-junit-rule:1.53.0")

    // ---- Instrumented tests (src/androidTest) ----
    androidTestImplementation(platform("androidx.compose:compose-bom:2026.06.01"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.navigation:navigation-testing:2.9.8")

    // Hilt testing (both source sets)
    testImplementation("com.google.dagger:hilt-android-testing:2.60")
    kspTest("com.google.dagger:hilt-android-compiler:2.60")
    androidTestImplementation("com.google.dagger:hilt-android-testing:2.60")
    kspAndroidTest("com.google.dagger:hilt-android-compiler:2.60")

    // Required so Compose tests can launch an empty activity
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
```

> Roborazzi (`1.53.0`) and Robolectric (`4.16`) coordinates are illustrative — check for
> the latest stable release before pinning them. Everything else (JUnit4 4.13.2,
> kotlinx-coroutines-test 1.11.0, Turbine 1.2.1, Compose BOM 2026.06.01,
> hilt-android-testing 2.60) is build-verified.

The types under test live in this module:

```kotlin
// com.example.app.domain
data class Item(val id: String, val title: String, val subtitle: String, val isFavorite: Boolean)

// com.example.app.data
interface CatalogRepository {
    fun observeItems(): Flow<List<Item>>
    suspend fun refresh(): Result<Unit>
    suspend fun toggleFavorite(id: String): Result<Unit>
}

// com.example.app.ui.items
sealed interface ItemsUiState {
    data object Loading : ItemsUiState
    data class Success(val items: List<Item>, val isRefreshing: Boolean = false) : ItemsUiState
    data class Error(val message: String, val canRetry: Boolean) : ItemsUiState
}
```

---

## 2. ViewModel Unit Tests on the JVM

`ItemsViewModel` collects from `CatalogRepository`, maps to `ItemsUiState`, and handles
intents. To test it we need three things: a main dispatcher we control, a coroutine test
scope, and a way to assert on `StateFlow` emissions.

### The main dispatcher rule

A ViewModel launches work in `viewModelScope`, backed by `Dispatchers.Main`. On the JVM
there is no main looper, so we swap it for a `TestDispatcher`. Wrap that in a reusable
JUnit rule so every test file stays clean:

```kotlin
// com.example.app.testing.MainDispatcherRule
@OptIn(ExperimentalCoroutinesApi::class)
class MainDispatcherRule(
    val dispatcher: TestDispatcher = UnconfinedTestDispatcher(),
) : TestWatcher() {
    override fun starting(description: Description) = Dispatchers.setMain(dispatcher)
    override fun finished(description: Description) = Dispatchers.resetMain()
}
```

`UnconfinedTestDispatcher` runs coroutines eagerly, making `StateFlow` collection
deterministic without manual clock advancing — the right default for ViewModel tests.
Reach for `StandardTestDispatcher` (plus `advanceUntilIdle()` / `runCurrent()`) only when a
test must observe an intermediate state before the coroutine completes.

### The ViewModel and a hand-written fake

```kotlin
// com.example.app.ui.items.ItemsViewModel
@HiltViewModel
class ItemsViewModel @Inject constructor(
    private val repository: CatalogRepository,
) : ViewModel() {

    private val isRefreshing = MutableStateFlow(false)

    val uiState: StateFlow<ItemsUiState> =
        combine(repository.observeItems(), isRefreshing) { items, refreshing ->
            ItemsUiState.Success(items = items, isRefreshing = refreshing)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = ItemsUiState.Loading,
        )

    fun refresh() = viewModelScope.launch {
        isRefreshing.value = true
        repository.refresh()
        isRefreshing.value = false
    }

    fun toggleFavorite(id: String) = viewModelScope.launch { repository.toggleFavorite(id) }
}
```

The fake implements the same `CatalogRepository` interface production depends on. No
mocking library — just a class you can read, with small knobs to drive it and counters to
verify against.

```kotlin
// com.example.app.testing.FakeCatalogRepository
class FakeCatalogRepository : CatalogRepository {
    private val items = MutableStateFlow<List<Item>>(emptyList())

    var refreshResult: Result<Unit> = Result.success(Unit)
    val refreshCount = AtomicInteger(0)
    val toggledIds = mutableListOf<String>()

    /** Test-only: push a new list to every collector of observeItems(). */
    fun emit(newItems: List<Item>) { items.value = newItems }

    override fun observeItems(): Flow<List<Item>> = items.asStateFlow()

    override suspend fun refresh(): Result<Unit> {
        refreshCount.incrementAndGet()
        return refreshResult
    }

    override suspend fun toggleFavorite(id: String): Result<Unit> {
        toggledIds += id
        items.update { list -> list.map { if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it } }
        return Result.success(Unit)
    }
}
```

### The tests

```kotlin
// src/test/kotlin/com/example/app/ui/items/ItemsViewModelTest.kt
class ItemsViewModelTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    private val repository = FakeCatalogRepository()
    private lateinit var viewModel: ItemsViewModel

    @Before fun setUp() { viewModel = ItemsViewModel(repository) }

    private fun item(id: String, title: String, favorite: Boolean = false) =
        Item(id = id, title = title, subtitle = "", isFavorite = favorite)

    @Test
    fun `starts Loading then emits Success once items arrive`() = runTest {
        viewModel.uiState.test {
            assertThat(awaitItem()).isInstanceOf(ItemsUiState.Loading::class.java)

            repository.emit(listOf(item("1", "First"), item("2", "Second")))

            val success = awaitItem() as ItemsUiState.Success
            assertThat(success.items).hasSize(2)
            assertThat(success.items[0].title).isEqualTo("First")

            cancelAndConsumeRemainingEvents()
        }
    }

    @Test
    fun `toggleFavorite flips the flag and records the id`() = runTest {
        repository.emit(listOf(item("1", "First", favorite = false)))

        viewModel.uiState.test {
            skipItems(1) // Loading
            assertThat((awaitItem() as ItemsUiState.Success).items[0].isFavorite).isFalse()

            viewModel.toggleFavorite("1")

            assertThat((awaitItem() as ItemsUiState.Success).items[0].isFavorite).isTrue()
            assertThat(repository.toggledIds).containsExactly("1")

            cancelAndConsumeRemainingEvents()
        }
    }

    @Test
    fun `refresh toggles isRefreshing around the repository call`() = runTest {
        repository.emit(listOf(item("1", "First")))

        viewModel.uiState.test {
            skipItems(1) // Loading
            assertThat((awaitItem() as ItemsUiState.Success).isRefreshing).isFalse()

            viewModel.refresh()

            assertThat((awaitItem() as ItemsUiState.Success).isRefreshing).isTrue()
            assertThat((awaitItem() as ItemsUiState.Success).isRefreshing).isFalse()
            assertThat(repository.refreshCount.get()).isEqualTo(1)

            cancelAndConsumeRemainingEvents()
        }
    }
}
```

**Why `runTest`, and why Turbine.** `runTest` (from `kotlinx-coroutines-test`) gives a
`TestScope` with a virtual clock: `delay()` calls are skipped instantly and the test fails
fast if a coroutine never completes — it replaces the old `runBlockingTest`. Turbine's
`flow.test { }` turns a hot `StateFlow` into an ordered stream you pull from with
`awaitItem()`, `skipItems(n)`, `awaitError()`, and it enforces that you consume every
emission before the block ends. Testing a `StateFlow` by hand — launch a collector, sleep,
read `.value` — is racy; Turbine makes each emission an explicit awaited step. Always close
with `cancelAndConsumeRemainingEvents()`.

---

## 3. Compose UI Tests

Compose UI tests drive the semantics tree, not pixels: they find nodes, assert on them, and
perform gestures. Test the **stateless content composable** — pass a state object in and
capture callbacks — so the test never touches a ViewModel or DI.

Two rules pick your host:

- `createComposeRule()` — no activity needed. Fastest; use it for a single composable.
- `createAndroidComposeRule<ComponentActivity>()` — hosts content in a real activity. Use
  when the composable reads `LocalContext`, resources, or the activity.

Both run on the JVM under Robolectric (`src/test`) or on a device (`src/androidTest`) with
no code change.

```kotlin
// src/test/kotlin/com/example/app/ui/items/ItemsScreenTest.kt
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ItemsScreenTest {

    @get:Rule
    val composeRule = createComposeRule()

    private fun item(id: String, title: String) =
        Item(id = id, title = title, subtitle = "", isFavorite = false)

    @Test
    fun `renders every item title in Success`() {
        composeRule.setContent {
            AppTheme {
                ItemsContent(
                    state = ItemsUiState.Success(listOf(item("1", "Kotlin"), item("2", "Compose"))),
                    onToggleFavorite = {},
                    onRefresh = {},
                )
            }
        }

        composeRule.onNodeWithText("Kotlin").assertIsDisplayed()
        composeRule.onNodeWithText("Compose").assertIsDisplayed()
    }

    @Test
    fun `tapping the favorite icon reports the item id`() {
        var toggledId: String? = null
        composeRule.setContent {
            AppTheme {
                ItemsContent(
                    state = ItemsUiState.Success(listOf(item("1", "Kotlin"))),
                    onToggleFavorite = { toggledId = it },
                    onRefresh = {},
                )
            }
        }

        composeRule.onNodeWithContentDescription("Toggle favorite").performClick()

        assertThat(toggledId).isEqualTo("1")
    }

    @Test
    fun `Error state shows the message and a retry button`() {
        var retried = false
        composeRule.setContent {
            AppTheme {
                ItemsContent(
                    state = ItemsUiState.Error("No connection", canRetry = true),
                    onToggleFavorite = {},
                    onRefresh = { retried = true },
                )
            }
        }

        composeRule.onNodeWithText("No connection").assertIsDisplayed()
        composeRule.onNodeWithText("Retry").assertIsDisplayed().performClick()
        assertThat(retried).isTrue()
    }
}
```

### Finding nodes: text, content description, and test tags

Prefer semantics that also help accessibility — `onNodeWithText`,
`onNodeWithContentDescription`. When a node has no natural label (a skeleton card, a
container), add an explicit `testTag` in production code:

```kotlin
ItemRow(item = item, modifier = Modifier.testTag("item_row_${item.id}")) // production
```

```kotlin
// test — matchers, assertions, actions, and collections
composeRule.onNodeWithTag("item_row_1").assertIsDisplayed()
composeRule.onNodeWithTag("item_row_1").performClick()
composeRule.onNodeWithTag("item_row_1").performScrollTo()

composeRule.onAllNodesWithTag("skeleton_card").assertCountEquals(3) // several at once
composeRule.onNode(hasTestTag("item_row_1") and hasText("Kotlin")).assertExists() // combined
```

Useful assertions: `assertIsDisplayed()`, `assertExists()` / `assertDoesNotExist()`,
`assertIsEnabled()`, `assertIsOn()`, `assertTextEquals(...)`. Common actions:
`performClick()`, `performScrollTo()`, `performTextInput(...)`,
`performTouchInput { swipeUp() }`. If an assertion races ahead of recomposition, sync
manually: set `composeRule.mainClock.autoAdvance = false` then `composeRule.waitForIdle()`,
or `composeRule.waitUntil { composeRule.onAllNodesWithText("Done").fetchSemanticsNodes().isNotEmpty() }`.

---

## 4. Navigation Tests

`TestNavHostController` lets you assert on the back stack without launching real screens.
Give it `LocalContext`, register a `ComposeNavigator`, then drive it and inspect the current
destination and typed arguments.

```kotlin
// src/androidTest/kotlin/com/example/app/ui/NavigationTest.kt
class NavigationTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var navController: TestNavHostController

    @Before
    fun setUp() {
        composeRule.setContent {
            navController = TestNavHostController(LocalContext.current).apply {
                navigatorProvider.addNavigator(ComposeNavigator())
            }
            AppTheme { AppNavHost(navController = navController) }
        }
    }

    @Test
    fun `start destination is the items list`() {
        assertThat(navController.currentBackStackEntry?.destination?.hasRoute<ItemsRoute>()).isTrue()
    }

    @Test
    fun `navigating to detail carries the item id`() {
        composeRule.runOnUiThread { navController.navigate(ItemDetailRoute(itemId = "42")) }

        val entry = navController.currentBackStackEntry
        assertThat(entry?.destination?.hasRoute<ItemDetailRoute>()).isTrue()
        assertThat(entry?.toRoute<ItemDetailRoute>()?.itemId).isEqualTo("42")
    }

    @Test
    fun `a deep link resolves to the detail destination`() {
        composeRule.runOnUiThread { navController.navigate("https://example.com/items/42".toUri()) }

        assertThat(navController.currentBackStackEntry?.destination?.hasRoute<ItemDetailRoute>()).isTrue()
    }
}
```

`navigation-testing` runs on a device (`src/androidTest`) reliably and works under
Robolectric in `src/test` for many cases. Always mutate the controller inside
`runOnUiThread { }` — navigation is main-thread-only.

---

## 5. Screenshot Testing with Roborazzi

Roborazzi renders composables to PNGs on the JVM (via Robolectric) and diffs them against
committed baselines. It catches visual regressions — spacing, color, truncation — that
semantics assertions miss. Two workflows: write capture tests by hand, or generate them
from your `@Preview` functions.

### Gradle setup

```kotlin
// app/build.gradle.kts
plugins {
    id("io.github.takahirom.roborazzi") version "1.53.0" // verify the latest version
}

android {
    testOptions { unitTests { isIncludeAndroidResources = true } } // Robolectric needs resources
}

// Generate Robolectric screenshot tests straight from @Preview composables
roborazzi {
    generateComposePreviewRobolectricTests {
        enable = true
        packages = listOf("com.example.app")
        includePrivatePreviews = true
    }
}
```

### Hand-written capture tests

```kotlin
// src/test/kotlin/com/example/app/ui/items/ItemsScreenScreenshotTest.kt
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE) // native graphics = real pixel rendering
@Config(sdk = [34], qualifiers = RobolectricDeviceQualifiers.Pixel7)
class ItemsScreenScreenshotTest {

    @get:Rule
    val composeRule = createComposeRule()

    private fun sampleState() = ItemsUiState.Success(
        items = listOf(
            Item("1", "Kotlin", "Language update", isFavorite = true),
            Item("2", "Compose", "Toolkit release", isFavorite = false),
        ),
    )

    @Test
    fun items_success_light() {
        composeRule.setContent {
            AppTheme(darkTheme = false) { ItemsContent(sampleState(), onToggleFavorite = {}, onRefresh = {}) }
        }
        composeRule.onRoot().captureRoboImage()
    }

    @Test
    fun items_success_dark() {
        composeRule.setContent {
            AppTheme(darkTheme = true) { ItemsContent(sampleState(), onToggleFavorite = {}, onRefresh = {}) }
        }
        composeRule.onRoot().captureRoboImage()
    }

    @Test
    fun items_error() {
        composeRule.setContent {
            AppTheme {
                ItemsContent(
                    ItemsUiState.Error("No connection", canRetry = true),
                    onToggleFavorite = {},
                    onRefresh = {},
                )
            }
        }
        composeRule.onRoot().captureRoboImage()
    }
}
```

`captureRoboImage()` writes `build/outputs/roborazzi/<TestClass>.<method>.png` during a
**record** run and compares against it during a **verify** run. Call it on `onRoot()` for
the whole screen, or on any node (`onNodeWithTag("item_row_1").captureRoboImage()`) for a
single component.

### Generating tests from `@Preview`

Keep `@Preview` functions next to production composables — they document the UI *and*
become screenshot tests for free:

```kotlin
// ItemsScreen.kt
@Preview(showBackground = true)
@Composable
private fun ItemsSuccessPreview() {
    AppTheme { ItemsContent(previewSuccessState(), onToggleFavorite = {}, onRefresh = {}) }
}

@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun ItemsSuccessDarkPreview() {
    AppTheme(darkTheme = true) { ItemsContent(previewSuccessState(), onToggleFavorite = {}, onRefresh = {}) }
}
```

With `generateComposePreviewRobolectricTests` enabled, every `@Preview` in the configured
packages gets a capture test automatically.

### Record vs verify

| Task | Purpose | When |
|---|---|---|
| `./gradlew recordRoborazziDebug` | Write/refresh baseline PNGs | On an approved UI change; commit the PNGs |
| `./gradlew verifyRoborazziDebug` | Fail on any pixel diff vs baseline | On every PR |
| `./gradlew compareRoborazziDebug` | Emit side-by-side `*_compare.png` | To review a diff |

Commit baseline images to the repo. A failed `verify` on CI means either an intended change
(re-record and commit) or a regression (fix the code).

---

## 6. Hilt in Tests

When a test exercises the real Hilt graph — an instrumented end-to-end flow, or a
Robolectric test that resolves `@Inject` dependencies — Hilt supplies the bindings and lets
you **replace** production modules with test doubles.

### Instrumented test runner

Instrumented Hilt tests need a custom `Application`. Ship `HiltTestApplication` via a runner:

```kotlin
// src/androidTest/kotlin/com/example/app/HiltTestRunner.kt
class HiltTestRunner : AndroidJUnitRunner() {
    override fun newApplication(cl: ClassLoader?, name: String?, context: Context?): Application =
        super.newApplication(cl, HiltTestApplication::class.java.name, context)
}
```

```kotlin
// app/build.gradle.kts
android { defaultConfig { testInstrumentationRunner = "com.example.app.HiltTestRunner" } }
```

### Replacing a production module with `@TestInstallIn`

Say production binds `CatalogRepository` in a `DataModule` installed in `SingletonComponent`:

```kotlin
// production
@Module
@InstallIn(SingletonComponent::class)
interface DataModule {
    @Binds
    fun bindCatalogRepository(impl: DefaultCatalogRepository): CatalogRepository
}
```

Provide a test module that **replaces** it globally. Every test then gets the fake:

```kotlin
// src/androidTest/kotlin/com/example/app/testing/TestDataModule.kt
@Module
@TestInstallIn(components = [SingletonComponent::class], replaces = [DataModule::class])
object TestDataModule {

    @Provides
    @Singleton
    fun provideCatalogRepository(): CatalogRepository = FakeCatalogRepository()
}
```

### A `@HiltAndroidTest`

```kotlin
// src/androidTest/kotlin/com/example/app/ui/items/ItemsScreenHiltTest.kt
@HiltAndroidTest
class ItemsScreenHiltTest {

    @get:Rule(order = 0)
    val hiltRule = HiltAndroidRule(this)

    @get:Rule(order = 1)
    val composeRule = createAndroidComposeRule<ComponentActivity>()

    @Inject lateinit var repository: CatalogRepository

    @Before fun setUp() = hiltRule.inject() // populates @Inject fields before the body

    @Test
    fun `list reflects what the injected repository emits`() {
        (repository as FakeCatalogRepository).emit(listOf(Item("1", "Kotlin", "", isFavorite = false)))

        composeRule.setContent { AppTheme { ItemsRoute() } } // resolves ItemsViewModel from Hilt

        composeRule.onNodeWithText("Kotlin").assertIsDisplayed()
    }
}
```

Rule ordering matters: `HiltAndroidRule` must run **first** (`order = 0`) so the graph is
ready before the compose/activity rule (`order = 1`) starts.

### Per-test bindings with `@BindValue`

For a double that differs per test, skip the module and bind a field directly:

```kotlin
@HiltAndroidTest
class ItemsErrorHiltTest {

    @get:Rule(order = 0)
    val hiltRule = HiltAndroidRule(this)

    @BindValue @JvmField
    val repository: CatalogRepository = FakeCatalogRepository().apply {
        refreshResult = Result.failure(IOException("offline"))
    }
    // ...
}
```

Remember the wiring: `hilt-android-testing` plus `kspAndroidTest(...)` (and `kspTest(...)` if
you run Hilt under Robolectric in `src/test`) — see the Dependencies block in §1.

---

## 7. Fakes vs Mocks

**Default to hand-written fakes** for repositories and other collaborators you own. A fake
implements the real interface with a simple in-memory behavior. It is deterministic,
readable, refactor-safe (the compiler updates it when the interface changes), and needs no
mocking framework. `FakeCatalogRepository` in §2 is the model: it stores state, exposes a
couple of test knobs, and records calls so a test can verify against plain fields.

```kotlin
val repository = FakeCatalogRepository()
// ... exercise the ViewModel ...
assertThat(repository.toggledIds).containsExactly("1")
assertThat(repository.refreshCount.get()).isEqualTo(1)
```

**Reach for a mock** (MockK, or a Hilt `@BindValue` stub) only when a fake is impractical:
hard-to-implement framework types (`WorkManager`, `SensorManager`, `ConnectivityManager`) or
a one-off interaction check against an interface you don't own. Even then, keep the surface
small. Rules of thumb:

- Owned interface, reused across many tests → **fake**.
- Framework type or a single throwaway verification → **mock**.
- Never mock the class under test. Never mock value/data classes — construct them.

---

## 8. CI Integration

Run the fast JVM tests (unit + Compose-under-Robolectric + screenshot verify) on every push.
They need only a JDK and Gradle — no emulator — so they finish in a couple of minutes.

```yaml
# .github/workflows/android-tests.yml
name: Android Tests

on:
  push:
    branches: [main]
  pull_request:

jobs:
  jvm-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-java@v4
        with:
          java-version: '21'
          distribution: 'temurin'

      - uses: gradle/actions/setup-gradle@v4

      - name: Unit + Compose (Robolectric) tests
        run: ./gradlew testDebugUnitTest

      - name: Verify screenshots
        run: ./gradlew verifyRoborazziDebug

      - name: Upload screenshot diffs on failure
        if: failure()
        uses: actions/upload-artifact@v4
        with:
          name: screenshot-diffs
          path: '**/build/outputs/roborazzi/**/*_compare.png'

      - name: Upload test reports on failure
        if: failure()
        uses: actions/upload-artifact@v4
        with:
          name: test-reports
          path: '**/build/reports/tests/'
```

Instrumented tests (`src/androidTest`, including the `@HiltAndroidTest` device flows) are
slower — they need an emulator. Keep them in a separate, less-frequent job (nightly or a
gated stage) using `reactivecircus/android-emulator-runner` with
`./gradlew connectedDebugAndroidTest`, so the fast feedback loop above stays fast.

### Test layout

```
app/
├── src/main/kotlin/com/example/app/        # production
│   ├── domain/Item.kt
│   ├── data/CatalogRepository.kt
│   └── ui/items/{ItemsViewModel,ItemsScreen}.kt
├── src/test/kotlin/com/example/app/        # JVM tests — run on every push
│   ├── testing/{MainDispatcherRule,FakeCatalogRepository}.kt
│   └── ui/items/{ItemsViewModelTest,ItemsScreenTest,ItemsScreenScreenshotTest}.kt
└── src/androidTest/kotlin/com/example/app/ # instrumented — device/emulator only
    ├── HiltTestRunner.kt
    ├── testing/TestDataModule.kt
    └── ui/{NavigationTest,ItemsScreenHiltTest}.kt
```

Most tests live in `src/test` and run on the JVM. Reserve `src/androidTest` for what truly
needs the framework or hardware: the full Hilt graph on a device, real navigation, camera,
biometrics, or sensors.
```
