# Jetpack Compose UI + Material 3 (Native Android)

Battle-tested Compose patterns for a pure-Android app: Material 3 theming, adaptive layouts, image loading, camera, and edge-to-edge — Hilt for DI, `hiltViewModel()` for screen state.

> Verified July 5, 2026 · Compose BOM `2026.06.01` · Material 3 (via BOM) · Coil `3.5.0` · CameraX `1.6.1` · Activity Compose `1.13.0` · Kotlin `2.3.10`.

## Table of Contents

1. [Versions & Gradle Setup](#1-versions--gradle-setup)
2. [Material 3 Theming](#2-material-3-theming)
3. [Scaffold & App Structure](#3-scaffold--app-structure)
4. [Lazy Lists & Pagination](#4-lazy-lists--pagination)
5. [Pull-to-Refresh](#5-pull-to-refresh)
6. [Shimmer & Skeleton Loading](#6-shimmer--skeleton-loading)
7. [Image Loading with Coil 3](#7-image-loading-with-coil-3)
8. [Animations](#8-animations)
9. [Bottom Sheets](#9-bottom-sheets)
10. [SearchBar](#10-searchbar)
11. [CameraX Preview + QR / Photo Capture](#11-camerax-preview--qr--photo-capture)
12. [Adaptive Layouts](#12-adaptive-layouts)
13. [Edge-to-Edge](#13-edge-to-edge)
14. [Forms, Snackbar, Runtime Permissions](#14-forms-snackbar-runtime-permissions)

The domain type used throughout:

```kotlin
package com.example.app.domain

data class Item(
    val id: Long,
    val name: String,
    val imageUrl: String?,
)
```

---

## 1. Versions & Gradle setup

The full, build-verified Gradle toolchain and version catalog live in **`project-setup.md`** — that file is
the single source of truth for every dependency version (it was validated with `./gradlew :app:assembleDebug`).
Add these Compose-related artifacts from the catalog to your `app/build.gradle.kts`:

```kotlin
dependencies {
    val composeBom = platform(libs.compose.bom)      // 2026.06.01
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation(libs.compose.ui)
    implementation(libs.compose.ui.tooling.preview)
    debugImplementation(libs.compose.ui.tooling)
    implementation(libs.compose.material3)
    implementation(libs.compose.material3.adaptive.nav)          // NavigationSuiteScaffold (from BOM)
    implementation(libs.compose.material3.adaptive)              // ListDetailPaneScaffold (1.2.0)
    implementation(libs.compose.material3.adaptive.layout)
    implementation(libs.compose.material3.adaptive.navigation)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)

    implementation(libs.coil.compose)                            // Coil 3.5.0
    implementation(libs.coil.network.okhttp)                     // OkHttp fetcher — pure-Android networking

    implementation(libs.camera.camera2)                          // CameraX 1.6.1
    implementation(libs.camera.lifecycle)
    implementation(libs.camera.view)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)                                      // KSP — do NOT use kapt with built-in Kotlin
    implementation(libs.hilt.navigation.compose)
    implementation(libs.hilt.lifecycle.viewmodel.compose)
}
```

For a QR/barcode scanner (section 11) add ML Kit barcode scanning (`com.google.mlkit:barcode-scanning`) and,
for the runtime-permission helper, Accompanist Permissions (`com.google.accompanist:accompanist-permissions`)
— pin each to its own latest stable release.

Every screen resolves its ViewModel through Hilt:

```kotlin
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun FeedRoute(viewModel: FeedViewModel = hiltViewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    FeedScreen(uiState = uiState, onItemClick = viewModel::onItemClick)
}
```

---

## 2. Material 3 Theming

### Dynamic color (Material You), dark/light

Dynamic color reads the wallpaper palette on Android 12+ (API 31). Fall back to a hand-authored scheme below that.

```kotlin
package com.example.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

@Composable
fun AppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context)
            else dynamicLightColorScheme(context)
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content,
    )
}
```

### Hand-authored color scheme

Define every role you rely on — leaving roles unset falls back to Material defaults and can break contrast in dark mode.

```kotlin
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

val LightColorScheme = lightColorScheme(
    primary = Color(0xFF3F5AA6),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDAE1FF),
    onPrimaryContainer = Color(0xFF001945),
    secondary = Color(0xFF5A5D72),
    surface = Color(0xFFFBF8FD),
    onSurface = Color(0xFF1B1B1F),
    surfaceVariant = Color(0xFFE2E1EC),
    error = Color(0xFFBA1A1A),
    // …fill in the remaining roles for full coverage
)

val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFB1C5FF),
    onPrimary = Color(0xFF002A6D),
    primaryContainer = Color(0xFF23428C),
    onPrimaryContainer = Color(0xFFDAE1FF),
    secondary = Color(0xFFC3C5DD),
    surface = Color(0xFF131316),
    onSurface = Color(0xFFE4E1E6),
    surfaceVariant = Color(0xFF45464F),
    error = Color(0xFFFFB4AB),
)
```

### Typography & shapes

```kotlin
import androidx.compose.material3.Typography
import androidx.compose.material3.Shapes
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val AppTypography = Typography(
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 24.sp, lineHeight = 32.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 16.sp),
)

val AppShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(20.dp),
)
```

---

## 3. Scaffold & App Structure

`Scaffold` owns the top bar, bottom bar, snackbar host, and — critically — the `innerPadding` that keeps content clear of the system bars. Apply that padding exactly once.

```kotlin
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.NavGraph.Companion.findStartDestination

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScaffold(navController: NavHostController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination

    Scaffold(
        topBar = {
            if (shouldShowTopBar(currentRoute)) {
                CenterAlignedTopAppBar(
                    title = { Text(titleFor(currentRoute)) },
                    navigationIcon = {
                        if (navController.previousBackStackEntry != null) {
                            IconButton(onClick = { navController.navigateUp() }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                            }
                        }
                    },
                )
            }
        },
        bottomBar = {
            if (shouldShowBottomBar(currentRoute)) {
                NavigationBar {
                    TopLevelDestination.entries.forEach { dest ->
                        NavigationBarItem(
                            selected = currentRoute?.hasRoute(dest.route::class) == true,
                            onClick = {
                                navController.navigate(dest.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(dest.icon, contentDescription = dest.label) },
                            label = { Text(dest.label) },
                        )
                    }
                }
            }
        },
    ) { innerPadding ->
        // innerPadding accounts for bars + system insets — apply ONCE here
        AppNavGraph(
            navController = navController,
            modifier = Modifier.padding(innerPadding),
        )
    }
}
```

---

## 4. Lazy Lists & Pagination

### LazyColumn with sticky headers, stable keys, `animateItem()`

Stable `key` values (the `Long` id) let Compose track items across data changes — without them, `animateItem()` and scroll position break. Note `stickyHeader` is stable as of Compose 1.9+; `animateItem()` replaced the old `animateItemPlacement`.

```kotlin
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import com.example.app.domain.Item

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FeedList(
    sections: List<FeedSection>,
    onItemClick: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(vertical = 8.dp),
    ) {
        sections.forEach { section ->
            stickyHeader(key = "header_${section.title}") {
                SectionHeader(
                    title = section.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface),
                )
            }
            items(
                items = section.items,
                key = { it.id }, // CRITICAL — stable keys drive diffing + animation
            ) { item ->
                ItemCard(
                    item = item,
                    onClick = { onItemClick(item.id) },
                    modifier = Modifier.animateItem(),
                )
            }
        }
    }
}
```

### LazyVerticalGrid

```kotlin
import androidx.compose.foundation.lazy.grid.*

@Composable
fun ItemGrid(items: List<Item>, onItemClick: (Long) -> Unit, modifier: Modifier = Modifier) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 160.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier,
    ) {
        items(items, key = { it.id }) { item ->
            ItemCard(item = item, onClick = { onItemClick(item.id) }, modifier = Modifier.animateItem())
        }
    }
}
```

### Infinite scroll — `derivedStateOf` + `snapshotFlow`

Wrap the "near the end?" computation in `derivedStateOf` so it only recomposes readers when the boolean flips, not on every scroll frame. Then drive the load callback off a `snapshotFlow`.

```kotlin
import androidx.compose.foundation.lazy.rememberLazyListState
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter

@Composable
fun InfiniteList(
    items: List<Item>,
    isLoadingMore: Boolean,
    onLoadMore: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()

    val shouldLoadMore by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val lastVisible = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            info.totalItemsCount > 0 && lastVisible >= info.totalItemsCount - 5
        }
    }

    LaunchedEffect(listState) {
        snapshotFlow { shouldLoadMore }
            .distinctUntilChanged()
            .filter { it }
            .collect { onLoadMore() }
    }

    LazyColumn(state = listState, modifier = modifier) {
        items(items, key = { it.id }) { item -> ItemRow(item) }
        if (isLoadingMore) {
            item(key = "loading_footer") {
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}
```

---

## 5. Pull-to-Refresh

`PullToRefreshBox` is the stable Material 3 wrapper — no manual nested-scroll wiring.

```kotlin
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RefreshableFeed(
    isRefreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val state = rememberPullToRefreshState()
    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = onRefresh,
        state = state,
        modifier = modifier,
    ) {
        content()
    }
}
```

Drive `isRefreshing` from the ViewModel; flip it back to `false` when the reload completes.

---

## 6. Shimmer & Skeleton Loading

Show a placeholder whose shape matches the real content, animated with an infinite-transition brush.

```kotlin
import androidx.compose.animation.core.*
import androidx.compose.foundation.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush

@Composable
fun rememberShimmerBrush(): Brush {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translate by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "shimmer_translate",
    )
    return Brush.linearGradient(
        colors = listOf(
            MaterialTheme.colorScheme.surfaceVariant,
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
            MaterialTheme.colorScheme.surfaceVariant,
        ),
        start = Offset(translate - 200f, translate - 200f),
        end = Offset(translate, translate),
    )
}

@Composable
fun SkeletonCard(modifier: Modifier = Modifier) {
    val brush = rememberShimmerBrush()
    Card(modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Box(
                Modifier.fillMaxWidth().height(180.dp)
                    .clip(MaterialTheme.shapes.medium).background(brush),
            )
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier.fillMaxWidth(0.7f).height(20.dp)
                    .clip(MaterialTheme.shapes.small).background(brush),
            )
        }
    }
}

@Composable
fun SkeletonList(count: Int = 6, modifier: Modifier = Modifier) {
    LazyColumn(modifier = modifier, contentPadding = PaddingValues(12.dp)) {
        items(count) { SkeletonCard(Modifier.padding(vertical = 6.dp)) }
    }
}
```

---

## 7. Image Loading with Coil 3

Coil 3 does not bundle networking. For a pure-Android app add `coil-network-okhttp` and build the `ImageLoader` from the Android `Context` via `LocalContext`.

### Setting up a singleton ImageLoader

Provide the loader through `setSingletonImageLoaderFactory` so every `AsyncImage` shares one memory/disk cache. Do this once, high in the tree (e.g. in your root composable).

```kotlin
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import coil3.ImageLoader
import coil3.compose.setSingletonImageLoaderFactory
import coil3.disk.DiskCache
import coil3.disk.directory
import coil3.memory.MemoryCache
import coil3.network.okhttp.OkHttpNetworkFetcherFactory
import coil3.request.crossfade

@Composable
fun AppRoot(content: @Composable () -> Unit) {
    val context = LocalContext.current
    setSingletonImageLoaderFactory { platformContext ->
        ImageLoader.Builder(platformContext)
            .components {
                // OkHttp network fetcher — the pure-Android networking stack
                add(OkHttpNetworkFetcherFactory())
            }
            .memoryCache {
                MemoryCache.Builder()
                    .maxSizePercent(context, 0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(context.cacheDir.resolve("image_cache"))
                    .maxSizePercent(0.02)
                    .build()
            }
            .crossfade(true)
            .build()
    }
    content()
}
```

> Prefer a custom OkHttp client (interceptors, auth headers)? Pass it in:
> `add(OkHttpNetworkFetcherFactory(callFactory = { myOkHttpClient }))`.

If you use Hilt for the rest of the app, you can also expose a single `ImageLoader` from a module and hand it to `setSingletonImageLoaderFactory { appImageLoader }` — the composable factory still runs once.

### Usage

```kotlin
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import androidx.compose.foundation.shape.CircleShape

// Basic
AsyncImage(
    model = item.imageUrl,
    contentDescription = item.name,
    contentScale = ContentScale.Crop,
    modifier = Modifier.fillMaxWidth().height(200.dp).clip(MaterialTheme.shapes.medium),
)

// Placeholder + error, with a stable memory-cache key (uses LocalContext)
AsyncImage(
    model = ImageRequest.Builder(LocalContext.current)
        .data(item.imageUrl)
        .crossfade(true)
        .memoryCacheKey(item.id.toString())
        .build(),
    placeholder = painterResource(R.drawable.placeholder),
    error = painterResource(R.drawable.error_image),
    contentDescription = item.name,
    contentScale = ContentScale.Crop,
    modifier = Modifier.size(64.dp).clip(CircleShape),
)
```

> Avoid `SubcomposeAsyncImage` inside `LazyColumn` — subcomposition is slow at scale. Use `AsyncImage` with `placeholder`/`error` painters instead.

Notes for Coil 3: Maven group is `io.coil-kt.coil3`, imports start with `coil3`, results are `coil3.Image` (not `Drawable`), and default max decode size is 4096×4096.

---

## 8. Animations

### AnimatedVisibility

```kotlin
import androidx.compose.animation.*

AnimatedVisibility(
    visible = isVisible,
    enter = fadeIn() + slideInVertically(),
    exit = fadeOut() + slideOutVertically(),
) {
    FilterChips(filters = filters, onFilterSelected = onFilterSelected)
}
```

### AnimatedContent for UI-state transitions

```kotlin
AnimatedContent(
    targetState = uiState,
    transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) },
    label = "feed_state",
) { state ->
    when (state) {
        is FeedUiState.Loading -> SkeletonList()
        is FeedUiState.Success -> FeedList(state.sections, onItemClick = {})
        is FeedUiState.Error -> ErrorScreen(state.message)
    }
}
```

### Shared element transitions

Wrap the nav graph in `SharedTransitionLayout` and thread the `AnimatedVisibilityScope` from each `composable` block into the screen. The matching element key ties the two screens together.

```kotlin
import androidx.compose.animation.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun AppNavHost(navController: NavHostController) {
    SharedTransitionLayout {
        NavHost(navController, startDestination = FeedRoute) {
            composable<FeedRoute> {
                FeedScreen(
                    onItemClick = { id -> navController.navigate(DetailRoute(id)) },
                    sharedScope = this@SharedTransitionLayout,
                    animatedVisibilityScope = this@composable,
                )
            }
            composable<DetailRoute> {
                DetailScreen(
                    sharedScope = this@SharedTransitionLayout,
                    animatedVisibilityScope = this@composable,
                )
            }
        }
    }
}

// In FeedScreen — the shared image
@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun FeedImage(
    item: Item,
    sharedScope: SharedTransitionScope,
    animatedVisibilityScope: AnimatedVisibilityScope,
) = with(sharedScope) {
    AsyncImage(
        model = item.imageUrl,
        contentDescription = item.name,
        modifier = Modifier.sharedElement(
            sharedContentState = rememberSharedContentState(key = "image_${item.id}"),
            animatedVisibilityScope = animatedVisibilityScope,
        ),
    )
}
```

### Item animation in LazyColumn

```kotlin
items(items, key = { it.id }) { item ->
    ItemCard(
        item = item,
        modifier = Modifier.animateItem(
            fadeInSpec = tween(300),
            fadeOutSpec = tween(300),
            placementSpec = spring(dampingRatio = 0.8f),
        ),
    )
}
```

---

## 9. Bottom Sheets

`ModalBottomSheet` is still `@ExperimentalMaterial3Api`. It manages its own bottom inset, so don't add navigation-bar padding yourself.

```kotlin
import androidx.compose.material3.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailBottomSheet(
    item: Item,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        dragHandle = { BottomSheetDefaults.DragHandle() },
    ) {
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text(item.name, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(24.dp))
            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Done") }
            Spacer(Modifier.height(16.dp)) // sheet already handles the system bottom inset
        }
    }
}
```

---

## 10. SearchBar

The Material 3 `SearchBar` API splits into a state object plus an input field. `ExpandedFullScreenSearchBar` gives phones a full-screen search surface; `DockedSearchBar` fits wider layouts.

```kotlin
import androidx.compose.material3.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    suggestions: List<String>,
    onSearch: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val searchBarState = rememberSearchBarState()
    val inputField = @Composable {
        SearchBarDefaults.InputField(
            query = query,
            onQueryChange = onQueryChange,
            onSearch = { onSearch(query) },
            expanded = searchBarState.currentValue == SearchBarValue.Expanded,
            onExpandedChange = { /* toggled by the state object */ },
            placeholder = { Text("Search items") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
        )
    }

    TopSearchBar(state = searchBarState, inputField = inputField, modifier = modifier)

    ExpandedFullScreenSearchBar(state = searchBarState, inputField = inputField) {
        LazyColumn {
            items(suggestions, key = { it }) { suggestion ->
                ListItem(
                    headlineContent = { Text(suggestion) },
                    leadingContent = { Icon(Icons.Default.History, contentDescription = null) },
                    modifier = Modifier.clickable { onSearch(suggestion) },
                )
            }
        }
    }
}
```

---

## 11. CameraX Preview + QR / Photo Capture

CameraX `1.6.1` with `camera-compose` ships `CameraXViewfinder` — a native Compose viewfinder, no `AndroidView` wrapper. Wire the preview surface through the ViewModel and analyze frames for QR codes with ML Kit; add `ImageCapture` for still photos.

### ViewModel (Hilt-injected)

```kotlin
package com.example.app.camera

import android.content.Context
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asExecutor
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class ScannerViewModel @Inject constructor() : ViewModel() {

    private val _surfaceRequest = MutableStateFlow<SurfaceRequest?>(null)
    val surfaceRequest: StateFlow<SurfaceRequest?> = _surfaceRequest.asStateFlow()

    private val _scannedCode = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val scannedCode: SharedFlow<String> = _scannedCode.asSharedFlow()

    private val imageCapture = ImageCapture.Builder().build()

    suspend fun bindCamera(lifecycleOwner: LifecycleOwner, context: Context) {
        val provider = ProcessCameraProvider.awaitInstance(context)

        val preview = Preview.Builder().build().apply {
            setSurfaceProvider { request -> _surfaceRequest.value = request }
        }

        val analyzer = QRCodeAnalyzer { code -> _scannedCode.tryEmit(code) }
        val analysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
            .apply { setAnalyzer(Dispatchers.Default.asExecutor(), analyzer) }

        provider.unbindAll()
        provider.bindToLifecycle(
            lifecycleOwner,
            CameraSelector.DEFAULT_BACK_CAMERA,
            preview, analysis, imageCapture,
        )
    }

    fun takePhoto(context: Context, onSaved: (android.net.Uri) -> Unit, onError: (Throwable) -> Unit) {
        val file = java.io.File(context.cacheDir, "capture_${System.currentTimeMillis()}.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(file).build()
        imageCapture.takePicture(
            output,
            Dispatchers.IO.asExecutor(),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(results: ImageCapture.OutputFileResults) {
                    onSaved(android.net.Uri.fromFile(file))
                }
                override fun onError(exc: ImageCaptureException) = onError(exc)
            },
        )
    }
}
```

### QR analyzer (ML Kit)

```kotlin
package com.example.app.camera

import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage

class QRCodeAnalyzer(private val onScanned: (String) -> Unit) : ImageAnalysis.Analyzer {
    private val scanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .build(),
    )

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image ?: run { imageProxy.close(); return }
        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
        scanner.process(image)
            .addOnSuccessListener { barcodes -> barcodes.firstOrNull()?.rawValue?.let(onScanned) }
            .addOnCompleteListener { imageProxy.close() } // ALWAYS close in onComplete
    }
}
```

### Compose screen with runtime permission

Accompanist `rememberPermissionState` handles the CAMERA grant; bind the camera only once it's granted.

```kotlin
package com.example.app.camera

import android.Manifest
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.camera.compose.CameraXViewfinder
import androidx.camera.viewfinder.compose.ImplementationMode
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun ScannerScreen(
    onCodeScanned: (String) -> Unit,
    viewModel: ScannerViewModel = hiltViewModel(),
) {
    val surfaceRequest by viewModel.surfaceRequest.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current
    val cameraPermission = rememberPermissionState(Manifest.permission.CAMERA)

    LaunchedEffect(cameraPermission.status) {
        if (cameraPermission.status.isGranted) {
            viewModel.bindCamera(lifecycleOwner, context)
        } else {
            cameraPermission.launchPermissionRequest()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.scannedCode.collect { onCodeScanned(it) }
    }

    if (!cameraPermission.status.isGranted) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Camera permission is required to scan.")
        }
        return
    }

    Box(Modifier.fillMaxSize()) {
        surfaceRequest?.let { request ->
            CameraXViewfinder(
                surfaceRequest = request,
                implementationMode = ImplementationMode.EXTERNAL,
                modifier = Modifier.fillMaxSize(),
            )
        }
        FilledTonalButton(
            onClick = { viewModel.takePhoto(context, onSaved = {}, onError = {}) },
            modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp),
        ) { Text("Capture") }
    }
}
```

`AndroidManifest.xml`:

```xml
<uses-feature android:name="android.hardware.camera.any" android:required="false" />
<uses-permission android:name="android.permission.CAMERA" />
```

---

## 12. Adaptive Layouts

### NavigationSuiteScaffold

Picks NavigationBar / NavigationRail / Drawer automatically from the current window size — one composable for phones, tablets, and foldables.

```kotlin
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffold

@Composable
fun AdaptiveShell(navController: NavHostController, currentRoute: NavDestination?) {
    NavigationSuiteScaffold(
        navigationSuiteItems = {
            TopLevelDestination.entries.forEach { dest ->
                item(
                    selected = currentRoute?.hasRoute(dest.route::class) == true,
                    onClick = { navController.navigate(dest.route) },
                    icon = { Icon(dest.icon, contentDescription = dest.label) },
                    label = { Text(dest.label) },
                )
            }
        },
    ) {
        AppNavGraph(navController = navController)
    }
}
```

### WindowSizeClass

```kotlin
import androidx.compose.material3.adaptive.currentWindowAdaptiveInfo
import androidx.window.core.layout.WindowWidthSizeClass

@Composable
fun FeedContainer() {
    val widthClass = currentWindowAdaptiveInfo().windowSizeClass.windowWidthSizeClass
    if (widthClass == WindowWidthSizeClass.EXPANDED) {
        ItemListDetail() // two-pane on tablets / unfolded devices
    } else {
        FeedScreen()     // single pane on phones
    }
}
```

### ListDetailPaneScaffold

Coordinates a list pane and a detail pane, collapsing to a single pane on narrow windows and driving back navigation through the pane navigator.

```kotlin
import androidx.compose.material3.adaptive.layout.*
import androidx.compose.material3.adaptive.navigation.*

@OptIn(ExperimentalMaterial3AdaptiveApi::class)
@Composable
fun ItemListDetail() {
    val navigator = rememberListDetailPaneScaffoldNavigator<Long>()

    BackHandler(navigator.canNavigateBack()) {
        // suspending navigateBack — launch from a coroutine scope in real code
    }

    ListDetailPaneScaffold(
        directive = navigator.scaffoldDirective,
        value = navigator.scaffoldValue,
        listPane = {
            AnimatedPane {
                ItemGrid(
                    items = emptyList(),
                    onItemClick = { id ->
                        // navigateTo is suspending — call it inside a coroutine
                    },
                )
            }
        },
        detailPane = {
            AnimatedPane {
                val id = navigator.currentDestination?.contentKey
                if (id != null) DetailScreen(itemId = id) else EmptyDetailPlaceholder()
            }
        },
    )
}
```

---

## 13. Edge-to-Edge

Call `enableEdgeToEdge()` before `super.onCreate` so the app draws behind the system bars. `Scaffold` and Material 3 bars consume their own insets; only custom, bar-less screens apply insets manually.

```kotlin
package com.example.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.rememberNavController
import com.example.app.ui.theme.AppTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()          // before super.onCreate
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                AppRoot {           // installs the singleton Coil ImageLoader
                    AppScaffold(rememberNavController())
                }
            }
        }
    }
}
```

Rules:

- `Scaffold` hands you `innerPadding` — feed it to your content, once.
- `TopAppBar`, `NavigationBar`, and `ModalBottomSheet` auto-handle their own insets.
- Custom full-bleed layouts: `Modifier.windowInsetsPadding(WindowInsets.systemBars)`.
- A root-level `LazyColumn` without a Scaffold: `contentPadding = WindowInsets.systemBars.asPaddingValues()`.
- Never double-apply insets — if the Scaffold consumed them, content must not add them again.

```kotlin
import androidx.compose.foundation.layout.*

@Composable
fun CustomBarlessScreen(items: List<Item>) {
    Box(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars),
    ) {
        LazyColumn(
            contentPadding = PaddingValues(
                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding(),
            ),
        ) {
            items(items, key = { it.id }) { item -> ItemRow(item) }
        }
    }
}
```

---

## 14. Forms, Snackbar, Runtime Permissions

### OutlinedTextField with validation

```kotlin
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.KeyboardType

@Composable
fun ValidatedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    error: String?,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        isError = error != null,
        supportingText = error?.let { { Text(it, color = MaterialTheme.colorScheme.error) } },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        singleLine = true,
        modifier = modifier.fillMaxWidth(),
    )
}
```

### ExposedDropdownMenuBox

```kotlin
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DropdownSelector(
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
        modifier = modifier,
    ) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = { onSelect(option); expanded = false },
                )
            }
        }
    }
}
```

### Snackbar via Scaffold + ViewModel events

```kotlin
@Composable
fun ScreenWithSnackbar(viewModel: FeedViewModel = hiltViewModel()) {
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.uiEvent.collect { event ->
            when (event) {
                is UiEvent.ShowSnackbar -> {
                    val result = snackbarHostState.showSnackbar(
                        message = event.message,
                        actionLabel = event.actionLabel,
                        duration = SnackbarDuration.Short,
                    )
                    if (result == SnackbarResult.ActionPerformed) viewModel.onSnackbarAction()
                }
            }
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { padding ->
        // screen content, using padding
    }
}
```

Rules:

- One `SnackbarHostState` per `Scaffold`.
- Trigger snackbars from a `LaunchedEffect` collecting ViewModel events, not directly from click handlers.
- Use `SnackbarDuration.Indefinite` only alongside an action label (dismiss or retry).

### Permission with rationale (non-camera example)

```kotlin
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

@Composable
fun PermissionGate(permission: String, content: @Composable () -> Unit) {
    val context = LocalContext.current
    var showRationale by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> if (!granted) showRationale = true }

    val granted = ContextCompat.checkSelfPermission(context, permission) ==
        PackageManager.PERMISSION_GRANTED

    when {
        granted -> content()
        showRationale -> AlertDialog(
            onDismissRequest = { showRationale = false },
            title = { Text("Permission required") },
            text = { Text("This feature needs the permission. Grant it in Settings.") },
            confirmButton = {
                TextButton(onClick = {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", context.packageName, null)
                        },
                    )
                }) { Text("Open Settings") }
            },
            dismissButton = { TextButton(onClick = { showRationale = false }) { Text("Cancel") } },
        )
        else -> LaunchedEffect(Unit) { launcher.launch(permission) }
    }
}
```

Rules:

- Always check the current permission state before launching a request.
- Show a rationale after denial that explains *why* the permission is needed.
- After a permanent denial, route the user to app Settings.
- For several permissions at once, use `ActivityResultContracts.RequestMultiplePermissions()`.
- Never hard-block the whole UI on a permission — offer a degraded experience.
