# android-native — Claude Code skill

A self-contained Claude Code skill for building **modern, standalone native Android apps** in Kotlin:
Jetpack Compose + Material 3, MVVM/MVI with ViewModels and StateFlow, Navigation Compose, Coroutines/Flow,
Retrofit/OkHttp + kotlinx.serialization, Room + DataStore, Hilt, Coil, CameraX, WorkManager, and testing.

All versions were verified compilable (`./gradlew :app:assembleDebug` → BUILD SUCCESSFUL) on **2026-07-05**.

## What's inside

```
android-native/
├── SKILL.md                    # entry point: stack, quick start, architecture, workflow, antipatterns
└── references/
    ├── project-setup.md        # Gradle, version catalog, toolchain (build-verified)
    ├── architecture.md         # MVVM/MVI, ViewModels, state, Hilt DI, error handling
    ├── data-layer.md           # Retrofit/OkHttp, Room, DataStore, repositories (offline-first)
    ├── compose.md              # UI: theming, lists, animations, Coil, CameraX, adaptive, edge-to-edge
    ├── coroutines.md           # Flow, StateFlow vs SharedFlow, WorkManager
    ├── navigation.md           # type-safe Navigation Compose, nested graphs, deep links
    └── testing.md              # ViewModel unit tests, Compose UI tests, screenshot tests
```

## Installation

1. **Unzip** the download:

   ```bash
   unzip android-native.zip
   ```

2. **Copy** the `android-native/` folder into your Claude Code skills directory — either per-user or
   per-project:

   ```bash
   # per-user (available in every project)
   mkdir -p ~/.claude/skills
   cp -r android-native ~/.claude/skills/

   # …or per-project (checked in with a repo)
   mkdir -p .claude/skills
   cp -r android-native .claude/skills/
   ```

3. **Restart Claude Code** (or reload the window) so it picks up the new skill.

Once installed, the skill activates automatically whenever you work on native Android tasks — Jetpack
Compose, ViewModels, Room, Hilt, Retrofit, or scaffolding an Android project from scratch. You can also
mention it explicitly.

## Requirements to build the apps it describes

- **JDK 17**
- **Android Studio** (latest stable) or the Android command-line SDK tools
- **Android SDK Platform 37** + build-tools

---

Cortesía de Talent Academy · Vibe Coder.
