#!/usr/bin/env python3
"""
gtm_helper.py -- Google Tag Manager API v2 wrapper.

Manages GTM containers, tags, triggers, variables, versions, and publishing.
Import as a module or run directly from the command line.

Dependencies:
    pip install google-auth google-auth-httplib2 google-api-python-client

Environment variables:
    GOOGLE_APPLICATION_CREDENTIALS  -- Path to Service Account JSON key file
    GTM_SERVICE_ACCOUNT_KEY         -- Alternative path to the key file

CLI:
    python gtm_helper.py list_accounts --credentials /path/to/creds.json
    python gtm_helper.py list_containers --credentials creds.json --account-id 123456
    python gtm_helper.py create_tag --path "accounts/1/containers/2/workspaces/3" --config '...'
    python gtm_helper.py publish --account-id 1 --container-id 2 --version-name "v1.0"

Module:
    from gtm_helper import GTMHelper
    helper = GTMHelper(credentials_path="/path/to/creds.json")
    accounts = helper.list_accounts()
"""

import argparse
import json
import logging
import os
import random
import sys
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, TypeVar

try:
    from google.oauth2 import service_account
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
except ImportError as exc:
    sys.exit(f"Missing dependency: {exc}\n"
             "Install: pip install google-auth google-auth-httplib2 google-api-python-client")

# ---------------------------------------------------------------------------
# Logging & Constants
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S")
logger = logging.getLogger("gtm_helper")
T = TypeVar("T")

GTM_SCOPES = [
    "https://www.googleapis.com/auth/tagmanager.edit.containers",
    "https://www.googleapis.com/auth/tagmanager.edit.containerversions",
    "https://www.googleapis.com/auth/tagmanager.publish",
    "https://www.googleapis.com/auth/tagmanager.readonly",
    "https://www.googleapis.com/auth/tagmanager.manage.users",
]

# ---------------------------------------------------------------------------
# Custom Exception
# ---------------------------------------------------------------------------

class GTMError(Exception):
    """Raised for any GTM API or configuration error."""
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code

# ---------------------------------------------------------------------------
# Circuit Breaker
# ---------------------------------------------------------------------------

@dataclass
class CircuitBreaker:
    """Protects against cascading failures from repeated GTM API rate-limits.

    States: closed (normal) -> open (blocked) -> half_open (probe one request).
    """
    failure_threshold: int = 5
    recovery_timeout: float = 60.0
    _failure_count: int = field(default=0, init=False, repr=False)
    _state: str = field(default="closed", init=False, repr=False)
    _last_failure_time: float = field(default=0.0, init=False, repr=False)

    def can_execute(self) -> bool:
        if self._state == "closed":
            return True
        if self._state == "open":
            if time.time() - self._last_failure_time >= self.recovery_timeout:
                self._state = "half_open"
                logger.info("Circuit breaker: open -> half_open")
                return True
            return False
        return self._state == "half_open"

    def record_success(self) -> None:
        if self._state != "closed":
            logger.info("Circuit breaker: %s -> closed", self._state)
        self._failure_count = 0
        self._state = "closed"

    def record_failure(self) -> None:
        self._failure_count += 1
        self._last_failure_time = time.time()
        if self._failure_count >= self.failure_threshold:
            self._state = "open"
            logger.warning("Circuit breaker OPEN after %d failures. Recovery in %.0fs.",
                           self._failure_count, self.recovery_timeout)

    @property
    def state(self) -> str:
        return self._state

# ---------------------------------------------------------------------------
# Retry with Exponential Backoff + Jitter
# ---------------------------------------------------------------------------

def retry_with_backoff(
    fn: Callable[[], T], max_retries: int = 5, base_delay: float = 1.0,
    max_delay: float = 60.0, retryable_codes: tuple = (429, 500, 502, 503),
    circuit_breaker: Optional[CircuitBreaker] = None,
) -> T:
    """Execute *fn* with exponential backoff, jitter, and optional circuit-breaker."""
    if circuit_breaker and not circuit_breaker.can_execute():
        raise GTMError(f"Circuit breaker open -- recovery in {circuit_breaker.recovery_timeout}s")

    last_exc: Optional[Exception] = None
    for attempt in range(max_retries):
        try:
            result = fn()
            if circuit_breaker:
                circuit_breaker.record_success()
            return result
        except HttpError as exc:
            last_exc = exc
            code = exc.resp.status if exc.resp else None
            if code in retryable_codes and attempt < max_retries - 1:
                delay = min(base_delay * (2 ** attempt) + random.uniform(0, 1), max_delay)
                logger.warning("Retry %d/%d after %.1fs (HTTP %s)", attempt + 1, max_retries, delay, code)
                time.sleep(delay)
            else:
                if circuit_breaker:
                    circuit_breaker.record_failure()
                raise GTMError(f"GTM API error (HTTP {code}): {exc}", status_code=code) from exc
        except Exception as exc:
            if circuit_breaker:
                circuit_breaker.record_failure()
            raise GTMError(f"Unexpected error: {exc}") from exc
    raise GTMError(f"Max retries ({max_retries}) exhausted. Last: {last_exc}")

# ===========================================================================
# GTMHelper
# ===========================================================================

class GTMHelper:
    """High-level wrapper around the Google Tag Manager API v2.

    Args:
        credentials_path: Service Account JSON key. Falls back to
            GOOGLE_APPLICATION_CREDENTIALS / GTM_SERVICE_ACCOUNT_KEY env vars.
        max_retries: Retries per API call (default 5).
        cb_threshold: Failures before circuit breaker trips.
        cb_recovery: Seconds before half-opening the breaker.
    """

    def __init__(self, credentials_path: Optional[str] = None, max_retries: int = 5,
                 cb_threshold: int = 5, cb_recovery: float = 60.0):
        self._creds_path = self._resolve_credentials(credentials_path)
        self._max_retries = max_retries
        self._cb = CircuitBreaker(failure_threshold=cb_threshold, recovery_timeout=cb_recovery)
        self._service = self._build_service()
        logger.info("GTMHelper initialised (credentials=%s)", self._creds_path)

    # -- internal ----------------------------------------------------------

    @staticmethod
    def _resolve_credentials(path: Optional[str] = None) -> str:
        for p in [path, os.environ.get("GOOGLE_APPLICATION_CREDENTIALS"),
                   os.environ.get("GTM_SERVICE_ACCOUNT_KEY")]:
            if p and os.path.isfile(p):
                return p
        raise GTMError("No credentials found. Set --credentials, "
                       "GOOGLE_APPLICATION_CREDENTIALS, or GTM_SERVICE_ACCOUNT_KEY.")

    def _build_service(self):
        try:
            creds = service_account.Credentials.from_service_account_file(
                self._creds_path, scopes=GTM_SCOPES)
            return build("tagmanager", "v2", credentials=creds, cache_discovery=False)
        except Exception as exc:
            raise GTMError(f"Failed to build GTM service: {exc}") from exc

    def _call(self, req) -> Any:
        """Execute a google-api-python-client request with retry + circuit breaker."""
        return retry_with_backoff(fn=req.execute, max_retries=self._max_retries,
                                  circuit_breaker=self._cb)

    @staticmethod
    def build_workspace_path(account_id: str, container_id: str, workspace_id: str = "0") -> str:
        """accounts/{accountId}/containers/{containerId}/workspaces/{workspaceId}"""
        return f"accounts/{account_id}/containers/{container_id}/workspaces/{workspace_id}"

    # -- discovery ---------------------------------------------------------

    def list_accounts(self) -> List[Dict[str, Any]]:
        """List all GTM accounts accessible to the service account."""
        accts = self._call(self._service.accounts().list()).get("account", [])
        logger.info("Found %d account(s).", len(accts))
        return accts

    def list_containers(self, account_id: str) -> List[Dict[str, Any]]:
        """List containers under *account_id*."""
        items = self._call(
            self._service.accounts().containers().list(parent=f"accounts/{account_id}")
        ).get("container", [])
        logger.info("Found %d container(s) in account %s.", len(items), account_id)
        return items

    def list_workspaces(self, account_id: str, container_id: str) -> List[Dict[str, Any]]:
        """List workspaces inside a container."""
        parent = f"accounts/{account_id}/containers/{container_id}"
        items = self._call(
            self._service.accounts().containers().workspaces().list(parent=parent)
        ).get("workspace", [])
        logger.info("Found %d workspace(s) in container %s.", len(items), container_id)
        return items

    # -- tags --------------------------------------------------------------

    def list_tags(self, path: str) -> List[Dict[str, Any]]:
        """List all tags in a workspace (*path*)."""
        tags = self._call(
            self._service.accounts().containers().workspaces().tags().list(parent=path)
        ).get("tag", [])
        logger.info("Found %d tag(s).", len(tags))
        return tags

    def get_tag(self, path: str, tag_id: str) -> Dict[str, Any]:
        """Get a single tag by *tag_id* within *path*."""
        tag = self._call(
            self._service.accounts().containers().workspaces().tags().get(
                path=f"{path}/tags/{tag_id}"))
        logger.info("Retrieved tag %s: %s", tag_id, tag.get("name", ""))
        return tag

    def create_tag(self, path: str, tag_config: Dict[str, Any]) -> Dict[str, Any]:
        """Create a tag from *tag_config* (see references/tag-templates.md)."""
        tag = self._call(
            self._service.accounts().containers().workspaces().tags().create(
                parent=path, body=tag_config))
        logger.info("Created tag '%s' (ID: %s).", tag.get("name", ""), tag.get("tagId", "?"))
        return tag

    def update_tag(self, path: str, tag_id: str, tag_config: Dict[str, Any]) -> Dict[str, Any]:
        """Update tag *tag_id* with *tag_config*."""
        tag = self._call(
            self._service.accounts().containers().workspaces().tags().update(
                path=f"{path}/tags/{tag_id}", body=tag_config))
        logger.info("Updated tag %s.", tag_id)
        return tag

    def delete_tag(self, path: str, tag_id: str) -> None:
        """Delete tag *tag_id* from *path*."""
        self._call(
            self._service.accounts().containers().workspaces().tags().delete(
                path=f"{path}/tags/{tag_id}"))
        logger.info("Deleted tag %s.", tag_id)

    # -- triggers ----------------------------------------------------------

    def list_triggers(self, path: str) -> List[Dict[str, Any]]:
        """List all triggers in workspace *path*."""
        items = self._call(
            self._service.accounts().containers().workspaces().triggers().list(parent=path)
        ).get("trigger", [])
        logger.info("Found %d trigger(s).", len(items))
        return items

    def create_trigger(self, path: str, trigger_config: Dict[str, Any]) -> Dict[str, Any]:
        """Create a trigger from *trigger_config*."""
        trg = self._call(
            self._service.accounts().containers().workspaces().triggers().create(
                parent=path, body=trigger_config))
        logger.info("Created trigger '%s' (ID: %s).", trg.get("name", ""), trg.get("triggerId", "?"))
        return trg

    # -- variables ---------------------------------------------------------

    def list_variables(self, path: str) -> List[Dict[str, Any]]:
        """List user-defined variables in workspace *path*."""
        items = self._call(
            self._service.accounts().containers().workspaces().variables().list(parent=path)
        ).get("variable", [])
        logger.info("Found %d variable(s).", len(items))
        return items

    def create_variable(self, path: str, variable_config: Dict[str, Any]) -> Dict[str, Any]:
        """Create a variable from *variable_config*."""
        var = self._call(
            self._service.accounts().containers().workspaces().variables().create(
                parent=path, body=variable_config))
        logger.info("Created variable '%s' (ID: %s).", var.get("name", ""), var.get("variableId", "?"))
        return var

    # -- versioning & publishing -------------------------------------------

    def create_version(self, path: str, name: str, notes: str = "") -> Dict[str, Any]:
        """Create a container version from the workspace.

        Returns the API response with 'containerVersion' or 'compilerError'.
        """
        resp = self._call(
            self._service.accounts().containers().workspaces().create_version(
                path=path, body={"name": name, "notes": notes}))
        vid = resp.get("containerVersion", {}).get("containerVersionId", "?")
        logger.info("Created version '%s' (ID: %s).", name, vid)
        return resp

    def publish(self, path: str) -> Dict[str, Any]:
        """Create a version from the workspace and publish it (make live).

        Requires the Service Account to hold *Publish* permission and the
        ``tagmanager.publish`` + ``tagmanager.edit.containerversions`` scopes.
        """
        create_resp = self.create_version(path, name="Auto-publish")
        version = create_resp.get("containerVersion")
        if not version:
            err = create_resp.get("compilerError")
            if err:
                raise GTMError(f"Compiler error: {json.dumps(err, indent=2)}")
            raise GTMError("No containerVersion returned -- workspace may have no pending changes.")
        vpath = version.get("path")
        if not vpath:
            raise GTMError("Created version has no path; cannot publish.")

        pub = self._call(self._service.accounts().containers().versions().publish(path=vpath))
        pv = pub.get("containerVersion", {})
        logger.info("Published version %s (fingerprint: %s).",
                     pv.get("containerVersionId", "?"), pv.get("fingerprint", "?"))
        return pub

    # -- snippet -----------------------------------------------------------

    def get_snippet(self, path: str) -> Dict[str, str]:
        """Return the container install snippet (JS + noscript iframe).

        The *path* is normalised to container level internally.
        """
        container_path = "/".join(path.split("/")[:4])  # accounts/X/containers/Y
        envs = self._call(
            self._service.accounts().containers().environments().list(parent=container_path)
        ).get("environment", [])

        for env in envs:
            if env.get("type", "") in ("latest", "live") and env.get("snippet"):
                logger.info("Snippet from '%s' environment.", env["type"])
                return {"snippet": env["snippet"], "environment": env["type"]}
        if envs and envs[0].get("snippet"):
            logger.info("Snippet from first available environment.")
            return {"snippet": envs[0]["snippet"], "environment": envs[0].get("type", "unknown")}
        raise GTMError(f"No snippet found for {container_path}.")

# ===========================================================================
# CLI
# ===========================================================================

def _load_json(raw: str) -> Dict[str, Any]:
    """Parse inline JSON or load from @filepath."""
    if raw.startswith("@"):
        fp = raw[1:]
        if not os.path.isfile(fp):
            raise GTMError(f"File not found: {fp}")
        with open(fp, "r", encoding="utf-8") as f:
            return json.load(f)
    return json.loads(raw)


def _add_path_args(p: argparse.ArgumentParser) -> None:
    """Add --path or --account-id/--container-id/--workspace-id."""
    g = p.add_mutually_exclusive_group()
    g.add_argument("--path", help="Full workspace path (accounts/X/containers/Y/workspaces/Z)")
    p.add_argument("--account-id", help="GTM Account ID")
    p.add_argument("--container-id", help="GTM Container ID")
    p.add_argument("--workspace-id", default="0", help="GTM Workspace ID (default: 0)")


def _resolve_path(a: argparse.Namespace) -> str:
    if getattr(a, "path", None):
        return a.path
    aid, cid = getattr(a, "account_id", None), getattr(a, "container_id", None)
    wid = getattr(a, "workspace_id", "0")
    if aid and cid:
        return GTMHelper.build_workspace_path(aid, cid, wid)
    raise GTMError("Provide --path or both --account-id and --container-id.")


def _build_parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(prog="gtm_helper.py",
                                   description="Google Tag Manager API v2 CLI wrapper")
    root.add_argument("--credentials", metavar="PATH", help="Service Account JSON key")
    root.add_argument("-v", "--verbose", action="store_true", help="DEBUG logging")
    sub = root.add_subparsers(dest="command", required=True)

    # Simple commands (no extra args beyond path)
    sub.add_parser("list_accounts", help="List GTM accounts")

    for name, help_text, extra in [
        ("list_containers", "List containers", [("--account-id", True)]),
        ("list_workspaces", "List workspaces",
         [("--account-id", True), ("--container-id", True)]),
    ]:
        p = sub.add_parser(name, help=help_text)
        for flag, req in extra:
            p.add_argument(flag, required=req)

    # Path-based list commands
    for name in ["list_tags", "list_triggers", "list_variables"]:
        p = sub.add_parser(name, help=f"{name.replace('_', ' ').title()}")
        _add_path_args(p)

    # get_tag
    p = sub.add_parser("get_tag", help="Get a single tag")
    p.add_argument("--tag-id", required=True)
    _add_path_args(p)

    # create / update / delete tag
    for cmd, extra_args in [
        ("create_tag", [("--tag-json", True, "Tag JSON or @file")]),
        ("update_tag", [("--tag-id", True, "Tag ID"), ("--tag-json", True, "Tag JSON or @file")]),
        ("delete_tag", [("--tag-id", True, "Tag ID")]),
    ]:
        p = sub.add_parser(cmd, help=cmd.replace("_", " ").title())
        for flag, req, hlp in extra_args:
            p.add_argument(flag, required=req, help=hlp)
        _add_path_args(p)

    # create_trigger / create_variable
    for cmd, json_flag in [("create_trigger", "--trigger-json"), ("create_variable", "--variable-json")]:
        p = sub.add_parser(cmd, help=cmd.replace("_", " ").title())
        p.add_argument(json_flag, required=True, help="JSON config or @file")
        _add_path_args(p)

    # create_version
    p = sub.add_parser("create_version", help="Create container version")
    p.add_argument("--version-name", required=True)
    p.add_argument("--notes", default="")
    _add_path_args(p)

    # publish
    p = sub.add_parser("publish", help="Create version and publish (make live)")
    p.add_argument("--version-name", default="CLI publish")
    _add_path_args(p)

    # get_snippet
    p = sub.add_parser("get_snippet", help="Print container install snippet")
    _add_path_args(p)

    return root


def _out(data: Any) -> None:
    print(json.dumps(data, indent=2, ensure_ascii=False))


def _run(args: argparse.Namespace) -> None:
    h = GTMHelper(credentials_path=args.credentials)
    c = args.command

    # -- discovery
    if c == "list_accounts":
        _out(h.list_accounts())
    elif c == "list_containers":
        _out(h.list_containers(args.account_id))
    elif c == "list_workspaces":
        _out(h.list_workspaces(args.account_id, args.container_id))
    # -- list resources
    elif c == "list_tags":
        _out(h.list_tags(_resolve_path(args)))
    elif c == "list_triggers":
        _out(h.list_triggers(_resolve_path(args)))
    elif c == "list_variables":
        _out(h.list_variables(_resolve_path(args)))
    # -- single tag
    elif c == "get_tag":
        _out(h.get_tag(_resolve_path(args), args.tag_id))
    # -- CRUD
    elif c == "create_tag":
        _out(h.create_tag(_resolve_path(args), _load_json(args.tag_json)))
    elif c == "update_tag":
        _out(h.update_tag(_resolve_path(args), args.tag_id, _load_json(args.tag_json)))
    elif c == "delete_tag":
        h.delete_tag(_resolve_path(args), args.tag_id)
        print(f"Tag {args.tag_id} deleted.")
    elif c == "create_trigger":
        _out(h.create_trigger(_resolve_path(args), _load_json(args.trigger_json)))
    elif c == "create_variable":
        _out(h.create_variable(_resolve_path(args), _load_json(args.variable_json)))
    # -- versioning
    elif c == "create_version":
        _out(h.create_version(_resolve_path(args), args.version_name, args.notes))
    elif c == "publish":
        _out(h.publish(_resolve_path(args)))
    elif c == "get_snippet":
        _out(h.get_snippet(_resolve_path(args)))
    else:
        raise GTMError(f"Unknown command: {c}")

# ===========================================================================
# Entry Point
# ===========================================================================

def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        logger.setLevel(logging.DEBUG)
    try:
        _run(args)
    except GTMError as exc:
        logger.error("GTMError: %s", exc)
        sys.exit(1)
    except KeyboardInterrupt:
        logger.info("Interrupted.")
        sys.exit(130)


if __name__ == "__main__":
    main()
