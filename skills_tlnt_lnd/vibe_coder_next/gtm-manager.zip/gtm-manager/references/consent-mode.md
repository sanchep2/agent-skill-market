# Consent Mode v2 Implementation Guide

## Table of Contents
- [Overview](#overview)
- [The Six Consent Parameters](#the-six-consent-parameters)
- [Basic vs Advanced Consent Mode](#basic-vs-advanced-consent-mode)
  - [Basic Consent Mode](#basic-consent-mode)
  - [Advanced Consent Mode](#advanced-consent-mode)
- [Implementation Steps](#implementation-steps)
  - [Step 1: Create Consent Default Tag](#step-1-create-consent-default-tag)
  - [Step 2: Integrate CMP](#step-2-integrate-cmp)
  - [Step 3: Configure Tag Consent Settings](#step-3-configure-tag-consent-settings)
  - [Step 4: Additional Settings](#step-4-additional-settings)
- [Non-Google Tags (Meta, LinkedIn, TikTok, X)](#non-google-tags-meta-linkedin-tiktok-x)
- [TCF v2.3 Deadline](#tcf-v23-deadline)
  - [Accion inmediata requerida](#accion-inmediata-requerida)
- [German Court Ruling (March 2025)](#german-court-ruling-march-2025)
- [Consent Overview in GTM UI](#consent-overview-in-gtm-ui)

## Overview

Google Consent Mode v2 became mandatory for EEA/UK traffic in March 2024. Without it, Google Ads loses remarketing audiences, conversion modeling, and bidding optimization for European users.

## The Six Consent Parameters

| Parameter | Purpose | Default (deny all) |
|-----------|---------|-------------------|
| `ad_storage` | Advertising cookies (Google Ads, Floodlight) | `denied` |
| `analytics_storage` | Analytics cookies (GA4) | `denied` |
| `ad_user_data` | Sending user data to Google for advertising **(NEW in v2)** | `denied` |
| `ad_personalization` | Personalized advertising / remarketing **(NEW in v2)** | `denied` |
| `functionality_storage` | Enhanced functionality (language prefs, etc.) | `denied` |
| `security_storage` | Security-related storage | `granted` |

## Basic vs Advanced Consent Mode

### Basic Consent Mode
- Tags are completely blocked until consent is granted
- No data sent to Google when consent is denied
- No conversion modeling for non-consented users
- **Legally safest** option

### Advanced Consent Mode
- Tags load on page load regardless of consent
- When consent is denied, sends anonymous "cookieless pings" (no cookies set, no user IDs)
- Google uses these pings for ML-based conversion modeling (typically 15-25% uplift in reported conversions)
- Minimum threshold: 700 ad clicks per country/domain over 7 days
- **Higher data recovery** but debated legal compliance in some jurisdictions

## Implementation Steps

### Step 1: Create Consent Default Tag

Fire on the **Consent Initialization** trigger (ID `2147479573`). This must fire before any other tag.

```javascript
gtag('consent', 'default', {
  'ad_storage': 'denied',
  'analytics_storage': 'denied',
  'ad_user_data': 'denied',
  'ad_personalization': 'denied',
  'functionality_storage': 'denied',
  'personalization_storage': 'denied',
  'security_storage': 'granted',
  'wait_for_update': 500  // ms to wait for CMP
});
```

For region-specific defaults (e.g., deny only for EEA, grant for others):
```javascript
gtag('consent', 'default', {
  'ad_storage': 'denied',
  'analytics_storage': 'denied',
  'ad_user_data': 'denied',
  'ad_personalization': 'denied',
  'region': ['AT','BE','BG','HR','CY','CZ','DK','EE','FI','FR','DE','GR','HU','IE','IT','LV','LT','LU','MT','NL','PL','PT','RO','SK','SI','ES','SE','IS','LI','NO','GB']
});

// Grant by default for rest of world
gtag('consent', 'default', {
  'ad_storage': 'granted',
  'analytics_storage': 'granted',
  'ad_user_data': 'granted',
  'ad_personalization': 'granted'
});
```

### Step 2: Integrate CMP

Most CMPs offer a GTM template in the Community Gallery:
- **Cookiebot** — Template available, auto-updates consent
- **Usercentrics** — Template available, also offers integrated sGTM hosting
- **OneTrust** — Template available
- **CookieYes** — Template available
- **Didomi** — Template available
- **Termly** — Template available
- **Consentmanager** — Template available

The CMP calls `gtag('consent', 'update', {...})` when the user grants or denies consent. This triggers GTM's consent infrastructure to fire or block tags accordingly.

### Step 3: Configure Tag Consent Settings

For each tag, set `consentSettings` in the API:

```json
{
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "analytics_storage": true
    }
  }
}
```

`consentStatus` values:
- `"needed"` — Tag requires the specified consent types to fire
- `"notNeeded"` — Tag fires regardless of consent (use for essential tags only)
- `"notSet"` — No consent requirement configured (default for existing tags)

### Step 4: Additional Settings

For Google tags, these additional parameters can be set via the Google Tag's config:

- **`ads_data_redaction`**: When `true` AND `ad_storage` is denied, redacts ad click IDs from requests
- **`url_passthrough`**: When `true`, passes ad click info (gclid, dclid) via URL parameters instead of cookies when `ad_storage` is denied

## Non-Google Tags (Meta, LinkedIn, TikTok, X)

Google's built-in consent checks only apply to Google tags (GA4, Ads, Floodlight). For third-party tags:

1. **Option A**: Use GTM's `consentSettings` — if the tag checks `ad_storage`, it will wait for that consent type to be granted
2. **Option B**: Create custom triggers that fire only when consent is granted (e.g., Custom Event trigger for `consent_granted`)
3. **Option C**: Use the tag's own consent mechanisms (Meta's `fbq('consent', 'revoke')`, TikTok's `ttq.holdConsent()`)

Best practice is to combine Option A with Option C for defense-in-depth.

## TCF v2.3 Deadline

> **URGENTE — Deadline 28 de febrero de 2026.** Faltan días para que Google rechace TC Strings v2.2.

Google mandó migrar de TCF v2.2 a TCF v2.3 con fecha límite **28 de febrero de 2026**. A partir de esa fecha:

- **TC Strings v2.2 serán inválidas** — Google las ignorará completamente
- **Ad requests caerán a "Limited Ads"** — sin personalización, sin remarketing, sin modelado de conversiones
- **Revenue programático puede bajar >50%** para tráfico EEA/UK sin strings v2.3 válidas

### Acción inmediata requerida

1. **Verificar con tu CMP** que ya genera strings TCF v2.3 (no v2.2)
2. Confirmar que el segmento `disclosedVendors` (obligatorio en v2.3) está presente en las TC Strings generadas
3. Testear con [TCF String Decoder](https://iabtcf.com/#/decode) que la versión reportada sea `3` (campo `cmpVersion`)
4. Si tu CMP no soporta v2.3, migrar inmediatamente a uno que sí (Cookiebot, Usercentrics, OneTrust, Didomi — todos soportan v2.3)

## German Court Ruling (March 2025)

The Administrative Court of Hannover ruled that **GTM itself requires user consent** before loading, as it transmits IP addresses and device data to Google upon initialization. This creates a circular problem: if GTM loads the CMP, but GTM itself needs consent...

Mitigations:
- Load the CMP **outside of GTM** (directly in the page HTML)
- Use **server-side GTM** to avoid client-side data transmission
- Load GTM only after initial consent is granted for "necessary" cookies
- Monitor whether this ruling gets adopted more broadly in the EU

## Consent Overview in GTM UI

Enable via Admin → Container Settings → "Enable consent overview". This shows a visual dashboard of which tags require which consent types. Not accessible via API but useful for manual verification.
