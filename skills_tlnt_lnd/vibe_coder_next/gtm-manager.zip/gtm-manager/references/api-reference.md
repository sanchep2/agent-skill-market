# GTM API v2 Quick Reference (February 2026)

## Table of Contents
- [API Status](#api-status)
- [Authentication](#authentication)
  - [Required OAuth Scopes](#required-oauth-scopes)
- [API Base URL](#api-base-url)
- [Resource Hierarchy](#resource-hierarchy)
- [Path Format](#path-format)
- [Common Tag Types](#common-tag-types)
- [Common Trigger Types](#common-trigger-types)
  - [Built-in Trigger IDs](#built-in-trigger-ids)
- [Built-in Variable Types (including Dec 2025 additions)](#built-in-variable-types-including-dec-2025-additions)
  - [Standard](#standard)
  - [New (December 2025)](#new-december-2025)
- [Rate Limits](#rate-limits)
- [Client Libraries](#client-libraries)
- [Alternative CLI Tools](#alternative-cli-tools)

## API Status

The Tag Manager API remains at **v2** — stable, no breaking changes since 2024, no v3 announced. API revision: **20251210** (December 2025). Client libraries last updated September 2025.

## Authentication

The wrapper script handles auth via Service Account. The user needs:

1. **Google Cloud Project** with "Tag Manager API" enabled
2. **Service Account** created in IAM & Admin → Service Accounts
3. **JSON key file** downloaded for the Service Account
4. **GTM permissions**: In GTM UI → Admin → Container-level → User Management → Add the Service Account email with **"Publish" permission** (not just "Edit" — "Edit" allows creating tags but the `publish` command requires "Publish" permission)

### Required OAuth Scopes
- `tagmanager.edit.containers` — Create/edit tags, triggers, variables
- `tagmanager.edit.containerversions` — Create versions from workspaces (required for publish workflow)
- `tagmanager.publish` — Publish versions to make them live
- `tagmanager.readonly` — List/read operations
- `tagmanager.manage.users` — Manage user permissions (rarely needed)

## API Base URL

```
https://tagmanager.googleapis.com/tagmanager/v2/
```

## Resource Hierarchy

```
Account
  └── Container (has a public ID like GTM-XXXXXX)
        ├── Workspace (draft area)
        │     ├── Tags
        │     ├── Triggers
        │     ├── Variables
        │     ├── Folders
        │     ├── Built-in Variables
        │     ├── Templates (custom templates)
        │     ├── Transformations
        │     └── Clients (server-side containers only)
        ├── Versions (published snapshots)
        └── Environments (preview, staging, live)
```

## Path Format

All resources use a hierarchical path:
```
accounts/{accountId}/containers/{containerId}/workspaces/{workspaceId}/tags/{tagId}
```

## Common Tag Types

| Platform | Tag Type | Description |
|----------|----------|-------------|
| **Google Tag** | `googtag` | **Unified tag** for GA4, Ads, Floodlight (replaces `gaawc`) |
| GA4 Event | `gaawe` | Google Analytics 4 event |
| Google Ads Conversion | `awct` | Google Ads conversion tracking |
| Google Ads Remarketing | `sp` | Google Ads remarketing |
| Custom HTML | `html` | Any custom JavaScript/HTML snippet |
| Custom Image | `img` | Pixel image tag |

**Deprecated/obsolete types (do not use):**
| Type | Status |
|------|--------|
| `gaawc` | Replaced by `googtag` (auto-migrated Sep 2023) |
| `ua` | Universal Analytics — stopped collecting Jul 2023/2024 |
| `ua_eventTracker` | Universal Analytics event — dead |

Meta, X, LinkedIn, and TikTok all use `html` (Custom HTML) type for client-side pixels.

## Common Trigger Types

| Type | Description |
|------|-------------|
| `pageview` | Page View |
| `domReady` | DOM Ready |
| `windowLoaded` | Window Loaded |
| `click` | Click (all elements) |
| `linkClick` | Click (just links) |
| `customEvent` | Custom Event (dataLayer.push) |
| `formSubmission` | Form Submission |
| `scrollDepth` | Scroll Depth |
| `timer` | Timer |
| `elementVisibility` | Element Visibility |

### Built-in Trigger IDs
- `"2147479553"` — All Pages
- `"2147479573"` — Consent Initialization (fires before everything else)

## Built-in Variable Types (including Dec 2025 additions)

### Standard
- `{{Page URL}}`, `{{Page Hostname}}`, `{{Page Path}}`
- `{{Click Element}}`, `{{Click Classes}}`, `{{Click ID}}`, `{{Click URL}}`, `{{Click Text}}`
- `{{Form Element}}`
- `{{Event}}` — dataLayer event name
- `{{Referrer}}`
- `{{Container ID}}`, `{{Container Version}}`

### New (December 2025)
- `{{Analytics Client ID}}` — GA4 client_id from cookie
- `{{Analytics Session ID}}` — GA4 session_id
- `{{Analytics Session Number}}` — GA4 session_number

Enable new built-in variables via:
```
POST /tagmanager/v2/{parent}/built_in_variables
?type=googleAnalyticsClientId&type=googleAnalyticsSessionId&type=googleAnalyticsSessionNumber
```

## Rate Limits

- **Write operations**: 5 per second per account
- **Read operations**: 20 per second per account
- HTTP 429 = rate limited. Wait and retry with exponential backoff.

## Client Libraries

| Language | Status | Package |
|----------|--------|---------|
| Python | Stable | `google-api-python-client` |
| Java | Stable | `google-api-services-tagmanager` |
| JavaScript | Stable | `googleapis` npm |
| .NET | Stable | `Google.Apis.TagManager.v2` |
| PHP | Stable | `google/apiclient` |
| Go | Beta | `google.golang.org/api/tagmanager/v2` |
| Ruby | Alpha | `google-apis-tagmanager_v2` |
| Dart | Beta | `googleapis` pub |

## Alternative CLI Tools

Besides our wrapper script, these third-party tools exist:

- **Owntag GTM CLI** (`github.com/owntag/gtm-cli`): Full API coverage, OAuth + SA auth, GitHub Actions examples, AI/LLM `agent guide` command
- **gtm-tools** (Node.js, `github.com/vaidik/gtm-tools`): Dev/prod sync
- **google-tagmanager2-cli** (Rust, `crates.io`): Auto-generated from API spec, v7.0.0
- **Simo Ahava's GTM Tools**: Google Sheets add-on for permissions management

No official Terraform provider exists (open issue #12439). Community providers are early-stage.
