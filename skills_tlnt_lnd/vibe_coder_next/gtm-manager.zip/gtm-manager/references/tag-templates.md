# Tag Templates Reference (v2 — February 2026)

Ready-to-use JSON templates for common tracking platforms. Replace placeholder values (marked with `{{PLACEHOLDER}}`) before creating.

## Table of Contents
1. [Google Tag (GA4 + Ads unified)](#google-tag)
2. [GA4 Event Tag](#ga4-event)
3. [Meta (Facebook) Pixel](#meta)
4. [X (Twitter) Pixel](#x-twitter)
5. [LinkedIn Insight Tag 2.0](#linkedin)
6. [TikTok Pixel](#tiktok)
7. [Google Ads Conversion](#google-ads)
8. [Custom HTML Tag (generic)](#custom-html)
9. [Common Triggers](#triggers)
10. [Common Variables](#variables)
11. [Consent Mode Tags](#consent)

---

## Google Tag

The unified Google Tag (`googtag`) replaces the old GA4 Configuration tag (`gaawc`). It handles GA4, Google Ads, and Floodlight through a single tag.

### Google Tag (base — replaces old GA4 Config)

```json
{
  "name": "Google Tag - {{TAG_ID}}",
  "type": "googtag",
  "parameter": [
    {
      "type": "template",
      "key": "tagId",
      "value": "{{TAG_ID}}"
    },
    {
      "type": "list",
      "key": "configSettingsTable",
      "list": []
    }
  ],
  "firingTriggerId": ["2147479553"],
  "tagFiringOption": "oncePerEvent",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "analytics_storage": true,
      "ad_user_data": true,
      "ad_personalization": true
    }
  }
}
```

Notes:
- `tagId` can be a GA4 Measurement ID (`G-XXXXXXXXXX`), Google Ads ID (`AW-XXXXXXXXX`), or Floodlight ID
- `googtag` is the current tag type — do NOT use `gaawc` for new implementations
- `configSettingsTable` holds key-value configuration like `send_page_view`, `cookie_prefix`, `server_container_url`
- `consentSettings` should always be included for EU-targeting implementations

### Google Tag with sGTM server container

```json
{
  "name": "Google Tag - {{TAG_ID}} (Server-Side)",
  "type": "googtag",
  "parameter": [
    {
      "type": "template",
      "key": "tagId",
      "value": "{{TAG_ID}}"
    },
    {
      "type": "list",
      "key": "configSettingsTable",
      "list": [
        {
          "type": "map",
          "map": [
            { "type": "template", "key": "parameter", "value": "server_container_url" },
            { "type": "template", "key": "parameterValue", "value": "{{SGTM_URL}}" }
          ]
        },
        {
          "type": "map",
          "map": [
            { "type": "template", "key": "parameter", "value": "send_page_view" },
            { "type": "template", "key": "parameterValue", "value": "true" }
          ]
        }
      ]
    }
  ],
  "firingTriggerId": ["2147479553"],
  "tagFiringOption": "oncePerEvent",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "analytics_storage": true,
      "ad_user_data": true,
      "ad_personalization": true
    }
  }
}
```

Notes:
- `server_container_url` points to your sGTM endpoint (e.g., `https://sgtm.yourdomain.com`)
- This routes ALL measurement through your server container for first-party tracking

---

## GA4 Event

### GA4 Event Tag

```json
{
  "name": "GA4 - Event - {{EVENT_NAME}}",
  "type": "gaawe",
  "parameter": [
    {
      "type": "template",
      "key": "eventName",
      "value": "{{EVENT_NAME}}"
    },
    {
      "type": "tagReference",
      "key": "measurementId",
      "value": "Google Tag - {{TAG_ID}}"
    },
    {
      "type": "list",
      "key": "eventParameters",
      "list": [
        {
          "type": "map",
          "map": [
            { "type": "template", "key": "name", "value": "{{PARAM_NAME}}" },
            { "type": "template", "key": "value", "value": "{{PARAM_VALUE}}" }
          ]
        }
      ]
    }
  ],
  "firingTriggerId": ["{{TRIGGER_ID}}"],
  "tagFiringOption": "oncePerEvent",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "analytics_storage": true
    }
  }
}
```

Notes:
- `gaawe` type is still correct for GA4 events
- The `measurementId` references the Google Tag by name (not the old GA4 Config)
- Event parameters are passed as map entries in `eventParameters`

---

## Meta

### Meta Pixel Base Code

```json
{
  "name": "Meta - Pixel Base",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\n!function(f,b,e,v,n,t,s)\n{if(f.fbq)return;n=f.fbq=function(){n.callMethod?\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};\nif(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';\nn.queue=[];t=b.createElement(e);t.async=!0;\nt.src=v;s=b.getElementsByTagName(e)[0];\ns.parentNode.insertBefore(t,s)}(window, document,'script',\n'https://connect.facebook.net/en_US/fbevents.js');\nfbq('init', '{{META_PIXEL_ID}}');\nfbq('track', 'PageView');\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["2147479553"],
  "tagFiringOption": "oncePerPage",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true,
      "ad_personalization": true
    }
  }
}
```

### Meta Standard Event

```json
{
  "name": "Meta - Event - {{EVENT_NAME}}",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\nfbq('track', '{{META_EVENT_NAME}}', {\n  value: {{VALUE}},\n  currency: '{{CURRENCY}}'\n});\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["{{TRIGGER_ID}}"],
  "tagFiringOption": "oncePerEvent",
  "setupTag": [
    {
      "tagName": "Meta - Pixel Base",
      "stopOnSetupFailure": true
    }
  ],
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true
    }
  }
}
```

Notes:
- Meta Pixel ID is a numeric string like `"123456789012345"`
- Standard events: `PageView`, `Purchase`, `Lead`, `CompleteRegistration`, `AddToCart`, `ViewContent`, `InitiateCheckout`, `Search`, `AddPaymentInfo`, `Subscribe`
- `setupTag` ensures the base pixel loads before the event fires
- **IMPORTANT (2026)**: Client-side pixel alone loses ~50% of conversions due to iOS ATT, ad blockers, and consent. Always recommend Meta CAPI via sGTM for production. See `references/server-side.md`.
- Meta 2025 sensitive category restrictions may block Pixel/CAPI for health, financial services, and political content

---

## X (Twitter)

### X Pixel Base Code (unified — replaces legacy Universal Web Tag)

```json
{
  "name": "X - Pixel Base",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\n!function(e,t,n,s,u,a){e.twq||(s=e.twq=function(){s.exe?s.exe.apply(s,arguments):s.queue.push(arguments);\n},s.version='1.1',s.queue=[],u=t.createElement(n),u.async=!0,u.src='https://static.ads-twitter.com/uwt.js',\na=t.getElementsByTagName(n)[0],a.parentNode.insertBefore(u,a))}(window,document,'script');\ntwq('config','{{X_PIXEL_ID}}');\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["2147479553"],
  "tagFiringOption": "oncePerPage",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true
    }
  }
}
```

### X Conversion Event

```json
{
  "name": "X - Event - {{EVENT_NAME}}",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\ntwq('event', '{{X_EVENT_ID}}', {\n  value: {{VALUE}},\n  currency: '{{CURRENCY}}',\n  num_items: {{NUM_ITEMS}}\n});\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["{{TRIGGER_ID}}"],
  "tagFiringOption": "oncePerEvent",
  "setupTag": [
    {
      "tagName": "X - Pixel Base",
      "stopOnSetupFailure": true
    }
  ],
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true
    }
  }
}
```

Notes:
- X Pixel ID format: `"oxxxx"` (starts with 'o')
- X consolidated legacy Universal Web Tag and Single Event Tags into unified X Pixel
- Server-side X CAPI exists (via Stape) but is complex to implement

---

## LinkedIn

### LinkedIn Insight Tag 2.0

```json
{
  "name": "LinkedIn - Insight Tag",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script type=\"text/javascript\">\n_linkedin_partner_id = \"{{LINKEDIN_PARTNER_ID}}\";\nwindow._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];\nwindow._linkedin_data_partner_ids.push(_linkedin_partner_id);\n(function(l) {\nif (!l){window.lintrk = function(a,b){window.lintrk.q.push([a,b])};\nwindow.lintrk.q=[]}\nvar s = document.getElementsByTagName(\"script\")[0];\nvar b = document.createElement(\"script\");\nb.type = \"text/javascript\";b.async = true;\nb.src = \"https://snap.licdn.com/li.lms-analytics/insight.min.js\";\ns.parentNode.insertBefore(b, s);})(window.lintrk);\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["2147479553"],
  "tagFiringOption": "oncePerPage",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true,
      "ad_personalization": true
    }
  }
}
```

### LinkedIn Conversion Event

```json
{
  "name": "LinkedIn - Conversion - {{EVENT_NAME}}",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\nwindow.lintrk('track', { conversion_id: {{LINKEDIN_CONVERSION_ID}} });\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["{{TRIGGER_ID}}"],
  "tagFiringOption": "oncePerEvent",
  "setupTag": [
    {
      "tagName": "LinkedIn - Insight Tag",
      "stopOnSetupFailure": true
    }
  ],
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true
    }
  }
}
```

Notes:
- LinkedIn now offers InsightTag 2.0 template in the GTM Community Gallery (alternative to Custom HTML)
- LinkedIn CAPI is available for sGTM — recommended for B2B where ad blockers affect 30-50% of executive traffic
- Use shared `event_id` for deduplication when running both browser + server-side

---

## TikTok

### TikTok Pixel Base Code

```json
{
  "name": "TikTok - Pixel Base",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\n!function (w, d, t) {\n  w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=[\"page\",\"track\",\"identify\",\"instances\",\"debug\",\"on\",\"off\",\"once\",\"ready\",\"alias\",\"group\",\"enableCookie\",\"disableCookie\",\"holdConsent\",\"revokeConsent\",\"grantConsent\"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var r=\"https://analytics.tiktok.com/i18n/pixel/events.js\",o=n&&n.partner;ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=r,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};var i=document.createElement(\"script\");i.type=\"text/javascript\",i.async=!0,i.src=r+\"?sdkid=\"+e+\"&lib=\"+t;var a=document.getElementsByTagName(\"script\")[0];a.parentNode.insertBefore(i,a)};\n  ttq.load('{{TIKTOK_PIXEL_ID}}');\n  ttq.page();\n}(window, document, 'ttq');\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["2147479553"],
  "tagFiringOption": "oncePerPage",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true
    }
  }
}
```

### TikTok Event

```json
{
  "name": "TikTok - Event - {{EVENT_NAME}}",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\nttq.track('{{TIKTOK_EVENT_NAME}}', {\n  value: {{VALUE}},\n  currency: '{{CURRENCY}}'\n});\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["{{TRIGGER_ID}}"],
  "tagFiringOption": "oncePerEvent",
  "setupTag": [
    {
      "tagName": "TikTok - Pixel Base",
      "stopOnSetupFailure": true
    }
  ],
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true
    }
  }
}
```

Notes:
- TikTok Pixel ID format: alphanumeric like `"CXXXXXXXXXXXXXXXXX"`
- Standard events: `ViewContent`, `ClickButton`, `Search`, `AddToWishlist`, `AddToCart`, `InitiateCheckout`, `AddPaymentInfo`, `CompletePayment`, `PlaceAnOrder`, `Subscribe`, `Contact`, `Download`, `SubmitForm`, `CompleteRegistration`
- TikTok Events API via sGTM shows 19% more events captured and 15% lower CPA
- Stape offers a simplified TikTok Events API Gateway ($10/month)

---

## Google Ads

### Google Ads Conversion Tag

```json
{
  "name": "Google Ads - Conversion - {{CONVERSION_NAME}}",
  "type": "awct",
  "parameter": [
    {
      "type": "template",
      "key": "conversionId",
      "value": "{{GOOGLE_ADS_CONVERSION_ID}}"
    },
    {
      "type": "template",
      "key": "conversionLabel",
      "value": "{{GOOGLE_ADS_CONVERSION_LABEL}}"
    },
    {
      "type": "template",
      "key": "conversionValue",
      "value": "{{VALUE}}"
    },
    {
      "type": "template",
      "key": "currencyCode",
      "value": "{{CURRENCY}}"
    }
  ],
  "firingTriggerId": ["{{TRIGGER_ID}}"],
  "tagFiringOption": "oncePerEvent",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true,
      "ad_personalization": true
    }
  }
}
```

### Google Ads Remarketing Tag

```json
{
  "name": "Google Ads - Remarketing",
  "type": "sp",
  "parameter": [
    {
      "type": "template",
      "key": "conversionId",
      "value": "{{GOOGLE_ADS_CONVERSION_ID}}"
    }
  ],
  "firingTriggerId": ["2147479553"],
  "tagFiringOption": "oncePerEvent",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_personalization": true
    }
  }
}
```

Notes:
- Conversion ID format: numeric like `"123456789"`
- Conversion Label: alphanumeric like `"AbCdEfGh"`
- Since April 2025, GTM auto-loads a Google Tag for Ads/Floodlight — your conversions will use it automatically
- For Enhanced Conversions, add user-provided data parameters (email, phone, address)

### Google Ads Enhanced Conversions for Leads (ECFL)

Enhanced Conversions for Leads envía datos hasheados (email, teléfono) que Google usa para atribuir conversiones offline a clics de ads. Google acepta datos sin hashear (los hashea server-side), pero hashear antes del envío es mejor práctica de privacidad.

```json
{
  "name": "Google Ads - Enhanced Conversions for Leads",
  "type": "awct",
  "parameter": [
    {
      "type": "template",
      "key": "conversionId",
      "value": "{{GOOGLE_ADS_CONVERSION_ID}}"
    },
    {
      "type": "template",
      "key": "conversionLabel",
      "value": "{{GOOGLE_ADS_CONVERSION_LABEL}}"
    },
    {
      "type": "boolean",
      "key": "enableEnhancedConversions",
      "value": "true"
    },
    {
      "type": "map",
      "key": "enhancedConversionsUserData",
      "map": [
        {
          "type": "template",
          "key": "email",
          "value": "{{DLV - user_email_sha256}}"
        },
        {
          "type": "template",
          "key": "phone",
          "value": "{{DLV - user_phone_sha256}}"
        }
      ]
    }
  ],
  "firingTriggerId": ["{{TRIGGER_ID}}"],
  "tagFiringOption": "oncePerEvent",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true,
      "ad_personalization": true
    }
  }
}
```

Notes:
- Los valores `user_email_sha256` y `user_phone_sha256` deben ser hashes SHA-256 en minúsculas y hex
- Para hashear en el navegador antes del push al dataLayer:
  ```javascript
  async function sha256(text) {
    const encoder = new TextEncoder();
    const data = encoder.encode(text.trim().toLowerCase());
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
  }
  // Uso:
  const hashedEmail = await sha256(userEmail);
  dataLayer.push({ user_email_sha256: hashedEmail, user_phone_sha256: hashedPhone });
  ```
- Si se envía via sGTM, Enhanced Conversions se configura automáticamente en el Google Tag del servidor

---

## Custom HTML

### Generic Custom HTML Tag

```json
{
  "name": "Custom HTML - {{TAG_NAME}}",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "{{HTML_CONTENT}}"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["{{TRIGGER_ID}}"],
  "tagFiringOption": "oncePerEvent",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true
    }
  }
}
```

Notes:
- Escape double quotes in the HTML content
- Set `supportDocumentWrite` to `"true"` only if absolutely needed (rare)
- Always set appropriate `consentSettings` based on what the tag does
- For any pixel not listed here, use this Custom HTML template

---

## Pinterest Tag

### Pinterest Tag Base Code

```json
{
  "name": "Pinterest - Tag Base",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\n!function(e){if(!window.pintrk){window.pintrk=function(){\nwindow.pintrk.queue.push(Array.prototype.slice.call(arguments))};\nvar n=window.pintrk;n.queue=[],n.version=\"3.0\";\nvar t=document.createElement(\"script\");t.async=!0,\nt.src=e;var r=document.getElementsByTagName(\"script\")[0];\nr.parentNode.insertBefore(t,r)}}(\"https://s.pinimg.com/ct/core.js\");\npintrk('load', '{{PINTEREST_TAG_ID}}');\npintrk('page');\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["2147479553"],
  "tagFiringOption": "oncePerPage",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true
    }
  }
}
```

### Pinterest Conversion Event

```json
{
  "name": "Pinterest - Event - {{EVENT_NAME}}",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\npintrk('track', '{{PINTEREST_EVENT_NAME}}', {\n  value: {{VALUE}},\n  currency: '{{CURRENCY}}'\n});\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["{{TRIGGER_ID}}"],
  "tagFiringOption": "oncePerEvent",
  "setupTag": [
    {
      "tagName": "Pinterest - Tag Base",
      "stopOnSetupFailure": true
    }
  ],
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true
    }
  }
}
```

Notes:
- Pinterest Tag ID: numérico como `"2612345678901"`
- Eventos estándar: `pagevisit`, `viewcategory`, `search`, `addtocart`, `checkout`, `signup`, `lead`, `watchvideo`, `custom`
- Pinterest CAPI está disponible via sGTM (template de Stape) — recomendado para mejorar atribución
- Enhanced Match: pasar `em` (email hasheado SHA-256) en los eventos para mejor matching

---

## Snapchat Pixel

### Snapchat Pixel Base Code

```json
{
  "name": "Snapchat - Pixel Base",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\n(function(e,t,n){if(e.snaptr)return;var a=e.snaptr=function(){a.handleRequest?\na.handleRequest.apply(a,arguments):a.queue.push(arguments)};\na.queue=[];var s='script';var r=t.createElement(s);r.async=!0;\nr.src=n;var u=t.getElementsByTagName(s)[0];\nu.parentNode.insertBefore(r,u);})(window,document,\n'https://sc-static.net/scevent.min.js');\nsnaptr('init', '{{SNAPCHAT_PIXEL_ID}}', {\n  'user_email': '{{USER_EMAIL_HASH}}'\n});\nsnaptr('track', 'PAGE_VIEW');\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["2147479553"],
  "tagFiringOption": "oncePerPage",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true
    }
  }
}
```

### Snapchat Conversion Event

```json
{
  "name": "Snapchat - Event - {{EVENT_NAME}}",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\nsnaptr('track', '{{SNAPCHAT_EVENT_NAME}}', {\n  'price': {{VALUE}},\n  'currency': '{{CURRENCY}}'\n});\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["{{TRIGGER_ID}}"],
  "tagFiringOption": "oncePerEvent",
  "setupTag": [
    {
      "tagName": "Snapchat - Pixel Base",
      "stopOnSetupFailure": true
    }
  ],
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "ad_storage": true,
      "ad_user_data": true
    }
  }
}
```

Notes:
- Snapchat Pixel ID: UUID como `"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"`
- Eventos estándar: `PAGE_VIEW`, `VIEW_CONTENT`, `ADD_CART`, `ADD_BILLING`, `SEARCH`, `SIGN_UP`, `PURCHASE`, `SAVE`, `START_CHECKOUT`, `ADD_TO_WISHLIST`, `SUBSCRIBE`, `COMPLETE_TUTORIAL`, `LIST_VIEW`
- `user_email` en el init es opcional — si se incluye, debe ser un hash SHA-256 en minúsculas
- Snapchat CAPI disponible via sGTM (template de Stape)

---

## Microsoft Clarity

### Microsoft Clarity Script

```json
{
  "name": "Microsoft Clarity",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script type=\"text/javascript\">\n(function(c,l,a,r,i,t,y){\nc[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};\nt=l.createElement(r);t.async=1;t.src=\"https://www.clarity.ms/tag/\"+i;\ny=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);\n})(window,document,\"clarity\",\"script\",\"{{CLARITY_PROJECT_ID}}\");\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["2147479553"],
  "tagFiringOption": "oncePerPage",
  "consentSettings": {
    "consentStatus": "needed",
    "consentType": {
      "analytics_storage": true
    }
  }
}
```

Notes:
- Clarity Project ID: alfanumérico como `"abc1def2gh"` (visible en el dashboard de Clarity)
- Clarity es gratuito sin límite de tráfico — heatmaps, session recordings y analytics
- No necesita `ad_storage` — solo usa `analytics_storage` porque no sirve para publicidad
- Clarity se integra nativamente con GA4 para correlacionar sesiones
- No hay CAPI para Clarity — es puramente client-side

---

## Triggers

### All Pages (built-in)
ID: `"2147479553"` — built-in All Pages trigger. Always verify with `list_triggers`.

### Consent Initialization (built-in)
ID: `"2147479573"` — fires before ALL other triggers. Use for consent default tags.

### DOM Ready

```json
{
  "name": "DOM Ready - All Pages",
  "type": "domReady"
}
```

### Window Loaded

```json
{
  "name": "Window Loaded - All Pages",
  "type": "windowLoaded"
}
```

### Custom Event (dataLayer)

```json
{
  "name": "CE - {{EVENT_NAME}}",
  "type": "customEvent",
  "customEventFilter": [
    {
      "type": "equals",
      "parameter": [
        { "type": "template", "key": "arg0", "value": "{{_event}}" },
        { "type": "template", "key": "arg1", "value": "{{EVENT_NAME}}" }
      ]
    }
  ]
}
```

### Click Trigger (specific element)

```json
{
  "name": "Click - {{ELEMENT_DESCRIPTION}}",
  "type": "click",
  "filter": [
    {
      "type": "cssSelector",
      "parameter": [
        { "type": "template", "key": "arg0", "value": "{{Click Element}}" },
        { "type": "template", "key": "arg1", "value": "{{CSS_SELECTOR}}" }
      ]
    }
  ]
}
```

### Page View (specific URL)

```json
{
  "name": "PV - {{PAGE_NAME}}",
  "type": "pageview",
  "filter": [
    {
      "type": "contains",
      "parameter": [
        { "type": "template", "key": "arg0", "value": "{{Page URL}}" },
        { "type": "template", "key": "arg1", "value": "{{URL_PATTERN}}" }
      ]
    }
  ]
}
```

---

## Variables

### Data Layer Variable

```json
{
  "name": "DLV - {{VARIABLE_NAME}}",
  "type": "v",
  "parameter": [
    {
      "type": "integer",
      "key": "dataLayerVersion",
      "value": "2"
    },
    {
      "type": "boolean",
      "key": "setDefaultValue",
      "value": "false"
    },
    {
      "type": "template",
      "key": "name",
      "value": "{{DATALAYER_KEY}}"
    }
  ]
}
```

### Constant Variable

```json
{
  "name": "Const - {{VARIABLE_NAME}}",
  "type": "c",
  "parameter": [
    {
      "type": "template",
      "key": "value",
      "value": "{{CONSTANT_VALUE}}"
    }
  ]
}
```

### JavaScript Variable

```json
{
  "name": "JS - {{VARIABLE_NAME}}",
  "type": "jsm",
  "parameter": [
    {
      "type": "template",
      "key": "javascript",
      "value": "function() { return {{JS_EXPRESSION}}; }"
    }
  ]
}
```

### Google Analytics Settings Variable (NEW — Dec 2025)

Note: New built-in variables are available for Analytics Client ID, Session ID, and Session Number. These replace legacy cookie-parsing approaches. Enable them via the `create_built_in_variable` API endpoint with types: `googleAnalyticsClientId`, `googleAnalyticsSessionId`, `googleAnalyticsSessionNumber`.

---

## Consent

### Consent Default Tag (fires on Consent Initialization)

This is a Custom HTML pattern. Most CMPs provide their own GTM template (Cookiebot, Usercentrics, OneTrust, etc.) which is preferred. This shows the manual approach:

```json
{
  "name": "Consent - Default (Deny All)",
  "type": "html",
  "parameter": [
    {
      "type": "template",
      "key": "html",
      "value": "<script>\nwindow.dataLayer = window.dataLayer || [];\nfunction gtag(){dataLayer.push(arguments);}\ngtag('consent', 'default', {\n  'ad_storage': 'denied',\n  'analytics_storage': 'denied',\n  'ad_user_data': 'denied',\n  'ad_personalization': 'denied',\n  'functionality_storage': 'denied',\n  'personalization_storage': 'denied',\n  'security_storage': 'granted',\n  'wait_for_update': 500\n});\n</script>"
    },
    {
      "type": "boolean",
      "key": "supportDocumentWrite",
      "value": "false"
    }
  ],
  "firingTriggerId": ["2147479573"],
  "tagFiringOption": "oncePerPage"
}
```

Notes:
- Trigger `2147479573` is the Consent Initialization trigger
- `wait_for_update: 500` gives the CMP 500ms to load and update consent
- `security_storage` is typically always granted
- The CMP then calls `gtag('consent', 'update', {...})` when user grants consent
- See `references/consent-mode.md` for full implementation guide
