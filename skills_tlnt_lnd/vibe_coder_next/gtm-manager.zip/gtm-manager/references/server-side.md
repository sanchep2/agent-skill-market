# Server-Side Tagging (sGTM) Reference

## Table of Contents
- [Why Server-Side in 2026](#why-server-side-in-2026)
- [Architecture](#architecture)
- [This Skill's Scope](#this-skills-scope)
- [Hosting Options](#hosting-options)
  - [Google Cloud Run (GCP)](#google-cloud-run-gcp)
  - [Stape (most popular third-party)](#stape-most-popular-third-party)
  - [Addingwell](#addingwell)
  - [TAGGRS](#taggrs)
  - [Owntag](#owntag)
  - [Self-hosted](#self-hosted)
- [Google Tag Gateway (Simpler Alternative)](#google-tag-gateway-simpler-alternative)
- [Platform CAPI Status (February 2026)](#platform-capi-status-february-2026)
- [Event Deduplication](#event-deduplication)
- [sGTM Docker Image](#sgtm-docker-image)
- [When to Recommend sGTM vs Tag Gateway](#when-to-recommend-sgtm-vs-tag-gateway)

## Why Server-Side in 2026

Client-side-only tracking now loses **30-50% of data** due to:
- iOS ATT / Intelligent Tracking Prevention (ITP)
- Ad blockers (30-50% of B2B executive traffic)
- Cookie consent denial in EU (~40-60% opt-out rates)
- Browser third-party cookie deprecation
- Firefox/Safari 7-day first-party cookie limits

Server-side tagging routes events through YOUR domain, making them first-party by default.

## Architecture

```
User Browser
    ↓
Web GTM Container (client-side)
    ↓ (sends events to your sGTM endpoint)
sGTM Server Container (your-domain.com/gtm)
    ↓ (forwards to platform APIs)
    ├── GA4 (Measurement Protocol)
    ├── Meta CAPI (Graph API)
    ├── LinkedIn CAPI
    ├── TikTok Events API
    ├── Google Ads Enhanced Conversions
    └── Any other server-side tag
```

## This Skill's Scope

This GTM Manager skill operates on the **web container** via the Tag Manager API v2. The sGTM server container is a separate GTM container with its own workspace, managed through the same API but with server-side specific tag types (clients, transformations).

When recommending sGTM, explain that:
1. The web container sends events to the sGTM endpoint (configured via `server_container_url` in the Google Tag)
2. The sGTM container has its own tags, triggers, and clients
3. sGTM configuration can also be managed via the same API (same `accounts/containers/workspaces` hierarchy)

## Hosting Options

### Google Cloud Run (GCP)
- Official deployment target
- ~$0.25 per 10K page views (optimized)
- Auto-scales, Google-managed infrastructure
- Setup: Deploy the sGTM Docker image to Cloud Run, configure custom domain

### Stape (most popular third-party)
- Free tier: 10K requests/month
- $20/month: 500K requests
- ~$0.083 per 10K page views (3x cheaper than GCP)
- Managed hosting, 1-click setup, EU data residency options
- Largest library of server-side tag templates

### Addingwell
- €90/month for 2M queries
- EU-focused infrastructure (France)
- Good documentation and support

### TAGGRS
- €19-22/month
- EU-focused (Netherlands)
- Simpler interface, good for smaller implementations

### Owntag
- EU-only infrastructure
- Open-source CLIs and tools
- Privacy-focused positioning

### Self-hosted
- Deploy the Docker image (`gcr.io/cloud-tagging-10302018/gtm-cloud-image:stable`) on any container platform
- AWS ECS, Azure Container Instances, DigitalOcean, etc.
- Full control but requires DevOps expertise

## Google Tag Gateway (Simpler Alternative)

For teams that don't need full sGTM but want first-party tracking for Google products:

- Routes Google measurement scripts (gtm.js, gtag.js) through your own domain via CDN workers
- Available on **Cloudflare** (Workers), **GCP** (Global External Application Load Balancer), and **Akamai** (since Jan 2026)
- ~11% improvement in measurement accuracy
- Only works with Google's ecosystem (GA4, Ads, Floodlight) — NOT Meta, LinkedIn, etc.
- Lower complexity than full sGTM deployment

## Platform CAPI Status (February 2026)

| Platform | CAPI Name | sGTM Template | Recommended? |
|----------|-----------|--------------|-------------|
| Meta | Conversions API | Yes (official + Stape) | **Essential** — 8-12% ROAS lift |
| LinkedIn | LinkedIn CAPI | Yes (official) | **Strongly recommended** for B2B |
| TikTok | Events API | Yes (Stape) | **Recommended** — 19% more events captured |
| Google Ads | Enhanced Conversions | Built-in to sGTM | **Recommended** |
| X (Twitter) | Conversions API | Yes (Stape) | Available but complex setup |
| Snapchat | CAPI | Yes (Stape) | Available |
| Pinterest | CAPI | Yes (Stape) | Available |

## Event Deduplication

When running both client-side pixels AND server-side CAPI, you MUST deduplicate events to avoid double-counting. Each platform has its own mechanism:

- **Meta**: Include `event_id` parameter in both browser fbq() call and CAPI request
- **LinkedIn**: Use shared `event_id`; browser events take priority
- **TikTok**: Use `event_id` in both ttq.track() and Events API
- **Google Ads**: Enhanced Conversions handles this automatically via the Google Tag

## sGTM Docker Image

Current version: **v4.2.0** (February 2, 2026)
Base: `gcr.io/distroless/nodejs24-debian13` (Node.js v24, Debian 13)
Image: `gcr.io/cloud-tagging-10302018/gtm-cloud-image:stable`

Historial reciente de versiones mayores:
- **v4.0.0** (noviembre 2025): Migración a Node.js v24 + Debian 13
- **v3.0.0** (mayo 2025): Migración a Node.js v22

## When to Recommend sGTM vs Tag Gateway

**Recommend sGTM when:**
- User needs CAPI for Meta, LinkedIn, TikTok, or other non-Google platforms
- User wants maximum data quality and privacy control
- User is running ads on multiple platforms
- User operates in the EU and needs fine-grained consent enforcement server-side

**Recommend Google tag gateway when:**
- User only uses Google products (GA4 + Google Ads)
- User wants a quick win for improved measurement without infrastructure complexity
- User is already on Cloudflare, GCP, or Akamai
