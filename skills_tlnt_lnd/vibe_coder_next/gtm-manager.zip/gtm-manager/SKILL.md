---
name: gtm-manager
description: >
  Manage Google Tag Manager containers, tags, triggers, and variables via the GTM API v2.
  Use this skill whenever the user wants to: add tracking pixels (Meta, GA4, LinkedIn, TikTok, X/Twitter, Google Ads, etc.),
  create or modify GTM tags, set up triggers or variables, configure Consent Mode v2,
  publish GTM container versions, list existing GTM configuration, audit tracking setup,
  or discuss server-side tagging (sGTM) strategy.
  Trigger on keywords like: "GTM", "tag manager", "tracking pixel", "conversion tag",
  "add Meta pixel", "add analytics", "add LinkedIn insight tag", "tracking setup", "pixel",
  "publish container", "GTM tag", "event tracking", "consent mode", "CAPI", "conversions API",
  "server-side tagging", "sGTM", "tag gateway". Even if the user says "add tracking to my site",
  use this skill if GTM is their tracking infrastructure.
---

# GTM Manager Skill (v2 — February 2026)

Manage Google Tag Manager containers programmatically via the Tag Manager API v2.

## Quick Orientation

| Property | Value |
|----------|-------|
| **API** | Tag Manager API **v2** (stable, no v3 exists) |
| **Auth** | Service Account (OAuth 2.0) with 5 scopes |
| **SDK** | No official SDK — use `google-api-python-client` |
| **Base URL** | `https://tagmanager.googleapis.com/tagmanager/v2/` |
| **Rate Limits** | Write: 5/sec/account, Read: 20/sec/account |
| **Pricing** | Free (GTM is free; sGTM hosting costs separate) |
| **Built-in Triggers** | All Pages: `2147479553`, Consent Init: `2147479573` |
| **Key Paradigm** | Web container + optional Server-side container (sGTM) |

## Critical Context for 2026

Before doing anything, be aware of these current realities:

1. **Google Tag unification**: The old "GA4 Configuration" tag type (`gaawc`) has been replaced by the unified **Google Tag** (`googtag`). It sends data to GA4, Google Ads, and Floodlight through a single Tag ID. Always use `googtag` for new implementations.
2. **Consent Mode v2 is mandatory** for EEA/UK traffic since March 2024. Two new parameters (`ad_user_data`, `ad_personalization`) are required. Without it, remarketing, conversion modeling, and full Ads optimization are disabled for European users.
3. **TCF v2.3 migration deadline**: February 28, 2026. All CMPs must support TCF v2.3 strings.
4. **German court ruling (March 2025)**: GTM itself may require user consent before loading in the EU, as it transmits IP addresses and device data to Google. Consider this when advising on compliance-sensitive implementations.
5. **Server-side tagging (sGTM)** is now mainstream (~20-25% of SMBs). All major ad platforms offer Conversions API (CAPI) support via sGTM templates. Dual client+server tracking is the recommended baseline.
6. **Auto-loading Google Tag (April 2025)**: GTM containers with Google Ads or Floodlight tags now automatically load a Google Tag with all settings enabled. Be aware of this when auditing containers.
7. **Universal Analytics is dead**: UA stopped collecting data in July 2023/2024. Any remaining UA tags should be deleted.
8. **New built-in variables (Dec 2025)**: Analytics Client ID, Analytics Session ID, Analytics Session Number are now available natively.

## Prerequisites

Before using this skill, the user must have completed the one-time setup:

1. A Google Cloud project with the Tag Manager API enabled
2. A Service Account with credentials JSON file
3. The Service Account email added as a user in GTM with **"Publish" permission** at the container level (not just "Edit" — "Edit" allows creating tags but NOT publishing versions)
4. The credentials JSON file accessible at a known path

Ask the user for:
- **Credentials path**: Path to the Service Account JSON file
- **Account ID**: GTM Account ID (numeric)
- **Container ID**: GTM Container ID (numeric)
- **Workspace ID**: Usually the default workspace — can be listed via API

If the user doesn't know their Account/Container IDs, use the `list_accounts` and `list_containers` commands from the wrapper script to discover them.

## Quick Start

```python
from scripts.gtm_helper import GTMHelper

# Initialize
gtm = GTMHelper(credentials_path="service-account.json")

# List accounts and containers
accounts = gtm.list_accounts()
containers = gtm.list_containers(account_id="123456")

# Create a GA4 tag
tag = gtm.create_tag(
    path="accounts/123/containers/456/workspaces/1",
    tag_config={
        "name": "GA4 - Page View",
        "type": "gaawc",
        "parameter": [
            {"type": "template", "key": "measurementId", "value": "G-XXXXXXXXXX"}
        ],
        "firingTriggerId": ["2147479553"]  # All Pages trigger
    }
)

# Publish
version = gtm.create_version(path="accounts/123/containers/456/workspaces/1", name="v1.0")
gtm.publish(path="accounts/123/containers/456/workspaces/1")
```

## Wrapper Script

Use `scripts/gtm.py` for all GTM API operations. It handles OAuth2 authentication with the Service Account and wraps the most common operations.

### Installation

```bash
pip install google-auth google-auth-httplib2 google-api-python-client --break-system-packages
```

### Usage

```bash
# Discovery
python scripts/gtm.py --credentials /path/to/creds.json list_accounts
python scripts/gtm.py --credentials /path/to/creds.json list_containers --account-id 123456
python scripts/gtm.py --credentials /path/to/creds.json list_workspaces --account-id 123456 --container-id 789012

# List resources
python scripts/gtm.py --credentials /path/to/creds.json list_tags --account-id 123456 --container-id 789012
python scripts/gtm.py --credentials /path/to/creds.json list_triggers --account-id 123456 --container-id 789012
python scripts/gtm.py --credentials /path/to/creds.json list_variables --account-id 123456 --container-id 789012

# Create resources (inline JSON or @file)
python scripts/gtm.py --credentials /path/to/creds.json create_tag --account-id 123456 --container-id 789012 --tag-json '{ ... }'
python scripts/gtm.py --credentials /path/to/creds.json create_tag --account-id 123456 --container-id 789012 --tag-json @tag-definition.json
python scripts/gtm.py --credentials /path/to/creds.json create_trigger --account-id 123456 --container-id 789012 --trigger-json '{ ... }'
python scripts/gtm.py --credentials /path/to/creds.json create_variable --account-id 123456 --container-id 789012 --variable-json '{ ... }'

# Modify / delete
python scripts/gtm.py --credentials /path/to/creds.json update_tag --account-id 123456 --container-id 789012 --tag-id 42 --tag-json '{ ... }'
python scripts/gtm.py --credentials /path/to/creds.json delete_tag --account-id 123456 --container-id 789012 --tag-id 42

# Publish
python scripts/gtm.py --credentials /path/to/creds.json publish --account-id 123456 --container-id 789012 --version-name "v2.0 - Added Meta CAPI + Consent Mode"

# Get container snippet (for embedding in HTML)
python scripts/gtm.py --credentials /path/to/creds.json get_snippet --account-id 123456 --container-id 789012
```

## Essential Patterns

### Tag Firing Sequence

```
  Page Load
     │
     ▼
┌──────────────┐
│ Consent Init │ ← Fires FIRST (trigger ID 2147479573)
│ (default:    │   Sets all consent to "denied"
│  denied)     │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  All Pages   │ ← Fires SECOND (trigger ID 2147479553)
│  Trigger     │   Loads Google Tag, base pixels
└──────┬───────┘
       │
       ▼
┌──────────────┐    ┌──────────────┐
│  CMP Banner  │───▶│ User grants  │
│  (Cookiebot/ │    │ consent      │
│   OneTrust)  │    └──────┬───────┘
└──────────────┘           │
                           ▼
                    ┌──────────────┐
                    │ Consent-     │ ← Marketing/analytics tags
                    │ dependent    │   fire only after consent
                    │ tags fire    │
                    └──────────────┘
```

### Server-Side GTM (sGTM) Dual Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     USER BROWSER                         │
│  dataLayer.push() ──▶ Web GTM Container                 │
│                         │                                │
│                         ├──▶ Client-side tags (GA4 gtag) │
│                         │                                │
│                         └──▶ HTTP request ───────────────┼──┐
└─────────────────────────────────────────────────────────┘  │
                                                             │
┌─────────────────────────────────────────────────────────┐  │
│                  sGTM SERVER                             │◀─┘
│  (Cloud Run / Stape / Addingwell / TAGGRS)              │
│                                                          │
│  ┌───────────┐  ┌──────────┐  ┌──────────┐  ┌────────┐ │
│  │ GA4 Tag   │  │ Meta     │  │ LinkedIn │  │ TikTok │ │
│  │ (server)  │  │ CAPI Tag │  │ CAPI Tag │  │ Events │ │
│  └───────────┘  └──────────┘  └──────────┘  └────────┘ │
│                                                          │
│  Bypasses ad blockers, 1st-party context, full PII      │
└─────────────────────────────────────────────────────────┘
```

### Consent Mode V2 Flow

```
┌──────────┐    ┌──────────────┐    ┌───────────────────┐
│  Page    │───▶│ gtag consent │───▶│ All consent =     │
│  loads   │    │  default     │    │ "denied"          │
└──────────┘    └──────────────┘    └─────────┬─────────┘
                                              │
                                    ┌─────────▼─────────┐
                                    │  CMP loads         │
                                    │  (user sees banner)│
                                    └─────────┬─────────┘
                                              │
                              ┌───────────────┼────────────────┐
                              ▼               ▼                ▼
                        ┌──────────┐   ┌──────────┐    ┌──────────┐
                        │ Accept   │   │ Reject   │    │ Dismiss  │
                        │ all      │   │ all      │    │ (ignore) │
                        └────┬─────┘   └────┬─────┘    └────┬─────┘
                             │              │               │
                             ▼              ▼               ▼
                       gtag update:   No update:      No update:
                       all "granted"  stays "denied"  stays "denied"
                             │              │               │
                             ▼              ▼               ▼
                       All tags fire   Tags blocked    Tags blocked
                                       (modeled data)  (modeled data)
```

---

## Workflows

### Adding a Tracking Pixel (Standard Flow)

1. **Identify** which platform the user wants (Meta, GA4, LinkedIn, TikTok, X, Google Ads, etc.)
2. **Ask for the pixel/measurement ID** (e.g., Meta Pixel ID, GA4 Measurement ID)
3. **Read the tag template** from `references/tag-templates.md` for the correct JSON structure
4. **Check Consent Mode**: If targeting EU/EEA users, ensure Consent Mode v2 is configured. Read `references/consent-mode.md`.
5. **Create the trigger** first (usually "All Pages" for base pixels, or specific event triggers for conversions)
6. **Create the tag** referencing the trigger ID returned in step 5. Include `consentSettings` if needed.
7. **Verify** by listing tags to confirm creation
8. **Recommend server-side**: For Meta, LinkedIn, TikTok — mention that CAPI via sGTM is now the recommended approach for maximum data quality. Read `references/server-side.md`.
9. **Publish** only when the user confirms — never auto-publish

### Setting Up Consent Mode v2

Read `references/consent-mode.md` for the full guide. The short version:

1. Create a **Consent Initialization** trigger (fires before All Pages)
2. Add a consent default tag that sets all parameters to "denied" initially
3. Integrate with a CMP (Cookiebot, Usercentrics, OneTrust, etc.) that updates consent state
4. Configure each tag's `consentSettings` to require appropriate consent types
5. For Google tags: `ad_storage`, `analytics_storage`, `ad_user_data`, `ad_personalization`
6. For non-Google tags: use `additionalConsentChecks` or fire based on custom consent triggers

### Auditing a Container

1. List all tags, triggers, and variables
2. Present a summary: what's tracking, what triggers are configured
3. Flag these specific issues:
   - **Legacy UA tags**: Any `ua` or `ua_eventTracker` type tags — recommend deletion
   - **Old GA4 Config tags**: Any `gaawc` type — should be migrated to `googtag`
   - **Missing Consent Mode**: Tags without `consentSettings` targeting EU users
   - **Duplicate pixels**: Multiple base pixels for the same platform
   - **Tags without triggers**: Orphaned tags
   - **Client-side only CAPI candidates**: Meta, LinkedIn, TikTok pixels without corresponding server-side CAPI
   - **Paused tags**: Identify and recommend cleanup
4. Recommend next steps based on findings

### Recommending Server-Side Tagging

When the user asks about improving tracking accuracy, dealing with ad blockers, or CAPI:

1. Read `references/server-side.md`
2. Explain the architecture: Web GTM → sGTM server → Platform APIs
3. Discuss hosting options (GCP Cloud Run, Stape, Addingwell, TAGGRS)
4. Note that sGTM is a separate container — the API skill manages the web container, sGTM configuration is done in its own GTM workspace
5. For simpler needs, mention Google tag gateway (Cloudflare/GCP/Akamai) as a lower-barrier alternative

## Tag JSON Structure

Tags in the GTM API use a `parameter` array with `type` and `value` (or `key`/`value` for maps and lists). The `type` field uses these values:
- `template` — a string value (most common)
- `boolean` — "true" or "false" as strings
- `integer` — a number as string
- `list` — an array of parameters
- `map` — key-value pairs

For Custom HTML tags, the HTML content goes in a parameter with key `html`.

**Consent settings** are added at the tag level via the `consentSettings` object:
```json
{
  "consentSettings": {
    "consentStatus": "notSet" | "needed" | "notNeeded",
    "consentType": {
      "ad_storage": true,
      "analytics_storage": true,
      "ad_user_data": true,
      "ad_personalization": true
    }
  }
}
```

**Read `references/tag-templates.md`** for ready-to-use JSON templates for each platform.

## Critical Gotchas

1. **Workspace conflicts -- only one workspace can be published at a time.** If two team members create workspaces and make changes simultaneously, only one can be published. The second publish will fail with a conflict error. Always coordinate workspace usage across the team, or use a single shared workspace for automation.

2. **Built-in variables must be explicitly enabled via API before use.** Variables like Click URL, Form ID, or the new Analytics Client ID (Dec 2025) exist but are disabled by default. Referencing them in triggers or tags before enabling them produces `undefined`. Enable them with `update_built_in_variable` or via the GTM UI.

3. **Container snippet changes require version publish (not just save).** Saving a tag, trigger, or variable to a workspace does NOT make it live. Users must explicitly publish a new container version. Creating tags via the API does not auto-publish -- always remind the user to publish when ready.

4. **Tag firing priority is NOT execution order -- use tag sequencing.** The `priority` field on tags affects which tag fires first when multiple tags share the same trigger, but it does NOT guarantee one tag completes before another starts. For true sequential execution (e.g., set a cookie before firing a pixel), use Tag Sequencing (setup/cleanup tags).

5. **Custom JavaScript variables run in a sandbox (no DOM access).** GTM's Custom JavaScript variable type executes in a restricted environment. It cannot access `document`, `window`, or the DOM directly. Use DOM Element variables or Custom HTML tags (which do have DOM access) instead.

6. **Consent Mode v2 blocks all tags by default until consent is granted.** When Consent Mode is configured with default `denied` state (the correct approach for EU), ALL tags that require consent will be suppressed until the user interacts with the CMP. This means zero tracking data for users who dismiss the banner without choosing. Ensure the CMP is prominent and test the consent flow thoroughly.

7. **Server-side GTM requires separate Cloud Run billing setup.** sGTM runs on a separate container hosted on GCP Cloud Run (or Stape/Addingwell/TAGGRS). It has its own billing, separate from the web GTM container. Cloud Run costs scale with request volume -- budget $30-100/month for moderate traffic.

8. **Preview mode shares the same cookie as live (can pollute analytics).** When using GTM Preview mode, the debug cookie (`__TAG_ASSISTANT`) is set on the same domain. If the previewer navigates the site, those pageviews and events are recorded in analytics as real traffic. Use a staging property or filter out debug traffic.

9. **Container version limit is 200 -- old versions are auto-archived.** GTM retains only the last 200 versions per container. Older versions are automatically archived and cannot be restored via the API. If you need version history beyond 200, export version JSON externally before archiving.

10. **Workspace-level changes are NOT atomic -- partial publishes are possible.** If a workspace contains 5 tag changes and the publish fails mid-way (e.g., a validation error on tag 3), the first 2 tags may already be committed to the version. Always validate all resources in the workspace before publishing.

11. **Trigger groups require ALL triggers to fire (AND logic, not OR).** A Trigger Group only activates when every trigger in the group has fired at least once on the same page. This is AND logic, not OR. For OR logic (fire when any trigger matches), assign multiple individual triggers to the tag's `firingTriggerId` array.

12. **Tag Manager API v2 uses path-based IDs not numeric (accounts/X/containers/Y).** API resources are identified by their full path (`accounts/123/containers/456/workspaces/7/tags/89`), not just numeric IDs. When the wrapper script takes `--account-id` and `--container-id` separately, it constructs the path internally. Direct API calls must use the full path format.

13. **API Version**: v2 is current and stable. No v3 exists.

14. **Rate Limits**: Write ops: 5/sec/account. Read ops: 20/sec/account. HTTP 429 = back off with exponential delay.

15. **All Pages trigger**: Built-in trigger with ID `"2147479553"`. Verify with `list_triggers`. Consent Initialization trigger: built-in ID `"2147479573"`.

16. **Google Tag auto-loading**: Since April 2025, containers with Ads/Floodlight tags auto-load a Google Tag. This is NOT visible in the API -- it happens at runtime. Do not create a duplicate manual Google Tag.

17. **DO NOT create GA4 Event tags for events fired via `gtag()` in application code.** The Google Tag (`googtag`) creates the `gtag()` function and automatically processes all `gtag("event", ...)` calls pushed to the dataLayer. Creating a separate GA4 Event tag (`gaawe`) for the same event causes double-counting. Only create GA4 Event tags for events triggered by GTM triggers (Custom Event, Click, etc.), NOT for events already dispatched by application code.

18. **OAuth Scopes**: The wrapper script requires 5 scopes: `edit.containers`, `edit.containerversions`, `publish`, `readonly`, `manage.users`. The `edit.containerversions` scope is specifically needed for the `create_version` step of the publish workflow -- without it, publish fails with "insufficient authentication scopes" even if the Service Account has Publish permission in GTM.

## Troubleshooting

Problemas comunes y soluciones rápidas:

| Problema | Causa probable | Solución |
|----------|---------------|----------|
| Tag no dispara | Trigger incorrecto o consent no otorgado | Verificar trigger asociado con `list_triggers`. Revisar `consentSettings` del tag — si requiere `ad_storage` y el usuario no dio consent, el tag no se ejecuta. Usar Preview Mode en GTM UI para diagnosticar. |
| Publish falla con "insufficient scopes" | Service Account sin scope `edit.containerversions` | Verificar que la SA tenga los 5 scopes requeridos (especialmente `edit.containerversions`). Regenerar credenciales si es necesario. |
| Double-counting de conversiones | Auto-loading Google Tag (abril 2025) duplica eventos | Desde abril 2025, GTM carga automáticamente un Google Tag para containers con Ads/Floodlight. Verificar que no haya un Google Tag manual que duplique el auto-cargado. No crear GA4 Event tags para eventos ya disparados via `gtag()` en código. |
| Rate limit 429 | Exceso de llamadas a la API | Write ops: máximo 5/sec por cuenta. Read ops: máximo 20/sec por cuenta. Implementar backoff exponencial y reintentar tras esperar. |
| Tags se ejecutan sin consent | `consentSettings` no configurado o en `"notSet"` | Auditar todos los tags: cambiar `consentStatus` de `"notSet"` a `"needed"` y especificar `consentType` requeridos. |
| Variable de DataLayer siempre `undefined` | Nombre incorrecto o `dataLayerVersion` mal configurado | Verificar que el `name` coincida exactamente con la clave del `dataLayer.push()`. Usar `dataLayerVersion: 2` (no 1). |

## Cross-Skill Integration

### ga4-skill
GTM is the primary delivery mechanism for GA4 events. The Google Tag (`googtag`) initializes `gtag()` and routes events to GA4 via the Measurement ID. Use `dataLayer.push()` from application code to fire events that GTM picks up via Custom Event triggers. For enhanced measurement events (scroll, outbound clicks, file downloads), GA4 handles them automatically -- do not duplicate with GTM triggers.

### nextjs-web
Load the GTM snippet in Next.js App Router using `next/script` with `afterInteractive` strategy. Place it in `app/layout.tsx` so it loads on every page. For Consent Mode compliance, load the consent default script before GTM.

```tsx
// app/layout.tsx -- GTM Script in Next.js App Router
import Script from "next/script";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html>
      <head>
        {/* Consent Mode defaults -- MUST load before GTM */}
        <Script id="consent-defaults" strategy="beforeInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('consent', 'default', {
              'ad_storage': 'denied',
              'analytics_storage': 'denied',
              'ad_user_data': 'denied',
              'ad_personalization': 'denied'
            });
          `}
        </Script>
        {/* GTM */}
        <Script id="gtm" strategy="afterInteractive">
          {`
            (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','GTM-XXXXXXX');
          `}
        </Script>
      </head>
      <body>
        <noscript>
          <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-XXXXXXX"
            height="0" width="0" style={{ display: "none", visibility: "hidden" }} />
        </noscript>
        {children}
      </body>
    </html>
  );
}
```

### stripe-skill
Track purchase and conversion events through GTM by pushing Stripe checkout data to the dataLayer. On `checkout.session.completed` webhook, pass transaction data to the frontend which then fires `dataLayer.push({ event: 'purchase', ecommerce: { ... } })`. GTM picks this up via a Custom Event trigger and forwards to GA4, Meta CAPI, Google Ads, etc.

### convex-skill / supabase-skill
For server-side event forwarding, backend events (sign-ups, purchases, key actions) can be sent directly to the sGTM endpoint via HTTP POST. This bypasses client-side ad blockers. Convex actions or Supabase Edge Functions make a `fetch()` call to your sGTM server URL with the event payload, which sGTM then routes to all configured server-side tags (GA4 MP, Meta CAPI, etc.).

## Reference Files

- `references/tag-templates.md` -- JSON templates for all major platforms (GA4, Meta, X, LinkedIn, TikTok, Google Ads, Pinterest, Snapchat, Clarity)
- `references/consent-mode.md` -- Consent Mode v2 implementation guide
- `references/server-side.md` -- Server-side tagging overview and CAPI guidance
- `references/api-reference.md` -- API endpoints, auth, rate limits, tag/trigger types
