# gtm-manager — Skill de Claude Code

Skill instalable para **Claude Code**: gestión de **Google Tag Manager** vía la GTM API v2.
Crea y modifica tags, triggers y variables; añade píxeles de tracking (Meta, GA4, LinkedIn,
TikTok, X/Twitter, Google Ads); configura Consent Mode v2; publica versiones del contenedor;
audita el setup de tracking y planifica server-side tagging (sGTM). Autocontenida.

## Cómo instalar
1. Descomprime este ZIP. Obtendrás una carpeta `gtm-manager/`.
2. Cópiala a tu directorio de skills de Claude Code:
   - **Personal:** `~/.claude/skills/gtm-manager/`
   - **Solo un proyecto:** `<tu-proyecto>/.claude/skills/gtm-manager/`
3. Reinicia Claude Code. Se activará sola al trabajar con GTM.

## Contenido
- `SKILL.md` — guía principal.
- `references/` — api-reference, consent-mode, server-side, tag-templates.

Cortesía de **Talent Academy · Vibe Coder**.
