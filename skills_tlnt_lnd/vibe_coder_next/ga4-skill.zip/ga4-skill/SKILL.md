---
name: ga4-skill
description: >
  Skill completo para Google Analytics 4 — las cuatro superficies de API: Data API v1beta
  (reporting), Admin API v1alpha/v1beta (configuracion de propiedades), Measurement Protocol
  (eventos server-side), y BigQuery Export (datos crudos sin muestreo). Usar este skill
  siempre que se trabaje con GA4 programaticamente o se necesite consultar datos de analytics.
  Incluye: runReport, batchRunReports, runPivotReport, runRealtimeReport, runFunnelReport,
  audienceExports, reportTasks, checkCompatibility, getMetadata, CRUD de properties/streams/
  custom dimensions/key events/BigQuery links/MP secrets/audiences/users, Measurement Protocol
  collect+validate, BigQuery SQL patterns (sessions, e-commerce, traffic, funnels),
  autenticacion (service accounts, Workload Identity, OAuth), quotas token-bucket (25K/dia
  standard, 250K GA360), retry con backoff+jitter, GA4 MCP Server, Terraform patterns,
  GitHub Actions CI/CD, y script helper Python con CLI.
  Trigger keywords: "GA4", "Google Analytics", "Google Analytics 4", "Data API", "Admin API",
  "Measurement Protocol", "BigQuery Export", "runReport", "batchRunReports", "runPivotReport",
  "runRealtimeReport", "runFunnelReport", "key events", "conversions GA4", "custom dimensions",
  "custom metrics", "audiences export", "audience list", "MP secret", "api_secret",
  "mp/collect", "debug/mp/collect", "property quota", "returnPropertyQuota", "token bucket",
  "BetaAnalyticsDataClient", "AnalyticsAdminServiceClient", "google-analytics-data",
  "@google-analytics/data", "@google-analytics/admin", "events_YYYYMMDD", "events_intraday",
  "analytics_{property_id}", "GOOGLE_APPLICATION_CREDENTIALS", "analytics.readonly",
  "analytics.edit", "session_id MP", "engagement_time_msec", "(other) row", "data thresholding",
  "Google Signals", "GA360", "sampling GA4", "cardinality limit", "checkCompatibility",
  "getMetadata", "consent mode GA4", "enhanced conversions GA4", "ga4 mcp server",
  "analytics-mcp", "reporting data annotations", "data retention GA4".
  Usar incluso para preguntas simples como "como saco un reporte de GA4", "configurar
  BigQuery Export", "enviar evento server-side a GA4", "crear key event", "ver quotas GA4".
---

# Google Analytics 4 — Estado del Arte (Febrero 2026)

## Quick Orientation

GA4 expone **cuatro superficies de API** que cubren el ciclo completo de analytics:

| Superficie | Base URL | Proposito |
|-----------|----------|-----------|
| **Data API v1beta** | `analyticsdata.googleapis.com` | Reporting: reportes tabulares, pivotes, realtime, funnels |
| **Admin API v1alpha/v1beta** | `analyticsadmin.googleapis.com` | Configuracion: CRUD properties, streams, dims, key events, BQ links |
| **Measurement Protocol** | `google-analytics.com/mp/collect` | Eventos server-side: augmentar tracking client-side |
| **BigQuery Export** | `bigquery.googleapis.com` | Datos crudos: 100% sin muestreo, sin limites de cardinalidad |

**Versiones actuales (febrero 2026):**
- Data API: **v1beta** (estable) y **v1alpha** (preview). **NO existe v2**.
- Admin API: **v1beta** (estable, superficie reducida) y **v1alpha** (completa)
- Python: `google-analytics-data` v0.20.0, `google-analytics-admin` v0.27.0
- Node.js: `@google-analytics/data` v5.x, `@google-analytics/admin` v9.x

> **IMPORTANTE:** Usar `@google-analytics/data`, NO el deprecado `@googleapis/analyticsdata`.

**Para temas especificos, leer la referencia apropiada ANTES de escribir codigo:**

| Tema | Archivo de Referencia | Cuando Leer |
|------|----------------------|-------------|
| Auth, service accounts, OAuth, scopes, roles | `references/auth-and-setup.md` | Setup de credenciales, permisos, Workload Identity |
| Data API: reportes, filtros, dimensiones, metricas | `references/data-api.md` | Cualquier reporte: runReport, batch, pivot, realtime, funnels |
| Admin API: CRUD properties, streams, config | `references/admin-api.md` | Crear/modificar properties, custom dims, key events, BQ links |
| Measurement Protocol: eventos server-side | `references/measurement-protocol.md` | Enviar eventos desde backend, validacion, gotchas |
| BigQuery Export: schema, SQL, costos | `references/bigquery-export.md` | Queries sobre datos crudos, sessions, e-commerce, traffic |
| Quotas, rate limits, retry, cache | `references/rate-limits.md` | Token budget, backoff, circuit breaker, caching strategy |
| CLI, Terraform, CI/CD, MCP Server | `references/ecosystem-tools.md` | Automatizacion, IaC, GitHub Actions, GA4 MCP Server |
| Pitfalls: discrepancias, cardinalidad, bugs | `references/pitfalls-and-workarounds.md` | Antes de produccion: (other) row, sampling, MP bugs |
| Changelog 2024-2026 | `references/changelog-2024-2026.md` | Key Events rename, nuevas APIs, breaking changes |

---

## Decision Trees

### ¿Que API usar?

```
¿Necesito datos de reporting (metricas, dimensiones)?
├── SI → ¿Datos en tiempo real (ultimos 30 min)?
│   ├── SI → Data API: runRealtimeReport
│   └── NO → ¿Necesito datos 100% sin muestreo?
│       ├── SI → BigQuery Export (SIEMPRE sin muestreo)
│       └── NO → ¿Necesito funnel multi-step?
│           ├── SI → Data API v1alpha: runFunnelReport
│           └── NO → Data API v1beta: runReport / batchRunReports
│
¿Necesito configurar la propiedad GA4?
├── SI → Admin API (v1alpha para features completas, v1beta para estables)
│
¿Necesito enviar eventos desde el servidor?
├── SI → Measurement Protocol (POST /mp/collect)
│
¿Necesito exportar lista de usuarios de una audiencia?
├── SI → Data API v1alpha: createAudienceExport / queryAudienceExport
```

### ¿Data API vs BigQuery?

```
¿Datos pre-agregados son suficientes?
├── SI → Data API (mas rapida, sin costo BQ)
├── NO → ¿Necesito user_pseudo_id individual?
│   ├── SI → BigQuery Export
│   └── NO → ¿Mas de 50K valores unicos en una dimension?
│       ├── SI → BigQuery Export (evita (other) row)
│       └── NO → ¿Necesito datos modelados por Consent Mode?
│           ├── SI → Data API (BQ NO incluye datos modelados)
│           └── NO → Cualquiera funciona, Data API es mas simple
```

### ¿v1beta vs v1alpha (Admin API)?

```
¿Necesito alguno de estos?
├── Audiences CRUD → v1alpha
├── BigQuery Links CRUD → v1alpha
├── Channel Groups → v1alpha
├── Calculated Metrics → v1alpha
├── Event Create/Edit Rules → v1alpha
├── Reporting Data Annotations → v1alpha
├── Access Bindings (user management) → v1alpha
├── Attribution Settings → v1alpha
├── Google Signals Settings → v1alpha
└── Todo lo demas (Properties, Streams, Custom Dims, Key Events, MP Secrets) → v1beta (estable)
```

### Data Flow: App → GA4 → BigQuery → Dashboard

```
┌──────────┐    ┌──────────┐    ┌─────────────┐    ┌──────────────┐    ┌───────────┐
│  Web App  │───▶│  gtag.js  │───▶│   GA4 Prop   │───▶│ BigQuery     │───▶│ Dashboard │
│  / Mobile │    │  + GTM    │    │  (collect)   │    │ Export       │    │ (Looker/  │
└──────────┘    └──────────┘    └──────┬──────┘    │ events_*     │    │  custom)  │
                                       │           └──────────────┘    └───────────┘
                                       │                  ▲
                                       ▼                  │
                                ┌──────────────┐          │
                                │  Data API    │          │
                                │  v1beta      │──────────┘ (alternative)
                                │  (reporting) │
                                └──────────────┘
                                       ▲
                                       │
                                ┌──────────────┐
                                │  Server-side │
                                │  (MP collect)│
                                └──────────────┘
```

---

## Critical Knowledge

### 1. Key Events (NO "Conversions")
Desde marzo 2024, GA4 usa "Key Events" en lugar de "Conversions". En Data API:
`conversions` → `keyEvents`, `sessionConversionRate` → `sessionKeyEventRate`.
Admin API: `properties.keyEvents` (legacy `conversionEvents` aun existe).

### 2. NO existe Data API v2
El canal v1beta ES la version estable. Features migran de v1alpha → v1beta.
No hay planes para v2.

### 3. Measurement Protocol requiere session_id
**SIEMPRE** enviar `session_id` y `engagement_time_msec` en eventos MP.
Sin estos, los eventos aparecen como `(not set)` en atribucion y NO aparecen en Realtime.

### 4. BigQuery Export NO incluye datos modelados
Consent Mode v2 genera datos modelados en la UI/API pero BigQuery Export
solo tiene datos observados. Esperar numeros menores en BQ vs Data API.

### 5. (other) row con >50K valores unicos
Dimensiones con alta cardinalidad agrupan excedentes en `(other)`.
Verificar con `response.metadata.dataLossFromOtherRow`. Solucion: BigQuery Export.

### 6. Quotas son token-bucket, NO request-based
Una request simple consume ~10 tokens; una compleja puede consumir 1000+.
Standard: 25K tokens/dia. GA360: 250K. **No se pueden incrementar.**

---

## Quick Start — runReport

### TypeScript
```typescript
import { BetaAnalyticsDataClient } from '@google-analytics/data';

const client = new BetaAnalyticsDataClient();
const propertyId = '123456789';

const [response] = await client.runReport({
  property: `properties/${propertyId}`,
  dimensions: [{ name: 'country' }, { name: 'sessionDefaultChannelGroup' }],
  metrics: [{ name: 'activeUsers' }, { name: 'sessions' }, { name: 'keyEvents' }],
  dateRanges: [{ startDate: '30daysAgo', endDate: 'yesterday' }],
  orderBys: [{ metric: { metricName: 'activeUsers' }, desc: true }],
  limit: 100,
  returnPropertyQuota: true,
});

for (const row of response.rows!) {
  const dims = row.dimensionValues!.map(d => d.value).join(' | ');
  const mets = row.metricValues!.map(m => m.value).join(' | ');
  console.log(`${dims} — ${mets}`);
}
// Verificar quota: response.propertyQuota.tokensPerDay.consumed / .remaining
```

### Python
```python
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    RunReportRequest, DateRange, Dimension, Metric, OrderBy,
)

client = BetaAnalyticsDataClient()

response = client.run_report(RunReportRequest(
    property=f"properties/{property_id}",
    dimensions=[Dimension(name="country"), Dimension(name="sessionDefaultChannelGroup")],
    metrics=[Metric(name="activeUsers"), Metric(name="sessions"), Metric(name="keyEvents")],
    date_ranges=[DateRange(start_date="30daysAgo", end_date="yesterday")],
    order_bys=[OrderBy(metric=OrderBy.MetricOrderBy(metric_name="activeUsers"), desc=True)],
    limit=100,
    return_property_quota=True,
))

for row in response.rows:
    dims = " | ".join(dv.value for dv in row.dimension_values)
    mets = " | ".join(mv.value for mv in row.metric_values)
    print(f"{dims} — {mets}")
```

---

## 10 Mandamientos GA4

1. **`returnPropertyQuota: true` SIEMPRE** — Monitorizar consumo de tokens activamente.
   Sin esto, no sabras cuando te acercas al limite diario.

2. **`session_id` + `engagement_time_msec` en CADA evento MP** — Sin estos dos parametros,
   los eventos del Measurement Protocol no aparecen en Realtime ni tienen atribucion.

3. **BigQuery Export para datos sin muestreo** — Es la UNICA fuente 100% sin muestreo,
   sin cardinalidad limitada, sin datos modelados de Consent Mode.

4. **Habilitar BigQuery Export TEMPRANO** — No hay backfill retroactivo. Cada dia
   sin export es un dia de datos perdido.

5. **Data retention a 14 meses** — Configurar desde el primer dia via Admin API
   (`updateDataRetentionSettings`). El default de 2 meses pierde datos.

6. **Validar eventos MP con `/debug/mp/collect`** — Siempre validar en desarrollo
   antes de enviar a produccion. Usar `validation_behavior: ENFORCE_RECOMMENDATIONS`.

7. **Cache de reportes 4-24 horas** — El lag de procesamiento GA4 es 4-48 horas.
   Cache key: `ga4:{propertyId}:{reportHash}:{dateRange}`.

8. **`checkCompatibility` antes de reportes complejos** — No todas las combinaciones
   de dimensiones y metricas son compatibles. Validar antes de gastar tokens.

9. **Backoff exponencial con jitter para TODA llamada** — Codigos 429, 500, 503
   requieren retry. Las client libraries lo hacen automaticamente, pero verificar.

10. **Consent Mode v2 obligatorio en EEA** — Parametros `ad_user_data` y
    `ad_personalization` requeridos desde marzo 2024. Sin compliance, se pierden
    features de advertising en esas regiones.

---

## Gotchas Críticos

1. **La fila `(other)` destruye reportes de alta cardinalidad** — Cualquier dimensión con más de 50K valores únicos agrupa el excedente en una fila `(other)`. Esto puede representar 30-60% de tus datos. Verificar siempre `response.metadata.dataLossFromOtherRow`. Si es `true`, migrar esa consulta a BigQuery Export, que no tiene límite de cardinalidad.

2. **"Key Events" reemplazó a "Conversions" — los campos API cambiaron** — Desde marzo 2024, `conversions` → `keyEvents`, `sessionConversionRate` → `sessionKeyEventRate` en Data API. El Admin API usa `properties.keyEvents` (el legacy `conversionEvents` aún existe pero está deprecado). Código que use los nombres viejos retorna ceros sin error.

3. **Measurement Protocol sin `session_id` = eventos fantasma** — Si no envías `session_id` y `engagement_time_msec` en cada evento MP, los eventos aparecen como `(not set)` en atribución, NO aparecen en Realtime, y no se asocian a ninguna sesión. Parecen existir en los datos crudos pero son inútiles para análisis.

4. **BigQuery Export NO incluye datos modelados de Consent Mode** — Si comparas BigQuery con la UI o Data API, los números de BigQuery serán menores (a veces 20-40% menos) en regiones con Consent Mode activo. BigQuery solo tiene datos observados. No hay workaround — son fuentes de verdad diferentes.

5. **Las quotas son token-bucket, NO request-based — una query compleja gasta 100x más** — Una consulta simple consume ~10 tokens; una con 9 dimensiones, 15 métricas y múltiples filtros puede consumir 1000+ tokens de tus 25K diarios (standard) o 250K (GA360). No se pueden incrementar. Monitorizar siempre con `returnPropertyQuota: true`.

6. **Sampling se activa silenciosamente con datasets grandes** — GA4 standard aplica muestreo cuando una consulta toca más de ~500K sesiones. La respuesta incluye `metadata.samplesReadCounts` y `metadata.samplingSpaceSizes`, pero si no los verificas, tus reportes tienen error estadístico sin que lo sepas. BigQuery Export es la única fuente 100% sin muestreo.

7. **BigQuery Export no tiene backfill retroactivo** — La exportación comienza el día que la activas. No hay forma de exportar datos históricos previos a la activación. Cada día sin export activado es un día de datos crudos perdido para siempre. Activar en el primer día de la propiedad.

8. **Data retention default es 2 meses — pierde datos en silencio** — La retención de datos predeterminada es 2 meses para exploración de usuarios. Después de 2 meses, los datos agregados permanecen pero pierdes la capacidad de hacer segmentación retroactiva. Cambiar inmediatamente a 14 meses via Admin API (`updateDataRetentionSettings`).

9. **Consent Mode v2 obligatorio en EEA — sin él pierdes funcionalidad de advertising** — Los parámetros `ad_user_data` y `ad_personalization` son requeridos desde marzo 2024 para el Espacio Económico Europeo. Sin compliance, pierdes audiencias de remarketing, conversiones importadas a Google Ads, y datos modelados. La pérdida es silenciosa — no hay error, simplemente faltan datos.

10. **`checkCompatibility` evita gastar tokens en queries imposibles** — No todas las combinaciones de dimensiones y métricas son compatibles. Por ejemplo, `sessionSource` con `itemRevenue` falla. Si no validas con `checkCompatibility` antes, gastas tokens de tu quota diaria en una query que retorna error. Siempre validar antes de reportes complejos.

11. **Lag de procesamiento de 4-48 horas — no cachear con TTL corto** — Los datos de GA4 tienen un retraso de procesamiento de 4 a 48 horas. Hacer una query cada 5 minutos no te da datos más frescos, solo quema tokens. Cachear reportes con TTL de 4-24 horas. Key recomendado: `ga4:{propertyId}:{reportHash}:{dateRange}`.

12. **El paquete Node.js correcto es `@google-analytics/data`, NO `@googleapis/analyticsdata`** — El paquete viejo `@googleapis/analyticsdata` está deprecado y tiene bugs conocidos. Usar `@google-analytics/data` v5.x para Data API y `@google-analytics/admin` v9.x para Admin API. Mezclarlos causa conflictos de tipos.

13. **BigQuery Export puede generar costos inesperados en queries sobre tablas particionadas** — Las tablas `events_YYYYMMDD` se acumulan rápidamente. Un `SELECT *` sin filtro de fecha escanea TODAS las particiones. Siempre usar `_TABLE_SUFFIX` para filtrar fechas y estimar costos con `--dry-run` antes de queries exploratorias.

## Integracion con Otros Skills

### gtm-manager
GA4 y GTM trabajan juntos: GTM dispara eventos que GA4 recolecta. El skill `gtm-manager`
cubre la configuracion de tags GA4 en GTM (GA4 Configuration Tag, GA4 Event Tag).
Usar `gtm-manager` para la parte de tagging y `ga4-skill` para la parte de reporting/config.

### google-ads-api
GA4 y Google Ads comparten audiencias y conversiones. Vinculacion via Admin API
(`createGoogleAdsLink`). Key Events de GA4 pueden importarse como conversiones en Google Ads.
Los datos de campañas Google Ads aparecen en reportes GA4 y BigQuery Export.

### creative-multimedia
Los reportes GA4 informan la estrategia creativa: que paginas convierten, que canales
traen usuarios valiosos, que eventos indican engagement. Usar Data API para alimentar
decisiones creativas.

---

## Notas de Implementacion para Este Proyecto

Para el Curso Online, GA4 se usa para:
- **Tracking de landings** (`index.html`, `extended.html`, `platino.html`) via GTM
- **Key Events**: registro de lead, inicio de checkout, compra completada
- **Measurement Protocol**: eventos server-side desde Convex (compra completada)
- **Reporting**: metricas en el dashboard admin via Data API
- **BigQuery Export**: analisis profundo de funnels de conversion

Recordar que el GTM ID se carga dinamicamente desde `systemSettings` (clave `gtm.id`,
endpoint `/api/gtm-id`). Ver skill `gtm-manager` para detalles de configuracion.
