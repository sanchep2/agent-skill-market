#!/usr/bin/env python3
"""
ga4_helper.py — Script helper para Google Analytics 4

Wrapper completo sobre las 4 superficies de API de GA4:
- Data API v1beta (reporting)
- Admin API v1alpha (configuracion)
- Measurement Protocol (eventos server-side)
- BigQuery (queries sobre datos exportados)

Dependencias:
    pip install google-analytics-data google-analytics-admin requests google-cloud-bigquery

Variables de entorno:
    GOOGLE_APPLICATION_CREDENTIALS  — Ruta al archivo JSON de service account
    GA4_PROPERTY_ID                — ID numerico de la propiedad GA4
    GA4_MEASUREMENT_ID             — Measurement ID (G-XXXXXXXXXX)
    GA4_MP_API_SECRET              — API Secret para Measurement Protocol
    GA4_BQ_PROJECT                 — Proyecto GCP para BigQuery
    GA4_BQ_DATASET                 — Dataset de BigQuery (analytics_{property_id})

Uso CLI:
    python ga4_helper.py report --property 123456789 --dims country --metrics activeUsers
    python ga4_helper.py realtime --property 123456789 --dims country --metrics activeUsers
    python ga4_helper.py metadata --property 123456789
    python ga4_helper.py quota --property 123456789
    python ga4_helper.py mp-send --mid G-XXXXXXXXXX --secret SECRET --event purchase --client-id CID
    python ga4_helper.py mp-validate --mid G-XXXXXXXXXX --secret SECRET --event test_event --client-id CID
    python ga4_helper.py admin-list-properties
    python ga4_helper.py admin-create-key-event --property 123456789 --event-name purchase
    python ga4_helper.py admin-list-streams --property 123456789
    python ga4_helper.py admin-create-mp-secret --property 123456789 --stream-id STREAM_ID --name "Prod"
"""

import argparse
import hashlib
import json
import logging
import os
import random
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Callable, Optional, TypeVar

# ============================================================================
# Logging
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("ga4_helper")

T = TypeVar("T")

# ============================================================================
# Circuit Breaker
# ============================================================================


@dataclass
class CircuitBreaker:
    """Proteccion contra rate limiting excesivo en APIs de GA4."""

    failure_threshold: int = 5
    recovery_timeout: float = 60.0

    _failure_count: int = field(default=0, init=False, repr=False)
    _state: str = field(default="closed", init=False, repr=False)
    _last_failure_time: float = field(default=0.0, init=False, repr=False)

    def can_execute(self) -> bool:
        """Verificar si se puede ejecutar una request."""
        if self._state == "closed":
            return True
        elif self._state == "open":
            if time.time() - self._last_failure_time >= self.recovery_timeout:
                self._state = "half_open"
                logger.info("Circuit breaker: open -> half_open")
                return True
            return False
        elif self._state == "half_open":
            return True
        return False

    def record_success(self) -> None:
        """Registrar exito — resetear contadores."""
        if self._state != "closed":
            logger.info(f"Circuit breaker: {self._state} -> closed")
        self._failure_count = 0
        self._state = "closed"

    def record_failure(self) -> None:
        """Registrar fallo — potencialmente abrir circuito."""
        self._failure_count += 1
        self._last_failure_time = time.time()
        if self._failure_count >= self.failure_threshold:
            self._state = "open"
            logger.warning(
                f"Circuit breaker ABIERTO despues de {self._failure_count} fallos. "
                f"Recovery en {self.recovery_timeout}s"
            )

    @property
    def state(self) -> str:
        return self._state


# ============================================================================
# Retry con Backoff Exponencial
# ============================================================================


def with_retry(
    fn: Callable[[], T],
    max_retries: int = 5,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    retryable_codes: tuple = (429, 500, 503),
    circuit_breaker: Optional[CircuitBreaker] = None,
) -> T:
    """Ejecutar funcion con retry, backoff exponencial + jitter, y circuit breaker."""
    if circuit_breaker and not circuit_breaker.can_execute():
        raise RuntimeError(
            f"Circuit breaker abierto — esperando recovery "
            f"({circuit_breaker.recovery_timeout}s)"
        )

    for attempt in range(max_retries):
        try:
            result = fn()
            if circuit_breaker:
                circuit_breaker.record_success()
            return result
        except Exception as e:
            code = getattr(e, "code", None) or getattr(
                getattr(e, "response", None), "status_code", None
            )

            if code in retryable_codes and attempt < max_retries - 1:
                delay = min(
                    base_delay * (2**attempt) + random.uniform(0, 1),
                    max_delay,
                )
                logger.warning(
                    f"Retry {attempt + 1}/{max_retries} despues de {delay:.1f}s "
                    f"(codigo: {code})"
                )
                time.sleep(delay)
            else:
                if circuit_breaker:
                    circuit_breaker.record_failure()
                raise

    raise RuntimeError("Max retries excedido")


# ============================================================================
# Cache en Memoria
# ============================================================================


class GA4Cache:
    """Cache simple en memoria para respuestas de Data API."""

    def __init__(self):
        self._store: dict[str, tuple[Any, float]] = {}

    def _make_key(self, property_id: str, request_dict: dict) -> str:
        serialized = json.dumps(request_dict, sort_keys=True, default=str)
        hash_val = hashlib.sha256(serialized.encode()).hexdigest()[:16]
        return f"ga4:{property_id}:{hash_val}"

    def get(self, property_id: str, request_dict: dict) -> Optional[Any]:
        key = self._make_key(property_id, request_dict)
        if key in self._store:
            value, expiry = self._store[key]
            if time.time() < expiry:
                logger.debug(f"Cache HIT: {key}")
                return value
            else:
                del self._store[key]
                logger.debug(f"Cache EXPIRED: {key}")
        return None

    def set(
        self, property_id: str, request_dict: dict, value: Any, ttl: int = 14400
    ) -> None:
        key = self._make_key(property_id, request_dict)
        self._store[key] = (value, time.time() + ttl)
        logger.debug(f"Cache SET: {key} (TTL: {ttl}s)")

    def clear(self) -> None:
        self._store.clear()

    def clear_property(self, property_id: str) -> None:
        to_delete = [k for k in self._store if k.startswith(f"ga4:{property_id}:")]
        for k in to_delete:
            del self._store[k]

    @staticmethod
    def determine_ttl(start_date: str, end_date: str) -> int:
        """Determinar TTL optimo basado en frescura de datos."""
        today = datetime.now().strftime("%Y-%m-%d")
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        two_days_ago = (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d")

        def resolve_date(d: str) -> str:
            if d == "today":
                return today
            elif d == "yesterday":
                return yesterday
            elif d.endswith("daysAgo"):
                days = int(d.replace("daysAgo", ""))
                return (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
            return d

        resolved_end = resolve_date(end_date)

        if resolved_end >= today:
            return 900  # 15 min
        elif resolved_end >= yesterday:
            return 7200  # 2 horas
        elif resolved_end >= two_days_ago:
            return 14400  # 4 horas
        else:
            return 86400  # 24 horas


# ============================================================================
# GA4 Data Client
# ============================================================================


class GA4DataClient:
    """Wrapper sobre BetaAnalyticsDataClient con retry, quota tracking y cache."""

    def __init__(
        self,
        property_id: Optional[str] = None,
        credentials_path: Optional[str] = None,
        use_cache: bool = True,
    ):
        try:
            from google.analytics.data_v1beta import BetaAnalyticsDataClient
            from google.analytics.data_v1beta.types import (
                BatchRunReportsRequest,
                CheckCompatibilityRequest,
                DateRange,
                Dimension,
                Filter,
                FilterExpression,
                GetMetadataRequest,
                Metric,
                OrderBy,
                RunRealtimeReportRequest,
                RunReportRequest,
            )
        except ImportError:
            logger.error("Instalar: pip install google-analytics-data")
            raise

        self._types = type(
            "Types",
            (),
            {
                "RunReportRequest": RunReportRequest,
                "BatchRunReportsRequest": BatchRunReportsRequest,
                "RunRealtimeReportRequest": RunRealtimeReportRequest,
                "GetMetadataRequest": GetMetadataRequest,
                "CheckCompatibilityRequest": CheckCompatibilityRequest,
                "DateRange": DateRange,
                "Dimension": Dimension,
                "Metric": Metric,
                "OrderBy": OrderBy,
                "Filter": Filter,
                "FilterExpression": FilterExpression,
            },
        )()

        kwargs = {}
        if credentials_path:
            from google.oauth2 import service_account

            credentials = service_account.Credentials.from_service_account_file(
                credentials_path,
                scopes=["https://www.googleapis.com/auth/analytics.readonly"],
            )
            kwargs["credentials"] = credentials

        self._client = BetaAnalyticsDataClient(**kwargs)
        self._property_id = property_id or os.environ.get("GA4_PROPERTY_ID", "")
        self._cache = GA4Cache() if use_cache else None
        self._breaker = CircuitBreaker(failure_threshold=5, recovery_timeout=120)
        self._quota_info: dict = {}

    @property
    def property_name(self) -> str:
        return f"properties/{self._property_id}"

    @property
    def quota_info(self) -> dict:
        return self._quota_info

    def _update_quota(self, response: Any) -> None:
        """Actualizar informacion de quota desde la response."""
        if hasattr(response, "property_quota") and response.property_quota:
            pq = response.property_quota
            self._quota_info = {
                "tokens_per_day": {
                    "consumed": pq.tokens_per_day.consumed,
                    "remaining": pq.tokens_per_day.remaining,
                },
                "tokens_per_hour": {
                    "consumed": pq.tokens_per_hour.consumed,
                    "remaining": pq.tokens_per_hour.remaining,
                },
                "concurrent": {
                    "consumed": pq.concurrently_sent_requests_per_property.consumed,
                    "remaining": pq.concurrently_sent_requests_per_property.remaining,
                },
            }
            remaining_day = pq.tokens_per_day.remaining
            if remaining_day < 1000:
                logger.warning(
                    f"ALERTA: Solo quedan {remaining_day} tokens/dia "
                    f"(consumidos: {pq.tokens_per_day.consumed})"
                )

    def run_report(
        self,
        dimensions: list[str],
        metrics: list[str],
        start_date: str = "30daysAgo",
        end_date: str = "yesterday",
        dimension_filter: Optional[Any] = None,
        metric_filter: Optional[Any] = None,
        order_by: Optional[list] = None,
        limit: int = 100,
        offset: int = 0,
        property_id: Optional[str] = None,
    ) -> Any:
        """Ejecutar runReport con retry, cache y quota tracking."""
        prop_id = property_id or self._property_id
        prop_name = f"properties/{prop_id}"

        request_dict = {
            "dimensions": dimensions,
            "metrics": metrics,
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
            "offset": offset,
        }

        # Verificar cache
        if self._cache:
            cached = self._cache.get(prop_id, request_dict)
            if cached is not None:
                return cached

        t = self._types
        request = t.RunReportRequest(
            property=prop_name,
            dimensions=[t.Dimension(name=d) for d in dimensions],
            metrics=[t.Metric(name=m) for m in metrics],
            date_ranges=[t.DateRange(start_date=start_date, end_date=end_date)],
            limit=limit,
            offset=offset,
            return_property_quota=True,
        )

        if dimension_filter:
            request.dimension_filter = dimension_filter
        if metric_filter:
            request.metric_filter = metric_filter
        if order_by:
            request.order_bys = order_by

        response = with_retry(
            lambda: self._client.run_report(request),
            circuit_breaker=self._breaker,
        )

        self._update_quota(response)

        # Cachear resultado
        if self._cache:
            ttl = GA4Cache.determine_ttl(start_date, end_date)
            self._cache.set(prop_id, request_dict, response, ttl=ttl)

        return response

    def run_realtime_report(
        self,
        dimensions: list[str],
        metrics: list[str],
        property_id: Optional[str] = None,
    ) -> Any:
        """Ejecutar reporte en tiempo real (ultimos 30 min)."""
        prop_id = property_id or self._property_id
        t = self._types

        request = t.RunRealtimeReportRequest(
            property=f"properties/{prop_id}",
            dimensions=[t.Dimension(name=d) for d in dimensions],
            metrics=[t.Metric(name=m) for m in metrics],
        )

        return with_retry(
            lambda: self._client.run_realtime_report(request),
            circuit_breaker=self._breaker,
        )

    def batch_run_reports(
        self,
        requests_list: list[dict],
        property_id: Optional[str] = None,
    ) -> Any:
        """Ejecutar hasta 5 reportes en una sola llamada."""
        prop_id = property_id or self._property_id
        t = self._types

        sub_requests = []
        for req in requests_list:
            sub_requests.append(
                t.RunReportRequest(
                    dimensions=[t.Dimension(name=d) for d in req.get("dimensions", [])],
                    metrics=[t.Metric(name=m) for m in req.get("metrics", [])],
                    date_ranges=[
                        t.DateRange(
                            start_date=req.get("start_date", "30daysAgo"),
                            end_date=req.get("end_date", "yesterday"),
                        )
                    ],
                    limit=req.get("limit", 100),
                    return_property_quota=True,
                )
            )

        return with_retry(
            lambda: self._client.batch_run_reports(
                request={
                    "property": f"properties/{prop_id}",
                    "requests": sub_requests,
                }
            ),
            circuit_breaker=self._breaker,
        )

    def get_metadata(self, property_id: Optional[str] = None) -> Any:
        """Obtener metadata (dimensiones y metricas disponibles)."""
        prop_id = property_id or self._property_id
        t = self._types

        return self._client.get_metadata(
            t.GetMetadataRequest(name=f"properties/{prop_id}/metadata")
        )

    def check_compatibility(
        self,
        dimensions: list[str],
        metrics: list[str],
        property_id: Optional[str] = None,
    ) -> Any:
        """Verificar compatibilidad de dimensiones/metricas sin gastar tokens."""
        prop_id = property_id or self._property_id
        t = self._types

        return self._client.check_compatibility(
            t.CheckCompatibilityRequest(
                property=f"properties/{prop_id}",
                dimensions=[t.Dimension(name=d) for d in dimensions],
                metrics=[t.Metric(name=m) for m in metrics],
            )
        )

    @staticmethod
    def parse_report(response: Any) -> list[dict]:
        """Parsear response de runReport a lista de diccionarios."""
        dim_headers = [h.name for h in response.dimension_headers]
        met_headers = [h.name for h in response.metric_headers]

        results = []
        for row in response.rows:
            record = {}
            for i, dv in enumerate(row.dimension_values):
                record[dim_headers[i]] = dv.value
            for i, mv in enumerate(row.metric_values):
                record[met_headers[i]] = mv.value
            results.append(record)

        return results

    @staticmethod
    def print_report(response: Any, max_rows: int = 50) -> None:
        """Imprimir reporte en formato tabular."""
        dim_headers = [h.name for h in response.dimension_headers]
        met_headers = [h.name for h in response.metric_headers]
        all_headers = dim_headers + met_headers

        print(" | ".join(all_headers))
        print("-" * (len(" | ".join(all_headers))))

        for i, row in enumerate(response.rows):
            if i >= max_rows:
                print(f"... ({response.row_count - max_rows} filas mas)")
                break
            dims = [dv.value for dv in row.dimension_values]
            mets = [mv.value for mv in row.metric_values]
            print(" | ".join(dims + mets))

        print(f"\nTotal filas: {response.row_count}")

        if response.metadata.data_loss_from_other_row:
            print("AVISO: Datos agrupados en (other) por alta cardinalidad")

        if hasattr(response, "property_quota") and response.property_quota:
            pq = response.property_quota
            print(
                f"Tokens/dia: {pq.tokens_per_day.consumed} consumidos, "
                f"{pq.tokens_per_day.remaining} restantes"
            )


# ============================================================================
# GA4 Admin Client
# ============================================================================


class GA4AdminClient:
    """Wrapper sobre AnalyticsAdminServiceClient con helpers para operaciones comunes."""

    def __init__(self, credentials_path: Optional[str] = None):
        try:
            from google.analytics.admin_v1alpha import AnalyticsAdminServiceClient
        except ImportError:
            logger.error("Instalar: pip install google-analytics-admin")
            raise

        kwargs = {}
        if credentials_path:
            from google.oauth2 import service_account

            credentials = service_account.Credentials.from_service_account_file(
                credentials_path,
                scopes=["https://www.googleapis.com/auth/analytics.edit"],
            )
            kwargs["credentials"] = credentials

        self._client = AnalyticsAdminServiceClient(**kwargs)

    def list_account_summaries(self) -> list[dict]:
        """Listar todas las cuentas y propiedades accesibles."""
        results = []
        for summary in self._client.list_account_summaries():
            account = {
                "account": summary.account,
                "display_name": summary.display_name,
                "properties": [],
            }
            for prop in summary.property_summaries:
                account["properties"].append(
                    {
                        "property": prop.property,
                        "display_name": prop.display_name,
                        "property_type": str(prop.property_type),
                    }
                )
            results.append(account)
        return results

    def list_data_streams(self, property_id: str) -> list[dict]:
        """Listar data streams de una propiedad."""
        results = []
        for stream in self._client.list_data_streams(
            parent=f"properties/{property_id}"
        ):
            info = {
                "name": stream.name,
                "type": str(stream.type_),
                "display_name": stream.display_name,
            }
            if stream.web_stream_data:
                info["measurement_id"] = stream.web_stream_data.measurement_id
                info["default_uri"] = stream.web_stream_data.default_uri
            results.append(info)
        return results

    def create_key_event(
        self,
        property_id: str,
        event_name: str,
        counting_method: str = "ONCE_PER_EVENT",
    ) -> Any:
        """Crear un key event en la propiedad."""
        from google.analytics.admin_v1alpha.types import KeyEvent

        method = getattr(KeyEvent.CountingMethod, counting_method)

        return self._client.create_key_event(
            request={
                "parent": f"properties/{property_id}",
                "key_event": KeyEvent(
                    event_name=event_name,
                    counting_method=method,
                ),
            }
        )

    def create_custom_dimension(
        self,
        property_id: str,
        parameter_name: str,
        display_name: str,
        scope: str = "EVENT",
        description: str = "",
    ) -> Any:
        """Crear una custom dimension."""
        from google.analytics.admin_v1alpha.types import CustomDimension

        scope_enum = getattr(CustomDimension.DimensionScope, scope)

        return self._client.create_custom_dimension(
            request={
                "parent": f"properties/{property_id}",
                "custom_dimension": CustomDimension(
                    parameter_name=parameter_name,
                    display_name=display_name,
                    scope=scope_enum,
                    description=description,
                ),
            }
        )

    def create_mp_secret(
        self,
        property_id: str,
        stream_id: str,
        display_name: str = "API Secret",
    ) -> dict:
        """Crear un Measurement Protocol API Secret."""
        from google.analytics.admin_v1alpha.types import MeasurementProtocolSecret

        secret = self._client.create_measurement_protocol_secret(
            request={
                "parent": f"properties/{property_id}/dataStreams/{stream_id}",
                "measurement_protocol_secret": MeasurementProtocolSecret(
                    display_name=display_name
                ),
            }
        )
        return {
            "name": secret.name,
            "display_name": secret.display_name,
            "secret_value": secret.secret_value,
        }

    def update_data_retention(
        self,
        property_id: str,
        retention: str = "FOURTEEN_MONTHS",
    ) -> Any:
        """Actualizar retencion de datos (recomendado: FOURTEEN_MONTHS)."""
        from google.analytics.admin_v1alpha.types import DataRetentionSettings
        from google.protobuf.field_mask_pb2 import FieldMask

        retention_enum = getattr(
            DataRetentionSettings.RetentionDuration, retention
        )

        return self._client.update_data_retention_settings(
            request={
                "data_retention_settings": DataRetentionSettings(
                    name=f"properties/{property_id}/dataRetentionSettings",
                    event_data_retention=retention_enum,
                ),
                "update_mask": FieldMask(paths=["event_data_retention"]),
            }
        )


# ============================================================================
# Measurement Protocol Client
# ============================================================================


class MeasurementProtocolClient:
    """Cliente para enviar y validar eventos via Measurement Protocol."""

    BASE_URL = "https://www.google-analytics.com"
    EU_BASE_URL = "https://region1.google-analytics.com"

    def __init__(
        self,
        measurement_id: Optional[str] = None,
        api_secret: Optional[str] = None,
        eu_region: bool = False,
    ):
        try:
            import requests as req_lib

            self._requests = req_lib
        except ImportError:
            logger.error("Instalar: pip install requests")
            raise

        self._measurement_id = measurement_id or os.environ.get(
            "GA4_MEASUREMENT_ID", ""
        )
        self._api_secret = api_secret or os.environ.get("GA4_MP_API_SECRET", "")
        self._base_url = self.EU_BASE_URL if eu_region else self.BASE_URL

        if not self._measurement_id or not self._api_secret:
            logger.warning(
                "GA4_MEASUREMENT_ID y/o GA4_MP_API_SECRET no configurados"
            )

    def _get_params(self) -> dict:
        return {
            "measurement_id": self._measurement_id,
            "api_secret": self._api_secret,
        }

    def validate_event(self, payload: dict) -> dict:
        """Validar payload contra endpoint de debug. Lanza ValueError si invalido."""
        url = f"{self._base_url}/debug/mp/collect"
        body = {**payload, "validation_behavior": "ENFORCE_RECOMMENDATIONS"}

        resp = self._requests.post(
            url, params=self._get_params(), json=body, timeout=10
        )
        resp.raise_for_status()

        result = resp.json()
        if result.get("validationMessages"):
            raise ValueError(
                f"Validacion MP fallida: "
                f"{json.dumps(result['validationMessages'], indent=2)}"
            )

        logger.info("Validacion MP exitosa")
        return result

    def send_event(self, payload: dict) -> bool:
        """Enviar payload a produccion. Devuelve True si se envio (no garantiza procesamiento)."""
        url = f"{self._base_url}/mp/collect"

        resp = self._requests.post(
            url, params=self._get_params(), json=payload, timeout=10
        )

        # Produccion SIEMPRE devuelve 2xx incluso con datos invalidos
        if resp.ok:
            logger.info("Evento MP enviado exitosamente")
            return True
        else:
            logger.error(f"Error enviando evento MP: {resp.status_code}")
            return False

    def send_event_with_retry(
        self,
        payload: dict,
        max_retries: int = 3,
        base_delay: float = 1.0,
    ) -> bool:
        """Enviar evento con retry y backoff exponencial."""
        for attempt in range(max_retries):
            try:
                return self.send_event(payload)
            except Exception:
                if attempt < max_retries - 1:
                    delay = base_delay * (2**attempt) + random.uniform(0, 1)
                    logger.warning(
                        f"Retry MP {attempt + 1}/{max_retries} "
                        f"despues de {delay:.1f}s"
                    )
                    time.sleep(delay)
                else:
                    raise
        return False

    def build_purchase_payload(
        self,
        client_id: str,
        transaction_id: str,
        value: float,
        currency: str = "USD",
        session_id: str = "",
        user_id: Optional[str] = None,
        items: Optional[list[dict]] = None,
    ) -> dict:
        """Construir payload de compra con todos los campos requeridos."""
        if not session_id:
            session_id = str(int(time.time()))

        params: dict[str, Any] = {
            "transaction_id": transaction_id,
            "value": value,
            "currency": currency,
            "session_id": session_id,
            "engagement_time_msec": "100",
        }

        if items:
            params["items"] = [
                {
                    "item_id": item.get("id", ""),
                    "item_name": item.get("name", ""),
                    **({"item_brand": item["brand"]} if item.get("brand") else {}),
                    **(
                        {"item_category": item["category"]}
                        if item.get("category")
                        else {}
                    ),
                    "price": item.get("price", 0),
                    "quantity": item.get("quantity", 1),
                }
                for item in items
            ]

        payload: dict[str, Any] = {
            "client_id": client_id,
            "events": [{"name": "purchase", "params": params}],
        }

        if user_id:
            payload["user_id"] = user_id

        return payload

    def build_custom_event_payload(
        self,
        client_id: str,
        event_name: str,
        event_params: dict,
        session_id: str = "",
        user_id: Optional[str] = None,
        user_properties: Optional[dict] = None,
    ) -> dict:
        """Construir payload de evento custom."""
        if not session_id:
            session_id = str(int(time.time()))

        params = {
            **event_params,
            "session_id": session_id,
            "engagement_time_msec": "100",
        }

        payload: dict[str, Any] = {
            "client_id": client_id,
            "events": [{"name": event_name, "params": params}],
        }

        if user_id:
            payload["user_id"] = user_id

        if user_properties:
            payload["user_properties"] = {
                k: {"value": v} for k, v in user_properties.items()
            }

        return payload

    def send_batch_events(
        self,
        client_id: str,
        events: list[dict],
        session_id: str,
        chunk_size: int = 25,
    ) -> int:
        """Enviar multiples eventos en batches de max 25. Devuelve conteo de exitosos."""
        sent = 0
        enriched = []
        for event in events:
            params = {**event.get("params", {})}
            params.setdefault("session_id", session_id)
            params.setdefault("engagement_time_msec", "100")
            enriched.append({"name": event["name"], "params": params})

        for i in range(0, len(enriched), chunk_size):
            chunk = enriched[i: i + chunk_size]
            payload = {"client_id": client_id, "events": chunk}
            if self.send_event_with_retry(payload):
                sent += len(chunk)

        logger.info(f"Enviados {sent}/{len(events)} eventos MP")
        return sent


# ============================================================================
# CLI
# ============================================================================


def cmd_report(args: argparse.Namespace) -> None:
    """Ejecutar reporte Data API."""
    client = GA4DataClient(property_id=args.property)
    response = client.run_report(
        dimensions=args.dims.split(",") if args.dims else [],
        metrics=args.metrics.split(",") if args.metrics else ["activeUsers"],
        start_date=args.start_date,
        end_date=args.end_date,
        limit=args.limit,
    )
    client.print_report(response, max_rows=args.limit)


def cmd_realtime(args: argparse.Namespace) -> None:
    """Ejecutar reporte realtime."""
    client = GA4DataClient(property_id=args.property)
    response = client.run_realtime_report(
        dimensions=args.dims.split(",") if args.dims else ["country"],
        metrics=args.metrics.split(",") if args.metrics else ["activeUsers"],
    )
    client.print_report(response)


def cmd_metadata(args: argparse.Namespace) -> None:
    """Listar dimensiones y metricas disponibles."""
    client = GA4DataClient(property_id=args.property)
    metadata = client.get_metadata()

    print(f"=== Dimensiones ({len(metadata.dimensions)}) ===")
    for dim in metadata.dimensions:
        print(f"  {dim.api_name}: {dim.ui_name} ({dim.category})")

    print(f"\n=== Metricas ({len(metadata.metrics)}) ===")
    for met in metadata.metrics:
        print(f"  {met.api_name}: {met.ui_name} ({met.category})")


def cmd_quota(args: argparse.Namespace) -> None:
    """Verificar cuotas de tokens."""
    client = GA4DataClient(property_id=args.property)
    # Ejecutar un reporte minimo para obtener quota
    client.run_report(
        dimensions=[],
        metrics=["activeUsers"],
        start_date="yesterday",
        end_date="yesterday",
    )
    quota = client.quota_info
    if quota:
        print("=== Cuotas de Tokens ===")
        for bucket, info in quota.items():
            print(f"  {bucket}: consumidos={info['consumed']}, restantes={info['remaining']}")
    else:
        print("No se pudo obtener informacion de cuotas")


def cmd_mp_send(args: argparse.Namespace) -> None:
    """Enviar evento via Measurement Protocol."""
    mp = MeasurementProtocolClient(
        measurement_id=args.mid,
        api_secret=args.secret,
    )

    params = {}
    if args.params:
        for p in args.params.split(","):
            k, v = p.split("=", 1)
            params[k] = v

    payload = mp.build_custom_event_payload(
        client_id=args.client_id,
        event_name=args.event,
        event_params=params,
        user_id=args.user_id,
    )

    print(f"Payload: {json.dumps(payload, indent=2)}")
    if mp.send_event(payload):
        print("Evento enviado exitosamente")
    else:
        print("Error enviando evento")


def cmd_mp_validate(args: argparse.Namespace) -> None:
    """Validar evento contra debug endpoint."""
    mp = MeasurementProtocolClient(
        measurement_id=args.mid,
        api_secret=args.secret,
    )

    params = {}
    if args.params:
        for p in args.params.split(","):
            k, v = p.split("=", 1)
            params[k] = v

    payload = mp.build_custom_event_payload(
        client_id=args.client_id,
        event_name=args.event,
        event_params=params,
    )

    print(f"Payload: {json.dumps(payload, indent=2)}")
    try:
        result = mp.validate_event(payload)
        print("Validacion EXITOSA")
        print(json.dumps(result, indent=2))
    except ValueError as e:
        print(f"Validacion FALLIDA: {e}")


def cmd_admin_list_properties(args: argparse.Namespace) -> None:
    """Listar todas las propiedades accesibles."""
    admin = GA4AdminClient()
    summaries = admin.list_account_summaries()

    for account in summaries:
        print(f"\nCuenta: {account['display_name']} ({account['account']})")
        for prop in account["properties"]:
            print(f"  Propiedad: {prop['display_name']} ({prop['property']})")


def cmd_admin_list_streams(args: argparse.Namespace) -> None:
    """Listar data streams de una propiedad."""
    admin = GA4AdminClient()
    streams = admin.list_data_streams(args.property)

    for stream in streams:
        print(f"  {stream['display_name']} ({stream['type']})")
        if "measurement_id" in stream:
            print(f"    Measurement ID: {stream['measurement_id']}")
        if "default_uri" in stream:
            print(f"    URI: {stream['default_uri']}")


def cmd_admin_create_key_event(args: argparse.Namespace) -> None:
    """Crear un key event."""
    admin = GA4AdminClient()
    result = admin.create_key_event(
        property_id=args.property,
        event_name=args.event_name,
        counting_method=args.counting or "ONCE_PER_EVENT",
    )
    print(f"Key event creado: {result.name}")


def cmd_admin_create_mp_secret(args: argparse.Namespace) -> None:
    """Crear un MP API Secret."""
    admin = GA4AdminClient()
    result = admin.create_mp_secret(
        property_id=args.property,
        stream_id=args.stream_id,
        display_name=args.name or "API Secret",
    )
    print(f"MP Secret creado: {result['display_name']}")
    print(f"Secret Value: {result['secret_value']}")
    print("GUARDAR ESTE VALOR — no se puede recuperar despues")


def main() -> None:
    """Entry point del CLI."""
    parser = argparse.ArgumentParser(
        description="GA4 Helper — Herramienta CLI para Google Analytics 4",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", help="Comando a ejecutar")

    # --- report ---
    p_report = subparsers.add_parser("report", help="Ejecutar reporte Data API")
    p_report.add_argument("--property", "-p", required=True, help="Property ID")
    p_report.add_argument("--dims", "-d", default="", help="Dimensiones (comma-separated)")
    p_report.add_argument("--metrics", "-m", default="activeUsers", help="Metricas (comma-separated)")
    p_report.add_argument("--start-date", default="30daysAgo", help="Fecha inicio")
    p_report.add_argument("--end-date", default="yesterday", help="Fecha fin")
    p_report.add_argument("--limit", type=int, default=50, help="Max filas")
    p_report.set_defaults(func=cmd_report)

    # --- realtime ---
    p_realtime = subparsers.add_parser("realtime", help="Reporte en tiempo real")
    p_realtime.add_argument("--property", "-p", required=True, help="Property ID")
    p_realtime.add_argument("--dims", "-d", default="country", help="Dimensiones")
    p_realtime.add_argument("--metrics", "-m", default="activeUsers", help="Metricas")
    p_realtime.set_defaults(func=cmd_realtime)

    # --- metadata ---
    p_meta = subparsers.add_parser("metadata", help="Listar dimensiones y metricas")
    p_meta.add_argument("--property", "-p", required=True, help="Property ID")
    p_meta.set_defaults(func=cmd_metadata)

    # --- quota ---
    p_quota = subparsers.add_parser("quota", help="Verificar cuotas de tokens")
    p_quota.add_argument("--property", "-p", required=True, help="Property ID")
    p_quota.set_defaults(func=cmd_quota)

    # --- mp-send ---
    p_mp_send = subparsers.add_parser("mp-send", help="Enviar evento via MP")
    p_mp_send.add_argument("--mid", required=True, help="Measurement ID (G-XXX)")
    p_mp_send.add_argument("--secret", required=True, help="API Secret")
    p_mp_send.add_argument("--event", required=True, help="Nombre del evento")
    p_mp_send.add_argument("--client-id", required=True, help="Client ID")
    p_mp_send.add_argument("--user-id", default=None, help="User ID (opcional)")
    p_mp_send.add_argument("--params", default=None, help="Parametros (key=val,key=val)")
    p_mp_send.set_defaults(func=cmd_mp_send)

    # --- mp-validate ---
    p_mp_val = subparsers.add_parser("mp-validate", help="Validar evento MP")
    p_mp_val.add_argument("--mid", required=True, help="Measurement ID")
    p_mp_val.add_argument("--secret", required=True, help="API Secret")
    p_mp_val.add_argument("--event", required=True, help="Nombre del evento")
    p_mp_val.add_argument("--client-id", required=True, help="Client ID")
    p_mp_val.add_argument("--params", default=None, help="Parametros (key=val,key=val)")
    p_mp_val.set_defaults(func=cmd_mp_validate)

    # --- admin-list-properties ---
    p_list = subparsers.add_parser("admin-list-properties", help="Listar propiedades")
    p_list.set_defaults(func=cmd_admin_list_properties)

    # --- admin-list-streams ---
    p_streams = subparsers.add_parser("admin-list-streams", help="Listar data streams")
    p_streams.add_argument("--property", "-p", required=True, help="Property ID")
    p_streams.set_defaults(func=cmd_admin_list_streams)

    # --- admin-create-key-event ---
    p_ke = subparsers.add_parser("admin-create-key-event", help="Crear key event")
    p_ke.add_argument("--property", "-p", required=True, help="Property ID")
    p_ke.add_argument("--event-name", required=True, help="Nombre del evento")
    p_ke.add_argument("--counting", default="ONCE_PER_EVENT", help="Metodo de conteo")
    p_ke.set_defaults(func=cmd_admin_create_key_event)

    # --- admin-create-mp-secret ---
    p_secret = subparsers.add_parser("admin-create-mp-secret", help="Crear MP secret")
    p_secret.add_argument("--property", "-p", required=True, help="Property ID")
    p_secret.add_argument("--stream-id", required=True, help="Stream ID")
    p_secret.add_argument("--name", default="API Secret", help="Nombre del secret")
    p_secret.set_defaults(func=cmd_admin_create_mp_secret)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
