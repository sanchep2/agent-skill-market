# BigQuery Export — Datos Crudos Sin Muestreo

## Resumen

GA4 BigQuery Export crea un dataset `analytics_{property_id}` con tablas diarias
`events_YYYYMMDD` y tablas streaming `events_intraday_YYYYMMDD`. Es la **UNICA** fuente
de datos 100% sin muestreo y sin limites de cardinalidad.

**Limites:**
- Standard properties: **1 millon de eventos/dia** para export diario (sin limite en streaming)
- GA360 properties: sin limite practico con Fresh Daily export
- Los datos se actualizan hasta **3 dias** despues de la fecha del evento (late-arriving events)

---

## Schema de la Tabla events_YYYYMMDD

### Columnas Top-Level

| Columna | Tipo | Descripcion |
|---------|------|-------------|
| `event_date` | STRING | Formato YYYYMMDD |
| `event_timestamp` | INTEGER | Microsegundos desde Unix epoch |
| `event_name` | STRING | Ej: `page_view`, `purchase`, `session_start` |
| `event_params` | RECORD (REPEATED) | Pares key/value: `.key` (STRING), `.value.string_value`, `.value.int_value`, `.value.float_value`, `.value.double_value` |
| `event_previous_timestamp` | INTEGER | Timestamp del evento anterior |
| `event_value_in_usd` | FLOAT | Valor monetizado en USD |
| `event_bundle_sequence_id` | INTEGER | ID secuencial del bundle |
| `event_server_timestamp_offset` | INTEGER | Offset del servidor en microsegundos |
| `user_id` | STRING | Identificador de usuario definido por el desarrollador |
| `user_pseudo_id` | STRING | ID pseudoanonimo generado por el cliente |
| `user_properties` | RECORD (REPEATED) | Misma estructura key/value que event_params, mas `.set_timestamp_micros` |
| `user_first_touch_timestamp` | INTEGER | Timestamp del primer toque |
| `user_ltv` | RECORD | `.revenue`, `.currency` |
| `device` | RECORD | `.category`, `.mobile_brand_name`, `.mobile_model_name`, `.operating_system`, `.operating_system_version`, `.browser`, `.browser_version`, `.language`, `.is_limited_ad_tracking`, `.web_info.browser`, `.web_info.hostname` |
| `geo` | RECORD | `.city`, `.country`, `.continent`, `.region`, `.sub_continent`, `.metro` |
| `traffic_source` | RECORD | First-touch user-scoped: `.name`, `.medium`, `.source` |
| `collected_traffic_source` | RECORD | Valores raw: `.gclid`, `.manual_source`, `.manual_medium`, `.manual_campaign_name`, `.manual_term`, `.manual_content`, etc. |
| `session_traffic_source_last_click` | RECORD | Atribucion last-click a nivel de sesion (agregado julio 2024) |
| `stream_id` | STRING | Identificador del data stream |
| `platform` | STRING | `WEB`, `IOS`, o `ANDROID` |
| `ecommerce` | RECORD | `.total_item_quantity`, `.purchase_revenue_in_usd`, `.purchase_revenue`, `.refund_value`, `.refund_value_in_usd`, `.shipping_value`, `.shipping_value_in_usd`, `.tax_value`, `.tax_value_in_usd`, `.unique_items`, `.transaction_id` |
| `items` | RECORD (REPEATED) | `.item_id`, `.item_name`, `.item_brand`, `.item_category` (1-5), `.price`, `.price_in_usd`, `.quantity`, `.item_revenue`, `.item_revenue_in_usd`, `.coupon`, `.affiliation`, `.location_id`, `.item_list_id`, `.item_list_name`, `.item_list_index`, `.promotion_id`, `.promotion_name`, `.creative_name`, `.creative_slot` |
| `privacy_info` | RECORD | `.analytics_storage`, `.ads_storage`, `.uses_transient_token` |
| `batch_event_index` | INTEGER | Secuencia del evento dentro del batch (julio 2024) |
| `batch_page_id` | INTEGER | Identificador de pagina dentro del batch |
| `batch_ordering_id` | INTEGER | Ordenamiento del batch |
| `publisher` | RECORD | Agregado octubre 2024 |
| `cross_channel_campaign` | RECORD | Agregado octubre 2024 |

---

## Funciones Helper (Patron Recomendado)

**SIEMPRE** crear estas funciones temporales al inicio de las queries para extraer
valores de `event_params` (estructura nested/repeated):

```sql
-- Helper: extraer string de event_params
CREATE TEMP FUNCTION GetParamString(event_params ANY TYPE, param_name STRING) AS (
  (SELECT ANY_VALUE(value.string_value) FROM UNNEST(event_params) WHERE key = param_name)
);

-- Helper: extraer integer de event_params
CREATE TEMP FUNCTION GetParamInt(event_params ANY TYPE, param_name STRING) AS (
  (SELECT ANY_VALUE(value.int_value) FROM UNNEST(event_params) WHERE key = param_name)
);

-- Helper: extraer float de event_params
CREATE TEMP FUNCTION GetParamFloat(event_params ANY TYPE, param_name STRING) AS (
  (SELECT ANY_VALUE(COALESCE(value.float_value, value.double_value)) FROM UNNEST(event_params) WHERE key = param_name)
);

-- Helper: extraer user property string
CREATE TEMP FUNCTION GetUserPropString(user_properties ANY TYPE, prop_name STRING) AS (
  (SELECT ANY_VALUE(value.string_value) FROM UNNEST(user_properties) WHERE key = prop_name)
);
```

---

## Queries SQL Esenciales

### Page Views con Paths

```sql
SELECT
  GetParamString(event_params, 'page_location') AS page_location,
  GetParamString(event_params, 'page_title') AS page_title,
  COUNT(*) AS page_views,
  COUNT(DISTINCT user_pseudo_id) AS users
FROM `project.analytics_123456789.events_*`
WHERE _TABLE_SUFFIX BETWEEN '20260101' AND '20260131'
  AND event_name = 'page_view'
GROUP BY 1, 2
ORDER BY page_views DESC
LIMIT 100;
```

### Conteo de Sesiones y Engagement

```sql
SELECT
  event_date,
  COUNT(DISTINCT CONCAT(
    user_pseudo_id,
    CAST(GetParamInt(event_params, 'ga_session_id') AS STRING)
  )) AS sessions,
  COUNT(DISTINCT user_pseudo_id) AS users,
  COUNTIF(GetParamInt(event_params, 'session_engaged') = 1)
    / NULLIF(COUNT(DISTINCT CONCAT(
        user_pseudo_id,
        CAST(GetParamInt(event_params, 'ga_session_id') AS STRING)
      )), 0) AS engagement_rate
FROM `project.analytics_123456789.events_*`
WHERE _TABLE_SUFFIX BETWEEN '20260101' AND '20260131'
GROUP BY 1
ORDER BY 1;
```

### Revenue E-commerce

```sql
SELECT
  event_date,
  COUNT(*) AS purchases,
  SUM(ecommerce.purchase_revenue) AS revenue,
  SUM(ecommerce.purchase_revenue_in_usd) AS revenue_usd,
  COUNT(DISTINCT user_pseudo_id) AS purchasers,
  SUM(ecommerce.purchase_revenue) / NULLIF(COUNT(*), 0) AS aov
FROM `project.analytics_123456789.events_*`
WHERE _TABLE_SUFFIX BETWEEN '20260101' AND '20260131'
  AND event_name = 'purchase'
GROUP BY 1
ORDER BY 1;
```

### Analisis de Fuentes de Trafico (Session-Level)

```sql
SELECT
  session_traffic_source_last_click.google_ads_campaign.campaign_name,
  session_traffic_source_last_click.manual_source.source AS source,
  session_traffic_source_last_click.manual_medium.medium AS medium,
  COUNT(DISTINCT CONCAT(
    user_pseudo_id,
    CAST(GetParamInt(event_params, 'ga_session_id') AS STRING)
  )) AS sessions,
  COUNT(DISTINCT user_pseudo_id) AS users
FROM `project.analytics_123456789.events_*`
WHERE _TABLE_SUFFIX BETWEEN '20260101' AND '20260131'
  AND event_name = 'session_start'
GROUP BY 1, 2, 3
ORDER BY sessions DESC;
```

### Landing Pages

```sql
SELECT
  GetParamString(event_params, 'page_location') AS landing_page,
  COUNT(DISTINCT CONCAT(
    user_pseudo_id,
    CAST(GetParamInt(event_params, 'ga_session_id') AS STRING)
  )) AS sessions,
  COUNT(DISTINCT user_pseudo_id) AS users
FROM `project.analytics_123456789.events_*`
WHERE _TABLE_SUFFIX BETWEEN '20260101' AND '20260131'
  AND event_name = 'session_start'
GROUP BY 1
ORDER BY sessions DESC
LIMIT 50;
```

### Funnel de Conversion

```sql
WITH funnel AS (
  SELECT
    user_pseudo_id,
    CAST(GetParamInt(event_params, 'ga_session_id') AS STRING) AS session_id,
    MAX(IF(event_name = 'page_view', 1, 0)) AS saw_page,
    MAX(IF(event_name = 'begin_checkout', 1, 0)) AS began_checkout,
    MAX(IF(event_name = 'add_payment_info', 1, 0)) AS added_payment,
    MAX(IF(event_name = 'purchase', 1, 0)) AS purchased
  FROM `project.analytics_123456789.events_*`
  WHERE _TABLE_SUFFIX BETWEEN '20260101' AND '20260131'
  GROUP BY 1, 2
)
SELECT
  COUNT(*) AS total_sessions,
  COUNTIF(saw_page = 1) AS page_viewers,
  COUNTIF(began_checkout = 1) AS checkout_starters,
  COUNTIF(added_payment = 1) AS payment_adders,
  COUNTIF(purchased = 1) AS purchasers,
  ROUND(COUNTIF(began_checkout = 1) / NULLIF(COUNTIF(saw_page = 1), 0) * 100, 1) AS pv_to_checkout_pct,
  ROUND(COUNTIF(purchased = 1) / NULLIF(COUNTIF(began_checkout = 1), 0) * 100, 1) AS checkout_to_purchase_pct
FROM funnel;
```

### Tiempo Promedio por Sesion

```sql
WITH session_durations AS (
  SELECT
    user_pseudo_id,
    GetParamInt(event_params, 'ga_session_id') AS session_id,
    (MAX(event_timestamp) - MIN(event_timestamp)) / 1000000 AS duration_seconds
  FROM `project.analytics_123456789.events_*`
  WHERE _TABLE_SUFFIX BETWEEN '20260101' AND '20260131'
  GROUP BY 1, 2
  HAVING COUNT(*) > 1  -- Excluir sesiones de un solo evento
)
SELECT
  AVG(duration_seconds) AS avg_session_duration_sec,
  APPROX_QUANTILES(duration_seconds, 100)[OFFSET(50)] AS median_duration_sec,
  COUNT(*) AS total_sessions
FROM session_durations;
```

### Usuarios Nuevos vs Recurrentes

```sql
WITH user_sessions AS (
  SELECT
    user_pseudo_id,
    MIN(event_date) AS first_visit_date,
    COUNT(DISTINCT GetParamInt(event_params, 'ga_session_id')) AS total_sessions
  FROM `project.analytics_123456789.events_*`
  WHERE _TABLE_SUFFIX BETWEEN '20260101' AND '20260231'
  GROUP BY 1
)
SELECT
  CASE
    WHEN total_sessions = 1 THEN 'Nuevo'
    WHEN total_sessions BETWEEN 2 AND 5 THEN 'Recurrente (2-5)'
    WHEN total_sessions BETWEEN 6 AND 20 THEN 'Activo (6-20)'
    ELSE 'Power User (20+)'
  END AS user_segment,
  COUNT(*) AS users
FROM user_sessions
GROUP BY 1
ORDER BY users DESC;
```

### Custom Dimensions y User Properties

```sql
-- Custom event parameter
SELECT
  GetParamString(event_params, 'plan_type') AS plan_type,
  COUNT(*) AS purchases,
  SUM(ecommerce.purchase_revenue) AS revenue
FROM `project.analytics_123456789.events_*`
WHERE _TABLE_SUFFIX BETWEEN '20260101' AND '20260131'
  AND event_name = 'purchase'
GROUP BY 1;

-- User property
SELECT
  GetUserPropString(user_properties, 'user_tier') AS user_tier,
  COUNT(DISTINCT user_pseudo_id) AS users,
  COUNT(DISTINCT IF(event_name = 'purchase', user_pseudo_id, NULL)) AS purchasers
FROM `project.analytics_123456789.events_*`
WHERE _TABLE_SUFFIX BETWEEN '20260101' AND '20260131'
GROUP BY 1;
```

---

## Optimizacion de Costos

### Regla #1: SIEMPRE filtrar con _TABLE_SUFFIX

```sql
-- CORRECTO: escanea solo las tablas necesarias
WHERE _TABLE_SUFFIX BETWEEN '20260201' AND '20260228'

-- INCORRECTO: escanea TODAS las tablas
WHERE event_date BETWEEN '20260201' AND '20260228'  -- Costoso!
```

### Regla #2: Evitar SELECT *

```sql
-- CORRECTO: solo columnas necesarias
SELECT event_name, event_timestamp, user_pseudo_id
FROM `project.analytics_123456789.events_*`

-- INCORRECTO: escanea todas las columnas
SELECT *
FROM `project.analytics_123456789.events_*`
```

### Regla #3: Usar particionamiento y clustering

Para tablas materializadas, particionar por `event_date` y clusterar por `event_name`.

### Regla #4: Estimar costos antes de ejecutar

Usar el validador de queries de BigQuery para estimar bytes escaneados antes de ejecutar.
`1 TB = ~$6.25 USD` en BigQuery on-demand.

### Regla #5: Considerar tablas materializadas

Para queries frecuentes, crear tablas materializadas con los datos pre-procesados:

```sql
CREATE OR REPLACE TABLE `project.analytics_processed.daily_metrics`
PARTITION BY event_date_parsed
CLUSTER BY event_name
AS
SELECT
  PARSE_DATE('%Y%m%d', event_date) AS event_date_parsed,
  event_name,
  COUNT(*) AS event_count,
  COUNT(DISTINCT user_pseudo_id) AS unique_users
FROM `project.analytics_123456789.events_*`
WHERE _TABLE_SUFFIX >= '20260101'
GROUP BY 1, 2;
```

---

## Export Intraday vs Diario

| Tipo | Tabla | Frecuencia | Notas |
|------|-------|-----------|-------|
| **Diario** | `events_YYYYMMDD` | 1x/dia, completo al dia siguiente | Datos finales, puede actualizarse hasta 3 dias despues |
| **Streaming (Intraday)** | `events_intraday_YYYYMMDD` | Continuo, datos parciales | Se reemplaza por tabla diaria al completarse |

### Query que incluye datos intraday

```sql
-- Union de datos historicos + datos de hoy (intraday)
SELECT event_name, COUNT(*) AS events
FROM (
  SELECT event_name FROM `project.analytics_123456789.events_*`
  WHERE _TABLE_SUFFIX BETWEEN '20260201' AND '20260223'
  UNION ALL
  SELECT event_name FROM `project.analytics_123456789.events_intraday_20260224`
)
GROUP BY 1
ORDER BY events DESC;
```

---

## Configurar BigQuery Export

### Via Admin API (Python)

```python
from google.analytics.admin_v1alpha import AnalyticsAdminServiceClient
from google.analytics.admin_v1alpha.types import BigQueryLink, CreateBigQueryLinkRequest

admin = AnalyticsAdminServiceClient()

link = admin.create_big_query_link(request=CreateBigQueryLinkRequest(
    parent=f"properties/{property_id}",
    bigquery_link=BigQueryLink(
        project=f"projects/{gcp_project_id}",
        daily_export_enabled=True,
        streaming_export_enabled=True,
        include_advertising_id=False,
        export_streams=[f"properties/{property_id}/dataStreams/{stream_id}"],
    ),
))
print(f"BigQuery Link creado: {link.name}")
```

### Requisitos

1. El proyecto GCP debe tener BigQuery API habilitada
2. El service account de GA4 necesita rol `BigQuery Data Editor` en el dataset
3. Para streaming export, tambien necesita `BigQuery Job User`

---

## Consent Mode y BigQuery

**CRITICO:** BigQuery Export **NO incluye datos modelados** de Consent Mode.

| Fuente | Datos Modelados | Datos Observados |
|--------|----------------|-----------------|
| Data API (UI) | SI | SI |
| BigQuery Export | **NO** | SI |

Los registros de usuarios que no dieron consentimiento tienen `user_pseudo_id` como `null`
en BigQuery. Esperar numeros **menores** en BigQuery vs la UI de GA4.

---

## Enhanced Conversions y BigQuery

**AVISO:** Habilitar Enhanced Conversions para GA4 **elimina permanentemente** `user_id`
de los exports de BigQuery y puede alterar estructuras de datos. Evaluar cuidadosamente
antes de habilitar.

---

## Limites de Export

| Tipo de Propiedad | Limite Diario | Limite Streaming |
|-------------------|---------------|-----------------|
| Standard | 1M eventos/dia | Sin limite |
| GA360 | Sin limite practico | Sin limite |

> Para propiedades standard que exceden 1M eventos/dia, se pueden excluir eventos/streams
> no criticos en la configuracion del BigQuery Link.
