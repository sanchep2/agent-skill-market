# Data API v1beta — Reporting Completo

## Table of Contents

1. [Resumen](#resumen)
2. [Metodos Core (v1beta — Estable)](#metodos-core-v1beta--estable)
3. [Metodos Alpha (v1alpha — Puede Tener Breaking Changes)](#metodos-alpha-v1alpha--puede-tener-breaking-changes)
4. [Anatomia de runReport](#anatomia-de-runreport)
5. [Tipos de Filtros](#tipos-de-filtros)
6. [Date Ranges](#date-ranges)
7. [Dimensiones y Metricas Clave](#dimensiones-y-metricas-clave)
8. [batchRunReports — Multiples Reportes en Una Llamada](#batchrunreports--multiples-reportes-en-una-llamada)
9. [runPivotReport — Tablas Pivote](#runpivotreport--tablas-pivote)
10. [runRealtimeReport — Datos en Tiempo Real](#runrealtimereport--datos-en-tiempo-real)
11. [checkCompatibility — Validar Antes de Gastar Tokens](#checkcompatibility--validar-antes-de-gastar-tokens)
12. [getMetadata — Descubrir Dimensiones y Metricas](#getmetadata--descubrir-dimensiones-y-metricas)
13. [Sampling y Calidad de Datos](#sampling-y-calidad-de-datos)
14. [Paginacion](#paginacion)
15. [Parsear Response](#parsear-response)
16. [Recetas Comunes](#recetas-comunes)

---

## Resumen

La Data API (`https://analyticsdata.googleapis.com`) es la superficie de solo lectura para
reporting en GA4. Requiere el scope OAuth `analytics.readonly` (o `analytics`).
Referencia propiedades como `properties/{numericId}`.

**Version estable: v1beta. NO existe v2.** Features migran de v1alpha → v1beta.

---

## Metodos Core (v1beta — Estable)

| Metodo | Endpoint | Proposito | Limites |
|--------|----------|-----------|---------|
| `runReport` | `POST properties/*:runReport` | Reporte tabular estandar | 9 dims, 10 metricas, 4 date ranges, 100K filas |
| `batchRunReports` | `POST properties/*:batchRunReports` | Hasta 5 runReport en una llamada | 5 sub-requests |
| `runPivotReport` | `POST properties/*:runPivotReport` | Tabla pivote cross-tabulation | Dims x pivots <= 100K celdas |
| `batchRunPivotReports` | `POST properties/*:batchRunPivotReports` | Hasta 5 pivot reports | 5 sub-requests |
| `runRealtimeReport` | `POST properties/*:runRealtimeReport` | Ultimos 30 min (60 min GA360) | Dims/metricas limitadas |
| `getMetadata` | `GET properties/*/metadata` | Descubrir dims, metricas, custom defs | Sin costo de tokens |
| `checkCompatibility` | `POST properties/*:checkCompatibility` | Validar compatibilidad dim/metric | Sin costo de tokens |

## Metodos Alpha (v1alpha — Puede Tener Breaking Changes)

| Metodo | Proposito |
|--------|-----------|
| `runFunnelReport` | Funnel multi-paso con segmentos |
| `createAudienceExport` / `getAudienceExport` / `listAudienceExports` / `queryAudienceExport` | Snapshot de usuarios en una audiencia (graduado a v1beta) |
| `createRecurringAudienceList` / `get` / `list` | Listas de audiencia con refresh diario |
| `createReportTask` / `getReportTask` / `listReportTasks` / `queryReportTask` | Reportes async con control de sampling (GA360: `UNSAMPLED` hasta 1B eventos) |
| `getPropertyQuotasSnapshot` | Ver todas las cuotas de un vistazo |
| `sheetExportAudienceList` | Exportar audiencia directamente a Google Sheets |

---

## Anatomia de runReport

### Request completa (TypeScript)

```typescript
import { BetaAnalyticsDataClient } from '@google-analytics/data';

const client = new BetaAnalyticsDataClient();
const propertyId = '123456789';

const [response] = await client.runReport({
  property: `properties/${propertyId}`,

  // Dimensiones (max 9)
  dimensions: [
    { name: 'country' },
    { name: 'sessionDefaultChannelGroup' },
  ],

  // Metricas (max 10)
  metrics: [
    { name: 'activeUsers' },
    { name: 'sessions' },
    { name: 'keyEvents' },
  ],

  // Date ranges (max 4)
  dateRanges: [
    { startDate: '30daysAgo', endDate: 'yesterday' },
    { startDate: '60daysAgo', endDate: '31daysAgo' },  // Periodo de comparacion
  ],

  // Filtro de dimensiones (antes de agregacion)
  dimensionFilter: {
    andGroup: {
      expressions: [
        {
          filter: {
            fieldName: 'country',
            stringFilter: { matchType: 'EXACT', value: 'United States' },
          },
        },
        {
          notExpression: {
            filter: {
              fieldName: 'sessionDefaultChannelGroup',
              stringFilter: { matchType: 'EXACT', value: '(other)' },
            },
          },
        },
      ],
    },
  },

  // Filtro de metricas (despues de agregacion)
  metricFilter: {
    filter: {
      fieldName: 'activeUsers',
      numericFilter: {
        operation: 'GREATER_THAN',
        value: { int64Value: '10' },
      },
    },
  },

  // Ordenamiento
  orderBys: [{ metric: { metricName: 'activeUsers' }, desc: true }],

  // Paginacion
  limit: 100,
  offset: 0,

  // SIEMPRE activar para monitorizar tokens
  returnPropertyQuota: true,
});
```

### Request completa (Python)

```python
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import (
    RunReportRequest, DateRange, Dimension, Metric,
    FilterExpression, Filter, FilterExpressionList, OrderBy,
)

client = BetaAnalyticsDataClient()

response = client.run_report(RunReportRequest(
    property=f"properties/{property_id}",
    dimensions=[
        Dimension(name="country"),
        Dimension(name="sessionDefaultChannelGroup"),
    ],
    metrics=[
        Metric(name="activeUsers"),
        Metric(name="sessions"),
        Metric(name="keyEvents"),
    ],
    date_ranges=[
        DateRange(start_date="30daysAgo", end_date="yesterday"),
        DateRange(start_date="60daysAgo", end_date="31daysAgo"),
    ],
    dimension_filter=FilterExpression(
        and_group=FilterExpressionList(expressions=[
            FilterExpression(filter=Filter(
                field_name="country",
                string_filter=Filter.StringFilter(
                    match_type=Filter.StringFilter.MatchType.EXACT,
                    value="United States",
                ),
            )),
        ])
    ),
    order_bys=[OrderBy(
        metric=OrderBy.MetricOrderBy(metric_name="activeUsers"),
        desc=True,
    )],
    limit=100,
    return_property_quota=True,
))
```

---

## Tipos de Filtros

Los filtros se envuelven en un `FilterExpression` que soporta `andGroup`, `orGroup`,
`notExpression`, o un `filter` individual.

### StringFilter

| matchType | Descripcion |
|-----------|-------------|
| `EXACT` | Coincidencia exacta |
| `BEGINS_WITH` | Empieza con |
| `ENDS_WITH` | Termina con |
| `CONTAINS` | Contiene |
| `FULL_REGEXP` | Regex completa (toda la cadena) |
| `PARTIAL_REGEXP` | Regex parcial (subcadena) |

### InListFilter

Hasta **500 valores** en la lista.

```typescript
filter: {
  fieldName: 'country',
  inListFilter: { values: ['United States', 'Canada', 'Mexico'] },
}
```

### NumericFilter

Operaciones: `EQUAL`, `LESS_THAN`, `LESS_THAN_OR_EQUAL`, `GREATER_THAN`, `GREATER_THAN_OR_EQUAL`.

```typescript
filter: {
  fieldName: 'activeUsers',
  numericFilter: {
    operation: 'GREATER_THAN',
    value: { int64Value: '100' },
  },
}
```

### BetweenFilter

```typescript
filter: {
  fieldName: 'sessions',
  betweenFilter: {
    fromValue: { int64Value: '10' },
    toValue: { int64Value: '1000' },
  },
}
```

### EmptyFilter (Nuevo 2024)

Filtra valores vacios/en blanco.

```typescript
filter: {
  fieldName: 'pagePath',
  emptyFilter: {},
}
```

> **REGLA:** Filtros de dimension aplican ANTES de la agregacion.
> Filtros de metrica aplican DESPUES de la agregacion.

---

## Date Ranges

### Valores especiales

- `today` — Hoy
- `yesterday` — Ayer
- `NdaysAgo` — Ej: `7daysAgo`, `30daysAgo`, `365daysAgo`

### Multiples date ranges (max 4)

Cada date range genera su propia columna en las filas de respuesta.
Util para comparaciones periodo a periodo.

```typescript
dateRanges: [
  { startDate: '30daysAgo', endDate: 'yesterday', name: 'actual' },
  { startDate: '60daysAgo', endDate: '31daysAgo', name: 'anterior' },
]
```

---

## Dimensiones y Metricas Clave

### Dimensiones por Categoria

**Tiempo:** `eventName`, `date`, `dateHour`, `dateHourMinute`, `dayOfWeek`, `hour`

**Geografia:** `country`, `city`, `region`, `continent`, `subContinent`, `metro`

**Dispositivo:** `deviceCategory`, `browser`, `operatingSystem`, `platform`,
`operatingSystemVersion`, `browserVersion`, `screenResolution`, `language`

**Pagina/Pantalla:** `pagePath`, `pagePathPlusQueryString`, `pageTitle`,
`landingPage`, `landingPagePlusQueryString`, `hostName`, `unifiedScreenName`

**Trafico:** `sessionDefaultChannelGroup`, `sessionSource`, `sessionMedium`,
`sessionSourceMedium`, `sessionCampaignName`, `firstUserSource`, `firstUserMedium`,
`firstUserCampaignName`, `firstUserDefaultChannelGroup`

**Usuario:** `newVsReturning`, `userAgeBracket`, `userGender`

**E-commerce:** `transactionId`, `itemName`, `itemId`, `itemBrand`,
`itemCategory` (1-5)

**Key Events:** `isKeyEvent`

**Custom:** `customEvent:param_name`, `customUser:param_name`, `customItem:param_name`

### Metricas Principales

**Usuarios:** `activeUsers`, `newUsers`, `totalUsers`, `returningUsers`

**Sesiones:** `sessions`, `engagedSessions`, `engagementRate`, `bounceRate`,
`averageSessionDuration`, `sessionsPerUser`

**Paginas:** `screenPageViews`, `screenPageViewsPerSession`

**Eventos:** `eventCount`, `eventsPerSession`, `eventCountPerUser`

**Key Events:** `keyEvents`, `sessionKeyEventRate`, `userKeyEventRate`

**E-commerce:** `totalRevenue`, `purchaseRevenue`, `ecommercePurchases`,
`transactions`, `itemRevenue`, `addToCarts`, `checkouts`

**Custom:** `customEvent:param_name` (suma por defecto), `:average`, `:count` sufijos

---

## batchRunReports — Multiples Reportes en Una Llamada

Ejecuta hasta 5 `runReport` en una sola llamada HTTP. Util para dashboards.

```python
response = client.batch_run_reports(request={
    "property": f"properties/{property_id}",
    "requests": [
        RunReportRequest(
            dimensions=[Dimension(name="country")],
            metrics=[Metric(name="activeUsers")],
            date_ranges=[DateRange(start_date="7daysAgo", end_date="yesterday")],
        ),
        RunReportRequest(
            dimensions=[Dimension(name="sessionDefaultChannelGroup")],
            metrics=[Metric(name="sessions"), Metric(name="keyEvents")],
            date_ranges=[DateRange(start_date="7daysAgo", end_date="yesterday")],
        ),
    ],
})

for i, report in enumerate(response.reports):
    print(f"--- Reporte {i+1} ---")
    for row in report.rows:
        dims = " | ".join(dv.value for dv in row.dimension_values)
        mets = " | ".join(mv.value for mv in row.metric_values)
        print(f"  {dims}: {mets}")
```

---

## runPivotReport — Tablas Pivote

```python
from google.analytics.data_v1beta.types import Pivot

response = client.run_pivot_report(request={
    "property": f"properties/{property_id}",
    "dimensions": [
        Dimension(name="country"),
        Dimension(name="deviceCategory"),
    ],
    "metrics": [Metric(name="activeUsers")],
    "date_ranges": [DateRange(start_date="30daysAgo", end_date="yesterday")],
    "pivots": [
        Pivot(
            field_names=["country"],
            limit=10,
            order_bys=[OrderBy(
                metric=OrderBy.MetricOrderBy(metric_name="activeUsers"),
                desc=True,
            )],
        ),
        Pivot(
            field_names=["deviceCategory"],
            limit=5,
        ),
    ],
})
```

---

## runRealtimeReport — Datos en Tiempo Real

Datos de los ultimos 30 minutos (60 minutos para GA360).
Conjunto limitado de dimensiones y metricas.

```python
from google.analytics.data_v1beta.types import RunRealtimeReportRequest, MinuteRange

response = client.run_realtime_report(RunRealtimeReportRequest(
    property=f"properties/{property_id}",
    dimensions=[Dimension(name="country"), Dimension(name="unifiedScreenName")],
    metrics=[Metric(name="activeUsers"), Metric(name="eventCount")],
    minute_ranges=[
        MinuteRange(name="0-5min", start_minutes_ago=5, end_minutes_ago=0),
        MinuteRange(name="5-30min", start_minutes_ago=30, end_minutes_ago=5),
    ],
))
```

### Dimensiones Realtime Disponibles

`appVersion`, `audienceId`, `audienceName`, `city`, `cityId`, `country`,
`countryId`, `deviceCategory`, `eventName`, `minutesAgo`, `platform`,
`streamId`, `streamName`, `unifiedScreenClass`, `unifiedScreenName`

### Metricas Realtime Disponibles

`activeUsers`, `eventCount`, `keyEvents`, `screenPageViews`

---

## checkCompatibility — Validar Antes de Gastar Tokens

Verifica que una combinacion de dimensiones y metricas sea compatible
**sin consumir tokens de quota**.

```python
from google.analytics.data_v1beta.types import CheckCompatibilityRequest

compat = client.check_compatibility(CheckCompatibilityRequest(
    property=f"properties/{property_id}",
    dimensions=[Dimension(name="country"), Dimension(name="sessionDefaultChannelGroup")],
    metrics=[Metric(name="activeUsers"), Metric(name="sessions")],
))

# Verificar incompatibilidades
for dim_compat in compat.dimension_compatibilities:
    if not dim_compat.compatible:
        print(f"Dimension incompatible: {dim_compat.dimension_metadata.api_name}")

for met_compat in compat.metric_compatibilities:
    if not met_compat.compatible:
        print(f"Metrica incompatible: {met_compat.metric_metadata.api_name}")
```

---

## getMetadata — Descubrir Dimensiones y Metricas

```python
from google.analytics.data_v1beta.types import GetMetadataRequest

metadata = client.get_metadata(GetMetadataRequest(
    name=f"properties/{property_id}/metadata"
))

print(f"Dimensiones disponibles: {len(metadata.dimensions)}")
for dim in metadata.dimensions:
    print(f"  {dim.api_name}: {dim.ui_name} ({dim.category})")

print(f"\nMetricas disponibles: {len(metadata.metrics)}")
for met in metadata.metrics:
    print(f"  {met.api_name}: {met.ui_name} ({met.category})")
```

---

## Sampling y Calidad de Datos

### Cuando Ocurre Sampling

- Standard properties: cuando eventos superan **~10M** para el date range
- GA360 properties: cuando eventos superan **~1B**
- Reportes pre-agregados de Data API generalmente NO tienen sampling

### Detectar Sampling

```python
response = client.run_report(request)

if response.metadata.sampling_metadatas:
    for sample in response.metadata.sampling_metadatas:
        rate = sample.samples_read_count / sample.sampling_space_size
        print(f"AVISO: Datos muestreados al {rate:.1%}")
```

### Evitar Sampling

1. **Acortar date ranges** — Dividir consulta en rangos mas cortos
2. **Reducir dimensiones** — Menos dimensiones = menos combinaciones
3. **BigQuery Export** — SIEMPRE 100% sin muestreo
4. **GA360 Report Tasks** — `samplingLevel: UNSAMPLED` hasta 1B eventos

### Cardinalidad y (other) Row

Dimensiones con mas de **~50K valores unicos** agrupan excedentes en `(other)`.

```python
# Detectar perdida de datos por cardinalidad
if response.metadata.data_loss_from_other_row:
    print("AVISO: Datos agrupados en (other) por alta cardinalidad")
    print("Solucion: usar BigQuery Export para datos completos")
```

---

## Paginacion

```python
# Primera pagina
response = client.run_report(RunReportRequest(
    property=f"properties/{property_id}",
    dimensions=[Dimension(name="pagePath")],
    metrics=[Metric(name="screenPageViews")],
    date_ranges=[DateRange(start_date="30daysAgo", end_date="yesterday")],
    limit=1000,
    offset=0,
))

total_rows = response.row_count
print(f"Total filas: {total_rows}")

# Paginar si hay mas filas
all_rows = list(response.rows)
offset = 1000
while offset < total_rows:
    response = client.run_report(RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[Dimension(name="pagePath")],
        metrics=[Metric(name="screenPageViews")],
        date_ranges=[DateRange(start_date="30daysAgo", end_date="yesterday")],
        limit=1000,
        offset=offset,
    ))
    all_rows.extend(response.rows)
    offset += 1000
```

---

## Parsear Response

### Estructura de Response

```python
response = client.run_report(request)

# Metadata
print(f"Total filas: {response.row_count}")
print(f"Perdida por (other): {response.metadata.data_loss_from_other_row}")

# Headers de dimensiones y metricas
dim_headers = [h.name for h in response.dimension_headers]
met_headers = [h.name for h in response.metric_headers]

# Filas de datos
for row in response.rows:
    record = {}
    for i, dv in enumerate(row.dimension_values):
        record[dim_headers[i]] = dv.value
    for i, mv in enumerate(row.metric_values):
        record[met_headers[i]] = mv.value
    print(record)

# Totals (agregados de todas las filas)
if response.totals:
    for total_row in response.totals:
        totals = {met_headers[i]: mv.value for i, mv in enumerate(total_row.metric_values)}
        print(f"Totales: {totals}")

# Quota (si returnPropertyQuota=true)
if response.property_quota:
    pq = response.property_quota
    print(f"Tokens/dia: {pq.tokens_per_day.consumed}/{pq.tokens_per_day.remaining}")
    print(f"Tokens/hora: {pq.tokens_per_hour.consumed}/{pq.tokens_per_hour.remaining}")
```

---

## Recetas Comunes

### Dashboard KPI basico

```python
def get_dashboard_kpis(client, property_id, start_date="7daysAgo", end_date="yesterday"):
    """Obtener KPIs principales para un dashboard."""
    response = client.run_report(RunReportRequest(
        property=f"properties/{property_id}",
        metrics=[
            Metric(name="activeUsers"),
            Metric(name="newUsers"),
            Metric(name="sessions"),
            Metric(name="engagementRate"),
            Metric(name="averageSessionDuration"),
            Metric(name="keyEvents"),
            Metric(name="totalRevenue"),
        ],
        date_ranges=[
            DateRange(start_date=start_date, end_date=end_date, name="actual"),
            DateRange(start_date="14daysAgo", end_date="8daysAgo", name="anterior"),
        ],
        return_property_quota=True,
    ))

    # Parsear periodo actual vs anterior
    kpis = {}
    if response.totals:
        for i, met in enumerate(["activeUsers", "newUsers", "sessions",
                                  "engagementRate", "avgSessionDuration",
                                  "keyEvents", "totalRevenue"]):
            actual = float(response.totals[0].metric_values[i].value or "0")
            anterior = float(response.totals[1].metric_values[i].value or "0")
            cambio = ((actual - anterior) / anterior * 100) if anterior else 0
            kpis[met] = {"actual": actual, "anterior": anterior, "cambio_pct": round(cambio, 1)}

    return kpis
```

### Top paginas por sesiones

```python
def get_top_pages(client, property_id, limit=20):
    """Top paginas por numero de sesiones."""
    response = client.run_report(RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[Dimension(name="pagePath"), Dimension(name="pageTitle")],
        metrics=[
            Metric(name="screenPageViews"),
            Metric(name="activeUsers"),
            Metric(name="averageSessionDuration"),
            Metric(name="bounceRate"),
        ],
        date_ranges=[DateRange(start_date="30daysAgo", end_date="yesterday")],
        order_bys=[OrderBy(
            metric=OrderBy.MetricOrderBy(metric_name="screenPageViews"),
            desc=True,
        )],
        limit=limit,
        return_property_quota=True,
    ))
    return response
```

### Fuentes de trafico

```python
def get_traffic_sources(client, property_id):
    """Desglose de fuentes de trafico."""
    response = client.run_report(RunReportRequest(
        property=f"properties/{property_id}",
        dimensions=[
            Dimension(name="sessionDefaultChannelGroup"),
            Dimension(name="sessionSourceMedium"),
        ],
        metrics=[
            Metric(name="sessions"),
            Metric(name="activeUsers"),
            Metric(name="keyEvents"),
            Metric(name="totalRevenue"),
        ],
        date_ranges=[DateRange(start_date="30daysAgo", end_date="yesterday")],
        order_bys=[OrderBy(
            metric=OrderBy.MetricOrderBy(metric_name="sessions"),
            desc=True,
        )],
        limit=50,
        return_property_quota=True,
    ))
    return response
```
