# Autenticacion y Setup — GA4 APIs

## Resumen

GA4 requiere autenticacion OAuth 2.0 o service accounts para todas sus APIs.
**Las API keys NO funcionan** con GA4 — siempre se necesitan credenciales OAuth o service account.
Este documento cubre todos los patrones de autenticacion, scopes, roles y setup para las
cuatro superficies de API de GA4.

---

## Service Accounts (Servidor a Servidor — Recomendado)

### Setup paso a paso

1. **Habilitar APIs** en el proyecto GCP:
   ```bash
   gcloud services enable analyticsdata.googleapis.com
   gcloud services enable analyticsadmin.googleapis.com
   ```

2. **Crear service account:**
   ```bash
   gcloud iam service-accounts create ga4-automation \
     --display-name="GA4 Automation" \
     --project=my-gcp-project
   ```

3. **Descargar clave JSON:**
   ```bash
   gcloud iam service-accounts keys create key.json \
     --iam-account=ga4-automation@my-gcp-project.iam.gserviceaccount.com
   ```

4. **Agregar a GA4 Property:**
   - GA4 Admin → Property Access Management
   - Agregar email del service account (ej: `ga4-automation@my-gcp-project.iam.gserviceaccount.com`)
   - Asignar rol apropiado (Viewer para lectura, Editor para escritura)

5. **Configurar variable de entorno:**
   ```bash
   export GOOGLE_APPLICATION_CREDENTIALS=/path/to/key.json
   ```

### Credenciales explicitas (sin variable de entorno)

```python
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient

credentials = service_account.Credentials.from_service_account_file(
    "key.json",
    scopes=["https://www.googleapis.com/auth/analytics.readonly"]
)
client = BetaAnalyticsDataClient(credentials=credentials)
```

```typescript
import { BetaAnalyticsDataClient } from '@google-analytics/data';

const client = new BetaAnalyticsDataClient({
  keyFilename: '/path/to/key.json',
});
```

### JSON string en memoria (para secrets managers)

```python
import json
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient

creds_dict = json.loads(os.environ["GA4_SERVICE_ACCOUNT_JSON"])
credentials = service_account.Credentials.from_service_account_info(
    creds_dict,
    scopes=["https://www.googleapis.com/auth/analytics.readonly"]
)
client = BetaAnalyticsDataClient(credentials=credentials)
```

---

## Workload Identity Federation (Sin Claves — Cloud Native)

Elimina archivos de claves para entornos cloud. Recomendado para GKE, Cloud Run,
GitHub Actions, AWS y Azure.

### GitHub Actions

```yaml
jobs:
  ga4-report:
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      contents: read
    steps:
      - uses: google-github-actions/auth@v2
        with:
          workload_identity_provider: 'projects/NUM/locations/global/workloadIdentityPools/POOL/providers/PROV'
          service_account: 'ga4-automation@my-project.iam.gserviceaccount.com'

      - run: pip install google-analytics-data google-analytics-admin
      - run: python scripts/ga4_report.py
        env:
          GA4_PROPERTY_ID: ${{ vars.GA4_PROPERTY_ID }}
```

### GCE / GKE

Attach el service account directamente al recurso de computo:

```bash
# GCE
gcloud compute instances create my-vm \
  --service-account=ga4-automation@my-project.iam.gserviceaccount.com \
  --scopes=https://www.googleapis.com/auth/analytics.readonly

# GKE — Workload Identity
gcloud iam service-accounts add-iam-policy-binding \
  ga4-automation@my-project.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:my-project.svc.id.goog[NAMESPACE/KSA_NAME]"
```

### Cloud Run

```bash
gcloud run deploy ga4-service \
  --service-account=ga4-automation@my-project.iam.gserviceaccount.com \
  --image=gcr.io/my-project/ga4-service
```

---

## OAuth 2.0 (Acceso Delegado por Usuario)

Necesario cuando se actua en nombre de un usuario humano (ej: apps web con login).

### Scopes por Operacion

| Scope | URL Completa | Proposito |
|-------|-------------|-----------|
| `analytics.readonly` | `https://www.googleapis.com/auth/analytics.readonly` | Data API lectura, Admin API lectura |
| `analytics.edit` | `https://www.googleapis.com/auth/analytics.edit` | Admin API escritura (crear/actualizar/eliminar config) |
| `analytics` | `https://www.googleapis.com/auth/analytics` | Acceso completo (lectura + escritura) |
| `analytics.manage.users` | `https://www.googleapis.com/auth/analytics.manage.users` | Gestion de permisos de usuarios |
| `analytics.manage.users.readonly` | `https://www.googleapis.com/auth/analytics.manage.users.readonly` | Leer permisos de usuarios |
| `analytics.provision` | `https://www.googleapis.com/auth/analytics.provision` | Crear nuevas cuentas |

> **NOTA:** Todos los scopes GA4 son **sensitive** y requieren verificacion de OAuth consent
> screen para apps publicas.

### Flujo OAuth (Python)

```python
from google_auth_oauthlib.flow import InstalledAppFlow

SCOPES = ["https://www.googleapis.com/auth/analytics.readonly"]

flow = InstalledAppFlow.from_client_secrets_file("client_secret.json", SCOPES)
credentials = flow.run_local_server(port=8080)

# Guardar token para reusar
import pickle
with open("token.pickle", "wb") as f:
    pickle.dump(credentials, f)

# Usar token guardado
with open("token.pickle", "rb") as f:
    credentials = pickle.load(f)
if credentials.expired:
    credentials.refresh(Request())
```

### Flujo OAuth (Node.js)

```typescript
import { OAuth2Client } from 'google-auth-library';

const oauth2Client = new OAuth2Client(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  'http://localhost:3000/callback'
);

// Generar URL de autorizacion
const url = oauth2Client.generateAuthUrl({
  access_type: 'offline',
  scope: ['https://www.googleapis.com/auth/analytics.readonly'],
});

// Intercambiar codigo por tokens
const { tokens } = await oauth2Client.getToken(code);
oauth2Client.setCredentials(tokens);

// Usar con Data API
import { BetaAnalyticsDataClient } from '@google-analytics/data';
const client = new BetaAnalyticsDataClient({ authClient: oauth2Client });
```

---

## Roles a Nivel de Propiedad GA4

| Rol | Capacidades |
|-----|-------------|
| **Administrator** | Control total incluyendo gestion de usuarios |
| **Editor** | Editar configuracion de propiedad, eventos, conversiones — sin gestion de usuarios |
| **Marketer** | Gestionar audiencias, conversiones, atribucion, eventos |
| **Analyst** | Crear/editar exploraciones y reportes compartidos |
| **Viewer** | Acceso de solo lectura a reportes y datos |

### Asignar roles via Admin API

```python
from google.analytics.admin_v1alpha import AnalyticsAdminServiceClient
from google.analytics.admin_v1alpha.types import AccessBinding

admin = AnalyticsAdminServiceClient()

# Agregar usuario con rol Analyst
admin.create_access_binding(request={
    "parent": f"properties/{property_id}",
    "access_binding": AccessBinding(
        user="analyst@company.com",
        roles=["predefinedRoles/analyst"],
    ),
})

# Roles disponibles:
# predefinedRoles/admin
# predefinedRoles/editor
# predefinedRoles/marketer
# predefinedRoles/analyst
# predefinedRoles/viewer
# predefinedRoles/no-cost-data  (solo datos sin costo)
# predefinedRoles/no-revenue-data  (sin datos de revenue)
```

---

## APIs a Habilitar

```bash
# Obligatorias
gcloud services enable analyticsdata.googleapis.com      # Data API
gcloud services enable analyticsadmin.googleapis.com      # Admin API

# Opcionales (segun uso)
gcloud services enable bigquery.googleapis.com            # BigQuery Export queries
gcloud services enable bigquerydatatransfer.googleapis.com # BigQuery transfers
```

---

## Variables de Entorno Recomendadas

```bash
# Credenciales
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account-key.json
# O bien:
GA4_SERVICE_ACCOUNT_JSON='{"type":"service_account",...}'

# IDs de propiedad
GA4_PROPERTY_ID=123456789

# Measurement Protocol
GA4_MEASUREMENT_ID=G-XXXXXXXXXX
GA4_MP_API_SECRET=your_api_secret_here

# BigQuery
GA4_BQ_PROJECT=my-gcp-project
GA4_BQ_DATASET=analytics_123456789
```

---

## Verificacion de Setup

```python
# Verificar que las credenciales funcionan
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import RunReportRequest, DateRange, Metric

client = BetaAnalyticsDataClient()

try:
    response = client.run_report(RunReportRequest(
        property=f"properties/{property_id}",
        metrics=[Metric(name="activeUsers")],
        date_ranges=[DateRange(start_date="yesterday", end_date="today")],
    ))
    print(f"OK — {response.rows[0].metric_values[0].value} usuarios activos ayer")
except Exception as e:
    print(f"ERROR: {e}")
    # Errores comunes:
    # 403 — Service account no tiene acceso a la propiedad
    # 401 — Credenciales invalidas o expiradas
    # 404 — Property ID incorrecto
```

```bash
# Verificar via curl
curl -X POST \
  -H "Authorization: Bearer $(gcloud auth application-default print-access-token)" \
  -H "Content-Type: application/json" \
  -d '{"dateRanges":[{"startDate":"yesterday","endDate":"today"}],"metrics":[{"name":"activeUsers"}]}' \
  "https://analyticsdata.googleapis.com/v1beta/properties/${GA4_PROPERTY_ID}:runReport"
```

---

## Troubleshooting de Auth

| Error | Causa | Solucion |
|-------|-------|----------|
| `403 PERMISSION_DENIED` | Service account sin acceso a la propiedad | Agregar email en GA4 Admin → Property Access Management |
| `401 UNAUTHENTICATED` | Credenciales invalidas o expiradas | Verificar `GOOGLE_APPLICATION_CREDENTIALS` o refresh token |
| `404 NOT_FOUND` | Property ID incorrecto | Verificar con `admin.list_account_summaries()` |
| `403 API not enabled` | API no habilitada en proyecto GCP | `gcloud services enable analyticsdata.googleapis.com` |
| `400 invalid_scope` | Scope no autorizado en consent screen | Agregar scope en GCP Console → OAuth consent screen |
| `DEADLINE_EXCEEDED` | Timeout en la request | Incrementar timeout del cliente: `client = BetaAnalyticsDataClient(transport='grpc', timeout=120)` |
