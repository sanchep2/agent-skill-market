# Ecosistema de Herramientas — CLI, Terraform, CI/CD, MCP

## Resumen

No existen comandos nativos `gcloud analytics` para GA4. La automatizacion se hace via
client libraries, REST API directa, o herramientas del ecosistema como el GA4 MCP Server.
Terraform tiene soporte muy limitado para GA4.

---

## Client Libraries Oficiales

### Python

```bash
pip install google-analytics-data    # v0.20.0 (Data API)
pip install google-analytics-admin   # v0.27.0 (Admin API)
```

```python
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.admin_v1alpha import AnalyticsAdminServiceClient

# Ambas usan GOOGLE_APPLICATION_CREDENTIALS automaticamente
data_client = BetaAnalyticsDataClient()
admin_client = AnalyticsAdminServiceClient()
```

### Node.js / TypeScript

```bash
npm install @google-analytics/data    # v5.x (Data API)
npm install @google-analytics/admin   # v9.x (Admin API)
```

> **IMPORTANTE:** Usar `@google-analytics/data`, NO el deprecado `@googleapis/analyticsdata`.

```typescript
import { BetaAnalyticsDataClient } from '@google-analytics/data';
import { AnalyticsAdminServiceClient } from '@google-analytics/admin/build/src/v1alpha';

const dataClient = new BetaAnalyticsDataClient();
const adminClient = new AnalyticsAdminServiceClient();
```

### Otras Plataformas

| Lenguaje | Paquete Data API | Paquete Admin API |
|----------|-----------------|-------------------|
| Java | `google-analytics-data` | `google-analytics-admin` |
| Go | `cloud.google.com/go/analytics/data/apiv1beta` | `cloud.google.com/go/analytics/admin/apiv1alpha` |
| PHP | `google/analytics-data` | `google/analytics-admin` |
| Ruby | `google-analytics-data-v1beta` | `google-analytics-admin-v1alpha` |
| .NET | `Google.Analytics.Data.V1Beta` | `Google.Analytics.Admin.V1Alpha` |

---

## GA4 MCP Server (Septiembre 2025)

Servidor MCP oficial y experimental de Google para acceso conversacional a datos de GA4.
**Solo lectura.**

### Instalacion

```bash
# Via pipx (recomendado)
pipx run analytics-mcp

# Via pip
pip install analytics-mcp
analytics-mcp
```

### Herramientas Disponibles

| Herramienta MCP | Descripcion |
|----------------|-------------|
| `get_account_summaries` | Listar todas las cuentas y propiedades accesibles |
| `run_report` | Ejecutar reporte estandar de Data API |
| `run_realtime_report` | Reporte en tiempo real |
| `get_property_details` | Detalles de una propiedad GA4 |

### Configuracion para Claude Desktop

```json
{
  "mcpServers": {
    "ga4": {
      "command": "pipx",
      "args": ["run", "analytics-mcp"],
      "env": {
        "GOOGLE_APPLICATION_CREDENTIALS": "/path/to/key.json"
      }
    }
  }
}
```

### Limitaciones

- Solo lectura — no puede modificar configuracion de propiedades
- Experimental — puede tener breaking changes
- Requiere autenticacion via service account o Application Default Credentials
- No soporta todas las features de Data API (funnels, audience exports, etc.)

---

## REST API via curl

Util para scripts rapidos y debugging.

### Obtener Access Token

```bash
# Con Application Default Credentials
ACCESS_TOKEN=$(gcloud auth application-default print-access-token)

# Con service account
ACCESS_TOKEN=$(gcloud auth print-access-token --impersonate-service-account=ga4@project.iam.gserviceaccount.com)
```

### runReport

```bash
PROPERTY_ID="123456789"

curl -s -X POST \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "dateRanges": [{"startDate": "7daysAgo", "endDate": "today"}],
    "dimensions": [{"name": "city"}],
    "metrics": [{"name": "activeUsers"}],
    "limit": 10,
    "returnPropertyQuota": true
  }' \
  "https://analyticsdata.googleapis.com/v1beta/properties/${PROPERTY_ID}:runReport" \
  | jq '.rows[:5]'
```

### runRealtimeReport

```bash
curl -s -X POST \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "dimensions": [{"name": "country"}],
    "metrics": [{"name": "activeUsers"}],
    "limit": 10
  }' \
  "https://analyticsdata.googleapis.com/v1beta/properties/${PROPERTY_ID}:runRealtimeReport" \
  | jq '.rows[:5]'
```

### Listar Propiedades

```bash
curl -s \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  "https://analyticsadmin.googleapis.com/v1beta/accountSummaries" \
  | jq '.accountSummaries[] | {account: .account, properties: [.propertySummaries[].property]}'
```

### Listar Data Streams

```bash
curl -s \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  "https://analyticsadmin.googleapis.com/v1beta/properties/${PROPERTY_ID}/dataStreams" \
  | jq '.dataStreams[] | {name, type, measurementId: .webStreamData.measurementId}'
```

### Measurement Protocol (Validacion)

```bash
MEASUREMENT_ID="G-XXXXXXXXXX"
API_SECRET="your_secret"

curl -s -X POST \
  -H "Content-Type: application/json" \
  -d '{
    "client_id": "test_client_123",
    "events": [{
      "name": "test_event",
      "params": {
        "session_id": "12345",
        "engagement_time_msec": "100"
      }
    }],
    "validation_behavior": "ENFORCE_RECOMMENDATIONS"
  }' \
  "https://www.google-analytics.com/debug/mp/collect?measurement_id=${MEASUREMENT_ID}&api_secret=${API_SECRET}" \
  | jq .
```

---

## Terraform

### Soporte Actual (Muy Limitado)

No existe recurso `google_analytics_property` en el provider oficial de Terraform
(hashicorp/google). Feature request abierto: #16898.

### Lo Que SI Puede Hacer Terraform

```hcl
# Habilitar APIs de GA4
resource "google_project_service" "analytics_data" {
  service = "analyticsdata.googleapis.com"
}

resource "google_project_service" "analytics_admin" {
  service = "analyticsadmin.googleapis.com"
}

# Crear service account para GA4
resource "google_service_account" "ga4" {
  account_id   = "ga4-automation"
  display_name = "GA4 Automation"
}

resource "google_service_account_key" "ga4" {
  service_account_id = google_service_account.ga4.name
}

# BigQuery dataset (para export)
resource "google_bigquery_dataset" "analytics" {
  dataset_id = "analytics_123456789"
  location   = "US"

  access {
    role          = "WRITER"
    user_by_email = google_service_account.ga4.email
  }
}
```

### Patron Recomendado: Terraform + Scripts Admin API

```bash
# 1. Terraform para infraestructura GCP
terraform apply

# 2. Script Python para configuracion GA4
python scripts/setup_ga4_property.py \
  --account-id $GA4_ACCOUNT_ID \
  --display-name "Mi Propiedad" \
  --timezone "America/Mexico_City" \
  --currency "MXN"
```

---

## GitHub Actions — CI/CD

### Reporte Diario Automatizado

```yaml
name: GA4 Daily Report
on:
  schedule:
    - cron: '0 8 * * *'  # 8:00 UTC diario
  workflow_dispatch:

jobs:
  report:
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      contents: read

    steps:
      - uses: actions/checkout@v4

      - uses: google-github-actions/auth@v2
        with:
          workload_identity_provider: ${{ secrets.WIF_PROVIDER }}
          service_account: ${{ secrets.GA4_SERVICE_ACCOUNT }}

      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'

      - run: pip install google-analytics-data google-analytics-admin

      - name: Generar reporte
        run: python scripts/ga4_daily_report.py
        env:
          GA4_PROPERTY_ID: ${{ vars.GA4_PROPERTY_ID }}

      - name: Subir reporte
        uses: actions/upload-artifact@v4
        with:
          name: ga4-report-${{ github.run_number }}
          path: reports/
```

### Validacion de Configuracion GA4

```yaml
name: Validate GA4 Config
on:
  pull_request:
    paths:
      - 'config/ga4/**'

jobs:
  validate:
    runs-on: ubuntu-latest
    permissions:
      id-token: write

    steps:
      - uses: actions/checkout@v4

      - uses: google-github-actions/auth@v2
        with:
          workload_identity_provider: ${{ secrets.WIF_PROVIDER }}
          service_account: ${{ secrets.GA4_SERVICE_ACCOUNT }}

      - run: pip install google-analytics-admin

      - name: Validar configuracion
        run: python scripts/validate_ga4_config.py --dry-run
        env:
          GA4_PROPERTY_ID: ${{ vars.GA4_PROPERTY_ID }}
```

### Deploy de Configuracion GA4

```yaml
name: Deploy GA4 Config
on:
  push:
    branches: [main]
    paths:
      - 'config/ga4/**'

jobs:
  deploy:
    runs-on: ubuntu-latest
    permissions:
      id-token: write

    steps:
      - uses: actions/checkout@v4

      - uses: google-github-actions/auth@v2
        with:
          workload_identity_provider: ${{ secrets.WIF_PROVIDER }}
          service_account: ${{ secrets.GA4_SERVICE_ACCOUNT }}

      - run: pip install google-analytics-admin

      - name: Aplicar configuracion
        run: python scripts/apply_ga4_config.py
        env:
          GA4_PROPERTY_ID: ${{ vars.GA4_PROPERTY_ID }}
```

---

## gcloud CLI — Setup y Auth

No hay comandos `gcloud analytics`, pero gcloud se usa para:

### Habilitar APIs

```bash
gcloud services enable analyticsdata.googleapis.com
gcloud services enable analyticsadmin.googleapis.com
gcloud services enable bigquery.googleapis.com
```

### Crear y Configurar Service Account

```bash
# Crear
gcloud iam service-accounts create ga4-automation \
  --display-name="GA4 Automation"

# Descargar clave
gcloud iam service-accounts keys create key.json \
  --iam-account=ga4-automation@PROJECT.iam.gserviceaccount.com

# Application Default Credentials (desarrollo local)
gcloud auth application-default login \
  --scopes=https://www.googleapis.com/auth/analytics.readonly
```

### Workload Identity Federation

```bash
# Crear pool
gcloud iam workload-identity-pools create ga4-pool \
  --location=global \
  --display-name="GA4 Pool"

# Crear provider para GitHub Actions
gcloud iam workload-identity-pools providers create-oidc github \
  --location=global \
  --workload-identity-pool=ga4-pool \
  --issuer-uri=https://token.actions.githubusercontent.com \
  --attribute-mapping="google.subject=assertion.sub,attribute.repository=assertion.repository"

# Vincular service account
gcloud iam service-accounts add-iam-policy-binding \
  ga4-automation@PROJECT.iam.gserviceaccount.com \
  --role=roles/iam.workloadIdentityUser \
  --member="principalSet://iam.googleapis.com/projects/NUM/locations/global/workloadIdentityPools/ga4-pool/attribute.repository/ORG/REPO"
```

---

## Integraciones ETL

### BigQuery como Hub Central

El patron mas comun es usar BigQuery Export como fuente y conectar herramientas ETL:

```
GA4 → BigQuery Export → dbt/Dataform → Dashboard (Looker, Tableau, etc.)
```

### Looker Studio

- Conector nativo GA4 consume tokens de Data API
- **Recomendado:** Usar conector BigQuery para evitar agotamiento de cuotas
- "Extract Data" feature permite cachear queries

### dbt / Dataform

```sql
-- models/ga4/stg_ga4_events.sql (dbt)
SELECT
  PARSE_DATE('%Y%m%d', event_date) AS event_date,
  event_name,
  user_pseudo_id,
  (SELECT value.string_value FROM UNNEST(event_params) WHERE key = 'page_location') AS page_location,
  (SELECT value.int_value FROM UNNEST(event_params) WHERE key = 'ga_session_id') AS session_id,
  event_timestamp
FROM {{ source('ga4', 'events_*') }}
WHERE _TABLE_SUFFIX >= FORMAT_DATE('%Y%m%d', DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY))
```
