# Pitfalls y Workarounds — Errores Comunes en GA4

## Resumen

El ecosistema GA4 tiene numerosos gotchas documentados por la comunidad que pueden
causar discrepancias de datos, errores silenciosos, y comportamientos inesperados.
Este documento recopila los mas impactantes con sus soluciones.

---

## 1. Discrepancias entre API y UI

### El Problema
Los numeros de la Data API pueden no coincidir con los de la interfaz de GA4.

### Causas

- **La API replica reportes estandar (pre-agregados)**, no Exploraciones
- Agregar dimensiones como `platform` o `deviceCategory` puede causar eventos faltantes vs la UI
- **Sessions que cruzan medianoche** causan doble conteo cuando se incluye la dimension `date`
- **La fila de totales para `sessions`** usa estimacion **HyperLogLog++** — NO es igual a la suma de filas individuales

### Workaround

```python
# Para verificar discrepancias, comparar reporte con y sin dimensiones extra
response_simple = client.run_report(RunReportRequest(
    property=f"properties/{property_id}",
    metrics=[Metric(name="sessions")],
    date_ranges=[DateRange(start_date="7daysAgo", end_date="yesterday")],
))

response_detailed = client.run_report(RunReportRequest(
    property=f"properties/{property_id}",
    dimensions=[Dimension(name="date")],
    metrics=[Metric(name="sessions")],
    date_ranges=[DateRange(start_date="7daysAgo", end_date="yesterday")],
))

total_simple = int(response_simple.rows[0].metric_values[0].value)
total_detailed = sum(int(r.metric_values[0].value) for r in response_detailed.rows)

if total_simple != total_detailed:
    print(f"AVISO: Discrepancia por HyperLogLog++ - "
          f"Total: {total_simple}, Suma filas: {total_detailed}")
```

---

## 2. Cardinalidad y la Fila (other)

### El Problema
Dimensiones con mas de **~50,000 valores unicos** agrupan el excedente en `(other)`.
Esto significa que los datos detallados se pierden en la agregacion de la API.

### Deteccion

```python
response = client.run_report(request)

if response.metadata.data_loss_from_other_row:
    print("AVISO: Datos agrupados en (other) por alta cardinalidad")
    print("Los valores individuales mas alla del top ~50K estan ocultos")
```

### Dimensiones Mas Afectadas

- `pagePath` / `pagePathPlusQueryString` — sitios con muchas URLs unicas
- `transactionId` — alto volumen de transacciones
- `itemName` / `itemId` — catalogos grandes
- `city` — dimension con alta variabilidad natural
- `sessionSourceMedium` — muchas combinaciones de fuente/medio

### Soluciones

1. **BigQuery Export** — UNICA fuente sin limites de cardinalidad
2. **Reducir cardinalidad** — Usar `pagePath` en lugar de `pagePathPlusQueryString`
3. **Filtrar** — Limitar la query a un subconjunto (ej: solo un pais)
4. **Acortar date range** — Menos dias = menos valores unicos
5. **Reportes mas granulares** — Dividir por dimensiones de menor cardinalidad

---

## 3. Data Thresholding

### El Problema
Cuando Google Signals esta habilitado y la identidad de reporting esta en "Observed"
o "Blended", GA4 suprime filas con pocos usuarios para evitar re-identificacion.
Los datos simplemente **desaparecen** del reporte sin aviso claro.

### Deteccion

Comparar metricas con y sin Google Signals:
- Total de usuarios en reporte simple vs reporte con dimension `userGender`
- Si hay diferencia significativa, thresholding esta activo

### Soluciones

1. **Cambiar a identidad "Device-based"** para verificar completitud de datos
   (GA4 Admin → Property Settings → Reporting Identity)
2. **Ampliar date range** — Mas datos = mas probable que se supere el umbral
3. **Reducir dimensiones** — Menos granularidad = filas con mas usuarios
4. **BigQuery Export** — Los datos estan completos (sin thresholding),
   pero tampoco tienen datos modelados

---

## 4. Consent Mode v2 — Impacto en Datos

### El Problema
Obligatorio para EEA desde marzo 2024. El impacto es que la API/UI incluyen
datos **modelados** de usuarios que no dieron consentimiento, pero BigQuery Export **NO**.

### Tabla de Impacto

| Fuente | Datos Observados | Datos Modelados | Total |
|--------|-----------------|----------------|-------|
| GA4 UI | SI | SI | Mas alto |
| Data API | SI | SI | Mas alto |
| BigQuery Export | SI | **NO** | Mas bajo |

### Consecuencias

- Los numeros de BigQuery seran **menores** que los de la UI/API
- En BigQuery, usuarios sin consentimiento tienen `user_pseudo_id` como `null`
- Regiones con alto uso de banners de consentimiento (ej: Alemania) tendran mayor discrepancia

### Parametros Requeridos

```json
{
  "consent": {
    "ad_user_data": "GRANTED",
    "ad_personalization": "GRANTED"
  }
}
```

Sin estos parametros en el Measurement Protocol, se pierden features de advertising en EEA.

---

## 5. Enhanced Conversions — Trade-Off Permanente

### El Problema
Habilitar Enhanced Conversions para GA4 tiene un efecto secundario **permanente e irreversible**:
elimina `user_id` de los exports de BigQuery y puede alterar estructuras de datos.

### Recomendacion

- **Evaluar cuidadosamente** antes de habilitar
- Si ya se depende de `user_id` en BigQuery para joins, NO habilitar
- Si se habilita, usar `user_pseudo_id` como alternativa (menos preciso)

---

## 6. Measurement Protocol — Bugs Conocidos

### 6.1 Eventos con user_id Descartados Silenciosamente

**Descripcion:** Cuando la politica "User-provided data collection" esta acknowledged
en GA4 Admin, eventos con `user_id` pueden ser descartados sin ningun error.

**Impacto:** Eventos enviados correctamente al MP simplemente no aparecen en GA4.

**Workaround:**
1. Testear exhaustivamente despues de acknowledgment
2. Verificar que los eventos aparecen en Realtime
3. Si se detecta el bug, contactar soporte de Google

### 6.2 session_id y engagement_time_msec "Opcionales"

**Descripcion:** Documentados como opcionales pero en la practica son obligatorios.

**Sin estos parametros:**
- Eventos NO aparecen en Realtime
- Atribucion muestra `(not set)`
- Datos pueden no procesarse correctamente

**Solucion:** SIEMPRE incluir ambos:
```python
"params": {
    "session_id": "1234567890",
    "engagement_time_msec": "100",
    # ... otros parametros
}
```

### 6.3 page_location Truncado

**Descripcion:** El parametro `page_location` tiene un limite de **100 caracteres**.
Los query strings largos se truncan silenciosamente.

**Workaround:** Para URLs largas, usar un parametro custom para la parte relevante:
```python
"params": {
    "page_location": url[:100],
    "full_url_hash": hashlib.md5(url.encode()).hexdigest(),
    "utm_campaign": extract_utm(url, "campaign"),
}
```

### 6.4 Backdating Poco Fiable

**Descripcion:** El backdating mas alla de medianoche UTC puede no funcionar de forma
fiable a pesar de la ventana documentada de 72 horas.

**Workaround:** Enviar eventos lo mas pronto posible. Si necesitas backdating fiable,
considerar enviar directamente a BigQuery en lugar de usar MP.

### 6.5 MP Events No Crean Sesiones

**Descripcion:** Los eventos del Measurement Protocol no pueden iniciar una nueva sesion
de usuario por si solos.

**Implicacion:** Si envias un evento con un `session_id` que no existe en tracking
client-side, GA4 crea una sesion "sintetica" con datos limitados.

### 6.6 MP Events No Son Modificados por UI

**Descripcion:** Las reglas de "Modify event" configuradas en la UI de GA4 NO se aplican
a eventos enviados via Measurement Protocol.

---

## 7. Quotas en Looker Studio

### El Problema
Los conectores de GA4 en Looker Studio consumen tokens de Data API del mismo token bucket.
Un dashboard con muchos graficos puede agotar la cuota diaria rapidamente.

### Deteccion

- Right-click en un grafico de Looker Studio → "Google Analytics Token Usage"
- Monitoreando tokens via `returnPropertyQuota: true` en la API

### Soluciones

1. **Usar conector BigQuery** en Looker Studio en lugar del conector GA4
2. **"Extract Data" feature** — Cachea los datos, no hace queries en vivo
3. **Reducir graficos** — Menos graficos = menos queries
4. **Limitar date range** — Date ranges mas cortos consumen menos tokens
5. **Programar extracciones** — Usar scheduled queries en BigQuery

---

## 8. Procesamiento de Datos y Latencia

### Latencia Normal

| Tipo de Datos | Latencia Tipica |
|---------------|----------------|
| Realtime | 0-5 minutos |
| Standard reports (UI) | 4-8 horas |
| Data API | 4-8 horas |
| BigQuery daily export | 24 horas (tabla del dia anterior) |
| BigQuery streaming | Near real-time |
| Late-arriving events | Hasta 3 dias de actualizaciones |

### Implicaciones para Cache

- No cachear datos de hoy por mas de 15 minutos
- Datos de ayer pueden cambiar durante 48 horas
- Datos de hace >48 horas son estables

---

## 9. Custom Dimensions y Metricas

### Limites

| Tipo | Standard | GA360 |
|------|----------|-------|
| Custom dimensions (event-scoped) | 50 | 125 |
| Custom dimensions (user-scoped) | 25 | 100 |
| Custom dimensions (item-scoped) | 10 | 25 |
| Custom metrics | 50 | 125 |

### Gotchas

- Los parametros de evento que NO estan registrados como custom dimensions
  **no estan disponibles** en reportes (ni API ni UI)
- Registrar un parametro como custom dimension NO es retroactivo
  — solo aplica a datos futuros
- `archive` en custom dimensions NO elimina datos historicos,
  solo libera el slot para reusar

---

## 10. Nombres de Eventos Reservados

Los siguientes nombres estan reservados y no deben usarse:

**Reservados para GA4 automatico:**
`first_open`, `first_visit`, `in_app_purchase`, `session_start`,
`user_engagement`, `app_remove`, `app_store_refund`, `app_exception`,
`app_update`, `os_update`

**Prefijos reservados:**
- `ga_` — Reservado para Google Analytics
- `google_` — Reservado para Google
- `firebase_` — Reservado para Firebase

---

## 11. Checklist Pre-Produccion

```
[ ] ¿BigQuery Export habilitado? (no hay backfill retroactivo)
[ ] ¿Data retention a 14 meses? (default es 2 meses)
[ ] ¿returnPropertyQuota: true en todas las queries?
[ ] ¿session_id + engagement_time_msec en todos los eventos MP?
[ ] ¿Validacion con /debug/mp/collect antes de produccion?
[ ] ¿Backoff exponencial implementado para 429/500/503?
[ ] ¿Cache de reportes con TTL apropiado?
[ ] ¿Custom dimensions registradas para todos los parametros necesarios?
[ ] ¿Consent Mode v2 configurado para trafico EEA?
[ ] ¿Enhanced Conversions evaluado? (efecto irreversible en BQ)
[ ] ¿Monitoring de cuotas de tokens activo?
[ ] ¿Dashboard de Looker Studio revisado para consumo de tokens?
```
