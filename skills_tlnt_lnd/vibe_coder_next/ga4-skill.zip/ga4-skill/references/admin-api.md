# Admin API v1 — Configuracion Completa de Propiedades

## Resumen

La **Admin API** (`analyticsadmin.googleapis.com`) proporciona CRUD completo sobre la
configuracion de propiedades GA4: cuentas, data streams, dimensiones/metricas personalizadas,
key events, enlaces a BigQuery/Firebase/Google Ads, permisos de usuarios y mas.

Existen dos versiones simultaneas:

| Version | Superficie | Estabilidad |
|---------|-----------|-------------|
| **v1beta** | Reducida (~15 recursos) | Estable, sin breaking changes |
| **v1alpha** | Completa (~35+ recursos) | Puede romper sin previo aviso |

**Scopes OAuth requeridos:**

| Scope | Uso |
|-------|-----|
| `analytics.edit` | Crear/modificar propiedades, streams, dimensiones, metricas, key events |
| `analytics.readonly` | Lecturas de configuracion |
| `analytics.manage.users` | Crear/modificar/eliminar access bindings (permisos) |
| `analytics.manage.users.readonly` | Leer access bindings |
| `analytics.provision` | Crear cuentas (provisionAccountTicket) |

**Endpoint base:** `https://analyticsadmin.googleapis.com`

---

## Mapa Completo de Recursos

### v1beta (Estable)

Recursos disponibles con garantia de estabilidad. Recomendados para produccion.

#### Accounts

| Metodo | Ruta | Descripcion |
|--------|------|-------------|
| `list` | `GET /v1beta/accounts` | Listar cuentas accesibles |
| `get` | `GET /v1beta/accounts/{accountId}` | Obtener cuenta por ID |
| `delete` | `DELETE /v1beta/accounts/{accountId}` | Eliminar cuenta (soft delete, 35 dias recuperable) |
| `patch` | `PATCH /v1beta/accounts/{accountId}` | Actualizar nombre/pais |
| `provisionAccountTicket` | `POST /v1beta/accounts:provisionAccountTicket` | Crear ticket para nueva cuenta |
| `searchChangeHistoryEvents` | `POST /v1beta/accounts/{accountId}:searchChangeHistoryEvents` | Buscar historial de cambios |
| `runAccessReport` | `POST /v1beta/accounts/{accountId}:runAccessReport` | Reporte de accesos a datos |

#### AccountSummaries

| Metodo | Ruta | Descripcion |
|--------|------|-------------|
| `list` | `GET /v1beta/accountSummaries` | Listar resumen de todas las cuentas y propiedades |

#### Properties

| Metodo | Ruta | Descripcion |
|--------|------|-------------|
| `create` | `POST /v1beta/properties` | Crear propiedad GA4 |
| `get` | `GET /v1beta/properties/{propertyId}` | Obtener propiedad |
| `list` | `GET /v1beta/properties` | Listar propiedades (filtro por account) |
| `patch` | `PATCH /v1beta/properties/{propertyId}` | Actualizar propiedad |
| `delete` | `DELETE /v1beta/properties/{propertyId}` | Soft delete (35 dias recuperable) |
| `getDataRetentionSettings` | `GET /v1beta/properties/{propertyId}/dataRetentionSettings` | Leer retencion de datos |
| `updateDataRetentionSettings` | `PATCH /v1beta/properties/{propertyId}/dataRetentionSettings` | Configurar retencion |
| `acknowledgeUserDataCollection` | `POST /v1beta/properties/{propertyId}:acknowledgeUserDataCollection` | Aceptar terminos de recoleccion |
| `runAccessReport` | `POST /v1beta/properties/{propertyId}:runAccessReport` | Reporte de accesos |

#### DataStreams

| Metodo | Ruta | Descripcion |
|--------|------|-------------|
| `create` | `POST /v1beta/properties/{propertyId}/dataStreams` | Crear stream (web/iOS/Android) |
| `get` | `GET /v1beta/properties/{propertyId}/dataStreams/{streamId}` | Obtener stream |
| `list` | `GET /v1beta/properties/{propertyId}/dataStreams` | Listar streams |
| `patch` | `PATCH /v1beta/properties/{propertyId}/dataStreams/{streamId}` | Actualizar stream |
| `delete` | `DELETE /v1beta/properties/{propertyId}/dataStreams/{streamId}` | Eliminar stream |

#### CustomDimensions

| Metodo | Ruta | Descripcion |
|--------|------|-------------|
| `create` | `POST /v1beta/properties/{propertyId}/customDimensions` | Crear dimension personalizada |
| `get` | `GET /v1beta/properties/{propertyId}/customDimensions/{customDimensionId}` | Obtener dimension |
| `list` | `GET /v1beta/properties/{propertyId}/customDimensions` | Listar dimensiones |
| `patch` | `PATCH /v1beta/properties/{propertyId}/customDimensions/{customDimensionId}` | Actualizar dimension |
| `archive` | `POST /v1beta/properties/{propertyId}/customDimensions/{customDimensionId}:archive` | Archivar dimension |

#### CustomMetrics

| Metodo | Ruta | Descripcion |
|--------|------|-------------|
| `create` | `POST /v1beta/properties/{propertyId}/customMetrics` | Crear metrica personalizada |
| `get` | `GET /v1beta/properties/{propertyId}/customMetrics/{customMetricId}` | Obtener metrica |
| `list` | `GET /v1beta/properties/{propertyId}/customMetrics` | Listar metricas |
| `patch` | `PATCH /v1beta/properties/{propertyId}/customMetrics/{customMetricId}` | Actualizar metrica |
| `archive` | `POST /v1beta/properties/{propertyId}/customMetrics/{customMetricId}:archive` | Archivar metrica |

#### KeyEvents (reemplaza ConversionEvents deprecados)

| Metodo | Ruta | Descripcion |
|--------|------|-------------|
| `create` | `POST /v1beta/properties/{propertyId}/keyEvents` | Crear key event |
| `get` | `GET /v1beta/properties/{propertyId}/keyEvents/{keyEventId}` | Obtener key event |
| `list` | `GET /v1beta/properties/{propertyId}/keyEvents` | Listar key events |
| `patch` | `PATCH /v1beta/properties/{propertyId}/keyEvents/{keyEventId}` | Actualizar key event |
| `delete` | `DELETE /v1beta/properties/{propertyId}/keyEvents/{keyEventId}` | Eliminar key event |

> **Nota:** `ConversionEvents` fue deprecado en 2024. Usar `KeyEvents` en todo codigo nuevo.

#### MeasurementProtocolSecrets

| Metodo | Ruta | Descripcion |
|--------|------|-------------|
| `create` | `POST /v1beta/properties/{propertyId}/dataStreams/{streamId}/measurementProtocolSecrets` | Crear secret |
| `get` | `GET /v1beta/properties/{propertyId}/dataStreams/{streamId}/measurementProtocolSecrets/{secretId}` | Obtener secret |
| `list` | `GET /v1beta/properties/{propertyId}/dataStreams/{streamId}/measurementProtocolSecrets` | Listar secrets |
| `patch` | `PATCH /v1beta/properties/{propertyId}/dataStreams/{streamId}/measurementProtocolSecrets/{secretId}` | Actualizar secret |
| `delete` | `DELETE /v1beta/properties/{propertyId}/dataStreams/{streamId}/measurementProtocolSecrets/{secretId}` | Eliminar secret |

#### FirebaseLinks

| Metodo | Ruta | Descripcion |
|--------|------|-------------|
| `create` | `POST /v1beta/properties/{propertyId}/firebaseLinks` | Crear enlace Firebase |
| `delete` | `DELETE /v1beta/properties/{propertyId}/firebaseLinks/{firebaseLinkId}` | Eliminar enlace |
| `list` | `GET /v1beta/properties/{propertyId}/firebaseLinks` | Listar enlaces |

#### GoogleAdsLinks

| Metodo | Ruta | Descripcion |
|--------|------|-------------|
| `create` | `POST /v1beta/properties/{propertyId}/googleAdsLinks` | Crear enlace Google Ads |
| `delete` | `DELETE /v1beta/properties/{propertyId}/googleAdsLinks/{googleAdsLinkId}` | Eliminar enlace |
| `list` | `GET /v1beta/properties/{propertyId}/googleAdsLinks` | Listar enlaces |
| `patch` | `PATCH /v1beta/properties/{propertyId}/googleAdsLinks/{googleAdsLinkId}` | Actualizar enlace |

---

### v1alpha (Completa)

Incluye todo lo de v1beta mas los siguientes recursos adicionales. Usar solo cuando se
necesite funcionalidad que no existe en v1beta.

#### Audiences

| Metodo | Descripcion |
|--------|-------------|
| `create` | Crear audiencia con filtros de eventos/usuarios |
| `get` | Obtener audiencia por nombre de recurso |
| `list` | Listar audiencias de la propiedad |
| `patch` | Actualizar audiencia (solo displayName y description) |
| `archive` | Archivar audiencia (no se puede recuperar) |

#### BigQueryLinks

| Metodo | Descripcion |
|--------|-------------|
| `create` | Crear enlace a BigQuery (exportacion continua) |
| `get` | Obtener configuracion del enlace |
| `list` | Listar enlaces BigQuery |
| `patch` | Actualizar configuracion de exportacion |
| `delete` | Eliminar enlace |

#### ChannelGroups

| Metodo | Descripcion |
|--------|-------------|
| `create` | Crear grupo de canales personalizado |
| `get` | Obtener grupo de canales |
| `list` | Listar grupos de canales |
| `patch` | Actualizar reglas del grupo |
| `delete` | Eliminar grupo de canales |

#### ExpandedDataSets

| Metodo | Descripcion |
|--------|-------------|
| `create` | Crear dataset expandido (datos historicos accesibles por mas tiempo) |
| `get` | Obtener dataset expandido |
| `list` | Listar datasets expandidos |
| `patch` | Actualizar dataset |
| `delete` | Eliminar dataset |

#### CalculatedMetrics

| Metodo | Descripcion |
|--------|-------------|
| `create` | Crear metrica calculada (formula sobre metricas existentes) |
| `get` | Obtener metrica calculada |
| `list` | Listar metricas calculadas |
| `patch` | Actualizar formula/nombre |
| `delete` | Eliminar metrica calculada |

#### AccessBindings (Gestion de Usuarios)

| Metodo | Descripcion |
|--------|-------------|
| `create` | Asignar rol a usuario en cuenta/propiedad |
| `get` | Obtener binding de acceso |
| `list` | Listar todos los bindings |
| `patch` | Cambiar rol de usuario |
| `delete` | Revocar acceso de usuario |
| `batchCreate` | Crear multiples bindings en lote |
| `batchUpdate` | Actualizar multiples bindings en lote |
| `batchDelete` | Eliminar multiples bindings en lote |
| `batchGet` | Obtener multiples bindings en lote |

**Roles predefinidos:**

| Rol | Constante | Descripcion |
|-----|-----------|-------------|
| Viewer | `predefinedRoles/viewer` | Solo lectura de reportes |
| Analyst | `predefinedRoles/analyst` | Crear/editar exploraciones, compartir assets |
| Editor | `predefinedRoles/editor` | Editar configuracion (no usuarios) |
| Admin | `predefinedRoles/admin` | Acceso completo excepto account-level |
| No Cost Data | `predefinedRoles/no-cost-data` | Restriccion: sin datos de costos |
| No Revenue Data | `predefinedRoles/no-revenue-data` | Restriccion: sin datos de ingresos |

#### EventCreateRules / EventEditRules (por DataStream)

| Metodo | Descripcion |
|--------|-------------|
| `create` | Crear regla para generar/modificar eventos |
| `get` | Obtener regla |
| `list` | Listar reglas del stream |
| `patch` | Actualizar condiciones/acciones |
| `delete` | Eliminar regla |

#### Otros Recursos v1alpha

| Recurso | Descripcion |
|---------|-------------|
| `AdSenseLinks` | Enlace a AdSense para datos de ingresos |
| `DisplayVideo360AdvertiserLinks` | Enlace a DV360 |
| `SearchAds360Links` | Enlace a SA360 |
| `ReportingDataAnnotations` | Anotaciones en reportes (nuevo 2025) |
| `RollupPropertySourceLinks` | Fuentes para rollup properties |
| `SubpropertyEventFilters` | Filtros de eventos para subpropiedades |
| `SKAdNetworkConversionValueSchema` | Esquema SKAdNetwork para iOS |
| `getAttributionSettings` / `updateAttributionSettings` | Modelo de atribucion |
| `getGoogleSignalsSettings` / `updateGoogleSignalsSettings` | Configuracion Google Signals |

---

## Ejemplos Node.js — Automatizacion de Setup

Todos los ejemplos usan `@google-analytics/admin` v9.x con TypeScript.

### 1. Crear Propiedad GA4

```typescript
import { AnalyticsAdminServiceClient } from "@google-analytics/admin";

const client = new AnalyticsAdminServiceClient();

async function crearPropiedad(accountId: string) {
  const [property] = await client.createProperty({
    property: {
      parent: `accounts/${accountId}`,
      displayName: "Curso Online - Produccion",
      timeZone: "America/Mexico_City",
      currencyCode: "MXN",
      industryCategory: "EDUCATION",
    },
  });

  console.log(`Propiedad creada: ${property.name}`);
  // property.name = "properties/123456789"
  return property;
}
```

**Categorias de industria validas:** `ARTS_AND_ENTERTAINMENT`, `AUTOMOTIVE`, `BEAUTY_AND_FITNESS`,
`BOOKS_AND_LITERATURE`, `BUSINESS_AND_INDUSTRIAL_MARKETS`, `COMPUTERS_AND_ELECTRONICS`,
`EDUCATION`, `FINANCE`, `FOOD_AND_DRINK`, `GAMES`, `HEALTHCARE`, `HOBBIES_AND_LEISURE`,
`HOME_AND_GARDEN`, `INTERNET_AND_TELECOM`, `JOBS_AND_EDUCATION`, `LAW_AND_GOVERNMENT`,
`NEWS`, `ONLINE_COMMUNITIES`, `PEOPLE_AND_SOCIETY`, `PETS_AND_ANIMALS`, `REAL_ESTATE`,
`REFERENCE`, `SCIENCE`, `SHOPPING`, `SPORTS`, `TECHNOLOGY`, `TRAVEL`.

### 2. Crear Web Data Stream

```typescript
async function crearWebStream(propertyId: string) {
  const [stream] = await client.createDataStream({
    parent: `properties/${propertyId}`,
    dataStream: {
      type: "WEB_DATA_STREAM",
      displayName: "Landing Curso Online",
      webStreamData: {
        defaultUri: "https://curso-online.example.com",
      },
    },
  });

  console.log(`Stream creado: ${stream.name}`);
  console.log(`Measurement ID: ${stream.webStreamData?.measurementId}`);
  // measurementId = "G-XXXXXXXXXX" — este va en gtag.js
  return stream;
}
```

> **Tipos de stream:** `WEB_DATA_STREAM`, `ANDROID_APP_DATA_STREAM`, `IOS_APP_DATA_STREAM`.

### 3. Crear Custom Dimension

```typescript
async function crearCustomDimension(propertyId: string) {
  const [dimension] = await client.createCustomDimension({
    parent: `properties/${propertyId}`,
    customDimension: {
      parameterName: "plan_type",
      displayName: "Tipo de Plan",
      description: "Plan adquirido por el usuario (online, presencial, vip, platino)",
      scope: "EVENT",
      // disallowAdsPersonalization: false, // Opcional
    },
  });

  console.log(`Dimension creada: ${dimension.name}`);
  return dimension;
}
```

**Scopes validos:**

| Scope | Descripcion | Limite |
|-------|-------------|--------|
| `EVENT` | Valor por evento individual | 50 event-scoped |
| `USER` | Valor persistente por usuario | 25 user-scoped |
| `ITEM` | Valor por item de ecommerce | 10 item-scoped |

### 4. Crear Custom Metric

```typescript
async function crearCustomMetric(propertyId: string) {
  const [metric] = await client.createCustomMetric({
    parent: `properties/${propertyId}`,
    customMetric: {
      parameterName: "purchase_value_mxn",
      displayName: "Valor de Compra (MXN)",
      description: "Monto de la compra en pesos mexicanos",
      scope: "EVENT",
      measurementUnit: "CURRENCY",
      // restrictedMetricType: [] // COST_DATA, REVENUE_DATA
    },
  });

  console.log(`Metrica creada: ${metric.name}`);
  return metric;
}
```

**Unidades de medida (`measurementUnit`):**

| Valor | Descripcion |
|-------|-------------|
| `STANDARD` | Numero generico (entero o decimal) |
| `CURRENCY` | Monetario (usa currencyCode de la propiedad) |
| `FEET` | Distancia en pies |
| `MILES` | Distancia en millas |
| `METERS` | Distancia en metros |
| `KILOMETERS` | Distancia en kilometros |
| `MILLISECONDS` | Tiempo en milisegundos |
| `SECONDS` | Tiempo en segundos |
| `MINUTES` | Tiempo en minutos |
| `HOURS` | Tiempo en horas |

### 5. Crear Key Event

```typescript
async function crearKeyEvent(propertyId: string) {
  const [keyEvent] = await client.createKeyEvent({
    parent: `properties/${propertyId}`,
    keyEvent: {
      eventName: "purchase",
      countingMethod: "ONCE_PER_EVENT",
      // defaultValue: { numericValue: 0, currencyCode: "MXN" }, // Opcional
    },
  });

  console.log(`Key event creado: ${keyEvent.name}`);
  return keyEvent;
}

// Key events tipicos para un funnel de curso
const keyEvents = [
  { eventName: "generate_lead", countingMethod: "ONCE_PER_EVENT" as const },
  { eventName: "begin_checkout", countingMethod: "ONCE_PER_EVENT" as const },
  { eventName: "purchase", countingMethod: "ONCE_PER_EVENT" as const },
  { eventName: "sign_up", countingMethod: "ONCE_PER_SESSION" as const },
];
```

**Metodos de conteo:**

| Valor | Descripcion |
|-------|-------------|
| `ONCE_PER_EVENT` | Cada ocurrencia cuenta como conversion |
| `ONCE_PER_SESSION` | Solo la primera ocurrencia por sesion cuenta |

### 6. Crear BigQuery Link

```typescript
// Solo disponible en v1alpha
import { AnalyticsAdminServiceClient } from "@google-analytics/admin";

const alphaClient = new AnalyticsAdminServiceClient({
  apiEndpoint: "analyticsadmin.googleapis.com",
});

async function crearBigQueryLink(propertyId: string) {
  const [link] = await alphaClient.createBigQueryLink({
    parent: `properties/${propertyId}`,
    bigqueryLink: {
      project: "mi-analytics",
      dailyExportEnabled: true,
      streamingExportEnabled: true,
      includeAdvertisingId: false,
      freshDailyExportEnabled: true,
      exportStreams: [
        `properties/${propertyId}/dataStreams/1234567`,
      ],
    },
  });

  console.log(`BigQuery link creado: ${link.name}`);
  return link;
}
```

> **Requisitos previos:** El proyecto de BigQuery debe existir, la cuenta de servicio de GA4
> debe tener rol `BigQuery Data Editor` en el proyecto destino.

### 7. Crear Measurement Protocol Secret

```typescript
async function crearMPSecret(propertyId: string, streamId: string) {
  const [secret] = await client.createMeasurementProtocolSecret({
    parent: `properties/${propertyId}/dataStreams/${streamId}`,
    measurementProtocolSecret: {
      displayName: "Backend Convex - Eventos servidor",
    },
  });

  console.log(`MP Secret creado: ${secret.name}`);
  console.log(`Secret Value: ${secret.secretValue}`);
  // secretValue = "aBcDeFgHiJkL" — guardar seguro, no se puede releer
  return secret;
}
```

> **Importante:** `secretValue` solo se muestra al crear. Guardar inmediatamente como
> variable de entorno. Si se pierde, hay que crear uno nuevo.

### 8. Gestionar Usuarios (Access Bindings)

```typescript
// Solo disponible en v1alpha
async function asignarRolUsuario(propertyId: string) {
  // Crear un access binding individual
  const [binding] = await alphaClient.createAccessBinding({
    parent: `properties/${propertyId}`,
    accessBinding: {
      user: "analista@example.com",
      roles: ["predefinedRoles/analyst"],
    },
  });

  console.log(`Acceso asignado: ${binding.name}`);
  return binding;
}

async function asignarRolesEnLote(propertyId: string) {
  // Crear multiples access bindings en batch
  const [response] = await alphaClient.batchCreateAccessBindings({
    parent: `properties/${propertyId}`,
    requests: [
      {
        parent: `properties/${propertyId}`,
        accessBinding: {
          user: "editor1@example.com",
          roles: ["predefinedRoles/editor"],
        },
      },
      {
        parent: `properties/${propertyId}`,
        accessBinding: {
          user: "viewer1@example.com",
          roles: ["predefinedRoles/viewer"],
        },
      },
      {
        parent: `properties/${propertyId}`,
        accessBinding: {
          user: "admin@example.com",
          roles: ["predefinedRoles/admin"],
        },
      },
    ],
  });

  console.log(`${response.accessBindings.length} accesos creados`);
  return response;
}
```

### 9. Data Retention Settings

```typescript
async function configurarRetencion(propertyId: string) {
  const [settings] = await client.updateDataRetentionSettings({
    dataRetentionSettings: {
      name: `properties/${propertyId}/dataRetentionSettings`,
      eventDataRetention: "FOURTEEN_MONTHS",
      resetUserDataOnNewActivity: true,
    },
    updateMask: {
      paths: ["event_data_retention", "reset_user_data_on_new_activity"],
    },
  });

  console.log(`Retencion: ${settings.eventDataRetention}`);
  return settings;
}
```

**Valores de retencion (`eventDataRetention`):**

| Valor | Descripcion |
|-------|-------------|
| `TWO_MONTHS` | 2 meses (por defecto en propiedades gratuitas) |
| `FOURTEEN_MONTHS` | 14 meses (maximo en propiedades gratuitas) |
| `TWENTY_FIVE_MONTHS` | 25 meses (solo GA4 360) |
| `THIRTY_EIGHT_MONTHS` | 38 meses (solo GA4 360) |
| `FIFTY_MONTHS` | 50 meses (solo GA4 360) |

### 10. Listar Account Summaries

```typescript
async function listarCuentas() {
  const summaries: any[] = [];
  const iterable = client.listAccountSummariesAsync({});

  for await (const summary of iterable) {
    console.log(`Cuenta: ${summary.displayName} (${summary.account})`);

    for (const prop of summary.propertySummaries || []) {
      console.log(`  Propiedad: ${prop.displayName} (${prop.property})`);
    }

    summaries.push(summary);
  }

  return summaries;
}
```

> **Paginacion:** `listAccountSummariesAsync` maneja paginacion automaticamente
> con el iterador async. Para control manual, usar `listAccountSummaries` con `pageToken`.

---

## Ejemplos Python — Automatizacion de Setup

Todos los ejemplos usan `google-analytics-admin` v0.27.0 con las clases de v1alpha
(que incluyen toda la funcionalidad de v1beta).

```python
from google.analytics.admin_v1alpha import AnalyticsAdminServiceClient
from google.analytics.admin_v1alpha.types import (
    Property,
    DataStream,
    WebStreamData,
    CustomDimension,
    CustomMetric,
    KeyEvent,
    BigQueryLink,
    MeasurementProtocolSecret,
    AccessBinding,
    DataRetentionSettings,
)
```

### 1. Crear Propiedad GA4

```python
def crear_propiedad(account_id: str) -> Property:
    client = AnalyticsAdminServiceClient()

    property = client.create_property(
        property=Property(
            parent=f"accounts/{account_id}",
            display_name="Curso Online - Produccion",
            time_zone="America/Mexico_City",
            currency_code="MXN",
            industry_category="EDUCATION",
        )
    )

    print(f"Propiedad creada: {property.name}")
    return property
```

### 2. Crear Web Data Stream

```python
def crear_web_stream(property_id: str) -> DataStream:
    client = AnalyticsAdminServiceClient()

    stream = client.create_data_stream(
        parent=f"properties/{property_id}",
        data_stream=DataStream(
            type_=DataStream.DataStreamType.WEB_DATA_STREAM,
            display_name="Landing Curso Online",
            web_stream_data=WebStreamData(
                default_uri="https://curso-online.example.com",
            ),
        ),
    )

    print(f"Stream creado: {stream.name}")
    print(f"Measurement ID: {stream.web_stream_data.measurement_id}")
    return stream
```

### 3. Crear Custom Dimension

```python
def crear_custom_dimension(property_id: str) -> CustomDimension:
    client = AnalyticsAdminServiceClient()

    dimension = client.create_custom_dimension(
        parent=f"properties/{property_id}",
        custom_dimension=CustomDimension(
            parameter_name="plan_type",
            display_name="Tipo de Plan",
            description="Plan adquirido (online, presencial, vip, platino)",
            scope=CustomDimension.DimensionScope.EVENT,
        ),
    )

    print(f"Dimension creada: {dimension.name}")
    return dimension
```

### 4. Crear Custom Metric

```python
def crear_custom_metric(property_id: str) -> CustomMetric:
    client = AnalyticsAdminServiceClient()

    metric = client.create_custom_metric(
        parent=f"properties/{property_id}",
        custom_metric=CustomMetric(
            parameter_name="purchase_value_mxn",
            display_name="Valor de Compra (MXN)",
            description="Monto de la compra en pesos mexicanos",
            scope=CustomMetric.MetricScope.EVENT,
            measurement_unit=CustomMetric.MeasurementUnit.CURRENCY,
        ),
    )

    print(f"Metrica creada: {metric.name}")
    return metric
```

### 5. Crear Key Event

```python
def crear_key_event(property_id: str) -> KeyEvent:
    client = AnalyticsAdminServiceClient()

    key_event = client.create_key_event(
        parent=f"properties/{property_id}",
        key_event=KeyEvent(
            event_name="purchase",
            counting_method=KeyEvent.CountingMethod.ONCE_PER_EVENT,
        ),
    )

    print(f"Key event creado: {key_event.name}")
    return key_event


# Crear multiples key events para funnel
def crear_key_events_funnel(property_id: str) -> list[KeyEvent]:
    client = AnalyticsAdminServiceClient()
    eventos = [
        ("generate_lead", KeyEvent.CountingMethod.ONCE_PER_EVENT),
        ("begin_checkout", KeyEvent.CountingMethod.ONCE_PER_EVENT),
        ("purchase", KeyEvent.CountingMethod.ONCE_PER_EVENT),
        ("sign_up", KeyEvent.CountingMethod.ONCE_PER_SESSION),
    ]

    creados = []
    for event_name, counting in eventos:
        ke = client.create_key_event(
            parent=f"properties/{property_id}",
            key_event=KeyEvent(
                event_name=event_name,
                counting_method=counting,
            ),
        )
        creados.append(ke)
        print(f"  Key event: {event_name}")

    return creados
```

### 6. Crear BigQuery Link

```python
def crear_bigquery_link(property_id: str, stream_id: str) -> BigQueryLink:
    client = AnalyticsAdminServiceClient()

    link = client.create_big_query_link(
        parent=f"properties/{property_id}",
        bigquery_link=BigQueryLink(
            project="mi-analytics",
            daily_export_enabled=True,
            streaming_export_enabled=True,
            include_advertising_id=False,
            fresh_daily_export_enabled=True,
            export_streams=[
                f"properties/{property_id}/dataStreams/{stream_id}",
            ],
        ),
    )

    print(f"BigQuery link creado: {link.name}")
    return link
```

### 7. Crear Measurement Protocol Secret

```python
def crear_mp_secret(property_id: str, stream_id: str) -> MeasurementProtocolSecret:
    client = AnalyticsAdminServiceClient()

    secret = client.create_measurement_protocol_secret(
        parent=f"properties/{property_id}/dataStreams/{stream_id}",
        measurement_protocol_secret=MeasurementProtocolSecret(
            display_name="Backend Convex - Eventos servidor",
        ),
    )

    print(f"MP Secret creado: {secret.name}")
    print(f"Secret Value: {secret.secret_value}")
    return secret
```

### 8. Gestionar Usuarios (Access Bindings)

```python
def asignar_rol_usuario(property_id: str) -> AccessBinding:
    client = AnalyticsAdminServiceClient()

    binding = client.create_access_binding(
        parent=f"properties/{property_id}",
        access_binding=AccessBinding(
            user="analista@example.com",
            roles=["predefinedRoles/analyst"],
        ),
    )

    print(f"Acceso asignado: {binding.name}")
    return binding


def asignar_roles_en_lote(property_id: str) -> list[AccessBinding]:
    from google.analytics.admin_v1alpha.types import (
        BatchCreateAccessBindingsRequest,
        CreateAccessBindingRequest,
    )

    client = AnalyticsAdminServiceClient()

    response = client.batch_create_access_bindings(
        request=BatchCreateAccessBindingsRequest(
            parent=f"properties/{property_id}",
            requests=[
                CreateAccessBindingRequest(
                    parent=f"properties/{property_id}",
                    access_binding=AccessBinding(
                        user="editor1@example.com",
                        roles=["predefinedRoles/editor"],
                    ),
                ),
                CreateAccessBindingRequest(
                    parent=f"properties/{property_id}",
                    access_binding=AccessBinding(
                        user="viewer1@example.com",
                        roles=["predefinedRoles/viewer"],
                    ),
                ),
                CreateAccessBindingRequest(
                    parent=f"properties/{property_id}",
                    access_binding=AccessBinding(
                        user="admin@example.com",
                        roles=["predefinedRoles/admin"],
                    ),
                ),
            ],
        )
    )

    print(f"{len(response.access_bindings)} accesos creados")
    return list(response.access_bindings)
```

### 9. Data Retention Settings

```python
from google.protobuf.field_mask_pb2 import FieldMask

def configurar_retencion(property_id: str) -> DataRetentionSettings:
    client = AnalyticsAdminServiceClient()

    settings = client.update_data_retention_settings(
        data_retention_settings=DataRetentionSettings(
            name=f"properties/{property_id}/dataRetentionSettings",
            event_data_retention=DataRetentionSettings.RetentionDuration.FOURTEEN_MONTHS,
            reset_user_data_on_new_activity=True,
        ),
        update_mask=FieldMask(
            paths=["event_data_retention", "reset_user_data_on_new_activity"]
        ),
    )

    print(f"Retencion: {settings.event_data_retention}")
    return settings
```

### 10. Listar Account Summaries

```python
def listar_cuentas():
    client = AnalyticsAdminServiceClient()

    resultados = []
    for summary in client.list_account_summaries():
        print(f"Cuenta: {summary.display_name} ({summary.account})")

        for prop in summary.property_summaries:
            print(f"  Propiedad: {prop.display_name} ({prop.property}")

        resultados.append(summary)

    return resultados
```

---

## Event Create Rules y Event Edit Rules

Permiten crear o modificar eventos directamente desde la configuracion de GA4, sin necesidad
de modificar codigo en el sitio web ni en GTM.

### Event Create Rules

Crean un **nuevo evento** cuando un evento existente cumple ciertas condiciones.

```typescript
// Crear regla: cuando "page_view" tiene page_location que contiene "/gracias-",
// generar un nuevo evento "conversion_thank_you"
async function crearEventCreateRule(propertyId: string, streamId: string) {
  const [rule] = await alphaClient.createEventCreateRule({
    parent: `properties/${propertyId}/dataStreams/${streamId}`,
    eventCreateRule: {
      destinationEvent: "conversion_thank_you",
      eventConditions: [
        {
          field: "event_name",
          comparisonType: "EQUALS",
          value: "page_view",
        },
        {
          field: "page_location",
          comparisonType: "CONTAINS",
          value: "/gracias-",
        },
      ],
      sourceCopyParameters: true,
      parameterMutations: [
        {
          parameter: "conversion_type",
          parameterValue: "thank_you_page",
        },
      ],
    },
  });

  console.log(`Regla creada: ${rule.name}`);
  return rule;
}
```

### Event Edit Rules

Modifican los **parametros de un evento existente** sin crear uno nuevo.

```typescript
// Editar eventos "purchase": agregar parametro "currency_original" con valor "MXN"
async function crearEventEditRule(propertyId: string, streamId: string) {
  const [rule] = await alphaClient.createEventEditRule({
    parent: `properties/${propertyId}/dataStreams/${streamId}`,
    eventEditRule: {
      displayName: "Agregar moneda original a purchase",
      eventConditions: [
        {
          field: "event_name",
          comparisonType: "EQUALS",
          value: "purchase",
        },
      ],
      parameterMutations: [
        {
          parameter: "currency_original",
          parameterValue: "MXN",
        },
      ],
    },
  });

  console.log(`Regla de edicion creada: ${rule.name}`);
  return rule;
}
```

**Tipos de comparacion (`comparisonType`):**
`EQUALS`, `CONTAINS`, `STARTS_WITH`, `ENDS_WITH`, `GREATER_THAN`, `LESS_THAN`,
`EQUALS_CASE_INSENSITIVE`, `CONTAINS_CASE_INSENSITIVE`, `STARTS_WITH_CASE_INSENSITIVE`,
`ENDS_WITH_CASE_INSENSITIVE`, `REGULAR_EXPRESSION`, `REGULAR_EXPRESSION_CASE_INSENSITIVE`.

> **Orden de ejecucion:** Event Edit Rules se aplican primero, luego Event Create Rules.
> Si una Edit Rule cambia el `event_name`, las Create Rules evaluan el nombre modificado.

---

## Reporting Data Annotations (Nuevo 2025)

Permiten agregar anotaciones textuales a fechas especificas en los reportes de GA4.
Utiles para marcar deploys, campanas, cambios de configuracion u otros eventos relevantes.

**Limites:** Hasta 1,000 anotaciones por propiedad.

```typescript
// Solo v1alpha
async function crearAnotacion(propertyId: string) {
  const [annotation] = await alphaClient.createReportingDataAnnotation({
    parent: `properties/${propertyId}`,
    reportingDataAnnotation: {
      title: "Lanzamiento campaña Meta Ads - Curso Online",
      description: "Inicio de campaña de conversion en Facebook/Instagram para plan VIP",
      annotationDate: {
        year: 2026,
        month: 3,
        day: 1,
      },
      color: "BLUE",
      systemAnnotationType: "USER_CREATED",
    },
  });

  console.log(`Anotacion creada: ${annotation.name}`);
  return annotation;
}

// Listar anotaciones existentes
async function listarAnotaciones(propertyId: string) {
  const iterable = alphaClient.listReportingDataAnnotationsAsync({
    parent: `properties/${propertyId}`,
  });

  for await (const annotation of iterable) {
    const fecha = annotation.annotationDate;
    console.log(
      `[${fecha?.year}-${fecha?.month}-${fecha?.day}] ${annotation.title}`
    );
  }
}
```

**Colores disponibles:** `BLUE`, `GREEN`, `YELLOW`, `ORANGE`, `RED`, `PURPLE`, `BROWN`, `GRAY`.

```python
# Equivalente en Python
from google.analytics.admin_v1alpha.types import ReportingDataAnnotation
from google.type import date_pb2

def crear_anotacion(property_id: str) -> ReportingDataAnnotation:
    client = AnalyticsAdminServiceClient()

    annotation = client.create_reporting_data_annotation(
        parent=f"properties/{property_id}",
        reporting_data_annotation=ReportingDataAnnotation(
            title="Lanzamiento campaña Meta Ads - Curso Online",
            description="Inicio de campaña de conversion para plan VIP",
            annotation_date=date_pb2.Date(year=2026, month=3, day=1),
            color=ReportingDataAnnotation.Color.BLUE,
        ),
    )

    print(f"Anotacion creada: {annotation.name}")
    return annotation
```

---

## Recetas Comunes

### Receta 1: Setup Completo de Propiedad Nueva

Script que automatiza la creacion de una propiedad GA4 completa con stream, dimensiones
personalizadas, key events y enlace a BigQuery.

```typescript
import { AnalyticsAdminServiceClient } from "@google-analytics/admin";

const client = new AnalyticsAdminServiceClient();

async function setupCompletoPropiedad(accountId: string) {
  console.log("=== SETUP COMPLETO DE PROPIEDAD GA4 ===\n");

  // 1. Crear propiedad
  const [property] = await client.createProperty({
    property: {
      parent: `accounts/${accountId}`,
      displayName: "Curso Online - Produccion",
      timeZone: "America/Mexico_City",
      currencyCode: "MXN",
      industryCategory: "EDUCATION",
    },
  });
  const propertyId = property.name!.split("/")[1];
  console.log(`1. Propiedad creada: ${property.name}`);

  // 2. Crear web data stream
  const [stream] = await client.createDataStream({
    parent: property.name!,
    dataStream: {
      type: "WEB_DATA_STREAM",
      displayName: "Landing Principal",
      webStreamData: {
        defaultUri: "https://curso-online.example.com",
      },
    },
  });
  const streamId = stream.name!.split("/").pop()!;
  console.log(`2. Stream creado: ${stream.webStreamData?.measurementId}`);

  // 3. Configurar retencion de datos a 14 meses
  await client.updateDataRetentionSettings({
    dataRetentionSettings: {
      name: `${property.name}/dataRetentionSettings`,
      eventDataRetention: "FOURTEEN_MONTHS",
      resetUserDataOnNewActivity: true,
    },
    updateMask: {
      paths: ["event_data_retention", "reset_user_data_on_new_activity"],
    },
  });
  console.log("3. Retencion: 14 meses");

  // 4. Crear custom dimensions
  const dimensiones = [
    { parameterName: "plan_type", displayName: "Tipo de Plan", scope: "EVENT" as const },
    { parameterName: "payment_method", displayName: "Metodo de Pago", scope: "EVENT" as const },
    { parameterName: "utm_source_custom", displayName: "UTM Source", scope: "EVENT" as const },
    { parameterName: "utm_campaign_custom", displayName: "UTM Campaign", scope: "EVENT" as const },
    { parameterName: "user_plan", displayName: "Plan del Usuario", scope: "USER" as const },
  ];

  for (const dim of dimensiones) {
    await client.createCustomDimension({
      parent: property.name!,
      customDimension: dim,
    });
  }
  console.log(`4. ${dimensiones.length} custom dimensions creadas`);

  // 5. Crear custom metrics
  const metricas = [
    {
      parameterName: "purchase_value_mxn",
      displayName: "Valor Compra MXN",
      scope: "EVENT" as const,
      measurementUnit: "CURRENCY" as const,
    },
    {
      parameterName: "purchase_value_eur",
      displayName: "Valor Compra EUR",
      scope: "EVENT" as const,
      measurementUnit: "CURRENCY" as const,
    },
  ];

  for (const met of metricas) {
    await client.createCustomMetric({
      parent: property.name!,
      customMetric: met,
    });
  }
  console.log(`5. ${metricas.length} custom metrics creadas`);

  // 6. Crear key events
  const keyEvents = [
    { eventName: "generate_lead", countingMethod: "ONCE_PER_EVENT" as const },
    { eventName: "begin_checkout", countingMethod: "ONCE_PER_EVENT" as const },
    { eventName: "purchase", countingMethod: "ONCE_PER_EVENT" as const },
    { eventName: "sign_up", countingMethod: "ONCE_PER_SESSION" as const },
    { eventName: "add_to_cart", countingMethod: "ONCE_PER_EVENT" as const },
  ];

  for (const ke of keyEvents) {
    await client.createKeyEvent({
      parent: property.name!,
      keyEvent: ke,
    });
  }
  console.log(`6. ${keyEvents.length} key events creados`);

  // 7. Crear MP secret para backend
  const [secret] = await client.createMeasurementProtocolSecret({
    parent: `${property.name}/dataStreams/${streamId}`,
    measurementProtocolSecret: {
      displayName: "Backend Convex - Server Events",
    },
  });
  console.log(`7. MP Secret: ${secret.secretValue}`);

  // 8. Aceptar terminos de recoleccion de datos
  await client.acknowledgeUserDataCollection({
    property: property.name!,
    acknowledgement: "I acknowledge that I have the necessary privacy disclosures and rights from my end users for the collection and processing of their data, including the association of such data with the visitation information Google Analytics collects from my site and/or app property.",
  });
  console.log("8. Terminos de recoleccion aceptados");

  console.log("\n=== SETUP COMPLETO ===");
  console.log(`Property ID: ${propertyId}`);
  console.log(`Measurement ID: ${stream.webStreamData?.measurementId}`);
  console.log(`MP Secret: ${secret.secretValue}`);
  console.log(`Stream ID: ${streamId}`);

  return { propertyId, streamId, measurementId: stream.webStreamData?.measurementId, mpSecret: secret.secretValue };
}
```

### Receta 2: Migrar Configuracion Entre Propiedades

Copia dimensiones personalizadas, metricas y key events de una propiedad a otra.

```typescript
async function migrarConfiguracion(sourcePropertyId: string, targetPropertyId: string) {
  console.log(`Migrando de properties/${sourcePropertyId} a properties/${targetPropertyId}\n`);

  // 1. Migrar custom dimensions
  const dims = client.listCustomDimensionsAsync({
    parent: `properties/${sourcePropertyId}`,
  });

  let dimCount = 0;
  for await (const dim of dims) {
    try {
      await client.createCustomDimension({
        parent: `properties/${targetPropertyId}`,
        customDimension: {
          parameterName: dim.parameterName!,
          displayName: dim.displayName!,
          description: dim.description || "",
          scope: dim.scope!,
        },
      });
      dimCount++;
    } catch (err: any) {
      if (err.code === 6) {
        // ALREADY_EXISTS — ya existe, saltar
        console.log(`  Dimension "${dim.parameterName}" ya existe, saltando`);
      } else {
        throw err;
      }
    }
  }
  console.log(`Custom dimensions migradas: ${dimCount}`);

  // 2. Migrar custom metrics
  const metrics = client.listCustomMetricsAsync({
    parent: `properties/${sourcePropertyId}`,
  });

  let metCount = 0;
  for await (const met of metrics) {
    try {
      await client.createCustomMetric({
        parent: `properties/${targetPropertyId}`,
        customMetric: {
          parameterName: met.parameterName!,
          displayName: met.displayName!,
          description: met.description || "",
          scope: met.scope!,
          measurementUnit: met.measurementUnit!,
        },
      });
      metCount++;
    } catch (err: any) {
      if (err.code === 6) {
        console.log(`  Metrica "${met.parameterName}" ya existe, saltando`);
      } else {
        throw err;
      }
    }
  }
  console.log(`Custom metrics migradas: ${metCount}`);

  // 3. Migrar key events
  const keyEvents = client.listKeyEventsAsync({
    parent: `properties/${sourcePropertyId}`,
  });

  let keCount = 0;
  for await (const ke of keyEvents) {
    try {
      await client.createKeyEvent({
        parent: `properties/${targetPropertyId}`,
        keyEvent: {
          eventName: ke.eventName!,
          countingMethod: ke.countingMethod!,
        },
      });
      keCount++;
    } catch (err: any) {
      if (err.code === 6) {
        console.log(`  Key event "${ke.eventName}" ya existe, saltando`);
      } else {
        throw err;
      }
    }
  }
  console.log(`Key events migrados: ${keCount}`);

  console.log("\nMigracion completada.");
}
```

### Receta 3: Auditar Permisos de Usuarios

Lista todos los usuarios con acceso a una propiedad y sus roles.

```typescript
async function auditarPermisos(propertyId: string) {
  console.log(`=== AUDITORIA DE PERMISOS: properties/${propertyId} ===\n`);

  const bindings = alphaClient.listAccessBindingsAsync({
    parent: `properties/${propertyId}`,
  });

  const resumen: Record<string, string[]> = {};

  for await (const binding of bindings) {
    const usuario = binding.user || "(grupo/desconocido)";
    const roles = binding.roles || [];

    resumen[usuario] = roles;

    const rolesLegibles = roles.map((r) => r.replace("predefinedRoles/", "")).join(", ");
    console.log(`  ${usuario}: ${rolesLegibles}`);
  }

  // Verificar usuarios con acceso admin
  const admins = Object.entries(resumen)
    .filter(([_, roles]) => roles.includes("predefinedRoles/admin"))
    .map(([user]) => user);

  if (admins.length > 0) {
    console.log(`\nUsuarios con rol ADMIN (${admins.length}):`);
    admins.forEach((a) => console.log(`  - ${a}`));
  }

  // Verificar usuarios con acceso editor
  const editors = Object.entries(resumen)
    .filter(([_, roles]) => roles.includes("predefinedRoles/editor"))
    .map(([user]) => user);

  if (editors.length > 0) {
    console.log(`\nUsuarios con rol EDITOR (${editors.length}):`);
    editors.forEach((e) => console.log(`  - ${e}`));
  }

  console.log(`\nTotal usuarios con acceso: ${Object.keys(resumen).length}`);
  return resumen;
}
```

```python
# Equivalente en Python
def auditar_permisos(property_id: str) -> dict[str, list[str]]:
    client = AnalyticsAdminServiceClient()

    resumen: dict[str, list[str]] = {}

    for binding in client.list_access_bindings(parent=f"properties/{property_id}"):
        usuario = binding.user or "(grupo/desconocido)"
        roles = list(binding.roles)
        resumen[usuario] = roles

        roles_legibles = ", ".join(r.replace("predefinedRoles/", "") for r in roles)
        print(f"  {usuario}: {roles_legibles}")

    admins = [u for u, r in resumen.items() if "predefinedRoles/admin" in r]
    if admins:
        print(f"\nUsuarios con rol ADMIN ({len(admins)}):")
        for a in admins:
            print(f"  - {a}")

    print(f"\nTotal usuarios con acceso: {len(resumen)}")
    return resumen
```

---

## Referencia Rapida de Errores Comunes

| Error | Causa | Solucion |
|-------|-------|----------|
| `403 PERMISSION_DENIED` | Scope insuficiente o sin acceso a la cuenta | Verificar scopes OAuth y permisos en la cuenta GA4 |
| `404 NOT_FOUND` | ID de propiedad/stream/recurso incorrecto | Verificar que el recurso existe con `get` o `list` |
| `409 ALREADY_EXISTS` | Recurso duplicado (ej: custom dimension con mismo `parameterName`) | Verificar existencia antes de crear, o capturar error code 6 |
| `429 RESOURCE_EXHAUSTED` | Rate limit excedido (600 req/min por proyecto) | Implementar exponential backoff |
| `400 INVALID_ARGUMENT` | Campo requerido faltante o valor invalido | Verificar campos obligatorios y enums validos |

## Rate Limits

| Recurso | Limite |
|---------|--------|
| Requests por proyecto | 600/minuto |
| Requests por usuario | 60/minuto |
| Requests de escritura por proyecto | 60/minuto |
| `searchChangeHistoryEvents` | 10/minuto por propiedad |
| `runAccessReport` | 10/minuto por propiedad |

---

## Dependencias y Versiones

### Node.js

```json
{
  "@google-analytics/admin": "^9.0.0"
}
```

### Python

```
google-analytics-admin==0.27.0
```

Ambas librerias requieren credenciales configuradas via:
- Variable de entorno `GOOGLE_APPLICATION_CREDENTIALS` apuntando a service account JSON
- Application Default Credentials (`gcloud auth application-default login`)
- Credenciales OAuth2 con los scopes correspondientes
