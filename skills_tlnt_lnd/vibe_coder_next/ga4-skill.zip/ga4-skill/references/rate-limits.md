# Quotas, Rate Limits y Estrategias de Retry

## Resumen

La Data API de GA4 usa un sistema de **token-bucket** donde cada request consume tokens
segun su complejidad. El Admin API tiene limites basados en requests/minuto.
El Measurement Protocol no tiene rate limiting explicito pero tiene limites de payload.

---

## Data API — Sistema Token-Bucket

### Cuotas por Tipo de Propiedad

| Cuota | Standard | GA360 |
|-------|----------|-------|
| Tokens por propiedad por **dia** | **25,000** | **250,000** |
| Tokens por propiedad por **hora** | **5,000** | **50,000** |
| Tokens por proyecto GCP por propiedad por **hora** | **1,250** | **12,500** |
| Requests concurrentes por propiedad | **10** | **10** |
| Requests potencialmente con thresholding por hora | **120** | **1,200** |

### Como se Calculan los Tokens

El costo en tokens varia por complejidad del reporte:

| Factor | Impacto en Tokens |
|--------|------------------|
| Reporte simple (1 dim, 1 metric, 1 date range) | ~10 tokens |
| Cada dimension adicional | +tokens |
| Cada metrica adicional | +tokens |
| Date range mas amplio | +tokens |
| Mas de 1 date range | Multiplica por numero de date ranges |
| Filtros complejos (regex) | +tokens |
| Alto numero de filas (limit alto) | +tokens |
| Reporte con muchas combinaciones dim/metric | Puede llegar a 1,000+ tokens |

> **CRITICO:** Las cuotas de tokens **NO se pueden incrementar** para propiedades standard.
> El unico camino para mas tokens es migrar a GA360.

### Monitorizar Consumo de Tokens

**SIEMPRE** activar `returnPropertyQuota: true` en las requests:

```python
response = client.run_report(RunReportRequest(
    property=f"properties/{property_id}",
    dimensions=[Dimension(name="country")],
    metrics=[Metric(name="activeUsers")],
    date_ranges=[DateRange(start_date="7daysAgo", end_date="yesterday")],
    return_property_quota=True,  # <-- SIEMPRE ACTIVAR
))

if response.property_quota:
    pq = response.property_quota
    print(f"Tokens/dia — consumidos: {pq.tokens_per_day.consumed}, "
          f"restantes: {pq.tokens_per_day.remaining}")
    print(f"Tokens/hora — consumidos: {pq.tokens_per_hour.consumed}, "
          f"restantes: {pq.tokens_per_hour.remaining}")
    print(f"Tokens/proyecto/hora — consumidos: {pq.tokens_per_project_per_hour.consumed}, "
          f"restantes: {pq.tokens_per_project_per_hour.remaining}")
    print(f"Concurrentes — consumidos: {pq.concurrently_sent_requests_per_property.consumed}, "
          f"restantes: {pq.concurrently_sent_requests_per_property.remaining}")
```

### getPropertyQuotasSnapshot (v1alpha)

Ver todas las cuotas de un vistazo sin ejecutar un reporte:

```python
from google.analytics.data_v1alpha import AlphaAnalyticsDataClient

alpha_client = AlphaAnalyticsDataClient()
snapshot = alpha_client.get_property_quotas_snapshot(
    name=f"properties/{property_id}/quotasSnapshot"
)
print(f"Tokens/dia restantes: {snapshot.tokens_per_day.remaining}")
```

---

## Admin API — Limites de Requests

| Cuota | Limite |
|-------|-------|
| Requests/minuto por **proyecto GCP** | **1,200** |
| Requests/minuto por **usuario** | **600** |
| Write requests/minuto por **proyecto** | **600** |
| Write requests/minuto por **usuario** | **180** |

> Las operaciones de lectura (list, get) son mas generosas que las de escritura (create, update, delete).

---

## Measurement Protocol — Limites

| Limite | Valor |
|--------|-------|
| Eventos por request | 25 |
| Parametros por evento | 25 |
| User properties por request | 25 |
| Tamaño del body | 130 KB |
| Ventana de backdating | 72 horas |

No hay rate limiting explicito documentado para MP, pero Google puede throttlear
si detecta patrones de abuso.

---

## BigQuery — Costos y Limites

| Recurso | Limite/Costo |
|---------|-------------|
| Export diario (standard) | 1M eventos/dia |
| Export diario (GA360) | Sin limite practico |
| Export streaming | Sin limite |
| Costo query on-demand | ~$6.25 USD/TB escaneado |
| Costo query flat-rate | Desde $2,000/mes (100 slots) |
| Slots concurrentes (on-demand) | 2,000 por proyecto |

---

## Backoff Exponencial con Jitter

### Patron Recomendado (TypeScript)

```typescript
interface RetryConfig {
  maxRetries: number;
  baseDelay: number;
  maxDelay: number;
  retryableCodes: number[];
}

const DEFAULT_RETRY_CONFIG: RetryConfig = {
  maxRetries: 5,
  baseDelay: 1000,
  maxDelay: 60000,
  retryableCodes: [429, 500, 503],
};

async function withRetry<T>(
  fn: () => Promise<T>,
  config: RetryConfig = DEFAULT_RETRY_CONFIG
): Promise<T> {
  for (let attempt = 0; attempt < config.maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err: any) {
      const code = err.code ?? err.response?.status ?? err.status;

      if (config.retryableCodes.includes(code) && attempt < config.maxRetries - 1) {
        const delay = Math.min(
          config.baseDelay * Math.pow(2, attempt) + Math.random() * 1000,
          config.maxDelay
        );
        console.warn(
          `Retry ${attempt + 1}/${config.maxRetries} despues de ${Math.round(delay)}ms ` +
          `(codigo: ${code})`
        );
        await new Promise((resolve) => setTimeout(resolve, delay));
      } else {
        throw err;
      }
    }
  }
  throw new Error('Max retries excedido');
}

// Uso:
const response = await withRetry(() =>
  client.runReport({
    property: `properties/${propertyId}`,
    dimensions: [{ name: 'country' }],
    metrics: [{ name: 'activeUsers' }],
    dateRanges: [{ startDate: '7daysAgo', endDate: 'yesterday' }],
    returnPropertyQuota: true,
  })
);
```

### Patron Recomendado (Python)

```python
import time
import random
import logging
from typing import TypeVar, Callable

T = TypeVar("T")
logger = logging.getLogger(__name__)


def with_retry(
    fn: Callable[[], T],
    max_retries: int = 5,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
    retryable_codes: tuple = (429, 500, 503),
) -> T:
    """Ejecutar funcion con retry y backoff exponencial + jitter."""
    for attempt in range(max_retries):
        try:
            return fn()
        except Exception as e:
            code = getattr(e, "code", None) or getattr(
                getattr(e, "response", None), "status_code", None
            )

            if code in retryable_codes and attempt < max_retries - 1:
                delay = min(
                    base_delay * (2 ** attempt) + random.uniform(0, 1),
                    max_delay,
                )
                logger.warning(
                    f"Retry {attempt + 1}/{max_retries} despues de {delay:.1f}s "
                    f"(codigo: {code})"
                )
                time.sleep(delay)
            else:
                raise

    raise RuntimeError("Max retries excedido")


# Uso:
response = with_retry(lambda: client.run_report(request))
```

### Retry Automatico en Google Client Libraries

Las client libraries de Google (Python `google-api-core`, Node.js `google-gax`)
incluyen retry automatico para errores 429/500/503:

```python
# Python — retry automatico incluido por defecto
from google.api_core.retry import Retry

# Default: exponential backoff, initial=1s, max=60s, multiplier=2
# Aplicado automaticamente por las client libraries para 429/500/503

# Configurar retry custom:
from google.api_core.retry import Retry

custom_retry = Retry(
    initial=1.0,
    maximum=60.0,
    multiplier=2.0,
    deadline=300.0,  # timeout total: 5 minutos
)

response = client.run_report(request, retry=custom_retry)
```

---

## Circuit Breaker

Para proteger contra exhaustion de cuotas:

```python
import time
from dataclasses import dataclass, field


@dataclass
class CircuitBreaker:
    """Proteccion contra rate limiting excesivo."""
    failure_threshold: int = 5
    recovery_timeout: float = 60.0
    half_open_requests: int = 1

    _failure_count: int = field(default=0, init=False)
    _state: str = field(default="closed", init=False)  # closed, open, half_open
    _last_failure_time: float = field(default=0, init=False)

    def can_execute(self) -> bool:
        """Verificar si se puede ejecutar una request."""
        if self._state == "closed":
            return True
        elif self._state == "open":
            if time.time() - self._last_failure_time >= self.recovery_timeout:
                self._state = "half_open"
                return True
            return False
        elif self._state == "half_open":
            return True
        return False

    def record_success(self) -> None:
        """Registrar exito."""
        self._failure_count = 0
        self._state = "closed"

    def record_failure(self) -> None:
        """Registrar fallo."""
        self._failure_count += 1
        self._last_failure_time = time.time()
        if self._failure_count >= self.failure_threshold:
            self._state = "open"


# Uso:
breaker = CircuitBreaker(failure_threshold=3, recovery_timeout=120)

def safe_run_report(client, request):
    if not breaker.can_execute():
        raise RuntimeError("Circuit breaker abierto — esperando recovery")

    try:
        response = client.run_report(request)
        breaker.record_success()
        return response
    except Exception as e:
        breaker.record_failure()
        raise
```

---

## Estrategia de Cache

### Reglas de Cache para GA4

| Tipo de Datos | TTL Recomendado | Razon |
|---------------|----------------|-------|
| Reportes historicos (>48h) | 24-72 horas | Datos estables, no cambian |
| Reportes recientes (24-48h) | 4-8 horas | Procesamiento GA4 aun en curso |
| Reportes de ayer | 2-4 horas | Puede recibir late-arriving events |
| Reportes de hoy | 15-60 minutos | Datos parciales, cambian frecuentemente |
| Datos Realtime | 30-60 segundos | Cambio constante |
| Metadata (dimensiones/metricas) | 24 horas | Cambia raramente |

### Implementacion de Cache

```python
import hashlib
import json
import time
from typing import Optional, Any


class GA4Cache:
    """Cache simple en memoria para respuestas de Data API."""

    def __init__(self):
        self._store: dict[str, tuple[Any, float]] = {}

    def _make_key(self, property_id: str, request_dict: dict) -> str:
        """Generar clave de cache basada en el request."""
        serialized = json.dumps(request_dict, sort_keys=True, default=str)
        hash_val = hashlib.sha256(serialized.encode()).hexdigest()[:16]
        return f"ga4:{property_id}:{hash_val}"

    def get(self, property_id: str, request_dict: dict) -> Optional[Any]:
        """Obtener respuesta cacheada si no ha expirado."""
        key = self._make_key(property_id, request_dict)
        if key in self._store:
            value, expiry = self._store[key]
            if time.time() < expiry:
                return value
            else:
                del self._store[key]
        return None

    def set(self, property_id: str, request_dict: dict, value: Any, ttl: int = 14400) -> None:
        """Cachear respuesta con TTL en segundos (default 4h)."""
        key = self._make_key(property_id, request_dict)
        self._store[key] = (value, time.time() + ttl)

    def clear(self) -> None:
        """Limpiar todo el cache."""
        self._store.clear()

    def clear_property(self, property_id: str) -> None:
        """Limpiar cache de una propiedad especifica."""
        to_delete = [k for k in self._store if k.startswith(f"ga4:{property_id}:")]
        for k in to_delete:
            del self._store[k]
```

### Determinar TTL automaticamente

```python
from datetime import datetime, timedelta


def determine_ttl(start_date: str, end_date: str) -> int:
    """Determinar TTL de cache basado en la frescura de los datos."""
    today = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    two_days_ago = (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d")

    # Resolver fechas relativas
    def resolve_date(d: str) -> str:
        if d == "today":
            return today
        elif d == "yesterday":
            return yesterday
        elif d.endswith("daysAgo"):
            days = int(d.replace("daysAgo", ""))
            return (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
        return d

    resolved_end = resolve_date(end_date)

    if resolved_end >= today:
        return 900  # 15 minutos — datos de hoy
    elif resolved_end >= yesterday:
        return 7200  # 2 horas — datos de ayer
    elif resolved_end >= two_days_ago:
        return 14400  # 4 horas — datos recientes
    else:
        return 86400  # 24 horas — datos historicos
```

---

## Optimizacion de Consumo de Tokens

### 1. Usar batchRunReports en lugar de multiples runReport

```python
# MAL: 5 requests individuales (5x tokens + 5x latencia)
for dims in dimension_groups:
    client.run_report(RunReportRequest(dimensions=dims, ...))

# BIEN: 1 batch request (tokens consolidados + 1x latencia)
client.batch_run_reports(request={
    "property": f"properties/{property_id}",
    "requests": [
        RunReportRequest(dimensions=dims, ...) for dims in dimension_groups
    ],
})
```

### 2. Reducir dimensiones al minimo necesario

Cada dimension adicional incrementa el costo en tokens significativamente.

### 3. Acortar date ranges

Dividir un reporte de 90 dias en 3 reportes de 30 dias puede consumir menos tokens total.

### 4. Cachear agresivamente

No repetir la misma query — usar el cache strategy descrito arriba.

### 5. checkCompatibility antes de reportes complejos

No gastar tokens en queries que van a fallar por incompatibilidad.

### 6. Mover reportes pesados a BigQuery

Para reportes con muchas dimensiones, alto volumen, o que necesitan datos sin muestreo,
BigQuery Export es mas eficiente (costo solo en BQ, no en tokens GA4).

---

## Codigos de Error Comunes

| Codigo | Significado | Accion |
|--------|-------------|--------|
| `429` | Rate limited — cuota excedida | Retry con backoff |
| `403` | Permission denied | Verificar permisos del service account |
| `404` | Property no encontrada | Verificar property ID |
| `400` | Request invalida | Verificar dimensiones/metricas compatibles |
| `500` | Error interno del servidor | Retry con backoff |
| `503` | Servicio no disponible | Retry con backoff |
| `RESOURCE_EXHAUSTED` | Cuota de tokens agotada | Esperar reset (horario o diario) |
