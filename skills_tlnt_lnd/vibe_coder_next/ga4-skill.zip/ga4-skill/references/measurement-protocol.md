# Measurement Protocol — Tracking Server-Side

## Resumen

El Measurement Protocol envia eventos directamente a GA4 desde cualquier servidor o sistema
backend. Su proposito es **augmentar** la recoleccion client-side — no reemplazarla.

---

## Endpoints

| Entorno | URL |
|---------|-----|
| **Produccion** | `POST https://www.google-analytics.com/mp/collect?measurement_id={MID}&api_secret={SECRET}` |
| **Validacion** | `POST https://www.google-analytics.com/debug/mp/collect?measurement_id={MID}&api_secret={SECRET}` |
| **EU Data Residency** | Reemplazar host con `region1.google-analytics.com` |

### Parametros de URL

- `measurement_id` — El Measurement ID de GA4 (formato `G-XXXXXXXXXX`)
- `api_secret` — API Secret generado en Admin API o GA4 UI (Admin → Data Streams → MP API Secrets)

---

## Restricciones

| Restriccion | Limite |
|-------------|--------|
| Eventos por request | **25** |
| Parametros por evento | **25** |
| User properties | **25** |
| Longitud nombre evento | **40 caracteres** |
| Longitud valor parametro | **100 caracteres** (500 para GA360) |
| Tamaño total del body | **130 KB** |
| Ventana de backdating | **72 horas** |
| Eventos reservados | `first_open`, `first_visit`, `in_app_purchase`, `session_start`, `app_remove`, etc. |

### Restricciones Funcionales

- Los eventos MP **NO pueden** crear nuevas sesiones de usuario por si solos
- Los eventos MP **NO se ven afectados** por las reglas de "Modify event" de la UI de GA4
- Los eventos MP **NO activan** triggers de GA4 configurados en la UI
- El endpoint de produccion **siempre** devuelve `2xx` incluso con datos invalidos
- Solo el endpoint `/debug/mp/collect` reporta errores de validacion

---

## Estructura del Payload

```json
{
  "client_id": "string (REQUERIDO)",
  "user_id": "string (opcional)",
  "timestamp_micros": "string (opcional, microsegundos Unix)",
  "non_personalized_ads": false,
  "consent": {
    "ad_user_data": "GRANTED",
    "ad_personalization": "GRANTED"
  },
  "user_properties": {
    "user_tier": { "value": "premium" }
  },
  "events": [
    {
      "name": "string (REQUERIDO)",
      "params": {
        "key": "value (string o numero)"
      }
    }
  ]
}
```

### Campos Requeridos

| Campo | Descripcion |
|-------|-------------|
| `client_id` | Identificador pseudoanonimo del cliente. Debe coincidir con el `_ga` cookie del browser si se quiere unir con datos client-side |
| `events[].name` | Nombre del evento (max 40 chars, solo alfanumerico + underscore) |

### Campos Criticos (Tecnicamente Opcionales, Practicamente Obligatorios)

| Campo | Por Que es Critico |
|-------|-------------------|
| `events[].params.session_id` | Sin esto, el evento aparece como `(not set)` en atribucion y NO aparece en Realtime |
| `events[].params.engagement_time_msec` | Sin esto, el evento NO aparece en reportes Realtime. Enviar al menos `"100"` |

---

## Ejemplos Completos

### TypeScript — Evento de Compra con Validacion

```typescript
const MEASUREMENT_ID = 'G-XXXXXXXXXX';
const API_SECRET = 'your_api_secret';
const BASE_URL = 'https://www.google-analytics.com';

interface MPEvent {
  name: string;
  params: Record<string, string | number>;
}

interface MPPayload {
  client_id: string;
  user_id?: string;
  timestamp_micros?: string;
  non_personalized_ads?: boolean;
  consent?: {
    ad_user_data?: 'GRANTED' | 'DENIED';
    ad_personalization?: 'GRANTED' | 'DENIED';
  };
  user_properties?: Record<string, { value: string | number }>;
  events: MPEvent[];
}

// ====== Validacion ======
async function validateEvent(payload: MPPayload): Promise<void> {
  const res = await fetch(
    `${BASE_URL}/debug/mp/collect?measurement_id=${MEASUREMENT_ID}&api_secret=${API_SECRET}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...payload,
        validation_behavior: 'ENFORCE_RECOMMENDATIONS',
      }),
    }
  );
  const data = await res.json();
  if (data.validationMessages?.length > 0) {
    throw new Error(
      `Validacion MP fallida: ${JSON.stringify(data.validationMessages)}`
    );
  }
}

// ====== Envio ======
async function sendEvent(payload: MPPayload): Promise<void> {
  const res = await fetch(
    `${BASE_URL}/mp/collect?measurement_id=${MEASUREMENT_ID}&api_secret=${API_SECRET}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }
  );
  // Nota: produccion SIEMPRE devuelve 2xx, incluso con datos invalidos
  if (!res.ok) {
    throw new Error(`MP request fallo: ${res.status}`);
  }
}

// ====== Ejemplo: Compra ======
async function sendPurchaseEvent(
  clientId: string,
  userId: string,
  transactionId: string,
  value: number,
  currency: string = 'USD',
  sessionId: string
): Promise<void> {
  const payload: MPPayload = {
    client_id: clientId,
    user_id: userId,
    events: [
      {
        name: 'purchase',
        params: {
          transaction_id: transactionId,
          value,
          currency,
          session_id: sessionId,
          engagement_time_msec: '100',
        },
      },
    ],
  };

  // Validar solo en desarrollo
  if (process.env.NODE_ENV !== 'production') {
    await validateEvent(payload);
  }

  await sendEvent(payload);
}
```

### Python — Evento de Compra con Validacion

```python
import requests
import json
import os
from typing import Optional

MEASUREMENT_ID = os.environ.get("GA4_MEASUREMENT_ID", "G-XXXXXXXXXX")
API_SECRET = os.environ.get("GA4_MP_API_SECRET", "your_api_secret")
BASE_URL = "https://www.google-analytics.com"


def validate_event(payload: dict) -> None:
    """Validar payload contra el endpoint de debug de MP."""
    url = f"{BASE_URL}/debug/mp/collect"
    params = {"measurement_id": MEASUREMENT_ID, "api_secret": API_SECRET}
    body = {**payload, "validation_behavior": "ENFORCE_RECOMMENDATIONS"}

    resp = requests.post(url, params=params, json=body, timeout=10)
    resp.raise_for_status()

    result = resp.json()
    if result.get("validationMessages"):
        raise ValueError(
            f"Validacion MP fallida: {json.dumps(result['validationMessages'], indent=2)}"
        )


def send_event(payload: dict) -> None:
    """Enviar payload al endpoint de produccion de MP."""
    url = f"{BASE_URL}/mp/collect"
    params = {"measurement_id": MEASUREMENT_ID, "api_secret": API_SECRET}

    resp = requests.post(url, params=params, json=body, timeout=10)
    # Produccion siempre devuelve 2xx, pero verificamos por si acaso
    resp.raise_for_status()


def send_purchase(
    client_id: str,
    transaction_id: str,
    value: float,
    currency: str = "USD",
    session_id: str = "1234567890",
    user_id: Optional[str] = None,
    validate: bool = True,
) -> None:
    """Enviar evento de compra a GA4 via Measurement Protocol."""
    payload = {
        "client_id": client_id,
        "events": [
            {
                "name": "purchase",
                "params": {
                    "transaction_id": transaction_id,
                    "value": value,
                    "currency": currency,
                    "session_id": session_id,
                    "engagement_time_msec": "100",
                },
            }
        ],
    }

    if user_id:
        payload["user_id"] = user_id

    if validate:
        validate_event(payload)

    send_event(payload)
```

### TypeScript — Evento Custom con User Properties

```typescript
async function sendCustomEvent(
  clientId: string,
  eventName: string,
  eventParams: Record<string, string | number>,
  userProperties?: Record<string, string | number>,
  sessionId?: string
): Promise<void> {
  const payload: MPPayload = {
    client_id: clientId,
    events: [
      {
        name: eventName,
        params: {
          ...eventParams,
          session_id: sessionId || Date.now().toString(),
          engagement_time_msec: '100',
        },
      },
    ],
  };

  if (userProperties) {
    payload.user_properties = {};
    for (const [key, value] of Object.entries(userProperties)) {
      payload.user_properties[key] = { value };
    }
  }

  await sendEvent(payload);
}

// Uso:
await sendCustomEvent(
  'client123',
  'lead_registered',
  { plan: 'online', source: 'landing' },
  { user_tier: 'lead', registration_date: '2026-02-24' }
);
```

---

## Eventos E-commerce Completos

### Evento purchase con items

```python
def send_ecommerce_purchase(
    client_id: str,
    transaction_id: str,
    items: list[dict],
    session_id: str,
    currency: str = "USD",
    user_id: str = None,
    coupon: str = None,
    shipping: float = 0,
    tax: float = 0,
) -> None:
    """Enviar compra e-commerce completa con items."""
    total_value = sum(item.get("price", 0) * item.get("quantity", 1) for item in items)

    event_params = {
        "transaction_id": transaction_id,
        "value": total_value,
        "currency": currency,
        "shipping": shipping,
        "tax": tax,
        "session_id": session_id,
        "engagement_time_msec": "100",
        "items": [
            {
                "item_id": item.get("id", ""),
                "item_name": item.get("name", ""),
                "item_brand": item.get("brand", ""),
                "item_category": item.get("category", ""),
                "price": item.get("price", 0),
                "quantity": item.get("quantity", 1),
                **({"coupon": item.get("coupon")} if item.get("coupon") else {}),
            }
            for item in items
        ],
    }

    if coupon:
        event_params["coupon"] = coupon

    payload = {
        "client_id": client_id,
        "events": [{"name": "purchase", "params": event_params}],
    }

    if user_id:
        payload["user_id"] = user_id

    send_event(payload)


# Ejemplo de uso:
send_ecommerce_purchase(
    client_id="GA1.1.123456789.1234567890",
    transaction_id="TXN_20260224_001",
    session_id="9876543210",
    items=[
        {
            "id": "plan_online",
            "name": "Curso Online Online",
            "brand": "Tu Marca",
            "category": "Education",
            "price": 379.0,
            "quantity": 1,
        }
    ],
    currency="EUR",
    coupon="VETERANO",
)
```

### Funnel de e-commerce: view_item → add_to_cart → begin_checkout → purchase

```python
def send_funnel_event(
    client_id: str,
    event_name: str,
    items: list[dict],
    session_id: str,
    currency: str = "USD",
) -> None:
    """Enviar evento de funnel e-commerce."""
    total_value = sum(item.get("price", 0) * item.get("quantity", 1) for item in items)

    payload = {
        "client_id": client_id,
        "events": [
            {
                "name": event_name,
                "params": {
                    "value": total_value,
                    "currency": currency,
                    "session_id": session_id,
                    "engagement_time_msec": "100",
                    "items": [
                        {
                            "item_id": item["id"],
                            "item_name": item["name"],
                            "price": item.get("price", 0),
                            "quantity": item.get("quantity", 1),
                        }
                        for item in items
                    ],
                },
            }
        ],
    }
    send_event(payload)


# Eventos validos del funnel e-commerce:
# view_item, view_item_list, select_item, add_to_cart,
# remove_from_cart, view_cart, begin_checkout,
# add_shipping_info, add_payment_info, purchase, refund
```

---

## Consent Mode v2

Para cumplimiento en EEA (obligatorio desde marzo 2024):

```python
payload = {
    "client_id": client_id,
    "consent": {
        "ad_user_data": "GRANTED",       # o "DENIED"
        "ad_personalization": "GRANTED",  # o "DENIED"
    },
    "events": [
        {
            "name": "purchase",
            "params": {
                "transaction_id": "TXN_001",
                "value": 99.99,
                "currency": "EUR",
                "session_id": "12345",
                "engagement_time_msec": "100",
            },
        }
    ],
}
```

---

## Backdating de Eventos

Permite enviar eventos con timestamps pasados (hasta 72 horas).

```python
import time

# Timestamp de hace 2 horas en microsegundos
two_hours_ago_micros = str(int((time.time() - 7200) * 1_000_000))

payload = {
    "client_id": client_id,
    "timestamp_micros": two_hours_ago_micros,
    "events": [
        {
            "name": "offline_purchase",
            "params": {
                "transaction_id": "OFFLINE_001",
                "value": 150.00,
                "currency": "USD",
                "session_id": "99999",
                "engagement_time_msec": "100",
            },
        }
    ],
}
```

> **AVISO:** Backdating mas alla de medianoche UTC puede no funcionar de forma fiable
> a pesar de la ventana documentada de 72 horas.

---

## EU Data Residency

Para propiedades configuradas con residencia de datos en la UE:

```python
# Reemplazar el host base
EU_BASE_URL = "https://region1.google-analytics.com"

url = f"{EU_BASE_URL}/mp/collect"
params = {"measurement_id": MEASUREMENT_ID, "api_secret": API_SECRET}
resp = requests.post(url, params=params, json=payload, timeout=10)
```

---

## Validacion Completa

### Niveles de validacion

| Nivel | Descripcion |
|-------|-------------|
| Sin `validation_behavior` | Validacion basica (solo errores criticos) |
| `ENFORCE_RECOMMENDATIONS` | Validacion estricta (errores + advertencias) |

### Response del endpoint debug

```json
{
  "validationMessages": [
    {
      "fieldPath": "events[0].params.engagement_time_msec",
      "description": "engagement_time_msec should be set...",
      "validationCode": "VALUE_REQUIRED"
    }
  ]
}
```

### Codigos de validacion comunes

| Codigo | Descripcion |
|--------|-------------|
| `VALUE_REQUIRED` | Campo requerido faltante |
| `VALUE_INVALID` | Valor con formato incorrecto |
| `VALUE_OUT_OF_BOUNDS` | Valor fuera del rango permitido |
| `NAME_INVALID` | Nombre de evento o parametro invalido |
| `NAME_RESERVED` | Nombre reservado por Google (`ga_`, `google_`, `firebase_`) |
| `NAME_DUPLICATED` | Nombre duplicado en la misma request |
| `EXCESSIVE_EVENTS` | Mas de 25 eventos en un request |

---

## Bugs Conocidos y Gotchas

### 1. Eventos con user_id pueden ser descartados silenciosamente
Cuando la politica "User-provided data collection" esta acknowledged en GA4 Admin,
eventos con `user_id` pueden ser descartados sin error. **Testear exhaustivamente.**

### 2. session_id y engagement_time_msec son OBLIGATORIOS en la practica
Documentados como opcionales, pero sin ellos:
- Eventos NO aparecen en Realtime
- Atribucion muestra `(not set)`
- Datos pueden no procesarse correctamente

### 3. page_location tiene limite de 100 caracteres
Los query strings se truncan. Si necesitas URLs largas, usar un parametro custom.

### 4. Produccion siempre devuelve 2xx
El endpoint `/mp/collect` NUNCA devuelve errores de validacion.
**Siempre** validar primero con `/debug/mp/collect` en desarrollo.

### 5. MP events no crean sesiones
Los eventos MP no pueden iniciar una nueva sesion de usuario.
Necesitan un `session_id` existente del tracking client-side,
o un session_id inventado (que creara una sesion "sintetica" limitada).

### 6. Nombres reservados
Nombres que empiezan con `ga_`, `google_`, o `firebase_` estan reservados.
Tambien eventos como `first_open`, `session_start`, `app_remove` estan reservados.

---

## Patron de Retry para MP

```python
import time
import random
import requests
from typing import Optional


def send_mp_event_with_retry(
    payload: dict,
    max_retries: int = 3,
    base_delay: float = 1.0,
) -> bool:
    """Enviar evento MP con retry y backoff exponencial."""
    url = f"{BASE_URL}/mp/collect"
    params = {"measurement_id": MEASUREMENT_ID, "api_secret": API_SECRET}

    for attempt in range(max_retries):
        try:
            resp = requests.post(
                url, params=params, json=payload, timeout=10
            )
            if resp.status_code < 500:
                return True
            # 5xx: reintentar
        except requests.exceptions.RequestException:
            pass

        if attempt < max_retries - 1:
            delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
            time.sleep(delay)

    return False
```

---

## Batch de Multiples Eventos

```python
def send_batch_events(
    client_id: str,
    events: list[dict],
    session_id: str,
    chunk_size: int = 25,
) -> None:
    """Enviar multiples eventos en batches de max 25."""
    # Agregar session_id y engagement_time_msec a cada evento
    enriched_events = []
    for event in events:
        params = {**event.get("params", {})}
        params.setdefault("session_id", session_id)
        params.setdefault("engagement_time_msec", "100")
        enriched_events.append({"name": event["name"], "params": params})

    # Dividir en chunks de 25
    for i in range(0, len(enriched_events), chunk_size):
        chunk = enriched_events[i : i + chunk_size]
        payload = {"client_id": client_id, "events": chunk}
        send_mp_event_with_retry(payload)
```

---

## Crear MP API Secret

### Via Admin API (Python)

```python
from google.analytics.admin_v1beta import AnalyticsAdminServiceClient
from google.analytics.admin_v1beta.types import (
    CreateMeasurementProtocolSecretRequest,
    MeasurementProtocolSecret,
)

admin = AnalyticsAdminServiceClient()

secret = admin.create_measurement_protocol_secret(
    request=CreateMeasurementProtocolSecretRequest(
        parent=f"properties/{property_id}/dataStreams/{stream_id}",
        measurement_protocol_secret=MeasurementProtocolSecret(
            display_name="Server-side produccion"
        ),
    )
)
print(f"API Secret: {secret.secret_value}")
print(f"Display Name: {secret.display_name}")
```

### Via GA4 UI

1. GA4 Admin → Data Streams → seleccionar stream
2. Measurement Protocol API Secrets → Create
3. Dar nombre descriptivo → Copiar el secret generado
