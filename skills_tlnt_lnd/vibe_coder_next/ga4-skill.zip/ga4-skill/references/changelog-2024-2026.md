# Changelog GA4 — 2024 a Febrero 2026

## Resumen

Historial de cambios significativos en las APIs de GA4.
Organizado cronologicamente para referencia rapida.

---

## Marzo 2024

### Key Events Rename (Breaking Change)
"Conversions" paso a llamarse "Key Events" en todo GA4.

| Antes | Despues |
|-------|---------|
| `conversions` (metrica) | `keyEvents` |
| `sessionConversionRate` | `sessionKeyEventRate` |
| `userConversionRate` | `userKeyEventRate` |
| `conversionEvents` (Admin API) | `keyEvents` (Admin API) |

> **Backward compatibility:** `conversionEvents` en Admin API sigue existiendo
> como legacy pero se recomienda migrar a `keyEvents`.

### Consent Mode v2 Enforcement (EEA)
- Nuevos parametros obligatorios: `ad_user_data` y `ad_personalization`
- Cuentas no conformes perdieron features de advertising en EEA
- Afecta tanto a tracking client-side como a Measurement Protocol

---

## Julio 2024

### BigQuery Schema Additions
Nuevas columnas agregadas a `events_YYYYMMDD`:

| Columna | Tipo | Descripcion |
|---------|------|-------------|
| `session_traffic_source_last_click` | RECORD | Atribucion last-click a nivel de sesion |
| `batch_event_index` | INTEGER | Secuencia del evento dentro del batch |
| `batch_page_id` | INTEGER | Identificador de pagina dentro del batch |
| `batch_ordering_id` | INTEGER | Ordenamiento del batch |

**Impacto:**
- `session_traffic_source_last_click` permite analisis de atribucion de sesion
  sin necesidad de auto-joins complejos
- Los campos `batch_*` permiten reconstruir el orden exacto de eventos

---

## Octubre 2024

### Cross-Channel Campaign Fields
Nuevas columnas en BigQuery Export:

| Columna | Descripcion |
|---------|-------------|
| `cross_channel_campaign` | Campana cross-channel |
| `sa360_campaign` | Campana SA360 |
| `cm360_campaign` | Campana CM360 |
| `dv360_campaign` | Campana DV360 |
| `publisher` | Informacion del publisher |

**Impacto:** Permite analisis unificado de campanas across Google Marketing Platform.

---

## 2024 — Data API Additions

### Audience Exports (Graduado a v1beta)
Los metodos de audience export pasaron de v1alpha a v1beta:
- `createAudienceExport`
- `getAudienceExport`
- `listAudienceExports`
- `queryAudienceExport`

### Report Tasks (v1alpha)
Nuevos metodos para reportes asincrono:
- `createReportTask` — Crear reporte asincronico
- `getReportTask` — Verificar estado
- `listReportTasks` — Listar reportes pendientes
- `queryReportTask` — Obtener resultados

**Feature clave:** GA360 puede solicitar `samplingLevel: UNSAMPLED` hasta 1B eventos.

### Recurring Audience Lists (v1alpha)
Listas de audiencia con actualizacion diaria automatica.

### EmptyFilter (v1beta)
Nuevo tipo de filtro para buscar valores vacios/en blanco.

```python
filter = Filter(
    field_name="pagePath",
    empty_filter=Filter.EmptyFilter(),
)
```

### Comparisons Field
Campo `comparisons` en `runReport` para evaluacion side-by-side.

---

## Marzo 2025

### Reporting Data Annotations (v1alpha)
Feature largamente esperado: anotaciones en reportes.

```python
admin.create_reporting_data_annotation(request={
    "parent": f"properties/{property_id}",
    "reporting_data_annotation": {
        "title": "Lanzamiento v2.0",
        "description": "Deploy de nueva version del sitio",
        "annotation_date": {"year": 2025, "month": 3, "day": 15},
        "color": "BLUE",
    },
})
```

**Limites:**
- Hasta 1,000 anotaciones por propiedad
- Colores: `PURPLE`, `BROWN`, `TEAL`, `GREEN`, `CYAN`, `BLUE`, `PINK`
- Gestionables via Admin API v1alpha `reportingDataAnnotations`

---

## 2025 — Admin API Additions

### BigQuery Link CRUD (v1alpha)
CRUD completo para links de BigQuery:
- `createBigQueryLink`
- `getBigQueryLink`
- `listBigQueryLinks`
- `updateBigQueryLink`
- `deleteBigQueryLink`

### userDataRetention Field
Campo para configurar retencion de datos de usuario programaticamente.

### getReportingIdentitySettings
Metodo para obtener la configuracion de identidad de reporting.

---

## Septiembre 2025

### Google Analytics MCP Server
Servidor MCP oficial y experimental para acceso conversacional a GA4 desde agentes.

**Repositorio:** `google-analytics-mcp` en GitHub
**Instalacion:** `pipx run analytics-mcp`

**Herramientas:**
- `get_account_summaries`
- `run_report`
- `run_realtime_report`
- `get_property_details`

**Limitaciones:**
- Solo lectura
- Experimental (puede tener breaking changes)
- No cubre todas las features de Data API

---

## Diciembre 2025

### Data Manager API
Nueva API unificada que consolida la ingestion de datos first-party
across Google Ads, Analytics y DV360.

**Relevancia para GA4:**
- Reemplaza algunos flujos de subida de datos
- Complementa Enhanced Conversions
- Centraliza la gestion de datos first-party en una sola API

---

## Febrero 2026 — Estado Actual

### Versiones de Client Libraries

| Plataforma | Paquete Data API | Version |
|-----------|-----------------|---------|
| Python | `google-analytics-data` | v0.20.0 |
| Node.js | `@google-analytics/data` | v5.x |
| Python | `google-analytics-admin` | v0.27.0 |
| Node.js | `@google-analytics/admin` | v9.x |

### Paquetes Deprecados

| Deprecado | Reemplazo |
|-----------|-----------|
| `@googleapis/analyticsdata` | `@google-analytics/data` |
| `conversionEvents` (Admin API) | `keyEvents` (Admin API) |
| `conversions` (metrica Data API) | `keyEvents` (metrica Data API) |

### Notas de Estado

- **NO existe Data API v2** — ni existe ni esta planeada
- El modelo de canales **v1beta / v1alpha** continua
- Features se graduan de alpha → beta conforme estabilizan
- La Data API v1beta ES la version estable

---

## Timeline Visual

```
2024 Q1  ─── Key Events rename + Consent Mode v2 enforcement
2024 Q2  ─── Audience Exports → v1beta, EmptyFilter
2024 Q3  ─── session_traffic_source_last_click (BQ), batch_* fields
2024 Q4  ─── cross_channel_campaign (BQ), Report Tasks (alpha)
2025 Q1  ─── Reporting Data Annotations, BQ Link CRUD
2025 Q2  ─── userDataRetention, reportingIdentitySettings
2025 Q3  ─── GA4 MCP Server (experimental)
2025 Q4  ─── Data Manager API
2026 Q1  ─── Estado actual (libs: data v0.20.0/v5.x, admin v0.27.0/v9.x)
```

---

## Migacion de "Conversions" a "Key Events"

### Codigo Antes (Pre-Marzo 2024)

```python
# Data API
metrics=[Metric(name="conversions")]

# Admin API
admin.create_conversion_event(request={
    "parent": f"properties/{property_id}",
    "conversion_event": {"event_name": "purchase"},
})
```

### Codigo Despues (Post-Marzo 2024)

```python
# Data API
metrics=[Metric(name="keyEvents")]

# Admin API
admin.create_key_event(request={
    "parent": f"properties/{property_id}",
    "key_event": {
        "event_name": "purchase",
        "counting_method": KeyEvent.CountingMethod.ONCE_PER_EVENT,
    },
})
```

> **NOTA:** Los campos legacy siguen funcionando por backward compatibility
> pero se recomienda migrar al naming nuevo.
