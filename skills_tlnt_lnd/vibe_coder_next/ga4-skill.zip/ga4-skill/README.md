# ga4-skill — Skill de Claude Code

Skill instalable para **Claude Code**: dominio de **Google Analytics 4** en sus cuatro
superficies de API — Data API (reporting), Admin API (configuración de propiedades),
Measurement Protocol (eventos server-side) y BigQuery Export (datos crudos sin muestreo).
Cubre runReport, funnels, realtime, audiencias, CRUD de propiedades/streams/dimensiones,
autenticación, rate limits y gotchas del mundo real. Autocontenida.

## Cómo instalar
1. Descomprime este ZIP. Obtendrás una carpeta `ga4-skill/`.
2. Cópiala a tu directorio de skills de Claude Code:
   - **Personal:** `~/.claude/skills/ga4-skill/`
   - **Solo un proyecto:** `<tu-proyecto>/.claude/skills/ga4-skill/`
3. Reinicia Claude Code. Se activará sola al trabajar con GA4.

## Contenido
- `SKILL.md` — guía principal.
- `references/` — data-api, admin-api, measurement-protocol, bigquery-export,
  auth-and-setup, rate-limits, pitfalls-and-workarounds, ecosystem-tools, changelog-2024-2026.

Cortesía de **Talent Academy · Vibe Coder**.
