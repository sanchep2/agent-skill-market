# perplexity-search 1.0.0

Skill para buscar fuentes web con Perplexity y obtener respuestas generadas con sus referencias.
Entrega JSON y Markdown, distingue extractos y síntesis y registra el coste antes y después de cada llamada.
Requiere Python ≥ 3.9 y una clave `PERPLEXITY_API_KEY`; no instala paquetes.

Copia la carpeta completa al directorio de skills de tu agente, por ejemplo
`~/.claude/skills/perplexity-search` o `~/.codex/skills/perplexity-search`.

```bash
python3 scripts/perplexity_helper.py salud
python3 scripts/perplexity_helper.py conectar perplexity
python3 scripts/perplexity_helper.py buscar "campañas de formación online" --idioma es \
  --salida estudio --investigacion ejemplo --tope-total-usd 0.10 --json
python3 scripts/perplexity_helper.py citas --salida estudio --investigacion ejemplo
```

Copia la clave al portapapeles antes de `conectar`; también admite `--desde-fichero RUTA`.
Nunca escribas el valor en el chat ni en un argumento. `salud` no gasta ni comprueba su validez
por red. `salud --en-vivo` anuncia y hace una única búsqueda mínima de pago (tarifa 0,001 USD).

Una solicitud fast cuesta 0,001 USD por tarifa; web, 0,005 USD. Hasta cinco consultas se
facturan como una solicitud, pero consumen cinco unidades de tasa. Precios documentados en
la Fase 0 del 2026-10-15, sin medición en esta versión. No hay plan gratis verificado.

Agent fast/low síncrono exige `--tope-usd` explícito y reserva una estimación local de
0,05/0,25 USD. Esa reserva **no limita la factura del proveedor**. Se liquida con
`usage.cost.total_cost`; si falta, por cota. Consulta la derivación y las hipótesis en
`references/costes-y-limites.md`. Background y presets caros están deshabilitados: no tienen una cota de gasto garantizable.

Por defecto el libro admite 0,50 USD por llamada y 1,50 USD por investigación. Mantén el mismo
ID y directorio al continuar. Costes desconocidos se declaran, nunca se hacen pasar por cero.
`saldo` muestra gasto local, no saldo de la cuenta. Este skill no lee páginas completas.

Estado: smoke real del 2026-10-15 incorporado como captura pública normalizada y saneada de Search y Agent fast/low. Los demás fixtures son construidos desde Fase 0. Evals con y sin el skill (16-oct-2026) en `evals/resultados.md`; no se han validado en vivo todos los parámetros. Windows sin probar.
Las seis referencias enlazadas en `SKILL.md` cubren uso, parámetros, costes e integración.

Pruebas sin red, en el entorno de verificación:
`cd scripts && python3 -m unittest -v test_perplexity_helper`.
El fichero `scripts/perplexity_helper.py.bak` se conserva por instrucción de construcción;
es obsoleto y no debe ejecutarse ni importarse.
