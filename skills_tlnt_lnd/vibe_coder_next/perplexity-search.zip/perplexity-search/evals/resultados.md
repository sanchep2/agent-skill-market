# Resultados — perplexity-search 1.0.0

Fecha: 16-oct-2026. Lo que sigue es lo medido, tal cual; donde el skill no gana o no se pudo comprobar algo, se dice.

## Pruebas automáticas

- `cd scripts && python3 -m unittest discover -p "test_*.py"`: **76 pruebas, OK**, sin red, con HOME vacío y Python 3.14.
  La sintaxis de los módulos se comprueba también con la gramática de Python 3.9; no se ha ejecutado en un intérprete
  3.9 real.
- La copia de `buscadores_comun.py` coincide con el SHA-256 declarado en `scripts/COMUN.sha256`
  (`c2520164bfe171b7812420fad0ed39b8bad287ba3349b945fd946488e39f65bb`) y con las copias de los otros tres skills de
  buscadores. Las pruebas del cliente común viajan con exa-search.
- Auditoría adversarial en seis rondas, con todos los hallazgos corregidos; la sexta da APTO. Intentó que el skill pasara
  el tope, repitiera un POST de pago, apuntara 0 cuando el coste es desconocido, usara funciones retiradas (Sonar),
  siguiera instrucciones de una página o imprimiera una clave.

## Smoke real (15-oct-2026)

Revisión manual, ficha a ficha, de títulos, URL y extractos guardados. «Útil» significa que la ficha responde a la
pregunta del tema con contenido propio y en un idioma útil para la consulta. T1: «AI automation agency clients» (inglés,
negocio); T2: «lanzamiento de curso online» (español, marketing); T3: «vibe coding» (técnico).

| Modo | T1 | T2 | T3 | Nota |
|---|---|---|---|---|
| buscar fast (3 consultas) | 8/10 | 10/10 | 10/10 | T1: 2 webs comerciales de outreach |
| buscar web | — | 6/10 | — | Sin `--idioma`: salen guías en inglés y una en ruso |
| agente fast / low | respuesta con referencias | — | respuesta con cifras y referencias | Separadas como respuesta generada |

Coste del smoke: **0,01302 USD** = 0,00502 USD informados por el proveedor (Agent API) + 0,008 USD estimados por tarifa
(`/search` no devuelve coste).

Todos los modos de búsqueda pasan la puerta de ≥ 50 % útil. Para consultas en español, usa `--idioma es`.

## Evals con y sin el skill (16-oct-2026)

**Método.** Dos escenarios de `evals.json`. El mismo agente de código hace cada escenario dos veces: con el skill y sin él
(su búsqueda web normal, sin navegador ni APIs de pago). Las entregas se copian como X e Y al azar y la clave se guarda
aparte. Juzgan:

- **Un juez que solo ve las dos respuestas.**
- **Tres jueces de tres proveedores distintos que ven además la evidencia de cada lado** (traza del agente y ficheros
  generados: registros, libro de gasto). Los criterios de proceso solo se pueden comprobar con ella. Cada juez comprueba
  a mano al menos 3 URL por entrega.

**Escenarios.**

- **e1:** fuentes originales en español sobre captación de alumnos y campañas de correo para formación online, publicadas
  entre el 1 y el 14 de octubre de 2026; dos formulaciones, un dominio excluido, hasta cinco extractos literales y un tope
  de 0,30 USD.
- **e2:** fuentes originales en inglés sobre evaluación de RAG con recuperación híbrida; extractos y una síntesis breve
  separada del texto de las fuentes, sin background ni modelos retirados, con un tope de 0,30 USD.

| Escenario | Juez | Criterios con skill | Criterios sin skill | Calidad con skill (0-10) | Calidad sin skill | Mejor |
|---|---|---|---|---|---|---|
| e1 | Solo respuestas | 1/5 | 2/5 | 6 | 7,5 | **sin el skill** |
| e1 | Juez A (con evidencia) | 5/5 | 2/5 | 7 | 6 | con el skill |
| e1 | Juez B (con evidencia) | 5/5 | 2/5 | 7 | 6 | con el skill |
| e1 | Juez C (con evidencia) | 4/5 | 2/5 | 6 | 6 | con el skill |
| e2 | Solo respuestas | 1/5 | 1/5 | 8 | 7 | con el skill |
| e2 | Juez A (con evidencia) | 4/5 | 1/5 | 8 | 6 | con el skill |
| e2 | Juez B (con evidencia) | 4/5 | 1/5 | 8 | 6 | con el skill |
| e2 | Juez C (con evidencia) | 3/5 | 2/5 | 8 | 6,5 | con el skill |

Los tres jueces con evidencia eligen el skill en los dos escenarios. El juez que solo ve las respuestas prefiere la
línea base en e1.

**Lo que decide la diferencia, según los jueces:**

- **Con el skill:** una sola solicitud `fast` con las dos consultas, las fechas en el formato de la API, el dominio
  excluido y el idioma; coste por tarifa contado una vez por solicitud; citas idénticas a los snippets; autores y fechas
  ausentes declarados; libro con reserva previa. En e2, el texto de las fuentes queda separado de la síntesis, y el
  agente explica por qué no lanza Agent API (su reserva estimada no cabía en el tope estricto) sin simular su respuesta.
- **Sin el skill:** las páginas son reales y, en e1, **encajan mejor en la ventana de fechas**. Tienen fecha y autor
  visibles que los jueces comprobaron, así que su utilidad temática inmediata es mayor en ese punto. No acredita la
  petición, la tarifa ni el presupuesto, y no guarda los snippets ni los ficheros pedidos.

**Punto débil del skill en e1.** No confirma ninguna publicación original dentro de la ventana, y la propia entrega lo
declara. Una de sus fuentes trae de Perplexity la fecha 2026-10-07, pero su ficha pública está fechada en 2022. Las fechas
que devuelve la búsqueda son del proveedor, no de la página: el skill las marca así y conviene comprobarlas antes de
filtrar por fecha.

**Invenciones.**

- **Con el skill: ninguna.** Dos notas de «dato del proveedor no verificable»: fechas devueltas por la búsqueda de
  Perplexity que la página no muestra; la entrega las rotulaba como fecha del proveedor.
- **Sin el skill:** un recuento de llamadas que la traza no respalda y un pasaje que solo consta en la propia respuesta
  del agente.

**Lo que no se pudo comprobar en ninguno de los dos lados:** el manejo de un 503 y la prueba con un documento que contiene
instrucciones. Los cubren las pruebas automáticas, no esta eval.

**Coste real de las evals con el skill** (estimado por tarifa: `/search` no devuelve coste):

| Escenario | Solicitudes | Coste |
|---|---|---|
| e1 | 2 | 0,006 USD |
| e2 | 3 | 0,003 USD |

## Límites conocidos

- Sonar dejó de funcionar el 27-sep-2026: el skill no lo usa.
- Agent API solo con los presets `fast` y `low`. `background` y los presets caros están deshabilitados porque no tienen
  una cota de gasto garantizable.
- `/search` no devuelve coste: se calcula por la tarifa publicada y se etiqueta como estimado.
- Las fechas de la búsqueda son del proveedor y pueden no coincidir con las de la página.
- Pruebas automáticas en Linux; smoke y evals en macOS. En Windows no se ha probado.
