# Usar desde otro skill

Ejecuta el helper como proceso separado con Python ≥ 3.9. No depende de otra carpeta de
skills: importa su propio scripts/buscadores_comun.py, copia canónica verificada por SHA.
Si varios conectores importan el módulo común en el mismo intérprete, configurar() altera
su configuración global; prefiere procesos separados. La ficha TOML es declarativa, no
instala un adaptador en el consumidor ni prueba su compatibilidad.

```bash
python3 "$SKILL_DIR/scripts/perplexity_helper.py" buscar \
  --consulta "hybrid retrieval evaluation" --consulta "evaluación de recuperación híbrida" \
  --modo fast --n 10 --idioma en,es --salida "$SALIDA" \
  --investigacion estudio-01 --tope-usd 0.01 --tope-total-usd 0.10 --json
python3 "$SKILL_DIR/scripts/perplexity_helper.py" citas \
  --salida "$SALIDA" --investigacion estudio-01 --json
```

No hay comando leer. No uses una búsqueda por URL como prueba de lectura completa.
La ficha no ofrece una receta leer ficticia; el consumidor debe declarar esa ausencia.

## stdout y archivos

Buscar --json: registros[], coste (solicitud final o cache), coste_investigacion (texto,
desglose, desconocido), avisos[], cobertura, archivo (ruta o null).
Agent --json: registros[], coste, coste_investigacion, cobertura, archivo.
Citas --json: skill, version, titulo, consulta, consultado, registros[], fallos[], coste,
cobertura y limites, según construir_entrega del cliente común.
Salud --json: skill, version, comando, codigo, sonda, en_vivo, diagnostico (sin claves).
En salud --en-vivo --json, el anuncio de pago va a stderr antes de llamar.
Saldo --json: saldo_del_proveedor=null, motivo, gastado_este_mes_usd, libro.
Libro --ver --json y pendientes --json: objetos/listas del libro, sin llamada remota.
Conectar y libro --liberar-colgadas con --json devuelven el mismo sobre de diagnóstico
(comando/codigo/diagnostico) que salud. Errores se escriben en stderr redactado.
No intentes json.loads(stdout) sin comprobar primero el código y el comando.

Los registros mantienen el contrato descrito en entrega-y-credibilidad.md. Solo url más
texto_literal pueden alimentar cita_literal; respuesta_generada se conserva como contexto
etiquetado con referencias. Ausencias null permanecen ausentes en el consumidor.
Suma la investigación desde coste_investigacion o citas.coste, nunca desde cada registro.
Si hubo 5xx y luego éxito, el coste de la última respuesta por sí solo está incompleto.

--salida es obligatorio para guardar evidencia, no para mostrar resultados. Sin salida
se sigue manteniendo libro y caché privados, con ID sin-salida salvo --investigacion.
Con salida, ID predeterminado es la ruta absoluta. Usa ID explícito común al reanudar un
estudio y no mezcles varias investigaciones en la misma carpeta de registros.

## Códigos de salida

| Código | Significado |
|---|---|
| 0 | Operación terminada; salud es diagnóstico y puede declarar FALTA/MAL; una búsqueda vacía es válida |
| 1 | Error general, contrato o respuesta Agent con error; citas sin registros |
| 2 | Uso incorrecto o modo deshabilitado (incluye fondo/caros/reanudar/cancelar) |
| 3 | Clave ausente, mal formada o rechazada |
| 4 | Reserva no cabe en tope de llamada o presupuesto total |
| 5 | Límite del proveedor o cuota (402/429); no compra ni recarga |
| 6 | Resultado desconocido o pendientes listados; nunca volver a crear a ciegas |

402 está manejado preventivamente, no verificado para Perplexity. 401 también puede
significar falta de créditos; revisa el diagnóstico sin imprimir secretos. 403 se trata
como clave/acceso rechazado por el contrato común. No hagas reintentos externos automáticos:
Search ya incorpora hasta dos y cada nuevo intento vuelve a poder costar.

Agent exige --tope-usd escrito explícitamente (antes o después del subcomando). La reserva
estimada de fast/low se puede aumentar con --cota-usd, pero no garantiza factura máxima.
El cliente Python puede usar Sesion configurada y buscar()/agente(); no hay wrapper Agent
que active background. reanudar y cancelar fallan antes de leer claves o consultar red.
