# Parámetros y contratos

Fuentes leídas el **2026-10-15**:
[Search P1](https://docs.perplexity.ai/api-reference/search-post),
[quickstart P2](https://docs.perplexity.ai/docs/search/quickstart),
[Agent P6](https://docs.perplexity.ai/docs/agent-api/quickstart),
[background P8](https://docs.perplexity.ai/docs/agent-api/background-mode).
Contratos de Fase 0; se incorporó captura saneada del smoke real de Search y Agent fast/low del 2026-10-15, sin verificar todos los parámetros.

## Buscar: POST https://api.perplexity.ai/search

| CLI | Campo API | Límite o transformación |
|---|---|---|
| `CONSULTA…`, `--consulta`/`-c` repetible | query | 1–5 cadenas; una sola se envía como cadena |
| `--modo fast|web` | search_type | fast predeterminado |
| `--n` | max_results | 1–20, defecto 10 |
| `--dominios` repetible/comas | search_domain_filter | hasta 20 dominios o rutas; sin excluir |
| `--excluir` repetible/comas | search_domain_filter | prefijo `-` añadido por el helper; sin permitidos |
| `--desde`, `--hasta` | search_after_date_filter, search_before_date_filter | AAAA-MM-DD → MM/DD/YYYY |
| `--actualizado-desde`, `--actualizado-hasta` | last_updated_after_filter, last_updated_before_filter | mismo formato; distinto de publicación |
| `--recencia` | search_recency_filter | hour/day/week/month/year |
| `--pais` | country | código ISO alfa-2, convertido a mayúsculas |
| `--idioma` repetible/comas | search_language_filter | hasta 10 códigos de dos letras minúsculas |
| `--tokens-por-pagina` | max_tokens_per_page | entero 1–1.000.000 |
| `--tokens-total` | max_tokens | entero 1–1.000.000 |

No mezclar recencia y fechas absolutas: su precedencia no se verificó. Rangos invertidos
se rechazan. Los códigos de país/idioma se validan por forma, no mediante un registro ISO completo.
P1 permite 50 resultados solo con people; P2 dice 20. Idiomas P1=20/P2=10:
se conserva el límite menor. `people` no tiene tarifa Search independiente confirmada en Fase 0.

```json
{"query":["captación de alumnos","correo de bienvenida"],"search_type":"fast","max_results":10,"search_domain_filter":["-example.net"],"search_language_filter":["es"],"search_after_date_filter":"10/01/2026","search_before_date_filter":"10/14/2026","country":"MX","max_tokens_per_page":2048,"max_tokens":10000}
```

La respuesta documentada tiene id, results con title/url/snippet/date/last_updated, y
server_time puede ser null. El formato agrupado de múltiples consultas no consta en la Fase 0:
el parser tolera listas planas/anidadas sin atribuir índices de consulta por una suposición.
`consulta=null` y `consulta_no_atribuible` lo hacen visible. Sin results reconocible hay error
de contrato tras liquidar la tarifa. La copia normalizada no conserva last_updated en fecha.

## Agente: POST https://api.perplexity.ai/v1/agent

`--preset fast|low`, `--instrucciones TEXTO`, pregunta posicional. `--tope-usd N` explícito
obligatorio al ejecutar. `--cota-usd N` puede aumentar la reserva estimada, nunca reducirla.
`--previsualizar` muestra cuerpo/cota sin exigir clave ni tope explícito porque no ejecuta.

```json
{"preset":"low","input":"Compara enfoques y cita tus fuentes.","instructions":"Responde en español."}
```

No se envía model, tools ni max_steps; se usa el contrato preset. Aunque model/tools/max_steps
son vigentes en P6, están fuera de la interfaz permitida de v1; no se etiquetan como retirados
por el proveedor. Otros campos heredados o no verificados se bloquean por lista de permitidos.

`medium|high|xhigh`, `--fondo`, `--espera-s`, `--cancelar-al-agotar` están deshabilitados.
Las opciones reservadas `--permitir-caros`, `--permitir-xhigh`, `--permitir-fondo` no los habilitan.
P8 documenta background=true, GET /v1/agent/{id}, POST /v1/agent/{id}/cancel, pero no
confirma cota en USD, estados terminales ni TTL. No se envían esos GET/POST en esta versión.

El normalizador admite output_text u output[].content[].text y annotations con URL, además
de citations/search_results si llegan. Estas formas son hipótesis defensivas de fixtures,
**sin confirmar con ejemplos completos ni con respuesta real**. Lo irreconocible se informa
como error; nunca se reconstruye texto o se asume autor/fecha. usage.cost.total_cost sí está
documentado por P6 y se prueba su lectura. Un error Agent se entrega en el campo error.

## Opciones comunes

`--salida DIR`, `--json`, `--investigacion ID`, `--tope-usd` (defecto 0,50),
`--tope-total-usd` (defecto 1,50), `--sin-cache`. Se admiten antes y después del subcomando.
Perplexity rechaza `--tope-creditos` y `--precio-credito`: se factura en USD.
Claves solo en entorno o fichero privado, nunca como argumento de valor.
