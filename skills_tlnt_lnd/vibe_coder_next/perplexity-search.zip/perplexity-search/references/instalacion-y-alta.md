# Instalación y alta

Requisitos: Python ≥ 3.9, biblioteca estándar y acceso HTTPS al usar el proveedor.
No hay dependencias pip, navegador, cookies ni sesiones. Windows sin probar.

Copia la carpeta completa, con scripts/references/evals, a la carpeta de skills de tu agente.
Por ejemplo ~/.claude/skills/perplexity-search o ~/.codex/skills/perplexity-search.
No basta SKILL.md. No ejecutes el fichero .bak, conservado como residuo obsoleto.
La copia común se verifica contra scripts/COMUN.sha256; no edites ese módulo en este skill.

La clave se obtiene desde el panel enlazado por la documentación de
[Perplexity](https://docs.perplexity.ai/). Fase 0, 2026-10-15:
[tiers](https://docs.perplexity.ai/docs/admin/rate-limits-usage-tiers) no confirma plan gratis;
Tier 0 y sus límites no implican crédito disponible. Consulta condiciones actuales al contratar.
El skill no compra créditos ni cambia planes.

```bash
python3 scripts/perplexity_helper.py salud
# Copiar la clave al portapapeles por la interfaz del proveedor y después:
python3 scripts/perplexity_helper.py conectar perplexity
# Alternativa: ruta de un fichero privado ya existente, nunca el valor en argv:
python3 scripts/perplexity_helper.py conectar perplexity --desde-fichero /ruta/privada/clave.env
python3 scripts/perplexity_helper.py salud --json
```

Conectar lee el portapapeles o el fichero indicado y guarda claves.env con permisos 0600.
No pegues el valor en un chat, argumento, URL ni código fuente. También se admite
PERPLEXITY_API_KEY ya inyectada en el entorno; tiene precedencia sobre claves.env.
No leas otros almacenes de claves para buscar alternativas automáticamente.

Datos predeterminados en ~/.perplexity-search: claves.env, gasto.jsonl con bloqueo y cache/.
PERPLEXITY_SEARCH_HOME cambia esa carpeta, útil para pruebas aisladas. El libro registra
reservas antes del envío, y caché con caducidad de un día reduce llamadas repetidas.
No uses una carpeta compartida o sincronizada públicamente para esos datos.

Salud sin clave termina en 0 y dice qué falta. Con clave, dice «clave presente, validez no
comprobada»: no hay sonda gratis verificada. Solo --en-vivo anuncia una solicitud pagada
mínima fast/1, sin reintentos (tarifa 0,001 USD). Si falla sigue devolviendo 0 como diagnóstico
con estado MAL. No interpretes ese código como aceptación de la clave por el proveedor.

Pruebas de construcción sin red: python3 -m unittest -v test_perplexity_helper en scripts/,
en el entorno de verificación designado. Smoke real (15-oct-2026) y evals con y sin el skill (16-oct-2026): ver `evals/resultados.md`.
