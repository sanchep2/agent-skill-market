# Método y recetas

Fuentes oficiales leídas el **2026-10-15** en la Fase 0:
[Search](https://docs.perplexity.ai/api-reference/search-post),
[quickstart Search](https://docs.perplexity.ai/docs/search/quickstart),
[precios](https://docs.perplexity.ai/docs/getting-started/pricing),
[presets](https://docs.perplexity.ai/docs/agent-api/presets).
La revisión de relevancia del smoke real del 15-oct-2026 figura en [evaluación](../evals/resultados.md#smoke-real-15-oct-2026). No se midió latencia ni ahorro real.

Sin filtro de idioma los resultados mezclan idiomas: Perplexity web devolvió guías en inglés y una en ruso en el smoke real del 15-oct-2026. Usa `--idioma es` (o el idioma requerido) y revisa cada ficha; el filtro `search_language_filter` de la Fase 0 ya está expuesto como `--idioma`.

Receta: `buscar "lanzamiento de curso online" --modo web --n 10 --idioma es`. Mantén `--salida` y `--investigacion` al continuar.

| Caso | Modo y receta derivada de la capacidad documentada | Coste esperado |
|---|---|---|
| Descubrir varias formulaciones | `buscar -c "tema A" -c "tema B" --modo fast --n 10` | 0,001 USD por solicitud, 2 unidades de tasa |
| Búsqueda web estándar | `buscar "tema" --modo web --n 20` | 0,005 USD por solicitud |
| Fuentes de dominios y ventana conocidos | `buscar "tema" --dominios example.org --desde 2026-10-01 --hasta 2026-10-14` | 0,001 USD fast; filtros sin cobro por tokens según precios |
| Excluir sitios | `buscar "tema" --excluir example.com,example.net --idioma es --pais MX` | 0,001 USD fast |
| Noticias recientes | `buscar "tema" --recencia hour --tokens-por-pagina 2048` | 0,001 USD fast; fecha ausente se declara |
| Síntesis breve con referencias | `agente "pregunta" --preset fast --tope-usd 0.05` | Reserva estimada 0,05 USD; real variable; captura saneada del smoke 2026-10-15 |
| Investigación de varios pasos | `agente "pregunta" --preset low --tope-usd 0.25` | Reserva estimada 0,25 USD; real variable; captura saneada del smoke 2026-10-15 |
| Investigación high/xhigh o en fondo | Documentada, deshabilitada | Sin reserva ni envío; falta cota del proveedor |

Los ejemplos necesitan `--salida DIR` para guardar evidencia y el mismo `--investigacion ID`
al continuar. Anteponer o añadir opciones comunes funciona. `--previsualizar` no llama a red.

Las recetas son elecciones de uso de funciones documentadas, no resultados comparativos medidos.
Los presets fast/low corresponden a uno/cinco pasos en la Fase 0, pero los tokens por paso y el
precio final no se conocen antes de ejecutarlos. Las reservas son hipótesis de planificación;
ver la fórmula en [costes](costes-y-limites.md). Agent no recibe automáticamente los resultados
guardados de una búsqueda anterior: cada pregunta Agent es una nueva solicitud independiente.

1. Define necesidad, ventana e idioma antes de buscar. Agrupa hasta cinco consultas compatibles
   con los mismos filtros. Si el presupuesto es estricto, usa Search de precio fijo documentado.
2. Revisa que los resultados respondan a la pregunta. `max_tokens` acota contenido, no calidad.
   Una respuesta vacía también consume la tarifa de la solicitud.
3. El resultado de Search es un snippet del proveedor; no se afirma lectura completa de la fuente.
   Autor ausente queda ausente. Actualización no demuestra publicación dentro de la ventana.
4. Para citas, conserva el pasaje recibido con su URL y fecha si existe. Para síntesis, etiqueta
   la salida como generada y revisa las referencias; una referencia no prueba cada afirmación.
5. Ejecuta `citas` y declara menos resultados de los pedidos, duplicados, ausencias y gasto total.

No se implementan navegador, cookies, métricas sociales ni lector de páginas. Si faltan,
se declara la limitación y otro conector autorizado puede aportar esa evidencia por separado.
