# Costes y límites

Fuentes oficiales, lectura **2026-10-15** en Fase 0:
[precios P3](https://docs.perplexity.ai/docs/getting-started/pricing),
[changelog P4](https://docs.perplexity.ai/docs/resources/changelog),
[Agent P6](https://docs.perplexity.ai/docs/agent-api/quickstart),
[presets P7](https://docs.perplexity.ai/docs/agent-api/presets),
[background P8](https://docs.perplexity.ai/docs/agent-api/background-mode),
[tasas P9](https://docs.perplexity.ai/docs/admin/rate-limits-usage-tiers),
[FAQ P10](https://docs.perplexity.ai/docs/resources/faq).
Son tarifas documentadas, no mediciones ni garantía de precios futuros.

## Search: tarifa por solicitud, BUS-C1

| Modo | USD por solicitud | Reserva y liquidación |
|---|---:|---|
| fast | 0,001 | Tarifa rápida: 1 USD/1.000 |
| web | 0,005 | Tarifa estándar: 5 USD/1.000 |

Una a cinco consultas consumen **una** solicitud facturada; la tasa cuenta una unidad por
consulta. No se cobra por tokens Search. La respuesta no tiene campo de coste documentado:
`fuente_coste=tarifa`, `valoracion_estimada=true`, URL P3 y fecha en constantes y libro.
El precio se comparte entre los registros de una solicitud: **no sumar coste por registro**.
Caché del día: cero llamadas nuevas, fuente cache, no se borra el coste histórico del libro.

La reserva comprueba gastado+pendiente+cota en el mismo bloqueo para USD/créditos.
Aquí cota_creditos=0. Topes locales: 0,50 USD/llamada y 1,50 USD/investigación, configurables.
Una carrera de procesos por el último remanente permite una única llamada. Usa el mismo ID
al continuar. Otros clientes de la cuenta pueden consumir saldo fuera de este libro.

Cada intento se reserva por separado. Red/5xx/respuesta perdida: cota completa liquidada y
coste **DESCONOCIDO**, incluso cuando otro intento funciona. Se presenta coste de llamada y
`coste_investigacion` con desglose; `citas` muestra toda la investigación. Respuesta correcta
Agent sin usage.cost se liquida **por cota**, que se distingue de respuesta perdida.

## Agent síncrono: excepción limitada de ESPEC-02

La Fase 0 §2 solo documenta presets/max_steps y `usage.cost.total_cost`, **no un máximo USD**.
Por ello no se afirma un límite contractual. ESPEC-02 permite fast/low síncronos con una
estimación documentada por margen, tope explícito y liquidación informada. Esa instrucción
posterior prevalece sobre el default «agente deshabilitado» de la decisión diferida de la issue.

Las estimaciones siguientes son **cálculos propios hipotéticos**, no precios de los presets:

- Proxy: tarifa P3 de claude-sonnet-4-6, 3 USD/1M entrada y 15 USD/1M salida. Ese modelo
  NO es el modelo documentado de fast/low; se usa solo como base conservadora de planificación.
- Hipótesis por paso: 5.000 tokens de entrada y 500 de salida, una web_search a 0,0025 USD
  (precio anterior, mayor que el rápido 0,001 publicado en el cambio de octubre de P4).
- Base hipotética: 5.000×3/1M + 500×15/1M + 0,0025 = **0,025 USD/paso**.
- fast, un paso: 0,025×1×margen 2 = **0,05 USD de reserva**.
- low, cinco pasos: 0,025×5×margen 2 = **0,25 USD de reserva**.

El volumen de tokens real, fetch_url y otras herramientas no están acotados por esa hipótesis.
No es una estimación estadística validada ni permite garantizar gasto máximo. `--cota-usd`
solo puede subir estas reservas. `--tope-usd` explícito debe admitirlas; no se envía al proveedor.
fast y low se probaron en vivo en el smoke del 2026-10-15. No se reintenta Agent, ni ante 5xx. Si usage.cost.total_cost supera la
reserva, se registra entero, aparece aviso y se bloquea otra llamada Agent en esa sesión.
Otra invocación vuelve a consultar el libro, pero no conserva ese cortacircuitos en memoria.

Coste real informado: usage.cost.total_cost; desglose input_cost/output_cost/tool_calls_cost
si existe. Ausente/inválido/negativo/NaN: por cota. «Real» significa informado por la respuesta,
no validación de una factura. El importe real puede superar el presupuesto admitido localmente.

## BUS-C2: fondo y presets caros deshabilitados

Fase 0 §2: «Segundo plano: background=true, consulta con GET /v1/agent/{id} y cancelación
con POST /v1/agent/{id}/cancel [P8]» y «El de Agent API es NO VERIFICADO» (TTL).
P6/P7 solo documentan pasos/presets: **max_steps×tarifa por paso no garantiza un máximo**.
No hay cota de USD confirmada que incluya tokens y herramientas. Por BUS-C2:

- Background no se crea, consulta ni cancela, aun con --permitir-fondo.
- medium/high/xhigh quedan documentados y deshabilitados; --permitir-xhigh y tope no bastan.
- pendientes es local. reanudar/cancelar devuelven código 2 y no llaman al proveedor.
- Los tests de respuesta perdida, timeout y cancelación ejercitan el cliente común con un
  proveedor **sintético** con cota impuesta; no prueban un contrato background de Perplexity.

## Errores, tasas y salud BUS-C4

Search: 50 unidades de consulta/s, ráfaga 50 en todos los tiers según P9. Agent Tier 0: 1 QPS.
Se espacian solicitudes locales ≥0,1 s y Agent ≥1 s; no es un control global entre procesos.
Reintentos Search: como máximo dos para red/5xx/429. Retry-After hasta 30 s; si pide más se
para sin reintentar. 401/402/403 paran proveedor en esa sesión. Se conservan cabeceras de tasa.
P10: 401 puede ser clave inválida o cuenta sin créditos. 402 no está documentado para este
proveedor: se maneja preventivamente como límite por el contrato común, sin afirmar haberlo observado.

Sin sonda gratis verificada, salud devuelve 0 y explica FALTA/SIN VALIDAR. salud --en-vivo
anuncia una búsqueda fast/1 de 0,001 USD, sin reintentos y con techo local hasta 0,05 USD.
El diagnóstico devuelve 0 incluso si esa prueba falla y lo etiqueta MAL; no es validación de clave.
Con --json el mensaje completo está en diagnostico, con en_vivo y sonda=ninguna.
saldo no llama: no hay endpoint gratuito confirmado ni plan gratis verificado en P9.

## No implementado o pendiente de verificar

- Sonar: «Sonar Chat Completions support ended on September 27, 2026», Fase 0 §2,
  [migración P5](https://docs.perplexity.ai/docs/agent-api/migrate-from-sonar/overview), 2026-10-15.
  No /chat/completions ni /v1/sonar aunque pudieran responder por migración gradual.
- search_mode no aparece en P1: NO VERIFICADO; bloqueado. people: tarifa Search no confirmada.
- TTL Agent, forma agrupada multiconsulta, estados y texto/annotations completos: sin evidencia
  real; se documentan hipótesis defensivas en parámetros y fixtures, no se afirman como hechos.
- Modelos directos: fuera de v1; P4 anuncia retirada de openai/gpt-5.4 y openai/gpt-5 el 24-oct-2026.
- Orchestrator, Embeddings, Decisions API, streaming y MCP: fuera de alcance; no son fallbacks.

## Coste después del smoke del 2026-10-15

La entrega y `coste_entrega()` desglosan el coste por origen, en texto y JSON.
El total liquidado es contable: no implica que todo sea una factura o una estimación.
En `desglose`:

- `usd_real_proveedor`: USD informados por el proveedor (Exa `costDollars`, Perplexity Agent `usage.cost`).
- `usd_estimado_tarifa`: USD calculados con tarifa, sin medición monetaria de esa llamada.
- `usd_valoracion_creditos`: conversión estimada a USD de créditos de Firecrawl; nunca USD reales informados.
- `creditos_informados_proveedor`: créditos medidos por el proveedor, separados de su valoración monetaria.
- `usd_cota_sin_coste_real`: cota liquidada cuyo coste real es DESCONOCIDO, incluso con HTTP exitoso sin uso.
- `reservado_sin_liquidar_usd` y `reservado_sin_liquidar_creditos`: reservas pendientes, fuera del total liquidado.

`valoracion_estimada: true` indica que hay componentes estimados; no etiqueta los USD
reales del proveedor como estimados. `coste_real_desconocido: true` cubre cotas sin coste real y pendientes. El flag preexistente `desconocido` conserva su significado de respuesta incierta (pérdida o pendiente), para mantener los códigos de salida de respuestas válidas sin uso informado. No sumar una llamada por cada resultado ni sumar créditos a USD.
