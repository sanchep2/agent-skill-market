#!/usr/bin/env bash
# probar-sonda.sh — pasa casos-sonda.tsv por la puerta y comprueba veredicto y motivo.
#
#   bash tests/probar-sonda.sh
#
# Sale 0 si todos los casos dan lo esperado. Es la prueba de que la puerta es
# fail-closed: cualquier maquina que no sea la de referencia tiene que rechazarse,
# y con el motivo correcto — no basta con que rechace por cualquier cosa.

set -uo pipefail
AQUI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SONDA="$AQUI/../scripts/sonda.sh"
FAKE="$AQUI/fake-nvidia-smi.sh"
CASOS="$AQUI/casos-sonda.tsv"

pasa=0; falla=0

while IFS=$'\t' read -r nombre esperado entorno fragmento; do
  case "$nombre" in ''|'#'*) continue ;; esac

  # El entorno del caso se aplica solo a esta invocacion.
  env_args=()
  if [ "$entorno" != "-" ]; then
    # Se trocea por espacios, asi que en el TSV los nombres de GPU van con '_' y se
    # dejan tal cual: sustituir '_' por espacio aqui destrozaria nombres de variable
    # como MIN_DISCO_MODELOS_GB.
    for asignacion in $entorno; do env_args+=("$asignacion"); done
  fi

  salida="$(env "${env_args[@]}" NVIDIA_SMI="$FAKE" DRY_RUN=1 bash "$SONDA" 2>&1)"
  rc=$?
  veredicto="$([ $rc -eq 0 ] && echo autoriza || echo rechaza)"

  problema=""
  [ "$veredicto" != "$esperado" ] && problema="esperaba $esperado y dio $veredicto"
  if [ -z "$problema" ] && [ "$esperado" = "rechaza" ] && [ "$fragmento" != "-" ]; then
    grep -qF -- "$fragmento" <<<"$salida" || problema="rechaza, pero no por el motivo esperado ('$fragmento')"
  fi

  if [ -z "$problema" ]; then
    printf '  OK    %s\n' "$nombre"; pasa=$((pasa + 1))
  else
    printf '  FALLO %s — %s\n' "$nombre" "$problema"; falla=$((falla + 1))
    printf '%s\n' "$salida" | sed 's/^/          | /'
  fi
done <"$CASOS"

printf '\n  %d casos correctos · %d fallidos\n\n' "$pasa" "$falla"
[ "$falla" -eq 0 ]
