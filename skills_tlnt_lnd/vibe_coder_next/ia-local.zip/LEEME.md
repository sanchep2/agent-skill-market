# IA local en tu máquina

Este paquete monta en tu ordenador un servidor de inteligencia artificial **tuyo**: el
modelo corre en tus tarjetas gráficas, no sale nada a internet, y no hay contador de
tokens corriendo mientras trabajas.

No es «lo mismo pero gratis». Es otra forma de trabajar: cuando el coste marginal es
cero puedes **derrochar** —lanzar la misma tarea con cincuenta prompts distintos, dejar
agentes trabajando toda la noche, procesar tus diez mil fotos, equivocarte doscientas
veces seguidas—, y derrochar es como se aprende.

---

## Antes de nada: ¿tu equipo llega?

Esto **no** vale para cualquier ordenador. Necesitas:

- **Exactamente 2 tarjetas gráficas NVIDIA idénticas**, Blackwell (serie RTX 50 o
  posterior), de **16 GB o más cada una**
- **Ubuntu** con systemd
- **70 GB** libres de disco
- El driver propietario de NVIDIA ya instalado

Antes de instalar nada, compruébalo:

```bash
bash ia-local/scripts/sonda.sh
```

No cambia nada en tu equipo y no necesita permisos de administrador. Te dirá si puedes
seguir o **exactamente qué te falta y cuánto**.

Si tu equipo no llega, el montaje se para y te lo dice. No instala una versión recortada
haciéndola pasar por esta: solo se conoce el comportamiento de esta configuración
concreta, y montar otra cosa sería adivinar.

---

## Cómo usarlo

### Opción A — con un asistente de IA que soporte *skills*

Copia la carpeta `ia-local/` dentro de `.claude/skills/` de tu proyecto. A partir de ahí
puedes pedirle a tu asistente que te monte la IA local y él sabrá qué hacer: el skill le
explica todo el procedimiento, los errores conocidos y cómo verificar cada paso.

### Opción B — tú, a mano

No hace falta ningún asistente. Los scripts funcionan solos:

```bash
bash ia-local/scripts/sonda.sh          # ¿llega tu equipo?
bash ia-local/scripts/montar.sh --dry-run   # qué haría, sin tocar nada
sudo bash ia-local/scripts/montar.sh    # montarlo
bash ia-local/scripts/verificar.sh      # comprobar
bash ia-local/scripts/banco.sh          # medir TU máquina
```

Y para quitarlo todo: `sudo bash ia-local/scripts/desmontar.sh`.

---

## Qué te deja montado

- Un **modelo de 35.000 millones de parámetros** corriendo en tus dos tarjetas
- **Cinco usuarios a la vez**: tú y cuatro agentes trabajando en paralelo, sin cola
  en el trabajo del día a día. Si alguien mete un contexto enorme los demás lo notan
  — cuánto y por qué, medido, en `references/05-cinco-usuarios-y-hermes.md`
- Dos modos: **`qwen`** (rápido, el del día a día) y **`qwent`** (pensante, para depurar)
- Un **medidor** que te dice quién ha consumido qué, con histórico
- Opcionalmente, el modelo dentro de tu asistente de código, conviviendo con los modelos
  de pago en el mismo selector

Todo arranca solo y escucha únicamente en tu propio ordenador.

---

## Por dónde empezar a leer

| Quiero… | Abre |
|---|---|
| Saber si mi equipo vale y por qué esos números | `references/01-requisitos-y-sonda.md` |
| Entender qué hace cada pieza del motor | `references/02-motor-vllm.md` |
| Saber cuándo usar el modo rápido y cuándo el pensante | `references/03-modelo-y-muestreo.md` |
| Usarlo desde mi asistente de código | `references/04-puente-y-claude-code.md` |
| Enchufar los cuatro agentes | `references/05-cinco-usuarios-y-hermes.md` |
| Saber si mis números son normales | `references/06-medir-tu-maquina.md` |
| **Algo no arranca** | `references/07-averias.md` |
| **Ya funciona, ¿y ahora qué construyo?** | `references/08-que-hacer-con-ella.md` |

Si solo vas a leer una, que sea la última.

---

## Tres cosas que te van a pasar

Salen de haber construido cosas de verdad con este modelo, no de la teoría:

**No comprueba su trabajo.** Te dirá que terminó cuando no ha terminado. No por mentir:
porque no vuelve a mirar. Si algo importa, lo verificas tú o lo verifica un script.

**Encuentra lo que da error, no lo que está mal.** Lo que falla ruidosamente lo arregla
muy bien. Lo que está mal pero funciona —un fallo de seguridad, una promesa incumplida—
no lo verá jamás, porque nadie se lo pide.

**Los datos verificables hay que verificarlos.** Cuando afirme un número, una versión o
una dirección, compruébalo. No inventa por maldad: rellena huecos con lo que suena
plausible.

---

## Honestidad sobre lo que no está probado

Dos cosas de este paquete **no están verificadas**, y así lo dice también el `SKILL.md`
en vez de disimularlo:

- **Que todo vuelva solo tras apagar y encender el ordenador.** Los servicios están
  configurados para arrancar solos, pero el ciclo completo de reinicio no se ha
  ejercitado. Después de montarlo, reinicia y corre `verificar.sh`.
- **Que montarlo dos veces seguidas no duplique nada.** Está escrito para que así sea y
  se comprobó en simulación, pero no ejecutado dos veces sobre una máquina real.

Los números de rendimiento que aparecen en la documentación son de **una** máquina
concreta (dos RTX 5060 Ti). Otro par de tarjetas que pase la comprobación puede rendir
distinto: por eso tienes `banco.sh`, para quedarte con los tuyos.
