# Authentication and Signing

## Table of Contents

1. [Two Signing Mechanisms Overview](#1-two-signing-mechanisms-overview)
2. [L1 Action Signing (Phantom Agent)](#2-l1-action-signing-phantom-agent)
3. [Phantom Agent Construction](#3-phantom-agent-construction)
4. [EIP-712 Domain Details](#4-eip-712-domain-details)
5. [User-Signed Action Signing](#5-user-signed-action-signing)
6. [Nonce Management](#6-nonce-management)
7. [API Wallets (Agent Wallets)](#7-api-wallets-agent-wallets)
8. [API Wallets and Subaccounts](#8-api-wallets-and-subaccounts)
9. [Python SDK Setup with API Wallets](#9-python-sdk-setup-with-api-wallets)
10. [TypeScript SDK Setup with API Wallets](#10-typescript-sdk-setup-with-api-wallets)
11. [Action Type Taxonomy](#11-action-type-taxonomy)
12. [Common Signing Errors and Debugging](#12-common-signing-errors-and-debugging)

---

## 1. Two Signing Mechanisms Overview

Hyperliquid uses two distinct EIP-712 signing mechanisms depending on the action type. Choosing the wrong one produces invalid signatures.

| Property | L1 Actions (Trading) | User-Signed Actions (Admin/Transfers) |
|----------|---------------------|--------------------------------------|
| Chain ID | **1337** | **42161** (mainnet) / **421614** (testnet) |
| EIP-712 Domain Name | `"Exchange"` | `"HyperliquidSignTransaction"` |
| Mechanism | Phantom agent construction | Direct EIP-712 signing |
| Covers | order, cancel, modify, leverage, TWAP, noop | transfers, withdraw, approveAgent, staking |
| Signing Key | Master wallet OR API wallet | Master wallet ONLY |
| vaultAddress support | Yes (for subaccount/vault trading) | No |

**Rule of thumb**: Actions that move funds or manage account permissions use user-signed. Actions that trade or manage positions use L1 phantom agent signing.

---

## 2. L1 Action Signing (Phantom Agent)

L1 actions go through a multi-step process that creates a "phantom agent" as an intermediary signing construct. This allows API wallets to sign on behalf of the master account without having direct access to funds.

### Step-by-Step Process

1. **Serialize** the action payload using **msgpack** (field order matters -- follow the exact field ordering from the SDK).
2. **Append** the nonce (as bytes) and vault_address (as bytes, or null if not trading on behalf of a vault/subaccount).
3. **Hash** the serialized bytes with **keccak256** to produce a `connectionId`.
4. **Construct the phantom agent** object with a `source` field and the `connectionId`.
5. **Sign** the phantom agent via EIP-712 using the `Exchange` domain.

### Serialization Example (Conceptual)

```python
import msgpack
from eth_abi import encode
from web3 import Web3

# 1. Serialize action with msgpack
action = {"type": "order", "orders": [...], "grouping": "na"}
action_bytes = msgpack.packb(action)

# 2. Append nonce and vault_address
nonce_bytes = nonce.to_bytes(8, "big")
# vault_address_bytes = bytes(20) if no vault, else bytes.fromhex(vault_address[2:])

# 3. Hash with keccak256
connection_id = Web3.keccak(action_bytes + nonce_bytes + vault_address_bytes)

# 4. Construct phantom agent
phantom_agent = {
    "source": "a",  # "a" for mainnet, "b" for testnet
    "connectionId": connection_id
}

# 5. Sign via EIP-712 (see domain details in section 4)
```

**Important**: Msgpack field ordering is critical. Using the wrong field order changes the hash and produces an invalid signature. Always use the official SDK to avoid subtle serialization bugs.

---

## 3. Phantom Agent Construction

The phantom agent is a lightweight construct that encodes the intent of an action into a signable EIP-712 message.

### Structure

```json
{
  "source": "a",
  "connectionId": "0x<32-byte-keccak256-hash>"
}
```

### Source Field

| Network | Source Value |
|---------|-------------|
| Mainnet | `"a"` |
| Testnet | `"b"` |

Using the wrong source value produces valid-looking but rejected signatures.

### EIP-712 Types for Phantom Agent

```json
{
  "Agent": [
    {"name": "source", "type": "string"},
    {"name": "connectionId", "type": "bytes32"}
  ]
}
```

The primary type is `"Agent"`. The `connectionId` is the keccak256 hash of the msgpack-serialized action concatenated with the nonce and vault address bytes.

---

## 4. EIP-712 Domain Details

### L1 Actions Domain (Phantom Agent)

```json
{
  "name": "Exchange",
  "version": "1",
  "chainId": 1337,
  "verifyingContract": "0x0000000000000000000000000000000000000000"
}
```

This domain is the same for both mainnet and testnet. The mainnet/testnet distinction is encoded in the phantom agent `source` field (`"a"` vs `"b"`), not in the domain.

### User-Signed Actions Domain

```json
{
  "name": "HyperliquidSignTransaction",
  "version": "1",
  "chainId": 42161,
  "verifyingContract": "0x0000000000000000000000000000000000000000"
}
```

For testnet user-signed actions, the `chainId` changes:

```json
{
  "name": "HyperliquidSignTransaction",
  "version": "1",
  "chainId": 421614,
  "verifyingContract": "0x0000000000000000000000000000000000000000"
}
```

### Chain ID Summary

| Context | Mainnet | Testnet |
|---------|---------|---------|
| L1 action signing (phantom agent) | 1337 | 1337 |
| User-signed action signing | 42161 | 421614 |
| HyperEVM RPC | 999 | 998 |

See [connection-and-endpoints.md](connection-and-endpoints.md) for the full chain ID reference.

---

## 5. User-Signed Action Signing

User-signed actions use direct EIP-712 signing without the phantom agent intermediary. Each action type has its own primary type in the EIP-712 schema.

### How It Works

1. Construct the EIP-712 typed data with the `HyperliquidSignTransaction` domain.
2. The primary type varies by action (e.g., `HyperliquidTransaction:SpotSend`, `HyperliquidTransaction:Withdraw`).
3. Sign directly with the master wallet private key.
4. API wallets **cannot** sign user-signed actions.

### Actions That Require User Signing

All transfer and account management actions are user-signed. They include additional fields in their payload:

```json
{
  "hyperliquidChain": "Mainnet",
  "signatureChainId": "0xa4b1"
}
```

- `hyperliquidChain`: `"Mainnet"` or `"Testnet"`
- `signatureChainId`: `"0xa4b1"` (hex for 42161 on mainnet) or `"0x66eee"` (hex for 421614 on testnet)

### Example: USDC Transfer (User-Signed)

```python
# This is handled internally by the SDK, shown for understanding
eip712_data = {
    "domain": {
        "name": "HyperliquidSignTransaction",
        "version": "1",
        "chainId": 42161,
        "verifyingContract": "0x0000000000000000000000000000000000000000"
    },
    "primaryType": "HyperliquidTransaction:UsdSend",
    "types": {
        "HyperliquidTransaction:UsdSend": [
            {"name": "hyperliquidChain", "type": "string"},
            {"name": "destination", "type": "string"},
            {"name": "amount", "type": "string"},
            {"name": "time", "type": "uint64"}
        ]
    },
    "message": {
        "hyperliquidChain": "Mainnet",
        "destination": "0xRecipientAddress",
        "amount": "100.0",
        "time": 1734567890123
    }
}
```

---

## 6. Nonce Management

Nonces prevent replay attacks and ensure action ordering. Hyperliquid uses a timestamp-based nonce system with specific constraints.

### Rules

| Rule | Detail |
|------|--------|
| Format | Current timestamp in **milliseconds** |
| Valid window | Must be within `(T - 2 days, T + 1 day)` of the block timestamp |
| Storage | **100 highest nonces** stored per signer address |
| Uniqueness | New nonce must be > smallest stored AND never previously used |
| Tracking scope | Per **signer** (private key), not per account |
| Subaccount sharing | Subaccounts sharing the same API wallet share nonce tracker |

### Best Practices

```python
import time

def generate_nonce() -> int:
    """Generate a nonce using current timestamp in milliseconds."""
    return int(time.time() * 1000)
```

For high-frequency systems, use an atomic counter that starts at the current timestamp and increments:

```python
import threading
import time

class NonceManager:
    def __init__(self):
        self._lock = threading.Lock()
        self._last_nonce = int(time.time() * 1000)

    def next(self) -> int:
        with self._lock:
            now = int(time.time() * 1000)
            self._last_nonce = max(now, self._last_nonce + 1)
            return self._last_nonce

nonce_mgr = NonceManager()
```

### Nonce Invalidation with Noop

The `noop` action consumes a nonce without performing any trading action. This is useful for:
- Invalidating a nonce that may have been compromised
- Advancing the nonce counter without side effects
- Saving rate limits compared to a cancel action

```json
{
  "action": {"type": "noop"},
  "nonce": 1734567890123,
  "signature": {"r": "0x...", "s": "0x...", "v": 27}
}
```

### Per-Signer Tracking

Nonces are tracked per private key (signer), not per Hyperliquid account. This means:
- Two different API wallets for the same master account have independent nonce spaces.
- One API wallet shared across multiple subaccounts shares a single nonce tracker -- this causes collisions.
- Always use **separate API wallets per subaccount** to avoid nonce conflicts.

---

## 7. API Wallets (Agent Wallets)

API wallets (also called agent wallets) are delegated signing keys that can execute L1 trading actions on behalf of a master account without having access to funds.

### Characteristics

| Property | Detail |
|----------|--------|
| Creation | Via `approveAgent` action (user-signed) or the web UI at `app.hyperliquid.xyz/API` |
| Capabilities | Sign **L1 actions only** (orders, cancels, modify, leverage, TWAP) |
| Restrictions | Cannot perform transfers, withdrawals, or other user-signed actions |
| State | **Stateless** -- no funds, no positions, no balance |
| Limits | **1 unnamed + 3 named** per account, **+2 additional named per subaccount** |

### Creating an API Wallet

#### Via the Web UI

1. Navigate to `https://app.hyperliquid.xyz/API`
2. Click "Create API Wallet"
3. Optionally name the wallet (named wallets do not replace existing unnamed wallets)
4. Save the generated private key securely

#### Via the SDK

```python
# Python SDK
response, agent_key = exchange.approve_agent("my_bot_v1")
print(f"Agent private key: {agent_key}")
print(f"Response: {response}")
# Save agent_key securely -- it cannot be retrieved later
```

```typescript
// TypeScript SDK (@nktkas/hyperliquid)
const result = await exchange.approveAgent({
  agentAddress: "0xNewAgentAddress",
  agentName: "my_bot_v1",
  nonce: Date.now(),
});
```

### Unnamed vs Named Wallets

| Type | Limit | Behavior on New Registration |
|------|-------|------------------------------|
| Unnamed | 1 per account | Registering a new unnamed wallet **deregisters** the old one |
| Named | 3 per account + 2 per subaccount | Independent; does not affect other wallets |

### Critical Rules

- **Never reuse deregistered agent wallet addresses.** Once an agent wallet is deregistered, its address should never be used again for any purpose.
- **Query with master address, not agent address.** When calling info endpoints (positions, balances, orders), always use the master or subaccount address. Using the agent wallet address returns empty results.
- **One API wallet per trading process.** Multiple processes sharing the same API wallet cause nonce collisions.

---

## 8. API Wallets and Subaccounts

Each subaccount requires its own dedicated API wallet(s). Sharing API wallets across subaccounts causes nonce collisions because nonces are tracked per signer (private key).

### Architecture

```
Master Account (0xMaster)
  |-- API Wallet A (for master account trading)
  |-- Subaccount 1 (0xSub1)
  |     |-- API Wallet B (dedicated to Sub1)
  |-- Subaccount 2 (0xSub2)
        |-- API Wallet C (dedicated to Sub2)
```

### Setup Pattern

```python
import eth_account
from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants

# Master account trading
master_agent = eth_account.Account.from_key("0xAGENT_KEY_A")
master_exchange = Exchange(
    master_agent,
    constants.MAINNET_API_URL,
    account_address="0xMasterAddress"
)

# Subaccount 1 trading
sub1_agent = eth_account.Account.from_key("0xAGENT_KEY_B")
sub1_exchange = Exchange(
    sub1_agent,
    constants.MAINNET_API_URL,
    account_address="0xSub1Address",
    vault_address="0xSub1Address"  # Trade on behalf of subaccount
)

# Subaccount 2 trading
sub2_agent = eth_account.Account.from_key("0xAGENT_KEY_C")
sub2_exchange = Exchange(
    sub2_agent,
    constants.MAINNET_API_URL,
    account_address="0xSub2Address",
    vault_address="0xSub2Address"
)
```

### Subaccount Limits

- Up to **10 subaccounts** per master account
- Each subaccount has isolated balances, positions, and PnL
- Trading volume rolls up to the master account for fee tier calculations
- Create via `createSubAccount` action (user-signed by master)
- Trade on behalf via the `vaultAddress` field in exchange requests

See [exchange-actions.md](exchange-actions.md) for `createSubAccount` and vault trading details.

---

## 9. Python SDK Setup with API Wallets

### Installation

```bash
pip install hyperliquid-python-sdk  # v0.22.0, Python >= 3.9
```

### Read-Only Client

```python
from hyperliquid.info import Info
from hyperliquid.utils import constants

# No private key needed for read-only operations
info = Info(constants.MAINNET_API_URL, skip_ws=True)

# Query market data
mids = info.all_mids()
print(f"BTC: {mids['BTC']}")

# Query user state (use master address, NOT agent address)
state = info.user_state("0xMasterAddress")
print(f"Account value: {state['marginSummary']['accountValue']}")
```

### Trading Client with Master Wallet

```python
import eth_account
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants

wallet = eth_account.Account.from_key("0xMASTER_PRIVATE_KEY")
exchange = Exchange(wallet, constants.MAINNET_API_URL, account_address=wallet.address)

# Place order (signed with master key)
result = exchange.order("ETH", True, 0.1, 2800.0, {"limit": {"tif": "Gtc"}})
```

### Trading Client with API Wallet

```python
import eth_account
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants

# The API wallet signs, but trades appear on the master account
agent_wallet = eth_account.Account.from_key("0xAGENT_PRIVATE_KEY")
exchange = Exchange(
    agent_wallet,
    constants.MAINNET_API_URL,
    account_address="0xMASTER_PUBLIC_ADDRESS"  # The master wallet address
)

# Place order (signed with agent key, executes on master account)
result = exchange.order("ETH", True, 0.1, 2800.0, {"limit": {"tif": "Gtc"}})
```

### Testnet Configuration

```python
from hyperliquid.utils import constants

# Swap MAINNET_API_URL for TESTNET_API_URL
info = Info(constants.TESTNET_API_URL, skip_ws=True)
exchange = Exchange(wallet, constants.TESTNET_API_URL, account_address=wallet.address)
```

### WebSocket with Authentication Context

```python
info = Info(constants.MAINNET_API_URL, skip_ws=False)

# Subscribe to user-specific channels (use master address)
info.subscribe(
    {"type": "orderUpdates", "user": "0xMasterAddress"},
    lambda data: print("Order update:", data)
)
info.subscribe(
    {"type": "userFills", "user": "0xMasterAddress"},
    lambda data: print("Fill:", data)
)
```

---

## 10. TypeScript SDK Setup with API Wallets

### @nktkas/hyperliquid (Recommended)

```bash
npm i @nktkas/hyperliquid
```

```typescript
import {
  HttpTransport,
  InfoClient,
  ExchangeClient,
  SubscriptionClient,
  WebSocketTransport,
} from "@nktkas/hyperliquid";
import { privateKeyToAccount } from "viem/accounts";

// Read-only client
const transport = new HttpTransport();
const info = new InfoClient({ transport });

// Trading with master wallet
const masterWallet = privateKeyToAccount("0xMASTER_PRIVATE_KEY");
const exchange = new ExchangeClient({ transport, wallet: masterWallet });

// Trading with API wallet
const agentWallet = privateKeyToAccount("0xAGENT_PRIVATE_KEY");
const agentExchange = new ExchangeClient({
  transport,
  wallet: agentWallet,
  // The SDK maps this to the master account internally
});

// Place order via agent wallet
await agentExchange.order({
  orders: [{ a: 0, b: true, p: "95000", s: "0.01", r: false, t: { limit: { tif: "Gtc" } } }],
  grouping: "na",
});

// WebSocket subscriptions
const wsTransport = new WebSocketTransport();
const subs = new SubscriptionClient({ transport: wsTransport });

await subs.orderUpdates({ user: "0xMasterAddress" }, (data) => {
  console.log("Order update:", data);
});
```

### nomeida/hyperliquid (Higher-Level API)

```bash
npm i hyperliquid  # Requires Node.js 22+ for native WebSocket
```

```typescript
const { Hyperliquid } = require("hyperliquid");

// With API wallet
const sdk = new Hyperliquid({
  privateKey: "0xAGENT_PRIVATE_KEY",
  testnet: false,
  walletAddress: "0xMASTER_ADDRESS",  // Required for API Agent Wallets
});

await sdk.exchange.placeOrder({
  coin: "BTC-PERP",
  is_buy: true,
  sz: 1,
  limit_px: 30000,
  order_type: { limit: { tif: "Gtc" } },
  reduce_only: false,
});

// WebSocket
await sdk.connect();
sdk.subscriptions.subscribeToAllMids((data) => console.log(data));
```

Note: nomeida/hyperliquid uses `BTC-PERP`/`ETH-PERP` format (not raw indices) and includes built-in rate limiting and auto asset map refresh.

### CCXT Integration

```python
import ccxt

exchange = ccxt.hyperliquid({
    "walletAddress": "0xMASTER_ADDRESS",
    "privateKey": "0xPRIVATE_KEY",
})
await exchange.load_markets()

# Symbol format: BTC/USDC:USDC
order = await exchange.create_order("BTC/USDC:USDC", "limit", "buy", 0.001, 95000)
balance = await exchange.fetch_balance()
```

CCXT adds abstraction overhead. For latency-sensitive applications, use the direct SDKs.

---

## 11. Action Type Taxonomy

### L1 Actions (Phantom Agent Signing, Chain ID 1337)

These actions use the phantom agent construction and can be signed by either the master wallet or an API wallet.

| Action Type | Purpose |
|-------------|---------|
| `order` | Place one or more orders |
| `cancel` | Cancel orders by OID |
| `cancelByCloid` | Cancel orders by client order ID |
| `modify` | Modify a single order |
| `batchModify` | Modify multiple orders |
| `scheduleCancel` | Dead man's switch |
| `updateLeverage` | Change leverage for an asset |
| `updateIsolatedMargin` | Add/remove isolated margin |
| `topUpIsolatedOnlyMargin` | Top up isolated-only margin |
| `vaultTransfer` | Deposit/withdraw from vault |
| `twapOrder` | Place TWAP order |
| `twapCancel` | Cancel TWAP order |
| `noop` | Invalidate nonce (no action) |
| `reserveRequestWeight` | Purchase additional rate limit capacity |

### User-Signed Actions (Direct EIP-712, Chain ID 42161/421614)

These actions use direct EIP-712 signing and **must** be signed by the master wallet. API wallets cannot sign these.

| Action Type | Purpose |
|-------------|---------|
| `usdSend` | Send USDC to another user |
| `spotSend` | Send spot token to another user |
| `usdClassTransfer` | Transfer between spot and perp wallets |
| `withdraw3` | Withdraw to Arbitrum |
| `approveAgent` | Create/register API wallet |
| `approveBuilderFee` | Approve builder fee for an address |
| `tokenDelegate` | Delegate HYPE to validator |
| `cDeposit` | Stake HYPE |
| `cWithdraw` | Unstake HYPE (7-day queue) |
| `sendAsset` | Generalized asset transfer |
| `sendToEvmWithData` | Send to EVM with calldata |
| `setReferrer` | Set referral code |
| `createSubAccount` | Create new subaccount |

See [exchange-actions.md](exchange-actions.md) for the full payload format of each action.

---

## 12. Common Signing Errors and Debugging

| Error | Likely Cause | Fix |
|-------|-------------|-----|
| `"User or API Wallet 0x... does not exist."` | Wrong recovered signer | Verify chain ID, signing key, and serialization order |
| Empty results from info queries | Querying with agent address | Use the master/subaccount address, never the agent wallet address |
| Signature rejected on testnet | Using mainnet signing params | Use `"b"` for phantom agent source, `421614` for user-signed chain ID |
| Nonce already used | Nonce collision | Use atomic counter; ensure separate API wallets per process |
| `"InvalidSignature"` | Wrong signing mechanism | Check if action is L1 (phantom agent) vs user-signed (direct EIP-712) |

### Debugging Checklist

1. **Correct chain ID?** L1 actions = 1337, user-signed = 42161 (mainnet) or 421614 (testnet).
2. **Correct domain name?** L1 = `"Exchange"`, user-signed = `"HyperliquidSignTransaction"`.
3. **Correct phantom agent source?** Mainnet = `"a"`, testnet = `"b"`.
4. **Using master address for queries?** Never query with the agent wallet address.
5. **Nonce fresh?** Must be within the 2-day past / 1-day future window and not previously used.
6. **Msgpack field order correct?** Use the SDK rather than manual serialization.
7. **No trailing zeros?** Price and size strings must not have trailing zeros.

---

**Cross-references:**
- [connection-and-endpoints.md](connection-and-endpoints.md) -- Base URLs, chain IDs, testnet vs mainnet configuration
- [exchange-actions.md](exchange-actions.md) -- Full action payloads and the exchange request envelope
- [info-queries.md](info-queries.md) -- Info endpoint queries (always use master address, not agent address)
