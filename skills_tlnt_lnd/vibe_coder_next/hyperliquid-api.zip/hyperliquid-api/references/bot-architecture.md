# Bot Architecture and Working Examples

## Table of Contents

1. [Recommended 6-Stage Bot Architecture](#1-recommended-6-stage-bot-architecture)
2. [Stage 1: INGEST](#2-stage-1-ingest)
3. [Stage 2: COMPUTE](#3-stage-2-compute)
4. [Stage 3: DECIDE](#4-stage-3-decide)
5. [Stage 4: RECONCILE](#5-stage-4-reconcile)
6. [Stage 5: RECOVER](#6-stage-5-recover)
7. [Stage 6: LOG](#7-stage-6-log)
8. [Latency Optimization Tips](#8-latency-optimization-tips)
9. [Notable Open-Source Bots](#9-notable-open-source-bots)
10. [Community Resources](#10-community-resources)
11. [Complete Python Working Example](#11-complete-python-working-example)
12. [Complete TypeScript Working Example](#12-complete-typescript-working-example)
13. [Recommended Project Structure](#13-recommended-project-structure)

---

## 1. Recommended 6-Stage Bot Architecture

Every well-designed Hyperliquid trading bot follows the same fundamental pipeline. Whether you are building a market maker, grid trader, arbitrage bot, or AI-driven strategy, this 6-stage architecture provides a clean separation of concerns and robust error handling.

```
1. INGEST   --> WebSocket streams (prices, fills, orders)
2. COMPUTE  --> Strategy logic on latest state
3. DECIDE   --> Generate target orders
4. RECONCILE --> Compare targets vs open orders, submit diffs
5. RECOVER  --> Handle disconnects with backoff, replay state from REST
6. LOG      --> Track decisions, acks, rejects, reconnects
```

Each stage has a single responsibility. Data flows forward through the pipeline. Errors and disconnects trigger the RECOVER stage, which feeds back into INGEST to restart the loop. The LOG stage observes every other stage for debugging and auditing.

---

## 2. Stage 1: INGEST

The INGEST stage is responsible for receiving real-time data from the Hyperliquid WebSocket and maintaining a local copy of market state.

### Responsibilities

- Connect to `wss://api.hyperliquid.xyz/ws`
- Subscribe to required channels (l2Book, trades, allMids, orderUpdates, userFills, userEvents)
- Maintain heartbeat (ping every 50 seconds, server closes after 60s inactivity)
- Parse and validate incoming messages
- Update local state objects (orderbook, positions, open orders, fills)

### Implementation pattern

```python
import asyncio
import json
import websockets
from dataclasses import dataclass, field
from typing import Dict, List, Optional

@dataclass
class LocalState:
    """Shared mutable state updated by INGEST, read by COMPUTE/DECIDE."""
    mid_prices: Dict[str, float] = field(default_factory=dict)
    orderbook: Dict[str, dict] = field(default_factory=dict)
    positions: Dict[str, dict] = field(default_factory=dict)
    open_orders: List[dict] = field(default_factory=list)
    last_update_ms: int = 0
    connected: bool = False

class IngestStage:
    def __init__(self, state: LocalState, coins: List[str], user_address: str):
        self.state = state
        self.coins = coins
        self.user_address = user_address
        self.ws: Optional[websockets.WebSocketClientProtocol] = None

    async def connect_and_subscribe(self, ws_url: str):
        self.ws = await websockets.connect(ws_url)
        self.state.connected = True

        # Subscribe to market data
        for coin in self.coins:
            await self.ws.send(json.dumps({
                "method": "subscribe",
                "subscription": {"type": "l2Book", "coin": coin}
            }))
            await self.ws.send(json.dumps({
                "method": "subscribe",
                "subscription": {"type": "trades", "coin": coin}
            }))

        # Subscribe to all mid prices
        await self.ws.send(json.dumps({
            "method": "subscribe",
            "subscription": {"type": "allMids"}
        }))

        # Subscribe to user-specific channels
        await self.ws.send(json.dumps({
            "method": "subscribe",
            "subscription": {"type": "orderUpdates", "user": self.user_address}
        }))
        await self.ws.send(json.dumps({
            "method": "subscribe",
            "subscription": {"type": "userFills", "user": self.user_address}
        }))

    async def run(self, ws_url: str):
        """Main INGEST loop with heartbeat."""
        await self.connect_and_subscribe(ws_url)
        last_ping = asyncio.get_event_loop().time()

        while True:
            now = asyncio.get_event_loop().time()
            if now - last_ping > 50:
                await self.ws.send(json.dumps({"method": "ping"}))
                last_ping = now

            try:
                msg = await asyncio.wait_for(self.ws.recv(), timeout=10)
                data = json.loads(msg)
                self._process_message(data)
            except asyncio.TimeoutError:
                continue

    def _process_message(self, data: dict):
        channel = data.get("channel")
        if channel == "pong":
            return
        elif channel == "allMids":
            mids = data["data"]["mids"]
            for coin, px in mids.items():
                self.state.mid_prices[coin] = float(px)
        elif channel == "l2Book":
            book = data["data"]
            self.state.orderbook[book["coin"]] = book
        elif channel == "orderUpdates":
            self._update_orders(data["data"])
        elif channel == "userFills":
            self._update_fills(data["data"])
        self.state.last_update_ms = int(asyncio.get_event_loop().time() * 1000)

    def _update_orders(self, orders):
        # Update local order tracking
        for order_update in orders:
            status = order_update.get("status")
            oid = order_update["order"]["oid"]
            if status in ("canceled", "filled"):
                self.state.open_orders = [
                    o for o in self.state.open_orders if o.get("oid") != oid
                ]
            elif status == "resting":
                self.state.open_orders.append(order_update["order"])

    def _update_fills(self, fills):
        # Process fills to update position tracking
        pass  # Strategy-specific logic
```

> **Cross-reference:** See `websocket-channels.md` for all 19 subscription channels and message formats.

---

## 3. Stage 2: COMPUTE

The COMPUTE stage reads the latest local state (populated by INGEST) and runs strategy-specific calculations.

### Responsibilities

- Read current mid prices, orderbook depth, positions, and open orders
- Compute signals, indicators, or models
- Calculate target position sizes based on strategy rules
- Apply risk constraints (max leverage, max position size, drawdown limits)

### Implementation pattern

```python
@dataclass
class StrategyOutput:
    """Output of COMPUTE stage, consumed by DECIDE."""
    target_positions: Dict[str, float]  # coin -> target signed size
    signals: Dict[str, float]           # coin -> signal strength [-1, 1]
    confidence: float                   # overall confidence [0, 1]

class ComputeStage:
    def __init__(self, state: LocalState, max_leverage: float = 5.0):
        self.state = state
        self.max_leverage = max_leverage

    def run(self) -> StrategyOutput:
        """Run strategy computation on latest state."""
        targets = {}
        signals = {}

        for coin, mid in self.state.mid_prices.items():
            if coin not in self.state.orderbook:
                continue

            signal = self._compute_signal(coin)
            signals[coin] = signal

            # Convert signal to target position
            max_notional = 1000.0  # $1000 max per position
            target_size = signal * max_notional / mid
            targets[coin] = target_size

        return StrategyOutput(
            target_positions=targets,
            signals=signals,
            confidence=1.0,
        )

    def _compute_signal(self, coin: str) -> float:
        """Strategy-specific signal generation. Override this."""
        # Example: simple spread signal
        book = self.state.orderbook.get(coin, {})
        levels = book.get("levels", [[], []])
        if not levels[0] or not levels[1]:
            return 0.0
        best_bid = float(levels[0][0]["px"])
        best_ask = float(levels[1][0]["px"])
        spread = (best_ask - best_bid) / best_bid
        # Wide spread -> opportunity signal
        return 1.0 if spread > 0.001 else 0.0
```

---

## 4. Stage 3: DECIDE

The DECIDE stage converts strategy output into concrete order instructions.

### Responsibilities

- Compare target positions to current positions
- Generate new orders, modifications, and cancellations
- Apply minimum order value constraints ($10 for perps)
- Assign CLOIDs to every order for tracking
- Format prices and sizes (no trailing zeros)

### Implementation pattern

```python
import uuid
from hyperliquid.utils.types import Cloid

@dataclass
class OrderInstruction:
    coin: str
    is_buy: bool
    size: float
    price: float
    tif: str  # "Gtc", "Ioc", "Alo"
    reduce_only: bool
    cloid: str

class DecideStage:
    def __init__(self, state: LocalState, min_notional: float = 10.0):
        self.state = state
        self.min_notional = min_notional

    def run(self, strategy_output: StrategyOutput) -> List[OrderInstruction]:
        """Generate order instructions from strategy targets."""
        instructions = []

        for coin, target_size in strategy_output.target_positions.items():
            current_size = self._get_current_position(coin)
            delta = target_size - current_size

            if abs(delta) < 1e-8:
                continue  # No action needed

            mid = self.state.mid_prices.get(coin, 0)
            if mid == 0:
                continue

            notional = abs(delta) * mid
            if notional < self.min_notional:
                continue  # Below minimum

            is_buy = delta > 0
            # For limit orders, set price slightly aggressive
            slippage = 0.001  # 0.1%
            price = mid * (1 + slippage) if is_buy else mid * (1 - slippage)

            cloid_hex = uuid.uuid4().hex
            instructions.append(OrderInstruction(
                coin=coin,
                is_buy=is_buy,
                size=abs(delta),
                price=round(price, 2),
                tif="Gtc",
                reduce_only=False,
                cloid=f"0x{cloid_hex}",
            ))

        return instructions

    def _get_current_position(self, coin: str) -> float:
        pos = self.state.positions.get(coin, {})
        return float(pos.get("szi", 0))
```

> **Cross-reference:** See `risk-and-error-handling.md` for minimum order value constraints and trailing zero formatting.

---

## 5. Stage 4: RECONCILE

The RECONCILE stage compares the new order instructions against currently open orders and submits only the necessary changes (new orders, cancellations, modifications).

### Responsibilities

- Diff target orders against current open orders
- Cancel stale orders that no longer match targets
- Submit new orders for unmatched targets
- Modify existing orders when price/size changed
- Batch requests efficiently (one batch per ~0.1 seconds)
- Separate ALO batches from IOC/GTC batches

### Implementation pattern

```python
class ReconcileStage:
    def __init__(self, exchange, state: LocalState):
        self.exchange = exchange
        self.state = state

    def run(self, instructions: List[OrderInstruction]):
        """Submit order diffs to the exchange."""
        # Separate ALO orders from others for batching priority
        alo_orders = [i for i in instructions if i.tif == "Alo"]
        other_orders = [i for i in instructions if i.tif != "Alo"]

        # Cancel orders that are no longer needed
        target_coins = {i.coin for i in instructions}
        for order in self.state.open_orders:
            if order["coin"] not in target_coins:
                try:
                    self.exchange.cancel(order["coin"], order["oid"])
                except Exception as e:
                    print(f"Cancel failed for {order['coin']} OID {order['oid']}: {e}")

        # Submit ALO batch first (validator priority)
        if alo_orders:
            self._submit_batch(alo_orders)

        # Then submit other orders
        if other_orders:
            self._submit_batch(other_orders)

    def _submit_batch(self, instructions: List[OrderInstruction]):
        """Submit a batch of orders."""
        order_list = []
        for inst in instructions:
            order_list.append({
                "coin": inst.coin,
                "is_buy": inst.is_buy,
                "sz": inst.size,
                "limit_px": inst.price,
                "order_type": {"limit": {"tif": inst.tif}},
                "reduce_only": inst.reduce_only,
                "cloid": Cloid.from_str(inst.cloid),
            })

        if not order_list:
            return

        try:
            result = self.exchange.bulk_orders(order_list)
            self._handle_result(result, instructions)
        except Exception as e:
            print(f"Batch submission failed: {e}")

    def _handle_result(self, result, instructions):
        """Handle batch and per-order results."""
        if result.get("status") != "ok":
            print(f"Batch-level error: {result}")
            return

        response_data = result.get("response", {}).get("data", {})
        if isinstance(response_data, str):
            print(f"Batch pre-validation error: {response_data}")
            return

        statuses = response_data.get("statuses", [])
        for i, status in enumerate(statuses):
            coin = instructions[i].coin if i < len(instructions) else "unknown"
            if "error" in status:
                print(f"Order {coin} error: {status['error']}")
            elif "resting" in status:
                print(f"Order {coin} resting: OID {status['resting']['oid']}")
            elif "filled" in status:
                print(f"Order {coin} filled: {status['filled']['totalSz']} @ {status['filled']['avgPx']}")
```

> **Cross-reference:** See `exchange-actions.md` for batch order and batch cancel formats, and `risk-and-error-handling.md` for batch error handling patterns.

---

## 6. Stage 5: RECOVER

The RECOVER stage handles errors, disconnects, and state inconsistencies. It is the safety net that keeps the bot running through transient failures.

### Responsibilities

- Detect WebSocket disconnects
- Implement exponential backoff reconnection
- Replay state from REST after reconnect (positions, open orders, fills)
- Handle rate limit errors with backoff
- Trigger emergency shutdown if critical errors persist
- Use dead man's switch (`scheduleCancel`) as a safety net

### Implementation pattern

```python
import time

class RecoverStage:
    def __init__(self, info, exchange, account_address: str):
        self.info = info
        self.exchange = exchange
        self.account_address = account_address
        self.consecutive_failures = 0
        self.max_failures = 10
        self.backoff_delay = 1

    async def handle_disconnect(self, state: LocalState, ingest: IngestStage, ws_url: str):
        """Handle WebSocket disconnect with backoff and state reconciliation."""
        state.connected = False
        self.consecutive_failures += 1

        if self.consecutive_failures >= self.max_failures:
            print("[RECOVER] Too many failures, initiating emergency shutdown")
            self._emergency_shutdown()
            return

        print(f"[RECOVER] Reconnecting in {self.backoff_delay}s "
              f"(failure {self.consecutive_failures}/{self.max_failures})")
        await asyncio.sleep(self.backoff_delay)
        self.backoff_delay = min(self.backoff_delay * 2, 60)

        try:
            await ingest.connect_and_subscribe(ws_url)
            await self._reconcile_state(state)
            self.consecutive_failures = 0
            self.backoff_delay = 1
            print("[RECOVER] Reconnected and state reconciled")
        except Exception as e:
            print(f"[RECOVER] Reconnection failed: {e}")

    async def _reconcile_state(self, state: LocalState):
        """Fetch full state from REST to reconcile after reconnect."""
        # Fetch current positions
        user_state = self.info.user_state(self.account_address)
        state.positions = {}
        for pos in user_state.get("assetPositions", []):
            p = pos["position"]
            state.positions[p["coin"]] = p

        # Fetch open orders
        state.open_orders = self.info.open_orders(self.account_address)

        # Fetch current prices
        mids = self.info.all_mids()
        state.mid_prices = {k: float(v) for k, v in mids.items()}

        print(f"[RECOVER] State reconciled: {len(state.positions)} positions, "
              f"{len(state.open_orders)} open orders")

    def _emergency_shutdown(self):
        """Full emergency shutdown: scheduleCancel -> cancel all -> close all."""
        try:
            future_time = int(time.time() * 1000) + 10_000
            self.exchange.schedule_cancel(future_time)
        except Exception:
            pass

        try:
            for order in self.info.open_orders(self.account_address):
                self.exchange.cancel(order["coin"], order["oid"])
        except Exception:
            pass

        try:
            user_state = self.info.user_state(self.account_address)
            for pos in user_state.get("assetPositions", []):
                p = pos["position"]
                if float(p["szi"]) != 0:
                    self.exchange.market_close(p["coin"])
        except Exception:
            pass

    def refresh_dead_mans_switch(self):
        """Refresh the dead man's switch every few minutes."""
        try:
            future_time = int(time.time() * 1000) + 300_000  # 5 minutes
            self.exchange.schedule_cancel(future_time)
        except Exception as e:
            print(f"[RECOVER] Failed to refresh dead man's switch: {e}")
```

> **Cross-reference:** See `risk-and-error-handling.md` for the complete emergency shutdown procedure and circuit breaker patterns.

---

## 7. Stage 6: LOG

The LOG stage provides observability across all other stages. Every decision, trade, error, and reconnect should be logged for debugging and auditing.

### Responsibilities

- Log every order submission with CLOID, price, size, and result
- Log every cancellation and modification
- Log every WebSocket disconnect and reconnect
- Log strategy signals and target positions
- Track PnL over time
- Export metrics for monitoring dashboards

### Implementation pattern

```python
import logging
import json
from datetime import datetime

class LogStage:
    def __init__(self, log_file: str = "trading_bot.log"):
        self.logger = logging.getLogger("trading_bot")
        self.logger.setLevel(logging.DEBUG)

        # File handler (structured JSON)
        fh = logging.FileHandler(log_file)
        fh.setLevel(logging.DEBUG)
        self.logger.addHandler(fh)

        # Console handler (human-readable)
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        ch.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        self.logger.addHandler(ch)

    def log_order(self, coin: str, side: str, size: float, price: float,
                  cloid: str, result: dict):
        self.logger.info(json.dumps({
            "event": "order",
            "timestamp": datetime.utcnow().isoformat(),
            "coin": coin,
            "side": side,
            "size": size,
            "price": price,
            "cloid": cloid,
            "result": result,
        }))

    def log_cancel(self, coin: str, oid: int, result: str):
        self.logger.info(json.dumps({
            "event": "cancel",
            "timestamp": datetime.utcnow().isoformat(),
            "coin": coin,
            "oid": oid,
            "result": result,
        }))

    def log_disconnect(self, reason: str, reconnect_delay: float):
        self.logger.warning(json.dumps({
            "event": "disconnect",
            "timestamp": datetime.utcnow().isoformat(),
            "reason": reason,
            "reconnect_delay_s": reconnect_delay,
        }))

    def log_signal(self, coin: str, signal: float, target_size: float):
        self.logger.debug(json.dumps({
            "event": "signal",
            "timestamp": datetime.utcnow().isoformat(),
            "coin": coin,
            "signal": signal,
            "target_size": target_size,
        }))

    def log_pnl(self, account_value: float, unrealized_pnl: float,
                positions: dict):
        self.logger.info(json.dumps({
            "event": "pnl_snapshot",
            "timestamp": datetime.utcnow().isoformat(),
            "account_value": account_value,
            "unrealized_pnl": unrealized_pnl,
            "position_count": len(positions),
        }))
```

---

## 8. Latency Optimization Tips

For competitive trading strategies (market making, arbitrage), latency matters. These optimizations reduce round-trip time and improve fill rates.

### Batch requests every ~0.1 seconds

Do not submit orders one at a time. Accumulate order instructions over a short window (100ms) and submit as a single batch. This reduces network round-trips and ensures atomic execution.

### ALO batching for validator priority

ALO-only batches receive priority processing from validators. Never mix ALO orders with IOC or GTC orders in the same batch:

```python
# ALO batch (gets validator priority)
alo_batch = [order for order in instructions if order.tif == "Alo"]
exchange.bulk_orders(alo_batch)

# Non-ALO batch (submitted separately)
other_batch = [order for order in instructions if order.tif != "Alo"]
exchange.bulk_orders(other_batch)
```

### Atomic counter for nonces

Use an atomic counter for nonce generation. Fast-forward to the current millisecond timestamp when it advances, but always increment if time has not advanced:

```python
import threading, time

class AtomicNonce:
    def __init__(self):
        self._lock = threading.Lock()
        self._value = 0

    def next(self) -> int:
        with self._lock:
            now_ms = int(time.time() * 1000)
            self._value = max(self._value + 1, now_ms)
            return self._value
```

### Cancel via nonce invalidation

Instead of sending explicit cancel actions (which consume rate limits), use a `noop` action to consume a nonce. This is faster and cheaper when you need to prevent a previously-submitted nonce from being used.

### One API wallet per process

Never share an API wallet between processes. Nonce tracking is per-signer -- shared wallets cause collisions that result in rejected actions.

### 2-second tolerance

The Hyperliquid matching engine tolerates **out-of-order transactions within approximately 2 seconds**. Structure your system to work within this tolerance rather than relying on strict ordering.

### WebSocket posting for lowest latency

For the fastest order submission, use WebSocket posting instead of REST:

```python
# Instead of REST POST /exchange, post via WebSocket
await ws.send(json.dumps({
    "method": "post",
    "id": unique_id,
    "request": {
        "type": "action",
        "payload": {
            "action": {"type": "order", "orders": [...], "grouping": "na"},
            "nonce": nonce,
            "signature": {"r": "...", "s": "...", "v": "..."}
        }
    }
}))
```

> **Cross-reference:** See `websocket-channels.md` for WebSocket posting and `rate-limits.md` for request weight calculations.

---

## 9. Notable Open-Source Bots

These open-source projects demonstrate real-world bot architectures on Hyperliquid:

### chainstacklabs/hyperliquid-trading-bot (Python)

- **Type**: Grid trading bot
- **Features**: YAML configuration, testnet-first development, configurable grid levels
- **Architecture**: Simple single-process, polling-based
- **Best for**: Learning grid trading concepts on Hyperliquid
- **URL**: `github.com/chainstacklabs/hyperliquid-trading-bot`

### Hummingbot

- **Type**: Professional market-making framework
- **Features**: Native Hyperliquid connector for both spot and perpetuals, cross-exchange strategies, advanced order management
- **Architecture**: Multi-process, event-driven, plugin-based
- **Best for**: Serious market-making with cross-exchange inventory management
- **URL**: `github.com/hummingbot/hummingbot`

### hyperliquid-ai-trading-bot (Python)

- **Type**: AI-powered trading bot
- **Features**: Integration with ChatGPT, DeepSeek, and Gemini for signal generation
- **Architecture**: LLM-based decision engine with Hyperliquid execution
- **Best for**: Experimenting with AI-driven trading strategies

### MaxIsOntoSomething/Hyperliquid_Copy_Trader (Python)

- **Type**: Automated copy trading
- **Features**: Monitor target wallets via WebSocket, replicate trades with configurable sizing
- **Architecture**: Event-driven, WebSocket-based position tracking
- **Best for**: Copying successful traders' positions

### Novus-Tech-LLC/Hyperliquid-Market-Maker (Rust)

- **Type**: Multi-market maker
- **Features**: React frontend for monitoring, Rust backend for low-latency execution, multi-asset quoting
- **Architecture**: Rust async runtime, WebSocket-driven, separate UI process
- **Best for**: High-performance market making with visual monitoring

---

## 10. Community Resources

| Resource | URL | Description |
|---|---|---|
| Discord | `discord.com/invite/hyperliquid` | 81,000+ members, open-ticket support, #developers channel |
| Official Docs | `hyperliquid.gitbook.io/hyperliquid-docs` | API reference and guides |
| Stats Dashboard | `stats.hyperliquid.xyz` | Historical volume, OI, liquidation data |
| Funding Comparison | `app.hyperliquid.xyz/fundingComparison` | Compare funding rates vs Binance, Bybit, etc. |
| Python SDK | `github.com/hyperliquid-dex/hyperliquid-python-sdk` | Official Python SDK (v0.22.0) |
| @nktkas/hyperliquid | `github.com/nktkas/hyperliquid` | Recommended TypeScript SDK |
| HyperEVM Lib | `github.com/hyperliquid-dev/hyper-evm-lib` | Foundry testing framework for HyperEVM |
| Builder Codes | `app.hyperliquid.xyz` | Earn up to 0.1% on perps, 1% on spot |

> **Cross-reference:** See `ecosystem-and-hips.md` for builder codes, testnet faucets, and the full SDK ecosystem.

---

## 11. Complete Python Working Example

This example demonstrates the full trading lifecycle using the official Python SDK: connecting, checking balances, setting leverage, placing orders (limit, stop-loss, take-profit), modifying orders, monitoring positions, and closing.

```python
"""
Hyperliquid Full Trading Lifecycle -- Python
Requires: pip install hyperliquid-python-sdk eth_account

WARNING: This is a working example. Use testnet for testing.
Replace PRIVATE_KEY with your actual key. Never commit secrets.
"""

import eth_account
import time
from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants
from hyperliquid.utils.types import Cloid


def main():
    # ----------------------------------------------------------------
    # 1. CONNECT
    # ----------------------------------------------------------------
    # For testnet: use constants.TESTNET_API_URL
    api_url = constants.MAINNET_API_URL

    wallet = eth_account.Account.from_key("0xPRIVATE_KEY")
    info = Info(api_url, skip_ws=True)
    exchange = Exchange(wallet, api_url, account_address=wallet.address)

    # For API wallets:
    # agent_wallet = eth_account.Account.from_key("0xAGENT_PRIVATE_KEY")
    # exchange = Exchange(agent_wallet, api_url, account_address="0xMASTER_ADDRESS")

    print(f"Connected. Account: {wallet.address}")

    # ----------------------------------------------------------------
    # 2. CHECK BALANCES AND ACCOUNT STATE
    # ----------------------------------------------------------------
    state = info.user_state(wallet.address)
    margin = state["marginSummary"]
    print(f"Account value:  {margin['accountValue']}")
    print(f"Total margin:   {margin['totalMarginUsed']}")
    print(f"Withdrawable:   {state['withdrawable']}")

    # Check spot balances
    spot_state = info.spot_user_state(wallet.address)
    for bal in spot_state.get("balances", []):
        print(f"Spot: {bal['coin']} = {bal['total']} (hold: {bal['hold']})")

    # ----------------------------------------------------------------
    # 3. SET LEVERAGE
    # ----------------------------------------------------------------
    exchange.update_leverage(5, "ETH", is_cross=True)
    print("Leverage set: ETH 5x cross")

    # ----------------------------------------------------------------
    # 4. PLACE LIMIT ORDER WITH CLOID
    # ----------------------------------------------------------------
    cloid = Cloid.from_str("0x" + "a1" * 16)
    result = exchange.order(
        "ETH",
        True,       # is_buy
        0.1,        # size
        2800.0,     # price
        {"limit": {"tif": "Gtc"}},
        cloid=cloid,
    )
    print(f"Limit order result: {result}")

    # Extract OID from response
    oid = None
    statuses = result.get("response", {}).get("data", {}).get("statuses", [])
    if statuses:
        first = statuses[0]
        if "resting" in first:
            oid = first["resting"]["oid"]
            print(f"Order resting: OID={oid}")
        elif "filled" in first:
            print(f"Order filled: {first['filled']['totalSz']} @ {first['filled']['avgPx']}")
        elif "error" in first:
            print(f"Order error: {first['error']}")

    # ----------------------------------------------------------------
    # 5. PLACE STOP-LOSS (reduce-only)
    # ----------------------------------------------------------------
    sl_result = exchange.order(
        "ETH",
        False,      # sell (opposite of long position)
        0.1,        # same size as entry
        2600.0,     # limit price if triggered
        {"trigger": {"triggerPx": "2650", "isMarket": True, "tpsl": "sl"}},
        reduce_only=True,
    )
    print(f"Stop-loss result: {sl_result}")

    # ----------------------------------------------------------------
    # 6. PLACE TAKE-PROFIT (reduce-only)
    # ----------------------------------------------------------------
    tp_result = exchange.order(
        "ETH",
        False,
        0.1,
        3200.0,
        {"trigger": {"triggerPx": "3100", "isMarket": True, "tpsl": "tp"}},
        reduce_only=True,
    )
    print(f"Take-profit result: {tp_result}")

    # ----------------------------------------------------------------
    # 7. MODIFY ORDER
    # ----------------------------------------------------------------
    if oid:
        mod_result = exchange.modify_order(
            oid, "ETH", True, 0.1, 2750.0, {"limit": {"tif": "Gtc"}}
        )
        print(f"Modify result: {mod_result}")

    # ----------------------------------------------------------------
    # 8. CHECK POSITIONS AND LIQUIDATION PRICE
    # ----------------------------------------------------------------
    state = info.user_state(wallet.address)
    for pos in state.get("assetPositions", []):
        p = pos["position"]
        print(
            f"Position: {p['coin']} | "
            f"size={p['szi']} | "
            f"entry={p['entryPx']} | "
            f"pnl={p['unrealizedPnl']} | "
            f"liq={p.get('liquidationPx', 'N/A')} | "
            f"leverage={p.get('leverage', {}).get('value', '?')}x "
            f"({p.get('leverage', {}).get('type', '?')})"
        )

    # ----------------------------------------------------------------
    # 9. CHECK OPEN ORDERS
    # ----------------------------------------------------------------
    open_orders = info.open_orders(wallet.address)
    print(f"\nOpen orders: {len(open_orders)}")
    for order in open_orders:
        print(
            f"  {order['coin']} {order['side']} "
            f"{order['sz']} @ {order['limitPx']} "
            f"(OID: {order['oid']})"
        )

    # ----------------------------------------------------------------
    # 10. QUERY ORDER BY CLOID
    # ----------------------------------------------------------------
    order_info = info.query_order_by_cloid(wallet.address, cloid)
    print(f"Order by CLOID: {order_info}")

    # ----------------------------------------------------------------
    # 11. MARKET CLOSE POSITION
    # ----------------------------------------------------------------
    close_result = exchange.market_close("ETH")
    print(f"Market close result: {close_result}")

    # ----------------------------------------------------------------
    # 12. CANCEL ALL REMAINING ORDERS
    # ----------------------------------------------------------------
    open_orders = info.open_orders(wallet.address)
    for order in open_orders:
        cancel_result = exchange.cancel(order["coin"], order["oid"])
        print(f"Canceled {order['coin']} OID {order['oid']}: {cancel_result}")

    # ----------------------------------------------------------------
    # 13. CHECK RECENT FILLS
    # ----------------------------------------------------------------
    fills = info.user_fills(wallet.address)
    for fill in fills[:5]:
        print(
            f"Fill: {fill['coin']} {fill['dir']} "
            f"{fill['sz']} @ {fill['px']} | "
            f"fee={fill['fee']} | pnl={fill.get('closedPnl', '0')}"
        )

    print("\nTrading lifecycle complete.")


if __name__ == "__main__":
    main()
```

> **Cross-reference:** See `python-sdk.md` for the complete SDK method reference, and `risk-and-error-handling.md` for error handling patterns.

---

## 12. Complete TypeScript Working Example

This example demonstrates market data retrieval and trading using the `@nktkas/hyperliquid` TypeScript SDK.

```typescript
/**
 * Hyperliquid Market Data + Trading -- TypeScript
 * Requires: npm i @nktkas/hyperliquid viem
 *
 * WARNING: This is a working example. Use testnet for testing.
 * Replace PRIVATE_KEY with your actual key. Never commit secrets.
 */

import {
  HttpTransport,
  InfoClient,
  ExchangeClient,
  SubscriptionClient,
  WebSocketTransport,
} from "@nktkas/hyperliquid";
import { privateKeyToAccount } from "viem/accounts";

async function main() {
  // ----------------------------------------------------------------
  // 1. SETUP CLIENTS
  // ----------------------------------------------------------------
  const wallet = privateKeyToAccount("0xPRIVATE_KEY" as `0x${string}`);
  const transport = new HttpTransport(); // Defaults to mainnet
  // For testnet: new HttpTransport({ url: "https://api.hyperliquid-testnet.xyz" })

  const info = new InfoClient({ transport });
  const exchange = new ExchangeClient({ transport, wallet });

  console.log("Connected. Wallet:", wallet.address);

  // ----------------------------------------------------------------
  // 2. FETCH MARKET METADATA
  // ----------------------------------------------------------------
  const [meta, ctxs] = await info.metaAndAssetCtxs();
  console.log(`\nAvailable perps: ${meta.universe.length}`);
  for (let i = 0; i < Math.min(5, meta.universe.length); i++) {
    const asset = meta.universe[i];
    const ctx = ctxs[i];
    console.log(
      `  ${asset.name} (index ${i}): ` +
      `mark=${ctx.markPx} funding=${ctx.funding} OI=${ctx.openInterest}`
    );
  }

  // ----------------------------------------------------------------
  // 3. FETCH MID PRICES
  // ----------------------------------------------------------------
  const mids = await info.allMids();
  console.log(`\nBTC mid: ${mids["BTC"]}`);
  console.log(`ETH mid: ${mids["ETH"]}`);

  // ----------------------------------------------------------------
  // 4. FETCH ORDERBOOK
  // ----------------------------------------------------------------
  const book = await info.l2Book({ coin: "ETH" });
  const bestBid = book.levels[0][0];
  const bestAsk = book.levels[1][0];
  console.log(`\nETH book: bid=${bestBid?.px} (${bestBid?.sz}) / ask=${bestAsk?.px} (${bestAsk?.sz})`);

  // ----------------------------------------------------------------
  // 5. CHECK ACCOUNT STATE
  // ----------------------------------------------------------------
  const state = await info.clearinghouseState({ user: wallet.address });
  console.log(`\nAccount value: ${state.marginSummary.accountValue}`);
  console.log(`Margin used: ${state.marginSummary.totalMarginUsed}`);
  console.log(`Withdrawable: ${state.withdrawable}`);

  for (const pos of state.assetPositions) {
    const p = pos.position;
    console.log(
      `  Position: ${p.coin} size=${p.szi} entry=${p.entryPx} ` +
      `pnl=${p.unrealizedPnl} liq=${p.liquidationPx}`
    );
  }

  // ----------------------------------------------------------------
  // 6. SET LEVERAGE
  // ----------------------------------------------------------------
  await exchange.updateLeverage({ asset: 1, isCross: true, leverage: 5 });
  console.log("\nLeverage set: ETH 5x cross");

  // ----------------------------------------------------------------
  // 7. PLACE LIMIT ORDER
  // ----------------------------------------------------------------
  const orderResult = await exchange.order({
    orders: [{
      a: 1,          // ETH = asset index 1
      b: true,       // buy
      p: "2800",     // price (no trailing zeros!)
      s: "0.1",      // size (no trailing zeros!)
      r: false,      // not reduce-only
      t: { limit: { tif: "Gtc" } },
    }],
    grouping: "na",
  });
  console.log("\nOrder result:", JSON.stringify(orderResult, null, 2));

  // Extract OID
  const statuses = orderResult?.response?.data?.statuses ?? [];
  let oid: number | null = null;
  if (statuses[0] && "resting" in statuses[0]) {
    oid = (statuses[0] as any).resting.oid;
    console.log(`Order resting: OID=${oid}`);
  }

  // ----------------------------------------------------------------
  // 8. CANCEL ORDER
  // ----------------------------------------------------------------
  if (oid !== null) {
    const cancelResult = await exchange.cancel({
      cancels: [{ a: 1, o: oid }],
    });
    console.log("Cancel result:", JSON.stringify(cancelResult));
  }

  // ----------------------------------------------------------------
  // 9. SUBSCRIBE TO REAL-TIME DATA
  // ----------------------------------------------------------------
  const subs = new SubscriptionClient({
    transport: new WebSocketTransport(),
    // For testnet: new WebSocketTransport({ url: "wss://api.hyperliquid-testnet.xyz/ws" })
  });

  // Subscribe to ETH orderbook updates
  const bookSub = await subs.l2Book({ coin: "ETH" }, (data) => {
    const bid = data.levels[0][0];
    const ask = data.levels[1][0];
    console.log(`[WS] ETH book: ${bid?.px} / ${ask?.px}`);
  });

  // Subscribe to ETH trades
  const tradeSub = await subs.trades({ coin: "ETH" }, (trades) => {
    for (const t of trades) {
      console.log(`[WS] ETH trade: ${t.side} ${t.sz} @ ${t.px}`);
    }
  });

  // Subscribe to all mid prices
  const midSub = await subs.allMids((data) => {
    console.log(`[WS] BTC mid: ${data.mids["BTC"]}`);
  });

  // Let subscriptions run for 30 seconds
  console.log("\nListening for 30 seconds...");
  await new Promise((resolve) => setTimeout(resolve, 30_000));

  // Unsubscribe
  await bookSub.unsubscribe();
  await tradeSub.unsubscribe();
  await midSub.unsubscribe();

  console.log("Done.");
}

main().catch(console.error);
```

> **Cross-reference:** See `typescript-sdks.md` for the complete @nktkas/hyperliquid and nomeida/hyperliquid SDK references.

---

## 13. Recommended Project Structure

This is the recommended directory structure for a Hyperliquid trading bot project. It follows the 6-stage architecture and separates concerns cleanly.

```
my-hyperliquid-bot/
|
|-- config/
|   |-- settings.py          # API URLs, leverage limits, risk parameters
|   |-- .env                 # PRIVATE_KEY, ACCOUNT_ADDRESS (never commit!)
|   +-- assets.yaml          # Asset configuration (coins, sizes, ticks)
|
|-- core/
|   |-- client.py            # SDK initialization (Info + Exchange)
|   |-- signer.py            # Authentication, API wallet setup
|   |-- ws_manager.py        # WebSocket with auto-reconnection (INGEST)
|   +-- nonce.py             # Thread-safe atomic nonce generator
|
|-- strategies/
|   |-- base.py              # Abstract strategy interface (COMPUTE)
|   |-- market_maker.py      # Example: spread quoting
|   |-- grid.py              # Example: grid trading
|   +-- trend.py             # Example: trend following
|
|-- execution/
|   |-- order_manager.py     # DECIDE: generate order instructions
|   |-- reconciler.py        # RECONCILE: diff and submit orders
|   +-- formatter.py         # Price/size formatting (no trailing zeros)
|
|-- risk/
|   |-- circuit_breaker.py   # RECOVER: halt on consecutive errors
|   |-- position_limits.py   # Max size, max leverage, drawdown limits
|   |-- emergency.py         # Emergency shutdown (scheduleCancel + close all)
|   +-- monitor.py           # Liquidation price monitoring
|
|-- data/
|   |-- state.py             # LocalState dataclass (shared mutable state)
|   |-- orderbook.py         # L2 book maintenance
|   |-- positions.py         # Position state tracking
|   +-- fills.py             # Fill tracking and PnL attribution
|
|-- logging/
|   |-- logger.py            # LOG: structured JSON logging
|   +-- metrics.py           # Prometheus/InfluxDB metrics export
|
|-- main.py                  # Entry point: wire all stages together
|-- requirements.txt         # hyperliquid-python-sdk, eth_account, websockets
|-- Dockerfile               # Container deployment
|
+-- tests/
    |-- test_formatting.py   # Price/size formatting tests
    |-- test_strategy.py     # Strategy signal tests
    |-- test_risk.py         # Circuit breaker, position limit tests
    +-- test_reconciler.py   # Order diffing tests
```

### Key principles

1. **Config is separate from code.** Secrets go in `.env` (never committed). Strategy parameters go in `settings.py` or YAML files.

2. **Each stage maps to a directory.** `core/ws_manager.py` = INGEST, `strategies/` = COMPUTE, `execution/` = DECIDE + RECONCILE, `risk/` = RECOVER, `logging/` = LOG.

3. **State is centralized.** `data/state.py` contains the `LocalState` dataclass that INGEST writes to and all other stages read from.

4. **Testing is practical.** Test formatting (trailing zeros), strategy signals (unit tests with mock data), risk rules (circuit breaker thresholds), and reconciliation (order diffing).

5. **Deployment is containerized.** A Dockerfile ensures consistent environments across development, testing, and production.

> **Cross-reference:** See `python-sdk.md` for SDK initialization patterns, `risk-and-error-handling.md` for the emergency shutdown procedure, and `ecosystem-and-hips.md` for community resources and open-source tools.
