# Rate Limits — Hyperliquid API Reference

## Table of Contents

1. [IP-Based Limits](#1-ip-based-limits)
2. [Request Weights](#2-request-weights)
3. [Address-Based Limits](#3-address-based-limits)
4. [Purchasing Additional Capacity](#4-purchasing-additional-capacity)
5. [Sub-Account Rate Limit Behavior](#5-sub-account-rate-limit-behavior)
6. [Open Order Limits](#6-open-order-limits)
7. [Stale expiresAfter Penalty](#7-stale-expiresafter-penalty)
8. [Best Practices for Staying Within Limits](#8-best-practices-for-staying-within-limits)
9. [Monitoring Rate Limit Status](#9-monitoring-rate-limit-status)

---

## 1. IP-Based Limits

All IP-based limits apply per originating IP address across all requests from that IP, regardless of which user accounts are being accessed.

| Resource | Limit | Notes |
|----------|-------|-------|
| REST requests | **1200 weight/minute** (aggregate) | Weights vary by endpoint (see section 2) |
| WebSocket connections | **100** | Total simultaneous connections per IP |
| WebSocket subscriptions | **1000** | Total across all connections per IP |
| Unique users in WS user-subscriptions | **10** | Distinct `user` addresses across all subscriptions |
| WebSocket messages sent/minute | **2000** | Includes subscribes, posts, and pings |
| WebSocket inflight post messages | **100** | Concurrent unresolved `method: "post"` requests |
| HyperEVM JSON-RPC | **100/minute** | Separate from REST/WS limits |

**Key implications:**

- The 1200 weight/minute REST limit is aggregate. A burst of heavy queries (weight 20 each) can exhaust the limit in just 60 requests per minute.
- The 10 unique user limit for WebSocket subscriptions means a single IP can only subscribe to channels for at most 10 different wallet addresses. For multi-user services, use multiple IP addresses or server instances.
- WebSocket inflight posts are capped at 100 concurrent. Await responses before sending more.

```python
# Example: calculating remaining capacity
WEIGHT_PER_MINUTE = 1200

# If you have sent 800 weight in the current minute window:
remaining_weight = 1200 - 800  # 400 weight remaining
# A userFills query costs 20 + items/20 weight
# An allMids query costs 2 weight
```

---

## 2. Request Weights

Not all requests consume equal weight. Use this table to plan your request budget.

### Exchange endpoint weights

| Request Type | Weight Formula |
|-------------|----------------|
| Exchange (unbatched, single action) | `1` |
| Exchange (batched, N items) | `1 + floor(N / 40)` |

For example, a batch of 80 orders costs `1 + floor(80/40) = 3` weight.

### Info endpoint weights

| Endpoint | Weight |
|----------|--------|
| `l2Book` | **2** |
| `allMids` | **2** |
| `clearinghouseState` | **2** |
| `orderStatus` | **2** |
| `spotClearinghouseState` | **2** |
| `exchangeStatus` | **2** |
| `userRole` | **60** |
| All other documented info endpoints | **20** |

### Per-items-returned surcharge

| Data Type | Surcharge |
|-----------|-----------|
| Fills, trades, funding entries, etc. | **+1 per 20 items** returned |
| Candles | **+1 per 60 candles** returned |

### Explorer API

| Endpoint | Weight |
|----------|--------|
| All Explorer API requests | **40** |

### Weight calculation examples

```
# allMids (lightweight)
weight = 2

# clearinghouseState (lightweight)
weight = 2

# userFills returning 200 fills
weight = 20 + ceil(200 / 20) = 20 + 10 = 30

# candleSnapshot returning 5000 candles
weight = 20 + ceil(5000 / 60) = 20 + 84 = 104

# historicalOrders (base 20, max 2000 orders)
weight = 20 + ceil(2000 / 20) = 20 + 100 = 120

# Batch order placement with 120 orders
weight = 1 + floor(120 / 40) = 1 + 3 = 4

# userRole (expensive)
weight = 60
```

> **Cross-reference:** For the full list of info query types and their response formats, see `info-queries.md`. For exchange action types, see `exchange-actions.md`.

---

## 3. Address-Based Limits

In addition to IP-based limits, each user address has its own rate limit budget based on cumulative trading volume.

### Core formula

```
Rate limit budget = 1 request per 1 USDC traded (cumulative lifetime volume)
```

### Initial buffer

Every new address starts with an **initial buffer of 10,000 requests**, even before any trading volume is generated. This allows bot setup, testing, and initial market data queries.

### When rate-limited

When an address exhausts its rate limit budget:

- The address is restricted to **1 request per 10 seconds**
- This applies to all requests made by or on behalf of that address
- The limit gradually replenishes as more trading volume is generated

### Cancel limit formula

Cancel operations have a separate, more generous limit:

```
Cancel limit = min(rate_limit + 100,000, rate_limit * 2)
```

This ensures that even accounts with modest trading volume can always cancel their open orders. For example:

| Trading Volume (USDC) | Request Budget | Cancel Budget |
|------------------------|----------------|---------------|
| 0 (new) | 10,000 | min(110,000, 20,000) = 20,000 |
| 50,000 | 60,000 | min(160,000, 120,000) = 120,000 |
| 500,000 | 510,000 | min(610,000, 1,020,000) = 610,000 |
| 5,000,000 | 5,010,000 | min(5,110,000, 10,020,000) = 5,110,000 |

### Important notes

- Volume is tracked **cumulatively** across the lifetime of the address.
- Both sides of a trade count toward volume (opening and closing a position both generate volume).
- The budget only decreases when requests are made. It does not decay over time.

---

## 4. Purchasing Additional Capacity

You can purchase additional rate limit capacity using the `reserveRequestWeight` exchange action.

### Price

**0.0005 USDC per request** (half a milli-USDC per request weight)

### Usage

```python
# Reserve 100,000 additional requests (costs 50 USDC)
exchange_payload = {
    "action": {
        "type": "reserveRequestWeight",
        "weight": 100000
    },
    "nonce": 1734567890123,
    "signature": {"r": "0x...", "s": "0x...", "v": 27}
}
```

With the Python SDK:

```python
# The SDK may not have a direct method for this.
# Use the raw exchange endpoint or check SDK documentation for updates.
# The action type is "reserveRequestWeight" with a "weight" field.
```

### Cost examples

| Additional Requests | Cost (USDC) |
|---------------------|-------------|
| 10,000 | 5.00 |
| 100,000 | 50.00 |
| 1,000,000 | 500.00 |

### When to use

- High-frequency trading bots that exceed volume-based budgets
- Market makers that need high cancel rates during volatile periods
- Data services that make many info queries without generating proportional trading volume
- Initial bot deployment when volume has not yet accumulated

> **Cross-reference:** The `reserveRequestWeight` action uses L1/phantom agent signing (chainId 1337). See `authentication-and-signing.md` for signing details. See `exchange-actions.md` section 2.7 for the full list of account management actions.

---

## 5. Sub-Account Rate Limit Behavior

**Sub-accounts are treated as separate users for rate limiting purposes.**

Each sub-account has its own:
- Address-based rate limit budget
- Trading volume counter
- Request tracking

This means:

- A master account with 1M USDC volume does NOT share that budget with its sub-accounts
- Each sub-account must build its own volume-based budget independently
- Each sub-account starts with the standard 10,000-request initial buffer
- The `reserveRequestWeight` action can be used per sub-account

### Practical implications

```
Master account:  0xMaster  → 500k volume → 510,000 request budget
Sub-account 1:   0xSub1    → 50k volume  →  60,000 request budget
Sub-account 2:   0xSub2    → 0 volume    →  10,000 request budget (initial buffer)
```

When designing multi-strategy systems with sub-accounts, allocate rate limit budgets separately and consider using `reserveRequestWeight` for sub-accounts that need high request rates before accumulating volume.

> **Cross-reference:** For sub-account creation and management, see `exchange-actions.md` section 2.7. For nonce management with sub-accounts (use separate API wallets), see `authentication-and-signing.md`.

---

## 6. Open Order Limits

The number of simultaneously open orders per address is capped.

### Formula

```
Max open orders = min(1000 + floor(volume_usdc / 5,000,000), 5000)
```

### Examples

| Lifetime Volume (USDC) | Max Open Orders |
|-------------------------|-----------------|
| 0 - 4,999,999 | 1,000 |
| 5,000,000 | 1,001 |
| 50,000,000 | 1,010 |
| 500,000,000 | 1,100 |
| 20,000,000,000+ | 5,000 (cap) |

### Behavior at 1000+ orders

When an address has **1000 or more** open orders:

- **Reduce-only orders are rejected** (cannot place new reduce-only orders)
- **Trigger orders are rejected** (cannot place new stop-loss or take-profit triggers)
- Regular limit orders can still be placed up to the cap

This means strategies that rely on many trigger orders (e.g., grid bots with stop-losses on every level) must stay below 1000 open orders or have sufficient volume for a higher cap.

### Mitigation strategies

```python
# Check open order count before placing new orders
open_orders = info.open_orders(address)
if len(open_orders) >= 990:
    # Approaching limit -- cancel oldest or least useful orders
    for order in open_orders[:10]:  # Cancel 10 oldest
        exchange.cancel(order["coin"], order["oid"])
```

---

## 7. Stale expiresAfter Penalty

The `expiresAfter` field on exchange actions sets a millisecond timestamp after which the action is rejected. If the action is received by the server **after** this timestamp, it is rejected AND **consumes 5x the normal rate limit weight**.

### Why this matters

```
Normal order placement:  1 weight
Stale expired order:     5 weight (5x penalty)
```

This penalty discourages spamming the network with pre-signed orders that have tight expiration windows. If your system pre-signs orders for future submission:

- Set `expiresAfter` with a generous buffer (several seconds, not milliseconds)
- Account for network latency and clock drift
- Never set `expiresAfter` in the past

### Example

```python
import time

# BAD: 100ms expiry -- likely to arrive stale
nonce = int(time.time() * 1000)
expires_after = nonce + 100  # Only 100ms window -- too tight

# GOOD: 5-second expiry -- safe buffer for network latency
expires_after = nonce + 5000  # 5 seconds

# ALSO GOOD: No expiry at all (omit the field)
# Only use expiresAfter when you specifically need time-limited actions
```

### Notes

- `expiresAfter` is **not supported on user-signed actions** (transfers, approveAgent, etc.). It only applies to L1 actions (orders, cancels, etc.).
- The `scheduleCancel` action (dead man's switch) uses a `time` field, not `expiresAfter`, and has different semantics.

> **Cross-reference:** For the full exchange action envelope including `expiresAfter`, see `exchange-actions.md` section 2.

---

## 8. Best Practices for Staying Within Limits

### 1. Use lightweight endpoints when possible

```python
# GOOD: allMids costs 2 weight -- use for price checks
mids = info.all_mids()

# EXPENSIVE: metaAndAssetCtxs costs 20 weight -- use sparingly
meta = info.meta_and_asset_ctxs()

# VERY EXPENSIVE: userRole costs 60 weight -- cache the result
role = info.user_role(address)  # Cache this, don't call repeatedly
```

### 2. Batch orders instead of individual requests

```python
# BAD: 10 individual orders = 10 weight
for order_params in orders:
    exchange.order(**order_params)  # 1 weight each, 10 total

# GOOD: 1 batch of 10 orders = 1 weight
exchange.bulk_orders(orders)  # 1 + floor(10/40) = 1 weight total
```

### 3. Use WebSocket instead of polling REST

```python
# BAD: Polling allMids every second = 2 weight/second = 120 weight/minute
while True:
    mids = info.all_mids()
    time.sleep(1)

# GOOD: WebSocket subscription = 0 REST weight
info.subscribe({"type": "allMids"}, on_mids_update)
```

### 4. Limit candle and fill queries

```python
# BAD: Requesting 5000 candles = 20 + 84 = 104 weight
candles = info.candles_snapshot("BTC", "1m", very_old_start, now)

# GOOD: Request only what you need (300 candles = 20 + 5 = 25 weight)
candles = info.candles_snapshot("BTC", "1m", five_hours_ago, now)
```

### 5. Cache metadata responses

```python
# Meta data changes infrequently -- cache for minutes, not seconds
import time

_meta_cache = None
_meta_cache_time = 0

def get_meta(info, ttl=300):
    """Cache meta response for 5 minutes."""
    global _meta_cache, _meta_cache_time
    now = time.time()
    if _meta_cache is None or now - _meta_cache_time > ttl:
        _meta_cache = info.meta()
        _meta_cache_time = now
    return _meta_cache
```

### 6. Spread requests across time

```python
# BAD: Burst all queries at once
for coin in all_coins:  # 200 coins * 2 weight = 400 weight in 1 second
    info.l2_snapshot(coin)

# GOOD: Spread queries with small delays
import asyncio

async def fetch_books_throttled(info, coins, max_per_second=20):
    for i, coin in enumerate(coins):
        info.l2_snapshot(coin)
        if (i + 1) % max_per_second == 0:
            await asyncio.sleep(1)
```

### 7. Cancel via nonce invalidation

```python
# Standard cancel: 1 weight per cancel
exchange.cancel("ETH", oid)  # 1 weight

# Alternative: noop to invalidate nonce (also 1 weight but useful in specific patterns)
# The noop action can invalidate a nonce without performing any trading action
```

### 8. Track your budget

```python
class RateLimitTracker:
    """Track request weight usage per minute."""
    def __init__(self, max_weight=1200, window_seconds=60):
        self.max_weight = max_weight
        self.window = window_seconds
        self.requests = []  # List of (timestamp, weight)

    def can_request(self, weight=1):
        self._prune()
        current_weight = sum(w for _, w in self.requests)
        return current_weight + weight <= self.max_weight

    def record(self, weight=1):
        self.requests.append((time.time(), weight))

    def _prune(self):
        cutoff = time.time() - self.window
        self.requests = [(t, w) for t, w in self.requests if t > cutoff]

    @property
    def remaining(self):
        self._prune()
        return self.max_weight - sum(w for _, w in self.requests)
```

---

## 9. Monitoring Rate Limit Status

Use the `userRateLimit` info query to check your current rate limit consumption and capacity.

### Request

```json
{"type": "userRateLimit", "user": "0x1234..."}
```

### Response

```json
{
  "cumVlm": "1500000.50",
  "nRequestsUsed": 45230,
  "nRequestsCap": 1510000
}
```

| Field | Description |
|-------|-------------|
| `cumVlm` | Cumulative lifetime trading volume in USDC |
| `nRequestsUsed` | Total number of requests consumed |
| `nRequestsCap` | Total request budget (10,000 + cumVlm + purchased) |

### Calculating remaining budget

```python
def check_rate_limit(info, address):
    """Check and report rate limit status."""
    rl = info.user_rate_limit(address)

    cum_vlm = float(rl["cumVlm"])
    used = int(rl["nRequestsUsed"])
    cap = int(rl["nRequestsCap"])
    remaining = cap - used
    pct_used = (used / cap * 100) if cap > 0 else 0

    print(f"Volume:    {cum_vlm:,.2f} USDC")
    print(f"Used:      {used:,} / {cap:,} requests")
    print(f"Remaining: {remaining:,} requests ({100 - pct_used:.1f}%)")

    if remaining < 1000:
        print("WARNING: Rate limit budget nearly exhausted!")
        print(f"  Consider: reserveRequestWeight (0.0005 USDC/request)")
        print(f"  Or generate more trading volume")

    return remaining
```

### Automated monitoring

```python
import asyncio

async def monitor_rate_limits(info, address, interval=60):
    """Periodically check rate limit status and alert if low."""
    while True:
        remaining = check_rate_limit(info, address)
        if remaining < 5000:
            # Trigger alert -- Slack webhook, email, log, etc.
            alert_low_rate_limit(address, remaining)
        await asyncio.sleep(interval)
```

> **Cross-reference:** The `userRateLimit` endpoint has weight 20. For all available info query types, see `info-queries.md`. For the `reserveRequestWeight` exchange action, see `exchange-actions.md` section 2.7. For WebSocket connection and subscription limits, see `websocket-channels.md` section 1.
