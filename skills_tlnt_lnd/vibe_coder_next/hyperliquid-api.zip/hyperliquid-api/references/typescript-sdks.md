# TypeScript SDKs — Hyperliquid API Reference

## Table of Contents

1. [@nktkas/hyperliquid (Recommended)](#1-nktkashyperliquid-recommended)
2. [nomeida/hyperliquid](#2-nomeidahyperliquid)
3. [CCXT Integration](#3-ccxt-integration)
4. [SDK Comparison Table](#4-sdk-comparison-table)
5. [Full Code Examples](#5-full-code-examples)

---

## 1. @nktkas/hyperliquid (Recommended)

**GitHub:** [github.com/nktkas/hyperliquid](https://github.com/nktkas/hyperliquid) (326 stars)
**Install:** `npm i @nktkas/hyperliquid`
**Architecture:** Modular -- separate clients for info, exchange, and subscriptions
**Wallet support:** Works with **viem**, **ethers**, or built-in `PrivateKeySigner`

This is the recommended TypeScript SDK for Hyperliquid. It provides a clean, type-safe API that maps closely to the raw Hyperliquid API, giving you full control with strong TypeScript support.

### 1.1 Installation

```bash
npm i @nktkas/hyperliquid

# With viem for wallet management (recommended)
npm i @nktkas/hyperliquid viem

# Or with ethers
npm i @nktkas/hyperliquid ethers
```

### 1.2 Architecture

The SDK is split into three independent clients:

| Client | Purpose | Transport |
|--------|---------|-----------|
| `InfoClient` | Read-only market data and user state queries | `HttpTransport` |
| `ExchangeClient` | Signed trading actions (orders, cancels, etc.) | `HttpTransport` |
| `SubscriptionClient` | Real-time WebSocket subscriptions | `WebSocketTransport` |

Each client is instantiated separately, so you can use only what you need.

### 1.3 InfoClient -- read-only queries

```typescript
import { HttpTransport, InfoClient } from "@nktkas/hyperliquid";

const info = new InfoClient({ transport: new HttpTransport() });

// Market metadata
const meta = await info.meta();
// Returns: { universe: [{ name: "BTC", szDecimals: 5, maxLeverage: 50 }, ...] }

// Meta + live asset context (funding, OI, prices)
const [metaData, assetCtxs] = await info.metaAndAssetCtxs();

// All mid prices
const mids = await info.allMids();
// Returns: { "BTC": "95123.5", "ETH": "2891.3", ... }

// L2 orderbook (max 20 levels per side)
const book = await info.l2Book({ coin: "ETH" });
// Returns: { levels: [[bids], [asks]], coin: "ETH", time: ... }

// Candle snapshot (OHLCV)
const candles = await info.candleSnapshot({
  coin: "BTC",
  interval: "1h",
  startTime: Date.now() - 3600_000,
  endTime: Date.now(),
});

// User state (positions, margin, balances)
const state = await info.clearinghouseState({ user: "0x..." });
// Key fields: assetPositions, marginSummary, withdrawable

// Spot balances
const spotState = await info.spotClearinghouseState({ user: "0x..." });

// Open orders
const orders = await info.openOrders({ user: "0x..." });
const detailedOrders = await info.frontendOpenOrders({ user: "0x..." });

// User fills
const fills = await info.userFills({ user: "0x..." });
const fillsByTime = await info.userFillsByTime({
  user: "0x...",
  startTime: Date.now() - 86400_000,
  endTime: Date.now(),
});

// Order status by OID
const orderStatus = await info.orderStatus({ user: "0x...", oid: 77738308 });

// Funding history
const funding = await info.fundingHistory({
  coin: "ETH",
  startTime: Date.now() - 86400_000,
});

// User rate limit
const rateLimit = await info.userRateLimit({ user: "0x..." });
// Returns: { cumVlm, nRequestsUsed, nRequestsCap }
```

### 1.4 ExchangeClient -- trading actions

```typescript
import { HttpTransport, ExchangeClient } from "@nktkas/hyperliquid";
import { privateKeyToAccount } from "viem/accounts";

const wallet = privateKeyToAccount("0xPRIVATE_KEY");
const exchange = new ExchangeClient({
  transport: new HttpTransport(),
  wallet,
});

// --- Order placement ---

// Limit order (GTC)
await exchange.order({
  orders: [{
    a: 0,        // asset index (BTC = 0)
    b: true,     // isBuy
    p: "95000",  // price (string, no trailing zeros)
    s: "0.01",   // size (string, no trailing zeros)
    r: false,    // reduceOnly
    t: { limit: { tif: "Gtc" } },
  }],
  grouping: "na",
});

// IOC order (market-like, fill-or-kill)
await exchange.order({
  orders: [{
    a: 1, b: true, p: "3000", s: "0.1", r: false,
    t: { limit: { tif: "Ioc" } },
  }],
  grouping: "na",
});

// ALO order (post-only)
await exchange.order({
  orders: [{
    a: 1, b: true, p: "2800", s: "0.1", r: false,
    t: { limit: { tif: "Alo" } },
  }],
  grouping: "na",
});

// Stop-loss trigger
await exchange.order({
  orders: [{
    a: 1, b: false, p: "2600", s: "0.1", r: true,
    t: { trigger: { triggerPx: "2650", isMarket: true, tpsl: "sl" } },
  }],
  grouping: "na",
});

// Take-profit trigger
await exchange.order({
  orders: [{
    a: 1, b: false, p: "3200", s: "0.1", r: true,
    t: { trigger: { triggerPx: "3100", isMarket: true, tpsl: "tp" } },
  }],
  grouping: "na",
});

// Entry + TP/SL grouped together
await exchange.order({
  orders: [
    { a: 1, b: true, p: "2800", s: "0.1", r: false, t: { limit: { tif: "Gtc" } } },
    { a: 1, b: false, p: "2600", s: "0.1", r: true,
      t: { trigger: { triggerPx: "2650", isMarket: true, tpsl: "sl" } } },
    { a: 1, b: false, p: "3200", s: "0.1", r: true,
      t: { trigger: { triggerPx: "3100", isMarket: true, tpsl: "tp" } } },
  ],
  grouping: "normalTpsl",
});

// With builder fee
await exchange.order({
  orders: [{ a: 0, b: true, p: "95000", s: "0.01", r: false, t: { limit: { tif: "Gtc" } } }],
  grouping: "na",
  builder: { b: "0xBuilderAddress", f: 10 }, // f=10 means 1bp (tenths of a bp)
});

// With client order ID (cloid)
await exchange.order({
  orders: [{
    a: 1, b: true, p: "2800", s: "0.1", r: false,
    t: { limit: { tif: "Gtc" } },
    c: "0x1234567890abcdef1234567890abcdef", // 128-bit hex cloid
  }],
  grouping: "na",
});

// --- Order modification and cancellation ---

// Cancel by OID
await exchange.cancel({ cancels: [{ a: 0, o: 77738308 }] });

// Cancel by CLOID
await exchange.cancelByCloid({
  cancels: [{ asset: 0, cloid: "0x1234567890abcdef1234567890abcdef" }],
});

// Modify order
await exchange.modify({
  oid: 77738308,
  order: { a: 0, b: true, p: "96000", s: "0.02", r: false, t: { limit: { tif: "Gtc" } } },
});

// Batch modify
await exchange.batchModify({
  modifies: [
    { oid: 77738308, order: { a: 0, b: true, p: "96000", s: "0.02", r: false, t: { limit: { tif: "Gtc" } } } },
    { oid: 77738309, order: { a: 1, b: false, p: "3200", s: "0.5", r: false, t: { limit: { tif: "Gtc" } } } },
  ],
});

// --- Position management ---

// Update leverage
await exchange.updateLeverage({ asset: 0, isCross: true, leverage: 5 });
await exchange.updateLeverage({ asset: 1, isCross: false, leverage: 10 });

// Schedule cancel (dead man's switch)
await exchange.scheduleCancel({ time: Date.now() + 60_000 }); // 60s from now
```

### 1.5 SubscriptionClient -- WebSocket streaming

```typescript
import { SubscriptionClient, WebSocketTransport } from "@nktkas/hyperliquid";

const subs = new SubscriptionClient({ transport: new WebSocketTransport() });

// All mid prices
const midsSub = await subs.allMids((data) => {
  console.log("BTC:", data.mids["BTC"], "ETH:", data.mids["ETH"]);
});

// L2 orderbook
const bookSub = await subs.l2Book({ coin: "ETH" }, (data) => {
  const bestBid = data.levels[0][0]?.px;
  const bestAsk = data.levels[1][0]?.px;
  console.log(`ETH spread: ${bestBid} / ${bestAsk}`);
});

// Real-time trades
const tradesSub = await subs.trades({ coin: "ETH" }, (trades) => {
  for (const t of trades) {
    console.log(`${t.side === "B" ? "BUY" : "SELL"} ${t.sz} @ ${t.px}`);
  }
});

// Candles
await subs.candle({ coin: "BTC", interval: "5m" }, (candle) => {
  console.log(`BTC 5m: O=${candle.o} H=${candle.h} L=${candle.l} C=${candle.c}`);
});

// Order updates (user-specific)
await subs.orderUpdates({ user: "0x..." }, (orders) => {
  for (const o of orders) {
    console.log(`Order ${o.order.oid}: ${o.status} (${o.order.coin})`);
  }
});

// User fills
await subs.userFills({ user: "0x..." }, (data) => {
  const label = data.isSnapshot ? "SNAPSHOT" : "NEW";
  for (const fill of data.fills) {
    console.log(`[${label}] ${fill.coin} ${fill.side} ${fill.sz} @ ${fill.px}`);
  }
});

// Unsubscribe when done
await midsSub.unsubscribe();
await bookSub.unsubscribe();
await tradesSub.unsubscribe();
```

### 1.6 Wallet options

The SDK supports three wallet providers:

```typescript
// Option 1: viem (recommended)
import { privateKeyToAccount } from "viem/accounts";
const wallet = privateKeyToAccount("0xPRIVATE_KEY");

// Option 2: ethers
import { Wallet } from "ethers";
const wallet = new Wallet("0xPRIVATE_KEY");

// Option 3: Built-in PrivateKeySigner
import { PrivateKeySigner } from "@nktkas/hyperliquid";
const wallet = new PrivateKeySigner("0xPRIVATE_KEY");

// All three work the same way with ExchangeClient
const exchange = new ExchangeClient({ transport: new HttpTransport(), wallet });
```

> **Cross-reference:** For the raw JSON API that this SDK wraps, see `exchange-actions.md` and `info-queries.md`. For WebSocket channel details and data formats, see `websocket-channels.md`.

---

## 2. nomeida/hyperliquid

**GitHub:** [github.com/nomeida/hyperliquid](https://github.com/nomeida/hyperliquid) (268 stars)
**Install:** `npm i hyperliquid`
**Requires:** Node.js 22+ (uses native WebSocket)
**Architecture:** Single `Hyperliquid` class with `.info`, `.exchange`, and `.subscriptions` namespaces
**Symbol format:** `BTC-PERP` / `ETH-PERP` (human-readable, not raw indices)

This SDK provides a higher-level API with convenience features like built-in rate limiting, automatic asset map refresh, and human-readable symbol names.

### 2.1 Installation

```bash
npm i hyperliquid
# Requires Node.js 22+ for native WebSocket support
```

### 2.2 Setup

```typescript
const { Hyperliquid } = require("hyperliquid");

// Basic setup (personal wallet)
const sdk = new Hyperliquid({
  privateKey: "0xPRIVATE_KEY",
  testnet: false,
});

// API Agent Wallet setup (requires walletAddress of master account)
const sdk = new Hyperliquid({
  privateKey: "0xAGENT_PRIVATE_KEY",
  testnet: false,
  walletAddress: "0xMASTER_ADDRESS",  // Required ONLY for API Agent Wallets
});
```

### 2.3 Info methods

```typescript
// Metadata
const meta = await sdk.info.perpetualsMetaAndAssetCtxs();

// All mid prices
const mids = await sdk.info.allMids();

// Orderbook
const book = await sdk.info.l2Snapshot("ETH-PERP");

// User state
const state = await sdk.info.perpetualsAccountState("0x...");

// Open orders
const orders = await sdk.info.openOrders("0x...");

// Fills
const fills = await sdk.info.userFills("0x...");
```

### 2.4 Exchange methods

```typescript
// Place order (uses human-readable symbol format)
const result = await sdk.exchange.placeOrder({
  coin: "BTC-PERP",
  is_buy: true,
  sz: 1,
  limit_px: 30000,
  order_type: { limit: { tif: "Gtc" } },
  reduce_only: false,
});

// Cancel order
await sdk.exchange.cancelOrder({
  coin: "ETH-PERP",
  oid: 77738308,
});

// Update leverage
await sdk.exchange.updateLeverage({
  coin: "ETH-PERP",
  leverage: 10,
  is_cross: true,
});
```

### 2.5 WebSocket subscriptions

```typescript
// Connect WebSocket first
await sdk.connect();

// Subscribe to all mid prices
sdk.subscriptions.subscribeToAllMids((data) => {
  console.log("Mids updated:", data);
});

// Subscribe to orderbook
sdk.subscriptions.subscribeToL2Book("ETH-PERP", (data) => {
  console.log("Book:", data);
});

// Subscribe to trades
sdk.subscriptions.subscribeToTrades("BTC-PERP", (trades) => {
  for (const trade of trades) {
    console.log(`${trade.side} ${trade.sz} @ ${trade.px}`);
  }
});

// Subscribe to user events
sdk.subscriptions.subscribeToUserEvents("0x...", (events) => {
  console.log("User events:", events);
});

// Disconnect when done
await sdk.disconnect();
```

### 2.6 Key features

- **Built-in rate limiting**: Automatically throttles requests to stay within limits.
- **Auto asset map refresh**: Keeps asset indices and symbols synchronized.
- **Human-readable symbols**: Use `BTC-PERP` instead of asset index `0`.
- **Auto referral code**: Automatically sets a referral code.
- **Native WebSocket**: Uses Node.js 22+ native WebSocket (no external dependency).

> **Cross-reference:** For asset indexing (how `BTC-PERP` maps to index 0), see `connection-and-endpoints.md`. For rate limit details, see `rate-limits.md`.

---

## 3. CCXT Integration

**Library:** [CCXT](https://github.com/ccxt/ccxt) (multi-exchange trading library)
**Install:** `pip install ccxt` (Python) or `npm i ccxt` (JavaScript)
**Symbol format:** `BTC/USDC:USDC` (CCXT unified format)

CCXT provides a standardized interface across 100+ exchanges. The Hyperliquid connector allows you to use the same code structure for Hyperliquid as for Binance, Bybit, and others.

### 3.1 Python setup

```python
import ccxt

exchange = ccxt.hyperliquid({
    "walletAddress": "0xYOUR_ADDRESS",
    "privateKey": "0xPRIVATE_KEY",
})

# Load markets (required before trading)
await exchange.load_markets()
```

### 3.2 JavaScript setup

```javascript
const ccxt = require("ccxt");

const exchange = new ccxt.hyperliquid({
  walletAddress: "0xYOUR_ADDRESS",
  privateKey: "0xPRIVATE_KEY",
});

await exchange.loadMarkets();
```

### 3.3 Available methods

```python
# Place order (CCXT unified format)
order = await exchange.create_order("BTC/USDC:USDC", "limit", "buy", 0.001, 95000)

# Cancel order
await exchange.cancel_order(order["id"], "BTC/USDC:USDC")

# Fetch balance
balance = await exchange.fetch_balance()

# Fetch orderbook
book = await exchange.fetch_order_book("ETH/USDC:USDC")

# Fetch OHLCV candles
candles = await exchange.fetch_ohlcv("BTC/USDC:USDC", "1h", limit=100)

# Fetch recent trades
trades = await exchange.fetch_trades("ETH/USDC:USDC")

# Set leverage
await exchange.set_leverage(10, "BTC/USDC:USDC")

# Withdraw
await exchange.withdraw("USDC", 100, "0xDEST_ADDRESS")
```

### 3.4 Symbol format

CCXT uses its unified symbol format, which differs from both the raw API and other SDKs:

| Raw API / @nktkas | nomeida | CCXT |
|-------------------|---------|------|
| Asset index `0` | `BTC-PERP` | `BTC/USDC:USDC` |
| Asset index `1` | `ETH-PERP` | `ETH/USDC:USDC` |
| `"SOL"` | `SOL-PERP` | `SOL/USDC:USDC` |

### 3.5 Limitations

- **Added abstraction overhead**: CCXT adds a layer of abstraction that increases latency compared to direct API calls or native SDKs.
- **Feature gaps**: TWAP orders, vault features, HIP-3 perps, and some advanced features may not be fully exposed through CCXT.
- **Symbol mapping**: Some Hyperliquid-specific asset naming (e.g., `UBTC/USDC` remapping, `@index` format for spot) may not be handled automatically.
- **Rate limiting**: CCXT has its own rate limiting logic that may not perfectly align with Hyperliquid's weight-based system.
- **Updates lag**: New Hyperliquid features may take time to be added to CCXT.

### 3.6 When to use CCXT

- You need to trade on **multiple exchanges** with a unified codebase
- You are migrating an existing CCXT-based bot to include Hyperliquid
- You need **quick prototyping** and are already familiar with CCXT
- You do not need TWAP, vaults, HIP-3, or the lowest possible latency

> **Cross-reference:** For a comparison of CCXT's limitations vs native SDKs, see the comparison table in section 4. For the official Python SDK (better for Hyperliquid-specific features), see `python-sdk.md`.

---

## 4. SDK Comparison Table

| Feature | @nktkas/hyperliquid | nomeida/hyperliquid | CCXT |
|---------|---------------------|---------------------|------|
| **Stars** | 326 | 268 | 35,000+ (multi-exchange) |
| **Language** | TypeScript | TypeScript/JS | Python / JavaScript |
| **Install** | `npm i @nktkas/hyperliquid` | `npm i hyperliquid` | `npm i ccxt` / `pip install ccxt` |
| **Architecture** | Modular (3 clients) | Single class | Unified exchange class |
| **Node.js version** | Any modern | 22+ (native WS) | Any modern |
| **Symbol format** | Raw indices / coin names | `BTC-PERP` | `BTC/USDC:USDC` |
| **Wallet support** | viem, ethers, built-in | Built-in | Built-in |
| **Type safety** | Full TypeScript | TypeScript | Partial |
| **Rate limiting** | Manual | Built-in | Built-in (generic) |
| **WebSocket** | `SubscriptionClient` | `.subscriptions` | Not for Hyperliquid |
| **All 19 WS channels** | Yes | Yes | No |
| **TWAP orders** | Yes | Yes | No |
| **Vault operations** | Yes | Yes | No |
| **HIP-3 perps** | Yes | Check latest | No |
| **Builder fees** | Yes | Check latest | No |
| **Client Order ID** | Yes | Yes | Partial |
| **Multi-exchange** | No (Hyperliquid only) | No (Hyperliquid only) | Yes (100+ exchanges) |
| **Latency** | Low (direct API) | Low (direct API) | Higher (abstraction) |
| **Learning curve** | Medium (close to raw API) | Low (high-level API) | Low (if familiar) |
| **Best for** | Full control, type safety | Quick start, convenience | Multi-exchange systems |

### Recommendation

- **Default choice**: Use `@nktkas/hyperliquid` for TypeScript projects. It has the most stars, most active maintenance, full feature coverage, and works with your preferred wallet library.
- **Quick prototyping**: Use `nomeida/hyperliquid` if you prefer a higher-level API with human-readable symbols and built-in rate limiting.
- **Multi-exchange**: Use CCXT if you need to trade on Hyperliquid alongside other exchanges with a unified interface, and you can accept the feature limitations.

---

## 5. Full Code Examples

### 5.1 @nktkas/hyperliquid: complete trading workflow

```typescript
import {
  HttpTransport,
  InfoClient,
  ExchangeClient,
  SubscriptionClient,
  WebSocketTransport,
} from "@nktkas/hyperliquid";
import { privateKeyToAccount } from "viem/accounts";

// ============================================================
// 1. SETUP
// ============================================================
const wallet = privateKeyToAccount("0xPRIVATE_KEY");
const transport = new HttpTransport();
const info = new InfoClient({ transport });
const exchange = new ExchangeClient({ transport, wallet });

// ============================================================
// 2. MARKET DATA
// ============================================================
const [meta, ctxs] = await info.metaAndAssetCtxs();
const mids = await info.allMids();
console.log("BTC mid:", mids["BTC"]);
console.log("ETH funding:", ctxs[1].funding);
console.log("ETH OI:", ctxs[1].openInterest);

// Orderbook
const book = await info.l2Book({ coin: "ETH" });
console.log("Best bid:", book.levels[0][0]?.px, "Best ask:", book.levels[1][0]?.px);

// ============================================================
// 3. ACCOUNT STATE
// ============================================================
const state = await info.clearinghouseState({ user: wallet.address });
console.log("Account value:", state.marginSummary.accountValue);
console.log("Withdrawable:", state.withdrawable);

// Check rate limit
const rl = await info.userRateLimit({ user: wallet.address });
console.log(`Rate limit: ${rl.nRequestsUsed}/${rl.nRequestsCap}`);

// ============================================================
// 4. SET LEVERAGE
// ============================================================
await exchange.updateLeverage({ asset: 1, isCross: true, leverage: 5 });

// ============================================================
// 5. PLACE ORDER WITH CLOID
// ============================================================
const ethMid = parseFloat(mids["ETH"]);
const entryPrice = (ethMid * 0.97).toFixed(1); // 3% below mid

const result = await exchange.order({
  orders: [{
    a: 1, // ETH
    b: true,
    p: entryPrice,
    s: "0.1",
    r: false,
    t: { limit: { tif: "Gtc" } },
    c: "0x1234567890abcdef1234567890abcdef",
  }],
  grouping: "na",
});

// Parse response
const statuses = result.response.data.statuses;
let oid: number | undefined;
for (const s of statuses) {
  if ("resting" in s) {
    oid = s.resting.oid;
    console.log(`Order resting: OID ${oid}`);
  } else if ("filled" in s) {
    console.log(`Filled: ${s.filled.totalSz} @ ${s.filled.avgPx}`);
  } else if ("error" in s) {
    console.log(`Error: ${s.error}`);
  }
}

// ============================================================
// 6. STOP-LOSS AND TAKE-PROFIT
// ============================================================
const slPrice = (ethMid * 0.93).toFixed(1);
const tpPrice = (ethMid * 1.05).toFixed(1);

await exchange.order({
  orders: [
    // Stop-loss
    { a: 1, b: false, p: slPrice, s: "0.1", r: true,
      t: { trigger: { triggerPx: slPrice, isMarket: true, tpsl: "sl" } } },
    // Take-profit
    { a: 1, b: false, p: tpPrice, s: "0.1", r: true,
      t: { trigger: { triggerPx: tpPrice, isMarket: true, tpsl: "tp" } } },
  ],
  grouping: "na",
});

// ============================================================
// 7. REAL-TIME STREAMING
// ============================================================
const subs = new SubscriptionClient({ transport: new WebSocketTransport() });

await subs.l2Book({ coin: "ETH" }, (data) => {
  console.log("Best bid:", data.levels[0][0]?.px, "Best ask:", data.levels[1][0]?.px);
});

await subs.trades({ coin: "ETH" }, (trades) => {
  for (const t of trades) {
    console.log(`${t.side === "B" ? "BUY" : "SELL"} ${t.sz} @ ${t.px}`);
  }
});

await subs.orderUpdates({ user: wallet.address }, (orders) => {
  for (const o of orders) {
    console.log(`Order ${o.order.oid}: ${o.status}`);
    if (o.status === "filled") {
      console.log("  Filled! Check position state.");
    }
  }
});

// ============================================================
// 8. CANCEL AND CLOSE
// ============================================================
if (oid) {
  await exchange.cancel({ cancels: [{ a: 1, o: oid }] });
}

// Close position: reduce-only IOC at aggressive price
await exchange.order({
  orders: [{
    a: 1, b: false, p: "0.01", s: "0.1", r: true,
    t: { limit: { tif: "Ioc" } },
  }],
  grouping: "na",
});
```

### 5.2 nomeida/hyperliquid: complete workflow

```typescript
const { Hyperliquid } = require("hyperliquid");

// ============================================================
// 1. SETUP
// ============================================================
const sdk = new Hyperliquid({
  privateKey: "0xPRIVATE_KEY",
  testnet: false,
});

// ============================================================
// 2. MARKET DATA
// ============================================================
const mids = await sdk.info.allMids();
console.log("BTC:", mids["BTC"], "ETH:", mids["ETH"]);

const book = await sdk.info.l2Snapshot("ETH-PERP");
console.log("Bids:", book.levels[0].length, "Asks:", book.levels[1].length);

// ============================================================
// 3. ACCOUNT STATE
// ============================================================
const state = await sdk.info.perpetualsAccountState("0xADDRESS");
console.log("Account value:", state.marginSummary.accountValue);

// ============================================================
// 4. PLACE ORDER
// ============================================================
const result = await sdk.exchange.placeOrder({
  coin: "ETH-PERP",
  is_buy: true,
  sz: 0.1,
  limit_px: 2800,
  order_type: { limit: { tif: "Gtc" } },
  reduce_only: false,
});

// ============================================================
// 5. WEBSOCKET STREAMING
// ============================================================
await sdk.connect();

sdk.subscriptions.subscribeToAllMids((data) => {
  console.log("BTC mid:", data.mids["BTC"]);
});

sdk.subscriptions.subscribeToL2Book("ETH-PERP", (data) => {
  const spread = parseFloat(data.levels[1][0].px) - parseFloat(data.levels[0][0].px);
  console.log(`ETH spread: ${spread.toFixed(2)}`);
});

sdk.subscriptions.subscribeToTrades("ETH-PERP", (trades) => {
  for (const t of trades) {
    console.log(`Trade: ${t.side} ${t.sz} ETH @ ${t.px}`);
  }
});

// ============================================================
// 6. CANCEL
// ============================================================
await sdk.exchange.cancelOrder({
  coin: "ETH-PERP",
  oid: result.oid,
});

// ============================================================
// 7. DISCONNECT
// ============================================================
await sdk.disconnect();
```

### 5.3 CCXT: basic trading example

```python
import ccxt
import asyncio

async def main():
    # Setup
    exchange = ccxt.hyperliquid({
        "walletAddress": "0xYOUR_ADDRESS",
        "privateKey": "0xPRIVATE_KEY",
    })

    # Load markets
    await exchange.load_markets()

    # Fetch balance
    balance = await exchange.fetch_balance()
    print(f"USDC balance: {balance['USDC']['free']}")

    # Fetch orderbook
    book = await exchange.fetch_order_book("ETH/USDC:USDC")
    print(f"Best bid: {book['bids'][0][0]}, Best ask: {book['asks'][0][0]}")

    # Fetch candles
    candles = await exchange.fetch_ohlcv("BTC/USDC:USDC", "1h", limit=24)
    for c in candles[-3:]:
        print(f"  {c[0]}: O={c[1]} H={c[2]} L={c[3]} C={c[4]} V={c[5]}")

    # Set leverage
    await exchange.set_leverage(5, "ETH/USDC:USDC")

    # Place limit order
    order = await exchange.create_order(
        "ETH/USDC:USDC", "limit", "buy", 0.1, 2800
    )
    print(f"Order placed: {order['id']}")

    # Cancel order
    await exchange.cancel_order(order["id"], "ETH/USDC:USDC")
    print("Order canceled")

    await exchange.close()

asyncio.run(main())
```

```javascript
// JavaScript equivalent
const ccxt = require("ccxt");

async function main() {
  const exchange = new ccxt.hyperliquid({
    walletAddress: "0xYOUR_ADDRESS",
    privateKey: "0xPRIVATE_KEY",
  });

  await exchange.loadMarkets();

  // Fetch balance
  const balance = await exchange.fetchBalance();
  console.log("USDC:", balance["USDC"]["free"]);

  // Place order
  const order = await exchange.createOrder(
    "BTC/USDC:USDC", "limit", "buy", 0.001, 95000
  );
  console.log("Order:", order.id);

  // Cancel
  await exchange.cancelOrder(order.id, "BTC/USDC:USDC");

  await exchange.close();
}

main();
```

> **Cross-reference:** For the Python SDK equivalent of these workflows, see `python-sdk.md` section 8. For detailed order type options (GTC, IOC, ALO, triggers), see `exchange-actions.md`. For WebSocket channel data formats, see `websocket-channels.md`. For rate limit considerations, see `rate-limits.md`.
