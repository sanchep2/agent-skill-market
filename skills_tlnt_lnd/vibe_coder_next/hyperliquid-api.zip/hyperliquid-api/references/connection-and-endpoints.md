# Connection and Endpoints

## Table of Contents

1. [Mainnet Base URLs](#1-mainnet-base-urls)
2. [Testnet Base URLs](#2-testnet-base-urls)
3. [HyperEVM RPC Endpoints](#3-hyperevm-rpc-endpoints)
4. [Request Format](#4-request-format)
5. [Asset Indexing](#5-asset-indexing)
6. [Asset Remapping](#6-asset-remapping)
7. [Testnet Development Workflow](#7-testnet-development-workflow)
8. [HyperEVM Chain IDs](#8-hyperevm-chain-ids)
9. [Third-Party Faucets](#9-third-party-faucets)
10. [Quick Connection Examples](#10-quick-connection-examples)

---

## 1. Mainnet Base URLs

All production traffic uses these endpoints:

| Service | URL |
|---------|-----|
| REST API | `https://api.hyperliquid.xyz` |
| WebSocket | `wss://api.hyperliquid.xyz/ws` |
| HyperEVM RPC | `https://rpc.hyperliquid.xyz/evm` |
| Web App | `https://app.hyperliquid.xyz` |

REST info queries go to `/info`, trading actions go to `/exchange`. Both accept only `POST` requests.

```bash
# Verify mainnet connectivity
curl -s -X POST https://api.hyperliquid.xyz/info \
  -H "Content-Type: application/json" \
  -d '{"type": "meta"}' | head -c 200
```

---

## 2. Testnet Base URLs

Testnet mirrors the mainnet API structure exactly. Swap the base URL and use `"Testnet"` instead of `"Mainnet"` in signing fields.

| Service | URL |
|---------|-----|
| REST API | `https://api.hyperliquid-testnet.xyz` |
| WebSocket | `wss://api.hyperliquid-testnet.xyz/ws` |
| Web App | `https://app.hyperliquid-testnet.xyz` |
| Faucet | `https://app.hyperliquid-testnet.xyz/drip` |

```bash
# Verify testnet connectivity
curl -s -X POST https://api.hyperliquid-testnet.xyz/info \
  -H "Content-Type: application/json" \
  -d '{"type": "allMids"}' | head -c 200
```

---

## 3. HyperEVM RPC Endpoints

HyperEVM is the Ethereum-compatible layer sharing consensus with HyperCore. It supports standard JSON-RPC methods.

| Network | RPC URL | Chain ID |
|---------|---------|----------|
| Mainnet | `https://rpc.hyperliquid.xyz/evm` | **999** |
| Testnet | (use testnet RPC equivalent) | **998** |

HyperEVM block time is 1 second with a 2M gas limit per block. Rate limit: **100 requests/minute** per IP.

```javascript
// ethers.js connection to HyperEVM
import { ethers } from "ethers";
const provider = new ethers.JsonRpcProvider("https://rpc.hyperliquid.xyz/evm", 999);
const blockNumber = await provider.getBlockNumber();
```

---

## 4. Request Format

All REST requests use `POST` with `Content-Type: application/json`. There are two primary endpoints:

| Endpoint | Path | Purpose |
|----------|------|---------|
| Info | `POST /info` | Read-only queries (market data, user state, metadata) |
| Exchange | `POST /exchange` | Signed trading actions (orders, cancels, transfers) |

**Info request structure:**

```json
{
  "type": "<query_type>",
  ...additional_params
}
```

**Exchange request structure:**

```json
{
  "action": { "type": "...", ...action_payload },
  "nonce": 1734567890123,
  "signature": { "r": "0x...", "s": "0x...", "v": 27 },
  "vaultAddress": "0x...",
  "expiresAfter": 1734567900000
}
```

The `vaultAddress` and `expiresAfter` fields are optional. See [exchange-actions.md](exchange-actions.md) for the full exchange request envelope details.

---

## 5. Asset Indexing

Hyperliquid uses different indexing schemes depending on the asset type. Understanding these is critical for constructing valid order and query payloads.

### Perpetual Assets

Perpetuals use the **numeric index** from the `meta` response's `universe` array. The index is zero-based.

| Asset | Index |
|-------|-------|
| BTC | 0 |
| ETH | 1 |
| (others) | Sequential from `meta` universe |

```json
// Get perpetual asset indices
{"type": "meta"}

// Response excerpt:
{
  "universe": [
    {"name": "BTC", "szDecimals": 5, "maxLeverage": 50},
    {"name": "ETH", "szDecimals": 4, "maxLeverage": 50}
  ]
}
```

When placing orders, the `a` field uses this numeric index (e.g., `"a": 0` for BTC, `"a": 1` for ETH).

### Spot Assets

Spot assets use `10000 + index` where `index` comes from the `spotMeta.universe` array.

```python
# Calculate spot asset index
spot_meta = info.spot_meta()
for i, asset in enumerate(spot_meta["universe"]):
    asset_index = 10000 + i
    print(f"{asset['name']}: index {asset_index}")
```

For info endpoint queries, spot coins use specific formats:
- PURR: `"PURR/USDC"`
- Other spot tokens: `"@{index}"` (e.g., `"@107"` for HYPE)

### HIP-3 Perp Assets

HIP-3 permissionless perpetual markets use the format `"dex_name:ASSET_NAME"`.

```
# HIP-3 asset format examples
xyz:XYZ100      # Nasdaq 100 index on xyz DEX
myDex:GOLD      # Gold perpetual on myDex
```

To discover HIP-3 assets, query the `perpDexs` and `allPerpMetas` info endpoints. See [info-queries.md](info-queries.md) for details.

### Info Query Coin Names

When querying the info endpoint, use the coin name string rather than the numeric index:
- Perps: `"ETH"`, `"BTC"`, `"SOL"`, etc.
- Spot: `"PURR/USDC"` or `"@107"`
- HIP-3: `"xyz:XYZ100"`

When placing orders via the exchange endpoint, always use the numeric asset index in the `a` field.

---

## 6. Asset Remapping

Some assets display differently on the Hyperliquid UI compared to their HyperCore API names. This can cause confusion when translating between the web app and programmatic access.

| UI Name | HyperCore Name | Notes |
|---------|---------------|-------|
| BTC/USDC (spot) | UBTC/USDC | UI remaps for user familiarity |

When building trading systems, always verify the actual HyperCore name by querying `meta` or `spotMeta`. Use the HyperCore name in all API calls.

```python
# Verify asset names from metadata
meta = info.meta()
for asset in meta["universe"]:
    print(f"HyperCore name: {asset['name']}, szDecimals: {asset['szDecimals']}")

spot_meta = info.spot_meta()
for token in spot_meta["tokens"]:
    print(f"Spot token: {token['name']}, index: {token['index']}")
```

---

## 7. Testnet Development Workflow

### Setup

1. **Prerequisite**: You must have deposited on mainnet at least once before using testnet.
2. **Access the faucet**: Navigate to `https://app.hyperliquid-testnet.xyz/drip`.
3. **Claim mock USDC**: Each claim provides **1,000 mock USDC** for testing.

### Programmatic Faucet Claim

You can claim testnet funds via the API:

```json
POST https://api.hyperliquid-testnet.xyz/info
{
  "type": "claimDrip",
  "user": "0xYourAddress"
}
```

```python
import requests

response = requests.post(
    "https://api.hyperliquid-testnet.xyz/info",
    json={"type": "claimDrip", "user": "0xYourAddress"},
    headers={"Content-Type": "application/json"}
)
print(response.json())
```

### Key Differences from Mainnet

| Aspect | Mainnet | Testnet |
|--------|---------|---------|
| REST URL | `api.hyperliquid.xyz` | `api.hyperliquid-testnet.xyz` |
| WebSocket URL | `wss://api.hyperliquid.xyz/ws` | `wss://api.hyperliquid-testnet.xyz/ws` |
| `hyperliquidChain` field | `"Mainnet"` | `"Testnet"` |
| Phantom agent source | `"a"` | `"b"` |
| HyperEVM Chain ID | 999 | 998 |
| EIP-712 chainId (user-signed) | 42161 | 421614 |
| Funds | Real USDC | Mock USDC (1,000 per faucet claim) |

**Important**: Testnet data and behavior may differ from mainnet. Use testnet for **technical flow validation** (signing, order lifecycle, WebSocket handling), not for performance testing or strategy backtesting.

### Testnet SDK Configuration

```python
# Python SDK — testnet
from hyperliquid.utils import constants

info = Info(constants.TESTNET_API_URL, skip_ws=True)
exchange = Exchange(wallet, constants.TESTNET_API_URL, account_address=wallet.address)
```

```typescript
// TypeScript SDK — testnet (@nktkas/hyperliquid)
const transport = new HttpTransport({ url: "https://api.hyperliquid-testnet.xyz" });
const info = new InfoClient({ transport });
const exchange = new ExchangeClient({
  transport,
  wallet: privateKeyToAccount("0x..."),
  isTestnet: true,
});
```

See [authentication-and-signing.md](authentication-and-signing.md) for how signing differs between mainnet and testnet.

---

## 8. HyperEVM Chain IDs

HyperEVM uses custom chain IDs that differ from Ethereum or Arbitrum:

| Network | Chain ID | Use |
|---------|----------|-----|
| HyperEVM Mainnet | **999** | EVM smart contract interactions |
| HyperEVM Testnet | **998** | EVM testnet development |

These are distinct from the EIP-712 signing chain IDs used in the trading API:

| Signing Context | Chain ID | Use |
|----------------|----------|-----|
| L1 Actions (phantom agent) | **1337** | Order, cancel, modify, leverage, TWAP |
| User-Signed Actions (mainnet) | **42161** | Transfers, withdrawals, approveAgent |
| User-Signed Actions (testnet) | **421614** | Testnet transfers, withdrawals |

Do not confuse HyperEVM chain IDs with EIP-712 signing chain IDs. Using the wrong chain ID produces invalid signatures. See [authentication-and-signing.md](authentication-and-signing.md) for full signing details.

---

## 9. Third-Party Faucets

In addition to the official testnet faucet, third-party services provide testnet HYPE tokens:

| Provider | Amount | Cooldown |
|----------|--------|----------|
| QuickNode | 1 HYPE | 12 hours |
| Chainstack | 1 HYPE | 24 hours |

These provide testnet HYPE tokens (not mock USDC). Use these for testing HyperEVM gas payments or staking flows on testnet.

---

## 10. Quick Connection Examples

### Python — Full Setup

```python
import eth_account
from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants

# Read-only connection (no private key needed)
info = Info(constants.MAINNET_API_URL, skip_ws=True)
mids = info.all_mids()
print(f"BTC: {mids['BTC']}, ETH: {mids['ETH']}")

# Trading connection
wallet = eth_account.Account.from_key("0xPRIVATE_KEY")
exchange = Exchange(wallet, constants.MAINNET_API_URL, account_address=wallet.address)

# With API wallet (agent wallet)
agent_wallet = eth_account.Account.from_key("0xAGENT_PRIVATE_KEY")
exchange = Exchange(
    agent_wallet,
    constants.MAINNET_API_URL,
    account_address="0xMASTER_WALLET_ADDRESS"  # Always the master wallet
)
```

### TypeScript — Full Setup

```typescript
import {
  HttpTransport,
  InfoClient,
  ExchangeClient,
  SubscriptionClient,
  WebSocketTransport,
} from "@nktkas/hyperliquid";
import { privateKeyToAccount } from "viem/accounts";

// Read-only
const transport = new HttpTransport();
const info = new InfoClient({ transport });
const mids = await info.allMids();

// Trading
const wallet = privateKeyToAccount("0xPRIVATE_KEY");
const exchange = new ExchangeClient({ transport, wallet });

// WebSocket subscriptions
const wsTransport = new WebSocketTransport();
const subs = new SubscriptionClient({ transport: wsTransport });
await subs.allMids((data) => console.log("Mids update:", data));
```

### Verifying Connectivity

```python
# Quick health check
import requests

def check_connection(base_url: str) -> bool:
    try:
        resp = requests.post(
            f"{base_url}/info",
            json={"type": "meta"},
            headers={"Content-Type": "application/json"},
            timeout=5,
        )
        data = resp.json()
        return "universe" in data
    except Exception as e:
        print(f"Connection failed: {e}")
        return False

# Check mainnet
check_connection("https://api.hyperliquid.xyz")

# Check testnet
check_connection("https://api.hyperliquid-testnet.xyz")
```

---

**Cross-references:**
- [authentication-and-signing.md](authentication-and-signing.md) -- Signing mechanics, chain IDs, and API wallet setup
- [exchange-actions.md](exchange-actions.md) -- All exchange endpoint actions and request envelopes
- [info-queries.md](info-queries.md) -- All info endpoint query types and response formats
