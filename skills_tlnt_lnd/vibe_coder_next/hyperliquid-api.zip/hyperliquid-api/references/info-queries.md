# Info Queries

## Table of Contents

1. [Info Endpoint Overview](#1-info-endpoint-overview)
2. [Market Metadata](#2-market-metadata)
3. [Market Data](#3-market-data)
4. [User State](#4-user-state)
5. [Orders and Fills](#5-orders-and-fills)
6. [Funding Data](#6-funding-data)
7. [User Info and Fees](#7-user-info-and-fees)
8. [Vault Endpoints](#8-vault-endpoints)
9. [Other Info Endpoints](#9-other-info-endpoints)
10. [Pagination and Limits](#10-pagination-and-limits)
11. [Rate Limit Weights](#11-rate-limit-weights)
12. [Python SDK Info Methods](#12-python-sdk-info-methods)
13. [TypeScript SDK Info Methods](#13-typescript-sdk-info-methods)

---

## 1. Info Endpoint Overview

All info requests are read-only queries sent via POST to the `/info` endpoint:

```
POST https://api.hyperliquid.xyz/info
Content-Type: application/json
```

Every request body has a `type` field that identifies the query, plus optional parameters:

```json
{
  "type": "<query_type>",
  ...additional_parameters
}
```

No authentication is required for info queries. Any client can read market data and user state.

**Important**: When querying user-specific data, always use the **master or subaccount address**, never an API wallet (agent) address. Using an agent address returns empty results. See [authentication-and-signing.md](authentication-and-signing.md) for details.

---

## 2. Market Metadata

### `meta` -- Perpetual Metadata

Returns the full perpetual market universe with asset parameters.

```json
// Request
{"type": "meta"}

// Response
{
  "universe": [
    {
      "name": "BTC",
      "szDecimals": 5,
      "maxLeverage": 50
    },
    {
      "name": "ETH",
      "szDecimals": 4,
      "maxLeverage": 50
    }
  ],
  "marginTables": [...]
}
```

**Universe fields:**

| Field | Description |
|-------|-------------|
| `name` | Asset symbol (e.g., "BTC", "ETH") |
| `szDecimals` | Size decimal precision |
| `maxLeverage` | Maximum allowed leverage |
| `onlyIsolated` | (optional) If true, only isolated margin allowed |
| `isDelisted` | (optional) If true, asset is delisted |
| `marginMode` | (optional) "strictIsolated" or "noCross" |
| `marginTableId` | (optional) ID for margin tier table |
| `growthMode` | (optional) Growth mode flag |

The index of each asset in the `universe` array is its **asset index** used in order placement. See [connection-and-endpoints.md](connection-and-endpoints.md) for asset indexing details.

### `metaAndAssetCtxs` -- Meta + Live Market Context

Returns perpetual metadata alongside live market context for each asset (funding, open interest, prices).

```json
// Request
{"type": "metaAndAssetCtxs"}

// Response: [meta_object, [asset_context, ...]]
```

**Asset context fields:**

| Field | Description |
|-------|-------------|
| `funding` | Current funding rate |
| `openInterest` | Total open interest |
| `prevDayPx` | Previous day's price |
| `dayNtlVlm` | 24h notional volume |
| `premium` | Current premium |
| `oraclePx` | Oracle price |
| `markPx` | Mark price |
| `midPx` | Mid price |
| `impactPxs` | Impact prices (for margin calculations) |
| `dayBaseVlm` | 24h base volume |

```python
# Python SDK
meta_and_ctxs = info.meta_and_asset_ctxs()
meta = meta_and_ctxs[0]
ctxs = meta_and_ctxs[1]

for i, asset in enumerate(meta["universe"]):
    ctx = ctxs[i]
    print(f"{asset['name']}: funding={ctx['funding']}, OI={ctx['openInterest']}, mark={ctx['markPx']}")
```

### `spotMeta` -- Spot Metadata

Returns spot market metadata with token definitions and trading pairs.

```json
// Request
{"type": "spotMeta"}

// Response includes tokens array and universe array
```

### `spotMetaAndAssetCtxs` -- Spot Meta + Live Context

Returns spot metadata alongside live market context for spot assets.

```json
// Request
{"type": "spotMetaAndAssetCtxs"}
```

### `perpDexs` -- List All Perp DEXes

Returns all registered perp DEXes (for HIP-3 permissionless perpetuals).

```json
// Request
{"type": "perpDexs"}
```

### `allPerpMetas` -- All Perp Metadata Across DEXes

Returns metadata for all perpetual assets across all DEXes, including HIP-3 assets.

```json
// Request
{"type": "allPerpMetas"}
```

---

## 3. Market Data

### `allMids` -- Mid Prices for All Assets

```json
// Request
{"type": "allMids"}

// Response
{"BTC": "29800.5", "ETH": "1890.3", "SOL": "125.7", ...}
```

Returns a map of coin name to mid-price string. Fast and lightweight query.

### `l2Book` -- L2 Orderbook Snapshot

Returns up to **20 levels** per side of the orderbook.

```json
// Request
{"type": "l2Book", "coin": "ETH", "nSigFigs": 5, "mantissa": null}

// Response
{
  "levels": [
    [
      {"px": "29790.0", "sz": "0.5", "n": 3},
      {"px": "29780.0", "sz": "1.2", "n": 5}
    ],
    [
      {"px": "29800.0", "sz": "0.3", "n": 2},
      {"px": "29810.0", "sz": "0.8", "n": 4}
    ]
  ],
  "coin": "ETH",
  "time": 1708622398623
}
```

- `levels[0]` = **bids** (descending by price)
- `levels[1]` = **asks** (ascending by price)
- Each level: `px` (price), `sz` (total size), `n` (number of orders)
- `nSigFigs`: Number of significant figures for price aggregation (2-5)
- `mantissa`: Optional mantissa for price bucketing

```python
# Python SDK
book = info.l2_snapshot("ETH")
best_bid = book["levels"][0][0]
best_ask = book["levels"][1][0]
spread = float(best_ask["px"]) - float(best_bid["px"])
print(f"Best bid: {best_bid['px']} ({best_bid['sz']}), Best ask: {best_ask['px']} ({best_ask['sz']}), Spread: {spread}")
```

### `recentTrades` -- Recent Trades

```json
// Request
{"type": "recentTrades", "coin": "BTC"}

// Response
[
  {
    "coin": "BTC",
    "side": "B",
    "px": "29800.0",
    "sz": "0.01",
    "hash": "0x...",
    "time": 1681222254710,
    "tid": 118906512037719
  }
]
```

- `side`: `"B"` = buyer aggressor (buy), `"A"` = seller aggressor (sell)
- `tid`: Unique trade identifier

### `candleSnapshot` -- OHLCV Candle Data

Returns up to **5000 candles** per request.

```json
// Request
{
  "type": "candleSnapshot",
  "req": {
    "coin": "BTC",
    "interval": "15m",
    "startTime": 1681222254710,
    "endTime": 1681308654710
  }
}

// Response
[
  {
    "t": 1681222200000,
    "T": 1681223100000,
    "s": "BTC",
    "i": "15m",
    "o": 29800.0,
    "c": 29850.0,
    "h": 29900.0,
    "l": 29750.0,
    "v": 123.45,
    "n": 500
  }
]
```

**Available intervals (14 total):**

| Interval | Code |
|----------|------|
| 1 minute | `1m` |
| 3 minutes | `3m` |
| 5 minutes | `5m` |
| 15 minutes | `15m` |
| 30 minutes | `30m` |
| 1 hour | `1h` |
| 2 hours | `2h` |
| 4 hours | `4h` |
| 8 hours | `8h` |
| 12 hours | `12h` |
| 1 day | `1d` |
| 3 days | `3d` |
| 1 week | `1w` |
| 1 month | `1M` |

**Candle response fields:**

| Field | Description |
|-------|-------------|
| `t` | Candle open timestamp (ms) |
| `T` | Candle close timestamp (ms) |
| `s` | Symbol |
| `i` | Interval |
| `o` | Open price |
| `c` | Close price |
| `h` | High price |
| `l` | Low price |
| `v` | Volume (base) |
| `n` | Number of trades |

```python
# Python SDK
import time
end_ms = int(time.time() * 1000)
start_ms = end_ms - 86400000  # 24 hours ago
candles = info.candles_snapshot("BTC", "1h", start_ms, end_ms)
for c in candles:
    print(f"Open: {c['o']}, Close: {c['c']}, High: {c['h']}, Low: {c['l']}, Vol: {c['v']}")
```

---

## 4. User State

### `clearinghouseState` -- Full Perpetual Account State

The most comprehensive user query. Returns all positions, margin details, and account summaries.

```json
// Request
{"type": "clearinghouseState", "user": "0xYourAddress"}
```

**Full response structure:**

```json
{
  "assetPositions": [
    {
      "position": {
        "coin": "ETH",
        "szi": "0.5",
        "entryPx": "2800.0",
        "positionValue": "1400.0",
        "unrealizedPnl": "50.0",
        "returnOnEquity": "0.035",
        "liquidationPx": "2100.0",
        "marginUsed": "280.0",
        "maxLeverage": 50,
        "leverage": {
          "type": "cross",
          "value": 5,
          "rawUsd": "280.0"
        },
        "cumFunding": {
          "allTime": "-12.5",
          "sinceChange": "-3.2",
          "sinceOpen": "-8.1"
        }
      }
    }
  ],
  "marginSummary": {
    "accountValue": "10500.0",
    "totalNtlPos": "1400.0",
    "totalRawUsd": "10000.0",
    "totalMarginUsed": "280.0"
  },
  "crossMarginSummary": {
    "accountValue": "10500.0",
    "totalNtlPos": "1400.0",
    "totalRawUsd": "10000.0",
    "totalMarginUsed": "280.0"
  },
  "withdrawable": "9720.0"
}
```

**Position fields reference:**

| Field | Description |
|-------|-------------|
| `coin` | Asset symbol |
| `szi` | Signed size (positive = long, negative = short) |
| `entryPx` | Average entry price |
| `positionValue` | Current notional value |
| `unrealizedPnl` | Unrealized profit/loss |
| `returnOnEquity` | Return on equity (decimal) |
| `liquidationPx` | Estimated liquidation price |
| `marginUsed` | Margin allocated to this position |
| `maxLeverage` | Maximum leverage for this asset |
| `leverage.type` | "isolated" or "cross" |
| `leverage.value` | Current leverage multiplier |
| `leverage.rawUsd` | Raw USD margin |
| `cumFunding.allTime` | Cumulative funding paid (all time) |
| `cumFunding.sinceChange` | Funding since last position change |
| `cumFunding.sinceOpen` | Funding since position opened |

```python
# Python SDK
state = info.user_state("0xAddress")
print(f"Account value: {state['marginSummary']['accountValue']}")
print(f"Withdrawable: {state['withdrawable']}")

for pos in state["assetPositions"]:
    p = pos["position"]
    print(f"{p['coin']}: size={p['szi']}, entry={p['entryPx']}, "
          f"pnl={p['unrealizedPnl']}, liq={p['liquidationPx']}")
```

### `spotClearinghouseState` -- Spot Balances

```json
// Request
{"type": "spotClearinghouseState", "user": "0xYourAddress"}

// Response
{
  "balances": [
    {
      "coin": "USDC",
      "token": 0,
      "hold": "0.0",
      "total": "100.22",
      "entryNtl": "0.0"
    },
    {
      "coin": "PURR",
      "token": 1,
      "hold": "0.0",
      "total": "500.0",
      "entryNtl": "25.0"
    }
  ]
}
```

| Field | Description |
|-------|-------------|
| `coin` | Token symbol |
| `token` | Token index |
| `hold` | Amount held in open orders |
| `total` | Total balance |
| `entryNtl` | Entry notional value |

```python
# Python SDK
spot_state = info.spot_user_state("0xAddress")
for bal in spot_state["balances"]:
    if float(bal["total"]) > 0:
        print(f"{bal['coin']}: {bal['total']} (held: {bal['hold']})")
```

---

## 5. Orders and Fills

### `openOrders` -- Current Open Orders

```json
// Request
{"type": "openOrders", "user": "0xAddress"}

// Response
[
  {
    "coin": "ETH",
    "limitPx": "2800.0",
    "oid": 77738308,
    "side": "B",
    "sz": "0.1",
    "timestamp": 1708622398623
  }
]
```

- `side`: `"B"` = buy, `"A"` = sell (ask)

### `frontendOpenOrders` -- Detailed Open Orders

Same as `openOrders` but includes additional fields for UI display:

```json
// Request
{"type": "frontendOpenOrders", "user": "0xAddress"}

// Response includes additional fields:
// orderType, origSz, reduceOnly, isTrigger, isPositionTpsl,
// triggerCondition, triggerPx
```

```python
# Python SDK
orders = info.frontend_open_orders("0xAddress")
for o in orders:
    trigger_info = f" (trigger: {o['triggerPx']})" if o.get("isTrigger") else ""
    print(f"{o['coin']} {o['side']} {o['sz']}@{o['limitPx']}{trigger_info}")
```

### `orderStatus` -- Single Order Status

```json
// Request
{"type": "orderStatus", "user": "0xAddress", "oid": 77738308}

// Response includes:
// status: "filled" | "canceled" | "rejected" | "resting" | "error"
// statusTimestamp: millisecond timestamp
```

You can also query by client order ID:

```python
# Python SDK
status = info.query_order_by_oid("0xAddress", 77738308)
print(f"Status: {status['status']}")

# By CLOID
from hyperliquid.utils.types import Cloid
cloid = Cloid.from_str("0x1234567890abcdef1234567890abcdef")
status = info.query_order_by_cloid("0xAddress", cloid)
```

### `historicalOrders` -- Historical Orders

Returns up to **2000** most recent orders.

```json
// Request
{"type": "historicalOrders", "user": "0xAddress"}
```

### `userFills` -- Recent Fills

```json
// Request
{"type": "userFills", "user": "0xAddress"}

// Response
[
  {
    "coin": "ETH",
    "px": "2850.0",
    "sz": "0.1",
    "side": "B",
    "time": 1708622398623,
    "startPosition": "0.0",
    "dir": "Open Long",
    "closedPnl": "0.0",
    "hash": "0x...",
    "oid": 77738308,
    "crossed": true,
    "fee": "0.128",
    "feeToken": "USDC",
    "builderFee": "0.0285",
    "tid": 118906512037719
  }
]
```

**Fill fields:**

| Field | Description |
|-------|-------------|
| `coin` | Asset symbol |
| `px` | Fill price |
| `sz` | Fill size |
| `side` | `"B"` (buy) or `"A"` (sell) |
| `time` | Fill timestamp (ms) |
| `startPosition` | Position size before this fill |
| `dir` | Direction: "Open Long", "Close Short", "Open Short", "Close Long" |
| `closedPnl` | Realized PnL if closing a position |
| `hash` | Transaction hash |
| `oid` | Order ID |
| `crossed` | Whether the order crossed the spread (taker) |
| `fee` | Fee paid |
| `feeToken` | Fee denomination |
| `builderFee` | (optional) Builder fee if applicable |
| `tid` | Unique trade ID |

### `userFillsByTime` -- Fills with Time Range

```json
// Request
{
  "type": "userFillsByTime",
  "user": "0xAddress",
  "startTime": 1681222254710,
  "endTime": 1681308654710,
  "aggregateByTime": true
}
```

**Pagination**: Returns maximum **500 elements** per request. Use the last timestamp as the next `startTime` to paginate through results.

```python
# Python SDK -- paginated fill retrieval
import time

all_fills = []
start_time = int(time.time() * 1000) - 86400000 * 7  # 7 days ago
end_time = int(time.time() * 1000)

while True:
    fills = info.user_fills_by_time("0xAddress", start_time, end_time)
    if not fills:
        break
    all_fills.extend(fills)
    if len(fills) < 500:
        break
    start_time = fills[-1]["time"]  # Use last timestamp for next page

print(f"Total fills: {len(all_fills)}")
```

---

## 6. Funding Data

### `fundingHistory` -- Historical Funding Rates

```json
// Request
{"type": "fundingHistory", "coin": "ETH", "startTime": 1683849600076}

// Response
[
  {
    "coin": "ETH",
    "fundingRate": "0.0000125",
    "premium": "0.00005",
    "time": 1683849600000
  }
]
```

### `userFunding` -- User Funding Payments

```json
// Request
{"type": "userFunding", "user": "0xAddress", "startTime": 1683849600076}

// Response
[
  {
    "delta": {
      "coin": "ETH",
      "fundingRate": "0.0000125",
      "szi": "1.5",
      "type": "funding",
      "usdc": "-0.053"
    },
    "hash": "0x...",
    "time": 1683849600000
  }
]
```

### `predictedFundings` -- Predicted Funding Rates

```json
// Request
{"type": "predictedFundings"}

// Response: predicted rates from multiple sources
// (BinPerp, HlPerp, BybitPerp)
```

### Funding Mechanics

| Property | Detail |
|----------|--------|
| Payment frequency | **Hourly** |
| Rate cap | **4% per hour** |
| Formula | `Average Premium Index + clamp(interest_rate - Premium, -0.0005, 0.0005)` |
| Premium sampling | Every **5 seconds** |
| Notional calculation | Uses **oracle price** |

```python
# Python SDK
funding = info.funding_history("ETH", start_ms, end_ms)
for f in funding:
    rate_annualized = float(f["fundingRate"]) * 24 * 365 * 100
    print(f"Time: {f['time']}, Rate: {f['fundingRate']} ({rate_annualized:.2f}% annualized)")

# User funding payments
user_funding = info.user_funding_history("0xAddress", start_ms, end_ms)
for uf in user_funding:
    d = uf["delta"]
    print(f"{d['coin']}: rate={d['fundingRate']}, paid={d['usdc']} USDC")
```

---

## 7. User Info and Fees

### `userFees` -- Fee Schedule and Rates

Returns the detailed fee schedule including VIP tiers, maker/taker rates, and discounts.

```json
// Request
{"type": "userFees", "user": "0xAddress"}

// Response includes:
// dailyUserVlm, feeSchedule (taker/maker rates, VIP tiers, MM tiers),
// userCrossRate, userAddRate, activeReferralDiscount, activeStakingDiscount
```

**Base fee rates:**

| Market Type | Taker | Maker |
|-------------|-------|-------|
| Perpetuals | 0.045% | 0.015% |
| Spot | 0.07% | 0.04% |
| HIP-3 Perps | 0.09% | 0.03% |

Fees decrease with higher volume tiers and HYPE staking discounts.

### `userRateLimit` -- Rate Limit Status

```json
// Request
{"type": "userRateLimit", "user": "0xAddress"}

// Response
{
  "cumVlm": "1234567.89",
  "nRequestsUsed": 450,
  "nRequestsCap": 10000
}
```

| Field | Description |
|-------|-------------|
| `cumVlm` | Cumulative trading volume (USDC) |
| `nRequestsUsed` | Requests used in current period |
| `nRequestsCap` | Current request capacity |

The address-based rate limit grants **1 request per 1 USDC traded** cumulatively, with an initial buffer of **10,000 requests**. See the rate limits reference for full details.

### `subAccounts` -- Subaccount Details

```json
// Request
{"type": "subAccounts", "user": "0xMasterAddress"}

// Response: sub-account details with clearinghouse and spot state
```

```python
# Python SDK
sub_accounts = info.sub_accounts("0xMasterAddress")
```

### `userRole` -- Account Role

```json
// Request
{"type": "userRole", "user": "0xAddress"}

// Response
{"role": "user"}
```

Possible roles: `"user"`, `"agent"`, `"vault"`, `"subAccount"`, `"missing"`.

---

## 8. Vault Endpoints

### `vaultDetails` -- Single Vault Details

```json
// Request
{"type": "vaultDetails", "vaultAddress": "0xVaultAddress"}
```

### `vaultSummaries` -- All Vault Summaries

```json
// Request
{"type": "vaultSummaries"}
```

### `leadingVaults` -- Top Performing Vaults

```json
// Request
{"type": "leadingVaults"}
```

Vaults are built-in strategy-sharing mechanisms. Key vault properties:
- **100 USDC** creation fee
- Leader gets **10% profit share**
- Leader must maintain at least **5%** of vault equity
- **4-day lockup** for HLP vaults, **1-day** for user vaults
- Trade on behalf via `vaultAddress` field in exchange requests

---

## 9. Other Info Endpoints

Hyperliquid provides many additional info query types for specialized data:

### Reference and Status

| Query Type | Description |
|------------|-------------|
| `exchangeStatus` | Exchange operational status |
| `maxBuilderFee` | Maximum builder fee for an asset |
| `maxMarketOrderNtls` | Maximum market order notional |
| `tokenDetails` | Token metadata details |

### User Data

| Query Type | Description |
|------------|-------------|
| `referral` | Referral program data |
| `extraAgents` | Extra agent wallets for user |
| `userDexAbstraction` | DEX abstraction settings |
| `userAbstraction` | User abstraction settings |
| `delegations` | Staking delegations |
| `delegatorSummary` | Delegator summary |

### Lending and Borrowing

| Query Type | Description |
|------------|-------------|
| `borrowLendUserState` | User's borrow/lend positions |
| `borrowLendReserveState` | Reserve state for a token |
| `allBorrowLendReserveStates` | All reserve states |

### Market Intelligence

| Query Type | Description |
|------------|-------------|
| `liquidatable` | Currently liquidatable positions |
| `portfolio` | Portfolio analytics |
| `perpAnnotation` | Perp annotation data |
| `perpCategories` | Perp market categories |
| `perpDexLimits` | DEX-specific limits |
| `perpDexStatus` | DEX operational status |
| `perpDeployAuctionStatus` | HIP-3 deployment auction status |
| `perpsAtOpenInterestCap` | Assets at OI capacity |
| `activeAssetData` | Active asset data for user |

### Example Queries

```python
# Exchange status
status = requests.post(
    "https://api.hyperliquid.xyz/info",
    json={"type": "exchangeStatus"},
    headers={"Content-Type": "application/json"}
).json()

# Liquidatable positions
liquidatable = requests.post(
    "https://api.hyperliquid.xyz/info",
    json={"type": "liquidatable"},
    headers={"Content-Type": "application/json"}
).json()

# Borrow/lend state
borrow_state = requests.post(
    "https://api.hyperliquid.xyz/info",
    json={"type": "borrowLendUserState", "user": "0xAddress"},
    headers={"Content-Type": "application/json"}
).json()
```

---

## 10. Pagination and Limits

### Result Limits

| Endpoint | Maximum Results |
|----------|----------------|
| `l2Book` | **20 levels** per side |
| `candleSnapshot` | **5000 candles** |
| `historicalOrders` | **2000 orders** |
| `userFillsByTime` | **500 fills** per page |

### Pagination Pattern for Fills

For endpoints that support time-based pagination, use the last item's timestamp as the next request's `startTime`:

```python
def get_all_fills(info, address, start_time, end_time):
    """Retrieve all fills using time-based pagination."""
    all_fills = []
    current_start = start_time

    while current_start < end_time:
        fills = info.user_fills_by_time(address, current_start, end_time)
        if not fills:
            break
        all_fills.extend(fills)
        if len(fills) < 500:
            break  # Last page
        current_start = fills[-1]["time"]

    return all_fills
```

### Candle Data Pagination

For large historical candle requests exceeding 5000 candles:

```python
def get_all_candles(info, coin, interval, start_time, end_time):
    """Retrieve all candles using time-based pagination."""
    all_candles = []
    current_start = start_time

    while current_start < end_time:
        candles = info.candles_snapshot(coin, interval, current_start, end_time)
        if not candles:
            break
        all_candles.extend(candles)
        if len(candles) < 5000:
            break
        current_start = candles[-1]["T"]  # Use close time of last candle

    return all_candles
```

---

## 11. Rate Limit Weights

Each info query has a weight that counts against the **1200 weight/minute** IP-based rate limit:

| Query Type | Weight |
|------------|--------|
| `l2Book` | **2** |
| `allMids` | **2** |
| `clearinghouseState` | **2** |
| `orderStatus` | **2** |
| `spotClearinghouseState` | **2** |
| `exchangeStatus` | **2** |
| `userRole` | **60** |
| All other documented info queries | **20** |

**Additional weights for result-set size:**
- Per **20 items** returned (fills, trades, funding entries): **+1**
- Per **60 candles** returned: **+1**

```python
# Example: userFills returning 200 fills
# Base weight: 20
# Result weight: 200 / 20 = +10
# Total weight: 30
```

Optimize rate limit usage by:
- Preferring low-weight queries (`allMids` at 2) over high-weight ones (`userRole` at 60)
- Batching time-range queries efficiently to minimize pagination requests
- Caching metadata responses (`meta`, `spotMeta`) that change infrequently

---

## 12. Python SDK Info Methods

Complete reference for `hyperliquid.info.Info` class methods:

```python
from hyperliquid.info import Info
from hyperliquid.utils import constants

info = Info(constants.MAINNET_API_URL, skip_ws=True)

# Market metadata
info.meta()                                           # Perp metadata
info.spot_meta()                                      # Spot metadata

# Market data
info.all_mids()                                       # All mid prices
info.l2_snapshot("ETH")                               # L2 orderbook
info.candles_snapshot("BTC", "1h", start_ms, end_ms)  # OHLCV candles

# User state
info.user_state("0x...")                              # Clearinghouse state
info.spot_user_state("0x...")                         # Spot balances

# Orders
info.open_orders("0x...")                             # Open orders (basic)
info.frontend_open_orders("0x...")                    # Open orders (detailed)
info.query_order_by_oid("0x...", oid)                 # Order by OID
info.query_order_by_cloid("0x...", cloid)             # Order by CLOID

# Fills
info.user_fills("0x...")                              # Recent fills
info.user_fills_by_time("0x...", start_ms, end_ms)    # Fills by time range

# Funding
info.funding_history("ETH", start_ms, end_ms)         # Funding rates
info.user_funding_history("0x...", start_ms, end_ms)   # User funding payments

# Account info
info.user_rate_limit("0x...")                          # Rate limit status
info.user_role("0x...")                                # Account role
info.user_vault_equities("0x...")                      # Vault positions
info.extra_agents("0x...")                             # Extra agent wallets

# Ledger
info.user_non_funding_ledger_updates("0x...", start_ms)  # Non-funding ledger
```

---

## 13. TypeScript SDK Info Methods

### @nktkas/hyperliquid

```typescript
import { HttpTransport, InfoClient } from "@nktkas/hyperliquid";

const info = new InfoClient({ transport: new HttpTransport() });

// Market metadata
const meta = await info.meta();
const [metaObj, ctxs] = await info.metaAndAssetCtxs();
const spotMeta = await info.spotMeta();
const [spotMetaObj, spotCtxs] = await info.spotMetaAndAssetCtxs();

// Market data
const mids = await info.allMids();
const book = await info.l2Book({ coin: "ETH" });
const candles = await info.candleSnapshot({
  coin: "BTC", interval: "1h",
  startTime: Date.now() - 86400000, endTime: Date.now()
});

// User state
const state = await info.clearinghouseState({ user: "0x..." });
const spotState = await info.spotClearinghouseState({ user: "0x..." });

// Orders and fills
const orders = await info.openOrders({ user: "0x..." });
const detailedOrders = await info.frontendOpenOrders({ user: "0x..." });
const orderStatus = await info.orderStatus({ user: "0x...", oid: 12345 });
const fills = await info.userFills({ user: "0x..." });
const fillsByTime = await info.userFillsByTime({
  user: "0x...", startTime: Date.now() - 86400000, endTime: Date.now()
});

// Funding
const funding = await info.fundingHistory({ coin: "ETH", startTime: Date.now() - 86400000 });
const predicted = await info.predictedFundings();

// User info
const fees = await info.userFees({ user: "0x..." });
const rateLimit = await info.userRateLimit({ user: "0x..." });
```

### nomeida/hyperliquid

```typescript
const { Hyperliquid } = require("hyperliquid");
const sdk = new Hyperliquid({ testnet: false });

// Uses coin-PERP format
const orderBook = await sdk.info.getL2Book("ETH-PERP");
const trades = await sdk.info.getRecentTrades("BTC-PERP");
const mids = await sdk.info.getAllMids();
```

---

**Cross-references:**
- [connection-and-endpoints.md](connection-and-endpoints.md) -- Base URLs, asset indexing, request format
- [exchange-actions.md](exchange-actions.md) -- Trading actions that modify state queried here
- [authentication-and-signing.md](authentication-and-signing.md) -- Always query with master address, not agent address
