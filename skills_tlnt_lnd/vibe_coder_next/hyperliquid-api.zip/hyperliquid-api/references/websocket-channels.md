# WebSocket Channels — Hyperliquid API Reference

## Table of Contents

1. [Connection Setup](#1-connection-setup)
2. [Keepalive and Heartbeat](#2-keepalive-and-heartbeat)
3. [Subscribe and Unsubscribe Format](#3-subscribe-and-unsubscribe-format)
4. [Market Data Channels](#4-market-data-channels)
5. [User Data Channels](#5-user-data-channels)
6. [Account State Channels](#6-account-state-channels)
7. [TWAP Channels](#7-twap-channels)
8. [Miscellaneous Channels](#8-miscellaneous-channels)
9. [Key TypeScript Interfaces](#9-key-typescript-interfaces)
10. [Posting Actions via WebSocket](#10-posting-actions-via-websocket)
11. [Response Matching with Unique ID](#11-response-matching-with-unique-id)
12. [Reconnection Strategy](#12-reconnection-strategy)
13. [Reconciliation on Reconnect](#13-reconciliation-on-reconnect)

---

## 1. Connection Setup

Connect to the WebSocket endpoint to receive real-time streaming data and optionally post info queries or signed exchange actions.

| Environment | WebSocket URL |
|-------------|---------------|
| Mainnet | `wss://api.hyperliquid.xyz/ws` |
| Testnet | `wss://api.hyperliquid-testnet.xyz/ws` |

The WebSocket API supports three operations:

- **Subscribe** to real-time data channels (19 channels available)
- **Unsubscribe** from previously subscribed channels
- **Post** info queries or signed exchange actions for lower latency than REST

All messages are JSON-encoded. The same channel/message structure works on both mainnet and testnet.

```typescript
// Node.js / Browser connection
const ws = new WebSocket("wss://api.hyperliquid.xyz/ws");

ws.onopen = () => {
  console.log("Connected to Hyperliquid WebSocket");
};

ws.onmessage = (event) => {
  const msg = JSON.parse(event.data);
  console.log("Received:", msg.channel, msg.data);
};
```

```python
# Python connection with websockets
import asyncio
import websockets
import json

async def connect():
    async with websockets.connect("wss://api.hyperliquid.xyz/ws") as ws:
        print("Connected to Hyperliquid WebSocket")
        async for message in ws:
            msg = json.loads(message)
            print(f"Channel: {msg.get('channel')}")
```

> **Cross-reference:** For REST API alternatives to these channels, see `info-queries.md`. For IP-based WebSocket connection limits (100 connections, 1000 subscriptions, 2000 messages/min), see `rate-limits.md`.

---

## 2. Keepalive and Heartbeat

The server closes connections after **60 seconds** of inactivity. Send heartbeat pings to keep the connection alive.

**Ping message:**

```json
{"method": "ping"}
```

**Pong response:**

```json
{"channel": "pong"}
```

Send a ping at least every 50 seconds to maintain the connection with a safety margin:

```typescript
const HEARTBEAT_INTERVAL = 50_000; // 50 seconds (10s before 60s timeout)

function startHeartbeat(ws: WebSocket): NodeJS.Timeout {
  return setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ method: "ping" }));
    }
  }, HEARTBEAT_INTERVAL);
}
```

```python
import asyncio, json

async def heartbeat(ws, interval=50):
    """Send ping every `interval` seconds to prevent 60s inactivity timeout."""
    while True:
        await ws.send(json.dumps({"method": "ping"}))
        await asyncio.sleep(interval)
```

---

## 3. Subscribe and Unsubscribe Format

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "<channel>", ...params}}
```

**Unsubscribe:**

```json
{"method": "unsubscribe", "subscription": {"type": "<channel>", ...params}}
```

**Confirmation response** (sent after a successful subscribe or unsubscribe):

```json
{
  "channel": "subscriptionResponse",
  "data": {
    "method": "subscribe",
    "subscription": {"type": "<channel>", ...params}
  }
}
```

**Data update messages** arrive as:

```json
{"channel": "<channel>", "data": { ...payload }}
```

The subscription payload in an unsubscribe message must exactly match the payload used in the corresponding subscribe message.

---

## 4. Market Data Channels

These channels provide real-time market data and do not require a user address.

### 4.1 allMids

All mid prices for every listed asset, updated per block.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "allMids"}}
```

**Data format:**

```json
{
  "channel": "allMids",
  "data": {
    "mids": {
      "BTC": "95123.5",
      "ETH": "2891.3",
      "SOL": "148.72"
    }
  }
}
```

**Notes:** Returns a `Record<string, string>` mapping coin names to mid-price strings. Updated each block. Useful for dashboards, cross-asset monitoring, and index calculations.

### 4.2 l2Book

Level 2 orderbook snapshot for a specific coin. Up to 20 levels per side.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "l2Book", "coin": "ETH"}}
```

**Data format:**

```json
{
  "channel": "l2Book",
  "data": {
    "coin": "ETH",
    "levels": [
      [{"px": "2890.5", "sz": "12.3", "n": 5}, {"px": "2890.0", "sz": "8.1", "n": 3}],
      [{"px": "2891.0", "sz": "10.7", "n": 4}, {"px": "2891.5", "sz": "6.2", "n": 2}]
    ],
    "time": 1708622398623
  }
}
```

**Notes:** `levels[0]` = bids (descending by price), `levels[1]` = asks (ascending by price). Each level includes `px` (price), `sz` (total size), and `n` (number of orders). Pushed per block, at least **0.5 seconds apart** between updates. Full snapshot on each push, not incremental deltas.

### 4.3 bbo

Best bid and offer only for a specific coin.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "bbo", "coin": "ETH"}}
```

**Data format:**

```json
{
  "channel": "bbo",
  "data": {
    "coin": "ETH",
    "bestBid": {"px": "2890.5", "sz": "12.3"},
    "bestAsk": {"px": "2891.0", "sz": "10.7"}
  }
}
```

**Notes:** Pushed only when the best bid or ask changes. Lower bandwidth than `l2Book`. Use this when you only need top-of-book data for spread monitoring or trigger decisions.

### 4.4 trades

Real-time trade feed for a specific coin.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "trades", "coin": "SOL"}}
```

**Data format:**

```json
{
  "channel": "trades",
  "data": [
    {
      "coin": "SOL",
      "side": "B",
      "px": "148.72",
      "sz": "5.0",
      "hash": "0xabc123...",
      "time": 1681222254710,
      "tid": 118906512037719,
      "users": ["0xBuyer...", "0xSeller..."]
    }
  ]
}
```

**Notes:** Returns an array of `WsTrade` objects. `side` is `"B"` (buy/taker was buyer) or `"A"` (sell/taker was seller). The `users` array contains `[taker, maker]` addresses. The `tid` is a unique trade ID.

### 4.5 candle

OHLCV candlestick data for a specific coin and interval.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "candle", "coin": "ETH", "interval": "1m"}}
```

**Data format:**

```json
{
  "channel": "candle",
  "data": {
    "t": 1681222200000,
    "T": 1681222260000,
    "s": "ETH",
    "i": "1m",
    "o": 2890.5,
    "c": 2891.3,
    "h": 2893.0,
    "l": 2889.8,
    "v": 234.56,
    "n": 42
  }
}
```

**Notes:** Supports all 14 intervals: `1m`, `3m`, `5m`, `15m`, `30m`, `1h`, `2h`, `4h`, `8h`, `12h`, `1d`, `3d`, `1w`, `1M`. Fields: `t` = open time, `T` = close time, `s` = symbol, `i` = interval, `o/c/h/l` = OHLC prices, `v` = volume, `n` = number of trades.

### 4.6 activeAssetCtx

Live asset context (funding, OI, prices) for a specific coin.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "activeAssetCtx", "coin": "ETH"}}
```

**Data format:**

```json
{
  "channel": "activeAssetCtx",
  "data": {
    "coin": "ETH",
    "ctx": {
      "funding": "0.00003",
      "openInterest": "125000.5",
      "prevDayPx": "2850.0",
      "dayNtlVlm": "500000000",
      "premium": "0.0001",
      "oraclePx": "2890.0",
      "markPx": "2891.0",
      "midPx": "2890.5",
      "impactPxs": ["2888.0", "2893.0"]
    }
  }
}
```

**Notes:** Provides the same data as the `metaAndAssetCtxs` info query but streamed in real time for a single asset.

---

## 5. User Data Channels

These channels require a `user` address (always the **master or subaccount address**, never the agent wallet address).

### 5.1 orderUpdates

Real-time order status changes for a user.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "orderUpdates", "user": "0x1234..."}}
```

**Data format:**

```json
{
  "channel": "orderUpdates",
  "data": [
    {
      "order": {
        "coin": "ETH",
        "side": "B",
        "limitPx": "2800",
        "sz": "0.1",
        "oid": 77738308,
        "timestamp": 1708622398623,
        "origSz": "0.2",
        "cloid": "0x1234567890abcdef1234567890abcdef"
      },
      "status": "filled",
      "statusTimestamp": 1708622398700
    }
  ]
}
```

**Notes:** Returns `WsOrder[]`. The `status` field indicates the new state: `"open"`, `"filled"`, `"canceled"`, `"triggered"`, `"rejected"`, `"marginCanceled"`. The `cloid` field is present if the order was placed with a client order ID. Essential for tracking order lifecycle.

### 5.2 userEvents

Composite event stream including fills, funding, liquidations, and non-user cancels.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "userEvents", "user": "0x1234..."}}
```

**Data format:**

```json
{
  "channel": "userEvents",
  "data": {
    "fills": [...],
    "funding": {...},
    "liquidation": {...},
    "nonUserCancel": [...]
  }
}
```

**Notes:** A single channel that aggregates multiple event types. Useful when you need to capture all account activity in one subscription without subscribing to individual channels separately.

### 5.3 userFills

User fill events with an initial snapshot.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "userFills", "user": "0x1234..."}}
```

**Data format:**

```json
{
  "channel": "userFills",
  "data": {
    "isSnapshot": true,
    "fills": [
      {
        "coin": "ETH",
        "px": "2891.4",
        "sz": "0.1",
        "side": "B",
        "time": 1708622398623,
        "startPosition": "0.0",
        "dir": "Open Long",
        "closedPnl": "0.0",
        "hash": "0xabc...",
        "oid": 77738308,
        "crossed": true,
        "fee": "0.13",
        "feeToken": "USDC",
        "tid": 118906512037719
      }
    ]
  }
}
```

**Notes:** The first message has `isSnapshot: true` and contains recent fills. Subsequent messages have `isSnapshot: false` and contain only new fills. The `dir` field values: `"Open Long"`, `"Open Short"`, `"Close Long"`, `"Close Short"`.

### 5.4 userFundings

User funding payment events.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "userFundings", "user": "0x1234..."}}
```

**Data format:**

```json
{
  "channel": "userFundings",
  "data": {
    "delta": {
      "coin": "ETH",
      "fundingRate": "0.00003",
      "szi": "1.5",
      "type": "funding",
      "usdc": "-0.045"
    },
    "hash": "0xdef...",
    "time": 1708622400000
  }
}
```

**Notes:** Funding is paid **hourly** with a **4% per hour cap**. Negative `usdc` means the user paid funding; positive means received.

### 5.5 userNonFundingLedgerUpdates

Non-funding ledger events: withdrawals, deposits, transfers, liquidations.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "userNonFundingLedgerUpdates", "user": "0x1234..."}}
```

**Notes:** Captures all balance-affecting events except funding payments. Useful for reconciling account balance changes in an audit trail.

---

## 6. Account State Channels

### 6.1 clearinghouseState

Full perpetual account state streamed in real time.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "clearinghouseState", "user": "0x1234..."}}
```

**Data format:**

```json
{
  "channel": "clearinghouseState",
  "data": {
    "assetPositions": [
      {
        "position": {
          "coin": "ETH",
          "szi": "1.5",
          "entryPx": "2800.0",
          "positionValue": "4335.0",
          "unrealizedPnl": "135.0",
          "liquidationPx": "2450.0",
          "leverage": {"type": "cross", "value": 5}
        }
      }
    ],
    "marginSummary": {
      "accountValue": "10000.0",
      "totalNtlPos": "4335.0",
      "totalMarginUsed": "867.0"
    },
    "withdrawable": "8500.0"
  }
}
```

**Notes:** Equivalent to the `clearinghouseState` info query but streamed on every state change. Monitor `liquidationPx` against current `markPx` for risk management.

> **Cross-reference:** For the full response schema and all position fields, see `info-queries.md` section 3.3.

### 6.2 openOrders

Current open orders for a user.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "openOrders", "user": "0x1234..."}}
```

**Data format:**

```json
{
  "channel": "openOrders",
  "data": [
    {
      "coin": "ETH",
      "limitPx": "2800",
      "oid": 77738308,
      "side": "B",
      "sz": "0.1",
      "timestamp": 1708622398623
    }
  ]
}
```

**Notes:** Pushes the complete set of open orders on each change. Use alongside `orderUpdates` for a full picture of order state.

---

## 7. TWAP Channels

### 7.1 twapStates

Active TWAP order states for a user.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "twapStates", "user": "0x1234..."}}
```

**Notes:** Shows the current status of all active TWAP orders including progress, remaining size, and execution details. TWAP suborders execute every **30 seconds** with **3% max slippage** per suborder.

### 7.2 userTwapSliceFills

Individual TWAP suborder (slice) fills.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "userTwapSliceFills", "user": "0x1234..."}}
```

**Notes:** Each TWAP order is broken into slices. This channel reports when each slice fills, useful for monitoring execution quality.

### 7.3 userTwapHistory

Historical TWAP order data.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "userTwapHistory", "user": "0x1234..."}}
```

**Notes:** Completed TWAP order history including total fill statistics and average execution price.

> **Cross-reference:** For TWAP order placement and cancellation, see `exchange-actions.md` section 2.5.

---

## 8. Miscellaneous Channels

### 8.1 notification

System notifications for a user.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "notification", "user": "0x1234..."}}
```

**Notes:** Receives notification strings from the Hyperliquid system, such as liquidation warnings or system maintenance alerts.

### 8.2 webData3

Frontend aggregate data for a user.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "webData3", "user": "0x1234..."}}
```

**Notes:** Aggregated data designed for the Hyperliquid web frontend. Contains a comprehensive snapshot of user state, positions, and market context in a single message.

### 8.3 activeAssetData

User-specific asset data for a particular coin.

**Subscribe:**

```json
{"method": "subscribe", "subscription": {"type": "activeAssetData", "user": "0x1234...", "coin": "ETH"}}
```

**Notes:** Provides user-specific context for a single asset, combining position data with live market context.

---

## 9. Key TypeScript Interfaces

These interfaces define the shape of data received from WebSocket channels.

```typescript
/** A single trade from the `trades` channel */
interface WsTrade {
  coin: string;       // Asset symbol (e.g., "ETH")
  side: string;       // "B" (buy/taker bought) or "A" (sell/taker sold)
  px: string;         // Execution price as string
  sz: string;         // Trade size as string
  hash: string;       // Transaction hash
  time: number;       // Timestamp in milliseconds
  tid: number;        // Unique trade ID
  users: [string, string]; // [taker address, maker address]
}

/** A single level in the orderbook */
interface WsLevel {
  px: string;         // Price level as string
  sz: string;         // Total size at this level as string
  n: number;          // Number of orders at this level
}

/** Orderbook snapshot from the `l2Book` channel */
interface WsBook {
  coin: string;       // Asset symbol
  levels: [WsLevel[], WsLevel[]]; // [bids (desc), asks (asc)]
  time: number;       // Timestamp in milliseconds
}

/** Order update from the `orderUpdates` channel */
interface WsOrder {
  order: {
    coin: string;     // Asset symbol
    side: string;     // "B" (buy) or "A" (sell)
    limitPx: string;  // Limit price as string
    sz: string;       // Remaining size as string
    oid: number;      // Order ID
    timestamp: number; // Order creation timestamp
    origSz: string;   // Original order size as string
    cloid?: string;   // Client order ID (if provided)
  };
  status: string;     // "open", "filled", "canceled", "triggered", "rejected", "marginCanceled"
  statusTimestamp: number; // When status changed
}
```

---

## 10. Posting Actions via WebSocket

Both info queries and signed exchange actions can be sent over the WebSocket connection using `method: "post"`. This provides lower latency than REST because the connection is already established.

### Info query via WebSocket

```json
{
  "method": "post",
  "id": 123,
  "request": {
    "type": "info",
    "payload": {"type": "l2Book", "coin": "ETH"}
  }
}
```

### Exchange action via WebSocket

```json
{
  "method": "post",
  "id": 256,
  "request": {
    "type": "action",
    "payload": {
      "action": {"type": "order", "orders": [...], "grouping": "na"},
      "nonce": 1713825891591,
      "signature": {"r": "0x...", "s": "0x...", "v": 27}
    }
  }
}
```

### Response format

```json
{
  "channel": "post",
  "data": {
    "id": 123,
    "response": {
      "type": "info",
      "payload": { ... }
    }
  }
}
```

> **Cross-reference:** For the full list of exchange action payloads, see `exchange-actions.md`. For signing mechanics (nonce, signature), see `authentication-and-signing.md`.

---

## 11. Response Matching with Unique ID

When posting multiple requests over a single WebSocket connection, use a unique `id` field (integer) per request to match responses to their originating requests. Responses arrive asynchronously, so without IDs, correlating responses to requests is unreliable.

```typescript
class WsRequestManager {
  private nextId = 1;
  private pending = new Map<number, {
    resolve: (data: any) => void;
    reject: (err: Error) => void;
  }>();

  constructor(private ws: WebSocket) {
    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      if (msg.channel === "post" && msg.data?.id) {
        const handler = this.pending.get(msg.data.id);
        if (handler) {
          handler.resolve(msg.data.response);
          this.pending.delete(msg.data.id);
        }
      }
    };
  }

  async postInfo(payload: any): Promise<any> {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({
        method: "post",
        id,
        request: { type: "info", payload }
      }));
      // Timeout after 10 seconds
      setTimeout(() => {
        if (this.pending.has(id)) {
          this.pending.delete(id);
          reject(new Error(`Request ${id} timed out`));
        }
      }, 10_000);
    });
  }
}
```

---

## 12. Reconnection Strategy

WebSocket disconnections happen periodically without prior announcement. Always implement automatic reconnection with exponential backoff.

### Python: exponential backoff reconnection

```python
import asyncio
import json
import websockets

WS_URL = "wss://api.hyperliquid.xyz/ws"

async def handle_connection(ws):
    """Process messages and send heartbeats."""
    heartbeat_task = asyncio.create_task(heartbeat(ws))
    try:
        async for message in ws:
            msg = json.loads(message)
            if msg.get("channel") == "pong":
                continue
            # Process data messages
            process_message(msg)
    finally:
        heartbeat_task.cancel()

async def heartbeat(ws, interval=50):
    while True:
        await ws.send(json.dumps({"method": "ping"}))
        await asyncio.sleep(interval)

def process_message(msg):
    channel = msg.get("channel")
    data = msg.get("data")
    print(f"[{channel}] {data}")

async def connect_with_retry():
    """Connect with exponential backoff: 1s -> 2s -> 4s -> ... -> 60s max."""
    delay = 1
    while True:
        try:
            async with websockets.connect(WS_URL) as ws:
                delay = 1  # Reset delay on successful connection
                # Re-subscribe to all channels
                await resubscribe(ws)
                await handle_connection(ws)
        except (websockets.ConnectionClosed, ConnectionError, OSError) as e:
            print(f"Disconnected: {e}. Reconnecting in {delay}s...")
            await asyncio.sleep(delay)
            delay = min(delay * 2, 60)  # Exponential backoff, max 60s

async def resubscribe(ws):
    """Re-subscribe to all desired channels after reconnection."""
    subscriptions = [
        {"type": "allMids"},
        {"type": "l2Book", "coin": "ETH"},
        {"type": "orderUpdates", "user": "0x1234..."},
        {"type": "userFills", "user": "0x1234..."},
    ]
    for sub in subscriptions:
        await ws.send(json.dumps({"method": "subscribe", "subscription": sub}))

asyncio.run(connect_with_retry())
```

### TypeScript: exponential backoff reconnection

```typescript
class HyperliquidWs {
  private ws: WebSocket | null = null;
  private delay = 1000;
  private subscriptions: any[] = [];
  private heartbeatTimer: NodeJS.Timeout | null = null;

  constructor(
    private url = "wss://api.hyperliquid.xyz/ws",
    private onMessage: (msg: any) => void = console.log
  ) {}

  async connect(): Promise<void> {
    while (true) {
      try {
        await this.doConnect();
      } catch (err) {
        console.error(`Disconnected. Reconnecting in ${this.delay}ms...`);
        await new Promise((r) => setTimeout(r, this.delay));
        this.delay = Math.min(this.delay * 2, 60_000);
      }
    }
  }

  private doConnect(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.ws = new WebSocket(this.url);
      this.ws.onopen = () => {
        this.delay = 1000; // Reset backoff
        this.startHeartbeat();
        this.resubscribe();
      };
      this.ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.channel !== "pong") this.onMessage(msg);
      };
      this.ws.onclose = () => {
        this.stopHeartbeat();
        reject(new Error("Connection closed"));
      };
      this.ws.onerror = (err) => reject(err);
    });
  }

  private startHeartbeat(): void {
    this.heartbeatTimer = setInterval(() => {
      this.ws?.send(JSON.stringify({ method: "ping" }));
    }, 50_000);
  }

  private stopHeartbeat(): void {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
  }

  subscribe(subscription: any): void {
    this.subscriptions.push(subscription);
    this.ws?.send(JSON.stringify({ method: "subscribe", subscription }));
  }

  private resubscribe(): void {
    for (const sub of this.subscriptions) {
      this.ws?.send(JSON.stringify({ method: "subscribe", subscription: sub }));
    }
  }
}
```

---

## 13. Reconciliation on Reconnect

After a reconnection, data may have been missed during the period the WebSocket was disconnected. Use these strategies to ensure state consistency:

### Snapshot acknowledgment

When you re-subscribe to channels like `userFills`, the first message will be a **snapshot** (`isSnapshot: true`) containing recent data. This snapshot acts as the ack and helps you catch up on missed events.

### REST reconciliation

For critical state, query REST endpoints immediately after reconnection to get the authoritative current state:

```python
async def reconcile_on_reconnect(info, address):
    """Reconcile state after WebSocket reconnection using REST snapshots."""
    # 1. Get current positions and balances
    state = info.user_state(address)
    print(f"Account value: {state['marginSummary']['accountValue']}")

    # 2. Get current open orders
    orders = info.open_orders(address)
    print(f"Open orders: {len(orders)}")

    # 3. Get recent fills since last known fill timestamp
    fills = info.user_fills_by_time(address, last_known_fill_time, int(time.time() * 1000))
    for fill in fills:
        print(f"Missed fill: {fill['coin']} {fill['side']} {fill['sz']} @ {fill['px']}")

    # 4. Get current mid prices
    mids = info.all_mids()

    return state, orders, fills, mids
```

### Recommended reconciliation flow

```
1. Detect disconnect (onclose / exception)
2. Reconnect with exponential backoff
3. Re-subscribe to all channels
4. Wait for snapshot acks (isSnapshot: true)
5. Query REST for authoritative state (clearinghouseState, openOrders)
6. Diff REST state against local state
7. Apply corrections (cancel stale orders, update position tracking)
8. Resume normal processing
```

> **Cross-reference:** For REST info queries used during reconciliation, see `info-queries.md`. For rate limit considerations when making REST calls during reconnect, see `rate-limits.md`. For the full risk management and emergency shutdown pattern, see `risk-and-error-handling.md`.

---

## Channel Summary Table

| # | Channel | Params | Updates On | Key Use Case |
|---|---------|--------|------------|--------------|
| 1 | `allMids` | none | Per block | Dashboard, cross-asset monitoring |
| 2 | `l2Book` | `coin` | Per block, >=0.5s | Orderbook display, spread tracking |
| 3 | `bbo` | `coin` | On change | Top-of-book, low bandwidth |
| 4 | `trades` | `coin` | Real-time | Trade feed, volume tracking |
| 5 | `candle` | `coin`, `interval` | Per candle update | Charting, technical analysis |
| 6 | `orderUpdates` | `user` | On order change | Order lifecycle tracking |
| 7 | `userEvents` | `user` | On any event | Composite: fills+funding+liquidation |
| 8 | `userFills` | `user` | On fill | Fill tracking with snapshot |
| 9 | `userFundings` | `user` | Hourly | Funding payment monitoring |
| 10 | `userNonFundingLedgerUpdates` | `user` | On event | Deposits, withdrawals, transfers |
| 11 | `clearinghouseState` | `user` | On state change | Position and margin monitoring |
| 12 | `openOrders` | `user` | On order change | Open order tracking |
| 13 | `notification` | `user` | On notification | System alerts |
| 14 | `webData3` | `user` | Aggregate | Frontend data aggregate |
| 15 | `twapStates` | `user` | On TWAP change | TWAP order monitoring |
| 16 | `activeAssetCtx` | `coin` | Per block | Funding, OI, mark price |
| 17 | `activeAssetData` | `user`, `coin` | On change | User-specific asset context |
| 18 | `userTwapSliceFills` | `user` | On TWAP fill | TWAP execution monitoring |
| 19 | `userTwapHistory` | `user` | On TWAP complete | TWAP order history |
