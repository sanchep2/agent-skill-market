# Ecosystem and HIPs (Hyperliquid Improvement Proposals)

## Table of Contents

1. [HIP-1: Native Tokens](#1-hip-1-native-tokens)
2. [HIP-2: Hyperliquidity (Automated Market Making)](#2-hip-2-hyperliquidity-automated-market-making)
3. [HIP-3: Builder-Deployed Perpetuals](#3-hip-3-builder-deployed-perpetuals)
4. [HIP-4: Outcome Trading](#4-hip-4-outcome-trading)
5. [HYPE Token and Staking](#5-hype-token-and-staking)
6. [Vaults](#6-vaults)
7. [Sub-Accounts](#7-sub-accounts)
8. [HyperEVM Integration](#8-hyperevm-integration)
9. [Community Resources and Builder Codes](#9-community-resources-and-builder-codes)

---

## 1. HIP-1: Native Tokens

HIP-1 defines the standard for **capped-supply fungible tokens** native to HyperCore. These are not ERC-20 tokens -- they live directly on the L1 trading engine with native on-chain order books.

### Deployment process

Token deployment uses a **31-hour Dutch auction** mechanism:

1. A deployer proposes a new token with a fixed total supply
2. The auction starts at an initial price and decreases over 31 hours down to a floor of **500 HYPE**
3. The first bidder to accept the current price wins the deployment slot
4. The protocol capacity is approximately **280 tokens per year**

### Token characteristics

- **Capped supply**: Total supply is fixed at deployment and cannot be increased
- **Native order book**: Each HIP-1 token automatically gets a spot order book paired with USDC on HyperCore
- **No smart contract needed**: Unlike ERC-20 tokens, HIP-1 tokens are first-class primitives on HyperCore

### PURR: The first HIP-1 token

**PURR** was the first HIP-1 token, launched in April 2024. It serves as both a proof of concept and a community token. PURR is traded on the native spot order book as `PURR/USDC`.

### ERC-20 linking

HIP-1 tokens can be **linked to ERC-20 contracts on HyperEVM**, enabling seamless bridging between the native HyperCore representation and the EVM-compatible representation. This allows HIP-1 tokens to be used in HyperEVM DeFi protocols (lending, AMMs, etc.) while maintaining their native order book on HyperCore.

### Querying HIP-1 tokens via API

```python
# Get all spot token metadata
spot_meta = info.spot_meta()
# Returns: {"tokens": [...], "universe": [...]}

# Each token in universe has trading pair info
# Query spot balances
spot_state = info.spot_user_state("0xACCOUNT_ADDRESS")
# Returns: {"balances": [{"coin": "PURR", "token": 1, "hold": "0.0", "total": "500.0", ...}]}

# Spot order book
book = info.l2_snapshot("PURR/USDC")

# Transfer spot tokens
exchange.spot_transfer(100.0, "0xDEST", "PURR:0xTokenAddress")
```

> **Cross-reference:** See `exchange-actions.md` for `spotSend` and `usdClassTransfer` actions, and `info-queries.md` for `spotMeta` and `spotClearinghouseState`.

---

## 2. HIP-2: Hyperliquidity (Automated Market Making)

HIP-2 provides **automated market making** for HIP-1 tokens, built directly into the block transition logic of HyperCore. This is not a separate smart contract or off-chain service -- it is part of the consensus layer.

### How it works

- Maintains a **0.3% spread** guarantee on both bid and ask sides
- Quotes are updated every **3 seconds** as part of block production
- Liquidity is **permanently locked** -- there is no operator who can withdraw it
- No external market maker or LP provider is needed
- The mechanism ensures every HIP-1 token has baseline liquidity from the moment of deployment

### Key properties

| Property | Value |
|---|---|
| Spread guarantee | 0.3% |
| Update frequency | Every 3 seconds |
| Liquidity removal | Impossible (permanently locked) |
| Operator required | No |
| Applies to | All HIP-1 tokens automatically |

### Interaction via API

HIP-2 liquidity appears on the regular spot order book. You interact with it the same way you interact with any other spot orders -- there is no separate API for HIP-2. The quotes placed by HIP-2 show up as resting orders in the `l2Book` snapshot:

```python
# HIP-2 quotes appear as normal orders in the book
book = info.l2_snapshot("PURR/USDC")
# bids = book["levels"][0], asks = book["levels"][1]
# HIP-2 quotes will be among these levels with the 0.3% spread
```

> **Cross-reference:** See `info-queries.md` for `l2Book` and `spotMetaAndAssetCtxs` query formats.

---

## 3. HIP-3: Builder-Deployed Perpetuals

HIP-3 enables **permissionless creation of perpetual futures markets** on Hyperliquid. Launched on mainnet in **October 2025**, it allows anyone to deploy new perp markets covering equities, commodities, FX, and prediction markets.

### Requirements

| Requirement | Value |
|---|---|
| HYPE staking | **500,000 HYPE** per DEX |
| Free assets | First **3 assets** per DEX (no auction) |
| Additional assets | Through auction process |
| Fee split | **50% deployer / 50% protocol** |
| Margin mode | **Isolated-only** (no cross margin) |

### Asset format

HIP-3 perpetual assets use the format `dex_name:ASSET_NAME`:

```python
# Examples of HIP-3 asset names
"xyz:XYZ100"       # Nasdaq 100 equivalent (equities)
"metals:GOLD"      # Commodities
"fx:EURUSD"        # Foreign exchange

# Query all HIP-3 perp DEXes
dexes = info.query("perpDexs")  # Returns list of all perp DEXes

# Query all perp metadata across all DEXes
all_metas = info.query("allPerpMetas")  # Returns metadata for every perp market
```

### Trading HIP-3 perps

HIP-3 perps are traded using the same exchange actions as regular perps, but with the `dex_name:ASSET_NAME` format and some constraints:

```python
# Place order on HIP-3 perp (isolated margin only)
exchange.update_leverage(5, "xyz:XYZ100", is_cross=False)  # Must be isolated

result = exchange.order(
    "xyz:XYZ100",       # HIP-3 asset format
    True,                # is_buy
    1.0,                 # size
    100.0,               # price
    {"limit": {"tif": "Gtc"}},
)
```

### Fee structure

HIP-3 perps have different fee rates than native perps:

| Market Type | Taker Fee | Maker Fee |
|---|---|---|
| Native perps | 0.045% | 0.015% |
| HIP-3 perps | **0.09%** | **0.03%** |
| Spot | 0.07% | 0.04% |

### Current scale

As of February 2026, HIP-3 markets have aggregated **over $340M+ in open interest** across multiple DEXes covering equities (Nasdaq 100 index via XYZ100), commodities, FX pairs, and prediction markets.

### Querying HIP-3 market status

```python
# Check DEX-specific limits
dex_limits = info.query("perpDexLimits")

# Check DEX status
dex_status = info.query("perpDexStatus")

# Check deployment auction status
auction_status = info.query("perpDeployAuctionStatus")

# Check which assets are at open interest cap
at_cap = info.query("perpsAtOpenInterestCap")
```

> **Cross-reference:** See `exchange-actions.md` for order placement on HIP-3 markets, `rate-limits.md` for fee tiers, and `connection-and-endpoints.md` for asset indexing.

---

## 4. HIP-4: Outcome Trading

HIP-4 introduces **fully collateralized outcome contracts** for prediction markets. As of February 2026, HIP-4 is **testnet only**.

### Design

| Property | Value |
|---|---|
| Collateralization | Fully collateralized (no leverage, no liquidation risk) |
| Contract types | **YES** and **NO** binary outcomes |
| Price range | Fixed (e.g., 0 to 1 USDH) |
| Settlement | **USDH** (Hyperliquid's native stablecoin) |
| Opening mechanism | **15-minute opening auctions** |
| Liquidation risk | **None** (fully collateralized) |
| Payoffs | Predefined at contract creation |

### How it works

1. A market is created for a specific event (e.g., "Will BTC exceed $100k by March 2026?")
2. YES and NO contracts are minted, each representing one side of the outcome
3. YES + NO always sum to the collateral amount (e.g., 1 USDH)
4. At resolution, the winning contract pays out 1 USDH, the losing contract pays 0
5. No margin calls or liquidation -- positions are fully backed

### Current status

HIP-4 is available on testnet only (February 2026). Test at `https://app.hyperliquid-testnet.xyz`. The testnet implementation allows developers to experiment with the outcome trading API before mainnet launch.

> **Cross-reference:** See `connection-and-endpoints.md` for testnet URLs and the testnet development workflow.

---

## 5. HYPE Token and Staking

HYPE is the native token of the Hyperliquid blockchain, used for staking, governance, fee discounts, and as the deployment currency for HIP-1 token auctions.

### Token economics

| Property | Value |
|---|---|
| Total supply | ~**1 billion** HYPE |
| Staking APY | **2.25-2.37%** |
| Unstaking queue | **7 days** |
| Fee discounts | Available for stakers |
| Fee burn | Trading fee assistance fund converts fees to HYPE and **burns** them |

### Staking via API

```python
# Delegate HYPE to a validator
# Action type: tokenDelegate (user-signed, chainId 42161)
exchange.token_delegate(validator_address, amount)

# Deposit HYPE for staking
# Action type: cDeposit (user-signed)
exchange.c_deposit(amount)

# Unstake HYPE (enters 7-day queue)
# Action type: cWithdraw (user-signed)
exchange.c_withdraw(amount)
```

### Querying staking info

```python
# Get delegation information
delegations = info.query("delegations", {"user": "0xACCOUNT"})

# Get delegator summary (rewards, APY, etc.)
summary = info.query("delegatorSummary", {"user": "0xACCOUNT"})
```

### Staking fee discounts

Staking HYPE provides fee discounts that stack with volume-based VIP tiers. The exact discount schedule is returned by the `userFees` info query:

```python
fees = info.query("userFees", {"user": "0xACCOUNT"})
# Returns: activeStakingDiscount, feeSchedule with tiers, etc.
```

> **Cross-reference:** See `exchange-actions.md` for `tokenDelegate`, `cDeposit`, and `cWithdraw` action formats, and `rate-limits.md` for fee tier details.

---

## 6. Vaults

Vaults are Hyperliquid's built-in **strategy sharing** mechanism. A vault leader trades on behalf of depositors, earning a profit share.

### Creating a vault

| Property | Value |
|---|---|
| Creation fee | **100 USDC** |
| Leader profit share | **10%** of depositor profits |
| Leader minimum stake | **>= 5%** of total vault value |
| Lockup: HLP vaults | **4 days** |
| Lockup: User vaults | **1 day** |

### Trading via vaults

To trade on behalf of a vault, include the `vaultAddress` field in exchange action requests:

```python
# Deposit into a vault
exchange.vault_transfer("0xVAULT_ADDRESS", is_deposit=True, amount=1000.0)

# Place order on behalf of a vault (signed by the vault leader)
# The vaultAddress field is added to the exchange envelope
result = exchange.order(
    "ETH", True, 0.1, 2800.0,
    {"limit": {"tif": "Gtc"}},
    vault_address="0xVAULT_ADDRESS",
)
```

In raw JSON, the vault address is part of the envelope:

```json
{
  "action": {"type": "order", "orders": [...], "grouping": "na"},
  "nonce": 1734567890123,
  "signature": {"r": "0x...", "s": "0x...", "v": 27},
  "vaultAddress": "0xVAULT_ADDRESS"
}
```

### Querying vault information

```python
# Get vault details (positions, PnL, depositors)
details = info.query("vaultDetails", {"vaultAddress": "0xVAULT"})

# Get all vault summaries
summaries = info.query("vaultSummaries")

# Get leading vaults ranked by performance
leading = info.query("leadingVaults")

# Get user's vault equity positions
equities = info.user_vault_equities("0xACCOUNT")
```

### Key constraints

- The vault leader must maintain at least 5% of total vault value as their own deposit
- Depositors face a lockup period (4 days for HLP, 1 day for user vaults)
- Vault deposits and withdrawals use the `vaultTransfer` action type (L1 action, phantom agent signing)
- The 10% profit share is calculated on realized profits when depositors withdraw

> **Cross-reference:** See `exchange-actions.md` for `vaultTransfer` action format and `info-queries.md` for vault query types.

---

## 7. Sub-Accounts

Sub-accounts provide **isolated trading environments** under a single master account. They are useful for separating strategies, isolating risk, or running multiple bots independently.

### Properties

| Property | Value |
|---|---|
| Maximum sub-accounts | **10** per master account |
| Balance isolation | Each sub-account has its own USDC balance |
| Position isolation | Positions and PnL are isolated per sub-account |
| Volume rollup | Trading volume rolls up to master for fee tier calculations |
| Fee tiers | Based on master's aggregated volume |

### Creating sub-accounts

```python
# Create a new sub-account (user-signed action, chainId 42161)
result = exchange.create_sub_account("Strategy1")
# Returns the sub-account address
```

### Trading via sub-accounts

Sub-accounts use the `vaultAddress` field (same mechanism as vaults):

```python
# Trade on behalf of a sub-account
# The master account signs, the sub-account address goes in vaultAddress
result = exchange.order(
    "ETH", True, 0.1, 2800.0,
    {"limit": {"tif": "Gtc"}},
    vault_address="0xSUB_ACCOUNT_ADDRESS",
)
```

### Transferring funds to sub-accounts

```python
# Transfer USDC from master to sub-account
exchange.usd_transfer(100.0, "0xSUB_ACCOUNT_ADDRESS")

# Transfer between spot and perp wallets within a sub-account
exchange.usd_class_transfer(50.0, to_perp=True)
```

### Querying sub-account state

```python
# Get all sub-accounts and their states
sub_accounts = info.query("subAccounts", {"user": "0xMASTER_ADDRESS"})
# Returns sub-account details with clearinghouse and spot state

# Query a specific sub-account's state
state = info.user_state("0xSUB_ACCOUNT_ADDRESS")
```

### Important: API wallets and sub-accounts

Each sub-account should have its own **dedicated API wallet** to avoid nonce collisions. If two sub-accounts share the same API wallet, their nonces are tracked together (per-signer), which causes conflicts.

```python
# WRONG -- shared API wallet for multiple sub-accounts
agent_wallet = eth_account.Account.from_key("0xSHARED_KEY")
exchange_sub1 = Exchange(agent_wallet, api_url, account_address="0xSUB1")
exchange_sub2 = Exchange(agent_wallet, api_url, account_address="0xSUB2")
# Nonce conflicts will occur!

# CORRECT -- separate API wallets per sub-account
agent_wallet_1 = eth_account.Account.from_key("0xAGENT_KEY_1")
agent_wallet_2 = eth_account.Account.from_key("0xAGENT_KEY_2")
exchange_sub1 = Exchange(agent_wallet_1, api_url, account_address="0xSUB1")
exchange_sub2 = Exchange(agent_wallet_2, api_url, account_address="0xSUB2")
```

Sub-accounts can have up to **2 additional named API wallets** each, on top of the master account's allocation (1 unnamed + 3 named).

> **Cross-reference:** See `authentication-and-signing.md` for API wallet limits and nonce management, and `risk-and-error-handling.md` for Gotcha 4 on nonce conflicts.

---

## 8. HyperEVM Integration

HyperEVM is the Ethereum-compatible execution layer of Hyperliquid, sharing consensus with HyperCore. It enables smart contract development while leveraging HyperCore's native trading engine.

### Timeline

| Date | Milestone |
|---|---|
| February 2025 | HyperEVM **mainnet launch** |
| April 2025 | **Read precompile**: HyperEVM contracts can read HyperCore state |
| July 2025 | **CoreWriter**: HyperEVM contracts can write to HyperCore |

### Network details

| Property | Mainnet | Testnet |
|---|---|---|
| Chain ID | **999** | **998** |
| RPC URL | `https://rpc.hyperliquid.xyz/evm` | -- |
| Block time | **1 second** (small blocks) | -- |
| Gas limit | **2M gas** per block | -- |

### Read precompile (April 2025)

HyperEVM smart contracts can read HyperCore state directly through precompiled contracts at addresses starting at `0x0000000000000000000000000000000000000800`. This allows:

- Reading **oracle prices** from HyperCore
- Reading **account positions** and balances
- Reading **order book state**
- All without REST API calls -- directly from within Solidity

```solidity
// Example: Reading oracle price from HyperCore (pseudocode)
// The exact interface depends on the precompile specification
interface IHyperCoreReader {
    function getOraclePrice(uint256 assetIndex) external view returns (uint256);
    function getAccountPosition(address user, uint256 assetIndex) external view returns (int256);
}

IHyperCoreReader reader = IHyperCoreReader(0x0000000000000000000000000000000000000800);
uint256 btcPrice = reader.getOraclePrice(0);  // BTC = asset index 0
```

### CoreWriter (July 2025)

CoreWriter enables HyperEVM contracts to **write to HyperCore** -- placing orders, transferring assets, and performing other trading actions from within smart contracts.

| Property | Value |
|---|---|
| System contract | `0x3333333333333333333333333333333333333333` |
| Latency | Actions delayed a few seconds (prevents latency arbitrage) |
| Atomicity | **No guarantee** -- a failed CoreWriter action does NOT revert the EVM transaction |

```solidity
// Example: Placing an order from HyperEVM (pseudocode)
interface ICoreWriter {
    function placeOrder(
        uint256 asset,
        bool isBuy,
        uint256 price,
        uint256 size,
        bool reduceOnly
    ) external;

    function transferToHyperCore(
        address token,
        uint256 amount
    ) external;
}

ICoreWriter writer = ICoreWriter(0x3333333333333333333333333333333333333333);
writer.placeOrder(1, true, 2800e6, 1e5, false);  // Buy 0.1 ETH at 2800
```

**Critical caveat:** CoreWriter actions are **not atomic** with the EVM transaction. If a CoreWriter call fails (e.g., insufficient margin on HyperCore), the EVM transaction still succeeds. Your contract must handle this asynchronously -- listen for order status updates or check positions after the delay.

### ERC-20 linking

HIP-1 tokens can be linked to ERC-20 contracts on HyperEVM, enabling:

- Bridging tokens between HyperCore (native) and HyperEVM (ERC-20)
- Using HIP-1 tokens in HyperEVM DeFi protocols
- Maintaining the native order book while enabling smart contract composability

### Development tools

- **Official testing library**: `github.com/hyperliquid-dev/hyper-evm-lib` -- Foundry-based testing framework for HyperEVM smart contracts
- **Standard tooling**: Foundry, Hardhat, and other EVM development tools work with HyperEVM
- **RPC endpoint**: Use `https://rpc.hyperliquid.xyz/evm` for mainnet JSON-RPC calls

```bash
# Configure Foundry for HyperEVM
forge create --rpc-url https://rpc.hyperliquid.xyz/evm \
  --chain-id 999 \
  --private-key 0xPRIVATE_KEY \
  src/MyContract.sol:MyContract

# JSON-RPC rate limit: 100 requests/minute
```

> **Cross-reference:** See `rate-limits.md` for HyperEVM JSON-RPC rate limits (100/minute) and `connection-and-endpoints.md` for RPC URLs.

---

## 9. Community Resources and Builder Codes

### Official resources

| Resource | URL | Description |
|---|---|---|
| Discord | `discord.com/invite/hyperliquid` | **81,000+ members**, open-ticket support |
| Documentation | `hyperliquid.gitbook.io/hyperliquid-docs` | Official gitbook docs |
| Stats dashboard | `stats.hyperliquid.xyz` | Historical trading data, volume, OI |
| Funding comparison | `app.hyperliquid.xyz/fundingComparison` | Compare funding rates across exchanges |
| Mainnet app | `app.hyperliquid.xyz` | Trading interface |
| Testnet app | `app.hyperliquid-testnet.xyz` | Testnet trading + faucet |
| API wallets | `app.hyperliquid.xyz/API` | Create and manage API wallets via UI |

### Builder codes (builder fees)

Builder codes enable front-end operators and integrators to earn fees from trades executed through their interface.

| Property | Value |
|---|---|
| Max builder fee (perps) | **0.1%** (10 basis points) |
| Max builder fee (spot) | **1%** (100 basis points) |
| Minimum account value | **>= 100 USDC** to use builder codes |
| Fee unit | Tenths of a basis point (f=10 means 1bp = 0.01%) |

### Using builder fees in orders

The builder fee is an optional field in order placement:

```python
# User must first approve the builder fee
exchange.approve_builder_fee("0xBUILDER_ADDRESS", "0.001%")

# Then orders can include the builder field
# In raw JSON:
{
  "type": "order",
  "orders": [...],
  "grouping": "na",
  "builder": {
    "b": "0xBUILDER_ADDRESS",
    "f": 10  # 10 = 1 basis point (0.01%)
  }
}
```

### Querying builder fee limits

```python
# Check maximum allowed builder fee for an asset
max_fee = info.query("maxBuilderFee", {"user": "0xACCOUNT", "builder": "0xBUILDER"})
```

### Third-party testnet faucets

| Provider | Amount | Cooldown |
|---|---|---|
| QuickNode | 1 HYPE | Every 12 hours |
| Chainstack | 1 HYPE | Every 24 hours |
| Official faucet | 1,000 mock USDC | Requires prior mainnet deposit |

The official faucet can be triggered programmatically:

```python
import requests

# Claim testnet USDC
response = requests.post(
    "https://api.hyperliquid-testnet.xyz/info",
    json={"type": "claimDrip", "user": "0xYOUR_ADDRESS"}
)
```

### SDK and tool ecosystem

| Tool | Language | Stars | Notes |
|---|---|---|---|
| hyperliquid-python-sdk | Python | Official | v0.22.0, Python >= 3.9 |
| @nktkas/hyperliquid | TypeScript | 326 | Modular, type-safe, recommended |
| nomeida/hyperliquid | TypeScript | 268 | High-level API, Node.js 22+ |
| CCXT | Multi-language | N/A | `ccxt.hyperliquid` connector |
| Hummingbot | Python | N/A | Native Hyperliquid connector (spot + perp) |

> **Cross-reference:** See `python-sdk.md` for complete Python SDK reference, `typescript-sdks.md` for TypeScript SDKs, and `bot-architecture.md` for open-source bot examples.
