# Python SDK — Hyperliquid API Reference

## Table of Contents

1. [Installation and Requirements](#1-installation-and-requirements)
2. [Setup and Initialization](#2-setup-and-initialization)
3. [API Wallet Setup](#3-api-wallet-setup)
4. [Info Class Methods](#4-info-class-methods)
5. [Exchange Class Methods](#5-exchange-class-methods)
6. [WebSocket Subscriptions](#6-websocket-subscriptions)
7. [Client Order ID (Cloid)](#7-client-order-id-cloid)
8. [Common Patterns: Full Trading Lifecycle](#8-common-patterns-full-trading-lifecycle)

---

## 1. Installation and Requirements

**Package:** `hyperliquid-python-sdk`
**Version:** 0.22.0 (as of February 2026)
**Python:** >= 3.9
**GitHub:** [github.com/hyperliquid-dex/hyperliquid-python-sdk](https://github.com/hyperliquid-dex/hyperliquid-python-sdk)

```bash
pip install hyperliquid-python-sdk
```

### Dependencies

The SDK depends on `eth_account` for wallet management and signing. Install it alongside if not already present:

```bash
pip install hyperliquid-python-sdk eth_account
```

For WebSocket support (non-`skip_ws` mode), the SDK uses its own internal WebSocket client. No additional WebSocket library is required for the SDK's built-in subscriptions.

---

## 2. Setup and Initialization

The SDK provides two main classes: `Info` for read-only queries and `Exchange` for signed trading actions.

```python
import eth_account
from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants

# --- Read-only client (no private key needed) ---
info = Info(constants.MAINNET_API_URL, skip_ws=True)

# --- Trading client (requires private key) ---
wallet = eth_account.Account.from_key("0xYOUR_PRIVATE_KEY")
exchange = Exchange(
    wallet,
    constants.MAINNET_API_URL,
    account_address=wallet.address
)
```

### Available constants

```python
from hyperliquid.utils import constants

constants.MAINNET_API_URL   # "https://api.hyperliquid.xyz"
constants.TESTNET_API_URL   # "https://api.hyperliquid-testnet.xyz"
```

### Testnet setup

```python
# For testnet, swap the URL constant
info = Info(constants.TESTNET_API_URL, skip_ws=True)
exchange = Exchange(wallet, constants.TESTNET_API_URL, account_address=wallet.address)
```

> **Cross-reference:** For testnet faucet and development workflow, see `connection-and-endpoints.md`. For mainnet vs testnet signing differences (`"a"` vs `"b"` phantom agent source), see `authentication-and-signing.md`.

---

## 3. API Wallet Setup

API wallets (agent wallets) are separate key pairs used exclusively for signing L1 trading actions. They are stateless -- they hold no funds and no positions. The master wallet address is always used for querying account state.

When using an API wallet:
- `secret_key` (the wallet passed to `Exchange`) = **agent wallet** private key
- `account_address` = **master wallet** public address

```python
import eth_account
from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants

# Agent wallet private key (from approveAgent or the UI)
agent_wallet = eth_account.Account.from_key("0xAGENT_PRIVATE_KEY")

# Exchange client: signs with agent key, operates on master account
exchange = Exchange(
    agent_wallet,
    constants.MAINNET_API_URL,
    account_address="0xMASTER_WALLET_ADDRESS"  # <-- MASTER address, not agent
)

# Info queries: always use the MASTER address
info = Info(constants.MAINNET_API_URL, skip_ws=True)
state = info.user_state("0xMASTER_WALLET_ADDRESS")   # Correct
# state = info.user_state("0xAGENT_ADDRESS")         # WRONG -- returns empty
```

### Creating an API wallet programmatically

```python
# approve_agent creates a new named API wallet and returns (response, agent_key)
response, agent_key = exchange.approve_agent("my_bot_v1")
print(f"Agent private key: {agent_key}")
# Store this key securely -- it cannot be retrieved later
```

### Limits

- **1 unnamed + 3 named** API wallets per master account
- **2 additional named** API wallets per sub-account
- Registering a new unnamed wallet **deregisters** the previous unnamed one
- Never reuse deregistered agent wallet addresses

> **Cross-reference:** For detailed API wallet mechanics and signing, see `authentication-and-signing.md`. For nonce management (use separate API wallets per process), see `authentication-and-signing.md` section 5.4.

---

## 4. Info Class Methods

All `Info` methods are read-only and do not require a private key. They map to `POST /info` requests.

### 4.1 Market metadata

```python
# Perpetual metadata: universe array with name, szDecimals, maxLeverage
meta = info.meta()
# Returns: {"universe": [{"name": "BTC", "szDecimals": 5, "maxLeverage": 50}, ...]}

# Spot metadata: tokens and universe
spot_meta = info.spot_meta()
```

### 4.2 Market data

```python
# All mid prices: {"BTC": "95123.5", "ETH": "2891.3", ...}
mids = info.all_mids()

# L2 orderbook snapshot (max 20 levels per side)
book = info.l2_snapshot("ETH")
# Returns: {"levels": [[bids], [asks]], "coin": "ETH", "time": ...}
# bids[0] = best bid, asks[0] = best ask
# Each level: {"px": "2890.5", "sz": "12.3", "n": 5}

# OHLCV candles (max 5000 candles)
# Intervals: 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 8h, 12h, 1d, 3d, 1w, 1M
import time
end_ms = int(time.time() * 1000)
start_ms = end_ms - 3600 * 1000  # Last hour
candles = info.candles_snapshot("BTC", "1h", start_ms, end_ms)
# Returns: [{"t": open_time, "T": close_time, "s": "BTC", "i": "1h",
#            "o": open, "c": close, "h": high, "l": low, "v": volume, "n": trades}]
```

### 4.3 User state

```python
address = "0xYOUR_ADDRESS"

# Full perp account state: positions, margin, withdrawable
state = info.user_state(address)
# Key fields:
#   state["assetPositions"][i]["position"]: coin, szi, entryPx, unrealizedPnl,
#       liquidationPx, leverage, marginUsed, positionValue, returnOnEquity
#   state["marginSummary"]: accountValue, totalNtlPos, totalMarginUsed
#   state["withdrawable"]: available to withdraw

# Spot balances
spot = info.spot_user_state(address)
# Returns: {"balances": [{"coin": "USDC", "token": 0, "hold": "0.0", "total": "100.22"}]}
```

### 4.4 Orders and fills

```python
address = "0xYOUR_ADDRESS"

# Open orders (basic): coin, limitPx, oid, side ("A"/"B"), sz, timestamp
orders = info.open_orders(address)

# Open orders (detailed): adds orderType, origSz, reduceOnly, triggerCondition, triggerPx
detailed = info.frontend_open_orders(address)

# Recent fills: coin, px, sz, side, time, dir, closedPnl, fee, hash, oid, tid
fills = info.user_fills(address)

# Fills by time range (max 500, paginate via last timestamp as next startTime)
fills = info.user_fills_by_time(address, start_ms, end_ms)

# Query specific order by OID
order = info.query_order_by_oid(address, 77738308)
# Returns: status (filled/canceled/rejected/resting/error), statusTimestamp, order details

# Query specific order by CLOID
order = info.query_order_by_cloid(address, cloid)
```

### 4.5 Funding data

```python
# Funding rate history for a coin
funding = info.funding_history("ETH", start_ms, end_ms)
# Returns: [{"coin": "ETH", "fundingRate": "0.00003", "premium": "0.0001", "time": ...}]

# User funding payments
user_funding = info.user_funding_history(address, start_ms, end_ms)
# Returns: [{"delta": {"coin", "fundingRate", "szi", "type": "funding", "usdc"}, "hash", "time"}]

# Non-funding ledger updates (deposits, withdrawals, transfers, liquidations)
ledger = info.user_non_funding_ledger_updates(address, start_ms)
```

### 4.6 Account info and rate limits

```python
# Rate limit status: cumVlm, nRequestsUsed, nRequestsCap
rate_limit = info.user_rate_limit(address)

# Account role: "user", "agent", "vault", "subAccount", "missing"
role = info.user_role(address)

# Vault positions for user
vaults = info.user_vault_equities(address)

# Extra agents (API wallets) registered for account
agents = info.extra_agents(address)
```

> **Cross-reference:** For the raw JSON request/response formats of all info queries, see `info-queries.md`. For rate limit weights of each query, see `rate-limits.md`.

---

## 5. Exchange Class Methods

All `Exchange` methods require a private key and produce signed `POST /exchange` requests.

### 5.1 Order placement

```python
# Limit order (GTC): rests on book until filled or canceled
result = exchange.order("ETH", True, 0.2, 1100, {"limit": {"tif": "Gtc"}})
# Args: coin, is_buy, size, price, order_type
# Returns: {"status": "ok", "response": {"type": "order", "data": {"statuses": [...]}}}

# IOC order (fill-or-kill): unfilled portion canceled immediately
result = exchange.order("ETH", True, 0.2, 2900, {"limit": {"tif": "Ioc"}})

# ALO order (post-only): canceled if would immediately match
result = exchange.order("ETH", True, 0.2, 2800, {"limit": {"tif": "Alo"}})

# Stop-loss (trigger): market sell when price hits trigger
result = exchange.order("ETH", False, 0.2, 2800,
    {"trigger": {"triggerPx": "2800", "isMarket": True, "tpsl": "sl"}})

# Take-profit (trigger): market sell at take-profit
result = exchange.order("ETH", False, 0.2, 3500,
    {"trigger": {"triggerPx": "3500", "isMarket": True, "tpsl": "tp"}})

# Market open: IOC with configurable slippage (default 1%)
result = exchange.market_open("ETH", True, 0.05, slippage=0.01)

# Market close: close full position at market
result = exchange.market_close("ETH")

# Market close: partial close
result = exchange.market_close("ETH", sz=0.01)

# Bulk orders: batch multiple orders in a single request
orders = [
    {
        "coin": "ETH",
        "is_buy": True,
        "sz": 0.1,
        "limit_px": 3000,
        "order_type": {"limit": {"tif": "Gtc"}},
        "reduce_only": False
    },
    {
        "coin": "BTC",
        "is_buy": False,
        "sz": 0.001,
        "limit_px": 100000,
        "order_type": {"limit": {"tif": "Gtc"}},
        "reduce_only": False
    }
]
result = exchange.bulk_orders(orders)
```

### 5.2 Order response handling

```python
result = exchange.order("ETH", True, 0.1, 2800, {"limit": {"tif": "Gtc"}})

# Check response
statuses = result["response"]["data"]["statuses"]
for status in statuses:
    if "resting" in status:
        oid = status["resting"]["oid"]
        print(f"Order resting with OID: {oid}")
    elif "filled" in status:
        print(f"Filled: {status['filled']['totalSz']} @ {status['filled']['avgPx']}")
    elif "error" in status:
        print(f"Error: {status['error']}")
```

### 5.3 Order modification and cancellation

```python
# Cancel by OID
exchange.cancel("ETH", 77738308)

# Cancel by CLOID
exchange.cancel_by_cloid("ETH", cloid)

# Bulk cancel
exchange.bulk_cancel([
    {"coin": "ETH", "oid": 77738308},
    {"coin": "BTC", "oid": 77738309}
])

# Modify order (change price and/or size, keeps the same OID)
exchange.modify_order(
    77738308,           # oid
    "ETH",              # coin
    True,               # is_buy
    0.2,                # new size
    3100,               # new price
    {"limit": {"tif": "Gtc"}}  # order type
)

# Bulk modify
exchange.bulk_modify_orders([
    {
        "oid": 77738308,
        "order": {
            "coin": "ETH",
            "is_buy": True,
            "sz": 0.2,
            "limit_px": 3100,
            "order_type": {"limit": {"tif": "Gtc"}},
            "reduce_only": False
        }
    }
])
```

### 5.4 Position and leverage management

```python
# Update leverage: cross mode, 10x
exchange.update_leverage(10, "ETH", is_cross=True)

# Update leverage: isolated mode, 5x
exchange.update_leverage(5, "BTC", is_cross=False)

# Add isolated margin (USDC)
exchange.update_isolated_margin(100.0, "ETH")

# Remove isolated margin (negative amount)
exchange.update_isolated_margin(-50.0, "ETH")
```

### 5.5 Transfers and withdrawals

```python
# Send USDC to another address
exchange.usd_transfer(100.0, "0xDEST_ADDRESS")

# Send spot token to another address
exchange.spot_transfer(0.1, "0xDEST_ADDRESS", "PURR:0xc1fb593a...")

# Withdraw USDC to Arbitrum ($1 fee, ~5 minutes)
exchange.withdraw_from_bridge(100.0, "0xDEST_ADDRESS")

# Transfer between spot and perp wallets
exchange.usd_class_transfer(100.0, to_perp=True)   # Spot -> Perp
exchange.usd_class_transfer(50.0, to_perp=False)    # Perp -> Spot

# Vault deposit/withdrawal
exchange.vault_transfer("0xVAULT_ADDRESS", is_deposit=True, amount=1000.0)
exchange.vault_transfer("0xVAULT_ADDRESS", is_deposit=False, amount=500.0)
```

### 5.6 Account management

```python
# Create named API wallet (returns response + agent private key)
response, agent_key = exchange.approve_agent("bot_v1")
print(f"New agent key: {agent_key}")

# Approve builder fee (max fee rate a builder can charge)
exchange.approve_builder_fee("0xBUILDER_ADDRESS", "0.001%")

# Set referral code
exchange.set_referrer("REFCODE")

# Create sub-account
exchange.create_sub_account("Strategy1")

# Dead man's switch: cancel all open orders at specified time
import time
future_ms = int(time.time() * 1000) + 60000  # 60 seconds from now
exchange.schedule_cancel(future_ms)
# Must be >= 5 seconds in the future. Max 10 triggers per day (resets 00:00 UTC).
# Omit the time argument to remove a scheduled cancel.
```

> **Cross-reference:** For the raw JSON format of all exchange actions, see `exchange-actions.md`. For signing mechanics behind these methods, see `authentication-and-signing.md`. For rate limit weights of exchange requests, see `rate-limits.md`.

---

## 6. WebSocket Subscriptions

The SDK has built-in WebSocket support when initialized with `skip_ws=False`.

### Setup

```python
from hyperliquid.info import Info
from hyperliquid.utils import constants

# Initialize with WebSocket enabled
info = Info(constants.MAINNET_API_URL, skip_ws=False)
```

### Subscribe to channels

The `subscribe` method takes a subscription payload dict and a callback function. The callback is invoked each time a message arrives on that channel.

```python
# Orderbook updates
def on_book(data):
    bids = data["levels"][0]
    asks = data["levels"][1]
    if bids and asks:
        print(f"Spread: {bids[0]['px']} / {asks[0]['px']}")

info.subscribe({"type": "l2Book", "coin": "ETH"}, on_book)

# Real-time trades
def on_trade(data):
    for trade in data:
        print(f"{trade['coin']} {trade['side']} {trade['sz']} @ {trade['px']}")

info.subscribe({"type": "trades", "coin": "BTC"}, on_trade)

# All mid prices
def on_mids(data):
    btc_mid = data["mids"].get("BTC")
    eth_mid = data["mids"].get("ETH")
    print(f"BTC: {btc_mid}, ETH: {eth_mid}")

info.subscribe({"type": "allMids"}, on_mids)

# User events (fills, funding, liquidations)
def on_events(data):
    if "fills" in data:
        for fill in data["fills"]:
            print(f"Fill: {fill['coin']} {fill['dir']} {fill['sz']} @ {fill['px']}")

info.subscribe({"type": "userEvents", "user": "0xYOUR_ADDRESS"}, on_events)

# Order updates
def on_orders(data):
    for order in data:
        print(f"Order {order['order']['oid']}: {order['status']}")

info.subscribe({"type": "orderUpdates", "user": "0xYOUR_ADDRESS"}, on_orders)

# User fills (with initial snapshot)
def on_fills(data):
    is_snapshot = data.get("isSnapshot", False)
    fills = data.get("fills", [])
    prefix = "SNAPSHOT" if is_snapshot else "NEW"
    for fill in fills:
        print(f"[{prefix}] {fill['coin']} {fill['side']} {fill['sz']} @ {fill['px']}")

info.subscribe({"type": "userFills", "user": "0xYOUR_ADDRESS"}, on_fills)
```

### Available subscription channels

All 19 channels documented in the WebSocket reference are available through the SDK's subscribe method:

```python
# Market data (no user address needed)
info.subscribe({"type": "allMids"}, callback)
info.subscribe({"type": "l2Book", "coin": "ETH"}, callback)
info.subscribe({"type": "bbo", "coin": "ETH"}, callback)
info.subscribe({"type": "trades", "coin": "SOL"}, callback)
info.subscribe({"type": "candle", "coin": "ETH", "interval": "1m"}, callback)
info.subscribe({"type": "activeAssetCtx", "coin": "ETH"}, callback)

# User data (requires user address -- always use master address, not agent)
info.subscribe({"type": "orderUpdates", "user": addr}, callback)
info.subscribe({"type": "userEvents", "user": addr}, callback)
info.subscribe({"type": "userFills", "user": addr}, callback)
info.subscribe({"type": "userFundings", "user": addr}, callback)
info.subscribe({"type": "userNonFundingLedgerUpdates", "user": addr}, callback)
info.subscribe({"type": "clearinghouseState", "user": addr}, callback)
info.subscribe({"type": "openOrders", "user": addr}, callback)
info.subscribe({"type": "notification", "user": addr}, callback)
info.subscribe({"type": "webData3", "user": addr}, callback)
info.subscribe({"type": "twapStates", "user": addr}, callback)
info.subscribe({"type": "activeAssetData", "user": addr, "coin": "ETH"}, callback)
info.subscribe({"type": "userTwapSliceFills", "user": addr}, callback)
info.subscribe({"type": "userTwapHistory", "user": addr}, callback)
```

> **Cross-reference:** For detailed data formats and notes for each WebSocket channel, see `websocket-channels.md`. For WebSocket connection limits (100 connections, 1000 subscriptions, 10 unique users per IP), see `rate-limits.md`.

---

## 7. Client Order ID (Cloid)

Client Order IDs (CLOIDs) are 128-bit hex identifiers you assign to orders for idempotent tracking. They persist across WebSocket reconnections and allow you to track orders without relying on server-assigned OIDs.

### Creating and using CLOIDs

```python
from hyperliquid.utils.types import Cloid

# Create from a hex string (128-bit = 32 hex chars, prefixed with 0x)
cloid = Cloid.from_str("0x1234567890abcdef1234567890abcdef")

# Place order with CLOID
result = exchange.order(
    "ETH",
    True,           # is_buy
    0.2,            # size
    1100,           # price
    {"limit": {"tif": "Gtc"}},
    cloid=cloid     # attach client order ID
)
```

### Querying by CLOID

```python
# Look up order status by CLOID (instead of OID)
order_status = info.query_order_by_cloid("0xYOUR_ADDRESS", cloid)
# Returns: order details with status, statusTimestamp, etc.
```

### Canceling by CLOID

```python
# Cancel order using CLOID (instead of OID)
exchange.cancel_by_cloid("ETH", cloid)
```

### Best practices for CLOIDs

```python
import uuid

def generate_cloid() -> Cloid:
    """Generate a unique CLOID using UUID4."""
    raw = uuid.uuid4().hex  # 32 hex chars
    return Cloid.from_str(f"0x{raw}")

# Use CLOIDs for every order to enable:
# 1. Tracking across WebSocket reconnections
# 2. Querying order status without knowing server OID
# 3. Canceling orders without knowing server OID
# 4. Idempotent order identification in your own systems

cloid = generate_cloid()
result = exchange.order("ETH", True, 0.1, 2800, {"limit": {"tif": "Gtc"}}, cloid=cloid)

# Store CLOID -> order mapping locally
order_map = {}
order_map[str(cloid)] = {
    "coin": "ETH",
    "side": "buy",
    "size": 0.1,
    "price": 2800,
    "result": result
}
```

> **Cross-reference:** For CLOID in WebSocket `orderUpdates` messages (the `cloid` field on WsOrder), see `websocket-channels.md` section 5.1.

---

## 8. Common Patterns: Full Trading Lifecycle

This example demonstrates a complete trading lifecycle from setup through position management to cleanup.

```python
import eth_account
import time
from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants
from hyperliquid.utils.types import Cloid

# ============================================================
# 1. CONNECT
# ============================================================
wallet = eth_account.Account.from_key("0xPRIVATE_KEY")
info = Info(constants.MAINNET_API_URL, skip_ws=True)
exchange = Exchange(wallet, constants.MAINNET_API_URL, account_address=wallet.address)

# ============================================================
# 2. CHECK ACCOUNT STATE
# ============================================================
state = info.user_state(wallet.address)
account_value = state["marginSummary"]["accountValue"]
withdrawable = state["withdrawable"]
print(f"Account value: {account_value} USDC")
print(f"Withdrawable:  {withdrawable} USDC")

# Check rate limit budget
rl = info.user_rate_limit(wallet.address)
print(f"Rate limit: {rl['nRequestsUsed']}/{rl['nRequestsCap']} used")

# ============================================================
# 3. GET MARKET DATA
# ============================================================
mids = info.all_mids()
eth_mid = float(mids["ETH"])
print(f"ETH mid price: {eth_mid}")

book = info.l2_snapshot("ETH")
best_bid = book["levels"][0][0]["px"]
best_ask = book["levels"][1][0]["px"]
print(f"ETH spread: {best_bid} / {best_ask}")

# ============================================================
# 4. SET LEVERAGE
# ============================================================
exchange.update_leverage(5, "ETH", is_cross=True)

# ============================================================
# 5. PLACE LIMIT ORDER WITH CLOID
# ============================================================
cloid = Cloid.from_str("0x" + "a1" * 16)
entry_price = round(eth_mid * 0.97, 1)  # 3% below mid
result = exchange.order("ETH", True, 0.1, entry_price,
                        {"limit": {"tif": "Gtc"}}, cloid=cloid)

oid = None
statuses = result["response"]["data"]["statuses"]
for s in statuses:
    if "resting" in s:
        oid = s["resting"]["oid"]
        print(f"Order resting: OID {oid}")
    elif "filled" in s:
        print(f"Filled: {s['filled']['totalSz']} @ {s['filled']['avgPx']}")
    elif "error" in s:
        print(f"Error: {s['error']}")

# ============================================================
# 6. PLACE STOP-LOSS AND TAKE-PROFIT
# ============================================================
sl_price = round(eth_mid * 0.93, 1)  # 7% below mid
tp_price = round(eth_mid * 1.05, 1)  # 5% above mid

# Stop-loss: market sell when price drops to trigger
exchange.order("ETH", False, 0.1, sl_price,
    {"trigger": {"triggerPx": str(sl_price), "isMarket": True, "tpsl": "sl"}},
    reduce_only=True)

# Take-profit: market sell when price rises to trigger
exchange.order("ETH", False, 0.1, tp_price,
    {"trigger": {"triggerPx": str(tp_price), "isMarket": True, "tpsl": "tp"}},
    reduce_only=True)

# ============================================================
# 7. MODIFY ORDER (if still resting)
# ============================================================
if oid:
    new_price = round(eth_mid * 0.96, 1)  # Adjust to 4% below mid
    exchange.modify_order(oid, "ETH", True, 0.1, new_price,
                          {"limit": {"tif": "Gtc"}})
    print(f"Modified order {oid} to price {new_price}")

# ============================================================
# 8. MONITOR POSITIONS
# ============================================================
state = info.user_state(wallet.address)
for pos in state["assetPositions"]:
    p = pos["position"]
    print(f"{p['coin']}: size={p['szi']}, entry={p['entryPx']}, "
          f"pnl={p['unrealizedPnl']}, liq={p['liquidationPx']}")

# ============================================================
# 9. CLOSE POSITION AT MARKET
# ============================================================
exchange.market_close("ETH")
print("Position closed")

# ============================================================
# 10. CANCEL ALL REMAINING ORDERS
# ============================================================
for order in info.open_orders(wallet.address):
    exchange.cancel(order["coin"], order["oid"])
    print(f"Canceled {order['coin']} order {order['oid']}")

# ============================================================
# 11. EMERGENCY SHUTDOWN (if needed)
# ============================================================
def emergency_shutdown(exchange, info, address):
    """Cancel all orders and close all positions immediately."""
    # Step 1: Dead man's switch (backup)
    exchange.schedule_cancel(int(time.time() * 1000) + 10000)

    # Step 2: Cancel all open orders
    for order in info.open_orders(address):
        try:
            exchange.cancel(order["coin"], order["oid"])
        except Exception as e:
            print(f"Cancel failed for {order['oid']}: {e}")

    # Step 3: Close all positions at market
    user_state = info.user_state(address)
    for pos in user_state["assetPositions"]:
        p = pos["position"]
        sz = float(p["szi"])
        if sz != 0:
            try:
                exchange.market_close(p["coin"])
                print(f"Closed {p['coin']} position (size: {sz})")
            except Exception as e:
                print(f"Close failed for {p['coin']}: {e}")
```

> **Cross-reference:** For TypeScript equivalents of these patterns, see `typescript-sdks.md`. For error codes and handling during the trading lifecycle, see `risk-and-error-handling.md`. For the 6-stage bot architecture pattern, see `bot-architecture.md`. For rate limit budget management during high-frequency operations, see `rate-limits.md`.
