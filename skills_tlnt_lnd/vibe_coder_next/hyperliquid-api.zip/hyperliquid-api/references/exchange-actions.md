# Exchange Actions

## Table of Contents

1. [Exchange Request Envelope](#1-exchange-request-envelope)
2. [Order Placement](#2-order-placement)
3. [Order Types](#3-order-types)
4. [Market Orders](#4-market-orders)
5. [Order Grouping and Builder Fee](#5-order-grouping-and-builder-fee)
6. [Order Responses](#6-order-responses)
7. [Order Cancellation](#7-order-cancellation)
8. [Order Modification](#8-order-modification)
9. [Position and Leverage Management](#9-position-and-leverage-management)
10. [Close Position Pattern](#10-close-position-pattern)
11. [TWAP Orders](#11-twap-orders)
12. [Transfers and Withdrawals](#12-transfers-and-withdrawals)
13. [Account Management Actions](#13-account-management-actions)
14. [Complete Action Type Taxonomy](#14-complete-action-type-taxonomy)
15. [Batch Operations and Error Handling](#15-batch-operations-and-error-handling)
16. [SDK Method Reference](#16-sdk-method-reference)

---

## 1. Exchange Request Envelope

Every exchange request wraps an action in a standard envelope sent via `POST /exchange`:

```json
{
  "action": { "type": "...", /* action-specific payload */ },
  "nonce": 1734567890123,
  "signature": { "r": "0x...", "s": "0x...", "v": 27 },
  "vaultAddress": "0x...",
  "expiresAfter": 1734567900000
}
```

### Field Details

| Field | Required | Description |
|-------|----------|-------------|
| `action` | Yes | The action object with a `type` field and action-specific parameters |
| `nonce` | Yes | Timestamp in milliseconds, used for replay protection |
| `signature` | Yes | EIP-712 signature with `r`, `s`, `v` components |
| `vaultAddress` | No | Address of subaccount or vault to trade on behalf of (signed by master account) |
| `expiresAfter` | No | Millisecond timestamp after which the action is rejected |

### Important Notes on Optional Fields

- **`vaultAddress`**: Used when the master account signs an action to execute on a subaccount or vault. Omit for direct account trading.
- **`expiresAfter`**: Not supported on user-signed actions. A stale `expiresAfter` (action submitted after expiry) consumes **5x rate limit weight**. Use this as a safety mechanism, not a routing tool.

See [authentication-and-signing.md](authentication-and-signing.md) for how `nonce` and `signature` are constructed.

---

## 2. Order Placement

Action type: `"order"`

```json
{
  "type": "order",
  "orders": [
    {
      "a": 0,
      "b": true,
      "p": "50000",
      "s": "0.01",
      "r": false,
      "t": {"limit": {"tif": "Gtc"}},
      "c": "0x1234567890abcdef1234567890abcdef"
    }
  ],
  "grouping": "na",
  "builder": {"b": "0xBuilderAddress", "f": 10}
}
```

### Order Field Abbreviations

| Field | Full Name | Type | Description |
|-------|-----------|------|-------------|
| `a` | asset | number | Asset index (0 = BTC, 1 = ETH, 10000+ = spot) |
| `b` | isBuy | boolean | `true` = buy/long, `false` = sell/short |
| `p` | price | string | Limit price, **no trailing zeros** |
| `s` | size | string | Order size, **no trailing zeros** |
| `r` | reduceOnly | boolean | If true, can only reduce existing position |
| `t` | orderType | object | Order type specification (see section 3) |
| `c` | cloid | string | Optional 128-bit hex client order ID |

### Critical Formatting Rules

- **Price (`p`)**: Must be a string with no trailing zeros. `"50000"` is correct, `"50000.0"` is wrong.
- **Size (`s`)**: Same rule. `"0.01"` is correct, `"0.010"` is wrong.
- **Asset (`a`)**: Use numeric index from `meta` response. See [connection-and-endpoints.md](connection-and-endpoints.md) for asset indexing.
- **Cloid (`c`)**: Optional 128-bit hex string. Useful for idempotent order tracking across reconnects.
- **Minimum order value**: **$10** for perps, 10 quote tokens for spot.

---

## 3. Order Types

The `t` field in an order specifies the order type and execution behavior.

### Order Type Table

| Type | Schema | Use Case |
|------|--------|----------|
| Limit GTC | `{"limit": {"tif": "Gtc"}}` | Rests on book until filled or canceled |
| Limit IOC | `{"limit": {"tif": "Ioc"}}` | Immediate-or-cancel; unfilled portion canceled |
| Limit ALO (Post-Only) | `{"limit": {"tif": "Alo"}}` | Add-liquidity-only; canceled if would immediately match |
| Stop-Loss Market | `{"trigger": {"triggerPx": "48000", "isMarket": true, "tpsl": "sl"}}` | Market sell when price hits trigger |
| Stop-Loss Limit | `{"trigger": {"triggerPx": "48000", "isMarket": false, "tpsl": "sl"}}` | Limit order at `p` when triggered |
| Take-Profit Market | `{"trigger": {"triggerPx": "55000", "isMarket": true, "tpsl": "tp"}}` | Market sell at take-profit level |
| Take-Profit Limit | `{"trigger": {"triggerPx": "55000", "isMarket": false, "tpsl": "tp"}}` | Limit at `p` when triggered |

### Trigger Order Details

For trigger orders (stop-loss and take-profit), `triggerPx` is the oracle price at which the order activates. Once triggered:
- If `isMarket: true`, the order executes as an IOC order at an aggressive price.
- If `isMarket: false`, the order becomes a limit order at the price specified in `p`.

### ALO (Post-Only) Optimization

Batch ALO orders separately from IOC/GTC orders. ALO-only batches receive **validator priority**, resulting in better queue position and fill rates for market-making strategies.

---

## 4. Market Orders

Hyperliquid has no native market order type. Simulate market orders using IOC with an aggressive price:

```json
{
  "type": "order",
  "orders": [
    {
      "a": 1,
      "b": true,
      "p": "3000",
      "s": "0.1",
      "r": false,
      "t": {"limit": {"tif": "Ioc"}}
    }
  ],
  "grouping": "na"
}
```

**Price strategy**: Set the limit price 3-5% above mid for buys, 3-5% below mid for sells. This provides enough slippage tolerance to guarantee a fill while limiting worst-case execution price.

```python
# Python SDK has built-in market order helpers
exchange.market_open("ETH", True, 0.05, slippage=0.01)   # Market buy 0.05 ETH, 1% slippage
exchange.market_close("ETH")                               # Close full ETH position
exchange.market_close("ETH", sz=0.01)                      # Partial close
```

---

## 5. Order Grouping and Builder Fee

### Grouping Field

The `grouping` field controls how orders in a batch relate to each other:

| Value | Behavior |
|-------|----------|
| `"na"` | Standalone orders, no grouping |
| `"normalTpsl"` | Entry order + TP/SL grouped together; TP/SL activate when entry fills |
| `"positionTpsl"` | TP/SL applied to the entire existing position |

### Builder Fee

Optional builder fee allows front-end builders to earn fees on orders they facilitate:

```json
{
  "builder": {
    "b": "0xBuilderAddress",
    "f": 10
  }
}
```

- `b`: Builder's Ethereum address
- `f`: Fee in **tenths of a basis point** (10 = 1bp = 0.01%)
- The user must first approve the builder fee via the `approveBuilderFee` action.
- Builder requirements: at least 100 USDC account value. Earn up to 0.1% on perps, 1% on spot.

See section 13 for the `approveBuilderFee` action.

---

## 6. Order Responses

### Resting Order (placed on book)

```json
{
  "status": "ok",
  "response": {
    "type": "order",
    "data": {
      "statuses": [
        {"resting": {"oid": 77738308}}
      ]
    }
  }
}
```

### Filled Order

```json
{
  "status": "ok",
  "response": {
    "type": "order",
    "data": {
      "statuses": [
        {
          "filled": {
            "totalSz": "0.02",
            "avgPx": "1891.4",
            "oid": 77747314
          }
        }
      ]
    }
  }
}
```

### Error Response

```json
{
  "status": "ok",
  "response": {
    "type": "order",
    "data": {
      "statuses": [
        {"error": "Order must have minimum value of $10."}
      ]
    }
  }
}
```

### Handling Batch Responses

When submitting multiple orders in a batch, the `statuses` array contains one entry per order in the same order as submitted. However, a single pre-validation error may be returned for the entire batch. Always handle both per-order and batch-level errors:

```python
result = exchange.bulk_orders([order1, order2, order3])
statuses = result["response"]["data"]["statuses"]
for i, status in enumerate(statuses):
    if "error" in status:
        print(f"Order {i} failed: {status['error']}")
    elif "resting" in status:
        print(f"Order {i} resting: OID {status['resting']['oid']}")
    elif "filled" in status:
        print(f"Order {i} filled: {status['filled']['totalSz']} @ {status['filled']['avgPx']}")
```

---

## 7. Order Cancellation

### Cancel by OID

Action type: `"cancel"`

```json
{
  "type": "cancel",
  "cancels": [
    {"a": 0, "o": 77738308}
  ]
}
```

- `a`: Asset index
- `o`: Order ID (from the resting/filled response)
- Can cancel multiple orders in one action by adding to the `cancels` array.

### Cancel by Client Order ID (CLOID)

Action type: `"cancelByCloid"`

```json
{
  "type": "cancelByCloid",
  "cancels": [
    {"asset": 0, "cloid": "0x1234567890abcdef1234567890abcdef"}
  ]
}
```

### Dead Man's Switch (Schedule Cancel)

Action type: `"scheduleCancel"`

```json
{
  "type": "scheduleCancel",
  "time": 1734567900000
}
```

| Rule | Detail |
|------|--------|
| Behavior | Cancels **all** open orders at the specified time |
| Minimum delay | Must be at least **5 seconds** in the future |
| Daily limit | Max **10 triggers per day** (resets at 00:00 UTC) |
| Remove | Omit the `time` field to remove a scheduled cancel |

```python
import time

# Set dead man's switch for 30 seconds from now
future_time = int(time.time() * 1000) + 30000
exchange.schedule_cancel(future_time)

# Remove the scheduled cancel
exchange.schedule_cancel(None)
```

### Cancel All Open Orders Pattern

```python
# Cancel all open orders across all assets
open_orders = info.open_orders(address)
for order in open_orders:
    exchange.cancel(order["coin"], order["oid"])

# Or batch cancel
cancels = [{"coin": o["coin"], "oid": o["oid"]} for o in open_orders]
exchange.bulk_cancel(cancels)
```

---

## 8. Order Modification

### Single Modify

Action type: `"modify"`

```json
{
  "type": "modify",
  "oid": 77738308,
  "order": {
    "a": 0,
    "b": true,
    "p": "51000",
    "s": "0.02",
    "r": false,
    "t": {"limit": {"tif": "Gtc"}}
  }
}
```

The `order` object uses the same fields as order placement (`a`, `b`, `p`, `s`, `r`, `t`). The `oid` identifies which existing order to modify.

### Batch Modify

Action type: `"batchModify"`

```json
{
  "type": "batchModify",
  "modifies": [
    {
      "oid": 77738308,
      "order": {
        "a": 0, "b": true, "p": "51000", "s": "0.02",
        "r": false, "t": {"limit": {"tif": "Gtc"}}
      }
    },
    {
      "oid": 77738309,
      "order": {
        "a": 1, "b": false, "p": "3200", "s": "0.5",
        "r": false, "t": {"limit": {"tif": "Gtc"}}
      }
    }
  ]
}
```

```python
# Python SDK
exchange.modify_order(oid, "ETH", True, 0.2, 3100, {"limit": {"tif": "Gtc"}})

# Batch modify
exchange.bulk_modify_orders([
    {"oid": 123, "order": {"coin": "ETH", "is_buy": True, "sz": 0.1, "limit_px": 3100, "order_type": {"limit": {"tif": "Gtc"}}, "reduce_only": False}},
    {"oid": 456, "order": {"coin": "BTC", "is_buy": False, "sz": 0.01, "limit_px": 96000, "order_type": {"limit": {"tif": "Gtc"}}, "reduce_only": False}},
])
```

---

## 9. Position and Leverage Management

### Update Leverage

Action type: `"updateLeverage"`

```json
{
  "type": "updateLeverage",
  "asset": 0,
  "isCross": true,
  "leverage": 10
}
```

- `asset`: Numeric asset index
- `isCross`: `true` for cross-margin, `false` for isolated-margin
- `leverage`: Leverage multiplier (up to the asset's `maxLeverage` from `meta`)

```python
# Python SDK
exchange.update_leverage(10, "ETH", is_cross=True)    # Cross 10x
exchange.update_leverage(5, "BTC", is_cross=False)     # Isolated 5x
```

```typescript
// TypeScript SDK
await exchange.updateLeverage({ asset: 0, isCross: true, leverage: 5 });
```

### Update Isolated Margin

Action type: `"updateIsolatedMargin"`

```json
{
  "type": "updateIsolatedMargin",
  "asset": 0,
  "isBuy": true,
  "ntli": 1000000
}
```

- `ntli`: Margin amount in **6 decimals** (1000000 = 1 USDC). Use a negative value to remove margin.
- `isBuy`: Direction of the position to adjust margin for.

```python
# Add 100 USDC margin to ETH long position
exchange.update_isolated_margin(100.0, "ETH")

# Remove 50 USDC margin (use negative)
exchange.update_isolated_margin(-50.0, "ETH")
```

---

## 10. Close Position Pattern

There is no dedicated "close position" action. Close positions by placing a reduce-only IOC order in the opposite direction:

```json
{
  "type": "order",
  "orders": [
    {
      "a": 0,
      "b": false,
      "p": "0.01",
      "s": "0.01",
      "r": true,
      "t": {"limit": {"tif": "Ioc"}}
    }
  ],
  "grouping": "na"
}
```

- Set `r: true` (reduce-only) to ensure the order cannot open a new position.
- Set an aggressive price (very low for sells, very high for buys) to guarantee execution.
- Set `s` to the full position size for a complete close, or a partial size for partial close.

### SDK Helpers

```python
# Close full position
exchange.market_close("ETH")

# Close partial position
exchange.market_close("ETH", sz=0.01)

# Manual close pattern
state = info.user_state(address)
for pos in state["assetPositions"]:
    p = pos["position"]
    sz = abs(float(p["szi"]))
    if sz > 0:
        is_long = float(p["szi"]) > 0
        exchange.order(
            p["coin"],
            not is_long,    # Opposite direction
            sz,             # Full size
            None,           # Market price (SDK handles)
            {"limit": {"tif": "Ioc"}},
            reduce_only=True
        )
```

---

## 11. TWAP Orders

TWAP (Time-Weighted Average Price) orders split a large order into smaller suborders executed over a specified duration.

### Place TWAP Order

Action type: `"twapOrder"`

```json
{
  "type": "twapOrder",
  "twap": {
    "a": 0,
    "b": true,
    "s": "10.0",
    "r": false,
    "m": 30,
    "t": true
  }
}
```

| Field | Description |
|-------|-------------|
| `a` | Asset index |
| `b` | Is buy |
| `s` | Total size |
| `r` | Reduce only |
| `m` | Duration in **minutes** |
| `t` | Randomize suborder timing |

### TWAP Execution Mechanics

- Suborders execute every **30 seconds**
- Maximum **3% slippage** per suborder
- If execution falls behind target, catch-up suborders up to **3x normal size**
- Randomized timing (`t: true`) adds jitter to reduce predictability

### Cancel TWAP Order

Action type: `"twapCancel"`

```json
{
  "type": "twapCancel",
  "a": 0,
  "t": 77738308
}
```

- `a`: Asset index
- `t`: TWAP order ID

---

## 12. Transfers and Withdrawals

All transfer actions are **user-signed** (direct EIP-712, not phantom agent). They include `hyperliquidChain` and `signatureChainId` fields. See [authentication-and-signing.md](authentication-and-signing.md) for signing details.

### Transfer Actions Table

| Action | Type | Key Fields | Notes |
|--------|------|------------|-------|
| USDC to user | `usdSend` | `destination`, `amount`, `time` | Internal transfer |
| Spot token to user | `spotSend` | `destination`, `token`, `amount`, `time` | Any spot token |
| Spot to/from Perp wallet | `usdClassTransfer` | `amount`, `toPerp` (bool) | Move USDC between wallets |
| Withdraw to Arbitrum | `withdraw3` | `destination`, `amount`, `time` | $1 fee, ~5 min settlement |
| Generalized transfer | `sendAsset` | `destination`, `sourceDex`, `destinationDex`, `token`, `amount` | Cross-DEX transfers |
| Vault deposit/withdraw | `vaultTransfer` | `vaultAddress`, `isDeposit`, `usd` (6 decimals) | L1 action (phantom agent) |

### Examples

```python
# USDC transfer to another user
exchange.usd_transfer(100.0, "0xRecipientAddress")

# Spot token transfer
exchange.spot_transfer(0.1, "0xRecipientAddress", "PURR:0xTokenAddress")

# Move USDC from spot wallet to perp wallet
exchange.usd_class_transfer(100.0, to_perp=True)

# Move USDC from perp wallet to spot wallet
exchange.usd_class_transfer(50.0, to_perp=False)

# Withdraw USDC to Arbitrum ($1 fee, ~5 min)
exchange.withdraw_from_bridge(100.0, "0xArbitrumAddress")

# Vault operations
exchange.vault_transfer("0xVaultAddress", is_deposit=True, amount=1000.0)
exchange.vault_transfer("0xVaultAddress", is_deposit=False, amount=500.0)
```

### Raw JSON for USDC Transfer

```json
{
  "action": {
    "type": "usdSend",
    "hyperliquidChain": "Mainnet",
    "signatureChainId": "0xa4b1",
    "destination": "0xRecipientAddress",
    "amount": "100",
    "time": 1734567890123
  },
  "nonce": 1734567890123,
  "signature": {"r": "0x...", "s": "0x...", "v": 27}
}
```

**Note**: `vaultTransfer` is the exception among transfer-like actions -- it uses L1 action signing (phantom agent), not user-signed.

---

## 13. Account Management Actions

All account management actions are **user-signed** unless otherwise noted.

### Account Management Table

| Action | Type | Purpose | Key Fields |
|--------|------|---------|------------|
| Approve API wallet | `approveAgent` | Create/register agent wallet | `agentAddress`, `agentName` (optional) |
| Approve builder fee | `approveBuilderFee` | Set max fee rate for builder | `builderAddress`, `maxFeeRate` |
| Create sub-account | `createSubAccount` | New sub-account under master | `name` |
| Set referrer | `setReferrer` | Set referral code | `code` |
| Stake HYPE | `cDeposit` / `tokenDelegate` | Deposit/delegate to validator | `amount`, `validator` |
| Unstake HYPE | `cWithdraw` | 7-day unstaking queue | `amount` |
| No-op | `noop` | Invalidate nonce (no action) | (none) -- **L1 action** |
| Reserve rate limit | `reserveRequestWeight` | Pay 0.0005 USDC per request | `weight` -- **L1 action** |

### Approve Agent (Create API Wallet)

```python
# Python SDK -- creates and returns the agent key
response, agent_key = exchange.approve_agent("my_trading_bot")
print(f"Agent private key: {agent_key}")
# Store agent_key securely; it cannot be retrieved later
```

See [authentication-and-signing.md](authentication-and-signing.md) for full API wallet management details.

### Approve Builder Fee

```python
# Allow builder to charge up to 0.001% on orders they facilitate
exchange.approve_builder_fee("0xBuilderAddress", "0.001%")
```

### Create Subaccount

```python
# Create a new subaccount
exchange.create_sub_account("Strategy1")

# List subaccounts
sub_accounts = info.sub_accounts("0xMasterAddress")
```

### Set Referrer

```python
exchange.set_referrer("REFCODE")
```

### Reserve Rate Limit Capacity

```json
{
  "type": "reserveRequestWeight",
  "weight": 1000
}
```

Cost: **0.0005 USDC per request**. This is an L1 action (phantom agent signing). Use this when you need burst capacity beyond the standard rate limit.

---

## 14. Complete Action Type Taxonomy

### L1 Actions (Phantom Agent Signing, Chain ID 1337)

Signable by master wallet or API wallet.

```
order, cancel, cancelByCloid, modify, batchModify,
scheduleCancel, updateLeverage, updateIsolatedMargin,
topUpIsolatedOnlyMargin, vaultTransfer, twapOrder,
twapCancel, noop, reserveRequestWeight
```

### User-Signed Actions (Direct EIP-712, Chain ID 42161 mainnet / 421614 testnet)

Must be signed by master wallet only. API wallets cannot sign these.

```
usdSend, spotSend, usdClassTransfer, withdraw3,
approveAgent, approveBuilderFee, tokenDelegate,
cDeposit, cWithdraw, sendAsset, sendToEvmWithData,
setReferrer, createSubAccount
```

See [authentication-and-signing.md](authentication-and-signing.md) for the signing mechanics of each category.

---

## 15. Batch Operations and Error Handling

### Batch Order Placement

Submit multiple orders in a single action:

```json
{
  "type": "order",
  "orders": [
    {"a": 0, "b": true, "p": "50000", "s": "0.01", "r": false, "t": {"limit": {"tif": "Gtc"}}},
    {"a": 1, "b": true, "p": "2800", "s": "0.1", "r": false, "t": {"limit": {"tif": "Gtc"}}},
    {"a": 1, "b": false, "p": "3200", "s": "0.1", "r": true, "t": {"trigger": {"triggerPx": "3100", "isMarket": true, "tpsl": "tp"}}}
  ],
  "grouping": "na"
}
```

### Batch Cancel

```json
{
  "type": "cancel",
  "cancels": [
    {"a": 0, "o": 77738308},
    {"a": 1, "o": 77738309},
    {"a": 1, "o": 77738310}
  ]
}
```

### Error Handling Patterns

```python
# Per-order error handling
result = exchange.bulk_orders(orders)
if result.get("status") != "ok":
    print(f"Batch-level error: {result}")
else:
    statuses = result["response"]["data"]["statuses"]
    for i, status in enumerate(statuses):
        if "error" in status:
            print(f"Order {i} error: {status['error']}")
        elif "resting" in status:
            oid = status["resting"]["oid"]
            print(f"Order {i} resting: {oid}")
        elif "filled" in status:
            filled = status["filled"]
            print(f"Order {i} filled: {filled['totalSz']} @ {filled['avgPx']}")
```

### Common Error Messages

| Error | Meaning | Fix |
|-------|---------|-----|
| `"Order must have minimum value of $10."` | Below minimum notional | Increase size * price |
| `"Insufficient margin"` | Not enough collateral | Deposit more USDC or reduce leverage |
| `"ReduceOnly"` | Reduce-only would increase position | Verify order direction matches position |
| `"BadAloPx"` | Post-only would cross spread | Use a more passive price |
| `"IocCancel"` | IOC could not match | Expected for tight-slippage market orders |
| `"PerpMaxPosition"` | Exceeds margin tier limit | Reduce size or leverage |
| `"PositionIncreaseAtOpenInterestCap"` | OI cap reached for this asset | Wait for OI to decrease |
| `"Oracle"` | Price too far from oracle | Adjust price closer to mark/oracle |
| `"Tick"` | Price not divisible by tick size | Round to proper tick increment |
| `"MissingOrder"` | Order already filled or canceled | Query order status before modifying |

---

## 16. SDK Method Reference

### Python SDK (`hyperliquid-python-sdk`)

```python
# Orders
exchange.order(coin, is_buy, sz, limit_px, order_type, cloid=None, reduce_only=False)
exchange.market_open(coin, is_buy, sz, slippage=0.01)
exchange.market_close(coin, sz=None)
exchange.bulk_orders([{coin, is_buy, sz, limit_px, order_type, reduce_only}])

# Modify/Cancel
exchange.cancel(coin, oid)
exchange.cancel_by_cloid(coin, cloid)
exchange.bulk_cancel([{coin, oid}])
exchange.modify_order(oid, coin, is_buy, sz, limit_px, order_type)
exchange.bulk_modify_orders([{oid, order}])
exchange.schedule_cancel(future_time_ms)

# Position management
exchange.update_leverage(leverage, coin, is_cross=True)
exchange.update_isolated_margin(amount, coin)

# Transfers (user-signed, requires master wallet)
exchange.usd_transfer(amount, destination)
exchange.spot_transfer(amount, destination, token)
exchange.usd_class_transfer(amount, to_perp=True)
exchange.withdraw_from_bridge(amount, destination)
exchange.vault_transfer(vault_address, is_deposit, amount)

# Account management (user-signed)
exchange.approve_agent(name)            # Returns (response, agent_key)
exchange.approve_builder_fee(address, max_fee)
exchange.set_referrer(code)
exchange.create_sub_account(name)
```

### TypeScript SDK (`@nktkas/hyperliquid`)

```typescript
// Orders
await exchange.order({ orders: [...], grouping: "na" });
await exchange.cancel({ cancels: [{ a: 0, o: 12345 }] });
await exchange.cancelByCloid({ cancels: [{ asset: 0, cloid: "0x..." }] });
await exchange.modify({ oid: 12345, order: { a: 0, b: true, p: "50000", s: "0.01", r: false, t: { limit: { tif: "Gtc" } } } });
await exchange.batchModify({ modifies: [...] });
await exchange.scheduleCancel({ time: futureTimeMs });

// Position management
await exchange.updateLeverage({ asset: 0, isCross: true, leverage: 10 });
await exchange.updateIsolatedMargin({ asset: 0, isBuy: true, ntli: 1000000 });

// TWAP
await exchange.twapOrder({ twap: { a: 0, b: true, s: "10", r: false, m: 30, t: true } });
await exchange.twapCancel({ a: 0, t: 12345 });
```

---

**Cross-references:**
- [authentication-and-signing.md](authentication-and-signing.md) -- Signing mechanics for L1 vs user-signed actions
- [connection-and-endpoints.md](connection-and-endpoints.md) -- Base URLs, asset indexing, testnet configuration
- [info-queries.md](info-queries.md) -- Querying order status, positions, fills, and market data
