# Risk Management and Error Handling

## Table of Contents

1. [Complete Error Codes Reference](#1-complete-error-codes-reference)
2. [Critical Gotcha 1: Agent Wallet Address Confusion](#2-critical-gotcha-1-agent-wallet-address-confusion)
3. [Critical Gotcha 2: Trailing Zeros](#3-critical-gotcha-2-trailing-zeros)
4. [Critical Gotcha 3: Chain ID Confusion](#4-critical-gotcha-3-chain-id-confusion)
5. [Critical Gotcha 4: Nonce Conflicts](#5-critical-gotcha-4-nonce-conflicts)
6. [Critical Gotcha 5: Asset Remapping](#6-critical-gotcha-5-asset-remapping)
7. [Critical Gotcha 6: Batch Error Handling](#7-critical-gotcha-6-batch-error-handling)
8. [Critical Gotcha 7: Minimum Order Value](#8-critical-gotcha-7-minimum-order-value)
9. [Critical Gotcha 8: WebSocket Disconnects](#9-critical-gotcha-8-websocket-disconnects)
10. [Critical Gotcha 9: Testnet Behavior](#10-critical-gotcha-9-testnet-behavior)
11. [Critical Gotcha 10: msgpack Field Ordering](#11-critical-gotcha-10-msgpack-field-ordering)
12. [Emergency Shutdown Procedure](#12-emergency-shutdown-procedure)
13. [Liquidation Price Monitoring](#13-liquidation-price-monitoring)
14. [Best Practices for Production Trading](#14-best-practices-for-production-trading)

---

## 1. Complete Error Codes Reference

Every exchange action response includes a `statuses` array. Each element is either a success (`resting`, `filled`) or an `error` string. Below is the complete table of known error codes, what triggers them, and how to fix each one.

| Error String | Meaning | Fix |
|---|---|---|
| `"Order must have minimum value of $10."` | The notional value (size x price) is below the $10 minimum for perpetuals, or below 10 quote tokens for spot markets. | Increase size or price so that `size * price >= $10`. For spot, ensure notional >= 10 quote tokens. |
| `"User or API Wallet 0x... does not exist."` | The signature was recovered to an address that is not registered as a user or API wallet. This typically means the signing key, chain ID, or serialization is wrong. | Verify: (1) correct private key, (2) correct chainId (1337 for L1 actions, 42161 for user-signed), (3) correct msgpack serialization order. See `authentication-and-signing.md` for details. |
| `"Insufficient margin"` | The account does not have enough free collateral (USDC) to cover the margin required for the new order or position. | Deposit more USDC, reduce existing positions, lower leverage, or reduce the order size. Check `clearinghouseState.withdrawable` for available margin. |
| `"ReduceOnly"` | A reduce-only order would increase the position instead of reducing it. This happens when the order direction does not match the existing position direction. | Verify the position direction first via `clearinghouseState`. A reduce-only sell requires a long position; a reduce-only buy requires a short position. If the position was already closed, remove the reduce-only order. |
| `"BadAloPx"` | An ALO (Add Liquidity Only / post-only) order would immediately match against the resting book, violating the post-only constraint. | Use a more passive price. For a buy ALO, the price must be below the best ask. For a sell ALO, the price must be above the best bid. Query `l2Book` or `allMids` to determine the current spread. |
| `"IocCancel"` | An IOC (Immediate Or Cancel) order could not be filled (partially or fully) at the specified price. The unfilled portion is automatically canceled. | This is expected behavior for IOC orders. If simulating a market order, widen the slippage (use a more aggressive price, e.g., 3-5% from mid). |
| `"PerpMaxPosition"` | The order would cause the position to exceed the maximum allowed size for the current margin tier. Higher notional positions require lower leverage. | Reduce the order size or reduce leverage. Check the `meta` response for `maxLeverage` at your position's tier. See the margin tables in `info-queries.md`. |
| `"PositionIncreaseAtOpenInterestCap"` | The total open interest for this asset has reached the protocol-wide cap. No new position-increasing orders are accepted until OI decreases. | Wait for other traders to close positions, or check `perpsAtOpenInterestCap` info query to monitor which assets are at cap. You can still place reduce-only orders. |
| `"Oracle"` | The order price is too far from the current oracle price. This is a safety check to prevent obviously erroneous orders. | Adjust the price closer to the current mark price. Query `metaAndAssetCtxs` for the current `oraclePx` and `markPx`. |
| `"Tick"` | The price is not divisible by the asset's tick size. Each asset has a specific minimum price increment. | Round the price to the correct tick size. The tick size can be derived from the `szDecimals` field in the `meta` response or from `nSigFigs` in the `l2Book` request. |
| `"MissingOrder"` | The order referenced by OID or CLOID does not exist. It was already filled, canceled, or never placed. | Query `orderStatus` to check the order's current state before attempting to cancel or modify. Track order lifecycle via `orderUpdates` WebSocket channel. |

### Response structure for errors

A successful API call still returns `"status": "ok"` even if individual orders fail. Always inspect the `statuses` array:

```json
{
  "status": "ok",
  "response": {
    "type": "order",
    "data": {
      "statuses": [
        {"resting": {"oid": 77738308}},
        {"error": "Order must have minimum value of $10."},
        {"filled": {"totalSz": "0.02", "avgPx": "1891.4", "oid": 77747314}}
      ]
    }
  }
}
```

A batch-level pre-validation failure returns a single error string instead of the `statuses` array. See Gotcha 6 below.

> **Cross-reference:** For the complete list of exchange action types and their response formats, see `exchange-actions.md`.

---

## 2. Critical Gotcha 1: Agent Wallet Address Confusion

Agent wallets (API wallets) are **stateless signers** -- they hold no funds, no positions, and no order history. All state belongs to the **master account** (or sub-account) that created the agent wallet.

When querying info endpoints, you must always use the master/sub-account address, never the agent wallet address.

```python
# Setup: agent_wallet signs, but master_address owns everything
agent_wallet = eth_account.Account.from_key("0xAGENT_PRIVATE_KEY")
exchange = Exchange(agent_wallet, constants.MAINNET_API_URL,
                    account_address="0xMASTER_ADDRESS")
```

Querying with the wrong address:

```python
# WRONG -- returns empty state, no positions, no orders
state = info.user_state("0xAGENT_WALLET_ADDRESS")
orders = info.open_orders("0xAGENT_WALLET_ADDRESS")

# CORRECT -- returns actual positions, orders, and balances
state = info.user_state("0xMASTER_ADDRESS")
orders = info.open_orders("0xMASTER_ADDRESS")
```

This applies to every info query that takes a `user` parameter: `clearinghouseState`, `openOrders`, `userFills`, `userFunding`, `spotClearinghouseState`, and all WebSocket user subscriptions.

You can verify which role an address has with `userRole`:

```python
role = info.user_role("0x...")
# Returns {"role": "user"|"agent"|"vault"|"subAccount"|"missing"}
```

> **Cross-reference:** See `authentication-and-signing.md` for API wallet creation and limits (1 unnamed + 3 named per account).

---

## 3. Critical Gotcha 2: Trailing Zeros

Price and size fields in exchange actions are strings that must have **no trailing zeros**. The signing process serializes these strings exactly, and trailing zeros produce a different hash, causing signature verification to fail silently or the order to be rejected.

```python
# WRONG -- trailing zeros cause signature mismatch or rejection
order = {"a": 0, "b": True, "p": "50000.0", "s": "0.010", ...}

# CORRECT -- no trailing zeros
order = {"a": 0, "b": True, "p": "50000", "s": "0.01", ...}
```

More examples:

```python
# WRONG                    # CORRECT
"1890.50"                  "1890.5"
"100.00"                   "100"
"0.0100"                   "0.01"
"3000.0"                   "3000"
```

A reliable formatting function:

```python
def format_price(value: float) -> str:
    """Format a number as a string with no trailing zeros."""
    formatted = f"{value:.10f}"  # Enough decimal places
    if '.' in formatted:
        formatted = formatted.rstrip('0').rstrip('.')
    return formatted

# format_price(50000.0)  -> "50000"
# format_price(0.010)    -> "0.01"
# format_price(1890.50)  -> "1890.5"
```

The official Python SDK handles this automatically via `float_to_wire` internally. If you are constructing raw JSON payloads (e.g., in Rust, Go, or manual HTTP calls), you must handle this yourself.

> **Cross-reference:** See `exchange-actions.md` for the complete order field schema.

---

## 4. Critical Gotcha 3: Chain ID Confusion

Hyperliquid uses **two distinct EIP-712 signing mechanisms** with different chain IDs. Mixing them produces invalid signatures that result in `"User or API Wallet 0x... does not exist."`.

| Action Category | Chain ID | Domain Name | Examples |
|---|---|---|---|
| L1 Actions (phantom agent) | **1337** | `"Exchange"` | order, cancel, modify, batchModify, scheduleCancel, updateLeverage, updateIsolatedMargin, twapOrder, twapCancel, noop |
| User-Signed Actions (direct EIP-712) | **42161** (mainnet) / **421614** (testnet) | `"HyperliquidSignTransaction"` | usdSend, spotSend, withdraw3, approveAgent, approveBuilderFee, createSubAccount, tokenDelegate |

```python
# WRONG -- using user-signed chainId for a trading action
# This will recover to the wrong address and be rejected
domain = {"chainId": 42161}  # Wrong for order placement
action = {"type": "order", ...}

# CORRECT -- L1 actions use chainId 1337
domain = {"chainId": 1337}
action = {"type": "order", ...}

# CORRECT -- transfers use chainId 42161 (mainnet)
domain = {"chainId": 42161}
action = {"type": "usdSend", ...}
```

The SDKs handle this automatically. This gotcha only applies when constructing raw signing payloads manually.

> **Cross-reference:** See `authentication-and-signing.md` for the complete EIP-712 domain specifications and phantom agent construction.

---

## 5. Critical Gotcha 4: Nonce Conflicts

Nonces are tracked **per signer** (per private key), not per account. The system stores the **100 highest nonces** seen for each signer. A new nonce must be:

1. Greater than the smallest stored nonce
2. Never used before
3. Within `(T - 2 days, T + 1 day)` of the block timestamp

If two processes share the same API wallet, they can easily produce duplicate or out-of-order nonces:

```python
# WRONG -- two processes sharing one API wallet
# Process A: nonce = 1734567890123 (sent at T=0)
# Process B: nonce = 1734567890123 (sent at T=0.001) -- COLLISION!

# CORRECT -- separate API wallet per process
# Process A uses agent_wallet_1 (private_key_1)
# Process B uses agent_wallet_2 (private_key_2)
```

This also applies to sub-accounts: if multiple sub-accounts share the same API wallet, their nonces collide. Each sub-account should have its own dedicated API wallet.

**Recommended nonce strategy for a single process:**

```python
import time
import threading

class NonceManager:
    """Thread-safe nonce generator using atomic counter."""
    def __init__(self):
        self._lock = threading.Lock()
        self._last_nonce = 0

    def next(self) -> int:
        with self._lock:
            candidate = int(time.time() * 1000)
            if candidate <= self._last_nonce:
                candidate = self._last_nonce + 1
            self._last_nonce = candidate
            return candidate
```

> **Cross-reference:** See `authentication-and-signing.md` for nonce storage rules and the `noop` action for nonce invalidation.

---

## 6. Critical Gotcha 5: Asset Remapping

Some assets have different names on the Hyperliquid UI versus the HyperCore API. The most notable example:

| UI Name | HyperCore Name | Notes |
|---|---|---|
| BTC/USDC | UBTC/USDC | On mainnet spot |

```python
# WRONG -- using the UI name directly for API calls
info.l2_snapshot("BTC/USDC")  # Might not match the actual asset

# CORRECT -- always verify asset names from the meta response
meta = info.meta()
for asset in meta["universe"]:
    print(f"Index {meta['universe'].index(asset)}: {asset['name']}")

spot_meta = info.spot_meta()
for token in spot_meta["universe"]:
    print(f"Spot: {token}")
```

For perpetuals, use the symbol name from the `meta.universe` array. For spot, use `"PURR/USDC"` for PURR or `"@{index}"` for other tokens. For HIP-3 perps, use the format `"dex_name:ASSET_NAME"`.

> **Cross-reference:** See `connection-and-endpoints.md` for the complete asset indexing scheme across perps, spot, and HIP-3.

---

## 7. Critical Gotcha 6: Batch Error Handling

When submitting batch orders, errors can occur at two levels:

1. **Batch-level pre-validation error** -- a single error string for the entire batch
2. **Per-order errors** -- individual errors in the `statuses` array

```python
# WRONG -- only checking per-order statuses
result = exchange.bulk_orders(order_list)
for status in result["response"]["data"]["statuses"]:
    if "error" in status:
        handle_error(status["error"])
# This misses batch-level errors!

# CORRECT -- check both levels
result = exchange.bulk_orders(order_list)

# Check for batch-level error first
if result.get("status") != "ok":
    handle_batch_error(result)
    return

response_data = result.get("response", {}).get("data", {})

# A batch-level pre-validation error may replace the statuses array
if isinstance(response_data, str):
    handle_batch_error(response_data)
    return

# Then check individual order statuses
statuses = response_data.get("statuses", [])
for i, status in enumerate(statuses):
    if "error" in status:
        print(f"Order {i} failed: {status['error']}")
    elif "resting" in status:
        print(f"Order {i} resting: OID {status['resting']['oid']}")
    elif "filled" in status:
        print(f"Order {i} filled: {status['filled']['totalSz']} @ {status['filled']['avgPx']}")
```

A batch-level pre-validation failure example: if the entire batch has an invalid signature, you get one error for all orders, not individual per-order errors.

> **Cross-reference:** See `exchange-actions.md` for batch order, batch modify, and batch cancel response formats.

---

## 8. Critical Gotcha 7: Minimum Order Value

Hyperliquid enforces minimum notional values for orders:

| Market Type | Minimum Notional |
|---|---|
| Perpetuals | **$10** (size x price >= $10) |
| Spot | **10 quote tokens** (typically 10 USDC) |

```python
# WRONG -- $5 notional order
exchange.order("ETH", True, 0.001, 2800.0, {"limit": {"tif": "Gtc"}})
# 0.001 * 2800 = $2.80 -> "Order must have minimum value of $10."

# CORRECT -- meets $10 minimum
exchange.order("ETH", True, 0.004, 2800.0, {"limit": {"tif": "Gtc"}})
# 0.004 * 2800 = $11.20 -> accepted
```

When building grid trading or dollar-cost-averaging strategies with many small orders, verify each order meets the minimum before submission. Calculate: `notional = float(size) * float(price)`.

For market orders (IOC with slippage), the minimum still applies based on the limit price you set, not the execution price.

> **Cross-reference:** See `exchange-actions.md` for the order placement schema and `rate-limits.md` for open order limits.

---

## 9. Critical Gotcha 8: WebSocket Disconnects

Hyperliquid WebSocket connections close after **60 seconds** of inactivity. Additionally, the server may disconnect at any time without sending a close frame. Your bot must handle this gracefully.

```python
# WRONG -- no reconnection logic, no heartbeat
ws = await websockets.connect("wss://api.hyperliquid.xyz/ws")
while True:
    data = await ws.recv()  # Hangs or crashes on disconnect
    process(data)

# CORRECT -- heartbeat + exponential backoff + state reconciliation
import asyncio, json, websockets

async def run_websocket():
    delay = 1
    while True:
        try:
            async with websockets.connect("wss://api.hyperliquid.xyz/ws") as ws:
                delay = 1  # Reset backoff on successful connect

                # Re-subscribe to all channels
                await ws.send(json.dumps({
                    "method": "subscribe",
                    "subscription": {"type": "l2Book", "coin": "ETH"}
                }))
                await ws.send(json.dumps({
                    "method": "subscribe",
                    "subscription": {"type": "orderUpdates", "user": "0x..."}
                }))

                # Reconcile state from REST after reconnect
                await reconcile_state_from_rest()

                # Main loop with heartbeat
                last_ping = asyncio.get_event_loop().time()
                while True:
                    now = asyncio.get_event_loop().time()
                    if now - last_ping > 50:  # Ping every 50 seconds
                        await ws.send(json.dumps({"method": "ping"}))
                        last_ping = now

                    try:
                        msg = await asyncio.wait_for(ws.recv(), timeout=10)
                        data = json.loads(msg)
                        if data.get("channel") != "pong":
                            process_message(data)
                    except asyncio.TimeoutError:
                        continue  # No data, loop back for heartbeat check

        except (websockets.exceptions.ConnectionClosed, Exception) as e:
            print(f"WebSocket disconnected: {e}. Reconnecting in {delay}s...")
            await asyncio.sleep(delay)
            delay = min(delay * 2, 60)  # Exponential backoff, max 60s
```

When you reconnect, the first message on a resubscribed channel is a **snapshot** (indicated by `isSnapshot: true` for `userFills`). Use this plus a REST query to reconcile any fills or state changes missed during the disconnect.

> **Cross-reference:** See `websocket-channels.md` for all 19 subscription channels, keepalive protocol, and reconnection strategy.

---

## 10. Critical Gotcha 9: Testnet Behavior

Testnet is useful for validating technical flows (signing, order lifecycle, WebSocket subscriptions) but **not** for performance testing or realistic market simulation. Key differences:

```python
# WRONG -- using mainnet phantom agent source on testnet
phantom_agent = {"source": "a", "connectionId": hash}  # "a" = mainnet

# CORRECT -- testnet uses "b" as source and "Testnet" as chain label
phantom_agent = {"source": "b", "connectionId": hash}  # "b" = testnet

# WRONG -- using mainnet chainId for user-signed actions on testnet
domain = {"chainId": 42161}  # Mainnet Arbitrum chainId

# CORRECT -- testnet uses 421614 for user-signed actions
domain = {"chainId": 421614}  # Testnet Arbitrum Sepolia chainId
```

| Property | Mainnet | Testnet |
|---|---|---|
| REST URL | `https://api.hyperliquid.xyz` | `https://api.hyperliquid-testnet.xyz` |
| WS URL | `wss://api.hyperliquid.xyz/ws` | `wss://api.hyperliquid-testnet.xyz/ws` |
| App URL | `app.hyperliquid.xyz` | `app.hyperliquid-testnet.xyz` |
| `hyperliquidChain` | `"Mainnet"` | `"Testnet"` |
| Phantom agent source | `"a"` | `"b"` |
| User-signed chainId | `42161` | `421614` |
| L1 chainId | `1337` | `1337` (same) |
| HyperEVM chainId | `999` | `998` |
| Faucet | N/A | `app.hyperliquid-testnet.xyz/drip` (1,000 mock USDC) |

Testnet markets have less liquidity, wider spreads, and may behave differently from mainnet. Use testnet to verify your signing code works, your WebSocket reconnection handles edge cases, and your order lifecycle logic is correct. Do not use testnet to benchmark latency or test market-making strategies.

> **Cross-reference:** See `connection-and-endpoints.md` for the full testnet development workflow.

---

## 11. Critical Gotcha 10: msgpack Field Ordering

For L1 action signing, the action payload is serialized using **msgpack**, and the byte output is hashed with keccak256. The hash depends on field ordering within the msgpack encoding. If you serialize fields in a different order than the protocol expects, you get a different hash, which produces a different `connectionId`, which causes the phantom agent signature to fail.

```python
# WRONG -- arbitrary field order
action = {
    "type": "order",
    "grouping": "na",
    "orders": [...]
}

# CORRECT -- field order must match protocol expectation
action = {
    "type": "order",
    "orders": [...],
    "grouping": "na"
}
```

Within each order:

```python
# WRONG -- fields in wrong order
order = {"b": True, "a": 0, "s": "0.01", "p": "50000", "r": False, "t": {...}}

# CORRECT -- fields in expected order
order = {"a": 0, "b": True, "p": "50000", "s": "0.01", "r": False, "t": {...}}
```

**The safest approach**: Use the official SDKs for signing. The Python SDK (`hyperliquid-python-sdk`) and TypeScript SDKs (`@nktkas/hyperliquid`) handle serialization order correctly. Only attempt manual msgpack serialization if you are building a custom SDK in another language (Rust, Go, C++), and reference the official SDK source code for the exact field ordering.

> **Cross-reference:** See `authentication-and-signing.md` for the complete phantom agent construction and signing flow.

---

## 12. Emergency Shutdown Procedure

An emergency shutdown should follow three steps in order: set the dead man's switch, cancel all open orders, then market-close all positions. This ensures safety even if the process crashes partway through.

```python
import time
import eth_account
from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants

def emergency_shutdown(
    private_key: str,
    account_address: str,
    testnet: bool = False,
) -> dict:
    """
    Execute a full emergency shutdown:
      1. Set dead man's switch (scheduleCancel) 10 seconds in the future
      2. Cancel all open orders
      3. Market-close all open positions

    Returns a summary dict with results from each step.
    """
    api_url = constants.TESTNET_API_URL if testnet else constants.MAINNET_API_URL
    wallet = eth_account.Account.from_key(private_key)
    info = Info(api_url, skip_ws=True)
    exchange = Exchange(wallet, api_url, account_address=account_address)

    results = {"schedule_cancel": None, "cancels": [], "closes": []}

    # Step 1: Dead man's switch -- cancels ALL orders at scheduled time
    # This is the safety net in case steps 2/3 fail or the process crashes
    try:
        future_time = int(time.time() * 1000) + 10_000  # 10 seconds from now
        sc_result = exchange.schedule_cancel(future_time)
        results["schedule_cancel"] = sc_result
        print(f"[EMERGENCY] scheduleCancel set for {future_time}")
    except Exception as e:
        print(f"[EMERGENCY] scheduleCancel failed: {e}")
        results["schedule_cancel"] = str(e)

    # Step 2: Cancel all open orders immediately
    try:
        open_orders = info.open_orders(account_address)
        print(f"[EMERGENCY] Canceling {len(open_orders)} open orders...")
        for order in open_orders:
            try:
                cancel_result = exchange.cancel(order["coin"], order["oid"])
                results["cancels"].append({
                    "coin": order["coin"],
                    "oid": order["oid"],
                    "result": "ok",
                })
            except Exception as e:
                results["cancels"].append({
                    "coin": order["coin"],
                    "oid": order["oid"],
                    "result": str(e),
                })
    except Exception as e:
        print(f"[EMERGENCY] Failed to fetch open orders: {e}")

    # Step 3: Market-close all positions
    try:
        user_state = info.user_state(account_address)
        positions = user_state.get("assetPositions", [])
        print(f"[EMERGENCY] Closing {len(positions)} positions...")
        for pos in positions:
            p = pos["position"]
            sz = float(p["szi"])
            if sz == 0:
                continue
            coin = p["coin"]
            try:
                close_result = exchange.market_close(coin)
                results["closes"].append({
                    "coin": coin,
                    "size": p["szi"],
                    "result": "ok",
                })
                print(f"[EMERGENCY] Closed {coin}: size={p['szi']}")
            except Exception as e:
                results["closes"].append({
                    "coin": coin,
                    "size": p["szi"],
                    "result": str(e),
                })
                print(f"[EMERGENCY] Failed to close {coin}: {e}")
    except Exception as e:
        print(f"[EMERGENCY] Failed to fetch positions: {e}")

    # Step 4: Remove the dead man's switch (optional -- only if everything succeeded)
    all_cancels_ok = all(c["result"] == "ok" for c in results["cancels"])
    all_closes_ok = all(c["result"] == "ok" for c in results["closes"])
    if all_cancels_ok and all_closes_ok:
        try:
            exchange.schedule_cancel()  # Omit time to remove scheduled cancel
            print("[EMERGENCY] Removed scheduleCancel (all actions succeeded)")
        except Exception:
            pass  # Dead man's switch will expire harmlessly

    print("[EMERGENCY] Shutdown complete.")
    return results
```

**Key notes on `scheduleCancel`:**

- Must be at least **5 seconds** in the future
- Maximum **10 triggers per day** (resets at 00:00 UTC)
- Cancels **all** open orders at the scheduled time
- Omit the `time` parameter to remove a scheduled cancel
- A stale `expiresAfter` on the request consumes **5x rate limit**

> **Cross-reference:** See `exchange-actions.md` for the `scheduleCancel` action format and `bot-architecture.md` for the RECOVER stage of bot design.

---

## 13. Liquidation Price Monitoring

The `clearinghouseState` response provides a `liquidationPx` for each position. Monitor this continuously against the current `markPx` to detect approaching liquidation.

```python
import time

def monitor_liquidation_risk(
    info,
    account_address: str,
    warning_threshold: float = 0.10,  # 10% proximity
    critical_threshold: float = 0.05,  # 5% proximity
    poll_interval: float = 5.0,
):
    """
    Continuously monitor positions for liquidation risk.

    Args:
        info: hyperliquid Info client
        account_address: master/sub-account address
        warning_threshold: distance ratio for warning (0.10 = 10%)
        critical_threshold: distance ratio for critical alert (0.05 = 5%)
        poll_interval: seconds between checks
    """
    while True:
        try:
            user_state = info.user_state(account_address)
            meta_and_ctxs = info.meta_and_asset_ctxs() if hasattr(info, 'meta_and_asset_ctxs') else None

            for pos in user_state.get("assetPositions", []):
                p = pos["position"]
                sz = float(p["szi"])
                if sz == 0:
                    continue

                coin = p["coin"]
                liq_px = float(p["liquidationPx"]) if p.get("liquidationPx") else None
                mark_px = float(p.get("markPx", 0)) if p.get("markPx") else None

                if liq_px is None or liq_px == 0 or mark_px is None or mark_px == 0:
                    continue

                # Calculate distance to liquidation
                if sz > 0:  # Long position: liquidation is below mark
                    distance_ratio = (mark_px - liq_px) / mark_px
                else:  # Short position: liquidation is above mark
                    distance_ratio = (liq_px - mark_px) / mark_px

                leverage = p.get("leverage", {})
                lev_value = leverage.get("value", "?")
                lev_type = leverage.get("type", "?")

                if distance_ratio < critical_threshold:
                    print(
                        f"[CRITICAL] {coin}: {distance_ratio:.1%} from liquidation | "
                        f"mark={mark_px} liq={liq_px} size={p['szi']} "
                        f"leverage={lev_value}x ({lev_type}) "
                        f"unrealizedPnl={p.get('unrealizedPnl', '?')}"
                    )
                elif distance_ratio < warning_threshold:
                    print(
                        f"[WARNING] {coin}: {distance_ratio:.1%} from liquidation | "
                        f"mark={mark_px} liq={liq_px} size={p['szi']}"
                    )

        except Exception as e:
            print(f"[MONITOR] Error: {e}")

        time.sleep(poll_interval)
```

**Important:** Funding payments use the **oracle price** for notional calculation, not the mark price. The `cumFunding` fields on each position track `allTime`, `sinceChange`, and `sinceOpen` funding payments. Large funding payments can erode margin and push you closer to liquidation even without price movement.

For real-time monitoring, subscribe to `clearinghouseState` via WebSocket instead of polling REST:

```python
info.subscribe(
    {"type": "clearinghouseState", "user": account_address},
    on_state_update
)
```

> **Cross-reference:** See `info-queries.md` for the full `clearinghouseState` response schema and `websocket-channels.md` for real-time account state streaming.

---

## 14. Best Practices for Production Trading

### Leverage management

- **Never exceed 10x leverage** -- this is community consensus. The platform supports up to 50x, but risk of liquidation increases exponentially with leverage.
- Use **cross margin** for portfolio-level risk management or **isolated margin** when you want to limit loss to a specific amount per position.
- Monitor margin usage: `clearinghouseState.marginSummary.totalMarginUsed` vs `accountValue`.

### Capital allocation

- Limit capital per strategy to **10-20%** of total account value.
- Keep at least **50%** of account value as free margin for adverse moves.
- Use sub-accounts to isolate strategy risk (up to 10 sub-accounts per master).

### Idempotent order tracking with CLOID

Use client order IDs (`cloid`) for every order. This enables tracking across WebSocket disconnects and process restarts:

```python
from hyperliquid.utils.types import Cloid
import uuid

def make_cloid() -> Cloid:
    """Generate a unique CLOID from UUID."""
    hex_str = uuid.uuid4().hex
    return Cloid.from_str("0x" + hex_str)

cloid = make_cloid()
exchange.order("ETH", True, 0.1, 2800.0, {"limit": {"tif": "Gtc"}}, cloid=cloid)

# Later: query or cancel by CLOID
status = info.query_order_by_cloid(account_address, cloid)
exchange.cancel_by_cloid("ETH", cloid)
```

### Nonce invalidation via noop

Instead of sending explicit cancel actions (which consume rate limits), you can invalidate a nonce by sending a `noop` action. This is useful for race conditions where you want to ensure a nonce cannot be reused:

```python
# The noop action consumes a nonce without performing any trading action
# Useful for: invalidating nonces, testing connectivity, rate limit savings
exchange.noop()  # If available in SDK, otherwise send raw:
# {"type": "noop"}
```

### ALO batching for priority

ALO (Add Liquidity Only / post-only) orders get **validator priority** when submitted in ALO-only batches. Do not mix ALO orders with IOC or GTC orders in the same batch:

```python
# WRONG -- mixing ALO with GTC in one batch
exchange.bulk_orders([
    {"coin": "ETH", "is_buy": True, "sz": 0.1, "limit_px": 2790,
     "order_type": {"limit": {"tif": "Alo"}}, "reduce_only": False},
    {"coin": "ETH", "is_buy": True, "sz": 0.1, "limit_px": 2800,
     "order_type": {"limit": {"tif": "Gtc"}}, "reduce_only": False},
])

# CORRECT -- separate batches: ALO orders get validator priority
exchange.bulk_orders([
    {"coin": "ETH", "is_buy": True, "sz": 0.1, "limit_px": 2790,
     "order_type": {"limit": {"tif": "Alo"}}, "reduce_only": False},
    {"coin": "ETH", "is_buy": False, "sz": 0.1, "limit_px": 2810,
     "order_type": {"limit": {"tif": "Alo"}}, "reduce_only": False},
])

exchange.bulk_orders([
    {"coin": "ETH", "is_buy": True, "sz": 0.1, "limit_px": 2800,
     "order_type": {"limit": {"tif": "Gtc"}}, "reduce_only": False},
])
```

### One API wallet per process

Each trading process should use its own dedicated API wallet. This prevents nonce collisions between processes and makes it easy to identify which process placed which orders:

```python
# Process 1: market maker
mm_wallet = eth_account.Account.from_key("0xMM_AGENT_KEY")
mm_exchange = Exchange(mm_wallet, api_url, account_address=master_address)

# Process 2: trend follower
tf_wallet = eth_account.Account.from_key("0xTF_AGENT_KEY")
tf_exchange = Exchange(tf_wallet, api_url, account_address=master_address)
```

Create named API wallets via the app UI or `approveAgent`:

```python
# Create a named API wallet (up to 3 named per account)
response, agent_key = exchange.approve_agent("market_maker_v1")
print(f"New agent private key: {agent_key}")
```

### Circuit breakers

Implement automatic trading halts when anomalies are detected:

```python
class CircuitBreaker:
    """Halt trading on consecutive errors or anomalous conditions."""
    def __init__(self, max_failures=5, cooldown_seconds=60):
        self.max_failures = max_failures
        self.cooldown_seconds = cooldown_seconds
        self.failure_count = 0
        self.state = "CLOSED"  # CLOSED = normal, OPEN = halted
        self.opened_at = 0

    def record_success(self):
        self.failure_count = 0
        self.state = "CLOSED"

    def record_failure(self):
        self.failure_count += 1
        if self.failure_count >= self.max_failures:
            self.state = "OPEN"
            self.opened_at = time.time()
            print(f"[CIRCUIT BREAKER] OPEN after {self.failure_count} failures")

    def can_trade(self) -> bool:
        if self.state == "CLOSED":
            return True
        # Check if cooldown has elapsed
        if time.time() - self.opened_at > self.cooldown_seconds:
            self.state = "HALF_OPEN"
            return True  # Allow one attempt
        return False
```

> **Cross-reference:** See `bot-architecture.md` for the complete 6-stage bot architecture including the RECOVER stage, and `rate-limits.md` for understanding how rate limits interact with error recovery.
