# hyperliquid-api — Skill de Claude Code

Skill instalable para **Claude Code**: integración con **Hyperliquid**, la L1 de
futuros perpetuos, spot y DeFi. Coloca y gestiona órdenes (limit, IOC, ALO, stop-loss,
take-profit, TWAP), consulta datos de mercado, maneja posiciones y apalancamiento,
suscripciones WebSocket, autenticación EIP-712 / phantom agent, bots de trading,
gestión de riesgo (circuit breaker, dead man's switch), HyperCore/HyperEVM y los HIPs.
Autocontenida.

## Cómo instalar
1. Descomprime este ZIP. Obtendrás una carpeta `hyperliquid-api/`.
2. Cópiala a tu directorio de skills de Claude Code:
   - **Personal:** `~/.claude/skills/hyperliquid-api/`
   - **Solo un proyecto:** `<tu-proyecto>/.claude/skills/hyperliquid-api/`
3. Reinicia Claude Code. Se activará sola al trabajar con Hyperliquid.

## Contenido
- `SKILL.md` — guía principal.
- `references/` — authentication-and-signing, exchange-actions, info-queries,
  websocket-channels, rate-limits, bot-architecture, risk-and-error-handling,
  python-sdk, typescript-sdks, connection-and-endpoints, ecosystem-and-hips.

Cortesía de **Talent Academy · Vibe Coder**.
