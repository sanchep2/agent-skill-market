#!/usr/bin/env python3
"""
hyperliquid_helper.py — Reusable helper functions for Hyperliquid API operations.

Usage:
    from hyperliquid_helper import HyperliquidHelper
    helper = HyperliquidHelper(private_key="0x...", account_address="0x...")
    mids = helper.get_all_mids()

Or as CLI:
    python hyperliquid_helper.py market-data --coin ETH
    python hyperliquid_helper.py account-state --address 0x...
    python hyperliquid_helper.py place-order --key 0x... --address 0x... --coin ETH --side buy --size 0.1 --price 2800
    python hyperliquid_helper.py emergency-shutdown --key 0x... --address 0x...
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
import time
import random
from decimal import Decimal
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

try:
    import eth_account
    HAS_ETH_ACCOUNT = True
except ImportError:
    HAS_ETH_ACCOUNT = False

try:
    from hyperliquid.info import Info
    from hyperliquid.exchange import Exchange
    from hyperliquid.utils import constants
    from hyperliquid.utils.types import Cloid
    HAS_SDK = True
except ImportError:
    HAS_SDK = False

try:
    import websockets
    HAS_WEBSOCKETS = True
except ImportError:
    HAS_WEBSOCKETS = False


logger = logging.getLogger("hyperliquid_helper")


# === CircuitBreaker Pattern ===


class CircuitBreakerState(Enum):
    """Estados del circuit breaker."""
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreakerOpenError(Exception):
    """Se lanza cuando el circuit breaker está abierto y rechaza llamadas."""
    pass


class CircuitBreaker:
    """
    Implementación del patrón Circuit Breaker para proteger contra fallos en cascada.

    Flujo: CLOSED → (fallos >= threshold) → OPEN → (timeout) → HALF_OPEN → (éxito) → CLOSED
                                                                             → (fallo) → OPEN

    Uso:
        cb = CircuitBreaker(failure_threshold=5, recovery_timeout=30.0)

        @cb
        def risky_call():
            return api.request()

        # O sin decorador:
        result = cb.call(risky_call)
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 30.0,
        expected_exceptions: Tuple[type, ...] = (Exception,),
        name: str = "default",
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exceptions = expected_exceptions
        self.name = name

        self._state = CircuitBreakerState.CLOSED
        self._failure_count = 0
        self._last_failure_time: Optional[float] = None
        self._success_count_in_half_open = 0

    @property
    def state(self) -> CircuitBreakerState:
        if self._state == CircuitBreakerState.OPEN:
            if self._last_failure_time and (
                time.time() - self._last_failure_time >= self.recovery_timeout
            ):
                self._state = CircuitBreakerState.HALF_OPEN
                self._success_count_in_half_open = 0
                logger.info(f"CircuitBreaker[{self.name}]: OPEN → HALF_OPEN")
        return self._state

    def _record_success(self):
        if self._state == CircuitBreakerState.HALF_OPEN:
            self._success_count_in_half_open += 1
            if self._success_count_in_half_open >= 2:
                self._state = CircuitBreakerState.CLOSED
                self._failure_count = 0
                logger.info(f"CircuitBreaker[{self.name}]: HALF_OPEN → CLOSED")
        else:
            self._failure_count = max(0, self._failure_count - 1)

    def _record_failure(self):
        self._failure_count += 1
        self._last_failure_time = time.time()
        if self._state == CircuitBreakerState.HALF_OPEN:
            self._state = CircuitBreakerState.OPEN
            logger.warning(f"CircuitBreaker[{self.name}]: HALF_OPEN → OPEN")
        elif self._failure_count >= self.failure_threshold:
            self._state = CircuitBreakerState.OPEN
            logger.warning(
                f"CircuitBreaker[{self.name}]: CLOSED → OPEN "
                f"(failures={self._failure_count})"
            )

    def call(self, func: Callable, *args, **kwargs) -> Any:
        current_state = self.state
        if current_state == CircuitBreakerState.OPEN:
            raise CircuitBreakerOpenError(
                f"CircuitBreaker[{self.name}] is OPEN. "
                f"Retry after {self.recovery_timeout}s."
            )
        try:
            result = func(*args, **kwargs)
            self._record_success()
            return result
        except self.expected_exceptions:
            self._record_failure()
            raise

    def __call__(self, func: Callable) -> Callable:
        """Permite usar como decorador: @circuit_breaker"""
        def wrapper(*args, **kwargs):
            return self.call(func, *args, **kwargs)
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper

    def reset(self):
        self._state = CircuitBreakerState.CLOSED
        self._failure_count = 0
        self._last_failure_time = None
        logger.info(f"CircuitBreaker[{self.name}]: manual reset → CLOSED")

    def __repr__(self) -> str:
        return (
            f"CircuitBreaker(name={self.name}, state={self.state.value}, "
            f"failures={self._failure_count}/{self.failure_threshold})"
        )


# === Retry con Exponential Backoff ===


class RetryWithBackoff:
    """
    Reintentos con backoff exponencial y jitter para manejar rate limits.

    Uso:
        retry = RetryWithBackoff(max_retries=5, base_delay=1.0)

        @retry
        def api_call():
            return requests.post(...)

        # O sin decorador:
        result = retry.call(api_call)
    """

    def __init__(
        self,
        max_retries: int = 5,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        multiplier: float = 2.0,
        jitter: bool = True,
        retryable_exceptions: Tuple[type, ...] = (Exception,),
    ):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.multiplier = multiplier
        self.jitter = jitter
        self.retryable_exceptions = retryable_exceptions

    def _calculate_delay(self, attempt: int) -> float:
        delay = self.base_delay * (self.multiplier ** attempt)
        delay = min(delay, self.max_delay)
        if self.jitter:
            delay = delay * (0.5 + random.random() * 0.5)
        return delay

    def call(self, func: Callable, *args, **kwargs) -> Any:
        last_exception = None
        for attempt in range(self.max_retries + 1):
            try:
                return func(*args, **kwargs)
            except self.retryable_exceptions as e:
                last_exception = e
                if attempt < self.max_retries:
                    delay = self._calculate_delay(attempt)
                    logger.warning(
                        f"Retry {attempt + 1}/{self.max_retries}: {e}. "
                        f"Waiting {delay:.2f}s..."
                    )
                    time.sleep(delay)
        raise last_exception

    def __call__(self, func: Callable) -> Callable:
        """Permite usar como decorador: @retry"""
        def wrapper(*args, **kwargs):
            return self.call(func, *args, **kwargs)
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper


# === Price Formatter ===


class PriceFormatter:
    """
    Formatea precios y tamaños para Hyperliquid API.

    Regla crítica: NO trailing zeros. "50000" no "50000.0". "0.01" no "0.010".
    """

    @staticmethod
    def format_price(value: float, sig_figs: int = 5) -> str:
        """
        Formatea un precio sin trailing zeros.

        >>> PriceFormatter.format_price(50000.0)
        '50000'
        >>> PriceFormatter.format_price(2800.50)
        '2800.5'
        >>> PriceFormatter.format_price(0.001234)
        '0.001234'
        """
        d = Decimal(str(value))
        normalized = d.normalize()
        result = format(normalized, 'f')
        return result

    @staticmethod
    def format_size(value: float, sz_decimals: int = 5) -> str:
        """
        Formatea un tamaño sin trailing zeros, respetando szDecimals del asset.

        >>> PriceFormatter.format_size(0.01, sz_decimals=2)
        '0.01'
        >>> PriceFormatter.format_size(1.0, sz_decimals=5)
        '1'
        """
        d = Decimal(str(value))
        if sz_decimals > 0:
            quantize_str = '0.' + '0' * sz_decimals
            d = d.quantize(Decimal(quantize_str))
        normalized = d.normalize()
        result = format(normalized, 'f')
        return result

    @staticmethod
    def round_to_tick(price: float, tick_size: float) -> float:
        """
        Redondea un precio al tick size más cercano.

        >>> PriceFormatter.round_to_tick(2801.37, 0.1)
        2801.4
        """
        tick = Decimal(str(tick_size))
        p = Decimal(str(price))
        rounded = (p / tick).quantize(Decimal('1')) * tick
        return float(rounded)

    @staticmethod
    def slippage_price(mid_price: float, is_buy: bool, slippage_pct: float = 0.03) -> str:
        """
        Calcula precio con slippage para market orders (IOC).

        Para compra: mid * (1 + slippage_pct)
        Para venta: mid * (1 - slippage_pct)

        >>> PriceFormatter.slippage_price(2800.0, True, 0.03)
        '2884'
        """
        if is_buy:
            price = mid_price * (1 + slippage_pct)
        else:
            price = mid_price * (1 - slippage_pct)
        return PriceFormatter.format_price(price)


# === HyperliquidHelper ===


class HyperliquidHelper:
    """
    Wrapper completo del SDK de Hyperliquid para operaciones comunes.

    Proporciona métodos simplificados para:
    - Market data (precios, orderbook, candles, funding)
    - Account state (posiciones, balances, órdenes abiertas)
    - Trading (limit orders, market orders, TWAP, cancel, modify)
    - Position management (leverage, margin, close)
    - Risk management (emergency shutdown, dead man's switch)
    - Transfers (USDC, spot, withdraw)
    - Monitoring (rate limits, order status)

    Uso:
        helper = HyperliquidHelper(
            private_key="0xPRIVATE_KEY",
            account_address="0xACCOUNT_ADDRESS",
            testnet=False,
        )
        mids = helper.get_all_mids()
        helper.place_limit_order("ETH", is_buy=True, size=0.1, price=2800.0)
    """

    def __init__(
        self,
        private_key: Optional[str] = None,
        account_address: Optional[str] = None,
        testnet: bool = False,
        circuit_breaker: Optional[CircuitBreaker] = None,
        retry: Optional[RetryWithBackoff] = None,
    ):
        if not HAS_SDK:
            raise ImportError(
                "hyperliquid-python-sdk is required. Install: pip install hyperliquid-python-sdk"
            )
        if not HAS_ETH_ACCOUNT:
            raise ImportError(
                "eth_account is required. Install: pip install eth_account"
            )

        self.testnet = testnet
        self.api_url = (
            constants.TESTNET_API_URL if testnet
            else constants.MAINNET_API_URL
        )

        # Info client (always available — read-only)
        self.info = Info(self.api_url, skip_ws=True)

        # Exchange client (requires private key)
        self._exchange: Optional[Exchange] = None
        self._wallet = None
        self._account_address = account_address

        if private_key:
            self._wallet = eth_account.Account.from_key(private_key)
            address = account_address or self._wallet.address
            self._account_address = address
            self._exchange = Exchange(
                self._wallet, self.api_url, account_address=address
            )

        # Protection patterns
        self.cb = circuit_breaker or CircuitBreaker(
            failure_threshold=5,
            recovery_timeout=30.0,
            name="hyperliquid",
        )
        self.retry = retry or RetryWithBackoff(
            max_retries=3,
            base_delay=1.0,
            max_delay=30.0,
        )

        # Cache for metadata
        self._meta_cache: Optional[Dict] = None
        self._meta_cache_time: float = 0

    @property
    def exchange(self) -> Exchange:
        if self._exchange is None:
            raise RuntimeError(
                "Exchange not initialized. Provide private_key to constructor."
            )
        return self._exchange

    @property
    def address(self) -> str:
        if self._account_address is None:
            raise RuntimeError(
                "Account address not set. Provide account_address to constructor."
            )
        return self._account_address

    # --- Market Data ---

    def get_all_mids(self) -> Dict[str, str]:
        """Obtiene mid prices de todos los assets."""
        return self.cb.call(self.info.all_mids)

    def get_mid_price(self, coin: str) -> Optional[float]:
        """Obtiene el mid price de un asset específico."""
        mids = self.get_all_mids()
        price_str = mids.get(coin)
        return float(price_str) if price_str else None

    def get_orderbook(self, coin: str, n_sig_figs: int = 5) -> Dict:
        """Obtiene L2 orderbook snapshot (max 20 niveles por lado)."""
        return self.cb.call(self.info.l2_snapshot, coin)

    def get_candles(
        self,
        coin: str,
        interval: str = "1h",
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
    ) -> List[Dict]:
        """
        Obtiene candles OHLCV (max 5000 por request).

        Intervals: 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 8h, 12h, 1d, 3d, 1w, 1M
        """
        now_ms = int(time.time() * 1000)
        start = start_time or (now_ms - 24 * 3600 * 1000)
        end = end_time or now_ms
        return self.cb.call(
            self.info.candles_snapshot, coin, interval, start, end
        )

    def get_meta(self, force_refresh: bool = False) -> Dict:
        """Obtiene metadata de perpetuos (cacheado 5 minutos)."""
        now = time.time()
        if (
            not force_refresh
            and self._meta_cache
            and (now - self._meta_cache_time) < 300
        ):
            return self._meta_cache
        self._meta_cache = self.cb.call(self.info.meta)
        self._meta_cache_time = now
        return self._meta_cache

    def get_funding_rates(
        self, coin: str, start_time: Optional[int] = None
    ) -> List[Dict]:
        """Obtiene historial de funding rates para un asset."""
        start = start_time or int((time.time() - 7 * 24 * 3600) * 1000)
        end = int(time.time() * 1000)
        return self.cb.call(
            self.info.funding_history, coin, start, end
        )

    def get_asset_index(self, coin: str) -> Optional[int]:
        """Obtiene el índice numérico de un asset perpetuo."""
        meta = self.get_meta()
        for i, asset in enumerate(meta.get("universe", [])):
            if asset.get("name") == coin:
                return i
        return None

    def get_sz_decimals(self, coin: str) -> int:
        """Obtiene los decimales de tamaño para un asset."""
        meta = self.get_meta()
        for asset in meta.get("universe", []):
            if asset.get("name") == coin:
                return asset.get("szDecimals", 5)
        return 5

    # --- Account State ---

    def get_account_state(self, address: Optional[str] = None) -> Dict:
        """Obtiene estado completo de la cuenta (perp clearinghouse)."""
        addr = address or self.address
        return self.cb.call(self.info.user_state, addr)

    def get_spot_state(self, address: Optional[str] = None) -> Dict:
        """Obtiene estado de balances spot."""
        addr = address or self.address
        return self.cb.call(self.info.spot_user_state, addr)

    def get_positions(self, address: Optional[str] = None) -> List[Dict]:
        """Obtiene posiciones abiertas con detalles."""
        state = self.get_account_state(address)
        positions = []
        for ap in state.get("assetPositions", []):
            pos = ap.get("position", {})
            szi = float(pos.get("szi", "0"))
            if szi != 0:
                positions.append({
                    "coin": pos.get("coin"),
                    "size": szi,
                    "entry_price": float(pos.get("entryPx", "0")),
                    "unrealized_pnl": float(pos.get("unrealizedPnl", "0")),
                    "liquidation_price": pos.get("liquidationPx"),
                    "leverage": pos.get("leverage", {}),
                    "margin_used": float(pos.get("marginUsed", "0")),
                    "return_on_equity": float(pos.get("returnOnEquity", "0")),
                })
        return positions

    def get_account_value(self, address: Optional[str] = None) -> float:
        """Obtiene el valor total de la cuenta."""
        state = self.get_account_state(address)
        return float(
            state.get("marginSummary", {}).get("accountValue", "0")
        )

    def get_withdrawable(self, address: Optional[str] = None) -> float:
        """Obtiene el monto disponible para retiro."""
        state = self.get_account_state(address)
        return float(state.get("withdrawable", "0"))

    def get_open_orders(self, address: Optional[str] = None) -> List[Dict]:
        """Obtiene órdenes abiertas."""
        addr = address or self.address
        return self.cb.call(self.info.open_orders, addr)

    def get_open_orders_detailed(
        self, address: Optional[str] = None
    ) -> List[Dict]:
        """Obtiene órdenes abiertas con detalles extendidos."""
        addr = address or self.address
        return self.cb.call(self.info.frontend_open_orders, addr)

    def get_fills(
        self,
        address: Optional[str] = None,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
    ) -> List[Dict]:
        """Obtiene fills recientes."""
        addr = address or self.address
        if start_time and end_time:
            return self.cb.call(
                self.info.user_fills_by_time, addr, start_time, end_time
            )
        return self.cb.call(self.info.user_fills, addr)

    def get_order_status(self, oid: int, address: Optional[str] = None) -> Dict:
        """Obtiene el estado de una orden por OID."""
        addr = address or self.address
        return self.cb.call(self.info.query_order_by_oid, addr, oid)

    def get_rate_limit(self, address: Optional[str] = None) -> Dict:
        """Obtiene estado del rate limit del usuario."""
        addr = address or self.address
        return self.cb.call(self.info.user_rate_limit, addr)

    # --- Trading ---

    def place_limit_order(
        self,
        coin: str,
        is_buy: bool,
        size: float,
        price: float,
        tif: str = "Gtc",
        reduce_only: bool = False,
        cloid: Optional[str] = None,
    ) -> Dict:
        """
        Coloca una orden limit.

        Args:
            coin: Asset symbol (e.g., "ETH")
            is_buy: True=buy, False=sell
            size: Order size (will be formatted without trailing zeros)
            price: Limit price (will be formatted without trailing zeros)
            tif: Time-in-force: "Gtc", "Ioc", "Alo"
            reduce_only: True for reduce-only orders
            cloid: Optional client order ID (128-bit hex string)
        """
        order_type = {"limit": {"tif": tif}}
        cloid_obj = Cloid.from_str(cloid) if cloid else None
        return self.retry.call(
            self.cb.call,
            self.exchange.order,
            coin, is_buy, size, price, order_type,
            reduce_only=reduce_only,
            cloid=cloid_obj,
        )

    def place_market_order(
        self,
        coin: str,
        is_buy: bool,
        size: float,
        slippage: float = 0.03,
    ) -> Dict:
        """
        Coloca una orden market (IOC con slippage).

        Args:
            coin: Asset symbol
            is_buy: True=buy, False=sell
            size: Order size
            slippage: Slippage percentage (default 3%)
        """
        return self.retry.call(
            self.cb.call,
            self.exchange.market_open,
            coin, is_buy, size, slippage=slippage,
        )

    def place_stop_loss(
        self,
        coin: str,
        size: float,
        trigger_price: float,
        is_market: bool = True,
        limit_price: Optional[float] = None,
    ) -> Dict:
        """
        Coloca un stop-loss.

        Args:
            coin: Asset symbol
            size: Position size to close
            trigger_price: Price at which the stop triggers
            is_market: True for market stop, False for limit stop
            limit_price: Required if is_market=False
        """
        price = limit_price or trigger_price
        trigger_px = PriceFormatter.format_price(trigger_price)
        order_type = {
            "trigger": {
                "triggerPx": trigger_px,
                "isMarket": is_market,
                "tpsl": "sl",
            }
        }
        return self.retry.call(
            self.cb.call,
            self.exchange.order,
            coin, False, size, price, order_type,
            reduce_only=True,
        )

    def place_take_profit(
        self,
        coin: str,
        size: float,
        trigger_price: float,
        is_market: bool = True,
        limit_price: Optional[float] = None,
    ) -> Dict:
        """
        Coloca un take-profit.

        Args:
            coin: Asset symbol
            size: Position size to close
            trigger_price: Price at which the TP triggers
            is_market: True for market TP, False for limit TP
            limit_price: Required if is_market=False
        """
        price = limit_price or trigger_price
        trigger_px = PriceFormatter.format_price(trigger_price)
        order_type = {
            "trigger": {
                "triggerPx": trigger_px,
                "isMarket": is_market,
                "tpsl": "tp",
            }
        }
        return self.retry.call(
            self.cb.call,
            self.exchange.order,
            coin, False, size, price, order_type,
            reduce_only=True,
        )

    def close_position(self, coin: str, size: Optional[float] = None) -> Dict:
        """
        Cierra una posición (total o parcial).

        Args:
            coin: Asset symbol
            size: If None, closes full position. If specified, partial close.
        """
        if size is not None:
            return self.retry.call(
                self.cb.call,
                self.exchange.market_close, coin, sz=size,
            )
        return self.retry.call(
            self.cb.call,
            self.exchange.market_close, coin,
        )

    def cancel_order(self, coin: str, oid: int) -> Dict:
        """Cancela una orden por OID."""
        return self.cb.call(self.exchange.cancel, coin, oid)

    def cancel_order_by_cloid(self, coin: str, cloid: str) -> Dict:
        """Cancela una orden por CLOID."""
        cloid_obj = Cloid.from_str(cloid)
        return self.cb.call(self.exchange.cancel_by_cloid, coin, cloid_obj)

    def cancel_all_orders(self, address: Optional[str] = None) -> List[Dict]:
        """Cancela todas las órdenes abiertas."""
        orders = self.get_open_orders(address)
        results = []
        for order in orders:
            try:
                result = self.cancel_order(order["coin"], order["oid"])
                results.append({"oid": order["oid"], "result": result})
            except Exception as e:
                results.append({"oid": order["oid"], "error": str(e)})
                logger.error(f"Failed to cancel order {order['oid']}: {e}")
        return results

    def modify_order(
        self,
        oid: int,
        coin: str,
        is_buy: bool,
        size: float,
        price: float,
        tif: str = "Gtc",
    ) -> Dict:
        """Modifica una orden existente."""
        order_type = {"limit": {"tif": tif}}
        return self.cb.call(
            self.exchange.modify_order,
            oid, coin, is_buy, size, price, order_type,
        )

    # --- Position Management ---

    def set_leverage(
        self,
        coin: str,
        leverage: int,
        is_cross: bool = True,
    ) -> Dict:
        """
        Configura leverage para un asset.

        Args:
            coin: Asset symbol
            leverage: Leverage multiplier (max 50, recommended max 10)
            is_cross: True for cross margin, False for isolated
        """
        if leverage > 50:
            raise ValueError("Maximum leverage is 50x")
        if leverage > 10:
            logger.warning(
                f"Leverage {leverage}x exceeds recommended max of 10x. "
                "Proceed with extreme caution."
            )
        return self.cb.call(
            self.exchange.update_leverage,
            leverage, coin, is_cross=is_cross,
        )

    def add_isolated_margin(self, coin: str, amount_usd: float) -> Dict:
        """Añade margen a una posición aislada."""
        return self.cb.call(
            self.exchange.update_isolated_margin, amount_usd, coin,
        )

    # --- Risk Management ---

    def set_dead_mans_switch(self, seconds_from_now: int = 60) -> Dict:
        """
        Configura dead man's switch (scheduleCancel).

        Cancela TODAS las órdenes abiertas en el tiempo especificado.
        Debe ser ≥5 segundos en el futuro. Máximo 10 por día.
        """
        if seconds_from_now < 5:
            raise ValueError("Dead man's switch must be ≥5 seconds in the future")
        cancel_time = int(time.time() * 1000) + (seconds_from_now * 1000)
        return self.cb.call(self.exchange.schedule_cancel, cancel_time)

    def emergency_shutdown(self) -> Dict:
        """
        Procedimiento de emergencia:
        1. Activa dead man's switch (10s)
        2. Cancela todas las órdenes abiertas
        3. Cierra todas las posiciones a market

        Returns:
            Dict con resultados de cada paso
        """
        results = {
            "dead_mans_switch": None,
            "cancelled_orders": [],
            "closed_positions": [],
            "errors": [],
        }

        # Step 1: Dead man's switch
        try:
            results["dead_mans_switch"] = self.set_dead_mans_switch(10)
            logger.info("Emergency: Dead man's switch set for 10s")
        except Exception as e:
            results["errors"].append(f"Dead man's switch failed: {e}")
            logger.error(f"Emergency: Dead man's switch failed: {e}")

        # Step 2: Cancel all orders
        try:
            orders = self.get_open_orders()
            for order in orders:
                try:
                    self.cancel_order(order["coin"], order["oid"])
                    results["cancelled_orders"].append(order["oid"])
                except Exception as e:
                    results["errors"].append(
                        f"Cancel order {order['oid']} failed: {e}"
                    )
            logger.info(
                f"Emergency: Cancelled {len(results['cancelled_orders'])} orders"
            )
        except Exception as e:
            results["errors"].append(f"Cancel all orders failed: {e}")
            logger.error(f"Emergency: Cancel all orders failed: {e}")

        # Step 3: Close all positions
        try:
            positions = self.get_positions()
            for pos in positions:
                try:
                    self.close_position(pos["coin"])
                    results["closed_positions"].append(pos["coin"])
                except Exception as e:
                    results["errors"].append(
                        f"Close {pos['coin']} failed: {e}"
                    )
            logger.info(
                f"Emergency: Closed {len(results['closed_positions'])} positions"
            )
        except Exception as e:
            results["errors"].append(f"Close all positions failed: {e}")
            logger.error(f"Emergency: Close all positions failed: {e}")

        return results

    def check_liquidation_risk(
        self, address: Optional[str] = None, threshold_pct: float = 0.1
    ) -> List[Dict]:
        """
        Verifica riesgo de liquidación.

        Returns:
            Lista de posiciones donde (mark - liquidation) / mark < threshold_pct
        """
        positions = self.get_positions(address)
        mids = self.get_all_mids()
        at_risk = []
        for pos in positions:
            coin = pos["coin"]
            liq_px = pos.get("liquidation_price")
            if not liq_px or liq_px == "N/A":
                continue
            liq_price = float(liq_px)
            mark_price = float(mids.get(coin, "0"))
            if mark_price == 0:
                continue
            distance_pct = abs(mark_price - liq_price) / mark_price
            if distance_pct < threshold_pct:
                at_risk.append({
                    **pos,
                    "mark_price": mark_price,
                    "distance_to_liquidation_pct": distance_pct,
                })
        return at_risk

    # --- Transfers ---

    def transfer_usdc(self, amount: float, destination: str) -> Dict:
        """Transfiere USDC a otra dirección."""
        return self.cb.call(self.exchange.usd_transfer, amount, destination)

    def transfer_spot_to_perp(self, amount: float) -> Dict:
        """Transfiere USDC de spot wallet a perp wallet."""
        return self.cb.call(
            self.exchange.usd_class_transfer, amount, to_perp=True,
        )

    def transfer_perp_to_spot(self, amount: float) -> Dict:
        """Transfiere USDC de perp wallet a spot wallet."""
        return self.cb.call(
            self.exchange.usd_class_transfer, amount, to_perp=False,
        )

    def withdraw_to_arbitrum(self, amount: float, destination: str) -> Dict:
        """
        Retira USDC a Arbitrum.
        Fee: $1, tiempo: ~5 minutos.
        """
        return self.cb.call(
            self.exchange.withdraw_from_bridge, amount, destination,
        )

    # --- Monitoring ---

    def get_snapshot(self, address: Optional[str] = None) -> Dict:
        """
        Obtiene un snapshot completo del estado de la cuenta.

        Incluye: account value, positions, open orders, rate limit, balances.
        """
        addr = address or self.address
        account_state = self.get_account_state(addr)
        positions = self.get_positions(addr)
        open_orders = self.get_open_orders(addr)

        rate_limit = None
        try:
            rate_limit = self.get_rate_limit(addr)
        except Exception:
            pass

        spot_state = None
        try:
            spot_state = self.get_spot_state(addr)
        except Exception:
            pass

        return {
            "timestamp": int(time.time() * 1000),
            "address": addr,
            "account_value": float(
                account_state.get("marginSummary", {}).get("accountValue", "0")
            ),
            "withdrawable": float(account_state.get("withdrawable", "0")),
            "total_margin_used": float(
                account_state.get("marginSummary", {}).get("totalMarginUsed", "0")
            ),
            "positions": positions,
            "open_orders_count": len(open_orders),
            "open_orders": open_orders,
            "rate_limit": rate_limit,
            "spot_balances": (
                spot_state.get("balances", []) if spot_state else []
            ),
        }


# === WebSocketManager ===


class WebSocketManager:
    """
    Gestor de WebSocket con auto-reconnection, heartbeat y tracking de suscripciones.

    Uso:
        async def on_book(data):
            print(data)

        manager = WebSocketManager(testnet=False)
        manager.subscribe("l2Book", {"coin": "ETH"}, on_book)
        await manager.run()
    """

    def __init__(
        self,
        testnet: bool = False,
        max_reconnect_delay: float = 60.0,
        heartbeat_interval: float = 50.0,
    ):
        if not HAS_WEBSOCKETS:
            raise ImportError(
                "websockets is required. Install: pip install websockets"
            )

        self.ws_url = (
            "wss://api.hyperliquid-testnet.xyz/ws" if testnet
            else "wss://api.hyperliquid.xyz/ws"
        )
        self.max_reconnect_delay = max_reconnect_delay
        self.heartbeat_interval = heartbeat_interval

        self._subscriptions: List[Tuple[str, Dict, Callable]] = []
        self._ws = None
        self._running = False
        self._reconnect_delay = 1.0

    def subscribe(
        self,
        channel_type: str,
        params: Dict,
        callback: Callable,
    ):
        """
        Registra una suscripción.

        Args:
            channel_type: e.g., "l2Book", "trades", "allMids", "orderUpdates"
            params: Additional params (e.g., {"coin": "ETH"}, {"user": "0x..."})
            callback: Async or sync callback function for incoming data
        """
        self._subscriptions.append((channel_type, params, callback))

    async def _send_subscriptions(self, ws):
        """Envía todas las suscripciones registradas."""
        for channel_type, params, _ in self._subscriptions:
            sub_msg = {
                "method": "subscribe",
                "subscription": {"type": channel_type, **params},
            }
            await ws.send(json.dumps(sub_msg))
            logger.debug(f"Subscribed to {channel_type}: {params}")

    async def _heartbeat(self, ws):
        """Envía pings periódicos para mantener la conexión."""
        while self._running:
            try:
                await ws.send(json.dumps({"method": "ping"}))
                await asyncio.sleep(self.heartbeat_interval)
            except Exception:
                break

    async def _handle_message(self, data: Dict):
        """Despacha mensajes a los callbacks correspondientes."""
        channel = data.get("channel")
        if channel == "pong":
            return
        if channel == "subscriptionResponse":
            logger.debug(f"Subscription confirmed: {data.get('data')}")
            return

        for channel_type, params, callback in self._subscriptions:
            if channel == channel_type:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(data.get("data"))
                    else:
                        callback(data.get("data"))
                except Exception as e:
                    logger.error(
                        f"Callback error for {channel_type}: {e}"
                    )

    async def run(self):
        """
        Loop principal de conexión con auto-reconnection.

        Implementa exponential backoff: 1s → 2s → 4s → ... → max_reconnect_delay.
        """
        self._running = True
        self._reconnect_delay = 1.0

        while self._running:
            try:
                async with websockets.connect(self.ws_url) as ws:
                    self._ws = ws
                    self._reconnect_delay = 1.0
                    logger.info(f"Connected to {self.ws_url}")

                    await self._send_subscriptions(ws)

                    heartbeat_task = asyncio.create_task(self._heartbeat(ws))

                    try:
                        async for message in ws:
                            try:
                                data = json.loads(message)
                                await self._handle_message(data)
                            except json.JSONDecodeError:
                                logger.warning(
                                    f"Invalid JSON: {message[:100]}"
                                )
                    finally:
                        heartbeat_task.cancel()

            except Exception as e:
                if not self._running:
                    break
                logger.warning(
                    f"WebSocket disconnected: {e}. "
                    f"Reconnecting in {self._reconnect_delay:.1f}s..."
                )
                await asyncio.sleep(self._reconnect_delay)
                self._reconnect_delay = min(
                    self._reconnect_delay * 2, self.max_reconnect_delay
                )

    async def stop(self):
        """Detiene el WebSocket manager."""
        self._running = False
        if self._ws:
            await self._ws.close()
            self._ws = None
        logger.info("WebSocket manager stopped")

    async def post_info(self, payload: Dict, request_id: int = 1) -> None:
        """
        Envía una query de info a través de WebSocket.

        Args:
            payload: e.g., {"type": "l2Book", "coin": "ETH"}
            request_id: Unique ID for response matching
        """
        if not self._ws:
            raise RuntimeError("WebSocket not connected")
        msg = {
            "method": "post",
            "id": request_id,
            "request": {"type": "info", "payload": payload},
        }
        await self._ws.send(json.dumps(msg))


# === CLI ===


def _setup_logging(verbose: bool = False):
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )


def _cmd_market_data(args):
    """Muestra datos de mercado para un asset."""
    helper = HyperliquidHelper(testnet=args.testnet)

    if args.coin:
        mid = helper.get_mid_price(args.coin)
        book = helper.get_orderbook(args.coin)
        bids = book.get("levels", [[], []])[0][:5]
        asks = book.get("levels", [[], []])[1][:5]

        print(f"\n=== {args.coin} Market Data ===")
        print(f"Mid price: {mid}")
        print("\nTop 5 Bids:")
        for level in bids:
            print(f"  {level['px']} x {level['sz']} ({level['n']} orders)")
        print("\nTop 5 Asks:")
        for level in asks:
            print(f"  {level['px']} x {level['sz']} ({level['n']} orders)")
    else:
        mids = helper.get_all_mids()
        print(f"\n=== All Mid Prices ({len(mids)} assets) ===")
        for coin, price in sorted(mids.items()):
            print(f"  {coin}: {price}")


def _cmd_account_state(args):
    """Muestra estado de la cuenta."""
    helper = HyperliquidHelper(
        account_address=args.address, testnet=args.testnet,
    )

    snapshot = helper.get_snapshot(args.address)
    print(f"\n=== Account State: {args.address[:10]}... ===")
    print(f"Account value: ${snapshot['account_value']:.2f}")
    print(f"Withdrawable:  ${snapshot['withdrawable']:.2f}")
    print(f"Margin used:   ${snapshot['total_margin_used']:.2f}")
    print(f"Open orders:   {snapshot['open_orders_count']}")

    if snapshot["positions"]:
        print(f"\nPositions ({len(snapshot['positions'])}):")
        for pos in snapshot["positions"]:
            direction = "LONG" if pos["size"] > 0 else "SHORT"
            print(
                f"  {pos['coin']}: {direction} {abs(pos['size'])} "
                f"@ {pos['entry_price']:.2f} "
                f"PnL: ${pos['unrealized_pnl']:.2f} "
                f"Liq: {pos.get('liquidation_price', 'N/A')}"
            )

    if snapshot.get("rate_limit"):
        rl = snapshot["rate_limit"]
        print(
            f"\nRate limit: {rl.get('nRequestsUsed', '?')}/"
            f"{rl.get('nRequestsCap', '?')} requests used"
        )


def _cmd_monitor(args):
    """Monitorea posiciones en loop."""
    helper = HyperliquidHelper(
        account_address=args.address, testnet=args.testnet,
    )
    interval = args.interval or 5

    print(f"Monitoring {args.address[:10]}... every {interval}s (Ctrl+C to stop)")
    try:
        while True:
            positions = helper.get_positions(args.address)
            mids = helper.get_all_mids()
            timestamp = time.strftime("%H:%M:%S")

            print(f"\n[{timestamp}] Positions:")
            if not positions:
                print("  No open positions")
            for pos in positions:
                mid = mids.get(pos["coin"], "?")
                direction = "LONG" if pos["size"] > 0 else "SHORT"
                print(
                    f"  {pos['coin']}: {direction} {abs(pos['size'])} "
                    f"entry={pos['entry_price']:.2f} "
                    f"mid={mid} "
                    f"pnl=${pos['unrealized_pnl']:.2f} "
                    f"liq={pos.get('liquidation_price', 'N/A')}"
                )

            at_risk = helper.check_liquidation_risk(args.address)
            if at_risk:
                print("\n  ⚠ LIQUIDATION RISK:")
                for r in at_risk:
                    print(
                        f"    {r['coin']}: "
                        f"{r['distance_to_liquidation_pct']:.1%} from liquidation"
                    )

            time.sleep(interval)
    except KeyboardInterrupt:
        print("\nMonitoring stopped.")


def _cmd_emergency_shutdown(args):
    """Ejecuta procedimiento de emergencia."""
    helper = HyperliquidHelper(
        private_key=args.key,
        account_address=args.address,
        testnet=args.testnet,
    )

    print("EMERGENCY SHUTDOWN INITIATED")
    print("=" * 40)

    results = helper.emergency_shutdown()

    print(f"\nDead man's switch: {results['dead_mans_switch']}")
    print(f"Cancelled orders: {len(results['cancelled_orders'])}")
    print(f"Closed positions: {len(results['closed_positions'])}")
    if results["errors"]:
        print(f"\nErrors ({len(results['errors'])}):")
        for err in results["errors"]:
            print(f"  - {err}")
    print("\nEmergency shutdown complete.")


def _cmd_place_order(args):
    """Coloca una orden."""
    helper = HyperliquidHelper(
        private_key=args.key,
        account_address=args.address,
        testnet=args.testnet,
    )

    is_buy = args.side.lower() == "buy"

    if args.order_type == "market":
        result = helper.place_market_order(
            args.coin, is_buy, args.size, slippage=args.slippage or 0.03,
        )
    else:
        if not args.price:
            print("Error: --price required for limit orders")
            sys.exit(1)
        result = helper.place_limit_order(
            args.coin, is_buy, args.size, args.price,
            tif=args.tif or "Gtc",
        )

    print(f"\nOrder result: {json.dumps(result, indent=2)}")


def _cmd_snapshot(args):
    """Guarda un snapshot completo del estado de la cuenta."""
    helper = HyperliquidHelper(
        account_address=args.address, testnet=args.testnet,
    )

    snapshot = helper.get_snapshot(args.address)
    output = args.output or "snapshot.json"

    with open(output, "w") as f:
        json.dump(snapshot, f, indent=2, default=str)

    print(f"Snapshot saved to {output}")
    print(f"Account value: ${snapshot['account_value']:.2f}")
    print(f"Positions: {len(snapshot['positions'])}")
    print(f"Open orders: {snapshot['open_orders_count']}")


def main():
    parser = argparse.ArgumentParser(
        description="Hyperliquid API Helper — CLI & Module",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python hyperliquid_helper.py market-data --coin ETH
  python hyperliquid_helper.py account-state --address 0x...
  python hyperliquid_helper.py monitor --address 0x... --interval 5
  python hyperliquid_helper.py emergency-shutdown --key 0x... --address 0x...
  python hyperliquid_helper.py place-order --key 0x... --address 0x... --coin ETH --side buy --size 0.1 --price 2800
  python hyperliquid_helper.py snapshot --address 0x... --output state.json
        """,
    )
    parser.add_argument("--testnet", action="store_true", help="Use testnet")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose logging")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # market-data
    p_market = subparsers.add_parser("market-data", help="Get market data")
    p_market.add_argument("--coin", help="Asset symbol (e.g., ETH). Omit for all mids.")

    # account-state
    p_account = subparsers.add_parser("account-state", help="Get account state")
    p_account.add_argument("--address", required=True, help="Account address (master, not agent)")

    # monitor
    p_monitor = subparsers.add_parser("monitor", help="Monitor positions in loop")
    p_monitor.add_argument("--address", required=True, help="Account address")
    p_monitor.add_argument("--interval", type=int, default=5, help="Poll interval (seconds)")

    # emergency-shutdown
    p_emergency = subparsers.add_parser("emergency-shutdown", help="Emergency shutdown")
    p_emergency.add_argument("--key", required=True, help="Private key")
    p_emergency.add_argument("--address", required=True, help="Account address")

    # place-order
    p_order = subparsers.add_parser("place-order", help="Place an order")
    p_order.add_argument("--key", required=True, help="Private key")
    p_order.add_argument("--address", required=True, help="Account address")
    p_order.add_argument("--coin", required=True, help="Asset symbol")
    p_order.add_argument("--side", required=True, choices=["buy", "sell"], help="Order side")
    p_order.add_argument("--size", required=True, type=float, help="Order size")
    p_order.add_argument("--price", type=float, help="Limit price (required for limit orders)")
    p_order.add_argument("--order-type", default="limit", choices=["limit", "market"], help="Order type")
    p_order.add_argument("--tif", default="Gtc", choices=["Gtc", "Ioc", "Alo"], help="Time-in-force")
    p_order.add_argument("--slippage", type=float, default=0.03, help="Slippage for market orders")

    # snapshot
    p_snapshot = subparsers.add_parser("snapshot", help="Save account snapshot to JSON")
    p_snapshot.add_argument("--address", required=True, help="Account address")
    p_snapshot.add_argument("--output", default="snapshot.json", help="Output file path")

    args = parser.parse_args()
    _setup_logging(args.verbose)

    if not args.command:
        parser.print_help()
        sys.exit(1)

    commands = {
        "market-data": _cmd_market_data,
        "account-state": _cmd_account_state,
        "monitor": _cmd_monitor,
        "emergency-shutdown": _cmd_emergency_shutdown,
        "place-order": _cmd_place_order,
        "snapshot": _cmd_snapshot,
    }

    cmd_func = commands.get(args.command)
    if cmd_func:
        cmd_func(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
