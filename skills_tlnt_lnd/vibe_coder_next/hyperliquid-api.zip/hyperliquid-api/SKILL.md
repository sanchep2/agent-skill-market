---
name: hyperliquid-api
description: >
  Use this skill whenever the user needs to work with Hyperliquid — the purpose-built L1
  blockchain for perpetual futures, spot trading, and DeFi. This includes: writing Python or
  TypeScript code that calls the Hyperliquid API, placing or managing orders (limit, IOC,
  ALO, stop-loss, take-profit, TWAP), querying market data (orderbook, candles, trades,
  funding rates), managing positions and leverage (cross/isolated, up to 50x), implementing
  WebSocket subscriptions (19 channels: l2Book, trades, orderUpdates, userEvents, allMids,
  etc.), handling EIP-712 authentication and phantom agent signing, working with API/agent
  wallets, managing nonces, building trading bots, implementing risk management (circuit
  breaker, dead man's switch, emergency shutdown), interacting with HyperCore or HyperEVM,
  working with HIP-1/HIP-2 spot tokens, HIP-3 permissionless perps, HIP-4 outcome trading,
  staking HYPE, vault management, sub-accounts, transfers and withdrawals, or using any
  Hyperliquid SDK (hyperliquid-python-sdk, @nktkas/hyperliquid, nomeida/hyperliquid, CCXT).
  ALSO trigger for: msgpack serialization, phantom agent construction, cloid (client order ID),
  builder fees, scheduleCancel (dead man's switch), asset indexing (perps vs spot vs HIP-3),
  rate limit management (IP-based 1200 weight/min, address-based per-volume), or testnet
  development workflow. Trigger keywords: "Hyperliquid", "HyperCore", "HyperEVM", "HyperBFT",
  "phantom agent", "perpetual futures", "perp", "TWAP", "cloid", "msgpack", "L1 blockchain",
  "50x leverage", "scheduleCancel", "dead man switch", "API wallet", "agent wallet",
  "hyperliquid-python-sdk", "@nktkas/hyperliquid", "nomeida/hyperliquid", "CCXT hyperliquid",
  "HIP-1", "HIP-2", "HIP-3", "HIP-4", "HYPE token", "HYPE staking", "HyperEVM RPC",
  "perpetual swap", "funding rate", "liquidation price", "reduce only", "post only ALO",
  "IOC order", "GTC order", "l2Book", "allMids", "clearinghouseState", "userFills",
  "orderUpdates", "wss://api.hyperliquid.xyz", "trading bot", "market maker bot",
  "grid trading", "copy trading", "DeFi trading", "on-chain trading", or any question
  about Hyperliquid architecture, API surfaces, or trading system design.
---

# Hyperliquid API — Complete Skill (February 2026)

## S1 — Architecture

Hyperliquid is a purpose-built L1 blockchain running **HyperBFT** consensus with sub-second finality, processing **200k+ orders/second** across two layers:

- **HyperCore**: Native high-performance trading engine (order books, matching, clearing)
- **HyperEVM**: Ethereum-compatible smart contracts sharing consensus with HyperCore

### Three API surfaces

| Surface | URL | Method | Purpose |
|---------|-----|--------|---------|
| Info (read) | `POST /info` | REST | Market data, user state, metadata (50+ query types) |
| Exchange (write) | `POST /exchange` | REST | Signed trading actions (27 action types) |
| WebSocket | `wss://api.hyperliquid.xyz/ws` | WS | Real-time streaming (19 channels) + posting |

**Base URLs:**

| Environment | REST | WebSocket | HyperEVM RPC |
|-------------|------|-----------|--------------|
| Mainnet | `https://api.hyperliquid.xyz` | `wss://api.hyperliquid.xyz/ws` | `https://rpc.hyperliquid.xyz/evm` |
| Testnet | `https://api.hyperliquid-testnet.xyz` | `wss://api.hyperliquid-testnet.xyz/ws` | — |

### Asset indexing

- **Perps**: numeric index from `meta` response's `universe` array (BTC=0, ETH=1, ...)
- **Spot**: `10000 + index` from `spotMeta.universe`; queries use `"PURR/USDC"` or `"@{index}"`
- **HIP-3 perps**: format `"dex_name:ASSET_NAME"` (e.g., `"xyz:XYZ100"`)
- Some assets are remapped on UI (BTC/USDC on app = UBTC/USDC on HyperCore)

**For deeper topics, read the appropriate reference file:**

| Topic | Reference File | When to Read |
|-------|---------------|--------------|
| URLs, asset indexing, testnet workflow | `references/connection-and-endpoints.md` | Setting up connections, understanding asset addressing |
| 27 exchange actions: orders, TWAP, transfers | `references/exchange-actions.md` | Placing/modifying/canceling orders, transfers, account management |
| 50+ info queries: market data, user state | `references/info-queries.md` | Querying orderbook, positions, fills, funding, metadata |
| 19 WebSocket channels, reconnection | `references/websocket-channels.md` | Real-time data streaming, posting via WS |
| EIP-712, phantom agent, nonces, API wallets | `references/authentication-and-signing.md` | Setting up signing, creating API wallets, nonce management |
| IP-based, address-based, request weights | `references/rate-limits.md` | Understanding and respecting rate limits |
| hyperliquid-python-sdk v0.22.0 complete | `references/python-sdk.md` | Building with Python SDK |
| @nktkas + nomeida + CCXT | `references/typescript-sdks.md` | Building with TypeScript SDKs |
| Error codes, gotchas, emergency shutdown | `references/risk-and-error-handling.md` | Error handling, risk management, safety patterns |
| HIP-1/2/3/4, staking, vaults, HyperEVM | `references/ecosystem-and-hips.md` | Understanding token standards, ecosystem features |
| 6-stage bot architecture, latency, examples | `references/bot-architecture.md` | Designing trading bots, optimization |

### Order Lifecycle

```
┌──────────┐    ┌──────────────┐    ┌──────────────┐
│  Client  │───▶│  Sign with   │───▶│  POST        │
│  builds  │    │  EIP-712     │    │  /exchange    │
│  order   │    │  (phantom    │    │              │
│  params  │    │   agent,     │    │  or WS post  │
│          │    │   chainId    │    │              │
│  price:  │    │   1337)      │    └──────┬───────┘
│  no trail│    └──────────────┘           │
│  zeros!  │                              ▼
└──────────┘                       ┌──────────────┐
                                   │  Validator   │
                                   │  processes   │
                                   └──────┬───────┘
                                          │
                          ┌───────────────┼───────────────┐
                          ▼               ▼               ▼
                   ┌──────────┐    ┌──────────┐    ┌──────────┐
                   │ "resting"│    │ "filled" │    │ "error"  │
                   │ (on book)│    │ (matched)│    │ (reject) │
                   └────┬─────┘    └──────────┘    └──────────┘
                        │
                 ┌──────┼──────┐
                 ▼      ▼      ▼
              Modify  Cancel  Fill
              (same   by OID  (partial
               flow)  or cloid or full)
```

### WebSocket Subscription Model

```
┌──────────────┐        ┌──────────────────────────────┐
│   Client     │◄──────▶│  wss://api.hyperliquid.xyz/ws│
│              │        │                               │
│ 1. Connect   │        │  19 Channels:                │
│ 2. Heartbeat │        │  ├── l2Book (orderbook)      │
│    ping/50s  │        │  ├── trades                  │
│ 3. Subscribe │        │  ├── allMids (prices)        │
│ 4. Receive   │        │  ├── orderUpdates            │
│ 5. Post      │        │  ├── userEvents              │
│    (orders)  │        │  ├── candle                  │
│              │        │  ├── userFills                │
│ On disconnect│        │  ├── userFundings             │
│ → exp backoff│        │  ├── activeAssetCtx           │
│   1s→2s→4s→  │        │  └── ... (10 more)           │
│   ...→60s max│        │                               │
│ → re-subscribe       │  Can also POST orders via WS  │
│ → reconcile  │        │  (lowest latency path)       │
│   via REST   │        │                               │
└──────────────┘        └──────────────────────────────┘
```

### L1 Architecture

```
┌─────────────────────────────────────────────────┐
│                  Hyperliquid L1                   │
│              HyperBFT Consensus                   │
│           Sub-second finality                     │
│           200K+ orders/second                     │
│                                                   │
│  ┌────────────────────┐  ┌─────────────────────┐ │
│  │     HyperCore       │  │     HyperEVM        │ │
│  │  (Native Trading)   │  │  (Smart Contracts)  │ │
│  │                     │  │                     │ │
│  │  Order books        │  │  EVM-compatible     │ │
│  │  Matching engine    │  │  Shares consensus   │ │
│  │  Clearing           │  │  with HyperCore     │ │
│  │  50x leverage       │  │                     │ │
│  │  Cross/Isolated     │  │  Chain ID: 999      │ │
│  │                     │  │  (mainnet)          │ │
│  │  REST: /info, /exch │  │                     │ │
│  │  WS: 19 channels    │  │  RPC: rpc.hyper...  │ │
│  └────────────────────┘  └─────────────────────┘ │
│                                                   │
│  Signing: EIP-712                                 │
│  L1 actions: chainId 1337                         │
│  User-signed: chainId 42161                       │
└─────────────────────────────────────────────────┘
```

---

## S2 — Decision Trees

### Which SDK?

```
Python project?
├── Need full control + low latency?        → hyperliquid-python-sdk (official, v0.22.0)
├── Need multi-exchange support?            → CCXT (hyperliquid connector)
└── Need quick prototyping?                 → hyperliquid-python-sdk

TypeScript project?
├── Need modular, type-safe, latest API?    → @nktkas/hyperliquid (recommended, 326★)
├── Need high-level convenience API?        → nomeida/hyperliquid (268★, Node 22+)
└── Need multi-exchange support?            → CCXT
```

### Which order type?

```
Want to rest on book?                       → Limit GTC: {"limit": {"tif": "Gtc"}}
Want to fill-or-kill immediately?           → Limit IOC: {"limit": {"tif": "Ioc"}}
Want post-only (maker rebate)?              → Limit ALO: {"limit": {"tif": "Alo"}}
Want market order?                          → IOC + aggressive price (3-5% slippage)
Want stop-loss?                             → {"trigger": {"triggerPx": "X", "isMarket": true, "tpsl": "sl"}}
Want take-profit?                           → {"trigger": {"triggerPx": "X", "isMarket": true, "tpsl": "tp"}}
Want to execute large size over time?       → TWAP: {"type": "twapOrder", ...}
```

### Which signing mechanism?

```
Trading action (order, cancel, modify,
  leverage, TWAP, scheduleCancel)?          → L1 / Phantom agent (chainId 1337)

Transfer, withdrawal, approveAgent,
  approveBuilderFee, staking?               → User-signed / Direct EIP-712 (chainId 42161)
```

### REST vs WebSocket?

```
One-off data fetch?                         → REST POST /info
Need real-time streaming?                   → WebSocket subscription
Need lowest latency for orders?             → WebSocket post (method: "post")
Need both data + orders in one connection?  → WebSocket (subscribe + post)
```

---

## S3 — 10 Commandments

1. **No trailing zeros** in price/size strings. `"50000"` not `"50000.0"`. `"0.01"` not `"0.010"`.
2. **Query with master address**, not agent wallet address. Agent wallets are stateless signers.
3. **Separate API wallets per trading process**. Nonces are per-signer — shared wallets cause collisions.
4. **Correct chainId**: `1337` for L1 actions, `42161` for user-signed actions (mainnet). Never mix.
5. **Exponential backoff for WebSocket** reconnection. Disconnects happen without warning.
6. **Use scheduleCancel** (dead man's switch) for safety. Max 10 per day, ≥5s in future.
7. **Batch ALO orders separately** from IOC/GTC. ALO-only batches get validator priority.
8. **Max 10x leverage** (community consensus). Platform allows up to 50x but risk is extreme.
9. **Use cloid** (client order ID) for idempotent order tracking across reconnections.
10. **Handle both batch-level AND per-order errors**. A single pre-validation error may cover the entire batch.

---

## S4 — Core Code Patterns

### Python: Setup + Limit Order + Market Order + Close

```python
import eth_account
from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from hyperliquid.utils import constants
from hyperliquid.utils.types import Cloid

# Setup
wallet = eth_account.Account.from_key("0xPRIVATE_KEY")
info = Info(constants.MAINNET_API_URL, skip_ws=True)
exchange = Exchange(wallet, constants.MAINNET_API_URL, account_address=wallet.address)

# For API wallets: secret_key = agent wallet key, account_address = MASTER wallet address
# exchange = Exchange(agent_wallet, constants.MAINNET_API_URL, account_address="0xMASTER")

# Set leverage (cross 5x)
exchange.update_leverage(5, "ETH", is_cross=True)

# Limit order with CLOID
cloid = Cloid.from_str("0x" + "a1" * 16)
result = exchange.order("ETH", True, 0.1, 2800.0, {"limit": {"tif": "Gtc"}}, cloid=cloid)

# Market buy (IOC with slippage)
result = exchange.market_open("ETH", True, 0.05, slippage=0.01)

# Stop-loss
exchange.order("ETH", False, 0.1, 2600.0,
    {"trigger": {"triggerPx": "2650", "isMarket": True, "tpsl": "sl"}}, reduce_only=True)

# Close full position at market
exchange.market_close("ETH")

# Cancel by OID
exchange.cancel("ETH", oid)

# Cancel by CLOID
exchange.cancel_by_cloid("ETH", cloid)
```

### TypeScript: InfoClient + ExchangeClient + SubscriptionClient

```typescript
import {
  HttpTransport, InfoClient, ExchangeClient,
  SubscriptionClient, WebSocketTransport
} from "@nktkas/hyperliquid";
import { privateKeyToAccount } from "viem/accounts";

const wallet = privateKeyToAccount("0xPRIVATE_KEY");
const transport = new HttpTransport();

// Info (read-only)
const info = new InfoClient({ transport });
const mids = await info.allMids();
const book = await info.l2Book({ coin: "ETH" });
const state = await info.clearinghouseState({ user: "0x..." });

// Exchange (trading)
const exchange = new ExchangeClient({ transport, wallet });
await exchange.order({
  orders: [{ a: 1, b: true, p: "2800", s: "0.1", r: false, t: { limit: { tif: "Gtc" } } }],
  grouping: "na",
});
await exchange.cancel({ cancels: [{ a: 1, o: 12345 }] });

// Subscriptions (WebSocket)
const subs = new SubscriptionClient({ transport: new WebSocketTransport() });
await subs.l2Book({ coin: "ETH" }, (data) => {
  console.log("Best bid:", data.levels[0][0]?.px);
});
await subs.trades({ coin: "ETH" }, (trades) => {
  for (const t of trades) console.log(`${t.side} ${t.sz} @ ${t.px}`);
});
```

---

## S5 — Recommended Project Structure

```
my-hyperliquid-bot/
├── config/
│   ├── settings.py          # API URLs, leverage limits, risk params
│   └── .env                 # PRIVATE_KEY, ACCOUNT_ADDRESS (never commit)
├── core/
│   ├── client.py            # SDK initialization (Info + Exchange)
│   ├── signer.py            # Authentication / API wallet setup
│   └── ws_manager.py        # WebSocket with auto-reconnection
├── strategies/
│   ├── base.py              # Abstract strategy interface
│   ├── market_maker.py      # Example: spread quoting
│   └── grid.py              # Example: grid trading
├── risk/
│   ├── circuit_breaker.py   # Halt trading on anomalies
│   ├── position_limits.py   # Max size / drawdown checks
│   └── emergency.py         # Emergency shutdown procedure
├── data/
│   ├── orderbook.py         # L2 book maintenance
│   ├── positions.py         # Position state tracking
│   └── fills.py             # Fill tracking and PnL
├── utils/
│   ├── formatting.py        # Price/size formatting (no trailing zeros)
│   ├── retry.py             # Exponential backoff + jitter
│   └── logging.py           # Structured logging
├── main.py                  # Entry point: wire everything
├── requirements.txt         # hyperliquid-python-sdk, eth_account, websockets
└── tests/
    ├── test_formatting.py
    ├── test_strategy.py
    └── test_risk.py
```

---

## S6 — Reference Map

| # | File | Lines | When to Read |
|---|------|-------|-------------|
| 1 | `references/connection-and-endpoints.md` | ~350 | Setting up connections, asset indexing, testnet |
| 2 | `references/exchange-actions.md` | ~550 | Placing/modifying/canceling orders, TWAP, transfers |
| 3 | `references/info-queries.md` | ~500 | Market data, user state, funding, fees |
| 4 | `references/websocket-channels.md` | ~400 | Real-time streaming, reconnection, WS posting |
| 5 | `references/authentication-and-signing.md` | ~450 | EIP-712, phantom agent, nonces, API wallets |
| 6 | `references/rate-limits.md` | ~350 | IP/address limits, request weights, open order caps |
| 7 | `references/python-sdk.md` | ~400 | Python SDK: Info, Exchange, WebSocket, Cloid |
| 8 | `references/typescript-sdks.md` | ~400 | @nktkas, nomeida, CCXT integration |
| 9 | `references/risk-and-error-handling.md` | ~450 | Error codes, gotchas, emergency shutdown, risk patterns |
| 10 | `references/ecosystem-and-hips.md` | ~400 | HIP-1/2/3/4, staking, vaults, HyperEVM, community |
| 11 | `references/bot-architecture.md` | ~450 | 6-stage bot design, latency, open-source examples |

---

## S7 — Version Lock (February 2026)

| Component | Version / Value |
|-----------|----------------|
| hyperliquid-python-sdk | **0.22.0** (Python ≥3.9) |
| @nktkas/hyperliquid | latest (npm) |
| nomeida/hyperliquid | latest (Node.js 22+) |
| CCXT | latest (`ccxt.hyperliquid`) |
| Mainnet Chain ID (L1) | **1337** |
| Mainnet Chain ID (user-signed) | **42161** |
| Testnet Chain ID (user-signed) | **421614** |
| HyperEVM Mainnet Chain ID | **999** |
| HyperEVM Testnet Chain ID | **998** |
| EIP-712 domain (L1) | `{name: "Exchange", version: "1", chainId: 1337}` |
| EIP-712 domain (user) | `{name: "HyperliquidSignTransaction", version: "1", chainId: 42161}` |
| Phantom agent source | `"a"` (mainnet) / `"b"` (testnet) |
| Base fees (perps) | 0.045% taker / 0.015% maker |
| Base fees (spot) | 0.07% taker / 0.04% maker |
| Base fees (HIP-3 perps) | 0.09% taker / 0.03% maker |
| Funding | Hourly, 4% per hour cap |
| Max open orders | 1000 (base) + 1 per 5M USDC volume, cap 5000 |

---

## S8 — Common Gotchas

1. **Agent wallet address confusion**
   - ❌ `info.user_state("0xAGENT_WALLET")` → returns empty
   - ✅ `info.user_state("0xMASTER_ADDRESS")` → returns positions

2. **Trailing zeros in price/size**
   - ❌ `"p": "50000.0"` → rejected or wrong
   - ✅ `"p": "50000"` → correct

3. **Chain ID confusion (L1 vs user-signed)**
   - ❌ Using chainId 42161 for order signing → invalid signature
   - ✅ Using chainId 1337 for L1 actions, 42161 for transfers

4. **Nonce collisions with shared API wallets**
   - ❌ Two processes sharing one API wallet → nonce conflicts
   - ✅ One API wallet per trading process

5. **Asset remapping (UI ≠ API)**
   - ❌ Expecting "BTC/USDC" on mainnet HyperCore → might be "UBTC/USDC"
   - ✅ Always check `meta` response for actual asset names

6. **Batch error handling**
   - ❌ Only checking per-order statuses → missing batch-level error
   - ✅ Check both top-level response AND individual order statuses

7. **Minimum order value**
   - ❌ Placing a $5 order → "Order must have minimum value of $10."
   - ✅ Perps: $10 minimum; Spot: 10 quote tokens minimum

8. **WebSocket silent disconnects**
   - ❌ No reconnection logic → data stops flowing silently
   - ✅ Heartbeat ping every 50s + exponential backoff reconnection

9. **Testnet signing differences**
   - ❌ Using `"a"` as phantom agent source on testnet → wrong
   - ✅ Mainnet: `"a"`, Testnet: `"b"` / `"Testnet"` in hyperliquidChain

10. **msgpack field ordering for manual signing**
    - ❌ Serializing action fields in arbitrary order → signature mismatch
    - ✅ Use the SDK for signing or match exact field order from SDK source

---

## S9 — Decision Workflows

### Workflow 1: Set up a new Hyperliquid bot

1. Read `references/connection-and-endpoints.md` for URLs and testnet setup
2. Read `references/authentication-and-signing.md` for API wallet creation
3. Read `references/python-sdk.md` or `references/typescript-sdks.md` for SDK setup
4. Start with **testnet** — claim 1,000 mock USDC from faucet
5. Initialize Info + Exchange clients with testnet URLs
6. Verify connectivity: `info.all_mids()` should return prices

### Workflow 2: Place and manage orders

1. Read `references/exchange-actions.md` for order types and fields
2. Format prices/sizes as strings with **no trailing zeros**
3. Use `cloid` for every order to enable tracking across reconnections
4. Handle responses: check `statuses[]` for `resting`, `filled`, or `error`
5. For stop/take-profit: use `grouping: "normalTpsl"` to group with entry

### Workflow 3: Real-time data streaming

1. Read `references/websocket-channels.md` for channel details
2. Connect to `wss://api.hyperliquid.xyz/ws`
3. Send heartbeat `{"method": "ping"}` every 50 seconds
4. Subscribe to needed channels (l2Book, trades, orderUpdates, etc.)
5. Implement exponential backoff reconnection (1s → 2s → 4s → ... → 60s max)
6. On reconnect: re-subscribe and reconcile state via REST snapshot

### Workflow 4: Risk management

1. Read `references/risk-and-error-handling.md` for error codes and patterns
2. Set up `scheduleCancel` (dead man's switch) — refreshed every few minutes
3. Monitor `liquidationPx` from `clearinghouseState` vs current `markPx`
4. Implement circuit breaker: halt on consecutive errors or anomalous price moves
5. Emergency shutdown: scheduleCancel → cancel all orders → market close all positions

### Workflow 5: HIP-3 permissionless perps

1. Read `references/ecosystem-and-hips.md` for HIP-3 details
2. Query `perpDexs` and `allPerpMetas` for available HIP-3 markets
3. Use asset format `"dex_name:ASSET_NAME"` for orders
4. Note: HIP-3 perps are **isolated-only margin**, higher fees (0.09%/0.03%)

### Workflow 6: Testnet development

1. Read `references/connection-and-endpoints.md` § Testnet
2. Use testnet URLs: `https://api.hyperliquid-testnet.xyz`
3. Claim mock USDC: `POST /info` with `{"type": "claimDrip", "user": "0x..."}`
4. Use `"Testnet"` in `hyperliquidChain`, `"b"` as phantom agent source
5. Validate technical flows — don't rely on testnet for performance testing

---

## S10 — Helper Script

A reusable helper is available at `scripts/hyperliquid_helper.py`. It provides:

- **CircuitBreaker**: CLOSED/OPEN/HALF_OPEN states, decorator pattern
- **RetryWithBackoff**: Exponential backoff + jitter for rate limits
- **PriceFormatter**: Remove trailing zeros, round to tick size
- **HyperliquidHelper**: Wrapper class for SDK — market data, account state, trading, position management, risk management, transfers, monitoring
- **WebSocketManager**: Async WS with auto-reconnection, heartbeat, subscription tracking

### Usage as module

```python
from hyperliquid_helper import HyperliquidHelper

helper = HyperliquidHelper(
    private_key="0xPRIVATE_KEY",
    account_address="0xACCOUNT",
    testnet=False,
)

# Market data
mids = helper.get_all_mids()
book = helper.get_orderbook("ETH")

# Trading
result = helper.place_limit_order("ETH", is_buy=True, size=0.1, price=2800.0)
helper.place_market_order("ETH", is_buy=True, size=0.05)
helper.close_position("ETH")

# Risk management
helper.emergency_shutdown()
```

### Usage as CLI

```bash
# Market data
python hyperliquid_helper.py market-data --coin ETH

# Account state
python hyperliquid_helper.py account-state --address 0x...

# Monitor positions
python hyperliquid_helper.py monitor --address 0x... --interval 5

# Emergency shutdown
python hyperliquid_helper.py emergency-shutdown --key 0x... --address 0x...

# Place order
python hyperliquid_helper.py place-order --key 0x... --address 0x... \
    --coin ETH --side buy --size 0.1 --price 2800

# Snapshot (save full state to JSON)
python hyperliquid_helper.py snapshot --address 0x... --output state.json
```

---

## Cross-Skill Integration

### convex-skill
Store trade history, position snapshots, and PnL data in Convex tables. Hyperliquid API calls MUST run in Convex **actions** (not queries/mutations). Use `ctx.scheduler.runAfter()` from mutations to trigger trading actions. Reactive queries let dashboards update in real-time as trades and positions are recorded. Use crons to periodically snapshot account state.

```typescript
// convex/trading.ts — Convex action
"use node";
import { action } from "./_generated/server";
import { HyperliquidHelper } from "./hyperliquid_helper";

export const placeOrder = action({
  args: { coin: v.string(), isBuy: v.boolean(), size: v.number(), price: v.number() },
  handler: async (ctx, args) => {
    const helper = new HyperliquidHelper(process.env.HL_PRIVATE_KEY!, process.env.HL_ACCOUNT!);
    const result = await helper.place_limit_order(args.coin, args.isBuy, args.size, args.price);
    await ctx.runMutation(internal.trades.record, { coin: args.coin, result });
    return result;
  },
});
```

### supabase-skill
Use Supabase for portfolio tracking and historical analytics. Store trade fills, funding payments, and daily PnL snapshots in PostgreSQL tables. Use `pg_cron` to periodically fetch account state from Hyperliquid and update portfolio tables. Edge Functions can serve as webhook-like endpoints for position alerts.

### nextjs-web
Build a trading dashboard with Next.js. Use Server Components for cached market overview data (all mids, funding rates) and Client Components for real-time WebSocket feeds (orderbook, trades). API routes can proxy Hyperliquid REST calls. Never expose private keys in client code — all signing happens server-side.

### stripe-skill / nowpayments-skill
For deposit/withdrawal flows: use **Stripe** for fiat on-ramp (user pays USD → your system deposits USDC to Hyperliquid via transfer API) and **NOWPayments** for crypto deposits (user pays any crypto → convert to USDC → deposit). Track deposit status in your database and reconcile with Hyperliquid balance via `clearinghouseState`.

---

## Next Steps

Read the reference files based on your task:
- **Setting up from scratch?** → `references/connection-and-endpoints.md` + `references/authentication-and-signing.md`
- **Placing orders?** → `references/exchange-actions.md`
- **Querying data?** → `references/info-queries.md`
- **Real-time streaming?** → `references/websocket-channels.md`
- **Using Python SDK?** → `references/python-sdk.md`
- **Using TypeScript?** → `references/typescript-sdks.md`
- **Handling errors / risk?** → `references/risk-and-error-handling.md`
- **Understanding rate limits?** → `references/rate-limits.md`
- **Understanding HIPs / ecosystem?** → `references/ecosystem-and-hips.md`
- **Building a trading bot?** → `references/bot-architecture.md`
