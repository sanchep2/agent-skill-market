# docs-as-code — Skill de Claude Code

Documentación como código: framework **Diátaxis** (tutoriales, how-tos, referencia, explicación),
**ADRs** en formato MADR 4.0, y un **pipeline de CI** para docs (markdownlint + vale + cspell +
lychee). La documentación vive en `docs/` dentro del repo, se revisa en PRs y se valida en CI como
parte del "definition of done".

## Contenido

- `SKILL.md` — punto de entrada: flujo de 6 pasos, tabla de decisión por tipo de cambio, gotchas.
- `references/diataxis.md` — reglas detalladas de cada uno de los 4 tipos Diátaxis.
- `references/templates.md` — plantillas listas para copiar (tutorial, how-to, referencia,
  explicación, ADR MADR, runbook, entrada de CHANGELOG).
- `references/ci-pipeline.md` — workflow de GitHub Actions y configuración de los linters de docs.

## Instalación

1. Descomprime el ZIP.
2. Copia la carpeta `docs-as-code/` a una de estas ubicaciones:
   - **Global (todos tus proyectos)**: `~/.claude/skills/docs-as-code/`
   - **Solo este proyecto**: `<tu-proyecto>/.claude/skills/docs-as-code/`
3. Reinicia Claude Code para que detecte el skill.

Verifica que quede así (ejemplo global):

```
~/.claude/skills/docs-as-code/
├── SKILL.md
└── references/
    ├── diataxis.md
    ├── templates.md
    └── ci-pipeline.md
```

## Uso

Claude Code carga el skill automáticamente cuando pides documentar algo ("documenta esto",
"crea un ADR", "actualiza los docs", "agrega docs al PR", …). También puedes invocarlo de forma
explícita mencionándolo por su nombre.

---

Cortesía de Talent Academy · Vibe Coder.
