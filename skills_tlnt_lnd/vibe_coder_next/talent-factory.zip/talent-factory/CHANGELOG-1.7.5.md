# Distribución 1.7.5 — cambios y migración

Base: distribución 1.7.4. Arregla la calibración de los panes cuando el auditor de los canales
es Codex (`codex=si` en el cuestionario): F7 no conseguía clasificar ninguna captura de `v:.1`.
Con Claude como auditor (`codex=no`) no cambia nada: las reglas de Claude, sus capturas y sus
pruebas son las de 1.7.4.

## A quién afecta

A toda instalación que declaró Codex como auditor. El analizador del TUI solo conocía el aspecto
de Claude: con Codex no localizaba el compositor, cada estado se descartaba con «limpia la
pantalla y repite» o «vuelve a provocar el estado», y el alumno repetía sin poder registrar el
par. Si hubiera pasado de F7, el despacho de F8 se habría parado con «CLI … sin calibrar».

## Cambios

- **El analizador elige sus reglas por el CLI de cada panel.** Cada entrada por panel del
  despacho y del relevo fija el perfil del TUI (`TCO_TUI_CLI`) con el CLI declarado de ese
  panel (`TCO_DEV_CLI` en `.0`, `TCO_AUDIT_CLI` en `.1`), y los fijadores de la calibración lo
  derivan del `cli:versión` ya validado. Vacío o `claude` conserva las reglas de siempre,
  sin un solo cambio; `codex` usa las nuevas; cualquier otro valor da «sin estructura» (rc 2)
  y nunca cae en reglas ajenas. `00-config.sh` desfija la variable, así que ninguna perilla
  heredada del entorno ni de `agents.conf` puede saltarse la calibración.
- **Reglas de Codex tan estrictas como las de Claude.** El compositor de Codex no tiene bordes:
  se acepta solo la estructura completa, desde el final de la captura y en orden (línea vacía,
  compositor `›`, línea vacía y línea de estado con modelo, ruta y título, con o sin pie). Nunca
  vale una pieza suelta: un selector, un eco de usuario o un pie solos dan rc 2. La lista de
  órdenes que abre `/model` («barra») tiene su rama propia. «Ocupado» lo decide solo la última
  línea en columna 0 del transcript, con la forma `• Palabra (… esc to interrupt …)`. El marcador
  parpadea entre `•` y `◦` en terminales sin truecolor, y falta con el movimiento reducido: valen los
  tres, y ningún otro glifo. Con un borrador en el compositor, Codex deja bajo la línea de estado solo
  lo de la derecha (como «⚠ 1 warning · f2 to view» o el contexto): también vale como pie, y el relay
  al auditor ya no se queda sin someter. Una cita de
  «esc to interrupt» en otro mensaje, o en el título de la línea de estado, no ocupa el panel, y
  una forma de temporizador que no cierra bien da rc 2. Las anomalías de cola y de encuesta son
  de Claude y no aplican a Codex; el diálogo de confianza y el selector sí.
- **Capturas reales de codex-cli 0.166.0** en `skills/talent-channel-operation/tests/fixtures/pane/codex_0.166.0/`
  (los seis estados de la calibración y nueve capturas con color de las órdenes de F7), con la
  prueba `tests/test-tui-codex.sh`: sin cruce entre perfiles en ninguna dirección, en locale `C` y
  `C.UTF-8`.
- **`f8-capturas.sh` y `calibrar-pane.sh` no meten en un bucle.** Con una versión de Codex sin
  capturas de referencia en el paquete, un fallo de clasificación ya no pide «vuelve a provocar el
  estado»: dice que se repita UNA vez y, si vuelve a fallar, que se pare y se escale con las
  capturas, porque el TUI de esa versión puede haber cambiado. Con Claude, y con las versiones que
  traen referencias, los mensajes son los de siempre. Ningún mensaje imprime el contenido de la
  pantalla. `calibrar-pane.sh` deduce el perfil del nombre del directorio `<cli>_<versión>`.
- **F7** declara qué CLI se calibran, dónde están las capturas de referencia, que `v:.1` con Codex
  se calibra igual y qué hacer si una clasificación falla dos veces. En Codex, `/model` más Enter
  abre «Select Model and Effort» y Escape lo cierra.
- **Con `codex=si`, EMPIEZA-AQUI instala Codex en el host y F3 lo recuerda antes de `codex login`.**
  La orden es `sudo npm install -g @openai/codex`, en un bloque propio para que quien responda
  `codex=no` no la ejecute. Sin `codex` en el host, `auth-move` abortaba en el health-check del
  donante.
- **F4 trata el 403 de plan de las reglas efectivas como privado gratuito.** En un repo privado sin
  rulesets, `rules/branches/<rama>` responde 403 «Upgrade to GitHub Pro…» y `f4-proteccion` y
  `check-F4` caían en rojo antes de llegar al pendiente procedimental. Ahora solo ese 403 exacto
  sigue al camino de privado gratuito; cualquier otro fallo (otro 403, 404, 5xx, red) sigue en rc 1.
  Con ese mismo 403 en el PUT de protección, `f4-proteccion --ejecutar` aplica y relee los ajustes del
  repo (antes abortaba sin PATCH y check-F4 caía en rojo en A2b) y termina con rc 3, pendiente procedimental.
- **La identidad del pane reconoce el Codex de npm cuando `codex.js` hace execve al binario nativo.**
  Con Node reciente, el `bin/codex.js` de `@openai/codex` hace `process.execve` al binario nativo de la
  plataforma y en el pane no queda ningún proceso node: `preparar-sesiones --ejecutar` decía «el pane de
  auditoría NO ejecuta 'codex'» aunque Codex estuviera corriendo. Ahora, solo si el ejecutable esperado es
  `<raíz>/bin/codex.js` y el `package.json` de esa raíz se llama `@openai/codex`, la identidad acepta también
  el binario nativo del paquete para la arquitectura de la máquina (`x86_64` o `aarch64`, triples musl, como
  `codex.js`), con la contención en la raíz del paquete: un enlace que sale de ella, otra arquitectura o un
  `package.json` de otro nombre no acreditan nada. La acreditación de la sonda no cambia de forma; el
  caso `spawn` (node más `codex.js`) sigue valiendo.
- **F4 ya no deja ficheros del paquete fuera de git por culpa del `.gitignore` del repositorio.**
  Si el `.gitignore` del producto ignoraba `lib/` (plantilla de Python), el fichero
  `.claude/skills/talent-repo-onboarding/scripts/lib/lectura_estable.py` quedaba ignorado y sin
  commit, los clones de C1 y M1 nacían sin él y una actualización posterior con `--sustituir` se
  paraba por «hay ignorados». También se cubre `*.manifest` (la misma plantilla ignoraba
  `package.manifest` y `creds.manifest`). El onboarding abre ahora una excepción, en el bloque de
  fábrica del `.gitignore`, solo para los ficheros del paquete que de verdad estaban ignorados: unas
  veinte líneas con las plantillas oficiales de Python y Node, sin reincluir los `.env.local`, las
  cachés ni los skills del alumno, y todo lo que el alumno ya ignoraba fuera del paquete sigue
  igual. Al repetir el onboarding tras una actualización, un fichero nuevo del paquete en una ruta
  ignorada también queda abierto y ninguna línea del bloque se duplica. Si `package.manifest` falta o
  está malformado, F4 se detiene con un error claro en lugar de seguir sin saber qué es del paquete.
- **La adjudicación ya no copia cachés de Python al repositorio del alumno.** Si el paquete traía un
  `__pycache__/` o un `*.pyc` dentro de `skills/` (lo creaba F4 al importar el helper de lectura
  estable cuando el paquete era escribible), la adjudicación lo copiaba al repositorio, donde el
  `.gitignore` del alumno lo ignora, y la siguiente actualización con `--sustituir` se paraba por «hay
  ignorados». Ahora el copiado de miembros y la sincronización (`sync-package.sh`, tanto el
  `--check` como el `--apply`) saltan `__pycache__/` y `*.pyc`, y F4 deja de escribir bytecode al
  importar ese helper. Un `.pyc` que ya esté en el destino no cuenta como deriva y la sincronización
  ni lo toca ni lo borra. La comparación de la adjudicación entre un miembro ya instalado y el
  paquete también ignora las cachés (la misma regla que el sellado del núcleo), así que una caché
  suelta de un lado u otro ya no obliga a repetir con `--sustituir`; la comprobación previa a
  `--sustituir` descarta igual las cachés ignoradas o sin seguimiento ya instaladas en el miembro
  (un ignorado que no es caché, un cambio o una caché bajo seguimiento modificada siguen parándola).

## Límites declarados

- Solo hay capturas de referencia de codex-cli 0.166.0. Cada versión nueva de Codex se calibra con
  sus propias capturas, en el F7 de la instalación; sin ellas no se registra.
- La anchura de referencia es la de las capturas, 200 columnas. Con menos, un pie que se envuelva en
  dos líneas, o una ruta abreviada con «…», da rc 2 (falla cerrado) y no es un fallo del analizador.
- No se han observado las continuaciones de descripción de las filas de la lista de órdenes, el
  diálogo de confianza de Codex ni el aviso de actualización; el golden preconfía el directorio y
  desactiva la comprobación de actualización.
- Residuo declarado, el mismo que tiene Claude con `●`: un mensaje cuya primera línea sea
  `• Working (… esc to interrupt)` es indistinguible de la línea de ocupado.
- F4 reabre en el `.gitignore` solo los ficheros del paquete que de verdad quedan ignorados. Si el
  repositorio ignora `.claude/`, `scripts/` o `*.md` enteros, el bloque de la fábrica crece hasta
  cientos de líneas; sigue siendo correcto.
- Si añades reglas después de `# fabrica:fin` o un `.gitignore` anidado, puedes volver a ocultar
  ficheros del paquete.
- **Segunda presentación del plan con Claude Code 2.1.318 (defecto conocido, se arregla en la versión siguiente).** Si el
  plan-gate rechaza un plan y el dev lo vuelve a presentar con el diálogo de plan (ExitPlanMode),
  `extract-plan.sh` sale con rc 19 («plan RECHAZADO… sin nueva presentación»). Claude no escribe esa
  presentación en el transcript mientras el diálogo sigue abierto. Salida: contesta el diálogo del
  pane dev con la opción 3, «Tell Claude what to change», con este texto, cambiando `<ENC>` por el
  `TAL-N` del encargo:
  «Presenta el plan corregido como TEXTO normal, entre PLAN-INICIO <ENC> y PLAN-FIN, sin
  ExitPlanMode ni modo plan.»
  Después relanza `extract-plan.sh`, que lo toma como texto con ancla del turno vigente.

## Migración desde 1.7.4

- **Auditor Claude (`codex=no`).** Nada que repetir. Actualiza el paquete; F0 comprueba el núcleo
  nuevo.
- **Auditor Codex (`codex=si`).** Actualizar solo el paquete no basta. Los panes ejecutan los skills
  desde el repositorio y desde los clones de C1 y M1, que conservan los de 1.7.4. Además, si el
  `.gitignore` propio del repositorio ignora `lib/` (frecuente en plantillas de Python), F4 de 1.7.4
  dejó fuera de git `.claude/skills/talent-repo-onboarding/scripts/lib/lectura_estable.py`: los
  clones de C1 y M1 no lo tienen y `--sustituir` se detiene porque hay un ignorado. Con las
  variables del primer bloque de F4:
  1. Si no tienes `codex` en el host, instálalo con `sudo npm install -g @openai/codex` antes de
     `codex login` y `auth-move`. Actualiza el paquete en su carpeta permanente y pasa F0.
  2. Guarda en el historial los ficheros del paquete que quedaron ignorados. La tercera orden los
     lista. Si sale un directorio entero (`!! …/scripts/lib/`), añade los ficheros del paquete que
     hay dentro. Añade solo ficheros del paquete; nunca secretos ni `.env`. Un `__pycache__` o un
     `*.pyc` bajo `.claude/skills/` es caché del propio paquete: bórralo del árbol de trabajo
     (`rm -r` de ese directorio) en lugar de añadirlo.

     ```bash
     git -C "$CLON" switch main
     git -C "$CLON" pull --ff-only origin main
     git -C "$CLON" status --ignored --porcelain --untracked-files=all .claude/skills
     git -C "$CLON" switch -c chore/actualizar-fabrica-1-7-5
     git -C "$CLON" add -f .claude/skills/talent-repo-onboarding/scripts/lib/lectura_estable.py
     # y cada otro fichero del paquete que haya listado la tercera orden; con la plantilla de Python,
     # también skill-creator/assets/package.manifest y talent-channels/assets/creds.manifest
     git -C "$CLON" commit -m 'chore(producto): versionar ficheros ignorados del paquete'
     cd "$CLON"
     bash scripts/audit-go.sh
     bash scripts/draft-handoff.sh
     git -C "$CLON" push -u origin chore/actualizar-fabrica-1-7-5
     gh pr create --repo "$REPO" --head chore/actualizar-fabrica-1-7-5 --base main --title 'Versionar ficheros del paquete' --body 'Migración de 1.7.4 a 1.7.5.'
     ```

     Fusiona ese PR como en F4 y vuelve a `main` con `git -C "$CLON" pull --ff-only origin main`.
     `git -C "$CLON" status --ignored --porcelain --untracked-files=all .claude/skills` ya no debe
     listar nada.
  3. Repite la adjudicación de F4. La primera vez sale con rc 3 y enumera los miembros distintos;
     repítela añadiendo `--sustituir <miembro>` por cada uno de ellos. Debe terminar con «PARIDAD-NUCLEO:
     OK» e «IDENTIDAD ADJUDICADA».
  4. Repite el onboarding de F4 (`f4-onboarding.sh --plan` y `f4-onboarding.sh`) y su commit, con la
     línea `git add` de F4. La rama `chore/contrato-fabrica` ya existe de la primera instalación: usa
     `chore/contrato-fabrica-1-7-5`. Después, `audit-go.sh`, `draft-handoff.sh`, push, PR y fusión, como
     en F4. Desde 1.7.5 el onboarding deja abiertos en el `.gitignore` los ficheros del paquete, así que
     el paso 2 ya no hará falta en las próximas actualizaciones.
  5. Lleva los clones de C1 y M1 a `main`, cada uno con su usuario: `git -C <clon> pull --ff-only origin
     main`. Comprueba que tienen `lectura_estable.py` y que el `lib.sh` de talent-channel-operation es el
     del paquete (`sha256sum`).
  6. Repite F5 (`preparar-modelo-canal`, `preparar-sesiones --ejecutar` y `check-F5`) y F7 en `v:.1` con
     `TCO_PANE_CLI_VERSION_CMD='codex --version'`: los seis estados y el registro del par.
- **Una versión de Codex distinta de 0.166.0.** Calíbrala con sus capturas en F7. Si dos intentos
  seguidos fallan, para y escala con el mensaje de la orden y una captura de la pantalla.
