#!/usr/bin/env python3
"""Recorrido F8 con código real y dobles de las cuatro interfaces externas."""
import io
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile

PACKAGE = Path(__file__).resolve().parents[2]
PASS = FAIL = 0


def expect(label, condition, output=''):
    global PASS, FAIL
    if condition:
        PASS += 1
        print('PASS '+label, flush=True)
    else:
        FAIL += 1
        print('FAIL '+label+' '+output[:600], flush=True)


with tempfile.TemporaryDirectory(prefix='f8-secuencia-') as td:
    t = Path(td)
    pkg = t/'paquete'
    shutil.copytree(PACKAGE, pkg, ignore=shutil.ignore_patterns('.git', 'estado', 'generado', '__pycache__'))
    state = pkg/'instalacion/estado'
    state.mkdir(mode=0o700)
    home = t/'hogar'
    home.mkdir(mode=0o700)
    clone = t/'producto'
    clone.mkdir()
    shutil.copytree(pkg/'scripts', clone/'scripts')
    shutil.copytree(pkg/'skills/talent-channel-operation', clone/'.claude/skills/talent-channel-operation')
    subprocess.run(['git', 'init', '-q', str(clone)], check=True)
    manifest = clone/'.claude/tf-manifest.conf'
    manifest.write_text('TF_LINEAR_TEAM_KEY="ABC"\nTF_SENSITIVE_SURFACES="auth credenciales"\n')
    answers = (pkg/'instalacion/tests/fixtures/minima.resp').read_text()
    user = pwd.getpwuid(os.getuid()).pw_name
    answers = answers.replace('usuario_ceo=operador', 'usuario_ceo='+user).replace('usuario_incus=ejemplo-incus', 'usuario_incus='+user)
    (state/'respuestas.resp').write_text(answers)
    (state/'contexto.conf').write_text('respuestas='+str(state/'respuestas.resp')+'\nhome='+str(home)+'\nclon='+str(clone)+'\n')
    envdir = home/'ejemplo'
    envdir.mkdir(mode=0o700)
    (envdir/'.env.local').write_text('LINEAR_API_KEY=secreto-sintetico-reservado\n')
    (envdir/'.env.local').chmod(0o600)
    escrow = home/'.config/talent-channels'
    escrow.mkdir(parents=True, mode=0o700)
    conf = home/'.config/talent-channel-operation/agents.conf'
    conf.parent.mkdir(mode=0o700)
    conf.write_text('TCO_DEV_CLI="claude"\nTCO_AUDIT_CLI="claude"\n')
    conf.chmod(0o600)
    binpath = t/'bin'
    binpath.mkdir()
    head = 'a'*40
    headers = ['Qué hace', 'Decisiones y porqués', 'Invariantes sellados por el code-audit',
               'Superficies tocadas y clasificación', 'Migraciones', 'Archivos calientes',
               'Verificación local ejecutada', 'Qué NO tocar / trampas', 'Bloque machine-readable']
    handoff = dict(schema_version=2, build='validado', issues=['ABC-1'], head_sha=head,
                   branch='docs/humo', sensitive=False, destructive=False, surfaces=[], migration_slots=[])
    comment = '## HANDOFF\n'+'\n'.join('### '+h+'\nTexto de prueba.' for h in headers)+'\n```json\n'+json.dumps(handoff)+'\n```\n'
    pr = dict(number=1, state='OPEN', isDraft=True, headRefOid=head, headRefName='docs/humo',
              mergeCommit={'oid':'b'*40}, body='Closes ABC-1', comments=[{'body':comment}],
              files=[{'path':'docs/humo.md'}], statusCheckRollup=[{'name':'local-gates', 'conclusion':'SUCCESS'},
                  {'name':'revision-opcional', 'conclusion':None, 'status':'IN_PROGRESS'}])
    pr_path = t/'pr.json'
    pr_path.write_text(json.dumps(pr))
    external = '''#!/usr/bin/env python3
import json,os,sys,stat,subprocess
from pathlib import Path
tool=Path(sys.argv[0]).name
args=sys.argv[1:]
if os.environ.get('F8_FAIL')==tool: sys.exit(7)
if tool=='gh':
    if args[:2]==['pr','view']: print(Path(os.environ['F8_PR_DATA']).read_text())
    else: print(json.dumps({'sha':'a'*40,'statuses':[{'context':'local-gates','state':'success'}]}))
elif tool=='curl':
    assert 'secreto-sintetico-reservado' not in ' '.join(args)
    p=Path(args[args.index('--header')+1][1:])
    assert stat.S_IMODE(p.stat().st_mode)==0o600
    assert p.parent==Path(os.environ['F8_ESCROW'])
    if os.environ.get('F8_LINEAR_ERRORS'):
        print(json.dumps({'errors':[{'message':'Consulta rechazada'}]}))
        sys.exit(0)
    if os.environ.get('F8_LINEAR_POR_ID'):
        # Estado por identificador consultado (sustitución: anterior y nueva); null = estado ilegible.
        asked=json.loads(args[args.index('--data')+1])['variables']['id']
        states=json.loads(os.environ['F8_LINEAR_POR_ID'])
        if asked not in states:
            print(json.dumps({'errors':[{'message':'Entity not found'}]}))
            sys.exit(0)
        row={'identifier':asked,'title':'Cambio de documentación',
             'createdAt':os.environ.get('F8_LINEAR_CREATED','2026-10-04T12:00:00Z')}
        if states[asked] is not None: row['state']={'name':states[asked]}
        print(json.dumps({'data':{'issue':row}}))
        sys.exit(0)
    print(json.dumps({'data':{'issue':{'identifier':os.environ.get('F8_LINEAR_ISSUE','ABC-1'),
      'title':os.environ.get('F8_LINEAR_TITLE','Cambio de documentación'),
      'createdAt':os.environ.get('F8_LINEAR_CREATED','2026-10-04T12:00:00Z'),
      'state':{'name':os.environ.get('F8_LINEAR_STATE','Todo')}}}}))
elif tool=='incus':
    command=' '.join(args)
    if 'display-message' in command: print('101')
    elif 'bash -c' in command: print('claude')
    elif '--version' in command: print('9.8.7 (Claude Code)')
    elif 'capture-pane' in command: subprocess.run(['tmux','capture-pane'],check=True)
    else: sys.exit(2)
elif tool=='tmux':
    print(Path(os.environ['F8_SCREEN']).read_text())
'''
    for name in ('gh', 'curl', 'incus', 'tmux'):
        path = binpath/name
        path.write_text(external)
        path.chmod(0o755)
    # El encargo de M1 y el del coordinador nombran el clon de su rol: los usuarios de rol del ensayo no existen
    # en este sistema, así que getent los resuelve a un home sintético y delega todo lo demás.
    getent = binpath/'getent'
    getent.write_text('#!/usr/bin/env python3\nimport os, sys\n'
                      'a = sys.argv[1:]\n'
                      'if a[:1] == ["passwd"] and len(a) == 2 and a[1] in ("ejemplo-m1", "ejemplo-c1"):\n'
                      '    print(a[1]+":x:1000:1000::"+'+repr(str(t/'homes'))+'+"/"+a[1]+":/bin/bash")\n'
                      '    sys.exit(0)\n'
                      'os.execv('+repr(shutil.which('getent'))+', ["getent", *a])\n')
    getent.chmod(0o755)
    screen = t/'screen.txt'
    captures = home/'evidencias-fabrica/ejemplo/pane'
    # Las evidencias de F8 son por issue (evidencias-fabrica/<proyecto>/<ISSUE>/humo); las capturas de F7 no.
    evidence = home/'evidencias-fabrica/ejemplo/ABC-1/humo'
    # Cronología real: los originales del coordinador (humo) NO existen en C1 durante F7; los crea f8-conservar en F8.
    captures.parent.mkdir(parents=True, mode=0o700)
    runtime = dict(os.environ, HOME=str(home), HOST_HOME=str(home), SECRET_DIR=str(conf.parent),
                   PATH=str(binpath)+':'+os.environ['PATH'], F8_PR_DATA=str(pr_path), F8_ESCROW=str(escrow),
                   F8_SCREEN=str(screen), F8_ISSUE='ABC-1', F8_PR='1', TCO_FIXTURE_DIR=str(captures),
                   TCO_PANE_CLI_VERSION_CMD='claude --version', TCO_REPO_DIR=str(clone),
                   TCO_REPO_SLUG='org-example/producto', TCO_REPO_STACK='ninguno',
                   TCO_ANEXO_FILE=str(clone/'anexo.md'), TCO_LINEAR_INPROGRESS_STATE='progreso',
                   TCO_LINEAR_INREVIEW_STATE='revision', TCO_HOST_ENV_REL='.env.local')

    def cli(name, *args, data=None, extra=None):
        p = subprocess.run(['bash', str(pkg/'instalacion/scripts'/(name+'.sh')), *map(str, args)],
                           env=dict(runtime, **(extra or {})), input=data, capture_output=True)
        return p.returncode, (p.stdout+p.stderr).decode()

    def read(path):
        # Lectura que no aborta el recorrido: un fichero ausente cuenta como FAIL del caso, no como excepción.
        return path.read_bytes() if path is not None and path.is_file() else None

    # Las importaciones de C1 al instalador se ejecutan TAL COMO las dicen las guías: se lee el `tar ... -cf - <dirs> |
    # f8-importar.sh` de F7.md y de F8.md, y el archivo se arma con esos directorios en el momento en que la guía manda
    # ejecutarlo. Como tar real, un directorio ausente en C1 es un error (el resto sale, rc 2).
    # El directorio de C1 del que sale el archivo también se lee de la guía (`tar -C "<dir>"`), con las variables del
    # montaje sustituidas: así un directorio de humo fijo (sin issue) en la guía se nota en el recorrido.
    guide_tar = r'tar -C "([^"\n]+)" -cf - ([a-z ]+?) \| bash "\$PKG/instalacion/scripts/f8-importar\.sh"'

    def guide_imports(name):
        text = (pkg/'instalacion/fases'/(name+'.md')).read_text()
        return [found[1].split() for found in re.findall(guide_tar, text)]

    def guide_import_bases(name, issue='ABC-1'):
        text = (pkg/'instalacion/fases'/(name+'.md')).read_text()
        bases = []
        for found in re.findall(guide_tar, text):
            base = found[0].replace('$HOME_C1', str(home)).replace('$PROYECTO', 'ejemplo').replace('$ISSUE', issue)
            bases.append(Path(base) if '$' not in base else None)
        return bases

    def c1_tar(dirs, base):
        present = [d for d in dirs if base is not None and (base/d).is_dir()]
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode='w') as tar:
            for d in present:
                tar.add(base/d, arcname=d)
        return buffer.getvalue(), [d for d in dirs if d not in present]

    rc, output = cli('f8-originales', 'ABC-1')
    expect('original issue antes de despacho', rc == 0 and (state/'humo/issue.json').is_file(), output)
    initial = (state/'humo/issue.json').read_bytes()
    rc, output = cli('f8-originales', 'ABC-1', extra={'F8_LINEAR_STATE':'Done'})
    expect('consulta inicial tras Done conserva creación', rc == 0 and
           (state/'humo/issue.json').read_bytes() == initial and b'createdAt' in initial and b'state' not in initial, output)
    for label, extra in [('otra issue', {'F8_LINEAR_ISSUE':'ABC-2'}),
                         ('errores GraphQL', {'F8_LINEAR_ERRORS':'1'}),
                         ('título ausente', {'F8_LINEAR_TITLE':''}),
                         ('fecha ausente', {'F8_LINEAR_CREATED':''}),
                         ('fecha inválida', {'F8_LINEAR_CREATED':'2026-99-04T12:00:00Z'}),
                         ('creación distinta', {'F8_LINEAR_CREATED':'2026-10-03T12:00:00Z'})]:
        rc, output = cli('f8-originales', 'ABC-1', extra=extra)
        expect('consulta inicial rechaza '+label, rc == 1 and 'issue.json' in output and
               (state/'humo/issue.json').read_bytes() == initial, output)
    # issue 9011 (ensayo 174d): salida documentada para sustituir una issue de humo creada mal. Solo con la anterior
    # Canceled en Linear (estado leído del doble), antes del cierre; aparta el original sin borrarlo y deja traza.
    humo_dir = state/'humo'
    saved_humo = t/'humo-antes-sustituir'
    shutil.copytree(humo_dir, saved_humo)

    def humo_snapshot():
        return {p.name: p.read_bytes() for p in sorted(humo_dir.iterdir())} if humo_dir.is_dir() else None

    def humo_restore():
        shutil.rmtree(humo_dir)
        shutil.copytree(saved_humo, humo_dir)
        humo_dir.chmod(0o700)

    canceled = {'F8_LINEAR_POR_ID': json.dumps({'ABC-1': 'Canceled', 'ABC-2': 'Todo'})}
    # (a) Sin la salida: otra issue sigue rechazada y el mensaje nombra la salida.
    before = humo_snapshot()
    rc, output = cli('f8-originales', 'ABC-2', extra=canceled)
    expect('sustituir (a) sin --sustituir otra issue sigue rechazada', rc == 1 and 'consulta inicial distinta' in output and
           '--sustituir' in output and humo_snapshot() == before, output)
    rc, output = cli('f8-originales', 'ABC-1', '--sustituir', 'ABC-2', extra=canceled)
    expect('sustituir (a) la opción fuera de su forma no sustituye', rc == 2 and humo_snapshot() == before, output)
    rc, output = cli('f8-originales', '--sustituir', extra=canceled)
    expect('sustituir (a) sin NUEVA es uso inválido', rc == 2 and 'uso f8-originales --sustituir NUEVA' in output and
           humo_snapshot() == before, output)
    # (b) Verde: anterior Canceled → original apartado (mismo sha256), traza inmutable y original de la nueva.
    rc, output = cli('f8-originales', '--sustituir', 'ABC-2', extra=canceled)
    names = sorted(humo_dir.iterdir()) if humo_dir.is_dir() else []
    asides = [p for p in names if re.fullmatch(r'issue\.json\.ABC-1-sustituida-\d{8}T\d{6}Z', p.name)]
    traces = [p for p in names if p.name.endswith('.traza.json')]
    expect('sustituir (b) rc 0 y solo issue.json, el apartado y su traza', rc == 0 and len(names) == 3 and
           len(asides) == 1 and len(traces) == 1 and traces[0].name == asides[0].name+'.traza.json' and
           (humo_dir/'issue.json') in names, output)
    expect('sustituir (b) el original apartado conserva bytes y sha256', len(asides) == 1 and
           asides[0].read_bytes() == initial and
           hashlib.sha256(asides[0].read_bytes()).hexdigest() == hashlib.sha256(initial).hexdigest(), output)
    trace_record = json.loads(traces[0].read_text()) if len(traces) == 1 else {}
    expect('sustituir (b) traza con anterior, nueva, hora, estado y sha256 del apartado', len(asides) == 1 and
           trace_record == {'anterior': 'ABC-1', 'nueva': 'ABC-2', 'hora': asides[0].name.rsplit('-', 1)[1],
                            'estado_anterior': 'Canceled', 'apartado': asides[0].name,
                            'sha256': hashlib.sha256(initial).hexdigest()} and
           (traces[0].stat().st_mode & 0o777) == 0o600, json.dumps(trace_record))
    replaced = json.loads((humo_dir/'issue.json').read_text()) if (humo_dir/'issue.json').is_file() else {}
    expect('sustituir (b) issue.json es el original de la nueva', replaced == {'data': {'issue': {
           'identifier': 'ABC-2', 'title': 'Cambio de documentación', 'createdAt': '2026-10-04T12:00:00Z'}}}, output)
    expect('sustituir (b) cabecera temporal eliminada', not list(escrow.iterdir()))
    rc, output = cli('f8-originales', 'ABC-2', extra=canceled)
    expect('sustituir (b) el flujo normal sigue con la nueva', rc == 0, output)
    rc, output = cli('f8-originales', 'ABC-1', extra=canceled)
    expect('sustituir (b) la anterior ya no se acepta', rc == 1 and 'consulta inicial distinta' in output, output)
    # (c) La anterior no está cancelada: rc ≠ 0 y nada se mueve.
    for status in ('Todo', 'In Progress', 'Done'):
        humo_restore()
        before = humo_snapshot()
        rc, output = cli('f8-originales', '--sustituir', 'ABC-2',
                         extra={'F8_LINEAR_POR_ID': json.dumps({'ABC-1': status, 'ABC-2': 'Todo'})})
        expect('sustituir (c) anterior en '+status+' rechaza sin mover', rc == 1 and 'no Canceled' in output and
               'ABC-1' in output and humo_snapshot() == before, output)
    # (d) Negativos: cada condición falla con su diagnóstico y nada se mueve.
    negatives = [
        ('nueva igual a la anterior', ['ABC-1'], canceled, None, 'es la misma issue'),
        ('nueva con otra clave', ['OTRO-2'], canceled, None, 'F8: issue inválida'),
        ('nueva no consultable', ['ABC-3'], canceled, None, 'consulta Linear de ABC-3'),
        ('estado de la anterior ilegible', ['ABC-2'], {'F8_LINEAR_POR_ID': json.dumps({'ABC-1': None, 'ABC-2': 'Todo'})},
         None, 'state.name'),
        ('anterior con errores de Linear', ['ABC-2'], {'F8_LINEAR_ERRORS': '1'}, None, 'consulta Linear de ABC-1'),
        ('Linear caído', ['ABC-2'], dict(canceled, F8_FAIL='curl'), None, 'consulta Linear de ABC-1'),
        ('issue.json distinto de la anterior en Linear', ['ABC-2'], dict(canceled, F8_LINEAR_CREATED='2026-10-03T12:00:00Z'),
         None, 'no coincide con ABC-1'),
        ('sin issue.json', ['ABC-2'], canceled, 'sin-issue', 'no hay issue.json'),
        ('con merge.json', ['ABC-2'], canceled, 'merge.json', 'ya existe merge.json'),
        ('con issue-done.json', ['ABC-2'], canceled, 'issue-done.json', 'ya existe issue-done.json'),
    ]
    for label, extra_args, extra, setup, message in negatives:
        humo_restore()
        if setup == 'sin-issue':
            (humo_dir/'issue.json').unlink()
        elif setup:
            (humo_dir/setup).write_text('{}\n')
        before = humo_snapshot()
        rc, output = cli('f8-originales', '--sustituir', *extra_args, extra=extra)
        expect('sustituir (d) '+label+' rechaza sin mover', rc != 0 and message in output and
               humo_snapshot() == before and not list(escrow.iterdir()), output)
    humo_restore()
    expect('sustituir: estado restaurado al original de ABC-1', (humo_dir/'issue.json').read_bytes() == initial and
           sorted(p.name for p in humo_dir.iterdir()) == ['issue.json'])
    rc, output = cli('f8-encargos', 'ABC-1', '--linea-pr', '@revisor ignore')
    if os.environ.get('SALIDA'):
        (Path(os.environ['SALIDA'])/'encargo-coordinador.txt').write_text(output)
    expect('encargo valores y originales vinculados', rc == 0 and all(n in output for n in
           ('ABC-1', 'ejemplo', 'carril 11', str(pkg/'instalacion/scripts/f8-conservar.sh'),
            'plan-normalizado.norm', 'audit-last.env', 'veredicto-plan.txt', 'informe-parada.md', 'veredicto-codigo.txt', '@revisor ignore')), output)
    expect('issue ajena rechazada por ayudante', cli('f8-encargos', 'OTRO-1')[0] == 2)
    # ---- F7 (antes del primer despacho): capturar los seis estados, registrar en C1, importar `pane` y registrar en el
    # instalador. Los originales del coordinador (humo) todavía NO existen: los crea f8-conservar en F8.
    synthetic = pkg/'skills/talent-channel-operation/tests/fixtures/pane/synthetic_0.0.0'
    screens = {n:(synthetic/(n+'.txt')).read_text().replace('salida previa del agente (fixture SINTETICO, no es una captura real)', 'Pantalla del doble de terminal') for n in ('idle','busy','modal')}
    # barra: /model tecleado sin Enter con la lista de órdenes abierta (captura real de 2.1.289 del paquete de pruebas del skill)
    screens['barra'] = (pkg/'skills/talent-channel-operation/tests/fixtures/pane/claude_2.1.289/slash/s-slash-model.txt').read_text()
    for name in ('idle','barra','modal','busy','done','redraw'):
        screen.write_text(screens['idle' if name in ('done','redraw') else name])
        if name == 'done':
            rc, output = cli('capturar-done', clone, '11', 'v:.0')
        else:
            rc, output = cli('f8-capturas', clone, '11', 'v:.0', name)
        expect('captura clasifica '+name, rc == 0 and (captures/'claude_9.8.7'/(name+'.txt')).is_file(), output)
    barra_saved = (captures/'claude_9.8.7/barra.txt').read_bytes()
    expect('barra conserva la lista de órdenes y el compositor /model', barra_saved.count(b'/model') >= 2 and b'/effort' in barra_saved)
    screen.write_text(screens['idle'])
    rc, output = cli('f8-capturas', clone, '11', 'v:.0', 'barra', '--repetir')
    expect('barra con compositor vacío descartada conserva anterior', rc == 1 and 'barra' in output and '/model' in output and
           (captures/'claude_9.8.7/barra.txt').read_bytes() == barra_saved, output)
    # Caso real de H4: «/model» tecleado pero la lista de órdenes CERRADA (compositor con /model, pie normal). El eco
    # coincide y la caja es la normal, así que reposo + eco no bastan: la barra solo vale con la lista ABIERTA.
    real302 = pkg/'skills/talent-channel-operation/tests/fixtures/pane/claude_2.1.302'
    closed_list = (real302/'idle.txt').read_text().replace('❯ ', '❯ /model')
    expect('el caso de lista cerrada contiene /model en el compositor y ninguna fila de lista',
           closed_list.count('/model') == 2 and '  ❯ /' not in closed_list)
    screen.write_text(closed_list)
    rc, output = cli('f8-capturas', clone, '11', 'v:.0', 'barra', '--repetir')
    expect('barra con la lista cerrada descartada por f8-capturas y conserva la anterior', rc == 1 and 'lista' in output and
           (captures/'claude_9.8.7/barra.txt').read_bytes() == barra_saved, output)
    fresh = t/'capturas-lista-cerrada'
    rc, output = cli('f8-capturas', clone, '11', 'v:.0', 'barra', extra={'TCO_FIXTURE_DIR':str(fresh)})
    expect('barra con la lista cerrada no se publica como captura nueva', rc == 1 and 'lista' in output and
           not list(fresh.glob('**/barra.txt')), output)
    screen.write_text(screens['busy'])
    rc, output = cli('f8-capturas', clone, '11', 'v:.0', 'barra', '--repetir')
    expect('barra con turno ocupado descartada por clasificación', rc == 1 and 'clasificación' in output and
           (captures/'claude_9.8.7/barra.txt').read_bytes() == barra_saved, output)
    screen.write_text(screens['idle'])
    rc, output = cli('f8-capturas', clone, '11', 'v:.0', 'busy', '--repetir')
    expect('busy reposo descartada conserva anterior', rc == 1 and 'clasificación' in output and
           (captures/'claude_9.8.7/busy.txt').read_text() == screens['busy'], output)
    expect('repetición requiere opción', cli('f8-capturas', clone, '11', 'v:.0', 'idle')[0] == 1)
    rc, output = cli('f8-capturas', clone, '11', 'v:.0', 'idle', '--repetir')
    expect('repetición válida conserva rechazada', rc == 0 and list((captures/'claude_9.8.7').glob('idle.rechazada.*')), output)
    rc, output = cli('capturar-done', clone, '11', 'v:.0', '--repetir', extra={'TCO_PANE_CLI_VERSION_CMD':''})
    expect('done falta versión explica variable', rc == 1 and 'TCO_PANE_CLI_VERSION_CMD' in output and 'falta: busy.txt' not in output, output)
    coordinator_home = t/'hogar-coordinador'
    coordinator_conf = coordinator_home/'.config/talent-channel-operation/agents.conf'
    coordinator_conf.parent.mkdir(parents=True, mode=0o700)
    coordinator_conf.write_text('TCO_DEV_CLI="claude"\n')
    coordinator_conf.chmod(0o600)
    # La sexta captura (barra) es obligatoria para registrar y para --completo; sin ellas, si existe se valida igual.
    barra_file = captures/'claude_9.8.7/barra.txt'
    barra_aside = captures/'claude_9.8.7/barra.aparte'
    barra_file.rename(barra_aside)
    coordinator_before = coordinator_conf.read_bytes()
    rc, output = cli('calibrar-pane', clone, captures/'claude_9.8.7', '--registrar', extra={'HOME':str(coordinator_home)})
    expect('registrar sin barra rechaza y no escribe registro', rc == 1 and 'captura ausente: barra' in output and
           coordinator_conf.read_bytes() == coordinator_before, output)
    rc, output = cli('calibrar-pane', clone, captures/'claude_9.8.7', '--completo')
    expect('completo sin barra rechaza', rc == 1 and 'captura ausente: barra' in output, output)
    rc, output = cli('calibrar-pane', clone, captures/'claude_9.8.7')
    expect('clasificar sin barra y sin opciones acepta las cinco de siempre', rc == 0 and 'capturas clasificadas' in output, output)
    barra_aside.rename(barra_file)
    barra_file.write_bytes(barra_aside.parent.joinpath('idle.txt').read_bytes())
    for label, args in (('sin opciones', ()), ('--completo', ('--completo',)), ('--registrar', ('--registrar',))):
        rc, output = cli('calibrar-pane', clone, captures/'claude_9.8.7', *args, extra={'HOME':str(coordinator_home)})
        expect('barra con compositor vacío rechazada '+label, rc == 1 and 'barra' in output, output)
    barra_file.write_text(closed_list)
    for label, args in (('sin opciones', ()), ('--completo', ('--completo',)), ('--registrar', ('--registrar',))):
        rc, output = cli('calibrar-pane', clone, captures/'claude_9.8.7', *args, extra={'HOME':str(coordinator_home)})
        expect('barra con la lista cerrada rechazada '+label, rc == 1 and 'barra' in output, output)
    barra_file.write_bytes(barra_saved)
    expect('barra mal formada no escribió registro', coordinator_conf.read_bytes() == coordinator_before)
    # Las seis capturas reales de 2.1.302 siguen verdes: --completo y --registrar con el juego real versionado.
    real_set = t/'reales/claude_2.1.302'
    real_set.mkdir(parents=True)
    for name in ('idle', 'busy', 'done', 'modal', 'redraw', 'barra'):
        shutil.copyfile(real302/(name+'.txt'), real_set/(name+'.txt'))
    rc, output = cli('calibrar-pane', clone, real_set, '--completo')
    expect('las seis capturas reales de 2.1.302 clasifican con --completo', rc == 0 and 'capturas clasificadas' in output, output)
    real_home = t/'hogar-reales'
    real_conf = real_home/'.config/talent-channel-operation/agents.conf'
    real_conf.parent.mkdir(parents=True, mode=0o700)
    real_conf.write_text('TCO_DEV_CLI="claude"\n')
    real_conf.chmod(0o600)
    rc, output = cli('calibrar-pane', clone, real_set, '--registrar', extra={'HOME':str(real_home)})
    expect('las seis capturas reales de 2.1.302 se registran', rc == 0 and 'claude:2.1.302' in real_conf.read_text(), output)
    rc, output = cli('calibrar-pane', clone, captures/'claude_9.8.7', '--registrar', extra={'HOME':str(coordinator_home)})
    expect('calibración C1 por orden', rc == 0 and 'claude:9.8.7' in coordinator_conf.read_text() and 'CALIBRATED' not in conf.read_text(), output)
    # Paso 3 de F7: el importador recibe de C1 exactamente lo que dice la guía. Durante F7 humo no existe en C1, así que un
    # `tar ... pane humo` fallaría (tar real: error por el directorio ausente) y el estado quedaría a medias.
    f7_imports = guide_imports('F7')
    expect('guía F7: una sola importación de C1 y solo del directorio pane', f7_imports == [['pane']], str(f7_imports))
    for dirs, base in zip(f7_imports, guide_import_bases('F7')):
        data, missing = c1_tar(dirs, base)
        expect('guía F7: el tar solo nombra directorios que ya existen en C1 (humo lo crea F8)', not missing, str(missing))
        rc, output = cli('f8-importar', data=data)
        expect('importación de F7 incorpora las seis capturas', rc == 0 and (state/'pane/claude_9.8.7/barra.txt').is_file(), output)
    if not (state/'pane/claude_9.8.7/barra.txt').is_file():
        cli('f8-importar', data=c1_tar(['pane'], captures.parent)[0])
    imported = state/'pane/claude_9.8.7'
    rc, output = cli('calibrar-pane', clone, imported, '--registrar')
    expect('calibración instalador por orden', rc == 0, output)
    expect('F7 termina sin originales del coordinador en el estado del instalador', not (state/'humo/plan-normalizado.norm').exists())

    plan = '# Plan — ABC-1 · Documentar una prueba (docs/humo.md)\n\n## Contexto\n\nCambiar un fichero Markdown bajo docs/.\n'
    runs = home/'.config/talent-channel-operation/runs'
    runs.mkdir()
    (runs/'plan-11-ABC-1-r1.norm').write_text('ABC-1 ronda anterior\n')
    (runs/'plan-11-ABC-1-r2.norm').write_text(plan)
    run_id = 'tco_1234567890_abcdef123456'
    (runs/'audit-last-11.env').write_text('RUN_ID='+run_id+'\nSHA='+head+'\nTYP=code\nTS=2026-10-05T06:23:39Z\n')
    # Ruta vieja sin issue (evidencias-fabrica/<proyecto>/humo) sembrada con originales de otra issue: lo que dejó una
    # versión anterior del paquete. Ningún ayudante ni el paso 6 la leen, la mueven ni la importan (se comprueba abajo).
    fixed_names = ('plan-normalizado.norm', 'audit-last.env', 'veredicto-plan.txt', 'informe-parada.md',
                   'veredicto-codigo.txt')
    legacy = home/'evidencias-fabrica/ejemplo/humo'
    legacy.mkdir(mode=0o700)
    for name in fixed_names:
        (legacy/name).write_text('ABC-9 en la ruta vieja sin issue: '+name+'\n')
    legacy_before = {p.name: p.read_bytes() for p in sorted(legacy.iterdir())}
    rc, output = cli('f8-conservar', 'ABC-1', 'ejemplo', '11')
    expect('custodia última ronda y registro cuatro líneas', rc == 0 and
           read(evidence/'plan-normalizado.norm') == (runs/'plan-11-ABC-1-r2.norm').read_bytes() and
           read(evidence/'audit-last.env') == (runs/'audit-last-11.env').read_bytes(), output)
    expect('ruta vieja: f8-conservar deja en el directorio de la issue solo plan y registro, nada de la ruta vieja',
           evidence.is_dir() and sorted(p.name for p in evidence.iterdir()) == ['audit-last.env', 'plan-normalizado.norm'] and
           not any(p.read_bytes() in legacy_before.values() for p in evidence.iterdir()),
           str(sorted(p.name for p in evidence.iterdir()) if evidence.is_dir() else None))
    digest = hashlib.sha256(plan.encode()).hexdigest()
    # El coordinador deja sus originales en el directorio de la issue (en verde ya lo creó f8-conservar).
    evidence.mkdir(parents=True, exist_ok=True, mode=0o700)
    (evidence/'veredicto-plan.txt').write_text('{"run_id":"tco_1234567800_abcdef123456","artifact_type":"plan","artifact_sha":"'+digest[:28]+'\n  '+digest[28:]+'","verdict":"GO","blocking_findings":[]}\n')
    (evidence/'informe-parada.md').write_text('STOP-AUDIT — ABC-1 · informe pre-push\n· SHA auditado: '+head+'\n')
    # Caso neutralizado de p61: SHA cortado por el ancho del panel.
    verdict = '{"run_id":"tco_1234567890_abcdef123456","artifact_type":"code","artifact_sha":"'+head[:28]+'\n  '+head[28:]+'","verdict":"GO","blocking_findings":[]}\n'
    (evidence/'veredicto-codigo.txt').write_text(verdict)
    (evidence/'watch-stop.log').write_text('')
    rc, output = cli('f8-handoff', '1', 'ABC-1')
    expect('verificador real antes de merge', rc == 0 and 'rc=0' in output, output)
    rc, output = cli('f8-encargos', 'ABC-1', '1')
    if os.environ.get('SALIDA'):
        (Path(os.environ['SALIDA'])/'encargo-estacion.txt').write_text(output)
    expect('encargo estación con PR', rc == 0 and 'PR 1' in output and 'Done' in output and
           str(pkg/'instalacion/scripts/lanza-gates.sh')+' 1 ' in output and 'AND de talent-merger' in output and
           '--rol M1' in output and str(t/'homes/ejemplo-m1/producto/.claude/skills/talent-ceo/scripts/bus-sellar.sh') in output, output)
    pr.update(state='MERGED', isDraft=False)
    pr_path.write_text(json.dumps(pr))
    expect('originales antes de Done rechazan', cli('f8-originales', 'ABC-1', '1')[0] == 1)
    (state/'humo/issue.json').unlink()
    rc, output = cli('f8-originales', 'ABC-1', '1', extra={'F8_LINEAR_STATE':'Done'})
    expect('originales fusion y Done recuperan consulta omitida', rc == 0 and
           (state/'humo/merge.json').is_file() and (state/'humo/issue.json').read_bytes() == initial, output)
    expect('cabecera temporal eliminada', not list(escrow.iterdir()))
    expect('fallo Linear diagnosticado', cli('f8-originales', 'ABC-1', '1', extra={'F8_FAIL':'curl'})[0] == 1)
    expect('cabecera eliminada tras fallo', not list(escrow.iterdir()))
    def archive(entries=None):
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode='w') as tar:
            if entries is None:
                tar.add(evidence, arcname='humo')
                tar.add(captures, arcname='pane')
            else:
                for name, content, kind in entries:
                    entry = tarfile.TarInfo(name)
                    if kind == 'link':
                        entry.type = tarfile.SYMTYPE
                        entry.linkname = 'plan-aprobado.md'
                        tar.addfile(entry)
                    else:
                        entry.size = len(content)
                        tar.addfile(entry, io.BytesIO(content))
        return buffer.getvalue()

    # ---- F8, paso 6: los originales del coordinador (humo) los creó f8-conservar DESPUÉS de la importación de F7; el
    # instalador los vuelve a importar con la orden de la guía y solo entonces f8-ciclo los encuentra.
    f8_imports = guide_imports('F8')
    expect('guía F8: una importación de C1, solo de humo, después de conservar los originales', f8_imports == [['humo']], str(f8_imports))
    f8_bases = guide_import_bases('F8')
    expect('guía F8: el tar sale del directorio de evidencias de la issue (evidencias-fabrica/<proyecto>/<ISSUE>)',
           f8_bases == [evidence.parent], str(f8_bases))
    output = ''
    for dirs, base in zip(f8_imports, f8_bases):
        data, missing = c1_tar(dirs, base)
        expect('guía F8: el tar solo nombra directorios que ya existen en C1', not missing, str(missing))
        rc, output = cli('f8-importar', data=data)
        expect('importación tolera incidental vacío nombrado', rc == 0 and 'watch-stop.log (nombre incidental)' in output and not (state/'humo/watch-stop.log').exists(), output)
    coordinator_files = ('plan-normalizado.norm', 'audit-last.env', 'veredicto-plan.txt', 'informe-parada.md', 'veredicto-codigo.txt')
    expect('siguiendo las guías en su orden real el estado del instalador tiene los originales que lee f8-ciclo',
           all(read(state/'humo'/n) is not None and read(state/'humo'/n) == read(evidence/n) for n in coordinator_files),
           ' '.join(n for n in coordinator_files if not (state/'humo'/n).is_file()))
    if not all((state/'humo'/n).is_file() for n in coordinator_files):
        # Control para que el resto del recorrido corra aunque la guía no importe (o importe otro directorio): el estado
        # se completa con la orden que falta, desde el directorio de la issue.
        cli('f8-importar', data=c1_tar(['humo'], evidence.parent)[0])
    # ---- issue 9011 (pieza 1.7.4e): dos issues seguidas del MISMO proyecto. Cada una tiene su directorio de evidencias
    # en C1 (evidencias-fabrica/<proyecto>/<ISSUE>/humo): ni f8-conservar ni el coordinador comparten o pisan los
    # originales de la otra, y el paso 6 de la segunda no importa los de la primera.
    def c1_snapshot(directory):
        return ({p.name: p.read_bytes() for p in sorted(directory.iterdir()) if p.is_file()}
                if directory.is_dir() else None)

    def assignment_dir(issue):
        # El directorio que el encargo del coordinador nombra para los originales de nombre fijo.
        rc, output = cli('f8-encargos', issue)
        found = re.search(r'Conserva íntegros, sin redactar, en \$HOME/(\S+) ', output)
        return rc, (home/found[1] if found else None), output

    second = home/'evidencias-fabrica/ejemplo/ABC-2/humo'
    first_before = c1_snapshot(evidence)
    rc1, first_dir, output1 = assignment_dir('ABC-1')
    rc2, second_dir, output2 = assignment_dir('ABC-2')
    expect('dos issues: cada encargo nombra el directorio de su issue, distinto del de la otra',
           rc1 == 0 and rc2 == 0 and first_dir == evidence and second_dir == second, output1+output2)
    head2 = 'c'*40
    run_id2 = 'tco_1234567999_fedcba654321'
    plan2 = '# Plan — ABC-2 · Documentar otra prueba (docs/humo-2.md)\n\n## Contexto\n\nCambiar otro fichero Markdown bajo docs/.\n'
    audit_saved = (runs/'audit-last-11.env').read_bytes()
    (runs/'plan-11-ABC-2-r1.norm').write_text(plan2)
    (runs/'audit-last-11.env').write_text('RUN_ID='+run_id2+'\nSHA='+head2+'\nTYP=code\nTS=2026-10-06T06:23:39Z\n')
    rc, output = cli('f8-conservar', 'ABC-2', 'ejemplo', '11')
    expect('dos issues: f8-conservar de la segunda escribe en el directorio que nombra su encargo', rc == 0 and
           read(second/'plan-normalizado.norm') == plan2.encode() and
           read(second/'audit-last.env') == (runs/'audit-last-11.env').read_bytes() and second_dir == second, output)
    digest2 = hashlib.sha256(plan2.encode()).hexdigest()
    coordinator2 = {
        'veredicto-plan.txt': '{"run_id":"tco_1234567900_fedcba654321","artifact_type":"plan","artifact_sha":"'+digest2+
                              '","verdict":"GO","blocking_findings":[]}\n',
        'informe-parada.md': 'STOP-AUDIT — ABC-2 · informe pre-push\n· SHA auditado: '+head2+'\n',
        'veredicto-codigo.txt': '{"run_id":"'+run_id2+'","artifact_type":"code","artifact_sha":"'+head2+
                                '","verdict":"GO","blocking_findings":[]}\n'}
    # El coordinador deja sus tres originales donde le dice SU encargo.
    if second_dir is not None:
        second_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        for name, content in coordinator2.items():
            (second_dir/name).write_text(content)
    expect('dos issues: la primera queda intacta en su directorio', c1_snapshot(evidence) == first_before and
           first_before is not None and all(n in first_before for n in coordinator_files))
    shared = ('plan-normalizado.norm', 'veredicto-plan.txt', 'informe-parada.md', 'veredicto-codigo.txt')
    expect('dos issues: plan, veredictos e informe de cada issue en su directorio, sin compartir ni pisar',
           all(read(evidence/n) is not None and read(second/n) is not None and read(evidence/n) != read(second/n) and
               (evidence/n).stat().st_ino != (second/n).stat().st_ino for n in shared) and
           all(read(second/n) == content.encode() for n, content in coordinator2.items()),
           ' '.join(n for n in shared if read(second/n) is None))
    second_bases = guide_import_bases('F8', 'ABC-2')
    expect('dos issues: el paso 6 de la guía para la segunda lee el directorio de la segunda',
           second_bases == [second.parent] and guide_imports('F8') == [['humo']], str(second_bases))
    state_before = c1_snapshot(state/'humo')
    aside = t/'estado-humo-ABC-1'
    (state/'humo').rename(aside)
    try:
        data, missing = c1_tar(['humo'], second_bases[0] if second_bases else None)
        rc, output = cli('f8-importar', data=data)
        got = c1_snapshot(state/'humo') or {}
    finally:
        shutil.rmtree(state/'humo', ignore_errors=True)
        aside.rename(state/'humo')
    expect('dos issues: el paso 6 de la segunda importa sus originales y ninguno de la primera',
           rc == 0 and not missing and sorted(got) == sorted(coordinator_files) and
           all(got[n] == read(second/n) and got[n] != (first_before or {}).get(n) for n in coordinator_files), output)
    expect('dos issues: el estado del instalador vuelve al de la primera', c1_snapshot(state/'humo') == state_before)
    (runs/'plan-11-ABC-2-r1.norm').unlink()
    (runs/'audit-last-11.env').write_bytes(audit_saved)
    decoys = set(legacy_before.values())
    reached = [str(p) for d in (evidence, second, state/'humo') if d.is_dir() for p in d.iterdir()
               if p.is_file() and p.read_bytes() in decoys] + [n for n, v in got.items() if v in decoys]
    expect('ruta vieja: queda como estaba y nada suyo llega a los directorios de las issues ni al estado del instalador',
           c1_snapshot(legacy) == legacy_before and not reached, ' '.join(reached))
    # Compatibilidad (paso 6 de F8.md): el paquete se actualizó tras el paso 2 y los originales de la issue en curso solo
    # están en la ruta vieja. La guía manda repetir SOLO f8-conservar (no el paso 2): lee de runs, escribe en el directorio
    # de la issue y no toca la ruta vieja; sin el plan en runs, rojo sin crear nada.
    compat = t/'hogar-compat'
    compat_runs = compat/'.config/talent-channel-operation/runs'
    compat_runs.mkdir(parents=True, mode=0o700)
    compat_old = compat/'evidencias-fabrica/ejemplo/humo'
    compat_old.mkdir(parents=True, mode=0o700)
    for name in fixed_names:
        (compat_old/name).write_bytes(read(evidence/name) or b'ausente\n')
    compat_before = c1_snapshot(compat_old)
    compat_new = compat/'evidencias-fabrica/ejemplo/ABC-1/humo'
    rc, output = cli('f8-conservar', 'ABC-1', 'ejemplo', '11', extra={'HOME': str(compat)})
    expect('compatibilidad: sin el plan en sus runs, repetir f8-conservar da rojo y no crea el directorio de la issue',
           rc == 1 and 'plan normalizado ausente' in output and not compat_new.exists() and
           c1_snapshot(compat_old) == compat_before, output)
    (compat_runs/'plan-11-ABC-1-r2.norm').write_text(plan)
    (compat_runs/'audit-last-11.env').write_bytes(audit_saved)
    rc, output = cli('f8-conservar', 'ABC-1', 'ejemplo', '11', extra={'HOME': str(compat)})
    expect('compatibilidad: repetir solo f8-conservar escribe plan y registro en el directorio de la issue desde runs '
           'y deja la ruta vieja como estaba', rc == 0 and
           c1_snapshot(compat_new) == {'audit-last.env': audit_saved, 'plan-normalizado.norm': plan.encode()} and
           c1_snapshot(compat_old) == compat_before, output)
    for name, content, kind in [('humo/plan-normalizado.norm', b'', 'file'), ('../escape', b'X', 'file'),
                                ('humo/incidental', b'', 'link'), ('humo/plan-normalizado.norm', b'ABC-2', 'file')]:
        before = read(state/'humo/plan-normalizado.norm')
        rc, output = cli('f8-importar', data=archive([(name, content, kind)]))
        expect('importación rechaza con fichero '+name+' '+kind, rc == 1 and name in output and
               before is not None and before == read(state/'humo/plan-normalizado.norm'), output)
    imported = state/'pane/claude_9.8.7'
    (imported/'busy.txt').write_text(screens['idle'])
    rc, output = cli('f8-importar', '--repetir-capturas', data=archive())
    expect('reimportación corrige captura con juego clasificado', rc == 0 and (imported/'busy.txt').read_text() == screens['busy'], output)
    rc, output = cli('calibrar-pane', clone, imported, '--registrar')
    expect('calibración instalador por orden', rc == 0, output)
    missing = state/'humo/veredicto-plan.txt'
    saved = missing.read_bytes()
    missing.unlink()
    rc, output = cli('f8-ciclo')
    expect('ciclo nombra veredicto plan ausente', rc == 1 and 'plan-gate' in output and 'veredicto-plan.txt' in output, output)
    missing.write_bytes(saved)
    rc, output = cli('f8-ciclo')
    expect('siete recibos automáticos desde originales fijos', rc == 0 and
           len(list((state/'humo').glob('*-recibo.json'))) == 7, output)
    rc, output = cli('check-F8', extra={'F8_LINEAR_STATE':'Done'})
    expect('secuencia check F8 real verde', rc == 0 and 'verde F8' in output, output)
    expect('ciclo idempotente', cli('f8-ciclo')[0] == 0)
    baseline = t/'reserva-humo'
    shutil.copytree(state/'humo', baseline)
    sys.path.insert(0, str(pkg/'instalacion/scripts'))
    from originales import verdicts, approval
    from fases import Error
    code_obj = dict(run_id=run_id, artifact_type='code', artifact_sha=head,
                    verdict='GO', blocking_findings=[])
    plan_obj = dict(code_obj, artifact_type='plan', artifact_sha=digest)
    for typ, obj in [('code', code_obj), ('plan', plan_obj)]:
        canonical = json.dumps(obj)
        for newline in ('\n', '\r\n'):
            failures = []
            for cut in range(1, len(canonical)):
                wrapped = 'Prosa del auditor.'+newline+'  '+canonical[:cut]+newline+'  '+canonical[cut:]+newline+'Fin del panel.'
                try:
                    same = verdicts(wrapped) == [obj]
                    approval(wrapped, typ, obj['artifact_sha'], 'ABC-1', run_id if typ == 'code' else None)
                except Error:
                    same = False
                if not same:
                    failures.append(cut)
            expect('cada corte JSON '+typ+' '+repr(newline), not failures, str(failures))

    def restore_positive():
        shutil.rmtree(state/'humo')
        shutil.copytree(baseline, state/'humo')

    prose_plan = plan+'\nAnte NO-GO se detiene la ejecución.\n'
    positives = [
        ('plan prosa NO-GO', 'plan-gate', {'plan-normalizado.norm':prose_plan,
            'veredicto-plan.txt':json.dumps(dict(plan_obj, artifact_sha=hashlib.sha256(prose_plan.encode()).hexdigest()))}),
        ('auditor prosa NO-GO', 'auditoria', {'veredicto-codigo.txt':'Se corrigió el NO-GO anterior.\n'+verdict}),
        ('code ronda rechazada anterior', 'auditoria', {'veredicto-codigo.txt':
            json.dumps(dict(code_obj, run_id='anterior', artifact_sha='c'*40, verdict='NO-GO'))+'\n'+verdict}),
        ('plan ronda rechazada anterior', 'plan-gate', {'veredicto-plan.txt':
            json.dumps(dict(plan_obj, artifact_sha='c'*64, verdict='NO-GO'))+'\n'+json.dumps(plan_obj)}),
        ('plan ronda anterior de code completa', 'plan-gate', {'veredicto-plan.txt':
            json.dumps(dict(code_obj, run_id='anterior-code', artifact_sha='c'*40, verdict='NO-GO'))+
            '\n'+json.dumps(plan_obj)}),
        ('code otro tipo anterior', 'auditoria', {'veredicto-codigo.txt':
            json.dumps(dict(plan_obj, run_id='anterior', verdict='NO-GO'))+'\n'+verdict}),
        ('code clave partida', 'auditoria', {'veredicto-codigo.txt':verdict.replace('artifact_type', 'artifact_\n  type')}),
        ('code run partido', 'auditoria', {'veredicto-codigo.txt':verdict.replace(run_id, run_id[:16]+'\n  '+run_id[16:])}),
        ('code CRLF', 'auditoria', {'veredicto-codigo.txt':json.dumps(code_obj)+'\r\n'}),
        ('plan CRLF', 'plan-gate', {'plan-normalizado.norm':plan.replace('\n', '\r\n'),
            'veredicto-plan.txt':json.dumps(dict(plan_obj, artifact_sha=hashlib.sha256(plan.replace('\n', '\r\n').encode()).hexdigest()))+'\r\n'}),
        ('code repetido idéntico', 'auditoria', {'veredicto-codigo.txt':verdict+verdict}),
        ('plan varias aprobaciones compatibles', 'plan-gate', {'veredicto-plan.txt':
            json.dumps(plan_obj)+json.dumps(dict(plan_obj, run_id='segunda-aprobacion'))}),
        ('code fragmento ilegible ajeno', 'auditoria', {'veredicto-codigo.txt':
            json.dumps(dict(code_obj, run_id='anterior', verdict='NO-GO')).replace('"verdict":', '"verdict":"NO-GO","verdict":')+'\n'+verdict}),
        ('plan fragmento ilegible ajeno', 'plan-gate', {'veredicto-plan.txt':
            json.dumps(dict(plan_obj, artifact_sha='c'*64, verdict='NO-GO')).replace('"verdict":', '"verdict":"NO-GO","verdict":')+'\n'+json.dumps(plan_obj)}),
        ('code llaves en prosa', 'auditoria', {'veredicto-codigo.txt':'Prosa { sin JSON.\n'+verdict+'\nOtra { llave.'}),
        ('plan llaves en prosa', 'plan-gate', {'veredicto-plan.txt':'Prosa { sin JSON.\n'+json.dumps(plan_obj)}),
        ('plan rechazo ajeno con objetos bloqueantes', 'plan-gate', {'veredicto-plan.txt':
            json.dumps(dict(plan_obj, artifact_sha='c'*64, verdict='NO-GO', blocking_findings=[plan_obj]))+'\n'+json.dumps(plan_obj)}),
        ('code rechazo ajeno con objetos bloqueantes', 'auditoria', {'veredicto-codigo.txt':
            json.dumps(dict(code_obj, run_id='anterior', verdict='NO-GO', blocking_findings=[code_obj]))+'\n'+verdict}),
    ]
    for typ, obj, stage in [('plan', plan_obj, 'plan-gate'), ('code', code_obj, 'auditoria')]:
        name = 'veredicto-plan.txt' if typ == 'plan' else 'veredicto-codigo.txt'
        key, other = ('artifact_sha', 'c'*64) if typ == 'plan' else ('run_id', 'anterior')
        positives.extend([
            (typ+' lista ajena demostrable', stage, {name:json.dumps([dict(obj, **{key:other})])+json.dumps(obj)}),
            (typ+' llaves de prosa no JSON', stage, {name:'{x} { tal } código citado { return 1; }\n'+json.dumps(obj)}),
            (typ+' prosa variada y verdict como valor', stage, {name:
                '[ ] [x] [guía](https://example.invalid) literal `{}` '+
                json.dumps({'nota':'verdict'})+'\n'+json.dumps(obj)}),
            (typ+' ronda anterior cortada por panel', stage, {name:
                json.dumps(dict(obj, verdict='NO-GO', **{key:other})).replace(
                    'artifact_type', 'artifact_\n  type')+'\n'+json.dumps(obj)}),
            ('R7-01 '+typ+' clave escapada ajena completa', stage, {name:
                json.dumps(dict(obj, verdict='NO-GO', **{key:other})).replace(
                    '"verdict"', r'"\u0076erdict"')+'\n'+json.dumps(obj)}),
        ])
        for label, prose in [
            ('regex', r'Veredicto: GO. La expresión regular `\[` reconoce el delimitador de apertura.'),
            ('token', 'El token `[` abre una lista.'),
            ('rangos', 'rangos [0, 5)'),
            ('tarea', '[x]'),
            ('numero', '[1] seguido de texto'),
            ('enlace', '[texto](https://example.invalid)'),
            ('pila fallida', '{"nota": [x],}'),
        ]:
            positives.append(('R5-01 '+typ+' '+label, stage, {name:prose+'\n'+json.dumps(obj)}))
    for label, stage, changes in positives:
        for name, content in changes.items():
            (state/'humo'/name).write_bytes(content.encode())
        provenance = state/'humo'/(stage+'-procedencia.json')
        row = json.loads(provenance.read_text())
        fixed = state/'humo'/('plan-normalizado.norm' if stage == 'plan-gate' else 'veredicto-codigo.txt')
        Path(row['artefacto']).write_bytes(fixed.read_bytes())
        row['sha256'] = hashlib.sha256(fixed.read_bytes()).hexdigest()
        row['auxiliares'] = {n:hashlib.sha256((state/'humo'/n).read_bytes()).hexdigest() for n in row['auxiliares']}
        provenance.write_text(json.dumps(row))
        checked = cli('check-F8', extra={'F8_LINEAR_STATE':'Done'})
        for suffix in ('-recibo.json', '-procedencia.json', '-artefacto.txt'):
            (state/'humo'/(stage+suffix)).unlink()
        (state/'humo/ciclo.json').unlink()
        received = cli('f8-recibo', stage, fixed, 'operador')
        built = cli('f8-ciclo')
        expect('positivo tres consumidores '+label, all(r[0] == 0 for r in (checked, received, built)),
               str((checked, received, built)))
        saved = state/'humo'/(stage+'-artefacto.txt')
        expect('bytes conservados '+label, saved.is_file() and saved.read_bytes() == fixed.read_bytes())
        expect('check generado '+label, cli('check-F8', extra={'F8_LINEAR_STATE':'Done'})[0] == 0)
        restore_positive()
    variants = [
        ('code dentro de objeto exterior', 'auditoria', 'veredicto-codigo.txt', json.dumps({'respuesta':code_obj})),
        ('plan dentro de objeto exterior', 'plan-gate', 'veredicto-plan.txt', json.dumps({'respuesta':plan_obj})),
        ('ejemplo sin auditor', 'auditoria', 'veredicto-codigo.txt', json.dumps({'artifact_sha':head,'verdict':'GO'})),
        ('tipo plan bloqueante', 'auditoria', 'veredicto-codigo.txt', json.dumps(dict(run_id=run_id, artifact_type='plan',artifact_sha=head,verdict='GO',blocking_findings=[{'severity':'BLOCKER'}]))),
        ('auditor otra issue', 'auditoria', 'veredicto-codigo.txt', verdict.replace('"verdict"', '"issue":"ABC-2","verdict"')),
        ('plan rechazado', 'plan-gate', 'plan-normalizado.norm', 'ABC-1\nVeredicto NO-GO\n'),
        ('veredicto plan ajeno', 'plan-gate', 'veredicto-plan.txt', 'ABC-2 auditoría GO\n'),
        ('plan otro digest', 'plan-gate', 'veredicto-plan.txt', (state/'humo/veredicto-plan.txt').read_text().replace(digest[:28], 'c'*28)),
        ('issue ajena con referencia', 'issue', 'issue.json', json.dumps({'data':{'issue':{'identifier':'ABC-2','title':'Relacionado con ABC-1','createdAt':'2026-10-04T12:00:00Z'}}})),
        ('registro ausente', 'auditoria', 'audit-last.env', None),
        ('registro otro run', 'auditoria', 'audit-last.env', (state/'humo/audit-last.env').read_text().replace(run_id, 'otro-run')),
        ('registro otro head', 'auditoria', 'audit-last.env', (state/'humo/audit-last.env').read_text().replace(head, 'c'*40)),
        ('registro tipo plan', 'auditoria', 'audit-last.env', (state/'humo/audit-last.env').read_text().replace('TYP=code', 'TYP=plan')),
        ('code bloqueante', 'auditoria', 'veredicto-codigo.txt', verdict.replace('"blocking_findings":[]', '"blocking_findings":[{"severity":"BLOCKER"}]')),
        ('code vigente contradictorio', 'auditoria', 'veredicto-codigo.txt', verdict+verdict.replace('"GO"', '"NO-GO"')),
        ('plan vigente contradictorio', 'plan-gate', 'veredicto-plan.txt', json.dumps(plan_obj)+json.dumps(dict(plan_obj, verdict='NO-GO'))),
        ('plan vigente bloqueante', 'plan-gate', 'veredicto-plan.txt', json.dumps(dict(plan_obj, blocking_findings=[{'severity':'BLOCKER'}]))),
        ('code clave repetida', 'auditoria', 'veredicto-codigo.txt', json.dumps(code_obj).replace('"verdict":', '"verdict":"GO","verdict":')),
        ('code JSON incompleto', 'auditoria', 'veredicto-codigo.txt', json.dumps(code_obj)[:-1]),
        ('code bloqueantes con GO anidado', 'auditoria', 'veredicto-codigo.txt',
            json.dumps(dict(code_obj, blocking_findings=[code_obj]))),
        ('informe otro commit', 'codigo', 'informe-parada.md', (state/'humo/informe-parada.md').read_text().replace(head, 'c'*40)),
        ('merge otra fusión', 'merge', 'merge.json', json.dumps(dict(pr, mergeCommit={'oid':'c'*40}))),
        ('informe sin cabecera', 'codigo', 'informe-parada.md', 'ABC-1 '+head),
        ('merge otro PR', 'merge', 'merge.json', json.dumps(dict(pr, number=2))),
        ('Done otro estado', 'Done', 'issue-done.json', (state/'humo/issue-done.json').read_text().replace('Done', 'Todo')),
    ]
    for label, stage, name, content in variants:
        path = state/'humo'/name
        if content is None:
            path.unlink()
        else:
            path.write_text(content)
        check = cli('check-F8', extra={'F8_LINEAR_STATE':'Done'})
        for suffix in ('-recibo.json', '-procedencia.json', '-artefacto.txt'):
            (state/'humo'/(stage+suffix)).unlink(missing_ok=True)
        (state/'humo/ciclo.json').unlink()
        cycle_result = cli('f8-ciclo')
        expect('variante roja '+label, check[0] == 1 and cycle_result[0] == 1, str((check, cycle_result)))
        shutil.rmtree(state/'humo')
        shutil.copytree(baseline, state/'humo')
        expect('restauración verde '+label, cli('check-F8', extra={'F8_LINEAR_STATE':'Done'})[0] == 0)
    # Reproducciones con sellos coherentes: el rojo debe ser semántico en los tres consumidores.
    reproductions = [
        ('R3-01 plan rechazo cortado GO antiguo', 'plan-gate', json.dumps(plan_obj)+'\n'+
            json.dumps(dict(plan_obj, run_id='rechazo-vigente', verdict='NO-GO'))[:-1]),
        ('R3-01 code rechazo cortado', 'auditoria', json.dumps(code_obj)+'\n'+
            json.dumps(dict(code_obj, verdict='NO-GO'))[:-1]),
        ('R3-01 duplicado rechazo con GO', 'plan-gate', json.dumps(plan_obj)+'\n'+
            json.dumps(dict(plan_obj, verdict='NO-GO')).replace('"verdict":', '"verdict":"GO","verdict":')),
        ('R3-02 code ejemplo anidado', 'auditoria', json.dumps({
            'nota':'No se ejecutó auditoría. Ejemplo de plantilla únicamente.', 'ejemplo':code_obj})),
        ('R3-02 plan ejemplo anidado', 'plan-gate', json.dumps({
            'nota':'No se aprobó el plan. Ejemplo de plantilla únicamente.', 'ejemplo':plan_obj})),
        ('ilegible sin vínculo completo', 'plan-gate', json.dumps(plan_obj)+'\n{"verdict":"NO-GO",'),
        ('ilegible run sin comilla final', 'auditoria', json.dumps(code_obj)+'\n{"verdict":"NO-GO","run_id":"anterior'),
        ('ilegible hash truncado', 'plan-gate', json.dumps(plan_obj)+'\n{"verdict":"NO-GO","artifact_sha":"'+('c'*63)+'"'),
        ('ilegible antes de aprobación', 'plan-gate', json.dumps(dict(plan_obj, verdict='NO-GO'))[:-1]+'\n'+json.dumps(plan_obj)),
    ]
    for typ, obj, stage in [('plan', plan_obj, 'plan-gate'), ('code', code_obj, 'auditoria')]:
        go = json.dumps(obj)
        rejection = dict(obj, verdict='NO-GO')
        key, other = ('artifact_sha', 'c'*64) if typ == 'plan' else ('run_id', 'anterior')
        repeated_links = [(key, other)]
        if typ == 'plan':
            repeated_links.append(('artifact_type', 'otro'))
        for link_key, foreign in repeated_links:
            for order, values in [('vigente-ajeno', [obj[link_key], foreign]),
                                  ('ajeno-vigente', [foreign, obj[link_key]])]:
                repeated = json.dumps(rejection).replace(
                    json.dumps(link_key)+': '+json.dumps(obj[link_key]),
                    ', '.join(json.dumps(link_key)+': '+json.dumps(value) for value in values))
                reproductions.append(('R8-01 '+typ+' '+link_key+' '+order, stage, repeated+'\n'+go))
        for label, note in [('vacio', {}), ('nota', {'a':1})]:
            for place in ('antes', 'despues'):
                bad = dict(nota=note, **rejection) if place == 'antes' else dict(rejection, nota=note)
                reproductions.append(('R4-01 '+typ+' '+label+' '+place, stage, go+'\n'+json.dumps(bad)[:-1]))
        reproductions.extend([
            ('R7-01 '+typ+' clave Unicode rechazo', stage,
                json.dumps(rejection).replace('"verdict"', r'"\u0076erdict"')+'\n'+go),
            ('R7-01 '+typ+' clave totalmente escapada rechazo', stage,
                json.dumps(rejection).replace('"verdict"',
                    r'"\u0076\u0065\u0072\u0064\u0069\u0063\u0074"')+'\n'+go),
            ('R7-02 '+typ+' contenedor repetido GO', stage,
                '{"x":0,"x":1,"ejemplo":'+go+'}'),
            ('lista vigente '+typ, stage, json.dumps([obj])),
            ('lista vigente tras GO '+typ, stage, go+'\n'+json.dumps([obj])),
            ('lista vigente con espacios '+typ, stage, '[ \n '+go+']'),
            ('lista vigente sin cierre con espacios '+typ, stage, '[ \n '+go),
            ('residuo verdict '+typ, stage, go+'\n"verdict":"NO-GO"'),
            ('ilegible ajeno sin cierre '+typ, stage, json.dumps(dict(rejection, **{key:other}))[:-1]+'\n'+go),
            (typ+' veredicto anidado en objeto legible', stage,
                json.dumps({'ejemplo':rejection})+go),
            ('portador NO-GO en objeto ajeno '+typ, stage,
                json.dumps(dict(obj, **{key:other}, ejemplo=rejection))+go),
            ('portador NO-GO lista en prosa '+typ, stage,
                'Prosa [ '+json.dumps(rejection)+' ] fin.\n'+go),
            ('portador GO seguido de ejemplo NO-GO '+typ, stage,
                go+json.dumps({'ejemplo':rejection})),
            ('lista escalar GO solo '+typ, stage, json.dumps([0, obj])),
        ])
        for scalar in (0, 'texto'):
            for label, bad in [('directo', rejection), ('anidado', {'x':rejection})]:
                reproductions.append(('R6-01 '+typ+' '+repr(scalar)+' '+label, stage,
                                      json.dumps([scalar, bad, obj])))
    for label, stage, content in reproductions:
        fixed = state/'humo'/('veredicto-codigo.txt' if stage == 'auditoria' else 'plan-normalizado.norm')
        (state/'humo'/('veredicto-codigo.txt' if stage == 'auditoria' else 'veredicto-plan.txt')).write_text(content)
        provenance = state/'humo'/(stage+'-procedencia.json')
        row = json.loads(provenance.read_text())
        (state/'humo'/(stage+'-artefacto.txt')).write_bytes(fixed.read_bytes())
        row['sha256'] = hashlib.sha256(fixed.read_bytes()).hexdigest()
        row['auxiliares'] = {n:hashlib.sha256((state/'humo'/n).read_bytes()).hexdigest() for n in row['auxiliares']}
        provenance.write_text(json.dumps(row))
        checked = cli('check-F8', extra={'F8_LINEAR_STATE':'Done'})
        for suffix in ('-recibo.json', '-procedencia.json', '-artefacto.txt'):
            (state/'humo'/(stage+suffix)).unlink()
        (state/'humo/ciclo.json').unlink()
        received = cli('f8-recibo', stage, fixed, 'operador')
        built = cli('f8-ciclo')
        print('REPRODUCCION '+label+' rc='+str([r[0] for r in (checked, received, built)]), flush=True)
        for result in (checked, received, built):
            print(result[1], flush=True)
        expected = ('veredicto sin vínculo' if label.startswith('R3-02') else
                    'veredicto contradictorio' if label.startswith(('R7-01', 'R6-01', 'portador NO-GO',
                    'portador GO seguido', 'plan veredicto anidado', 'code veredicto anidado')) else
                    'veredicto ilegible')
        expect('rojo tres consumidores '+label, all(r[0] == 1 and expected in r[1]
               for r in (checked, received, built)), str((checked, received, built)))
        restore_positive()
        expect('restauración verde '+label, cli('check-F8', extra={'F8_LINEAR_STATE':'Done'})[0] == 0)
    # Solo acredita el objeto que coincide con el registro; otro GO compatible no lo sustituye.
    multiple = verdict.replace(run_id, 'tco_1234567800_abcdef123456')+verdict
    (state/'humo/veredicto-codigo.txt').write_text(multiple)
    for suffix in ('-recibo.json', '-procedencia.json', '-artefacto.txt'):
        (state/'humo'/('auditoria'+suffix)).unlink()
    (state/'humo/ciclo.json').unlink()
    expect('varios objetos seleccionan registro vigente', cli('f8-ciclo')[0] == 0 and
           cli('check-F8', extra={'F8_LINEAR_STATE':'Done'})[0] == 0)
    shutil.rmtree(state/'humo')
    shutil.copytree(baseline, state/'humo')
    for name in ('merge.json', 'issue-done.json'):
        (state/'humo'/name).unlink()
    rc, output = cli('f8-originales', 'ABC-1', '1', extra={'F8_LINEAR_STATE':'Done', 'F8_LINEAR_TITLE':'Título corregido'})
    expect('título mutable conserva inicial y final', rc == 0 and (state/'humo/issue.json').read_bytes() == initial and
           json.loads((state/'humo/issue-done.json').read_text())['data']['issue']['title'] == 'Título corregido', output)
    for key in ('number', 'state', 'headRefOid', 'mergeCommit', 'body', 'files', 'statusCheckRollup'):
        for name in ('merge.json', 'issue-done.json'):
            (state/'humo'/name).unlink(missing_ok=True)
        changed = dict(pr)
        del changed[key]
        pr_path.write_text(json.dumps(changed))
        rc, output = cli('f8-originales', 'ABC-1', '1', extra={'F8_LINEAR_STATE':'Done'})
        expect('respuesta parcial sin escritura '+key, rc == 1 and 'merge.json' in output and key in output and
               not (state/'humo/merge.json').exists() and not (state/'humo/issue-done.json').exists(), output)
        changed[key] = None
        pr_path.write_text(json.dumps(changed))
        rc, output = cli('f8-originales', 'ABC-1', '1', extra={'F8_LINEAR_STATE':'Done'})
        expect('tipo inválido sin escritura '+key, rc == 1 and 'merge.json' in output and key in output and
               not (state/'humo/merge.json').exists() and not (state/'humo/issue-done.json').exists(), output)
    pr_path.write_text(json.dumps(pr))
    shutil.rmtree(state/'humo')
    shutil.copytree(baseline, state/'humo')
    curl_saved = (binpath/'curl').read_bytes()
    for identifier in (None, '', 7):
        row = dict(title='Documento', createdAt='2026-10-04T12:00:00Z', state={'name':'Done'})
        if identifier is not None:
            row['identifier'] = identifier
        payload = json.dumps({'data':{'issue':row}})
        (binpath/'curl').write_text('#!/usr/bin/env python3\nprint('+repr(payload)+')\n')
        for name in ('merge.json', 'issue-done.json'):
            (state/'humo'/name).unlink(missing_ok=True)
        rc, output = cli('f8-originales', 'ABC-1', '1')
        expect('Linear identifier parcial '+repr(identifier), rc == 1 and 'data.issue.identifier' in output and
               not (state/'humo/merge.json').exists() and not (state/'humo/issue-done.json').exists(), output)
        restore_positive()
    (binpath/'curl').write_bytes(curl_saved)
    for key in ('headRefOid', 'state', 'mergeCommit', 'body'):
        for invalid in ('ausente', 'tipo'):
            for suffix in ('-recibo.json', '-procedencia.json', '-artefacto.txt'):
                (state/'humo'/('issue'+suffix)).unlink(missing_ok=True)
            changed = dict(pr)
            if invalid == 'ausente':
                del changed[key]
            else:
                changed[key] = None
            pr_path.write_text(json.dumps(changed))
            rc, output = cli('f8-recibo', 'issue', state/'humo/issue.json', 'operador')
            expect('consulta parcial de recibo sin escritura '+key+' '+invalid,
                   rc == 1 and key in output and 'issue.json' in output and
                   not any((state/'humo'/('issue'+s)).exists() for s in
                           ('-recibo.json', '-procedencia.json', '-artefacto.txt')), output)
            shutil.rmtree(state/'humo')
            shutil.copytree(baseline, state/'humo')
    pr_path.write_text(json.dumps(pr))
    # Mismo artefacto evaluado por recibo y check; recalcular digest no oculta un rojo.
    artifact = state/'humo/auditoria-artefacto.txt'
    provenance = state/'humo/auditoria-procedencia.json'
    original_record = provenance.read_bytes()
    import hashlib
    for label, bad in [('otro commit', verdict.replace(head[:28], 'b'*28)),
                       ('NO-GO', verdict.replace('"GO"', '"NO-GO"')),
                       ('SHA truncado', verdict.replace(head[28:], head[28:-1]))]:
        source = t/'veredicto.txt'
        source.write_text(bad)
        rc, output = cli('f8-recibo', 'auditoria', source, 'auditor')
        expect('recibo rechaza '+label, rc == 1 and 'auditoria' in output and str(source) in output, output)
        artifact.write_text(bad)
        (state/'humo/veredicto-codigo.txt').write_text(bad)
        record = json.loads(original_record)
        record['sha256'] = hashlib.sha256(artifact.read_bytes()).hexdigest()
        provenance.write_text(json.dumps(record))
        expect('check rechaza '+label+' aun con digest correcto', cli('check-F8', extra={'F8_LINEAR_STATE':'Done'})[0] == 1)
    artifact.write_text(verdict)
    (state/'humo/veredicto-codigo.txt').write_text(verdict)
    provenance.write_bytes(original_record)
    expect('verde después de revertir mutaciones', cli('check-F8', extra={'F8_LINEAR_STATE':'Done'})[0] == 0)
    (imported/'busy.txt').write_text(screens['idle'])
    before = conf.read_bytes()
    rc, output = cli('calibrar-pane', clone, imported, '--registrar')
    expect('calibración roja no escribe registro', rc == 1 and conf.read_bytes() == before, output)
    rc, output = cli('f8-importar', '--repetir-capturas', data=archive([
        ('pane/claude_9.8.7/busy.txt', screens['idle'].encode(), 'file')]))
    expect('reimportación incompleta rechaza sin sustituir', rc == 1 and 'repetición rechazada' in output, output)
    # Lint real y orden documentado; cada CLI citado también se ejercita arriba.
    guide = pkg/'instalacion/fases/F8.md'
    calibration_guide = pkg/'instalacion/fases/F7.md'
    rc, output = cli('lint-md', calibration_guide)
    expect('guía de calibración F7 comandos y modos existentes', rc == 0, output)
    rc, output = cli('lint-md', guide)
    expect('guía comandos y modos existentes', rc == 0, output)
    # (e) La fila de sustitución está en Remediación, con su caso registrado, y el paso 1 la remite.
    remediation = guide.read_text().split('## Remediación', 1)[1].split('## Al terminar', 1)[0]
    step_one = guide.read_text().split('1. **Persona', 1)[1].split('```', 1)[0]
    cases = json.loads((pkg/'tests/remediaciones.json').read_text())
    expect('sustituir (e) fila de Remediación, caso registrado y nota del paso 1',
           '| issue de humo creada mal / hay que sustituirla |' in remediation and
           'f8-originales.sh --sustituir "$NUEVA"' in remediation and 'Canceled' in remediation and
           'issue de humo creada mal' in step_one and
           any(case['fase'] == 'F8' and case['fila'] == 'issue de humo creada mal / hay que sustituirla' and
               not case['verde'] for case in cases))
    # (f) issue 9011, pieza 1.7.4e: la fila cubre antes y después de conservar, y la guía dice qué pasa con la ruta vieja.
    flat = ' '.join(guide.read_text().split())
    expect('sustituir (f) la fila fija ISSUE a la nueva y da el paso exacto antes y después de imprimir el encargo',
           '`ISSUE="$NUEVA"`' in remediation and 'los pasos 2 a 6 usan `$ISSUE`' in remediation and
           'Si el encargo del paso 2 aún no se imprimió, se imprime ya con la nueva' in remediation and
           'Si ya se imprimió con la anterior (haya conservado o no)' in remediation and
           'f8-encargos.sh "$ISSUE"' in remediation and 'en lugar del anterior' in remediation and
           'evidencias-fabrica/$PROYECTO/$NUEVA/humo' in remediation and 'queda intacta en el suyo' in remediation and
           'se cierra sin fusionar' in remediation and 'con eso basta' not in remediation)
    # (g) Compatibilidad del paso 6: la ruta vieja queda como estaba y, tras Done, se repite SOLO f8-conservar.
    step_six = ' '.join(flat.split('6. **Persona', 1)[1].split('## Comprobación', 1)[0].split())
    expect('sustituir (g) paso 6: ruta vieja sin issue como estaba y, tras Done, solo f8-conservar sin repetir el paso 2',
           '(`evidencias-fabrica/$PROYECTO/humo`) quedan como estaban' in step_six and
           'ningún ayudante las lee, las mueve ni las importa como de la issue actual' in step_six and
           'NO repetir el paso 2' in step_six and '`f8-conservar.sh "$ISSUE" "$PROYECTO" "$CARRIL"`' in step_six and
           'sin volver a despachar' in step_six and 'f8-encargos.sh' not in step_six)
    sequence = re.findall(r'^\d+\. \*\*Persona', guide.read_text(), re.M)
    expect('guía secuencia única siete pasos', len(sequence) == 7 and [int(s.split('.')[0]) for s in sequence] == list(range(1,8)))
    commands = re.findall(r'\bbash "\$PKG/instalacion/scripts/([^"\n]+)\.sh"', guide.read_text())
    expect('guía órdenes en el orden ejercitado', commands == [
        'f8-originales', 'f8-encargos', 'f8-conservar', 'f8-handoff', 'f8-encargos', 'f8-originales',
        'f8-importar', 'f8-ciclo', 'check-F8'])
    text = guide.read_text()
    expect('F8 ya no captura ni registra los panes (lo hace F7) pero SÍ importa humo tras conservar los originales',
           'f8-capturas' not in text and 'calibrar-pane' not in text and 'capturar-done' not in text and
           text.count('f8-importar.sh') == 1 and text.index('f8-conservar') < text.index('f8-importar.sh') < text.index('f8-ciclo.sh') and
           'F7' in text)
    sequence = re.findall(r'^\d+\. \*\*Persona', calibration_guide.read_text(), re.M)
    expect('guía F7 secuencia única cinco pasos', len(sequence) == 5 and [int(s.split('.')[0]) for s in sequence] == list(range(1,6)))
    commands = re.findall(r'\bbash "\$PKG/instalacion/scripts/([^"\n]+)\.sh"', calibration_guide.read_text())
    expect('guía F7 órdenes en el orden ejercitado', commands == [
        'f8-capturas', 'f8-capturas', 'f8-capturas', 'f8-capturas', 'capturar-done', 'f8-capturas',
        'calibrar-pane', 'f8-importar', 'calibrar-pane', 'check-F7'])
    expect('guía F7 captura idle, barra, modal, busy, done y redraw en ese orden',
           re.findall(r'(?:f8-capturas|capturar-done)\.sh" "\$CLON" "\$CARRIL" v:\.0(?: (\w+))?', calibration_guide.read_text()) ==
           ['idle', 'barra', 'modal', 'busy', '', 'redraw'])
    text = calibration_guide.read_text()
    expect('guía reposo y ocupado medidos', 'teclear /clear' in text and 'Ctrl+L' not in text and
           'python3 -c "import time; time.sleep(40)"' in text and '6 segundos' in text)
    expect('guía barra: /model sin Enter, lista abierta, Escape y Ctrl-U', 'teclear /model SIN pulsar Enter' in text and
           'lista de órdenes' in text and 'Escape' in text and 'Ctrl-U' in text)
    expect('guía F7: la calibración va antes del doctor',
           text.index('calibrar-pane.sh') < text.index('doctor.sh') and text.index('f8-capturas.sh') < text.index('doctor.sh'))
    expect('guía acceso canal y desacople conservan sesión',
           '''incus exec "$CONTENEDOR" -- su - "$CUSER" -c 'tmux attach -t v' '''.strip() in text and
           'usuario_incus=' in text and 'cuser=' in text and 'Ctrl-b d' in text)

TOTAL_ESPERADO = 451
expect('conteo permanente', PASS+FAIL == TOTAL_ESPERADO, str(PASS+FAIL))
print(f'RESULTADO: PASS={PASS} FAIL={FAIL} TOTAL={PASS+FAIL}')
raise SystemExit(1 if FAIL else 0)
