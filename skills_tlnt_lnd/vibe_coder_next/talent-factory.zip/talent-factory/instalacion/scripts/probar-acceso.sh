#!/usr/bin/env bash
# Comprobación de acceso de un actor con el test BUILTIN de bash. El binario externo `test` no sirve:
# en Ubuntu 26.04 es el de uutils y su -r/-w/-x no cuenta los grupos suplementarios, así que un acceso
# concedido por grupo (el bus) da un falso rojo. Este ayudante es lo único que lanzan el instalador
# (por sudo -u) y las reglas sudoers del montaje: la orden es la misma en ambos sitios.
# Uso: probar-acceso.sh <-r|-w|-x|-e|-d|-f|-L> <ruta-absoluta>   o   probar-acceso.sh ! -L <ruta-absoluta>
# No imprime nada. rc 0 si se cumple; rc 1 si no se cumple o si los argumentos no son exactamente esa forma.
set -u
set +x
exec >/dev/null 2>&1
negado=0
case "$#" in
  2) flag=$1; ruta=$2 ;;
  3) [ "$1" = '!' ] && [ "$2" = '-L' ] || exit 1
     negado=1; flag=$2; ruta=$3 ;;
  *) exit 1 ;;
esac
case "$flag" in
  -r|-w|-x|-e|-d|-f|-L) ;;
  *) exit 1 ;;
esac
# Ruta absoluta y nada más: sin vacío, sin saltos de línea ni retornos de carro.
case "$ruta" in
  /*) ;;
  *) exit 1 ;;
esac
case "$ruta" in
  *$'\n'*|*$'\r'*) exit 1 ;;
esac
if [ "$negado" = 1 ]; then
  builtin test ! "$flag" "$ruta" && exit 0
else
  builtin test "$flag" "$ruta" && exit 0
fi
exit 1
