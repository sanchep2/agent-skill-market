"""Encargos y originales públicos del ensayo; secretos únicamente en escrow."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import tempfile

from fases import ROOT, STATE, Error, require, run, safe_dir, secret_values, channels, write, regular, code_audit, review_warning, role_clone
from recibos import immutable


def arguments(c, args):
    parser = argparse.ArgumentParser()
    parser.add_argument('issue')
    parser.add_argument('pr', nargs='?')
    parser.add_argument('--linea-pr', default='')
    ns = parser.parse_args(args)
    require(re.fullmatch(re.escape(c['answers']['linear_clave'])+r'-[1-9][0-9]*', ns.issue),
            'F8: issue inválida', 2)
    require(ns.pr is None or re.fullmatch(r'[1-9][0-9]*', ns.pr), 'F8: PR inválido', 2)
    require(not any(x in ns.linea_pr for x in '\r\n\x00'), 'F8: línea PR inválida', 2)
    return ns


def bus_sealer(clone, role):
    """Orden de sello del rol en el bus: nombra --rol, que bus-sellar.sh exige si la sesión no trae TA_ROL."""
    return shlex.join(['bash', str(clone/'.claude/skills/talent-ceo/scripts/bus-sellar.sh'),
                       '--marcador', '<marcador>', '--rol', role])


def assignments(c, args):
    ns = arguments(c, args)
    channel = channels(c)[0]
    lane = channel.removeprefix('vibe-channel-')
    preserve = shlex.join(['bash', str(ROOT/'instalacion/scripts/f8-conservar.sh'), ns.issue, c['project'], lane])
    audit = code_audit(c)
    if audit:
        print(review_warning())
    if ns.pr:
        clone = role_clone(c, 'M1')
        # El verificador es el del clon de M1: allí el instalador escribe repo-identity.conf, que la copia del paquete no trae.
        verifier = str(clone/'.claude/skills/talent-channel-operation/scripts/verify-code-audit-go.sh')
        reviewer_step = ('ejecuta una pasada del revisor y atiende su resultado' if not audit else
                         'como revisor es code-audit y no hay CodeRabbit: verifica el GO archivado en el PR con '
                         + shlex.join(['bash', verifier, ns.pr, '<head completo>']) +
                         ' (debe dar yes) y atiende un NO-GO o la ausencia del GO devolviendo el PR al canal')
        launcher = shlex.join(['bash', str(ROOT/'instalacion/scripts/lanza-gates.sh'), ns.pr, '<head completo>'])
        sealer = bus_sealer(clone, 'M1')
        print(f'Estación de merge: consume el PR {ns.pr} de {ns.issue} en el proyecto {c["project"]}. '
              'El instalador ya conservó el handoff del borrador. Los gates de fusión son el AND de talent-merger: '
              'local-gates sobre ese head, que produce '
              + launcher + ' (antes de correr ningún gate comprueba que tu token pueda publicar statuses; puede '
              'tardar: lánzalo en segundo plano y lee su resultado), más la revisión: '
              + reviewer_step + '. Los checks de CI ajenos al repositorio solo se informan, no bloquean. '
              'Fusiona únicamente con local-gates=success sobre el mismo head verificado y la revisión en verde. '
              'Completa la issue en Done tras la fusión. La clave de Linear no está en tu clon: es LINEAR_API_KEY en el '
              'fichero que apunta TA_OPERATION_ENV (ya está en tu sesión; no la imprimas ni la pases por argv). '
              'Sigue el procedimiento de autenticación y llamada GraphQL de '
              + str(clone/'.claude/skills/linear-skill/SKILL.md') + ' (resuelve la clave en ese fichero y, si falta, sale '
              'con un error que nombra la ruta). linear-client.ts no trae acción para cambiar el estado: usa el curl de ese '
              'procedimiento cambiando solo el cuerpo de -d. Primero consulta los estados del equipo de la issue, '
              '{"query":"{ issue(id: \\"' + ns.issue + '\\") { team { states { nodes { id name type } } } } }"}, '
              'elige el de nombre Done y tipo completed, y aplícalo con '
              '{"query":"mutation { issueUpdate(id: \\"' + ns.issue + '\\", input: {stateId: \\"<id de Done>\\"}) '
              '{ success issue { identifier state { name } } } }"}. '
              'Comprueba que la respuesta trae success true y state.name Done. Si ese procedimiento falla con su error '
              'claro, sella el bloqueo con ese motivo y detente. '
              'Sella hitos y bloqueos en el bus con tu identidad de rol, '
              + sealer + ' (TA_BUS y TA_ROL ya están en tu sesión); ante rojo, sella y detente.')
        return
    clone = role_clone(c, 'C1')
    # Mismo defecto que el de M1: el archivador se ejecuta desde el clon del coordinador, no desde la copia del paquete.
    archiver = str(clone/'.claude/skills/talent-channel-operation/scripts/verify-code-audit-go.sh')
    archive_step = ('' if not audit else
                    'Como el revisor es code-audit, tras el GO de la auditoría de código sobre el commit definitivo y antes de '
                    'retirar el borrador, archiva el veredicto en el PR con '
                    + shlex.join(['bash', archiver, '--archivar', '<pr>', lane, '<literal-del-veredicto>']) + '. ')
    print(f'Coordinador: lleva {ns.issue} del proyecto {c["project"]} hasta un PR en borrador con '
          f'entrega validada. Despacha tú con dispatch.sh al carril {lane} (contenedor {channel}), '
          'desde tu clon de producto y tu identidad. Código solo tras plan-gate GO. '
          + archive_step +
          'Al terminar, ejecuta '+preserve+' desde tu identidad. '
          'El ayudante conserva plan-normalizado.norm y audit-last.env sin modificar los registros del skill. '
          'Conserva íntegros, sin redactar, en $HOME/evidencias-fabrica/' + c['project'] + '/' + ns.issue + '/humo '
          'los otros originales de nombre fijo: '
          'veredicto-plan.txt (veredicto de su auditoría), informe-parada.md (informe de parada '
          'del desarrollador) y veredicto-codigo.txt (veredicto final de auditoría de código). '
          'El informe exige cabecera STOP-AUDIT — '+ns.issue+' y SHA auditado: seguido del head completo. Conserva ambos JSON del auditor '
          'con run_id, artifact_type, artifact_sha completo, verdict y blocking_findings, '
          'incluido el veredicto code cuyo run_id casa con audit-last.env. Valida el handoff con los gates del producto mientras '
          'el PR sigue en borrador. Devuelve su número y espera a que el instalador conserve '
          'f8-handoff. No fusiones ni retires el borrador. Sella hitos y bloqueos en el bus con tu identidad de rol, '
          + bus_sealer(clone, 'C1') + ' (TA_BUS y TA_ROL ya están en tu sesión); ante rojo, sella y detente.')
    if ns.linea_pr:
        print('Opción declarada por la persona: incluye exactamente como última línea del cuerpo del PR:')
        print(ns.linea_pr)
    elif audit:
        print('Revisor code-audit: no hay revisión automática de la App que desactivar.')
    else:
        print('Opción --linea-pr no declarada: antes de retirar el borrador, la persona debe '
              'desactivar la revisión automática de la App o aceptar explícitamente el gasto adicional.')


def linear(c, issue):
    token = secret_values(c).get('LINEAR_API_KEY')
    require(token and not any(x in token for x in '\r\n'), 'originales: token Linear missing')
    safe_dir(c['escrow'])
    fd, name = tempfile.mkstemp(dir=c['escrow'])
    os.close(fd)
    try:
        write(Path(name), 'Authorization: '+token+'\n')
        body = run(['curl', '--fail', '--silent', '--show-error', '--max-time', '30',
                    '--header', '@'+name, '--header', 'Content-Type: application/json',
                    '--data', json.dumps({'query':'query($id:String!){issue(id:$id){identifier title createdAt state{name}}}',
                                          'variables':{'id':issue}}), 'https://api.linear.app/graphql'],
                   diagnostic='originales: issue.json/issue-done.json consulta Linear fallida')
        data = json.loads(body)
    finally:
        Path(name).unlink(missing_ok=True)
    require(isinstance(data, dict) and isinstance(data.get('data'), dict) and
            isinstance(data['data'].get('issue'), dict),
            'originales: issue.json/issue-done.json respuesta parcial: data.issue o errores')
    record = data['data']['issue']
    require(isinstance(record.get('identifier'), str) and record['identifier'].strip(),
            'originales: issue.json/issue-done.json respuesta parcial: data.issue.identifier')
    require(not data.get('errors') and record.get('identifier') == issue,
            'originales: issue.json/issue-done.json respuesta de otra issue o errores')
    initial_issue(record)
    require(isinstance(record.get('state'), dict) and isinstance(record['state'].get('name'), str) and
            record['state']['name'].strip(), 'originales: issue.json/issue-done.json respuesta parcial: state.name')
    return body, data['data']['issue']


def initial_issue(issue):
    require(isinstance(issue.get('title'), str) and issue['title'].strip() and
            isinstance(issue.get('createdAt'), str) and
            re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})', issue['createdAt']),
            'originales: etapa issue fichero issue.json respuesta parcial: título/fecha de creación')
    try:
        datetime.fromisoformat(issue['createdAt'].replace('Z', '+00:00'))
    except ValueError:
        require(False, 'originales: etapa issue fichero issue.json fecha de creación inválida')
    return {key: issue[key] for key in ('identifier', 'title', 'createdAt')}


def save_initial(directory, issue):
    # La creación se acredita independientemente del estado al consultar.
    path = directory/'issue.json'
    identity = initial_issue(issue)
    if path.exists() or path.is_symlink():
        old = json.loads(regular(path).read_text())
        prior = initial_issue((old.get('data') or {}).get('issue') or {})
        require(all(prior[key] == identity[key] for key in ('identifier', 'createdAt')),
                'originales: etapa issue fichero issue.json consulta inicial distinta (guarda '+str(prior['identifier'])+
                '); si la issue de humo se creó mal, cancélela en Linear con un comentario, cree la nueva con '
                'talent-issue-craft y ejecute f8-originales.sh --sustituir NUEVA (F8, Remediación)')
    else:
        immutable(path, (json.dumps({'data': {'issue': identity}}, ensure_ascii=False)+'\n').encode())


def substitute(c, args):
    # Única salida documentada para una issue de humo creada mal: solo antes del cierre y con la anterior
    # Canceled en Linear (estado leído, nunca declarado). El original se aparta sin borrarlo y queda traza.
    require(len(args) == 2 and args[0] == '--sustituir', 'uso f8-originales --sustituir NUEVA', 2)
    ns = arguments(c, args[1:])
    directory = STATE/'humo'
    safe_dir(STATE)
    safe_dir(directory)
    path = directory/'issue.json'
    require(path.exists() or path.is_symlink(),
            'originales: sustituir: no hay issue.json que sustituir; sin original previo use f8-originales.sh ISSUE')
    for name in ('merge.json', 'issue-done.json'):
        require(not ((directory/name).exists() or (directory/name).is_symlink()),
                'originales: sustituir: ya existe '+name+'; la issue de humo ya cerró y no se sustituye')
    content = regular(path).read_bytes()
    prior = initial_issue((json.loads(content).get('data') or {}).get('issue') or {})
    previous = prior['identifier']
    require(isinstance(previous, str) and
            re.fullmatch(re.escape(c['answers']['linear_clave'])+r'-[1-9][0-9]*', previous),
            'originales: sustituir: issue.json guarda un identificador inválido')
    require(ns.issue != previous, 'originales: sustituir: la nueva '+ns.issue+' es la misma issue que guarda issue.json')
    found = {}
    for issue in (previous, ns.issue):
        try:
            found[issue] = linear(c, issue)[1]
        except Error as exc:
            raise Error('originales: sustituir: consulta Linear de '+issue+': '+str(exc), exc.rc) from None
    old = found[previous]
    require(old['createdAt'] == prior['createdAt'],
            'originales: sustituir: issue.json no coincide con '+previous+' en Linear (fecha de creación)')
    require(old['state']['name'] == 'Canceled',
            'originales: sustituir: la anterior '+previous+' está en '+old['state']['name']+', no Canceled; '
            'cancélela en Linear con un comentario y repita')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    aside = directory/('issue.json.'+previous+'-sustituida-'+stamp)
    trace = directory/(aside.name+'.traza.json')
    require(not any(p.exists() or p.is_symlink() for p in (aside, trace)),
            'originales: sustituir: destino ya existe '+aside.name+'; repita pasado un segundo')
    digest = hashlib.sha256(content).hexdigest()
    # Enlace duro sin sobrescritura: el original apartado es el mismo contenido, comprobado por sha256.
    os.link(path, aside)
    require(hashlib.sha256(regular(aside).read_bytes()).hexdigest() == digest,
            'originales: sustituir: el original apartado no conserva su sha256')
    immutable(trace, (json.dumps({'anterior': previous, 'nueva': ns.issue, 'hora': stamp,
                                  'estado_anterior': old['state']['name'], 'apartado': aside.name,
                                  'sha256': digest}, ensure_ascii=False)+'\n').encode())
    path.unlink()
    save_initial(directory, found[ns.issue])
    print('original apartado: '+str(aside))
    print('traza: '+str(trace))
    print(path)


def originals(c, args):
    ns = arguments(c, args)
    require(not ns.linea_pr, 'originales: --linea-pr solo para encargos', 2)
    directory = STATE/'humo'
    safe_dir(STATE)
    safe_dir(directory)
    body, issue = linear(c, ns.issue)
    if ns.pr is None:
        save_initial(directory, issue)
        print(directory/'issue.json')
        return
    require(issue.get('state', {}).get('name') == 'Done', 'originales: etapa Done fichero issue-done.json no está Done')
    slug = c['answers']['repo_url'].split('github.com/', 1)[1].removesuffix('.git')
    pr_body = run(['gh', 'pr', 'view', ns.pr, '--repo', slug, '--json',
                   'number,state,headRefOid,mergeCommit,body,files,statusCheckRollup'],
                  diagnostic='originales: etapa merge fichero merge.json consulta GitHub fallida')
    pr = json.loads(pr_body)
    from originales import pr_record
    pr_record(pr, ns.issue, number=int(ns.pr))
    require(pr.get('state') == 'MERGED' and re.fullmatch(r'[0-9a-f]{40}', pr.get('headRefOid', '')) and
            re.fullmatch(r'[0-9a-f]{40}', (pr.get('mergeCommit') or {}).get('oid', '')) and
            re.search(r'(?i)\b(?:closes|fixes|resolves)\s+'+re.escape(ns.issue)+r'\b', pr.get('body', '')),
            'originales: etapa merge fichero merge.json sin fusión/head/vínculo')
    save_initial(directory, issue)
    immutable(directory/'merge.json', pr_body.encode())
    immutable(directory/'issue-done.json', body.encode())
    print('originales conservados: merge.json issue-done.json')
