"""Protección GitHub: valores cerrados, comparación tras aplicación."""
import json
from pathlib import Path
import subprocess
import sys
# Antes de cualquier import del paquete: un __pycache__ dentro de $PKG/skills acabaría copiado al repo del alumno.
sys.dont_write_bytecode = True
from fases import Error, command_context, execute, config, require, run

# Lectura estable tras escribir (issue 9011): el helper vive en el skill porque verify-repo-parity.sh
# también lo usa en repos de producto, sin instalacion/. `matches` es el suyo, con la misma semántica.
sys.path.insert(0, str(Path(__file__).resolve().parents[2]/'skills/talent-repo-onboarding/scripts/lib'))
import lectura_estable
from lectura_estable import matches

BODY = {'required_status_checks': {'strict': True, 'checks': [{'context': 'local-gates'}]},
        'enforce_admins': False,
        'required_pull_request_reviews': {'required_approving_review_count': 0, 'dismiss_stale_reviews': True,
                                         'require_code_owner_reviews': False, 'require_last_push_approval': False},
        'restrictions': None, 'required_linear_history': True, 'allow_force_pushes': False,
        'allow_deletions': False, 'block_creations': False, 'required_conversation_resolution': True}
SETTINGS = {'allow_squash_merge': True, 'allow_merge_commit': True, 'allow_rebase_merge': True,
            'delete_branch_on_merge': False}


def main():
    require(sys.argv[1:] in (['--plan'], ['--ejecutar']), 'uso f4-proteccion --plan|--ejecutar', 2)
    c = config()
    a = c['answers']
    from rulesets import effective_rules, es_403_de_plan, PENDIENTE_PLAN_GRATUITO
    effective_rules(c)
    slug = a['repo_url'].removesuffix('.git').split('github.com/')[1]
    repo = 'repos/'+slug
    endpoint = repo+'/branches/'+a['repo_rama']+'/protection'
    current_repo = json.loads(run(['gh', 'api', repo]))
    require(isinstance(current_repo, dict), 'protección: respuesta no verificable')
    # 404 puede significar falta de protección/permisos: no se presume plan gratuito.
    p = execute(['gh', 'api', endpoint], stdin=subprocess.DEVNULL, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    current = json.loads(p.stdout) if p.returncode == 0 else None
    print('Estado actual repo: '+json.dumps({k: current_repo.get(k) for k in SETTINGS}, sort_keys=True))
    print('Estado actual protección: '+json.dumps(current, sort_keys=True))
    print('PUT '+endpoint+'\n'+json.dumps(BODY, sort_keys=True))
    print('PATCH '+repo+'\n'+json.dumps(SETTINGS, sort_keys=True))
    if sys.argv[1] == '--plan':
        if p.returncode:
            print('Protección no legible: confirmar permisos/plan; privado gratuito puede quedar pendiente procedimental.')
        return
    # Privado gratuito: el PUT de protección da el 403 de plan. Solo ese 403 exacto (misma detección que las
    # reglas efectivas) sigue al PATCH de ajustes; cualquier otro fallo del PUT o del PATCH es rc 1.
    plan_gratuito = False
    for method, url, body in [('PUT', endpoint, BODY), ('PATCH', repo, SETTINGS)]:
        result = execute(['gh', 'api', '--method', method, url, '--input', '-'], input=json.dumps(body),
                                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if method == 'PUT' and result.returncode and es_403_de_plan(getattr(result, 'stderr', '')):
            plan_gratuito = True
            print(PENDIENTE_PLAN_GRATUITO)
            continue
        require(result.returncode == 0, 'protección: aplicación rechazada; comprobar admin y plan del repo; '+
                command_context(['gh', 'api', '--method', method, url, '--input', '-']))
    # GitHub puede alternar nuevo → viejo → nuevo tras escribir: se exige una lectura ESTABLE de cada
    # endpoint (lectura_estable.py). Los errores de gh y las respuestas no JSON siguen siendo error.
    # En privado gratuito la protección no existe: solo se relee los ajustes.
    lecturas = (('ajustes', repo, SETTINGS),) if plan_gratuito else (('protección', endpoint, BODY), ('ajustes', repo, SETTINGS))
    for name, url, expected in lecturas:
        stable, _, reason = lectura_estable.leer_estable(lambda url=url: json.loads(run(['gh', 'api', url])),
                                                         expected, url)
        require(stable, name+': relectura distinta; '+reason)
    if plan_gratuito:
        print('ajustes verificados; protección no aplicable en privado gratuito')
        raise Error(PENDIENTE_PLAN_GRATUITO, 3)
    print('protección y ajustes verificados')


if __name__ == '__main__':
    try:
        main()
    except (Error, OSError, ValueError, KeyError) as exc:
        print('falla '+(str(exc) if isinstance(exc, Error) else 'respuesta no verificable'), file=sys.stderr)
        sys.exit(exc.rc if isinstance(exc, Error) else 1)
