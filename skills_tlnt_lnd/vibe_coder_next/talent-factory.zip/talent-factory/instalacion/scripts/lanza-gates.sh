#!/usr/bin/env bash
# Lanzador de gates de la estación M1: uso `bash lanza-gates.sh <pr> <head completo>`. Sin timer, servicio ni cola.
# Puede tardar (cada gate hasta TF_GATE_TIMEOUT s): lánzalo en segundo plano y lee su resultado.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
# shellcheck source=/dev/null
. "$HERE/../lib-fases.sh"
fases_ejecutar estacion-gates "$@"
