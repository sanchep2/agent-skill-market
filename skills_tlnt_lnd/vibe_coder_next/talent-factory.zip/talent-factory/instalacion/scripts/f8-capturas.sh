#!/usr/bin/env bash
# Capturar un estado real y clasificar antes de publicar el fichero.
set -euo pipefail
umask 077
fail() { printf 'falla captura %s: %s\n' "${estado:-sin estado}" "$*" >&2; exit 1; }
[ $# -ge 4 ] && [ $# -le 5 ] || { echo 'uso f8-capturas CLON CARRIL PANE ESTADO [--repetir]' >&2; exit 2; }
clon=$1; carril=$2; pane=$3; estado=$4; repetir=${5:-}
case "$estado" in idle|busy|done|modal|redraw|barra) ;; *) fail 'estado inválido' ;; esac
[ -z "$repetir" ] || [ "$repetir" = --repetir ] || fail 'opción inválida'
case "$clon" in /*) ;; *) fail 'CLON debe ser absoluto' ;; esac
scripts="$clon/.claude/skills/talent-channel-operation/scripts"
for file in 00-config.sh lib.sh capture-pane-fixtures.sh; do
  [ -f "$scripts/$file" ] && [ ! -L "$scripts/$file" ] || fail "falta $scripts/$file"
done
# shellcheck source=/dev/null
. "$scripts/00-config.sh" || fail 'no se pudo cargar configuración'
# shellcheck source=/dev/null
. "$scripts/lib.sh" || fail 'no se pudo cargar parser'
[ -n "${TCO_PANE_CLI_VERSION_CMD:-}" ] || fail 'define TCO_PANE_CLI_VERSION_CMD con la versión real del CLI (claude --version o codex --version); sin ella no se captura'
[ -n "${TCO_FIXTURE_DIR:-}" ] || fail 'define TCO_FIXTURE_DIR con ruta absoluta'
case "$TCO_FIXTURE_DIR" in /*) ;; *) fail 'TCO_FIXTURE_DIR debe ser absoluto' ;; esac
version="$(_tco_pane_cli_version "$carril" "$pane")" || fail 'no se pudo consultar CLI/versión; revisa TCO_PANE_CLI_VERSION_CMD y no repitas la captura hasta que responda'
[[ $version =~ ^(claude|codex):[0-9]+\.[0-9]+\.[0-9]+$ ]] \
  || fail 'CLI/versión inválidos (se esperaba claude:X.Y.Z o codex:X.Y.Z); no repitas la captura: el problema no es la pantalla'
# Perfil del TUI de este CLI para clasificar: lo fija el CLI resuelto, no una perilla del operador.
TCO_TUI_CLI="$(tco_tui_cli_de "$version")" || fail "el analizador del TUI no tiene perfil para $version; no repitas la captura"
export TCO_TUI_CLI
# Con una versión de Codex sin capturas de referencia en el paquete, un fallo no prueba un estado mal provocado: el TUI de esa
# versión puede haber cambiado. Se repite UNA vez y se escala; con referencias (y siempre con Claude) vale el mensaje de siempre.
repite=''
if [ "${version%%:*}" = codex ] && [ ! -d "$scripts/../tests/fixtures/pane/${version/:/_}" ]; then
  repite="la versión $version no tiene capturas de referencia en el paquete: si el estado provocado era el correcto, el TUI de esta versión puede haber cambiado; repite UNA vez y, si vuelve a fallar, para y escala con las capturas"
fi
destination="$TCO_FIXTURE_DIR/${version/:/_}/$estado.txt"
parent=${destination%/*}
probe=$parent
while [ "$probe" != / ]; do
  [ ! -L "$probe" ] || fail "directorio enlazado: $probe"
  probe=${probe%/*}; [ -n "$probe" ] || probe=/
done
[ ! -L "$destination" ] || fail "destino enlazado: $destination"
if [ -e "$destination" ]; then
  [ -f "$destination" ] || fail "destino no regular: $destination"
  [ "$repetir" = --repetir ] || fail "destino existente: $destination; usa --repetir"
fi
work="$(mktemp -d)" || fail 'no se pudo crear área temporal'
trap 'rm -rf "$work"' EXIT
tco_cap_pane "$carril" "$pane" > "$work/pane" || fail 'no se pudo leer el panel'
# done y barra se guardan con su propio nombre; el capturador solo conoce los cuatro estados de siempre y los trata como idle.
capture_state=$estado; case "$estado" in done|barra) capture_state=idle ;; esac
if ! TCO_FIXTURE_DIR="$work" bash "$scripts/capture-pane-fixtures.sh" --from-stdin \
  --cli-version "$version" "$capture_state" < "$work/pane" > "$work/capturador.log" 2>&1; then
  fail "capturador rechazó la pantalla (secreto/cuenta, vacío o compositor ausente); ${repite:-limpia la pantalla y repite}"
fi
capture="$work/${version/:/_}/$capture_state.txt"
[ -s "$capture" ] || fail 'fichero temporal vacío'
rc=0; tco_pane_busy_from < "$capture" >/dev/null 2>&1 || rc=$?
case "$estado" in idle|done|barra) esperado=1 ;; busy) esperado=0 ;; *) esperado=2 ;; esac
[ "$rc" = "$esperado" ] || fail "clasificación rc=$rc esperado=$esperado; ${repite:-descartada, vuelve a provocar el estado}"
# barra = /model tecleado SIN Enter con la lista de órdenes abierta: reposo Y compositor con exactamente «/model». Una pantalla
# vacía o con otro texto no acredita que el analizador reconozca la lista que abre el CLI instalado (el punto que falló en el ensayo).
if [ "$estado" = barra ]; then
  # La lista abierta es una rama propia del analizador: reposo y eco de /model no bastan (un compositor con /model, el pie
  # normal y la lista cerrada también los cumple).
  tco_tui_list_open_from < "$capture" >/dev/null 2>&1 \
    || fail "barra: no se ve la lista de órdenes abierta con /model en el compositor (con la lista cerrada no vale); ${repite:-teclea /model sin Enter y repite}"
  composer="$(tco_tui_regions_from composer < "$capture" 2>/dev/null)" \
    && printf '%s' "$composer" | tco_composer_echo_from /model \
    || fail "barra: el compositor no contiene exactamente /model con la lista de órdenes abierta; ${repite:-teclea /model sin Enter y repite}"
fi
mkdir -p "$parent" || fail "no se pudo crear $parent"
if [ -e "$destination" ]; then
  backup="$(mktemp "$parent/$estado.rechazada.XXXXXX")" || fail 'no se pudo conservar captura anterior'
  cp -- "$destination" "$backup" || fail 'no se pudo conservar captura anterior'
fi
install -m 600 "$capture" "$destination" || fail "no se pudo guardar $destination"
printf 'captura %s clasificada rc=%s: %s\n' "$estado" "$rc" "$destination"
