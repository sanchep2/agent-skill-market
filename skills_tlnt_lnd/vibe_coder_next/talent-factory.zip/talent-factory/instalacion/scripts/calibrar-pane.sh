#!/usr/bin/env bash
# Clasifica capturas usando el parser real instalado; no registra versiones automáticamente.
# Estados: idle busy done modal redraw, más barra (/model tecleado sin Enter, con la lista de órdenes abierta: reposo y
# compositor exacto «/model»). Con --completo o --registrar la sexta captura es OBLIGATORIA; sin ellas, si existe se
# valida igual (nunca se acepta una barra mal clasificada), pero su ausencia no impide clasificar el juego anterior.
set -uo pipefail
modo=''
case "$#:${3:-}" in
  2:|3:--registrar) ;;
  3:--completo) ;;
  *) echo 'precondición calibrar-pane CLON DIRECTORIO [--completo|--registrar]' >&2; exit 2 ;;
esac
[ "$#" -eq 2 ] || modo="$3"
lib="$1/.claude/skills/talent-channel-operation/scripts/lib.sh"
[ -f "$lib" ] && [ ! -L "$lib" ] || { echo "falla parser ausente: $lib" >&2; exit 1; }
# shellcheck source=/dev/null
. "$lib" || { echo "falla carga del parser: $lib" >&2; exit 1; }
# Perfil del TUI = el CLI del nombre del directorio «<cli>_<versión>» (claude_2.1.302, codex_0.166.0); cualquier otro nombre
# conserva las reglas de siempre. Se fija aquí siempre: un valor heredado del entorno nunca decide.
par="${2%/}"; par="${par##*/}"
TCO_TUI_CLI="$(tco_tui_cli_de "$par")" || TCO_TUI_CLI=''
export TCO_TUI_CLI
# Una versión de Codex sin capturas de referencia en el paquete no prueba un estado mal provocado: se repite UNA vez y se escala.
sin_refs=''
if [ "$TCO_TUI_CLI" = codex ] && [ ! -d "${lib%/*}/../tests/fixtures/pane/$par" ]; then
  sin_refs="; la versión ${par/_/:} no tiene capturas de referencia en el paquete: si el estado provocado era el correcto, el TUI de esta versión puede haber cambiado; repite UNA vez y, si vuelve a fallar, para y escala con las capturas"
fi
for estado in idle busy 'done' modal redraw barra; do
  fichero="$2/$estado.txt"
  if [ "$estado" = barra ] && [ -z "$modo" ] && [ ! -e "$fichero" ] && [ ! -L "$fichero" ]; then continue; fi
  [ -s "$fichero" ] && [ ! -L "$fichero" ] || { echo "falla captura ausente: $estado" >&2; exit 1; }
  tco_fixture_secret_scan < "$fichero" >/dev/null 2>&1 || { echo "falla captura rechazada: $estado" >&2; exit 1; }
  rc=0
  tco_pane_busy_from < "$fichero" >/dev/null 2>&1 || rc=$?
  case "$estado" in idle|done|barra) esperado=1 ;; busy) esperado=0 ;; *) esperado=2 ;; esac
  [ "$rc" -eq "$esperado" ] || { echo "falla clasificación: $estado rc=$rc esperado=$esperado$sin_refs" >&2; exit 1; }
  if [ "$estado" = barra ]; then
    # La barra solo vale con la lista de órdenes ABIERTA (rama propia del analizador): reposo y eco de /model no bastan,
    # porque un compositor con /model, el pie normal y la lista cerrada también los cumple (el caso que falló en el ensayo).
    tco_tui_list_open_from < "$fichero" >/dev/null 2>&1 \
      || { echo 'falla clasificación: barra sin la lista de órdenes abierta (/model en el compositor con el pie normal no la acredita)' >&2; exit 1; }
    composer="$(tco_tui_regions_from composer < "$fichero" 2>/dev/null)" \
      && printf '%s' "$composer" | tco_composer_echo_from /model \
      || { echo 'falla clasificación: barra sin /model exacto en el compositor' >&2; exit 1; }
  fi
done
echo 'capturas clasificadas'
if [ "$modo" = --registrar ]; then
  HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
  python3 "$HERE/calibracion.py" "$2"
fi
