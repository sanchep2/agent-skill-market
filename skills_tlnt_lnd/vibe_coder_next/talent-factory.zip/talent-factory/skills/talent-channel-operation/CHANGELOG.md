# Changelog — talent-channel-operation

Esta es la distribución publicable del paquete de fábrica: la bitácora interna de
desarrollo no se incluye.

## Distribución pública — 2026-09 (paquete 1.7.5, versión intermedia)

- 1.7.5: el analizador del TUI elige sus reglas por el CLI de cada panel (`TCO_TUI_CLI`, que fijan con
  `local -x` las entradas por panel desde el CLI declarado y que `00-config.sh` nunca hereda del entorno).
  Vacío o `claude` conserva las reglas de siempre; `codex` usa las suyas (compositor `›` sin bordes, línea de
  estado, ocupado por la última línea en columna 0 y lista de órdenes propia); cualquier otro valor da rc 2.
  Fixtures reales `codex_0.166.0` y prueba `tests/test-tui-codex.sh`.
- 1.7.4f: un «[Request interrupted by user]» final (o su variante «… for tool use]»), solo en la
  forma array de UN elemento `text` con el texto exacto (un string con ese texto es un humano),
  cuenta como reposo en `tco_transcript_inflight_from`, de modo que `tco_pane_busy` ya no ve «ocupado» tras el
  Escape del plan-gate y `tco_set_model`/`tco_set_effort` pueden abrir el picker. Un único predicado
  compartido (`_TCO_JQ_INTERRUPT_DEFS`) lo aplica también a `tco_exitplan_plan_from`,
  `tco_last_assistant_text_from` y `tco_user_submit_*`.
