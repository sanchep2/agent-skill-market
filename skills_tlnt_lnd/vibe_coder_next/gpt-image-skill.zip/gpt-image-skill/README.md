# gpt-image-skill — Producción de ads con GPT Image 2 desde Claude Code

Skill instalable para Claude Code: genera creatividades de campaña (feed, stories,
banners display, heros) con GPT Image 2 y las entrega en las dimensiones EXACTAS de cada
plataforma, con texto y CTA renderizados en la imagen.

## Instalación (3 pasos)

1. Descomprime este ZIP.
2. Copia la carpeta `gpt-image-skill` a `~/.claude/skills/` (disponible en todos tus
   proyectos) o a `.claude/skills/` dentro de tu proyecto.
3. Instala la única dependencia de los scripts: `pip install Pillow`.

Listo: pide a Claude Code "hazme las creatividades de la campaña X" y el skill se activa.

## Las dos rutas de generación

- **Puente Codex (por defecto, sin API key)**: usa Codex CLI autenticado con tu cuenta de
  ChatGPT. Requiere `codex` instalado y logueado (`codex login`).
- **API directa de OpenAI**: requiere `OPENAI_API_KEY` con límite de gasto configurado.
  Da control exacto de parámetros, edits con máscara y lotes.

El skill trae sondas que comprueban lo que falta ANTES de gastar nada y te dicen
exactamente cómo arreglarlo.

## Qué incluye

- `SKILL.md` — punto de entrada: sondas, quick starts y gotchas.
- `references/ads-playbook.md` — el pipeline completo de campaña (empieza por aquí).
- `references/ruta-codex-bridge.md` · `ruta-api-directa.md` — las dos rutas al detalle.
- `references/restricciones-y-validacion.md` — el contrato de tamaños del modelo.
- `references/specs-plataformas.md` — dimensiones, pesos y safe zones por plataforma.
- `scripts/validate_image_request.py` — validador pre-flight (evita generaciones inválidas).
- `scripts/adapt_master.py` — adaptador master → asset publicable exacto (+ overlay de
  safe zone). Ambos con tests (`test_*.py`).
