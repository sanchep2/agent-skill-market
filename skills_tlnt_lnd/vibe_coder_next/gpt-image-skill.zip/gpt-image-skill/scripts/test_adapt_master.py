#!/usr/bin/env python3
"""Tests deterministas de adapt_master.py (unittest + Pillow, sin red).

Correr: python3 test_adapt_master.py
"""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from PIL import Image

from adapt_master import (
    PLATFORM_SPECS,
    AdaptationError,
    adapt,
    cover_crop,
    safezone_overlay,
    spec_for,
)


def _master(width: int, height: int, detail: bool = False) -> Image.Image:
    """Master sintético; con detail=True añade ruido de alta frecuencia (difícil de comprimir)."""
    img = Image.new("RGB", (width, height), (30, 90, 60))
    if detail:
        import random

        rnd = random.Random(42)  # determinista
        px = img.load()
        for x in range(width):
            for y in range(0, height, 2):
                px[x, y] = (rnd.randrange(256), rnd.randrange(256), rnd.randrange(256))
    return img


class TestCoverCrop(unittest.TestCase):
    def test_sin_distorsion_story(self) -> None:
        """Master 9:16 (1152x2048) → 1080x1920 exactos, crop centrado."""
        out = cover_crop(_master(1152, 2048), 1080, 1920)
        self.assertEqual(out.size, (1080, 1920))

    def test_cuadrado_a_display(self) -> None:
        """Master 1:1 (2048x2048) → 300x250 exactos (deriva del feed)."""
        out = cover_crop(_master(2048, 2048), 300, 250)
        self.assertEqual(out.size, (300, 250))


class TestAdapt(unittest.TestCase):
    def test_story_1080x1920_exactos(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            master = Path(td) / "master.png"
            _master(1152, 2048).save(master)
            result = adapt(master, spec_for("meta-story"), Path(td) / "story.jpg")
            self.assertEqual((result["width"], result["height"]), (1080, 1920))
            with Image.open(result["out"]) as img:
                self.assertEqual(img.size, (1080, 1920))
            self.assertLessEqual(result["bytes"], result["max_bytes"])

    def test_display_300x250_bajo_150kb(self) -> None:
        """Condición observable: el 300x250 sale <= 150 KB o falla explícito."""
        with tempfile.TemporaryDirectory() as td:
            master = Path(td) / "master.png"
            _master(2048, 2048, detail=True).save(master)
            result = adapt(master, spec_for("gdn-300x250"), Path(td) / "banner.jpg")
            self.assertEqual((result["width"], result["height"]), (300, 250))
            self.assertLessEqual(result["bytes"], 150 * 1024)
            self.assertEqual(Path(result["out"]).stat().st_size, result["bytes"])

    def test_peso_inalcanzable_falla_explicito(self) -> None:
        """Si ni la quality mínima cabe en el límite, AdaptationError — nunca silencio."""
        import dataclasses

        spec_imposible = dataclasses.replace(spec_for("gdn-300x250"), max_bytes=100)
        with tempfile.TemporaryDirectory() as td:
            master = Path(td) / "master.png"
            _master(2048, 2048, detail=True).save(master)
            with self.assertRaises(AdaptationError):
                adapt(master, spec_imposible, Path(td) / "imposible.jpg")

    def test_frontera_floor_se_codifica_antes_de_fallar(self) -> None:
        """M8: si SOLO quality=40 (floor) cabe en el límite, el adaptador debe producirlo,
        no fallar sin haberlo probado. Límite construido entre el peso a floor y a floor+step."""
        import dataclasses
        import io

        from adapt_master import (
            JPEG_QUALITY_FLOOR,
            QUALITY_STEP,
            _encode,
            cover_crop,
        )

        img = _master(2048, 2048, detail=True)
        base_spec = spec_for("gdn-300x250")
        final = cover_crop(img, base_spec.width, base_spec.height)
        size_floor = len(_encode(final, "JPEG", JPEG_QUALITY_FLOOR))
        size_above = len(_encode(final, "JPEG", JPEG_QUALITY_FLOOR + QUALITY_STEP))
        self.assertLess(size_floor, size_above)  # premisa del caso frontera
        limit = (size_floor + size_above) // 2  # solo el floor cabe

        spec_frontera = dataclasses.replace(base_spec, max_bytes=limit)
        with tempfile.TemporaryDirectory() as td:
            master = Path(td) / "master.png"
            img.save(master)
            result = adapt(master, spec_frontera, Path(td) / "frontera.jpg")
            self.assertEqual(result["quality"], JPEG_QUALITY_FLOOR)
            self.assertLessEqual(result["bytes"], limit)

    def test_extension_incompatible_falla(self) -> None:
        """Un .png cuyo contenido sería JPEG rompe validaciones aguas abajo — se rechaza."""
        with tempfile.TemporaryDirectory() as td:
            master = Path(td) / "master.png"
            _master(2048, 2048).save(master)
            with self.assertRaises(AdaptationError):
                adapt(master, spec_for("meta-feed"), Path(td) / "final.png")

    def test_spec_desconocida(self) -> None:
        with self.assertRaises(KeyError):
            spec_for("periodico-impreso")

    def test_out_no_pisa_el_master(self) -> None:
        """El destino jamás sobreescribe el master: ni mismo path ni hard link."""
        import dataclasses
        import os

        spec_png = dataclasses.replace(spec_for("meta-feed"), file_format="PNG")
        with tempfile.TemporaryDirectory() as td:
            master = Path(td) / "master.png"
            _master(2048, 2048).save(master)
            before = master.read_bytes()
            with self.assertRaises(AdaptationError):
                adapt(master, spec_png, master)  # mismo path
            link = Path(td) / "link.png"
            os.link(master, link)
            with self.assertRaises(AdaptationError):
                adapt(master, spec_png, link)  # hard link
            self.assertEqual(master.read_bytes(), before)


class TestSafezone(unittest.TestCase):
    def test_overlay_es_artefacto_separado(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            master = Path(td) / "master.png"
            _master(1152, 2048).save(master)
            result = adapt(master, spec_for("meta-story"), Path(td) / "story.jpg")
            asset = Path(result["out"])
            before = asset.read_bytes()
            overlay_path = Path(safezone_overlay(asset, spec_for("meta-story")))
            self.assertTrue(overlay_path.exists())
            self.assertEqual(overlay_path.name, "story-safezone.png")
            self.assertNotEqual(overlay_path, asset)
            self.assertEqual(asset.read_bytes(), before)  # el asset NO cambió

    def test_overlay_se_niega_a_pisar_el_asset(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            asset = Path(td) / "a.png"
            _master(1080, 1920).save(asset)
            with self.assertRaises(AdaptationError):
                safezone_overlay(asset, spec_for("meta-story"), asset)

    def test_overlay_rechaza_hardlink_al_asset(self) -> None:
        """Un hard link al asset esquiva el check de paths resueltos — samefile lo caza."""
        import os

        with tempfile.TemporaryDirectory() as td:
            asset = Path(td) / "a.png"
            _master(1080, 1920).save(asset)
            before = asset.read_bytes()
            link = Path(td) / "b.png"
            os.link(asset, link)
            with self.assertRaises(AdaptationError):
                safezone_overlay(asset, spec_for("meta-story"), link)
            self.assertEqual(asset.read_bytes(), before)

    def test_overlay_rechaza_extension_no_png(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            asset = Path(td) / "a.png"
            _master(1080, 1920).save(asset)
            with self.assertRaises(AdaptationError):
                safezone_overlay(asset, spec_for("meta-story"), Path(td) / "overlay.jpg")

    def test_overlay_tiktok_pinta_franja_derecha(self) -> None:
        """TikTok declara safe_right_pct=0.15: el píxel del borde derecho debe quedar
        teñido por la franja y el del centro no."""
        spec = spec_for("tiktok-video-cover")
        self.assertEqual(spec.safe_right_pct, 0.15)
        with tempfile.TemporaryDirectory() as td:
            asset = Path(td) / "a.png"
            base = (10, 20, 30)
            Image.new("RGB", (1080, 1920), base).save(asset)
            overlay_path = Path(safezone_overlay(asset, spec))
            with Image.open(overlay_path) as img:
                rgb = img.convert("RGB")
                mid_h = 1920 // 2  # fuera de franjas top/bottom
                edge_right = rgb.getpixel((1079, mid_h))
                center = rgb.getpixel((540, mid_h))
            self.assertEqual(center, base)  # el centro NO se tiñe
            self.assertGreater(edge_right[0], base[0])  # el borde derecho SÍ (banda roja)


class TestSpecs(unittest.TestCase):
    def test_dimensiones_positivas_y_formatos(self) -> None:
        for spec in PLATFORM_SPECS.values():
            with self.subTest(spec=spec.slug):
                self.assertGreater(spec.width, 0)
                self.assertGreater(spec.height, 0)
                self.assertIn(spec.file_format, ("JPEG", "PNG", "WEBP"))
                self.assertGreater(spec.max_bytes, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
