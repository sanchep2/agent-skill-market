#!/usr/bin/env python3
"""Tests deterministas de validate_image_request.py (stdlib unittest, sin red).

Correr: python3 test_validate_image_request.py
"""

from __future__ import annotations

import unittest

from validate_image_request import (
    AD_FORMATS,
    ValidationResult,
    master_for,
    nearest_valid_size,
    validate_request,
    validate_size,
)


class TestValidateSize(unittest.TestCase):
    def test_21_9_exacto_valido(self) -> None:
        """1792x768 es el 21:9 exacto válido (M1 del audit)."""
        result = validate_size(1792, 768)
        self.assertTrue(result.ok, result.errors)

    def test_2560x1080_rechazado_por_multiplo(self) -> None:
        """2560x1080 se RECHAZA: 1080 no es múltiplo de 16 (M1 del audit)."""
        result = validate_size(2560, 1080)
        self.assertFalse(result.ok)
        self.assertTrue(any("múltiplo de 16" in e for e in result.errors), result.errors)

    def test_ratio_4_1_rechazado(self) -> None:
        """3072x768 (4:1) se rechaza por exceder 3:1."""
        result = validate_size(3072, 768)
        self.assertFalse(result.ok)
        self.assertTrue(any("aspect ratio" in e for e in result.errors), result.errors)

    def test_1023x1024_rechazado(self) -> None:
        result = validate_size(1023, 1024)
        self.assertFalse(result.ok)
        self.assertTrue(any("width=1023" in e for e in result.errors), result.errors)

    def test_borde_maximo(self) -> None:
        self.assertTrue(validate_size(3840, 2160).ok)
        self.assertFalse(validate_size(3856, 2160).ok)

    def test_pixeles_minimos(self) -> None:
        """300x250 (75.000 px) queda por debajo del mínimo del modelo — por eso el
        display banner se produce SIEMPRE por adaptación de un master, nunca directo."""
        result = validate_size(304, 256)  # múltiplos de 16, pero área ínfima
        self.assertFalse(result.ok)
        self.assertTrue(any("por debajo del mínimo" in e for e in result.errors), result.errors)

    def test_pixeles_maximos(self) -> None:
        result = validate_size(3840, 3840)  # 14.7M px > 8.29M
        self.assertFalse(result.ok)
        self.assertTrue(any("por encima del máximo" in e for e in result.errors), result.errors)


class TestValidateRequest(unittest.TestCase):
    def test_transparencia_rechazada(self) -> None:
        result = validate_request(1024, 1024, background="transparent")
        self.assertFalse(result.ok)
        self.assertTrue(any("transparent" in e for e in result.errors), result.errors)

    def test_background_desconocido_rechazado(self) -> None:
        result = validate_request(1024, 1024, background="banana")
        self.assertFalse(result.ok)
        self.assertTrue(any("background='banana'" in e for e in result.errors), result.errors)

    def test_background_validos(self) -> None:
        for bg in ("auto", "opaque"):
            with self.subTest(bg=bg):
                self.assertTrue(validate_request(1024, 1024, background=bg).ok)

    def test_compression_solo_jpeg_webp(self) -> None:
        result = validate_request(1024, 1024, output_format="png", output_compression=80)
        self.assertFalse(result.ok)
        ok = validate_request(1024, 1024, output_format="webp", output_compression=80)
        self.assertTrue(ok.ok, ok.errors)

    def test_partial_images_requiere_stream(self) -> None:
        result = validate_request(1024, 1024, partial_images=2, stream=False)
        self.assertFalse(result.ok)
        ok = validate_request(1024, 1024, partial_images=2, stream=True)
        self.assertTrue(ok.ok, ok.errors)

    def test_partial_images_rango(self) -> None:
        result = validate_request(1024, 1024, partial_images=4, stream=True)
        self.assertFalse(result.ok)

    def test_peticion_valida_completa(self) -> None:
        result = validate_request(2048, 1152, quality="high", output_format="png")
        self.assertTrue(result.ok, result.errors)
        self.assertIsInstance(result, ValidationResult)


class TestAdFormats(unittest.TestCase):
    def test_todos_los_masters_son_validos(self) -> None:
        """Cada master de la tabla de formatos DEBE cumplir el contrato del modelo."""
        for fmt in AD_FORMATS.values():
            with self.subTest(fmt=fmt.slug):
                result = validate_size(fmt.master_width, fmt.master_height)
                self.assertTrue(result.ok, f"{fmt.slug}: {result.errors}")

    def test_display_deriva_de_feed(self) -> None:
        fmt = master_for("display-300x250")
        self.assertEqual(fmt.derives_from, "feed-1x1")
        self.assertEqual((fmt.final_width, fmt.final_height), (300, 250))

    def test_formato_desconocido(self) -> None:
        with self.assertRaises(KeyError):
            master_for("valla-times-square")


class TestNearestValidSize(unittest.TestCase):
    def test_redondeo_a_multiplo(self) -> None:
        w, h = nearest_valid_size(2560, 1080)
        self.assertTrue(validate_size(w, h).ok, (w, h))

    def test_area_infima_se_escala(self) -> None:
        w, h = nearest_valid_size(300, 250)
        self.assertTrue(validate_size(w, h).ok, (w, h))

    def test_ratio_invalido_de_entrada_no_se_corrige(self) -> None:
        """Regresión: 3072x768 (4:1, error de diseño) NO debe producir un candidato
        válido — la CLI suprime la sugerencia y solo reporta el error de ratio."""
        w, h = nearest_valid_size(3072, 768)
        self.assertFalse(validate_size(w, h).ok, (w, h))

    def test_ratio_limite_3_1_produce_valido(self) -> None:
        """Entrada 3:1 exacta (300x100): los ajustes de área no deben dejar el
        resultado por encima del ratio máximo."""
        w, h = nearest_valid_size(300, 100)
        self.assertTrue(validate_size(w, h).ok, (w, h))

    def test_entrada_gigante_conserva_aspect(self) -> None:
        """El clamp de entradas enormes es proporcional: 2:1 se mantiene 2:1."""
        w, h = nearest_valid_size(20_000, 10_000)
        self.assertEqual((w, h), (3840, 1920))
        self.assertTrue(validate_size(w, h).ok)

    def test_entrada_astronomica_sin_overflow(self) -> None:
        """Ratio válido (2:1) a escala astronómica: sin overflow y resultado válido.
        (Un ratio > 3:1 gigante seguiría siendo inválido por diseño — el clamp conserva
        el aspecto, no lo corrige.)"""
        w, h = nearest_valid_size(10**24, 5 * 10**23)
        self.assertTrue(validate_size(w, h).ok, (w, h))


if __name__ == "__main__":
    unittest.main(verbosity=2)
