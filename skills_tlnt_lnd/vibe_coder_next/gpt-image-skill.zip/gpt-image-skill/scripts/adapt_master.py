#!/usr/bin/env python3
"""
adapt_master.py — Adaptador master → asset publicable para el playbook de ads.

Convierte un MASTER generado con GPT Image 2 (dimensiones válidas del modelo) en el
entregable EXACTO que exige cada plataforma: crop centrado sin distorsión + resize a las
dimensiones finales, conversión de formato y compresión iterativa hasta el peso máximo
de la plataforma (o fallo explícito). Puede además emitir un overlay de safe zone como
ARTEFACTO DE INSPECCIÓN SEPARADO (`<asset>-safezone.png`) — nunca sobreescribe el asset.

Dependencias:
    pip install Pillow

Variables de entorno:
    Ninguna.

Deviación documentada del template Gold Standard: script 100% local (sin llamadas de
red), por lo que no incorpora CircuitBreaker/retry — no hay endpoint remoto que proteger.

Uso CLI:
    python3 adapt_master.py adapt --master master.png --spec meta-story --out story-final.jpg
    python3 adapt_master.py safezone --asset story-final.jpg --spec meta-story
    python3 adapt_master.py list-specs
"""

from __future__ import annotations

import argparse
import io
import json
import sys
from dataclasses import dataclass
from pathlib import Path

try:
    from PIL import Image, ImageDraw
except ImportError:  # pragma: no cover
    print(
        "FALTA Pillow — el adaptador no puede correr. Instalar con: pip install Pillow",
        file=sys.stderr,
    )
    raise

# ============================================================================
# Specs de plataforma (fuente: references/specs-plataformas.md del skill —
# re-verificar contra la plataforma antes de una campaña real)
# ============================================================================


@dataclass(frozen=True)
class PlatformSpec:
    """Spec de entrega de una plataforma: dimensiones exactas + formato + peso máximo."""

    slug: str
    description: str
    width: int
    height: int
    file_format: str  # "JPEG" | "PNG" | "WEBP"
    max_bytes: int
    # Safe zones como fracción del alto/ancho (contenido crítico NO debe caer ahí)
    safe_top_pct: float = 0.0
    safe_bottom_pct: float = 0.0
    safe_right_pct: float = 0.0


PLATFORM_SPECS: dict[str, PlatformSpec] = {
    s.slug: s
    for s in (
        PlatformSpec("meta-feed", "Meta feed cuadrado", 1080, 1080, "JPEG", 30 * 1024 * 1024),
        PlatformSpec("meta-feed-4x5", "Meta feed vertical 4:5", 1080, 1350, "JPEG", 30 * 1024 * 1024),
        PlatformSpec(
            "meta-story",
            "Meta/IG Story y Reels (UI ocupa ~14% arriba / ~20% abajo)",
            1080,
            1920,
            "JPEG",
            30 * 1024 * 1024,
            safe_top_pct=0.14,
            safe_bottom_pct=0.20,
        ),
        PlatformSpec(
            "tiktok-video-cover",
            "TikTok imagen 9:16 (UI derecha e inferior cargadas)",
            1080,
            1920,
            "JPEG",
            30 * 1024 * 1024,
            safe_top_pct=0.10,
            safe_bottom_pct=0.15,
            safe_right_pct=0.15,
        ),
        PlatformSpec(
            "gdn-300x250",
            "Google Display medium rectangle (límite 150 KB)",
            300,
            250,
            "JPEG",
            150 * 1024,
        ),
        PlatformSpec(
            "gdn-336x280",
            "Google Display large rectangle (límite 150 KB)",
            336,
            280,
            "JPEG",
            150 * 1024,
        ),
        PlatformSpec("linkedin-feed", "LinkedIn single image 1.91:1", 1200, 628, "JPEG", 5 * 1024 * 1024),
        PlatformSpec("x-feed", "X (Twitter) imagen 16:9", 1600, 900, "JPEG", 5 * 1024 * 1024),
    )
}

JPEG_QUALITY_START = 92
JPEG_QUALITY_FLOOR = 40
QUALITY_STEP = 6


class AdaptationError(RuntimeError):
    """El asset no puede cumplir la spec (p. ej. peso máximo inalcanzable)."""


VALID_EXTENSIONS: dict[str, tuple[str, ...]] = {
    "JPEG": (".jpg", ".jpeg"),
    "PNG": (".png",),
    "WEBP": (".webp",),
}


# ============================================================================
# Núcleo de adaptación
# ============================================================================


def cover_crop(img: Image.Image, target_w: int, target_h: int) -> Image.Image:
    """Escalar para CUBRIR el destino y recortar centrado — nunca distorsiona."""
    src_w, src_h = img.size
    scale = max(target_w / src_w, target_h / src_h)
    new_w, new_h = round(src_w * scale), round(src_h * scale)
    resized = img.resize((new_w, new_h), Image.LANCZOS)
    left = (new_w - target_w) // 2
    top = (new_h - target_h) // 2
    return resized.crop((left, top, left + target_w, top + target_h))


def _encode(img: Image.Image, file_format: str, quality: int) -> bytes:
    buf = io.BytesIO()
    if file_format == "JPEG":
        img.convert("RGB").save(buf, "JPEG", quality=quality, optimize=True, progressive=True)
    elif file_format == "WEBP":
        img.save(buf, "WEBP", quality=quality, method=6)
    else:  # PNG: sin pérdida — quality no aplica
        img.save(buf, "PNG", optimize=True)
    return buf.getvalue()


def adapt(master_path: str | Path, spec: PlatformSpec, out_path: str | Path) -> dict:
    """Adaptar un master a la spec: crop centrado + formato + compresión bajo peso máximo.

    Returns:
        dict con dimensiones finales, bytes y quality usada.

    Raises:
        AdaptationError: si ni la quality mínima logra el peso máximo (condición
        observable exigida por el contrato: archivo <= max_bytes o fallo explícito).
    """
    src_master = Path(master_path)
    dst_out = Path(out_path)
    if dst_out.resolve() == src_master.resolve() or (dst_out.exists() and dst_out.samefile(src_master)):
        raise AdaptationError("El asset de salida NUNCA sobreescribe el master (ni vía hard link).")

    out_ext = Path(out_path).suffix.lower()
    if out_ext not in VALID_EXTENSIONS[spec.file_format]:
        raise AdaptationError(
            f"Extensión {out_ext!r} incompatible con el formato {spec.file_format} de la spec "
            f"{spec.slug} (válidas: {', '.join(VALID_EXTENSIONS[spec.file_format])}) — un archivo "
            f"con extensión engañosa rompe validaciones aguas abajo."
        )

    with Image.open(master_path) as master:
        final = cover_crop(master, spec.width, spec.height)

    quality = JPEG_QUALITY_START
    data = _encode(final, spec.file_format, quality)
    while len(data) > spec.max_bytes and spec.file_format in ("JPEG", "WEBP"):
        if quality <= JPEG_QUALITY_FLOOR:
            # El floor YA se codificó y aun así no cabe — solo entonces se falla.
            raise AdaptationError(
                f"No se alcanza el peso máximo de {spec.slug} ({spec.max_bytes:,} bytes) ni con "
                f"quality={JPEG_QUALITY_FLOOR}: último intento {len(data):,} bytes. Simplificar el "
                f"master (menos detalle fino) o subir el límite si la plataforma lo permite."
            )
        quality = max(quality - QUALITY_STEP, JPEG_QUALITY_FLOOR)
        data = _encode(final, spec.file_format, quality)

    if len(data) > spec.max_bytes:  # PNG que no cabe
        raise AdaptationError(
            f"PNG de {len(data):,} bytes excede el máximo de {spec.slug} "
            f"({spec.max_bytes:,}); usar spec con formato JPEG/WEBP."
        )

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(data)
    return {
        "out": str(out),
        "width": spec.width,
        "height": spec.height,
        "bytes": len(data),
        "max_bytes": spec.max_bytes,
        "quality": quality if spec.file_format in ("JPEG", "WEBP") else None,
        "format": spec.file_format,
    }


def safezone_overlay(asset_path: str | Path, spec: PlatformSpec, out_path: str | Path | None = None) -> str:
    """Emitir el overlay de safe zone como artefacto SEPARADO (nunca pisa el asset).

    Si out_path es None, se deriva como `<asset>-safezone.png`. Se niega explícitamente
    a escribir sobre el asset de entrada.
    """
    src = Path(asset_path)
    dst = Path(out_path) if out_path else src.with_name(f"{src.stem}-safezone.png")
    if dst.resolve() == src.resolve() or (dst.exists() and dst.samefile(src)):
        # samefile cubre también hard links al asset, que resolve() no detecta
        raise AdaptationError("El overlay de safe zone NUNCA sobreescribe el asset publicable.")
    if dst.suffix.lower() != ".png":
        raise AdaptationError(
            f"El overlay se escribe SIEMPRE como .png (pedido: {dst.suffix!r}) — su canal alpha "
            f"y el sufijo -safezone.png lo mantienen fuera de los entregables."
        )

    with Image.open(src) as src_img:
        img = src_img.convert("RGBA")
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    w, h = img.size
    top_px = round(h * spec.safe_top_pct)
    bottom_px = round(h * spec.safe_bottom_pct)
    right_px = round(w * spec.safe_right_pct)
    if top_px:
        draw.rectangle([0, 0, w, top_px], fill=(255, 0, 0, 96))
    if bottom_px:
        draw.rectangle([0, h - bottom_px, w, h], fill=(255, 0, 0, 96))
    if right_px:
        draw.rectangle([w - right_px, 0, w, h], fill=(255, 0, 0, 96))
    Image.alpha_composite(img, overlay).save(dst, "PNG")
    return str(dst)


def spec_for(slug: str) -> PlatformSpec:
    if slug not in PLATFORM_SPECS:
        raise KeyError(f"Spec desconocida: {slug!r}. Válidas: {', '.join(sorted(PLATFORM_SPECS))}")
    return PLATFORM_SPECS[slug]


# ============================================================================
# CLI Commands
# ============================================================================


def cmd_adapt(args: argparse.Namespace) -> None:
    """Handler del subcomando 'adapt'."""
    try:
        result = adapt(args.master, spec_for(args.spec), args.out)
    except (AdaptationError, KeyError, OSError) as exc:
        # OSError cubre FileNotFoundError y también fallos de Image.open/mkdir/write
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        sys.exit(1)
    print(json.dumps({"ok": True, **result}, ensure_ascii=False, indent=2))


def cmd_safezone(args: argparse.Namespace) -> None:
    """Handler del subcomando 'safezone'."""
    try:
        out = safezone_overlay(args.asset, spec_for(args.spec), args.out)
    except (AdaptationError, KeyError, OSError) as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        sys.exit(1)
    print(json.dumps({"ok": True, "overlay": out}, ensure_ascii=False, indent=2))


def cmd_list_specs(_args: argparse.Namespace) -> None:
    """Handler del subcomando 'list-specs'."""
    rows = [
        {
            "slug": s.slug,
            "description": s.description,
            "size": f"{s.width}x{s.height}",
            "format": s.file_format,
            "max_kb": s.max_bytes // 1024,
            "safe_top_pct": s.safe_top_pct,
            "safe_bottom_pct": s.safe_bottom_pct,
            "safe_right_pct": s.safe_right_pct,
        }
        for s in PLATFORM_SPECS.values()
    ]
    print(json.dumps(rows, ensure_ascii=False, indent=2))


# ============================================================================
# Main
# ============================================================================


def main() -> None:
    parser = argparse.ArgumentParser(
        description="adapt_master.py — master GPT Image 2 → asset publicable exacto"
    )
    subparsers = parser.add_subparsers(dest="command", help="Subcomandos disponibles")

    p1 = subparsers.add_parser("adapt", help="Adaptar master a una spec de plataforma")
    p1.add_argument("--master", required=True, help="Path del master generado")
    p1.add_argument("--spec", required=True, help="Slug de la spec (ver list-specs)")
    p1.add_argument("--out", required=True, help="Path del asset final")
    p1.set_defaults(func=cmd_adapt)

    p2 = subparsers.add_parser("safezone", help="Overlay de safe zone (artefacto separado)")
    p2.add_argument("--asset", required=True, help="Asset final a inspeccionar")
    p2.add_argument("--spec", required=True)
    p2.add_argument("--out", default=None, help="Default: <asset>-safezone.png")
    p2.set_defaults(func=cmd_safezone)

    p3 = subparsers.add_parser("list-specs", help="Listar specs de plataforma")
    p3.set_defaults(func=cmd_list_specs)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)
    args.func(args)


if __name__ == "__main__":
    main()
