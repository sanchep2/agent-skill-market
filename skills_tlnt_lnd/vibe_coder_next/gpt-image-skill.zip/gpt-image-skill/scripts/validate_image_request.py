#!/usr/bin/env python3
"""
validate_image_request.py — Validador pre-flight para peticiones a GPT Image 2.

Valida dimensiones y parámetros contra el contrato oficial del modelo `gpt-image-2`
ANTES de lanzar una generación (evita quemar minutos y cuota en peticiones que la API
o la herramienta integrada de Codex van a rechazar). Incluye la tabla formato-de-ad →
master válido más cercano usada por el playbook de ads del skill.

Contrato del modelo (fuente oficial: developers.openai.com/api/docs/guides/image-generation,
consultado 2026-08-05; coincide con el contrato local del skill de sistema `imagegen` de Codex):
    - Ambos lados múltiplos de 16 px
    - Borde máximo <= 3840 px
    - Ratio largo/corto <= 3:1
    - Píxeles totales entre 655.360 y 8.294.400
    - `background=transparent` NO soportado (workaround: chroma-key + remoción local)
    - `output_compression` 0..100, solo con jpeg/webp
    - `partial_images` 0..3 (requiere streaming)

Dependencias:
    Ninguna (stdlib puro). Deviación documentada del template Gold Standard: este script
    no realiza llamadas de red, por lo que no incorpora CircuitBreaker/retry — no hay
    endpoint remoto que proteger.

Variables de entorno:
    Ninguna.

Uso CLI:
    python3 validate_image_request.py validate --width 1792 --height 768
    python3 validate_image_request.py validate --width 1024 --height 1024 --background transparent
    python3 validate_image_request.py master --ad-format story-9x16
    python3 validate_image_request.py list-formats
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field

# ============================================================================
# Contrato oficial gpt-image-2 (last_verified: 2026-08-05)
# ============================================================================

EDGE_MULTIPLE = 16
MAX_EDGE_PX = 3840
MAX_ASPECT_RATIO = 3.0
MIN_TOTAL_PIXELS = 655_360
MAX_TOTAL_PIXELS = 8_294_400
VALID_QUALITIES = ("auto", "low", "medium", "high")
VALID_FORMATS = ("png", "jpeg", "webp")
COMPRESSIBLE_FORMATS = ("jpeg", "webp")
VALID_BACKGROUNDS = ("auto", "opaque")  # transparent existe en la API pero gpt-image-2 lo rechaza


@dataclass
class ValidationResult:
    """Resultado de una validación pre-flight."""

    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"ok": self.ok, "errors": self.errors, "warnings": self.warnings}


@dataclass(frozen=True)
class AdFormat:
    """Formato de ad soportado por el playbook: master válido para el modelo + entregable final."""

    slug: str
    description: str
    master_width: int
    master_height: int
    final_width: int
    final_height: int
    derives_from: str | None = None  # slug de otro formato si el master se comparte


# Tabla formato-de-ad → master válido más cercano (todos los masters cumplen el contrato
# del modelo; el entregable final EXACTO lo produce adapt_master.py, nunca el modelo).
AD_FORMATS: dict[str, AdFormat] = {
    f.slug: f
    for f in (
        AdFormat("feed-1x1", "Feed cuadrado (Meta/LinkedIn/X)", 2048, 2048, 1080, 1080),
        AdFormat("feed-4x5", "Feed vertical (Meta 4:5)", 1280, 1600, 1080, 1350),
        AdFormat("story-9x16", "Story/Reel (Meta/TikTok)", 1152, 2048, 1080, 1920),
        AdFormat("landscape-16x9", "Horizontal (X/LinkedIn vía specs propias)", 2048, 1152, 1600, 900),
        AdFormat("ultrawide-21x9", "Hero panorámico 21:9 exacto", 1792, 768, 1792, 768),
        AdFormat(
            "display-300x250",
            "Banner display IAB medium rectangle (Google Display)",
            2048,
            2048,
            300,
            250,
            derives_from="feed-1x1",
        ),
        AdFormat(
            "display-336x280",
            "Banner display IAB large rectangle (Google Display)",
            2048,
            2048,
            336,
            280,
            derives_from="feed-1x1",
        ),
    )
}


# ============================================================================
# Validación
# ============================================================================


def validate_size(width: int, height: int) -> ValidationResult:
    """Validar unas dimensiones contra el contrato de gpt-image-2."""
    errors: list[str] = []
    if width <= 0 or height <= 0:
        return ValidationResult(False, [f"Dimensiones no positivas: {width}x{height}"])

    if width % EDGE_MULTIPLE != 0:
        errors.append(f"width={width} no es múltiplo de {EDGE_MULTIPLE}")
    if height % EDGE_MULTIPLE != 0:
        errors.append(f"height={height} no es múltiplo de {EDGE_MULTIPLE}")

    long_edge, short_edge = max(width, height), min(width, height)
    if long_edge > MAX_EDGE_PX:
        errors.append(f"borde mayor {long_edge}px excede el máximo {MAX_EDGE_PX}px")

    # Comparación en enteros (sin float): dimensiones arbitrariamente grandes no
    # desbordan; MAX_ASPECT_RATIO=3 → largo > 3×corto.
    if long_edge > int(MAX_ASPECT_RATIO) * short_edge:
        shown = long_edge / short_edge if long_edge <= MAX_EDGE_PX * 10 else float("inf")
        errors.append(f"aspect ratio {shown:.2f}:1 excede el máximo {MAX_ASPECT_RATIO:.0f}:1")

    total = width * height
    if total < MIN_TOTAL_PIXELS:
        errors.append(f"píxeles totales {total:,} por debajo del mínimo {MIN_TOTAL_PIXELS:,}")
    if total > MAX_TOTAL_PIXELS:
        errors.append(f"píxeles totales {total:,} por encima del máximo {MAX_TOTAL_PIXELS:,}")

    return ValidationResult(not errors, errors)


def validate_request(
    width: int,
    height: int,
    background: str | None = None,
    quality: str | None = None,
    output_format: str | None = None,
    output_compression: int | None = None,
    partial_images: int | None = None,
    stream: bool = False,
) -> ValidationResult:
    """Validar la petición completa (dimensiones + parámetros) antes de generar."""
    result = validate_size(width, height)
    errors, warnings = list(result.errors), list(result.warnings)

    if background == "transparent":
        errors.append(
            "background=transparent NO está soportado por gpt-image-2 — usar el workaround "
            "chroma-key (ver references/restricciones-y-validacion.md)"
        )
    elif background is not None and background not in VALID_BACKGROUNDS:
        errors.append(
            f"background={background!r} inválido (válidos para gpt-image-2: {', '.join(VALID_BACKGROUNDS)})"
        )

    if quality is not None and quality not in VALID_QUALITIES:
        errors.append(f"quality={quality!r} inválido (válidos: {', '.join(VALID_QUALITIES)})")

    if output_format is not None and output_format not in VALID_FORMATS:
        errors.append(f"output_format={output_format!r} inválido (válidos: {', '.join(VALID_FORMATS)})")

    if output_compression is not None:
        if not 0 <= output_compression <= 100:
            errors.append(f"output_compression={output_compression} fuera de 0..100")
        if output_format not in COMPRESSIBLE_FORMATS:
            errors.append(
                f"output_compression solo aplica a {'/'.join(COMPRESSIBLE_FORMATS)} "
                f"(formato pedido: {output_format!r})"
            )

    if partial_images is not None:
        if not 0 <= partial_images <= 3:
            errors.append(f"partial_images={partial_images} fuera de 0..3")
        if not stream:
            errors.append("partial_images requiere stream=true")

    return ValidationResult(not errors, errors, warnings)


def nearest_valid_size(width: int, height: int) -> tuple[int, int]:
    """Aproximar unas dimensiones al tamaño válido más cercano del modelo.

    Redondea cada lado al múltiplo de 16 más próximo, recorta al borde máximo y escala
    proporcionalmente si el total de píxeles queda fuera de rango. NO corrige ratios
    > 3:1 — eso es un error de diseño del formato, no de redondeo, y se reporta como tal.
    """
    def round16(v: int) -> int:
        return max(EDGE_MULTIPLE, round(v / EDGE_MULTIPLE) * EDGE_MULTIPLE)

    # Clamp temprano PROPORCIONAL en enteros: entradas extremas no llegan a la aritmética
    # float y la relación de aspecto se conserva (20000x10000 → 3840x1920).
    width, height = max(1, width), max(1, height)
    # El loop correctivo de ratio del final SOLO repara deriva introducida por el propio
    # redondeo/ajuste (entrada originalmente válida, p. ej. 300x100 = 3:1 exacto). Un
    # ratio de ENTRADA > 3:1 (p. ej. 3072x768) es error de diseño del formato y NO se
    # corrige: el candidato queda inválido y la CLI no lo sugiere.
    original_ratio_ok = max(width, height) <= int(MAX_ASPECT_RATIO) * min(width, height)
    longest = max(width, height)
    if longest > MAX_EDGE_PX:
        width = width * MAX_EDGE_PX // longest
        height = height * MAX_EDGE_PX // longest

    w, h = round16(width), round16(height)
    scale = min(1.0, MAX_EDGE_PX / max(w, h))
    w, h = round16(int(w * scale)), round16(int(h * scale))

    total = w * h
    if total < MIN_TOTAL_PIXELS or total > MAX_TOTAL_PIXELS:
        target = MIN_TOTAL_PIXELS if total < MIN_TOTAL_PIXELS else MAX_TOTAL_PIXELS
        factor = (target / total) ** 0.5
        w, h = round16(int(w * factor)), round16(int(h * factor))
    # El redondeo a múltiplos de 16 puede dejar el área justo fuera de rango: ajustar
    # en pasos de 16 (acotado — nunca más de unos pocos pasos).
    while w * h < MIN_TOTAL_PIXELS and max(w, h) + EDGE_MULTIPLE <= MAX_EDGE_PX:
        if w <= h:
            w += EDGE_MULTIPLE
        else:
            h += EDGE_MULTIPLE
    while w * h > MAX_TOTAL_PIXELS and min(w, h) - EDGE_MULTIPLE >= EDGE_MULTIPLE:
        if w >= h:
            w -= EDGE_MULTIPLE
        else:
            h -= EDGE_MULTIPLE
    # Los ajustes de área pueden empujar el ratio por encima de 3:1 aunque la ENTRADA
    # fuera <= 3:1 (p. ej. 300x100): subir el lado corto en pasos de 16 hasta recuperarlo.
    while original_ratio_ok and max(w, h) > int(MAX_ASPECT_RATIO) * min(w, h) and max(w, h) <= MAX_EDGE_PX:
        if w <= h:
            w += EDGE_MULTIPLE
        else:
            h += EDGE_MULTIPLE
    return w, h


def master_for(ad_format: str) -> AdFormat:
    """Resolver el master recomendado para un formato de ad del playbook."""
    if ad_format not in AD_FORMATS:
        raise KeyError(
            f"Formato de ad desconocido: {ad_format!r}. Válidos: {', '.join(sorted(AD_FORMATS))}"
        )
    return AD_FORMATS[ad_format]


# ============================================================================
# CLI Commands
# ============================================================================


def cmd_validate(args: argparse.Namespace) -> None:
    """Handler del subcomando 'validate'."""
    result = validate_request(
        width=args.width,
        height=args.height,
        background=args.background,
        quality=args.quality,
        output_format=args.output_format,
        output_compression=args.output_compression,
        partial_images=args.partial_images,
        stream=args.stream,
    )
    payload = result.to_dict()
    if not result.ok and not validate_size(args.width, args.height).ok:
        # Solo aplica a errores de TAMAÑO, y solo si la sugerencia es realmente válida
        # (un ratio > 3:1 no se corrige por redondeo: es un error de diseño del formato).
        candidate = nearest_valid_size(args.width, args.height)
        if validate_size(*candidate).ok:
            payload["nearest_valid_size"] = "x".join(map(str, candidate))
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    sys.exit(0 if result.ok else 1)


def cmd_master(args: argparse.Namespace) -> None:
    """Handler del subcomando 'master'."""
    try:
        fmt = master_for(args.ad_format)
    except KeyError as exc:
        print(json.dumps({"ok": False, "errors": [str(exc)]}, ensure_ascii=False))
        sys.exit(1)
    check = validate_size(fmt.master_width, fmt.master_height)
    print(
        json.dumps(
            {
                "ok": check.ok,
                "ad_format": fmt.slug,
                "master": f"{fmt.master_width}x{fmt.master_height}",
                "final": f"{fmt.final_width}x{fmt.final_height}",
                "derives_from": fmt.derives_from,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    sys.exit(0 if check.ok else 1)


def cmd_list_formats(_args: argparse.Namespace) -> None:
    """Handler del subcomando 'list-formats'."""
    rows = [
        {
            "slug": f.slug,
            "description": f.description,
            "master": f"{f.master_width}x{f.master_height}",
            "final": f"{f.final_width}x{f.final_height}",
            "derives_from": f.derives_from,
        }
        for f in AD_FORMATS.values()
    ]
    print(json.dumps(rows, ensure_ascii=False, indent=2))


# ============================================================================
# Main
# ============================================================================


def main() -> None:
    parser = argparse.ArgumentParser(
        description="validate_image_request.py — pre-flight de peticiones a gpt-image-2"
    )
    subparsers = parser.add_subparsers(dest="command", help="Subcomandos disponibles")

    p1 = subparsers.add_parser("validate", help="Validar dimensiones y parámetros de una petición")
    p1.add_argument("--width", type=int, required=True)
    p1.add_argument("--height", type=int, required=True)
    # Sin choices= a propósito: los valores inválidos deben llegar a validate_request para
    # producir el JSON documentado + exit 1, no el exit 2 abrupto de argparse.
    p1.add_argument("--background", default=None, help="auto | opaque (transparent se rechaza)")
    p1.add_argument("--quality", default=None, help="auto | low | medium | high")
    p1.add_argument("--output-format", dest="output_format", default=None, help="png | jpeg | webp")
    p1.add_argument("--output-compression", dest="output_compression", type=int, default=None)
    p1.add_argument("--partial-images", dest="partial_images", type=int, default=None)
    p1.add_argument("--stream", action="store_true")
    p1.set_defaults(func=cmd_validate)

    p2 = subparsers.add_parser("master", help="Master válido recomendado para un formato de ad")
    p2.add_argument("--ad-format", dest="ad_format", required=True)
    p2.set_defaults(func=cmd_master)

    p3 = subparsers.add_parser("list-formats", help="Listar formatos de ad del playbook")
    p3.set_defaults(func=cmd_list_formats)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)
    args.func(args)


if __name__ == "__main__":
    main()
