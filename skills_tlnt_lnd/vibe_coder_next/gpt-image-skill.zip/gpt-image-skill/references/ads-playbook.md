# Ads Playbook — Complete Reference

LA referencia principal del skill: pipeline completo para producir creatividades de
campaña con GPT Image 2, en volumen, listas para publicar. Todo lo demás
(`ruta-*`, `restricciones-*`, `specs-*`) es plomería que este playbook invoca.

Contrato del pipeline (sellado 2026-08-05):

```text
brief → conceptos/prompts → elección de ruta → pre-flight → MASTERS → adaptación exacta
     → inspección visual + safe zone → TU APROBACIÓN → entrega
```

**Sin publicación automática, nunca**: este skill produce y presenta piezas; subirlas a
una plataforma de ads es SIEMPRE un acto manual tuyo (o del responsable de la campaña)
(enviar una creatividad a un vendor/plataforma ya es publicar).

## Table of Contents

1. [Flujo de una campaña, de brief a entrega](#1-flujo-de-una-campaña-de-brief-a-entrega)
2. [Elección de ruta: puente Codex vs API](#2-elección-de-ruta-puente-codex-vs-api)
3. [Prompts de ads: texto, CTA y copy](#3-prompts-de-ads-texto-cta-y-copy)
4. [Consistencia de personaje y marca](#4-consistencia-de-personaje-y-marca)
5. [Producción en lote: N conceptos × M formatos](#5-producción-en-lote-n-conceptos--m-formatos)
6. [Inspección, errores del pipeline y aprobación](#6-inspección-errores-del-pipeline-y-aprobación)
7. [Gotchas & Cross-References](#7-gotchas--cross-references)

---

## 1. Flujo de una campaña, de brief a entrega

Ejemplo canónico: "6 creatividades para el lanzamiento X — feed y story, con CTA".

```text
1. BRIEF → matriz de piezas
   3 conceptos × 2 formatos (feed-1x1, story-9x16) = 6 piezas, 6 masters
   (display: DEFAULT deriva del master feed sin generación extra; FALLBACK master
    dedicado 1920x1600 si la inspección del paso 5 detecta titular cortado/ilegible)

2. PRE-FLIGHT (gratis, antes de gastar nada)
   python3 .claude/skills/gpt-image-skill/scripts/validate_image_request.py master --ad-format feed-1x1    → 2048x2048
   python3 .claude/skills/gpt-image-skill/scripts/validate_image_request.py master --ad-format story-9x16  → 1152x2048
   + sonda de la ruta elegida (ruta-codex-bridge.md §2 / ruta-api-directa.md §1)

3. GENERAR MASTERS (1 llamada por asset, en background)
   → primera pieza como prueba de ruta; el resto en paralelo ESCALONADO
     (lotes grandes: no lanzar decenas a la vez; ante 429 en la ruta API, backoff)
   → verificación por pieza: archivo + dimensiones + visual

4. ADAPTAR a entregables exactos
   python3 .claude/skills/gpt-image-skill/scripts/adapt_master.py adapt --master c1-feed.png --spec meta-feed --out final/c1-feed.jpg
   python3 .claude/skills/gpt-image-skill/scripts/adapt_master.py adapt --master c1-story.png --spec meta-story --out final/c1-story.jpg
   python3 .claude/skills/gpt-image-skill/scripts/adapt_master.py adapt --master c1-feed.png --spec gdn-300x250 --out final/c1-display.jpg

5. INSPECCIONAR
   overlay safezone por pieza vertical + revisión visual de texto/CTA/distorsión

6. REVISAR Y APROBAR → entregar la carpeta final/
   (registrar qué master y qué método de adaptación produjo cada pieza)
```

Registro por pieza (reproducibilidad): `concepto, ruta usada, master (path+size), spec de
adaptación, quality/peso final` — en el mensaje de entrega o un `manifest.json` junto a
las piezas. Si una llamada de la ruta API usó `n>1`, cada variante se registra con su
índice y su ruta determinista (`<concepto>-v<n>.png`) — nunca un solo asiento para N
variantes.

## 2. Elección de ruta: puente Codex vs API

```text
¿Hay OPENAI_API_KEY con presupuesto?
├── NO → PUENTE CODEX (ruta por defecto)
│        Requiere: codex CLI + sesión ChatGPT + capacidad imagegen (sonda fail-closed)
│        Coste: pool agentic de la suscripción (limitado, sin factura por imagen)
└── SÍ → ¿la tarea necesita máscaras, lotes programáticos deterministas o streaming?
         ├── SÍ → API DIRECTA (control exacto de parámetros; low→high por coste)
         └── NO → PUENTE CODEX igualmente (perfil de coste mejor para el día a día)
```

- El puente NO es "gratis": consume el pool de la suscripción. En ráfagas grandes (>20
  piezas) valorar la ruta API con `quality low` para exploración (~$0.005/draft).
- NUNCA cambiar de ruta en silencio: perfiles de coste distintos → anunciarlo.

## 3. Prompts de ads: texto, CTA y copy

El render de texto es la fortaleza diferencial de `gpt-image-2` — pero solo si el prompt
lo trata como contrato:

- **Texto VERBATIM entre comillas**: `con el texto exacto "INSCRIPCIONES ABIERTAS"` —
  nunca parafrasear ("un texto de inscripción").
- **Tipografía y ubicación**: `titular grande arriba en sans-serif bold; CTA en botón
  pill verde abajo al centro`.
- **Palabras difíciles**: deletrear (`V-I-B-E-C-O-D-E-R`) y exigir render literal.
- **Copy del espectador**: el texto de la pieza usa el vocabulario de la audiencia, no
  jerga interna del equipo.
- **Legibilidad al tamaño final**: un CTA que se lee en el master 2048px puede morir a
  300×250. Contrato del display (coherente con el paso 1 del pipeline): DEFAULT derivar
  del master feed 1:1; si la inspección detecta titular cortado o texto ilegible,
  FALLBACK a master dedicado con composición simple, texto GRANDE y ratio afín al final:
  `1920x1600` (1,2:1 exacto, válido para el modelo) elimina la pérdida por crop hacia
  300×250/336×280 — validado en el test live del 2026-08-05.
- **Estructura**: escena/fondo → sujeto → detalles → texto (verbatim) → constraints →
  avoid (sin marca de agua, sin texto extra, sin logos de terceros).

Plantilla de prompt de pieza:

```text
Creatividad publicitaria <formato>: <escena y estilo>.
Sujeto: <qué se ve>.
Texto (verbatim): "<TITULAR>" como titular <posición/estilo>; botón CTA "<CTA>" <posición>.
Paleta: <colores de la marca>.
Constraints: composición centrada con aire en los bordes (se recorta a <ratios finales>);
sin marca de agua; sin texto adicional al indicado; sin logos de terceros.
```

## 4. Consistencia de personaje y marca

Workflow validado (2026-08-05, personaje Talent-Oso, 3 piezas consistentes):

1. **Referencia de imagen** del personaje/producto (la mejor disponible, frontal, limpia).
2. **Descripción textual de invariantes EN el prompt** además de adjuntar: "oso pardo 3D
   con gafas rectangulares, auriculares negros al cuello, sudadera verde oscuro" — el
   texto ancla los invariantes, la imagen ancla el estilo.
3. **Cláusula de fidelidad**: `Mantén EXACTAMENTE el diseño del personaje: <lista>`.
4. **Verificación visual pieza a pieza** contra la referencia (gafas, ropa, paleta) —
   los deslices son sutiles (accesorio puesto vs colgado) y solo se ven mirando.
5. En iteraciones/edits, **repetir los invariantes en cada vuelta** (evita drift).

Mecánica por ruta: puente → `-i ref.png` + prompt por stdin (`ruta-codex-bridge.md` §4,
gotcha `-i`); API → `images.edit` con `image=[ref]` (`ruta-api-directa.md` §4). Varias
referencias (personaje + fondo + producto): etiquetar el rol de cada una en el prompt.

## 5. Producción en lote: N conceptos × M formatos

- **1 generación = 1 asset**: los lotes se paralelizan lanzando N llamadas independientes
  (en el puente: N procesos `codex exec` en background; ~1-3 min cada uno, corren a la vez).
- **Primera pieza como prueba de ruta**: generar UNA, verificarla (archivo + dimensiones +
  visual) y solo entonces lanzar el resto — si la primera falla por auth/capacidad, fallo
  cerrado: no quemar el lote sobre una disponibilidad falsa.
- **Pool acotado, no fan-out ilimitado**: mantener como máximo 3-4 generaciones en vuelo
  por ruta y encolar el resto; ante 429 en la ruta API, backoff exponencial con jitter
  antes de reincorporar la pieza a la cola.
- **Matriz mínima de masters**: por concepto bastan 2 masters (1:1 + 9:16) para cubrir
  feed + story + display (+ LinkedIn/X vía el 1:1 o un 16:9 extra) — ver mapeo en
  `specs-plataformas.md` §3.
- **Nomenclatura**: `<concepto>-<formato>.png` para masters, `final/<concepto>-<spec>.jpg`
  para entregables, `*-safezone.png` para inspección. El overlay JAMÁS entra en `final/`.
- **A/B**: las variantes de UN concepto (mismo prompt, salidas NO deterministas — la API
  no expone semillas) sí pueden salir de `n>1` en la ruta API; conceptos distintos
  siempre son prompts distintos.

## 6. Inspección, errores del pipeline y aprobación

Checklist por pieza ANTES de aprobar:

- [ ] Dimensiones finales EXACTAS (las reporta `adapt_master.py`; re-verificable con `sips`)
- [ ] Texto y CTA legibles al tamaño final y VERBATIM contra el brief
- [ ] Sin distorsión (el cover-crop nunca estira; si el sujeto quedó cortado, recomponer el master)
- [ ] Safe zone respetada en 9:16 (overlay `*-safezone.png` revisado)
- [ ] Personaje/marca fiel a la referencia (si aplica)
- [ ] Peso ≤ máximo de plataforma (lo garantiza el adaptador o falla explícito)

Errores típicos del pipeline y reacción:

| Fallo | Dónde se manifiesta | Reacción |
|-------|--------------------|----------|
| Texto mal renderizado / typo | Inspección visual | Regenerar SOLO esa pieza (prompt: deletrear la palabra) |
| Sujeto cortado por el crop | Asset final | Recomponer master con sujeto centrado + aire; no estirar |
| Display no cabe en 150 KB | `AdaptationError` explícito | Simplificar el master (menos detalle), regenerar |
| Personaje off-model | Inspección visual | Reforzar invariantes en el prompt + re-adjuntar referencia |
| Generación silenciosamente vacía | Verificación post-gen | Gotcha `-i` (puente): prompt por stdin |

La **aprobación humana** es un paso del pipeline, no una cortesía: piezas user-facing
requieren su OK explícito ANTES de cualquier publicación o envío a plataforma/vendor.

## 7. Gotchas & Cross-References

1. **El modelo no produce entregables de plataforma** → siempre master → adaptador. Ni
   una pieza directa a plataforma sin pasar por `adapt_master.py`.
2. **Componer para el recorte** → el mismo master alimenta ratios distintos; sujeto
   centrado + aire en bordes o el crop lo corta.
3. **El texto se valida mirando** → ni exit codes ni dimensiones detectan un typo del
   modelo en el titular.
4. **El overlay no es entregable** → excluir `*-safezone.png` de `final/` y de cualquier
   selección automática.
5. **Registrar master + método por pieza** → sin ese rastro, "ausencia de distorsión" no
   es reproducible ni auditable.

**Related reference files:**

- Generar sin API key (default) → `ruta-codex-bridge.md`
- Generar con API key (máscaras/lotes/streaming) → `ruta-api-directa.md`
- Contrato de tamaños del modelo → `restricciones-y-validacion.md`
- Dimensiones finales, pesos y safe zones → `specs-plataformas.md`
