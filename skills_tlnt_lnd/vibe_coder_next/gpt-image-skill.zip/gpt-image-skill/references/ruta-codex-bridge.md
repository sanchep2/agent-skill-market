# Ruta Puente Codex — Complete Reference

Generación con GPT Image 2 delegando en Codex CLI desde cualquier agente con acceso a
shell (Claude Code, scripts, otra terminal). Sin `OPENAI_API_KEY`: el consumo va contra
el pool agentic de la suscripción ChatGPT de la cuenta logueada en Codex — limitado, no
"gratis" (puede tirar de créditos adicionales del plan).

Patrón validado end-to-end el 2026-08-05 (codex-cli 0.146.0, macOS).

## Table of Contents

1. [Nomenclatura exacta](#1-nomenclatura-exacta)
2. [Sonda pre-flight (fail-closed)](#2-sonda-pre-flight-fail-closed)
3. [Patrón base: texto a imagen](#3-patrón-base-texto-a-imagen)
4. [Con imágenes de referencia (el gotcha -i)](#4-con-imágenes-de-referencia-el-gotcha--i)
5. [Operativa: background, lotes y verificación](#5-operativa-background-lotes-y-verificación)
6. [Manejo de errores](#6-manejo-de-errores)
7. [Gotchas & Cross-References](#7-gotchas--cross-references)

---

## 1. Nomenclatura exacta

Tres nombres que NO son intercambiables:

| Término | Qué es |
|---------|--------|
| `imagegen` | Skill de SISTEMA de Codex (`${CODEX_HOME:-$HOME/.codex}/skills/.system/imagegen/`) — la doctrina que Codex sigue |
| `$imagegen` | La INVOCACIÓN de ese skill dentro de una sesión de Codex |
| `image_gen` | La HERRAMIENTA integrada efectiva que ejecuta la generación (no requiere API key) |

El puente funciona porque el prompt de `codex exec` activa el skill `imagegen`, que usa la
herramienta `image_gen`. La disponibilidad la garantiza el RUNTIME de Codex que exponga esa
capacidad — no la mera instalación del ejecutable `codex`.

```text
Claude Code ──Bash──▶ codex exec "genera…" ──skill imagegen──▶ tool image_gen ──▶ gpt-image-2
                                                    │
                              guarda original en ${CODEX_HOME:-~/.codex}/generated_images/<uuid>/
                                                    │
                              copia al directorio de trabajo pedido en el prompt
```

## 2. Sonda pre-flight (fail-closed)

Correr ANTES de la primera generación de una sesión. Diferencia los TRES fallos posibles y
NUNCA degrada en silencio — si falta algo, PARAR con la instrucción de arreglo:

```bash
# 1) ¿CLI presente?
command -v codex >/dev/null || { echo "FALTA Codex CLI → instalar: npm i -g @openai/codex (o brew install --cask codex)"; exit 1; }

# 2) ¿Sesión válida Y de ChatGPT? (una sesión con API key factura como API, no como suscripción)
login_out="$(codex login status 2>&1)" || { echo "SESIÓN INVÁLIDA O AUSENTE → correr: codex login (auth ChatGPT)"; exit 1; }
case "$login_out" in *ChatGPT*) : ;; *) echo "SESIÓN NO-ChatGPT ($login_out) → coste de API, no de suscripción; usar la ruta API explícita o re-loguear con ChatGPT"; exit 1 ;; esac

# 3) ¿Skill de sistema imagegen presente? (prerrequisito ESTÁTICO)
[ -f "${CODEX_HOME:-$HOME/.codex}/skills/.system/imagegen/SKILL.md" ] || { echo "SIN el skill de sistema imagegen → actualizar Codex CLI (lo trae de serie desde las versiones 2026); la ruta puente NO está disponible aquí"; exit 1; }

echo "PRERREQUISITOS DEL PUENTE OK: $(codex --version)"
```

Qué garantiza y qué NO garantiza la sonda:

- Garantiza: CLI presente, sesión declarada válida (`codex login status` — cazará una
  sesión ausente; una revocada server-side puede seguir declarándose válida hasta el
  primer uso real) y el skill de sistema instalado.
- NO garantiza que el runtime exponga la herramienta `image_gen` ni que la cuenta tenga
  cuota: **la prueba definitiva es la PRIMERA generación real**. Protocolo de lote:
  generar UNA pieza, verificarla, y solo entonces lanzar el resto en paralelo. Si esa
  primera pieza falla por auth o capacidad → fallo cerrado: parar, reportar la causa y NO
  lanzar el lote.

## 3. Patrón base: texto a imagen

```bash
cd <directorio-destino> && codex exec --skip-git-repo-check --sandbox workspace-write \
  "Usa tu skill de generación de imágenes (imagegen / gpt-image-2) para generar UNA imagen \
   <descripción, estilo> en tamaño <WxH válido del modelo>. Guárdala como <nombre>.png en el \
   directorio de trabajo actual. Verifica con un comando que el archivo existe y reporta sus \
   dimensiones en píxeles. No hagas nada más."
```

Reglas del prompt:

- **Tamaño**: pedir SIEMPRE un size válido del contrato (`restricciones-y-validacion.md`);
  validado antes con `scripts/validate_image_request.py`.
- **"UNA imagen"** y **"No hagas nada más"**: acotan al agente — sin ellos puede iterar
  variantes o tocar otros archivos.
- **"Verifica y reporta dimensiones"**: convierte el output de Codex en evidencia
  verificable (usa `sips`/`identify` él mismo).
- Assets DISTINTOS = llamadas `codex exec` distintas (no pedir "5 imágenes" en una).

## 4. Con imágenes de referencia (el gotcha -i)

⚠️ **EL GOTCHA MÁS CARO DE ESTA RUTA**: `-i/--image` es variádico (`-i <FILE>...`) y se
TRAGA el prompt posicional como si fuera otra ruta de imagen. El fallo es silencioso:
`codex exec` termina con exit 0 y el mensaje `No prompt provided via stdin` — sin imagen.
Con `-i`, el prompt va SIEMPRE por stdin con `-` final:

```bash
cd <directorio-destino> && echo "La imagen adjunta es <descripción del personaje/marca: \
rasgos, ropa, paleta, estética>. Usa tu skill de generación de imágenes (imagegen / \
gpt-image-2) con la imagen adjunta como referencia para generar UNA imagen <formato y \
escena>. Mantén EXACTAMENTE el diseño del personaje: <lista de invariantes: gafas, ropa, \
colores>. Guárdala como <nombre>.png en el directorio de trabajo actual. Verifica que \
existe y reporta dimensiones. No hagas nada más." \
  | codex exec --skip-git-repo-check --sandbox workspace-write -i <ruta/referencia.png> -
```

- Varias referencias — DOS sintaxis verificadas en vivo (codex-cli 0.146.0, 2026-08-06,
  el modelo confirmó ver ambas imágenes con las dos): `-i ref1.png ref2.png -` (espacios)
  y `-i ref1.png,ref2.png -` (comas). En ambas el `-` final sigue siendo obligatorio.
  Los ejemplos oficiales de la API usan hasta 4 imágenes de entrada; límites mayores NO
  están documentados — probar antes de prometer.
- Describir la referencia EN el prompt además de adjuntarla (el texto ancla los
  invariantes; la imagen ancla el estilo).
- Repetir los invariantes en cada iteración de edit para evitar drift.

## 5. Operativa: background, lotes y verificación

- **Duración**: 1-3 min por imagen → lanzar en background y seguir con otra cosa; varias
  generaciones en paralelo funcionan (procesos `codex exec` independientes).
- **Coste observado** (medición local 2026-08-05, esta máquina; no es garantía portable):
  ~16-20k tokens de Codex por imagen sin referencia, ~40k con referencia.
- **Dónde quedan los originales**: `${CODEX_HOME:-$HOME/.codex}/generated_images/<uuid>/…` — el prompt pide
  la copia al cwd; si algo falla a mitad, el original suele estar ahí.
- **Verificación SIEMPRE**: exit 0 de `codex exec` NO garantiza imagen (ver gotcha `-i`).
  Verificar: (a) el tail del output menciona el archivo guardado; (b) el archivo existe con
  las dimensiones pedidas; (c) inspección VISUAL del resultado (abrir el PNG) — texto en
  imagen, encuadre y fidelidad del personaje solo se validan mirando.

```bash
# Verificación mínima post-generación: COMPARA contra lo esperado, no solo imprime.
# Pillow ya es prerrequisito del skill → herramienta portable única (macOS y Linux):
EXPECTED_W=2048 EXPECTED_H=2048 FILE=<nombre>.png
test -s "$FILE" || { echo "FALTA el archivo"; exit 1; }
python3 -c "
import os, sys
from PIL import Image
w, h = Image.open(os.environ['FILE']).size
ew, eh = int(os.environ['EXPECTED_W']), int(os.environ['EXPECTED_H'])
sys.exit(0 if (w, h) == (ew, eh) else print(f'DIMENSIONES {w}x{h} != esperadas {ew}x{eh}') or 1)
" || exit 1
```

## 6. Manejo de errores

| Síntoma | Causa | Arreglo |
|---------|-------|---------|
| `No prompt provided via stdin` + exit 0 | Gotcha `-i`: el flag se tragó el prompt | Prompt por stdin con `-` final (§4) |
| `command not found: codex` | CLI ausente | Sonda §2 paso 1 |
| Error de auth / login requerido | Sesión caducada | `codex login` |
| Genera pero no copia al cwd | Sandbox sin permiso de escritura o prompt sin destino | `--sandbox workspace-write` + cwd correcto + destino explícito en el prompt |
| Tamaño distinto del pedido | Size inválido del contrato → el modelo eligió otro | Validar antes con `validate_image_request.py` |
| Imagen correcta pero detalle mal (auriculares puestos vs al cuello) | Ambigüedad del prompt | Añadir el invariante explícito y regenerar |

## 7. Gotchas & Cross-References

1. **Exit 0 ≠ imagen generada** → verificar SIEMPRE archivo + dimensiones + visual (§5).
2. **`-i` se traga el prompt** → stdin + `-`. Es el fallo silencioso número uno (§4).
3. **No es gratis: es pool de suscripción** → limitado; en volumen alto considerar la ruta
   API con presupuesto (`ruta-api-directa.md`).
4. **La capacidad vive en el runtime, no en el binario** → un `codex` instalado sin el
   skill de sistema `imagegen` no puede generar; la sonda §2 lo detecta (fallo 3).
5. **Un `codex exec` por asset** → `n`/lotes en una sola llamada producen variantes de un
   prompt, no assets distintos.

**Related reference files:**

- Contrato de tamaños y parámetros → `restricciones-y-validacion.md`
- Pipeline completo de campaña → `ads-playbook.md`
- La misma generación con API key y control determinista de parámetros → `ruta-api-directa.md`
