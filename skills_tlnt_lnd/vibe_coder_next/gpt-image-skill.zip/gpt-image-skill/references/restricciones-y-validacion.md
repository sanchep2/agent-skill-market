# Restricciones y Validación Pre-flight — Complete Reference

Contrato duro del modelo `gpt-image-2` y cómo validarlo ANTES de generar. Toda cifra de
esta página está verificada contra la guía oficial de Image Generation
(`developers.openai.com/api/docs/guides/image-generation`, consultada 2026-08-05) y
coincide con el contrato local del skill de sistema `imagegen` de Codex.

## Table of Contents

1. [Contrato de dimensiones](#1-contrato-de-dimensiones)
2. [Tamaños canónicos que siempre pasan](#2-tamaños-canónicos-que-siempre-pasan)
3. [Parámetros y sus límites](#3-parámetros-y-sus-límites)
4. [Transparencia: no soportada y su workaround](#4-transparencia-no-soportada-y-su-workaround)
5. [El validador del skill](#5-el-validador-del-skill)
6. [Ciclo de vida del modelo](#6-ciclo-de-vida-del-modelo)
7. [Gotchas & Cross-References](#7-gotchas--cross-references)

---

## 1. Contrato de dimensiones

Una petición `size=WIDTHxHEIGHT` a `gpt-image-2` es válida SOLO si cumple TODO esto:

| Regla | Valor | Ejemplo que FALLA |
|-------|-------|-------------------|
| Ambos lados múltiplos de 16 px | `w % 16 == 0 && h % 16 == 0` | `2560x1080` (1080/16 = 67,5) |
| Borde mayor | `<= 3840 px` | `4096x1024` |
| Ratio largo:corto | `<= 3:1` | `3072x768` (4:1) |
| Píxeles totales | `655.360 .. 8.294.400` | `304x256` (77.824 px) y `3840x3840` (14,7 M px) |

```text
¿size válido?
├── ¿w y h múltiplos de 16?  ── no ──▶ RECHAZADO (redondear con nearest_valid_size)
├── ¿max(w,h) <= 3840?       ── no ──▶ RECHAZADO
├── ¿ratio <= 3:1?           ── no ──▶ RECHAZADO (error de diseño del formato, no de redondeo)
└── ¿655.360 <= w*h <= 8.294.400? ── no ──▶ RECHAZADO
                                   └ sí ──▶ VÁLIDO
```

Consecuencia clave para ads: **el modelo NUNCA produce el entregable final de plataforma**
(`1080x1920` viola múltiplos-de-16; `300x250` viola el mínimo de píxeles). El flujo es
siempre master válido → `scripts/adapt_master.py` → dimensiones exactas de plataforma.

## 2. Tamaños canónicos que siempre pasan

| Uso | size | Ratio | Nota |
|-----|------|-------|------|
| Cuadrado draft rápido | `1024x1024` | 1:1 | El más rápido de generar |
| Cuadrado final | `2048x2048` | 1:1 | Master de feed y de display |
| Horizontal | `1536x1024` · `2048x1152` | 3:2 · 16:9 | |
| Vertical | `1024x1536` · `1152x2048` | 2:3 · 9:16 | Master de story |
| Feed 4:5 | `1280x1600` | 4:5 | Master de feed vertical (no requiere upscale a 1080×1350) |
| 21:9 exacto | `1792x768` | 2,33:1 | Hero panorámico |
| 4K | `3840x2160` · `2160x3840` | 16:9 | Máximo del modelo |
| Automático | `auto` | — | El modelo decide |

`2560x1088` es una aproximación cinematográfica (2,35:1) válida para el modelo — NO es
21:9 exacto (2,33:1); para 21:9 exacto usar `1792x768`.

## 3. Parámetros y sus límites

| Parámetro | Valores | Regla dura |
|-----------|---------|------------|
| `quality` | `auto` \| `low` \| `medium` \| `high` | `low` para drafts; `high`/`auto` para texto denso y assets finales |
| `output_format` | `png` \| `jpeg` \| `webp` | |
| `output_compression` | `0..100` | SOLO con `jpeg`/`webp` — con `png` la petición es inválida |
| `partial_images` | `0..3` | Requiere streaming activo; con `0` solo llega la imagen final |
| `n` | entero | `n` = variantes de UN prompt; assets distintos = llamadas distintas |
| `input_fidelity` | — | NO ajustable en `gpt-image-2` (siempre alta para inputs de imagen) |
| `response_format` | — | OMITIR en modelos GPT Image: la respuesta ya llega en base64 |

**Imágenes de referencia**: los ejemplos oficiales usan hasta 4 imágenes de entrada en
edits. NO hay límite máximo documentado oficialmente; la observación local de este equipo
(2026-08-05, puente Codex) operó con 1 referencia sin incidencias. Tratar cualquier cifra
de límite ("16") como NO garantizada.

**`stream` + `n`**: la documentación oficial no define la interacción — los ejemplos de
streaming son de imagen única. No asumir que la combinación funciona; probar con la
petición real si se necesita.

## 4. Transparencia: no soportada y su workaround

La guía oficial es explícita: *"gpt-image-2 doesn't currently support transparent
backgrounds. Requests with `background: 'transparent'` aren't supported for this model."*

Workaround estándar (el mismo que usa el propio skill `imagegen` de Codex):

```text
1. Generar el sujeto sobre fondo chroma plano (#00ff00; #ff00ff si el sujeto es verde)
   — fondo uniforme, sin sombras/gradientes/reflejos, bordes nítidos, padding generoso
2. Remover el chroma localmente → PNG/WebP con alpha
3. Validar: canal alpha presente, esquinas transparentes, sin halo del color clave
```

- En la ruta puente: Codex trae el helper instalado
  `~/.codex/skills/.system/imagegen/scripts/remove_chroma_key.py` (auto-key, soft matte,
  despill) — pedirle en el prompt que lo aplique, o correrlo a mano sobre el PNG.
- Transparencia NATIVA del modelo solo existe en `gpt-image-1.5` (deprecado, shutdown
  2026-12-01) — no construir flujos nuevos sobre ella.

## 5. El validador del skill

`scripts/validate_image_request.py` implementa este contrato completo, sin red ni
dependencias:

```bash
# Validar una petición antes de gastarla
python3 .claude/skills/gpt-image-skill/scripts/validate_image_request.py validate --width 1792 --height 768
# → {"ok": true, ...}  · exit 0

python3 .claude/skills/gpt-image-skill/scripts/validate_image_request.py validate --width 2560 --height 1080
# → {"ok": false, "errors": ["height=1080 no es múltiplo de 16"],
#    "nearest_valid_size": "2560x1088"}  · exit 1

# Master recomendado para un formato de ad del playbook
python3 .claude/skills/gpt-image-skill/scripts/validate_image_request.py master --ad-format story-9x16
# → {"master": "1152x2048", "final": "1080x1920", ...}

python3 .claude/skills/gpt-image-skill/scripts/validate_image_request.py list-formats
```

Manejo de errores del validador: dimensiones no positivas, formato de ad desconocido y
parámetros fuera de rango devuelven `ok:false` + `exit 1` con el error explícito en JSON —
apto para gatear pipelines (`&&`).

## 6. Ciclo de vida del modelo

| Modelo | Estado | Nota |
|--------|--------|------|
| `gpt-image-2` | Flagship, recomendado | Este skill |
| `gpt-image-1.5` | **Deprecado — shutdown 2026-12-01** | Única vía de transparencia nativa; no adoptar |
| `gpt-image-1-mini` | **Deprecado — shutdown 2026-12-01** | |
| `gpt-image-1` | Generación anterior | No usar en flujos nuevos |

## 7. Gotchas & Cross-References

1. **El entregable de plataforma casi nunca es un size válido del modelo** → `1080x1920`,
   `1080x1080` y `300x250` fallan el contrato (múltiplos/mínimo de píxeles). Generar el
   master del playbook y adaptar SIEMPRE con `adapt_master.py`.
2. **`2560x1080` parece 21:9 y falla** → 1080 no es múltiplo de 16. El 21:9 exacto válido
   es `1792x768`.
3. **Validar ANTES de generar** → una petición inválida quema 1-3 minutos y cuota del pool
   antes de fallar (o produce un tamaño inesperado silenciosamente en la ruta puente).
4. **Ratio > 3:1 no se "redondea"** → es un error de diseño del formato pedido; el
   validador lo reporta y no lo corrige.
5. **`output_compression` con `png` invalida la petición** → solo `jpeg`/`webp`.

**Related reference files:**

- Recetas por formato de campaña → `ads-playbook.md`
- Parámetros completos de la API → `ruta-api-directa.md`
- Generación vía Codex sin API key → `ruta-codex-bridge.md`
