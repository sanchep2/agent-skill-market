# Specs por Plataforma — Complete Reference

Tabla propia y compacta de especificaciones de imagen por plataforma de ads: dimensiones
finales EXACTAS, formato, peso máximo y safe zones. Es la fuente que consume
`scripts/adapt_master.py` (specs codificadas en `PLATFORM_SPECS`).

⚠️ Las plataformas cambian specs sin aviso: antes de una campaña real, re-verificar la
cifra concreta contra el manager de anuncios de la plataforma (nunca confiar en specs
de vendor recordadas: cambian sin aviso). Esta tabla es el punto de partida operativo,
verificada por última vez 2026-08-05.

## Table of Contents

1. [Tabla maestra de entregables](#1-tabla-maestra-de-entregables)
2. [Safe zones verticales (story/reel)](#2-safe-zones-verticales-storyreel)
3. [Mapeo formato → master del modelo](#3-mapeo-formato--master-del-modelo)
4. [Del master al asset con adapt_master.py](#4-del-master-al-asset-con-adapt_masterpy)
5. [Gotchas & Cross-References](#5-gotchas--cross-references)

---

## 1. Tabla maestra de entregables

| Spec (`adapt_master.py`) | Plataforma / placement | Final exacto | Formato | Peso máx |
|--------------------------|------------------------|--------------|---------|----------|
| `meta-feed` | Meta feed cuadrado (FB/IG) | 1080×1080 | JPEG | 30 MB |
| `meta-feed-4x5` | Meta feed vertical 4:5 | 1080×1350 | JPEG | 30 MB |
| `meta-story` | IG/FB Stories y Reels | 1080×1920 | JPEG | 30 MB |
| `tiktok-video-cover` | TikTok imagen/cover 9:16 | 1080×1920 | JPEG | 30 MB |
| `gdn-300x250` | Google Display medium rectangle | 300×250 | JPEG | **150 KB** |
| `gdn-336x280` | Google Display large rectangle | 336×280 | JPEG | **150 KB** |
| `linkedin-feed` | LinkedIn single image (1.91:1) | 1200×628 | JPEG | 5 MB |
| `x-feed` | X (Twitter) imagen 16:9 | 1600×900 | JPEG | 5 MB |

Notas de peso: Meta acepta hasta 30 MB por imagen; Google Display es el estricto real
(150 KB por asset de display) — por eso el adaptador comprime iterativamente y FALLA
explícito si no cabe.

## 2. Safe zones verticales (story/reel)

En 9:16 la UI de la plataforma pisa las franjas superior e inferior — el contenido
crítico (texto, CTA, logo, cara del personaje) debe vivir en la zona central:

```text
1080×1920 (story/reel)
┌──────────────────────┐ 0
│  ~14% UI superior     │  ← username, cámara (Meta) — NO poner texto/CTA
├──────────────────────┤ ~270 px
│                      │
│   ZONA SEGURA        │  ← todo lo importante aquí
│   (~66% central)     │
│                      │
├──────────────────────┤ ~1536 px
│  ~20% UI inferior     │  ← CTA de la plataforma, caption, compartir
└──────────────────────┘ 1920
```

TikTok añade además una columna cargada a la DERECHA (likes/comentarios): mantener texto
alejado del borde derecho (~15%). Los porcentajes exactos varían por app y versión — el
overlay `safezone` del adaptador pinta las franjas para inspección visual pieza a pieza.

## 3. Mapeo formato → master del modelo

Los finales de plataforma casi nunca son sizes válidos de `gpt-image-2` (múltiplos de 16,
mínimo de píxeles). El playbook genera SIEMPRE estos masters y adapta:

| Formato de ad (`validate_image_request.py`) | Master (válido modelo) | Final | Spec de adaptación |
|---------------------------------------------|------------------------|-------|--------------------|
| `feed-1x1` | 2048×2048 | 1080×1080 | `meta-feed` |
| `feed-4x5` | 1280×1600 | 1080×1350 | `meta-feed-4x5` |
| `story-9x16` | 1152×2048 | 1080×1920 | `meta-story` / `tiktok-video-cover` |
| `landscape-16x9` | 2048×1152 | 1600×900 · 1200×628 | `x-feed` / `linkedin-feed` |
| `ultrawide-21x9` | 1792×768 | 1792×768 | (hero web — sin adaptación) |
| `display-300x250` / `display-336x280` | reutilizan el master `feed-1x1` | 300×250 · 336×280 | `gdn-300x250` / `gdn-336x280` |

Un solo master 1:1 sirve para feed cuadrado Y los dos displays; un master 9:16 sirve para
Meta story Y TikTok. Minimiza generaciones por concepto: **2 masters → 5+ entregables**.

## 4. Del master al asset con adapt_master.py

```bash
# Ver las specs disponibles
python3 .claude/skills/gpt-image-skill/scripts/adapt_master.py list-specs

# Master 9:16 → story final exacta (crop centrado, JPEG bajo peso máximo)
python3 .claude/skills/gpt-image-skill/scripts/adapt_master.py adapt --master master-story.png --spec meta-story --out story-final.jpg

# Overlay de safe zone como ARTEFACTO SEPARADO (nunca pisa el asset)
python3 .claude/skills/gpt-image-skill/scripts/adapt_master.py safezone --asset story-final.jpg --spec meta-story
# → story-final-safezone.png (bandas rojas translúcidas para inspección)

# Master 1:1 → display 300×250 bajo 150 KB (o fallo explícito)
python3 .claude/skills/gpt-image-skill/scripts/adapt_master.py adapt --master master-feed.png --spec gdn-300x250 --out banner-300.jpg
```

Manejo de errores del adaptador: spec desconocida, master ausente y peso inalcanzable
devuelven `ok:false` + `exit 1` (JSON con el motivo). El peso es condición OBSERVABLE:
archivo final ≤ máximo o `AdaptationError` — jamás un asset silenciosamente pasado.

## 5. Gotchas & Cross-References

1. **El crop centrado puede cortar el motivo** → el cover-crop recorta bordes al cambiar
   de ratio (1:1 → 300×250 pierde franjas arriba/abajo). Componer los masters con el
   sujeto centrado y aire alrededor; inspeccionar SIEMPRE el resultado.
2. **150 KB de Google Display es el límite duro real** → un master con mucho detalle fino
   (ruido, texturas) puede no caber ni a quality mínima; el adaptador falla explícito →
   simplificar el master, no subir el límite.
3. **El overlay safezone NO es publicable** → es `*-safezone.png`, artefacto de
   inspección; el adaptador se niega a escribirlo sobre el asset. No subirlo a la
   plataforma ni incluirlo en la selección automática de entregables.
4. **Texto pegado a bordes en 9:16** → cae bajo la UI de la app. Validar con el overlay
   antes de aprobar la pieza.
5. **Re-verificar specs antes de cada campaña** → las cifras de esta tabla caducan sin
   aviso; 5 minutos contra el ads manager evitan un rechazo de campaña.

**Related reference files:**

- Pipeline completo y lotes → `ads-playbook.md`
- Por qué los finales no se generan directos → `restricciones-y-validacion.md`
