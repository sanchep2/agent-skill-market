# Ruta API Directa — Complete Reference

Generación con `gpt-image-2` contra la API de OpenAI con `OPENAI_API_KEY`. Pago por
imagen (facturación por token del modelo). Úsala cuando necesites: control determinista
del CONTRATO de parámetros (tamaño/calidad/formato exactos, sin agente interpretando),
edits con máscara, lotes programáticos o streaming. "Determinista" aplica al contrato de
parámetros y facturación — el contenido visual sigue siendo no determinista.

Fuente: `developers.openai.com/api/docs/guides/image-generation`, consultada 2026-08-05.

## Table of Contents

1. [Sonda pre-flight (fail-closed)](#1-sonda-pre-flight-fail-closed)
2. [Pricing por calidad y tamaño](#2-pricing-por-calidad-y-tamaño)
3. [Generations: texto a imagen](#3-generations-texto-a-imagen)
4. [Edits: referencia y máscara](#4-edits-referencia-y-máscara)
5. [Responses API y streaming](#5-responses-api-y-streaming)
6. [Manejo de errores](#6-manejo-de-errores)
7. [Gotchas & Cross-References](#7-gotchas--cross-references)

---

## 1. Sonda pre-flight (fail-closed)

```bash
[ -n "${OPENAI_API_KEY:-}" ] || { echo "FALTA OPENAI_API_KEY → crear la key en \
platform.openai.com/api-keys y, ANTES de lotes o n alto, configurar y verificar un HARD \
SPEND LIMIT a nivel de proyecto u organización (la key por sí sola no limita el gasto). \
Alternativa sin key: la ruta puente Codex (ruta-codex-bridge.md)"; exit 1; }
# Hard spend limit NO verificable por API → confirmación explícita del operador:
[ "${OPENAI_SPEND_LIMIT_CONFIRMED:-}" = "1" ] || { echo "SIN CONFIRMAR el HARD SPEND LIMIT → \
verificarlo a nivel de proyecto/organización en el dashboard y exportar \
OPENAI_SPEND_LIMIT_CONFIRMED=1 antes de lotes o n alto"; exit 1; }
```

El hard spend limit no es verificable por API: la sonda exige la confirmación explícita
del operador (`OPENAI_SPEND_LIMIT_CONFIRMED=1` tras verificarlo en el dashboard) antes de
lotes o `n` alto — ver la rama `api` de la sonda en `SKILL.md`.

Nunca degradar a la ruta puente en silencio: son perfiles de coste distintos — anunciar el
cambio de ruta y por qué.

## 2. Pricing por calidad y tamaño

Precio POR IMAGEN según calidad y tamaño (tabla oficial, consultada 2026-08-05 — usar el
calculador oficial para el caso concreto; NO citar una cifra única "por imagen"):

| Quality | 1024×1024 | 1024×1536 | 1536×1024 |
|---------|-----------|-----------|-----------|
| `low` | $0.006 | $0.005 | $0.005 |
| `medium` | $0.053 | $0.041 | $0.041 |
| `high` | $0.211 | $0.165 | $0.165 |

Los inputs (prompt + imágenes de referencia) se facturan aparte por token. Regla de
trabajo: `low` para explorar conceptos (≈1 centavo), `high` solo para los finalistas.

## 3. Generations: texto a imagen

`POST /v1/images/generations` — parámetros para `gpt-image-2`: `model`, `prompt`, `size`,
`quality`, `n`, `output_format`, `output_compression`, `partial_images`, `moderation`,
`stream`. OMITIR `response_format` (la imagen llega en base64 siempre).

### TypeScript

```bash
npm install openai        # SDK oficial
```

```typescript
import OpenAI from "openai";
import { writeFileSync } from "node:fs";

const client = new OpenAI({ maxRetries: 0 }); // sin reintentos del SDK (postura no-auto-retry); lee OPENAI_API_KEY del entorno

// --- Operación 1: master de feed (validar el size ANTES con validate_image_request.py) ---
const gen = await client.images.generate({
  model: "gpt-image-2",
  prompt: "Cartel de campaña con el texto exacto 'INSCRIPCIONES ABIERTAS', estilo …",
  size: "2048x2048",
  quality: "high",
  output_format: "png",
});
writeFileSync("master-feed.png", Buffer.from(gen.data![0].b64_json!, "base64"));

// --- Operación 2: draft barato para explorar (low ≈ $0.006) ---
const draft = await client.images.generate({
  model: "gpt-image-2",
  prompt: "…",
  size: "1024x1024",
  quality: "low",
});

// --- Operación 3: variantes de UN prompt ---
const variants = await client.images.generate({
  model: "gpt-image-2",
  prompt: "…",
  size: "1024x1024",
  quality: "medium",
  n: 3,
});

// --- Error handling ---
try {
  await client.images.generate({ model: "gpt-image-2", prompt: "…", size: "2560x1080" });
} catch (err) {
  if (err instanceof OpenAI.APIError) {
    // 400: size inválido (el pre-flight local lo habría cazado gratis)
    console.error(err.status, err.message);
  } else throw err;
}
```

### Python

```bash
pip install openai
```

```python
import base64
from openai import OpenAI, APIError

client = OpenAI(max_retries=0)  # sin reintentos del SDK (postura no-auto-retry); lee OPENAI_API_KEY del entorno

# --- Operación 1: master de story ---
gen = client.images.generate(
    model="gpt-image-2",
    prompt="…",
    size="1152x2048",
    quality="high",
    output_format="png",
)
with open("master-story.png", "wb") as f:
    f.write(base64.b64decode(gen.data[0].b64_json))

# --- Operación 2: jpeg comprimido directo ---
gen2 = client.images.generate(
    model="gpt-image-2", prompt="…", size="1024x1024",
    quality="medium", output_format="jpeg", output_compression=85,
)

# --- Operación 3 + error handling ---
try:
    client.images.generate(model="gpt-image-2", prompt="…", size="300x250")
except APIError as e:  # 400: viola el mínimo de píxeles del modelo
    print(e.status_code, e.message)
```

### curl

```bash
# La key va por archivo --config 0600, NUNCA en argv (sería visible en ps/proc) —
# nunca exponer credenciales en argumentos de proceso.
cfg=$(mktemp); chmod 600 "$cfg"; trap 'rm -f "$cfg"' EXIT
printf 'header = "Authorization: Bearer %s"\n' "$OPENAI_API_KEY" > "$cfg"
# Timeouts explícitos + fail-with-body; se decodifica a un temporal y solo un payload
# VÁLIDO se mueve al destino (nunca escribir hero.png con una respuesta de error):
tmp=$(mktemp hero-XXXX.png)
curl -sS --fail-with-body --connect-timeout 10 --max-time 300 --config "$cfg" \
  https://api.openai.com/v1/images/generations \
  -H "Content-Type: application/json" \
  -d '{"model":"gpt-image-2","prompt":"…","size":"1792x768","quality":"high"}' \
  | python3 -c "
import base64, json, sys
body = json.load(sys.stdin)
data = body.get('data') or sys.exit(f'sin data en la respuesta: {body}')
open('$tmp', 'wb').write(base64.b64decode(data[0]['b64_json']))
" && mv "$tmp" hero.png || { rm -f "$tmp"; exit 1; }
```

## 4. Edits: referencia y máscara

`POST /v1/images/edits` (multipart) — parámetros: `model`, `image` (una o varias),
`mask`, `prompt`, `size`, `quality`, `output_format`, `output_compression`. En
`gpt-image-2` `input_fidelity` NO es ajustable (siempre alta). Los ejemplos oficiales
usan hasta 4 imágenes de entrada; no hay máximo documentado.

```python
# Editar manteniendo el personaje: la referencia entra como image[]
result = client.images.edit(
    model="gpt-image-2",
    image=[open("talent-oso-ref.png", "rb")],
    prompt="El mismo personaje EXACTO celebrando con confeti verde, fondo oscuro …",
    size="1152x2048",
    quality="high",
)
```

Con `mask`: PNG con alpha del MISMO tamaño que la imagen; las zonas transparentes de la
máscara son las que el modelo puede repintar (inpainting selectivo).

## 5. Responses API y streaming

La Responses API expone la generación como herramienta `image_generation` de un modelo de
texto (útil para flujos mixtos texto+imagen o `previous_response_id`):

```python
resp = client.responses.create(
    # Usar un modelo de texto que soporte la tool image_generation — verificar la lista
    # vigente en la guía oficial de Image Generation antes de fijarlo (los modelos
    # soportados cambian por generación; no fijar uno aquí sin verificarlo)
    model="<modelo-texto-compatible>",
    input="Genera un póster …",
    tools=[{"type": "image_generation"}],
)
# La imagen llega DENTRO de resp.output como item image_generation_call (base64 en .result):
import base64
images = [o.result for o in resp.output if o.type == "image_generation_call"]
if not images:
    raise RuntimeError(f"la respuesta no trae image_generation_call: {resp.output}")
open("poster.png", "wb").write(base64.b64decode(images[0]))
```

Streaming con previews progresivos: `stream=true` + `partial_images` (`0..3`; con `0`
solo llega la final). Los ejemplos oficiales de streaming son de imagen única — la
interacción `stream` × `n>1` NO está documentada: no asumirla.

## 6. Manejo de errores

| HTTP | Causa típica | Acción |
|------|--------------|--------|
| 400 | `size` inválido · `background=transparent` · `output_compression` con png | Pre-flight local primero (`validate_image_request.py`) — es gratis |
| 401 | Key ausente/revocada | Sonda §1; rotar key |
| 429 | Rate limit / presupuesto | Backoff exponencial; revisar los controles de gasto y límites del PROYECTO u ORGANIZACIÓN (la key por sí sola no limita) |
| 403 verificación de organización | La org de la key no está habilitada para el modelo | Fallo cerrado: NO lanzar el lote; completar la verificación de la organización en el dashboard de OpenAI y reintentar |
| `moderation_blocked` | Prompt/imagen rechazados por política | Reformular; no reintentar idéntico |
| 5xx / error de transporte | Transitorio del servicio | SIN reintento automático (el endpoint no documenta idempotency key y un fallo ambiguo puede haber facturado la imagen): registrar identidad del asset + `request_id` si existe, reconciliar contra el uso facturado y solo entonces decidir el reintento |

## 7. Gotchas & Cross-References

1. **Pre-flight local antes de pagar** → un 400 por size inválido cuesta una llamada y
   tiempo; `validate_image_request.py` lo caza gratis.
2. **`high` es 35× más caro que `low`** → explorar en `low`, finalizar en `high`.
3. **`response_format` rompe la petición** → omitirlo siempre con modelos GPT Image.
4. **Hard spend limit SIEMPRE a nivel de proyecto/organización** → una org sin techo + un
   bucle con `n` alto es una factura sorpresa; la key por sí sola no limita el gasto.
5. **No fabricar transparencia aquí** → `gpt-image-2` la rechaza igual que en el puente;
   mismo workaround chroma (`restricciones-y-validacion.md` §4).

**Related reference files:**

- Contrato completo de dimensiones/parámetros → `restricciones-y-validacion.md`
- Generación sin API key → `ruta-codex-bridge.md`
- Pipeline de campaña → `ads-playbook.md`
