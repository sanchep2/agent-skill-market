---
name: gpt-image-skill
description: >
  Usar SIEMPRE que se generen imágenes con GPT Image 2 / gpt-image-2 (OpenAI) — sobre todo
  ads y creatividades de campañas de marketing digital: feed, stories, reels, banners
  display, heros, CTA cards, texto en imagen, lotes A/B y personaje/marca consistente con
  imagen de referencia. Dos rutas: puente Codex CLI (codex exec + imagegen/image_gen, sin
  OPENAI_API_KEY) y API directa (images/generations, images/edits con máscara, streaming).
  Incluye pre-flight del contrato del modelo y adaptación master→asset exacto por
  plataforma (Meta, TikTok, Google Display, LinkedIn, X) con safe zones. Triggers ES/EN:
  generar imagen, generate image, GPT Image, gpt-image-2, imagegen, image_gen, ad creative,
  creatividad, campaña, campaign, ads, anuncio, banner, display, 300x250, feed, story,
  reel, 9:16, 21:9, hero, CTA, cartel, poster, texto en imagen, mask, inpainting, imagen
  de referencia, personaje consistente, batch, marketing digital. Incluso si solo dicen
  "hazme unas creatividades", usarlo.
---

# GPT Image 2 — Producción de Ads e Imágenes (agosto 2026)

## Quick Orientation

Skill especializado de `gpt-image-2` (modelo de imagen flagship de OpenAI, abril 2026 —
el mejor render de texto/CTA en imagen) con caso de uso rector: **ads para campañas de
marketing digital en volumen**. Dos rutas de ejecución, un mismo contrato de calidad.

| Property | Value |
|----------|-------|
| **Modelo** | `gpt-image-2` (flagship; `gpt-image-1.5`/`1-mini` deprecados, shutdown 2026-12-01) |
| **Ruta 1 — Puente Codex** | `codex exec` → skill `imagegen` → tool `image_gen`; SIN `OPENAI_API_KEY` (pool de suscripción ChatGPT) |
| **Ruta 2 — API directa** | `POST /v1/images/{generations,edits}` + Responses API; `OPENAI_API_KEY`. Images API: coste POR PIEZA según tamaño/calidad (ej. 1024: low $0.005 → high $0.211) + tokens de inputs (incl. referencias) — calcular con los parámetros REALES antes de un lote. Responses API: tokens de entrada/salida ADEMÁS de la imagen |
| **Contrato de tamaños** | lados múltiplos de 16 · borde ≤ 3840 px · ratio ≤ 3:1 · 655.360–8.294.400 px |
| **Transparencia** | NO soportada → workaround chroma-key + remoción local |
| **Verificado** | Guía oficial `developers.openai.com/api/docs/guides/image-generation` + contrato local `imagegen` de Codex · `last_verified: 2026-08-05` |

**Prerrequisitos externos por ruta** (autosuficiente: esto es lo ÚNICO externo que cada ruta exige):

| Prerrequisito | Ruta que lo exige |
|---------------|-------------------|
| Codex CLI instalado y autenticado (sesión ChatGPT) | Puente Codex |
| Capacidad `imagegen` disponible en ese runtime de Codex | Puente Codex |
| `OPENAI_API_KEY` (con límite de gasto) | API directa (únicamente) |
| Python 3.10+ y Pillow (`pip install Pillow`) | Adaptación master→asset (ambas rutas) |

**Sonda pre-flight fail-closed (OBLIGATORIA antes de generar)**: comprobar los
prerrequisitos de la ruta elegida y, si falta algo, PARAR con instrucción accionable —
nunca degradar en silencio. La sonda verifica PRERREQUISITOS; la prueba definitiva de la
ruta es la PRIMERA generación real: si esa primera pieza falla por auth o por capacidad,
tratarlo como fallo cerrado y NO lanzar el resto del lote.

```bash
RUTA=codex   # codex | api — sondear SOLO la ruta elegida
case "$RUTA" in
  codex)  # diferencia los 3 fallos: CLI ausente / sesión inválida o no-ChatGPT / sin capacidad
    command -v codex >/dev/null || { echo "FALTA Codex CLI → npm i -g @openai/codex"; exit 1; }
    login_out="$(codex login status 2>&1)" || { echo "SESIÓN INVÁLIDA O AUSENTE → codex login"; exit 1; }
    case "$login_out" in *ChatGPT*) : ;; *) echo "SESIÓN NO-ChatGPT ($login_out) → esta ruta factura como API, no como suscripción; usar la ruta API o re-loguear con ChatGPT"; exit 1 ;; esac
    [ -f "${CODEX_HOME:-$HOME/.codex}/skills/.system/imagegen/SKILL.md" ] || { echo "SIN el skill de sistema imagegen (prerrequisito estático) → actualizar Codex; puente NO disponible"; exit 1; }
    echo "PRERREQUISITOS DEL PUENTE OK — la primera generación es la prueba definitiva" ;;
  api)
    [ -n "${OPENAI_API_KEY:-}" ] || { echo "FALTA OPENAI_API_KEY → crearla en platform.openai.com/api-keys"; exit 1; }
    # El hard spend limit NO es verificable por API → gate de confirmación explícita del operador:
    [ "${OPENAI_SPEND_LIMIT_CONFIRMED:-}" = "1" ] || { echo "SIN CONFIRMAR el HARD SPEND LIMIT → verificarlo a nivel de proyecto/organización en el dashboard de OpenAI y exportar OPENAI_SPEND_LIMIT_CONFIRMED=1 antes de lotes o n alto"; exit 1; } ;;
  *) echo "RUTA desconocida: '$RUTA' (válidas: codex | api)"; exit 1 ;;
esac
# Adaptación (SIEMPRE, ambas rutas): Python >= 3.10 y Pillow
python3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" || { echo "PYTHON < 3.10 → actualizar Python antes de continuar"; exit 1; }
python3 -c "import PIL" 2>/dev/null || { echo "FALTA Pillow → pip install Pillow"; exit 1; }
```

**For deeper topics, read the appropriate reference file before writing code:**

| Topic | Reference File | When to Read |
|-------|---------------|--------------|
| Pipeline de campaña completo: brief → masters → adaptación → aprobación → entrega; prompts de texto/CTA; personaje consistente; lotes | `references/ads-playbook.md` | SIEMPRE que se pidan creatividades/ads — es la puerta de entrada del 90% de los usos |
| Puente Codex: patrón `codex exec`, sonda, gotcha `-i`, verificación, costes | `references/ruta-codex-bridge.md` | Generar sin API key (ruta por defecto) |
| API directa: generations/edits/máscaras/Responses/streaming, pricing, SDKs | `references/ruta-api-directa.md` | Generar con `OPENAI_API_KEY`; edits con máscara; lotes deterministas |
| Contrato del modelo: dimensiones, parámetros, transparencia, validador | `references/restricciones-y-validacion.md` | Antes de pedir CUALQUIER tamaño no canónico; al fallar un size |
| Dimensiones finales, pesos máximos y safe zones por plataforma | `references/specs-plataformas.md` | Al adaptar masters a entregables; antes de una campaña real |

## Quick Start — Puente Codex (bash, default)

```bash
# 0) Sonda (arriba) → 1) master válido para el formato:
python3 .claude/skills/gpt-image-skill/scripts/validate_image_request.py master --ad-format feed-1x1
# → master 2048x2048

# 2) Generar (1-3 min; en agentes: lanzar en background) — cd aislado en subshell
mkdir -p out && (cd out/ && codex exec --skip-git-repo-check --sandbox workspace-write \
  "Usa tu skill de generación de imágenes (imagegen / gpt-image-2) para generar UNA imagen \
   2048x2048: cartel de campaña <estilo> con el texto exacto \"INSCRIPCIONES ABIERTAS\" como \
   titular y botón CTA \"Empieza hoy\". Guárdala como c1-feed.png en el directorio actual. \
   Verifica que existe y reporta dimensiones. No hagas nada más.")

# 3) Adaptar a entregables exactos (feed + display del MISMO master), desde la raíz
python3 .claude/skills/gpt-image-skill/scripts/adapt_master.py adapt --master out/c1-feed.png --spec meta-feed   --out out/final/c1-feed.jpg
python3 .claude/skills/gpt-image-skill/scripts/adapt_master.py adapt --master out/c1-feed.png --spec gdn-300x250 --out out/final/c1-display.jpg
```

⚠️ Con imagen de referencia el prompt va por **stdin** (`echo "…" | codex exec … -i ref.png -`)
— el flag `-i` es variádico y se traga el prompt posicional (fallo silencioso con exit 0).
Detalle en `references/ruta-codex-bridge.md` §4.

## Quick Start — API directa (TypeScript)

```bash
npm install openai
```

```typescript
import OpenAI from "openai";
import { writeFileSync } from "node:fs";

const client = new OpenAI({ maxRetries: 0 }); // sin reintentos del SDK; OPENAI_API_KEY del entorno

const gen = await client.images.generate({
  model: "gpt-image-2",
  prompt: 'Cartel de campaña con el texto exacto "INSCRIPCIONES ABIERTAS" …',
  size: "2048x2048",   // validar antes con validate_image_request.py
  quality: "low",       // low para explorar; la tarifa depende de TAMAÑO y calidad — ver tabla/calculador oficial
});
writeFileSync("master.png", Buffer.from(gen.data![0].b64_json!, "base64"));
```

## Quick Start — API directa (Python)

```bash
pip install openai Pillow
```

```python
import base64
from openai import OpenAI

client = OpenAI(max_retries=0)  # sin reintentos del SDK
gen = client.images.generate(
    model="gpt-image-2", prompt="…", size="1152x2048", quality="high",
)
open("master-story.png", "wb").write(base64.b64decode(gen.data[0].b64_json))
# Edit con referencia: client.images.edit(model="gpt-image-2", image=[open("ref.png","rb")], prompt="…")
```

(curl como tercer ejemplo en `references/ruta-api-directa.md` §3.)

## Essential Patterns Quick Reference

### Pipeline de campaña (contrato sellado)

```text
brief → conceptos/prompts → ruta → pre-flight → MASTERS → adaptación exacta
     → inspección + safe zone → TU APROBACIÓN → entrega   (publicar: SIEMPRE manual)
```

### Elección de ruta

```text
¿OPENAI_API_KEY con presupuesto?
├── NO → PUENTE CODEX (default)
└── SÍ → ¿máscaras / lotes deterministas / streaming?
         ├── SÍ → API DIRECTA
         └── NO → PUENTE CODEX (mejor perfil de coste diario)
```

### Master → entregables (2 masters cubren 5+ piezas)

```text
master 2048x2048 (feed-1x1) ──▶ meta-feed 1080x1080 · gdn-300x250 · gdn-336x280
master 1152x2048 (story-9x16) ─▶ meta-story 1080x1920 · tiktok-video-cover 1080x1920
```

### Validación en dos capas

```text
ANTES de generar:  validate_image_request.py  (contrato del modelo — gratis)
DESPUÉS de adaptar: dimensiones exactas + peso ≤ máx (lo garantiza adapt_master.py) + VISUAL
```

## Critical Gotchas

1. **El flag `-i` de `codex exec` se traga el prompt** → es variádico; el prompt posicional
   se interpreta como ruta de imagen y el proceso "triunfa" (exit 0) sin generar nada. Con
   referencias, prompt SIEMPRE por stdin con `-` final.

2. **Exit 0 del puente ≠ imagen generada** → verificar archivo + dimensiones + inspección
   visual tras CADA generación; el original queda en `~/.codex/generated_images/<uuid>/`.

3. **El modelo nunca produce el entregable de plataforma** → `1080x1920` viola múltiplos
   de 16 y `300x250` el mínimo de píxeles. Siempre master válido → `adapt_master.py`.

4. **`2560x1080` parece 21:9 y es inválido** → 1080 no es múltiplo de 16; el 21:9 exacto
   válido es `1792x768` (`2560x1088` es 2,35:1 cinematográfico, no 21:9).

5. **`background=transparent` se rechaza** → gpt-image-2 no lo soporta; workaround
   chroma-key + remoción local (helper de Codex `remove_chroma_key.py` ya instalado).

6. **El puente no es gratis** → consume el pool agentic de la suscripción ChatGPT
   (~16-40k tokens/imagen, medición local). En ráfagas grandes, ruta API con `quality low`.

7. **`high` cuesta 35× más que `low` en la API** → explorar conceptos en `low`
   ($0.005-0.006), regenerar en `high` ($0.165-0.211) solo los aprobados.

8. **Texto en imagen solo se valida MIRANDO** → typos del modelo en titulares/CTA no los
   detecta ningún exit code; inspección visual pieza a pieza, texto verbatim en el prompt.

9. **El cover-crop recorta bordes al cambiar de ratio** → componer masters con sujeto
   centrado y aire; un titular pegado al borde muere al derivar el display del feed.

10. **`output_compression` con `png` invalida la petición** → solo `jpeg`/`webp`; y
    `partial_images` (0..3) exige streaming activo.

11. **Personaje off-model por drift** → repetir los invariantes textuales ("mantén
    EXACTAMENTE: gafas, sudadera verde…") en CADA iteración, no solo en la primera.

12. **Límites no documentados no se prometen** → nº máximo de imágenes de referencia y
    `stream`×`n>1` NO están en la doc oficial (2026-08-05); tratarlos como no
    garantizados y probar antes de apoyar un flujo en ellos.

## Integración con tu proyecto

Este skill es **autosuficiente**: no requiere ningún otro skill. Los entregables que
produce (`final/*.jpg` con dimensiones exactas de plataforma) se suben tal cual al ads
manager correspondiente, y los heros/OG images aterrizan como assets estáticos de tu web
(p. ej. `public/`) con el tamaño exacto que el componente consume.

## Next Steps

- **¿Te pidieron creatividades/ads/campaña?** → `references/ads-playbook.md`
- **¿Generar sin API key (default)?** → `references/ruta-codex-bridge.md`
- **¿Máscaras, lotes deterministas, streaming o pricing?** → `references/ruta-api-directa.md`
- **¿Un tamaño falla o dudas del contrato?** → `references/restricciones-y-validacion.md`
- **¿Dimensiones finales/pesos/safe zones de una plataforma?** → `references/specs-plataformas.md`
