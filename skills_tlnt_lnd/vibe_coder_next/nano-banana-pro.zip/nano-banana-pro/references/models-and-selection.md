# Models and Selection — Nano Banana Pro Skill

Guia completa de los 4 modelos de generacion de imagenes de Google soportados por este skill.
Gemini 3 Pro Image es el modelo principal. Imagen 4 para volumen sin edicion.

## Table of Contents

- [1. Gemini 3 Pro Image (modelo principal)](#1-gemini-3-pro-image-modelo-principal)
- [2. Imagen 4 Fast](#2-imagen-4-fast)
- [3. Imagen 4 Standard](#3-imagen-4-standard)
- [4. Imagen 4 Ultra](#4-imagen-4-ultra)
- [5. Modelos excluidos](#5-modelos-excluidos)
- [6. Feature matrix](#6-feature-matrix)
- [7. Decision tree](#7-decision-tree)
- [8. Pricing comparison](#8-pricing-comparison)
- [9. Migration timeline](#9-migration-timeline)

---

## 1. Gemini 3 Pro Image (modelo principal)

**ID:** `gemini-3-pro-image-preview`
**Estado:** Preview (estable para produccion)
**Endpoint:** `generateContent` (Gemini nativo)
**Familia:** Gemini 3 Pro

### Capacidades unicas

- **Resolucion maxima 4K** (~4096x4096) — unico modelo con soporte 4K
- **Text rendering SOTA** — el mejor renderizado de texto de todos los modelos actuales
- **Hasta 14 imagenes de referencia** — mas que cualquier otro modelo
- **Edicion conversacional** — instrucciones en lenguaje natural, sin mascaras
- **Multi-turn** — mantiene contexto visual entre turnos de chat
- **Google Search grounding** — genera imagenes basadas en datos reales de busqueda
- **Modo "Thinking"** — razonamiento interno antes de generar
- **Consistencia de personajes** — superior a otros modelos con ref images
- **Batch API** — 50% descuento en procesamiento asincrono

### Precios

| Resolucion | Costo/imagen | Con Batch API (50% off) |
|-----------|-------------|------------------------|
| 2K (~2048x2048) | ~$0.134 | ~$0.067 |
| 4K (~4096x4096) | ~$0.24 | ~$0.12 |

> No hay precio publicado para 1K en Gemini 3 Pro — el minimo es 2K.

### Cuando usar

- **SIEMPRE como default** — es el modelo mas capaz
- Cuando necesitas texto en imagenes
- Cuando necesitas edicion (cambiar fondo, eliminar objetos, etc.)
- Cuando necesitas multi-turn (refinamiento iterativo)
- Cuando necesitas imagenes de referencia (fotos de personas, logos, estilos)
- Cuando necesitas 4K
- Cuando necesitas Google Search grounding

### Limitaciones

- Preview (no GA todavia, pero estable en produccion)
- Mas caro que Imagen 4 ($0.134 vs $0.02-$0.06)
- 503 "model overloaded" frecuente en horas pico
- Solo 1 imagen por response (usar Batch API para multiples)

---

## 2. Imagen 4 Fast

**ID:** `imagen-4.0-fast-generate-001`
**Estado:** GA (estable)
**Endpoint:** `predict` / `generateImages`
**Familia:** Imagen 4

### Capacidades

- Text-to-image puro
- 1-4 imagenes por request (`sampleCount`)
- Resolucion maxima ~1K
- **$0.02/imagen** — el mas barato

### Limitaciones

- **NO soporta edicion** — solo text-to-image
- **NO soporta multi-turn** — cada request es independiente
- **NO soporta imagenes de referencia** — solo texto
- **NO soporta Batch API** — solo llamadas individuales
- Text rendering inferior a Gemini 3 Pro

### Cuando usar

- Volumen masivo (>1000 imagenes) donde el costo importa
- Thumbnails, variaciones de producto, contenido social basico
- Cuando no necesitas edicion ni imagenes de referencia
- Prototipado rapido (multiples variantes a bajo costo)

---

## 3. Imagen 4 Standard

**ID:** `imagen-4.0-generate-001`
**Estado:** GA (estable)
**Endpoint:** `predict` / `generateImages`
**Familia:** Imagen 4

### Capacidades

- Text-to-image puro
- 1-4 imagenes por request
- Resolucion maxima 2K
- **$0.04/imagen**
- Mayor calidad y detalle que Fast

### Cuando usar

- Cuando necesitas mas calidad que Fast pero no edicion
- Assets de mayor resolucion (2K) sin edicion
- Balance calidad/costo para produccion media

---

## 4. Imagen 4 Ultra

**ID:** `imagen-4.0-ultra-generate-001`
**Estado:** GA (estable)
**Endpoint:** `predict` / `generateImages`
**Familia:** Imagen 4

### Capacidades

- Text-to-image puro
- 1-4 imagenes por request
- Resolucion maxima 2K
- **$0.06/imagen**
- **Maxima calidad** y adherencia al prompt
- Mejor text rendering de la familia Imagen

### Cuando usar

- Cuando necesitas la maxima calidad text-to-image sin edicion
- Assets hero, portadas, piezas premium
- Cuando Gemini 3 Pro no esta disponible y necesitas alta calidad

---

## 5. Modelos excluidos

### Gemini 2.5 Flash Image (`gemini-2.5-flash-image`)

**EXCLUIDO por decision explicita.** Calidad insuficiente para los estandares del proyecto.
GA estable, $0.039/img, 1K max, soporta edicion y multi-turn.
Si se menciona en documentacion externa, NO recomendarlo.

### Gemini 2.0 Flash (`gemini-2.0-flash`)

**EXCLUIDO.** Deprecado con shutdown programado para 31 marzo 2026.
Solo mantenia algo de free tier para imagenes. No usar.

### Gemini 3 Flash (`gemini-3-flash`)

Preview solo-texto al momento de escribir (feb 2026). Sin capacidad de imagen confirmada.

---

## 6. Feature matrix

| Capacidad | Gemini 3 Pro | Imagen 4 Fast | Imagen 4 Standard | Imagen 4 Ultra |
|-----------|:---:|:---:|:---:|:---:|
| Text-to-image | ✅ | ✅ | ✅ | ✅ |
| Edicion conversacional | ✅ | ❌ | ❌ | ❌ |
| Multi-turn | ✅ | ❌ | ❌ | ❌ |
| Imagenes de referencia | Hasta 14 | ❌ | ❌ | ❌ |
| Consistencia personajes | ✅ (superior) | ❌ | ❌ | ❌ |
| Text rendering | **SOTA** | Bueno | Bueno | Mejor |
| Google Search grounding | ✅ | ❌ | ❌ | ❌ |
| Modo Thinking | ✅ | ❌ | ❌ | ❌ |
| Resolucion 4K | ✅ | ❌ | ❌ | ❌ |
| Resolucion 2K | ✅ | ❌ | ✅ | ✅ |
| Multiples imgs/request | ❌ (1) | ✅ (1-4) | ✅ (1-4) | ✅ (1-4) |
| Batch API (50% off) | ✅ | ❌ | ❌ | ❌ |
| Free tier | ❌ | ❌ | ❌ | ❌ |

---

## 7. Decision tree

```
  ¿Que necesitas generar?
       │
       ├── ¿Edicion de imagen existente?
       │   └── SI → Gemini 3 Pro Image (UNICO que soporta edicion)
       │
       ├── ¿Texto legible en la imagen?
       │   └── SI → Gemini 3 Pro Image (mejor text rendering)
       │
       ├── ¿Imagenes de referencia (personas, logos, estilos)?
       │   └── SI → Gemini 3 Pro Image (hasta 14 refs)
       │
       ├── ¿Resolucion 4K?
       │   └── SI → Gemini 3 Pro Image (unico con 4K)
       │
       ├── ¿Multi-turn (refinamiento iterativo)?
       │   └── SI → Gemini 3 Pro Image (unico con multi-turn)
       │
       ├── ¿Volumen masivo (>1000 imgs) sin edicion?
       │   ├── ¿Costo minimo? → Imagen 4 Fast ($0.02)
       │   ├── ¿Mayor calidad? → Imagen 4 Standard ($0.04)
       │   └── ¿Maxima calidad? → Imagen 4 Ultra ($0.06)
       │
       └── Cualquier otra cosa
            └── Gemini 3 Pro Image (default)
```

### Resumen rapido

- **99% de los casos** → Gemini 3 Pro Image
- **Volumen masivo sin edicion** → Imagen 4 Fast
- **Maxima calidad sin edicion** → Imagen 4 Ultra

---

## 8. Pricing comparison

### Costo por imagen

| Modelo | 1K | 2K | 4K | Batch (50%) |
|--------|:---:|:---:|:---:|:---:|
| Imagen 4 Fast | $0.02 | — | — | N/A |
| Imagen 4 Standard | $0.04 | $0.04 | — | N/A |
| Imagen 4 Ultra | $0.06 | $0.06 | — | N/A |
| Gemini 3 Pro | — | $0.134 | $0.24 | $0.067/$0.12 |

### Proyecciones mensuales

| Volumen | Imagen 4 Fast | Imagen 4 Ultra | 3 Pro 2K | 3 Pro 2K Batch |
|---------|:---:|:---:|:---:|:---:|
| 100 imgs | $2 | $6 | $13.40 | $6.70 |
| 1,000 imgs | $20 | $60 | $134 | $67 |
| 10,000 imgs | $200 | $600 | $1,340 | $670 |
| 100,000 imgs | $2,000 | $6,000 | $13,400 | $6,700 |

### Ejemplo real del proyecto

```
10 ad creatives (Gemini 3 Pro, ~1K default):
  ~10 × $0.134 = ~$1.34

9 CTA cards (Gemini 3 Pro, 2K):
  ~9 × $0.134 = ~$1.21

Total 19 imagenes: ~$2.55
```

---

## 9. Migration timeline

| Fecha | Evento |
|-------|--------|
| Feb 2025 | Imagen 3 disponible ($0.03/img) |
| Mar 2025 | Gemini 2.0 Flash con generacion nativa (experimental) |
| May 2025 | Google I/O: Imagen 4 anunciado, Veo 3 |
| Jun 2025 | Imagen 4 Ultra y Standard en paid preview |
| Ago 2025 | **Imagen 4 GA** (Fast/Standard/Ultra). Gemini 2.5 Flash Image preview |
| Oct 2025 | Gemini 2.5 Flash Image → GA estable |
| Nov 2025 | **Gemini 3 Pro Image** lanzado. Imagen 3 descontinuado |
| Dic 2025 | Recorte masivo de rate limits free tier (50-92%) |
| Ene 2026 | 1 billon de imagenes con Nano Banana Pro en 53 dias. Veo 3.1 (4K, vertical) |
| Feb 2026 | Gemini 3.1 Pro Preview (solo texto). Estado actual |
| Mar 2026 | Gemini 2.0 Flash shutdown programado |

### Que cambio para este proyecto

- **Nov 2025:** Adoptamos Gemini 3 Pro Image como modelo principal
- **Feb 2026:** 10 ad creatives + 9 CTA cards generados en produccion
- **Excluimos Flash:** calidad insuficiente para estandares del proyecto
