# Image Editing and Multimodal — Nano Banana Pro Skill

Edicion conversacional, imagenes de referencia, multi-turn, style transfer, composicion.
Solo Gemini 3 Pro Image soporta estas funciones — Imagen 4 NO.

## Table of Contents

- [1. Edicion conversacional](#1-edicion-conversacional)
- [2. Tipos de edicion soportados](#2-tipos-de-edicion-soportados)
- [3. Lo que NO funciona](#3-lo-que-no-funciona)
- [4. Reference images](#4-reference-images)
- [5. Multi-turn chat](#5-multi-turn-chat)
- [6. Style transfer](#6-style-transfer)
- [7. Character consistency](#7-character-consistency)
- [8. Composicion multi-imagen](#8-composicion-multi-imagen)
- [9. Inpainting con mascaras](#9-inpainting-con-mascaras)
- [10. Best practices edicion](#10-best-practices-edicion)

---

## 1. Edicion conversacional

Gemini 3 Pro Image usa **edicion en lenguaje natural**, no mascaras binarias. La diferencia
fundamental vs DALL-E inpainting o Stable Diffusion ControlNet.

### Python con SDK

```python
from PIL import Image
from google import genai
from google.genai import types

client = genai.Client()
image_ref = Image.open("original.jpg")

response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Cambia el fondo por una playa tropical al atardecer. "
        "Manten el sujeto principal exactamente igual.",
        image_ref,
    ],
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
    ),
)

for part in response.parts:
    if part.inline_data is not None:
        part.as_image().save("editado.png")
```

### Node.js con SDK

```typescript
import { GoogleGenAI } from "@google/genai";
import * as fs from "node:fs";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
const imageData = fs.readFileSync("original.jpg").toString("base64");

const response = await ai.models.generateContent({
  model: "gemini-3-pro-image-preview",
  contents: [
    { text: "Cambia el fondo por una playa tropical al atardecer" },
    { inlineData: { mimeType: "image/jpeg", data: imageData } },
  ],
  config: { responseModalities: ["TEXT", "IMAGE"] },
});

for (const part of response.candidates[0].content.parts) {
  if (part.inlineData) {
    fs.writeFileSync("editado.png", Buffer.from(part.inlineData.data, "base64"));
  }
}
```

### REST (sin SDK)

```json
{
  "contents": [
    {
      "parts": [
        {"text": "Cambia el fondo por una playa tropical al atardecer"},
        {
          "inlineData": {
            "mimeType": "image/jpeg",
            "data": "<BASE64_IMAGE_DATA>"
          }
        }
      ]
    }
  ],
  "generationConfig": {
    "responseModalities": ["TEXT", "IMAGE"]
  }
}
```

---

## 2. Tipos de edicion soportados

Todas las ediciones son via instrucciones de texto, sin mascaras:

| Tipo | Ejemplo de prompt |
|------|------------------|
| **Cambio de fondo** | "Cambia el fondo por una playa tropical" |
| **Eliminacion de objetos** | "Elimina la persona de la izquierda" |
| **Modificacion de estilo** | "Convierte esta foto en una acuarela" |
| **Cambio de color** | "Cambia el sofa a azul marino" |
| **Ajuste de iluminacion** | "Haz la iluminacion mas calida, como golden hour" |
| **Desenfoque de fondo** | "Aplica bokeh al fondo" |
| **Colorizacion** | "Coloriza esta foto en blanco y negro" |
| **Cambio de pose** | "Haz que la persona mire hacia la camara" |
| **Eliminacion de manchas** | "Elimina las manchas del vestido" |
| **Transfer de estilo** | "Aplica el estilo de este cuadro a esta foto" (con 2 refs) |
| **Composicion multi-imagen** | "Combina estas dos fotos: pon a esta persona en este escenario" |
| **Cambio de texto** | "Cambia el titulo a 'NUEVO EVENTO 2026'" |
| **Cambio de formato** | "Adapta esta imagen horizontal a formato vertical 9:16" |
| **Mejora de calidad** | "Mejora la nitidez y el contraste de esta imagen" |

---

## 3. Lo que NO funciona

| Limitacion | Detalle |
|-----------|---------|
| Precision pixel-perfect | El modelo aproxima, no edita con precision exacta |
| Areas muy pequenas | Cambios en areas minusculas pueden alterar otras partes |
| Logos/branding repetido | Iteraciones repetidas de logos pierden contexto |
| Sobre-edicion | El modelo a veces cambia mas de lo pedido |
| Iteration drift | Despues de muchas ediciones, pierde contexto del diseno original |
| Inpainting con mascaras | Gemini nativo NO soporta mascaras binarias |
| Texto pixel-perfect | El texto generado es aproximado, no tiene precision tipografica |

---

## 4. Reference images

Gemini 3 Pro Image acepta hasta **14 imagenes de referencia** — mas que cualquier otro modelo.

### Una imagen de referencia

```python
from PIL import Image

ref = Image.open("referencia.png")
response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Genera una variante de esta imagen adaptada a formato vertical 9:16. "
        "Mantener el mismo estilo visual y paleta de colores.",
        ref,
    ],
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(aspect_ratio="9:16"),
    ),
)
```

### Multiples imagenes de referencia

```python
response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Foto grupal de estas personas en un evento corporativo, "
        "sonriendo, vestimenta formal, fondo de salon elegante",
        Image.open("persona1.png"),
        Image.open("persona2.png"),
        Image.open("persona3.png"),
        Image.open("persona4.png"),
    ],
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(aspect_ratio="16:9", image_size="2K"),
    ),
)
```

### REST con multiples refs

```json
{
  "contents": [{
    "parts": [
      {"inlineData": {"mimeType": "image/png", "data": "<REF1>"}},
      {"inlineData": {"mimeType": "image/png", "data": "<REF2>"}},
      {"inlineData": {"mimeType": "image/png", "data": "<REF3>"}},
      {"text": "Combina el estilo de las primeras dos con la composicion de la tercera"}
    ]
  }],
  "generationConfig": {"responseModalities": ["TEXT", "IMAGE"]},
  "imageConfig": {"aspectRatio": "16:9", "imageSize": "2K"}
}
```

### Limites de referencia

| Modelo | Max refs |
|--------|---------|
| Gemini 3 Pro Image | 14 |
| Imagen 4 (todos) | 0 (no soporta) |

> Formatos soportados: JPEG, PNG, WebP, GIF, HEIC, HEIF. Max 20MB inline.

---

## 5. Multi-turn chat

Edicion iterativa preservando contexto visual entre turnos.

### Python con SDK

```python
chat = client.chats.create(
    model="gemini-3-pro-image-preview",
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(
            aspect_ratio="1:1",
            image_size="2K",
        ),
    ),
)

# Turno 1: Generar
response = chat.send_message(
    "Crea un poster profesional para un festival de musica llamado 'SOLSTICE 2026'"
)
for part in response.parts:
    if part.inline_data:
        part.as_image().save("poster_v1.png")

# Turno 2: Editar colores
response = chat.send_message(
    "Cambia la paleta de colores a tonos sunset (naranja, rosa, purpura). "
    "Mantener el diseno y texto."
)
for part in response.parts:
    if part.inline_data:
        part.as_image().save("poster_v2.png")

# Turno 3: Agregar texto
response = chat.send_message(
    "Agrega '21-23 JUNIO | PARQUE CENTRAL' en la parte inferior "
    "en fuente sans-serif blanca"
)
for part in response.parts:
    if part.inline_data:
        part.as_image().save("poster_v3.png")
```

### Node.js con SDK

```typescript
const chat = ai.chats.create({
  model: "gemini-3-pro-image-preview",
  config: {
    responseModalities: ["TEXT", "IMAGE"],
    imageConfig: { aspectRatio: "1:1", imageSize: "2K" },
  },
});

let response = await chat.sendMessage({
  message: "Crea un logo minimalista para una cafeteria llamada 'AROMA'",
});
saveImage(response, "logo_v1.png");

response = await chat.sendMessage({
  message: "Hazlo en tonos verde oscuro y crema",
});
saveImage(response, "logo_v2.png");
```

### Buenas practicas multi-turn

1. **1 instruccion por turno** — mejor que multiples cambios simultaneos
2. **Especificar que NO cambiar** — "Cambia el fondo. No modifiques el texto ni el sujeto"
3. **Guardar cada version** — si hay drift, puedes volver a una version anterior
4. **Max ~5-7 turnos** — despues de muchos turnos, el contexto se degrada
5. **Reiniciar si hay drift** — crear nuevo chat con descripcion detallada

---

## 6. Style transfer

Transferir el estilo de una imagen a otra usando multiples referencias.

### Patron basico

```python
style_ref = Image.open("estilo_artdeco.png")
content_ref = Image.open("foto_producto.jpg")

response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Aplica el estilo artistico de la Imagen A a la Imagen B. "
        "Mantener la composicion y sujeto de la Imagen B, "
        "pero con los colores, texturas y estetica de la Imagen A.",
        style_ref,   # Imagen A (estilo)
        content_ref,  # Imagen B (contenido)
    ],
    config=types.GenerateContentConfig(response_modalities=["TEXT", "IMAGE"]),
)
```

### Especificar roles de cada referencia

```python
response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Usa la Imagen 1 como referencia de POSE y composicion. "
        "Usa la Imagen 2 como referencia de ESTILO artistico y paleta de colores. "
        "Genera una nueva imagen combinando ambas.",
        Image.open("pose_ref.jpg"),    # Imagen 1
        Image.open("style_ref.jpg"),   # Imagen 2
    ],
    config=types.GenerateContentConfig(response_modalities=["TEXT", "IMAGE"]),
)
```

---

## 7. Character consistency

Mantener la apariencia de un personaje consistente entre generaciones.

### Estrategia 1: Multi-turn chat

```python
chat = client.chats.create(
    model="gemini-3-pro-image-preview",
    config=types.GenerateContentConfig(response_modalities=["TEXT", "IMAGE"]),
)

# Establecer personaje con detalle
response = chat.send_message(
    "Un sprite de hongo bioluminiscente con ojos curiosos grandes, "
    "cuerpo de enredaderas tejidas, gorro de hongo brillante azul-verde, "
    "pequeno (30cm), expresion amigable"
)

# Generaciones posteriores mantienen consistencia
response = chat.send_message("Muestra al mismo personaje caminando en un bosque")
response = chat.send_message("Ahora el mismo personaje descansando junto a un rio")
```

### Estrategia 2: Style Sheet reutilizable

Documentar colores hex, terminos de iluminacion, tipo de lente, y reutilizar como sufijo:

```python
STYLE_SHEET = """
PERSONAJE: Mujer de 30 anos, cabello rizado castano, ojos verdes,
vestido con blazer azul marino y camisa blanca.
ESTILO: Fotografia editorial, lente 85mm, f/2.8, luz natural suave.
PALETA: #1A365D (azul), #FFFFFF (blanco), #F5E6D3 (piel calida).
"""

prompt = f"El personaje descrito aqui entrando a una oficina moderna. {STYLE_SHEET}"
```

### Estrategia 3: Imagen de referencia directa

```python
# Usar una foto/render del personaje como referencia en cada generacion
character_ref = Image.open("personaje_base.png")

response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Genera una imagen de esta misma persona en un ambiente diferente: "
        "sentada en un cafe parisino. Mantener exactamente la misma apariencia.",
        character_ref,
    ],
    config=types.GenerateContentConfig(response_modalities=["TEXT", "IMAGE"]),
)
```

---

## 8. Composicion multi-imagen

Combinar multiples personas/objetos de referencia en una escena.

### Ejemplo: foto grupal

```python
response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Crea una foto grupal profesional de estas 4 personas reunidas "
        "en una sala de conferencias moderna. Estan de pie, sonriendo, "
        "vestimenta business casual. Fondo: ventanales con vista a ciudad.",
        Image.open("persona1.png"),
        Image.open("persona2.png"),
        Image.open("persona3.png"),
        Image.open("persona4.png"),
    ],
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(aspect_ratio="16:9", image_size="2K"),
    ),
)
```

### Ejemplo: producto en escena

```python
response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Coloca este producto en un ambiente de cocina moderna y luminosa. "
        "El producto debe ser el elemento central, sobre una encimera de marmol. "
        "Iluminacion natural desde la ventana, estilo editorial de lifestyle.",
        Image.open("producto.png"),
    ],
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(aspect_ratio="1:1"),
    ),
)
```

---

## 9. Inpainting con mascaras

**Gemini nativo NO soporta mascaras binarias.** Solo edicion en lenguaje natural.

Para inpainting con mascaras, las opciones son:
1. **Vertex AI** (Imagen en Vertex historicamente soportaba mascaras)
2. **Gemini nativo** — usar instrucciones de texto especificas: "Elimina el objeto en la esquina superior izquierda"
3. **Herramientas externas** — Stable Diffusion ControlNet, DALL-E inpainting

> La mayoria de los casos de uso se resuelven con edicion conversacional.
> Solo para precision pixel-perfect se necesitan mascaras.

---

## 10. Best practices edicion

1. **Ser especifico y directo**
   - ✅ "Cambia el color del coche de rojo a azul"
   - ❌ "Cambia algo del coche"

2. **Una instruccion por turno**
   - ✅ Turno 1: "Cambia el fondo" → Turno 2: "Cambia el color del texto"
   - ❌ "Cambia el fondo, el color del texto, y agrega un logo"

3. **Especificar que NO cambiar**
   - ✅ "Cambia el fondo. No modifiques el sujeto principal ni el texto"
   - ❌ "Cambia el fondo" (puede alterar otras partes)

4. **Mantener la conversacion (multi-turn)**
   - El contexto del chat preserva la imagen, evitando regeneracion completa
   - Mas eficiente que enviar la imagen como referencia cada vez

5. **Recortar antes de editar**
   - Para ediciones locales, enviar un crop del area reduce falsos positivos del filtro
   - Luego recomponer la imagen final

6. **Reiniciar si hay drift**
   - Despues de 5-7 ediciones, el modelo pierde contexto
   - Mejor: guardar la mejor version y empezar nuevo chat con ella como referencia

7. **Usar framing afirmativo**
   - ✅ "Imagen limpia sin texto ni bordes"
   - ❌ "No pongas texto" (Gemini no tiene negative prompts)
