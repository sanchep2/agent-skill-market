# Image Generation — Nano Banana Pro Skill

Generacion de imagenes: text-to-image, aspect ratios, resoluciones, multi-formato para ads.
Todo verificado en produccion con 19 imagenes generadas (feb 2026).

## Table of Contents

- [1. Text-to-image basico](#1-text-to-image-basico)
- [2. Aspect ratios](#2-aspect-ratios)
- [3. Resoluciones (imageSize)](#3-resoluciones-imagesize)
- [4. Imagen 4 multi-image](#4-imagen-4-multi-image)
- [5. Formatos de entrada](#5-formatos-de-entrada)
- [6. Formato de salida](#6-formato-de-salida)
- [7. Tokens por imagen](#7-tokens-por-imagen)
- [8. Multi-formato para ads](#8-multi-formato-para-ads)
- [9. Mapeo plataforma → aspect ratio](#9-mapeo-plataforma--aspect-ratio)
- [10. Produccion real: ad creatives](#10-produccion-real-ad-creatives)
- [11. Produccion real: CTA cards](#11-produccion-real-cta-cards)
- [12. Resize y crop post-generacion](#12-resize-y-crop-post-generacion)

---

## 1. Text-to-image basico

### Python con SDK

```python
from google import genai
from google.genai import types

client = genai.Client()  # Lee GEMINI_API_KEY del entorno

response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=["Poster profesional para evento de trading, fondo oscuro, acentos dorados"],
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(
            aspect_ratio="16:9",
            image_size="2K",
        ),
    ),
)

for part in response.parts:
    if part.inline_data is not None:
        img = part.as_image()  # PIL.Image
        img.save("output.png")
```

### Node.js con SDK

```typescript
import { GoogleGenAI } from "@google/genai";
import * as fs from "node:fs";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const response = await ai.models.generateContent({
  model: "gemini-3-pro-image-preview",
  contents: "Poster profesional para evento de trading",
  config: {
    responseModalities: ["TEXT", "IMAGE"],
    imageConfig: { aspectRatio: "16:9", imageSize: "2K" },
  },
});

for (const part of response.candidates[0].content.parts) {
  if (part.inlineData) {
    fs.writeFileSync("output.png", Buffer.from(part.inlineData.data, "base64"));
  }
}
```

### REST directo (sin SDK)

```python
import requests, base64, os
from PIL import Image
from io import BytesIO

GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]
MODEL = "gemini-3-pro-image-preview"
URL = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={GEMINI_API_KEY}"

payload = {
    "contents": [{"parts": [{"text": "Un gato astronauta en el espacio"}]}],
    "generationConfig": {
        "responseModalities": ["TEXT", "IMAGE"],
        "imageConfig": {"aspectRatio": "1:1", "imageSize": "2K"}
    }
}

resp = requests.post(URL, json=payload, headers={"Content-Type": "application/json"}, timeout=120)
data = resp.json()

for part in data["candidates"][0]["content"]["parts"]:
    if "inlineData" in part:
        img_bytes = base64.b64decode(part["inlineData"]["data"])
        img = Image.open(BytesIO(img_bytes))
        img.save("output.png")
```

---

## 2. Aspect ratios

### Gemini nativo — 10 ratios disponibles

| Ratio | Orientacion | Uso principal |
|-------|------------|---------------|
| `"1:1"` | Cuadrado | Instagram, Facebook, X, carrusel |
| `"2:3"` | Retrato | Pinterest |
| `"3:2"` | Paisaje ligero | — |
| `"3:4"` | Retrato | — |
| `"4:3"` | Paisaje | — |
| `"4:5"` | Retrato | **Instagram Feed** (1080x1350) |
| `"5:4"` | Paisaje ligero | — |
| `"9:16"` | Vertical | **Stories, Reels, TikTok** |
| `"16:9"` | Horizontal | **YouTube, LinkedIn, Facebook, X** |
| `"21:9"` | Ultrawide | Banner |

### Imagen 4 — solo 5 ratios

| Ratio | Orientacion |
|-------|------------|
| `"1:1"` | Cuadrado |
| `"3:4"` | Retrato |
| `"4:3"` | Paisaje |
| `"9:16"` | Vertical |
| `"16:9"` | Horizontal |

> Imagen 4 no soporta `"4:5"` (Instagram Feed), `"2:3"` (Pinterest), ni `"21:9"` (ultrawide).
> Para esos formatos, usar Gemini 3 Pro.

### Mapeo de ratios no-nativos

Cuando la plataforma pide un ratio que la API no soporta:

| Ratio deseado | Ratio API mas cercano | Post-procesamiento |
|---------------|----------------------|-------------------|
| 1.91:1 (1200x628) | `"16:9"` | Crop a 1200x628 |
| 1200x300 (logo horizontal) | `"21:9"` | Resize |

---

## 3. Resoluciones (imageSize)

| Valor | Resolucion aprox. | Modelos | Costo Gemini 3 Pro |
|-------|-------------------|---------|-------------------|
| `"1K"` | ~1024x1024 | Todos | — |
| `"2K"` | ~2048x2048 | 3 Pro, Imagen Standard/Ultra | ~$0.134 |
| `"4K"` | ~4096x4096 | Solo 3 Pro | ~$0.24 |

### Cuando usar cada resolucion

```
  ¿Para que es la imagen?
       │
       ├── Redes sociales (1080p) → "1K" suficiente
       │
       ├── YouTube pre-roll (1920x1080) → "2K" recomendado
       │
       ├── Impresion / display 4K → "4K"
       │
       └── Video ads (composicion Remotion) → "2K" recomendado
```

> **La K debe ser MAYUSCULA.** `"2k"` NO funciona.
> No usar 4K innecesariamente — hasta **12x mas caro** que 1K.

### Dimensiones exactas por combinacion

| Ratio | 1K | 2K | 4K |
|-------|:--:|:--:|:--:|
| 1:1 | ~1024x1024 | ~2048x2048 | ~4096x4096 |
| 16:9 | ~1024x576 | ~2048x1152 | ~4096x2304 |
| 9:16 | ~576x1024 | ~1152x2048 | ~2304x4096 |
| 4:5 | ~896x1120 | ~1792x2240 | ~3584x4480 |

> Las dimensiones son aproximadas. Para dimensiones exactas, usar resize post-generacion.

---

## 4. Imagen 4 multi-image

Imagen 4 puede generar 1-4 imagenes en un solo request con `sampleCount`:

```python
response = client.models.generate_images(
    model="imagen-4.0-fast-generate-001",
    prompt="Product photo of wireless headphones, dramatic studio lighting",
    config=types.GenerateImagesConfig(
        number_of_images=4,
        aspect_ratio="1:1",
        person_generation="allow_adult",
        safety_filter_level="block_only_high",
    ),
)

for i, img in enumerate(response.generated_images):
    img.image.save(f"variante_{i}.png")
```

> Solo disponible en Imagen 4 (Fast, Standard, Ultra).
> Gemini 3 Pro genera 1 imagen por response.

---

## 5. Formatos de entrada

### Imagenes de referencia (input)

| Formato | MIME Type | Soportado |
|---------|-----------|-----------|
| JPEG | `image/jpeg` | ✅ |
| PNG | `image/png` | ✅ |
| WebP | `image/webp` | ✅ |
| GIF | `image/gif` | ✅ |
| HEIC | `image/heic` | ✅ |
| HEIF | `image/heif` | ✅ |

### Limites

- **Max inline:** 20 MB por imagen
- **Max ref images:** 14 (Gemini 3 Pro)
- **Files API:** Para archivos >20MB, usar `client.files.upload()`

### Como enviar imagenes de referencia (REST)

```python
import base64

def image_to_base64(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")

parts = [
    {"inlineData": {
        "mimeType": "image/png",
        "data": image_to_base64("referencia.png")
    }},
    {"text": "Genera una variante de esta imagen con fondo azul"}
]
```

### Como enviar imagenes de referencia (SDK Python)

```python
from PIL import Image

ref = Image.open("referencia.png")
response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=["Genera una variante con fondo azul", ref],
    config=types.GenerateContentConfig(response_modalities=["TEXT", "IMAGE"]),
)
```

---

## 6. Formato de salida

- **Siempre PNG** (`image/png`)
- **Base64** en `inlineData.data`
- **SynthID watermark** invisible en todas las imagenes (no se puede desactivar)
- **1 imagen por response** en Gemini nativo
- **1-4 imagenes por response** en Imagen 4

### Extraccion

```python
# SDK Python
for part in response.parts:
    if part.inline_data is not None:
        img = part.as_image()  # PIL.Image
        img.save("output.png")

# REST Python
import base64
for part in data["candidates"][0]["content"]["parts"]:
    if "inlineData" in part:
        img_bytes = base64.b64decode(part["inlineData"]["data"])
        with open("output.png", "wb") as f:
            f.write(img_bytes)
```

---

## 7. Tokens por imagen

Cada imagen generada consume exactamente **1290 tokens de salida**.

### Impacto en quota

- Con `maxOutputTokens=8192`, puedes generar ~6 imagenes en secuencia antes de alcanzar el limite
- En la practica, como Gemini genera 1 imagen por response, no es un problema
- Monitorear `usageMetadata.candidatesTokenCount` en la respuesta

---

## 8. Multi-formato para ads

Patron verificado: 1 prompt base → multiples aspect ratios para diferentes plataformas.

### Flujo

```
  1 Prompt base (variante A o B)
       │
       ├── aspect_ratio="16:9" → Landscape (YouTube, LinkedIn, X, FB)
       │   └── Resize: 1200x628 (FB/LinkedIn), 1920x1080 (YouTube)
       │
       ├── aspect_ratio="1:1"  → Square (IG, FB, X)
       │   └── Resize: 1200x1200 (FB), 1080x1080 (IG)
       │
       ├── aspect_ratio="4:5"  → Portrait (IG Feed, FB Feed)
       │   └── Resize: 960x1200, 1080x1350
       │
       └── aspect_ratio="9:16" → Vertical (Stories, Reels, TikTok)
            └── Resize: 1080x1920
```

### Codigo de produccion (simplificado)

```python
FORMATS = [
    {"name": "landscape", "ratio": "16:9", "width": 1200, "height": 628},
    {"name": "square",    "ratio": "1:1",  "width": 1200, "height": 1200},
    {"name": "portrait",  "ratio": "4:5",  "width": 960,  "height": 1200},
    {"name": "stories",   "ratio": "9:16", "width": 1080, "height": 1920},
]

base_prompt = "Premium curso online premium ad..."

for fmt in FORMATS:
    img = generate_image(
        prompt=base_prompt + f"\nLAYOUT: {fmt['name'].upper()} format.",
        aspect_ratio=fmt["ratio"],
    )
    if img:
        img = resize_and_crop(img, fmt["width"], fmt["height"])
        img.save(f"creative-{fmt['name']}.png")
    time.sleep(2)  # Evitar rate limiting
```

---

## 9. Mapeo plataforma → aspect ratio

| Plataforma | Formato | Dimensiones | Aspect ratio API |
|------------|---------|-------------|-----------------|
| Instagram Feed (cuadrado) | 1080x1080 | `"1:1"` |
| Instagram Feed (retrato) | 1080x1350 | `"4:5"` |
| Instagram Stories/Reels | 1080x1920 | `"9:16"` |
| Facebook Post | 1200x630 | `"16:9"` (cercano) |
| Facebook Stories | 1080x1920 | `"9:16"` |
| LinkedIn Post | 1200x627 | `"16:9"` |
| X/Twitter Post | 1200x1200 | `"1:1"` |
| YouTube Thumbnail | 1280x720 | `"16:9"` |
| TikTok Cover | 1080x1920 | `"9:16"` |
| Pinterest Pin | 1000x1500 | `"2:3"` |
| Google Demand Gen (landscape) | 1200x628 | `"16:9"` → crop |
| Google Demand Gen (square) | 1200x1200 | `"1:1"` |
| Google Demand Gen (logo) | 1200x300 | Sin IA (composicion manual) |
| Banner ultrawide | — | `"21:9"` |

> Para 1200x628 (Facebook/Google), generar con `"16:9"` y hacer crop a 1200x628 despues.

---

## 10. Produccion real: ad creatives

Extraido de `scripts/generate-ad-creatives.py` — 10 imagenes generadas exitosamente.

### Configuracion usada

```python
GEMINI_MODEL = "gemini-3-pro-image-preview"
# Sin imageSize (default ~1K)
# Con imagenes de referencia (foto de Jaime Merino para variante A)
```

### Assets generados

| Asset | Ratio | Dimensiones | Referencia |
|-------|-------|-------------|------------|
| A1-landscape-1200x628 | 16:9 | 1200x628 | Foto persona |
| A2-square-1200x1200 | 1:1 | 1200x1200 | Foto persona |
| A3-portrait-960x1200 | 4:5 | 960x1200 | Foto persona |
| A4-meta-feed-1080x1350 | 4:5 | 1080x1350 | Foto persona |
| A5-stories-1080x1920 | 9:16 | 1080x1920 | Foto persona |
| B1-landscape-1200x628 | 16:9 | 1200x628 | Sin persona |
| B2-square-1200x1200 | 1:1 | 1200x1200 | Sin persona |
| B3-portrait-960x1200 | 4:5 | 960x1200 | Sin persona |
| B4-meta-feed-1080x1350 | 4:5 | 1080x1350 | Sin persona |
| B5-stories-1080x1920 | 9:16 | 1080x1920 | Sin persona |

### Patrones clave del script de produccion

1. **Brand styling en prompt**: Colores hex, tipografia, regla del 20% texto
2. **Layout hints por formato**: "HORIZONTAL/LANDSCAPE format. Person on the LEFT side (30%)"
3. **Skip si ya existe**: `if os.path.exists(output_path): continue`
4. **Rate limiting**: `time.sleep(2)` entre generaciones
5. **Retry**: 3 intentos con backoff en 429

---

## 11. Produccion real: CTA cards

Extraido de `scripts/generate-video-cta-cards.py` — 9 imagenes generadas exitosamente.

### Configuracion usada

```python
GEMINI_MODEL = "gemini-3-pro-image-preview"
# Con imageSize: "2K" (mayor calidad para video ads)
# Con imagenes de referencia: 3 creatives de campana + logo
```

### Assets generados

| Asset | Ratio | Dimensiones | Variante |
|-------|-------|-------------|----------|
| cta-landscape-main | 16:9 | 1920x1080 | CURSO ONLINE GRATIS |
| cta-vertical-main | 9:16 | 1080x1920 | CURSO ONLINE GRATIS |
| cta-square-main | 1:1 | 1080x1080 | CURSO ONLINE GRATIS |
| cta-landscape-registrate | 16:9 | 1920x1080 | REGISTRATE GRATIS |
| cta-vertical-registrate | 9:16 | 1080x1920 | REGISTRATE GRATIS |
| cta-square-registrate | 1:1 | 1080x1080 | REGISTRATE GRATIS |
| cta-landscape-empieza | 16:9 | 1920x1080 | EMPIEZA GRATIS |
| cta-vertical-empieza | 9:16 | 1080x1920 | EMPIEZA GRATIS |
| cta-square-empieza | 1:1 | 1080x1080 | EMPIEZA GRATIS |

### Patrones clave

1. **Style matching via referencia**: Se pasaron creatives existentes como referencia para mantener consistencia visual
2. **Variantes de texto**: Mismo layout base con diferentes CTAs
3. **imageSize "2K"**: Mayor calidad porque son end-cards de video
4. **Safe zones en vertical**: "Leave safe zones (top 150px, bottom 440px clear of critical content)"

---

## 12. Resize y crop post-generacion

La API genera imagenes en resoluciones aproximadas. Para dimensiones exactas, usar resize:

### Resize y crop centrado (Python)

```python
from PIL import Image

def resize_and_crop(img, target_w, target_h):
    """Redimensiona y recorta imagen al tamano exacto."""
    src_w, src_h = img.size
    target_ratio = target_w / target_h
    src_ratio = src_w / src_h

    if src_ratio > target_ratio:
        # Imagen mas ancha: escalar por alto, recortar lados
        new_h = target_h
        new_w = int(src_w * (target_h / src_h))
    else:
        # Imagen mas alta: escalar por ancho, recortar arriba/abajo
        new_w = target_w
        new_h = int(src_h * (target_w / src_w))

    img = img.resize((new_w, new_h), Image.LANCZOS)

    # Recortar centro
    left = (new_w - target_w) // 2
    top = (new_h - target_h) // 2
    img = img.crop((left, top, left + target_w, top + target_h))

    return img
```

### Resize simple (sin crop)

```python
def resize_simple(img, width, height):
    """Redimensiona imagen (puede distorsionar)."""
    return img.resize((width, height), Image.LANCZOS)
```

> Preferir `resize_and_crop` para mantener aspect ratio.
> El script de produccion usa este patron para todos los assets.
