# Limitations and Error Handling — Nano Banana Pro Skill

Filtros de seguridad, SynthID, rate limits, retry patterns, workarounds, comparacion con alternativas.

## Table of Contents

- [1. Filtros PROHIBITED_CONTENT](#1-filtros-prohibited_content)
- [2. SynthID watermark](#2-synthid-watermark)
- [3. 1 imagen por response](#3-1-imagen-por-response)
- [4. Over-editing](#4-over-editing)
- [5. Iteration drift](#5-iteration-drift)
- [6. 503 model overloaded](#6-503-model-overloaded)
- [7. Rate limits](#7-rate-limits)
- [8. Formatos soportados](#8-formatos-soportados)
- [9. SDK deprecation](#9-sdk-deprecation)
- [10. Gemini 2.0 Flash shutdown](#10-gemini-20-flash-shutdown)
- [11. Retry pattern completo](#11-retry-pattern-completo)
- [12. Circuit breaker](#12-circuit-breaker)
- [13. Comparacion con alternativas](#13-comparacion-con-alternativas)

---

## 1. Filtros PROHIBITED_CONTENT

El **problema #1** de la API. Filtro a nivel de modelo que **NO se puede desactivar**.

### Sintomas

- `finishReason: "SAFETY"` o `finishReason: "IMAGE_SAFETY"`
- Response sin `candidates`
- Error message con "PROHIBITED_CONTENT"
- Prompts completamente inocuos rechazados (~30% de prompts de ads SaaS)

### Lo que NO funciona

- Ajustar `safetySettings` a `BLOCK_NONE` — NO desactiva PROHIBITED_CONTENT
- Usar Vertex AI en vez de Gemini API — mismo filtro
- Usar modelos diferentes — todos tienen el filtro

### Workarounds verificados

1. **Reintentar** — el filtro es inconsistente; el mismo prompt puede funcionar en segundo intento
2. **Reformular ligeramente** — cambiar una palabra puede desbloquear
3. **Descripciones genericas** — "dibujo 2D de un ninja" en vez de nombres de franquicias
4. **Mas especificidad** — "golden retriever jugando en parque" en vez de "un perro"
5. **Recortar imagenes** — enviar crop del area a editar reduce falsos positivos
6. **Evitar palabras gatillo** — "hack", "exploit", "manipulate", "circumvent", "bypass"
7. **Dividir ediciones** — multiples pasos simples en vez de una edicion compleja
8. **Framing afirmativo** — "imagen limpia sin personas" en vez de "no people"

### Patron de retry con reformulacion

```python
REFORMULATIONS = [
    lambda p: p,                                    # Intento original
    lambda p: f"Professional photo: {p}",           # Agregar contexto
    lambda p: p.replace("crypto", "digital finance"),  # Suavizar terminos
    lambda p: f"Stock photography style. {p}",      # Contexto editorial
]

def generate_with_reformulation(client, prompt, max_attempts=4):
    for i, reformulate in enumerate(REFORMULATIONS[:max_attempts]):
        modified = reformulate(prompt)
        result = generate_with_retry(client, modified, max_retries=2)
        if result.get("success"):
            return result
        if result.get("error") not in ("safety_filtered", "content_filtered"):
            return result  # Error no relacionado con filtros
    return {"error": "all_reformulations_failed"}
```

---

## 2. SynthID watermark

- **Invisible** — no afecta la calidad visual
- **En TODAS las imagenes** generadas por Gemini e Imagen
- **NO se puede desactivar** — es obligatorio por politica de Google
- Detectable con herramientas de Google (pero no visible a simple vista)
- Sobrevive algunos recortes y redimensionados
- No afecta uso comercial ni publicidad

> No intentar removerlo. Es invisible y no afecta el uso practico.

---

## 3. 1 imagen por response

`generateContent` retorna maximo 1 imagen por llamada.

### Solucion: multiples llamadas

```python
# Para 4 variantes de la misma imagen:
for i in range(4):
    img = generate_image(prompt)
    if img:
        img.save(f"variante_{i}.png")
    time.sleep(2)  # Evitar rate limits
```

### Solucion: Imagen 4 con sampleCount

```python
# Imagen 4 si genera multiples (1-4) por request:
response = client.models.generate_images(
    model="imagen-4.0-fast-generate-001",
    prompt=prompt,
    config=types.GenerateImagesConfig(number_of_images=4),
)
```

### Solucion: Batch API

```python
# Para muchas imagenes distintas:
batch = client.batches.create(
    model="gemini-3-pro-image-preview",
    src=[{"contents": p} for p in prompts],
)
```

---

## 4. Over-editing

El modelo a veces cambia mas de lo pedido en ediciones.

### Sintomas

- Cambiar el fondo tambien altera el sujeto
- Cambiar un color afecta toda la paleta
- Agregar texto mueve otros elementos

### Workarounds

1. **Ser MUY especifico sobre que NO cambiar**
   ```
   "Cambia SOLO el fondo por playa. NO modifiques: el sujeto, la ropa,
    la posicion, los colores del texto, ni ningun otro elemento."
   ```

2. **1 instruccion por turno** (multi-turn)
   ```
   Turno 1: "Cambia el fondo"
   Turno 2: "Cambia el color del titulo"
   Turno 3: "Agrega fecha"
   ```

3. **Recortar area de edicion**
   - Crop solo la zona a editar
   - Editar el crop
   - Recomponer en la imagen original

---

## 5. Iteration drift

Despues de muchas ediciones (~5-7 turnos), el modelo pierde contexto del diseno original.

### Sintomas

- Estilo visual cambia gradualmente
- Texto se distorsiona
- Colores divergen del original
- Layout se reorganiza sin pedirlo

### Workarounds

1. **Guardar cada version** — para poder volver atras
2. **Limitar a 5 turnos** por conversacion
3. **Reiniciar con referencia** — nuevo chat pasando la mejor version como imagen de referencia
4. **Style Sheet detallado** — repetir colores hex y reglas de diseno en cada prompt

---

## 6. 503 model overloaded

Gemini 3 Pro Image experimenta "model overloaded" frecuentemente en horas pico.

### Retry con exponential backoff

```python
import time
import random

def retry_on_503(func, max_retries=5):
    for attempt in range(max_retries):
        try:
            return func()
        except Exception as e:
            code = getattr(e, "code", getattr(e, "status_code", 0))
            if code == 503:
                delay = (2 ** attempt) + random.uniform(0, 1)
                print(f"503 overloaded, retry en {delay:.1f}s (intento {attempt + 1})")
                time.sleep(delay)
            else:
                raise
    raise Exception(f"Fallo tras {max_retries} intentos con 503")
```

### Horas pico tipicas

- Horas pico: 10:00-18:00 PST (horario laboral EEUU)
- Mejor momento: 00:00-06:00 PST (madrugada EEUU)
- Batch API evita este problema (procesamiento diferido)

---

## 7. Rate limits

### Limites por tier (post-diciembre 2025)

| Dimension | Free tier | Tier 1 (billing activo) | Tier 2+ |
|-----------|:---------:|:-----------------------:|:-------:|
| RPM | 5-15 | 150-300 | Mayor |
| RPD | 20-100 | 10,000 | Sin limite |
| IPM (imagenes/min) | **0** | ~10 | ~20+ |
| TPM | 250,000 | 1,000,000 | 4,000,000 |

### Dato critico

> Desde diciembre 2025, el free tier tiene **0 IPM para modelos de imagen**.
> Se necesita billing activo para generar imagenes con Gemini 3 Pro o Imagen 4.

### Manejo de 429

```python
if resp.status_code == 429:
    # Extraer Retry-After si existe
    retry_after = int(resp.headers.get("Retry-After", 0))
    delay = max(retry_after, 15 * (attempt + 1))
    print(f"Rate limited, esperando {delay}s...")
    time.sleep(delay)
```

### Estrategias para no exceder limites

1. `time.sleep(2-5)` entre generaciones secuenciales
2. `asyncio.Semaphore(3)` para concurrencia controlada
3. Batch API para volumen (sin rate limits IPM)
4. Cache local para evitar regenerar imagenes identicas

---

## 8. Formatos soportados

### Input

| Formato | MIME Type | Soportado |
|---------|-----------|-----------|
| JPEG | `image/jpeg` | ✅ |
| PNG | `image/png` | ✅ |
| WebP | `image/webp` | ✅ |
| GIF | `image/gif` | ✅ |
| HEIC | `image/heic` | ✅ |
| HEIF | `image/heif` | ✅ |
| SVG | — | ❌ |
| TIFF | — | ❌ |
| BMP | — | ❌ |

- Max inline: 20 MB
- Para archivos mayores: `client.files.upload()`
- Max imagenes de referencia: 14 (Gemini 3 Pro)

### Output

- **Siempre PNG** (`image/png`)
- No configurable en Gemini nativo
- Imagen SDK en Firebase permite JPEG con calidad ajustable

---

## 9. SDK deprecation

### Python

| Paquete | Estado | Accion |
|---------|--------|--------|
| `google-genai` | **ACTUAL** | ✅ Usar este |
| `google-generativeai` | **DEPRECADO** (Nov 2025) | ❌ Migrar |

```bash
# Migrar:
pip uninstall google-generativeai
pip install google-genai
```

### Node.js

| Paquete | Estado | Accion |
|---------|--------|--------|
| `@google/genai` | **ACTUAL** | ✅ Usar este |
| `@google/generative-ai` | **DEPRECADO** (Ago 2025) | ❌ Migrar |

```bash
# Migrar:
npm uninstall @google/generative-ai
npm install @google/genai
```

### Diferencias principales en el import

```python
# Viejo (NO usar)
import google.generativeai as genai
genai.configure(api_key="...")
model = genai.GenerativeModel("gemini-...")
response = model.generate_content(...)

# Nuevo (USAR)
from google import genai
client = genai.Client()
response = client.models.generate_content(model="gemini-...", ...)
```

---

## 10. Gemini 2.0 Flash shutdown

**Fecha:** 31 marzo 2026
**Impacto:** `gemini-2.0-flash` dejara de funcionar

> Este skill no usa 2.0 Flash. Solo se menciona como referencia historica.
> Si encuentras codigo con `gemini-2.0-flash`, migrar a `gemini-3-pro-image-preview`.

---

## 11. Retry pattern completo

Patron robusto con exponential backoff + jitter + safety detection:

```python
import time
import random
import logging

logger = logging.getLogger(__name__)


def generate_with_full_retry(client, prompt, model="gemini-3-pro-image-preview",
                              aspect_ratio="1:1", image_size=None,
                              max_retries=5, reference_images=None):
    """
    Genera imagen con retry completo.

    Returns:
        dict con claves: success, image, text, error, message
    """
    config_dict = {
        "response_modalities": ["TEXT", "IMAGE"],
        "image_config": {"aspect_ratio": aspect_ratio},
    }
    if image_size:
        config_dict["image_config"]["image_size"] = image_size

    contents = []
    if reference_images:
        for ref in reference_images:
            contents.append(ref)
    contents.append(prompt)

    for attempt in range(max_retries):
        try:
            response = client.models.generate_content(
                model=model,
                contents=contents,
                config=config_dict,
            )

            # Sin candidatos
            if not response.candidates:
                logger.warning("Sin candidatos — filtro de seguridad")
                return {"error": "content_filtered",
                        "message": "Sin candidatos en la respuesta"}

            candidate = response.candidates[0]

            # Safety check
            if candidate.finish_reason and candidate.finish_reason.name in (
                "SAFETY", "IMAGE_SAFETY", "RECITATION"
            ):
                logger.warning(f"Bloqueado: {candidate.finish_reason.name}")
                return {"error": "safety_filtered",
                        "message": str(candidate.finish_reason.name)}

            # Extraer imagen
            text_out = None
            for part in response.parts:
                if part.inline_data is not None:
                    return {"success": True,
                            "image": part.as_image(),
                            "text": text_out}
                if part.text is not None:
                    text_out = part.text

            # Respuesta sin imagen (prompt ambiguo)
            logger.warning("Respuesta sin imagen")
            return {"error": "no_image",
                    "message": "Sin imagen en la respuesta",
                    "text": text_out}

        except Exception as e:
            code = getattr(e, "code", getattr(e, "status_code", 0))

            if code == 429:
                delay = (2 ** attempt) + random.uniform(0, 2)
                logger.info(f"429 rate limit, retry en {delay:.1f}s")
                time.sleep(delay)

            elif code >= 500:
                delay = (2 ** attempt) + random.uniform(0, 1)
                logger.info(f"{code} server error, retry en {delay:.1f}s")
                time.sleep(delay)

            elif code == 400:
                logger.error(f"400 bad request: {e}")
                return {"error": "bad_request", "message": str(e)}

            else:
                logger.error(f"Error inesperado: {e}")
                raise

    return {"error": "max_retries",
            "message": f"Fallo tras {max_retries} intentos"}
```

---

## 12. Circuit breaker

Para evitar bombardear la API cuando esta caida:

```python
import time
from enum import Enum


class CircuitState(Enum):
    CLOSED = "closed"        # Funcionando normal
    OPEN = "open"            # API caida, no enviar requests
    HALF_OPEN = "half_open"  # Probando si se recupero


class CircuitBreaker:
    """Circuit breaker para la API de Gemini."""

    def __init__(self, failure_threshold=5, recovery_timeout=60):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.last_failure_time = 0

    def can_execute(self) -> bool:
        if self.state == CircuitState.CLOSED:
            return True
        if self.state == CircuitState.OPEN:
            if time.time() - self.last_failure_time >= self.recovery_timeout:
                self.state = CircuitState.HALF_OPEN
                return True
            return False
        return True  # HALF_OPEN

    def record_success(self):
        self.failure_count = 0
        self.state = CircuitState.CLOSED

    def record_failure(self):
        self.failure_count += 1
        self.last_failure_time = time.time()
        if self.failure_count >= self.failure_threshold:
            self.state = CircuitState.OPEN

    @property
    def is_open(self):
        return self.state == CircuitState.OPEN


# Uso:
breaker = CircuitBreaker(failure_threshold=5, recovery_timeout=60)

def generate_with_breaker(client, prompt):
    if not breaker.can_execute():
        return {"error": "circuit_open", "message": "API temporalmente no disponible"}

    result = generate_with_retry(client, prompt, max_retries=2)

    if result.get("success"):
        breaker.record_success()
    elif result.get("error") in ("max_retries",):
        breaker.record_failure()

    return result
```

---

## 13. Comparacion con alternativas

### Gemini vs OpenAI GPT Image / DALL-E 3

| Aspecto | Gemini gana | OpenAI gana |
|---------|-------------|-------------|
| Costo | ✅ Mas barato a volumen | |
| Edicion multi-turn | ✅ Conversacional | |
| Consistencia personajes | ✅ Con ref images | |
| Velocidad | ✅ ~1s | |
| Multimodal | ✅ Texto+imagen intercalados | |
| Filtros de contenido | | ✅ Mas predecibles |
| Text rendering | | ✅ Ligeramente superior (GPT Image 1.5) |
| Documentacion | | ✅ Mas madura |

### Gemini vs Midjourney

| Aspecto | Gemini gana | Midjourney gana |
|---------|-------------|-----------------|
| API programatica | ✅ Completa | |
| Edicion | ✅ Conversacional | |
| Texto en imagenes | ✅ Superior | |
| Velocidad | ✅ ~1s vs 9-22s | |
| Costo volumen | ✅ | |
| Calidad artistica | | ✅ "Magazine polish" |
| Creatividad visual | | ✅ Mas sorprendente |
| Comunidad | | ✅ Galeria de referencia |

### Gemini vs Stable Diffusion / Flux

| Aspecto | Gemini gana | SD/Flux ganan |
|---------|-------------|---------------|
| Facilidad de uso | ✅ API sin setup | |
| Sin GPU requerida | ✅ | |
| Texto en imagenes | ✅ | |
| Seguridad/watermarks | ✅ Built-in | |
| Gratuito | | ✅ Self-hosted |
| Control total | | ✅ LoRA, fine-tuning |
| Sin filtros | | ✅ Sin restricciones |
| Sin watermarks | | ✅ |
| Personalizacion | | ✅ ControlNet, etc. |

### Recomendacion practica

Para produccion de ads y contenido visual programatico:
1. **Gemini 3 Pro Image** como backend principal (edicion, texto, refs, multi-turn)
2. **Imagen 4 Fast** para volumen masivo sin edicion
3. **Midjourney** para creacion artistica inicial (manual, no API)
4. **SD/Flux** solo si necesitas control total o zero cost
