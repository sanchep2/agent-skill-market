# Prompting and Text Rendering — Nano Banana Pro Skill

Framework de prompting de 6 elementos, texto en imagenes, ejemplos verificados por caso de uso.
Gemini entiende lenguaje narrativo — describir la escena, no listar keywords.

## Table of Contents

- [1. Principio fundamental](#1-principio-fundamental)
- [2. Framework de 6 elementos](#2-framework-de-6-elementos)
- [3. Lenguaje fotografico y cinematografico](#3-lenguaje-fotografico-y-cinematografico)
- [4. Negative prompts y exclusiones](#4-negative-prompts-y-exclusiones)
- [5. Texto en imagenes (text rendering)](#5-texto-en-imagenes-text-rendering)
- [6. Consistencia visual](#6-consistencia-visual)
- [7. Ejemplos por caso de uso](#7-ejemplos-por-caso-de-uso)
- [8. Prompts para ads (verificados)](#8-prompts-para-ads-verificados)
- [9. Anti-patrones](#9-anti-patrones)

---

## 1. Principio fundamental

> **"Describe la escena, no listes keywords."**

Los modelos Gemini entienden lenguaje narrativo. Un parrafo descriptivo produce mejores
resultados que una lista de terminos separados por comas (a diferencia de Midjourney o
Stable Diffusion).

```
  ❌ Incorrecto (estilo Midjourney):
  "trading, crypto, dark background, gold accents, professional, 4k,
   ultra detailed, cinematic lighting, octane render"

  ✅ Correcto (estilo Gemini):
  "Un poster profesional para un evento de trading de criptomonedas.
   Fondo oscuro elegante con acentos dorados. Graficos de velas japonesas
   sutiles en el fondo. Tipografia sans-serif bold blanca para el titulo.
   Estetica premium fintech. Iluminacion cinematografica con rim light dorado."
```

---

## 2. Framework de 6 elementos

Google recomienda incluir estos 6 componentes en cada prompt:

```
  Framework de prompt
  ══════════════════════════════════════════

  1. SUJETO      → Quien o que aparece
                    "Una mujer de 30 anos con cabello rizado"
                    NO: "una persona"

  2. COMPOSICION → Encuadre, angulo, layout
                    "Plano medio", "vista cenital", "close-up macro"
                    "Horizontal con sujeto a la izquierda"

  3. ACCION      → Que esta pasando
                    "Preparando cafe", "caminando bajo la lluvia"
                    "Mirando a camara con expresion confiada"

  4. LOCACION    → Donde ocurre
                    "Cafeteria vintage en Paris"
                    "Laboratorio futurista con pantallas holograficas"

  5. ESTILO      → Estetica general
                    "Fotografia editorial", "ilustracion acuarela"
                    "Render 3D Pixar", "minimalista premium"

  6. EDICION     → Instrucciones especificas (si aplica)
                    "Cambia el fondo por playa"
                    "Agrega texto 'EVENTO 2026' centrado"
```

### Ejemplo completo

```
SUJETO:      Trader profesional hispanico en sus 30s
COMPOSICION: Plano medio, ligeramente angulado, mirando a camara
ACCION:      De pie con brazos cruzados, expresion confiada
LOCACION:    Oficina de trading con multiples pantallas mostrando graficos
ESTILO:      Fotografia corporativa premium, iluminacion de estudio
EDICION:     (no aplica — generacion nueva)
```

Prompt final: "Un trader profesional hispanico en sus 30s, plano medio ligeramente angulado,
de pie con brazos cruzados mirando a camara con expresion confiada. Oficina de trading con
multiples pantallas mostrando graficos de criptomonedas en el fondo. Fotografia corporativa
premium con iluminacion de estudio, tonos oscuros con acentos dorados."

---

## 3. Lenguaje fotografico y cinematografico

Los modelos responden especialmente bien a terminologia tecnica de fotografia:

### Tipos de plano

| Termino | Descripcion |
|---------|-------------|
| `extreme wide shot` | Vista muy amplia, sujeto pequeno |
| `wide-angle shot` | Vista amplia, contexto completo |
| `medium shot` | Cintura para arriba |
| `close-up` | Cara/objeto principal |
| `extreme close-up` | Detalle muy cercano (ojos, textura) |
| `establishing shot` | Vista general que establece ubicacion |
| `over-the-shoulder` | Desde atras del hombro de alguien |

### Angulos

| Termino | Descripcion |
|---------|-------------|
| `eye-level` | A la altura de los ojos (neutral) |
| `low-angle` | Desde abajo (empodera al sujeto) |
| `high-angle` | Desde arriba (sujeto vulnerable) |
| `Dutch angle` | Inclinado (tension, dinamismo) |
| `bird's eye view` | Cenital (vista de pajaro) |
| `worm's eye view` | Desde el suelo |

### Lentes

| Termino | Efecto |
|---------|--------|
| `85mm portrait lens` | Compresion bonita, bokeh, retratos |
| `24mm wide-angle` | Distorsion dramatica, espacios amplios |
| `50mm standard` | Natural, como el ojo humano |
| `macro lens` | Detalles minusculos amplificados |
| `fisheye` | Distorsion esferica extrema |
| `tilt-shift` | Efecto miniatura |

### Profundidad de campo

| Termino | Efecto |
|---------|--------|
| `shallow depth of field (f/1.8)` | Fondo muy borroso, sujeto nitido |
| `deep focus` | Todo nitido |
| `bokeh` | Circulos de luz borrosos en fondo |
| `tilt-shift` | Plano de enfoque selectivo |

### Iluminacion

| Termino | Efecto |
|---------|--------|
| `golden hour` | Luz calida de atardecer |
| `backlighting` | Luz desde atras (silueta) |
| `rim light` | Borde de luz alrededor del sujeto |
| `volumetric god rays` | Rayos de luz visibles |
| `chiaroscuro` | Contraste dramatico luz/sombra |
| `Rembrandt lighting` | Triangulo de luz en mejilla |
| `neon glow` | Luz neon colorida |
| `studio softbox` | Luz suave y uniforme de estudio |
| `natural window light` | Luz natural de ventana |

---

## 4. Negative prompts y exclusiones

**Gemini nativo NO tiene parametro de negative prompt.** Las alternativas:

### Framing afirmativo (recomendado)

```
  ❌ "No text, no borders, no watermarks"
  ✅ "Imagen limpia sin elementos de texto, sin bordes ni watermarks"

  ❌ "No people"
  ✅ "Escena vacia, sin personas, solo el paisaje y la arquitectura"

  ❌ "Don't make it blurry"
  ✅ "Imagen nitida con enfoque perfecto en primer plano"
```

### Exclusiones en lenguaje natural

Funciona razonablemente, pero no es garantizado:

```
"No incluyas texto, bordes ni watermarks en la imagen"
"Sin personas visibles en la escena"
"Evita colores neon o saturacion excesiva"
```

### Refinamiento conversacional (multi-turn)

```
Turno 1: "Genera un paisaje de montana al amanecer"
Turno 2: "Elimina el texto que aparece en la imagen"
Turno 3: "Reduce la saturacion de los colores, hacerlos mas naturales"
```

---

## 5. Texto en imagenes (text rendering)

Gemini 3 Pro Image tiene el **mejor renderizado de texto** entre todos los modelos actuales.

### Reglas para texto en imagenes

```
  ✅ Hacer:
  ─────────────────────────────────
  • Texto entre comillas exactas: "CURSO ONLINE"
  • Textos cortos: <25 caracteres por linea
  • Maximo 2-3 frases distintas por imagen
  • Especificar tipografia: "sans-serif bold blanca"
  • Indicar ubicacion: "centrado", "esquina superior derecha"
  • Especificar color: "texto dorado (#C9A962)"
  • Especificar tamano relativo: "titulo grande", "subtexto pequeno"

  ❌ Evitar:
  ─────────────────────────────────
  • Textos largos (>25 chars) = errores frecuentes
  • Muchas lineas de texto = degradacion
  • No especificar estilo = tipografia aleatoria
  • Textos muy pequenos = ilegibles
  • Multiples idiomas = confusion
```

### Ejemplo: ad creative con texto

```
"Imagen publicitaria para evento de trading.
 Fondo oscuro premium (#0A0B0F) con graficos de velas japonesas sutiles.

 Texto a renderizar:
 - Titulo en DORADO (#C9A962), grande, sans-serif bold: 'CURSO ONLINE'
 - Subtitulo en BLANCO, mediano: 'GRATIS'
 - Fecha en DORADO, pequeno: '28 FEB — 1 MAR 2026'
 - CTA en badge dorado con texto negro: 'REGISTRATE AHORA'

 Layout: titulo centrado superior, subtitulo debajo, fecha mas abajo, CTA al fondo.
 Estetica: premium fintech, minimalista, dark mode."
```

### Estrategia para texto complejo

Para texto largo o estilizado, dividir en pasos:

```
Turno 1: "Genera la imagen base sin texto — fondo oscuro con graficos de trading"
Turno 2: "Agrega el titulo 'CURSO ONLINE' centrado, sans-serif bold dorado"
Turno 3: "Agrega 'GRATIS' debajo en blanco grande"
Turno 4: "Agrega '28 FEB — 1 MAR 2026' en dorado pequeno en la parte inferior"
```

---

## 6. Consistencia visual

### Mantener conversacion activa

El mismo chat preserva contexto visual del personaje/marca:

```python
chat = client.chats.create(
    model="gemini-3-pro-image-preview",
    config=types.GenerateContentConfig(response_modalities=["TEXT", "IMAGE"]),
)

# Establecer con detalle en primer prompt
chat.send_message("Sprite de hongo bioluminiscente: ojos curiosos grandes, "
                   "cuerpo de enredaderas, gorro brillante azul-verde, 30cm")

# Prompts posteriores mantienen consistencia
chat.send_message("El mismo personaje caminando en un bosque")
chat.send_message("El mismo personaje descansando junto a un rio")
```

### Style Sheet reutilizable

Documentar y reutilizar como sufijo en cada prompt:

```python
BRAND_STYLE = """
REGLAS DE DISENO:
- Fondo: oscuro/negro (#0A0B0F) con graficos sutiles de trading
- Color primario: dorado (#C9A962) para titulos y elementos clave
- Texto secundario: blanco sobre fondo oscuro
- Estilo: premium fintech/crypto, moderno, limpio, profesional
- Tipografia: sans-serif bold, alto contraste, legible
- Sin clipart, sin aspecto de stock photo
- Logo 'TU MARCA' pequeno en una esquina
- Maximo 20% del area en texto (politica Google/Meta)
"""

prompt = f"Ad creative para Instagram Feed. {BRAND_STYLE}"
```

### Si hay drift de consistencia

1. Guardar la mejor version como imagen
2. Reiniciar conversacion
3. Pasar la imagen guardada como referencia
4. Describir con detalle lo que quieres mantener

---

## 7. Ejemplos por caso de uso

### Post de Instagram (4:5)

```
"Create a 4:5 portrait image for Instagram: A flat-lay arrangement of
artisanal coffee beans, a ceramic pour-over, and a linen napkin on a
warm oak table. Overhead shot, soft natural window light, earth-tone
palette of browns, creams, and terracotta. Clean, minimalist composition
with breathing space. High-resolution editorial food photography style.
No text."
```

### YouTube Thumbnail (16:9)

```
"Create a 16:9 YouTube thumbnail: A dramatic close-up of hands pulling
apart a freshly baked sourdough loaf with steam rising, against a dark
rustic wood background. The text 'PERFECT BREAD' in large bold yellow
sans-serif font with a dark outline in the upper right. High contrast,
saturated warm tones, eye-catching food photography."
```

### Flyer de evento (9:16)

```
"Design a vertical 9:16 poster for a summer music festival called
'SOLSTICE SOUNDS 2026.' The title in large, bold, retro-inspired serif
font at the top. Below, a dreamy illustration of a sunset over a
festival crowd with stage lights. Color palette: warm sunset oranges,
pinks, and deep purples. Include text '21-23 JUNIO | PARQUE RIVERSIDE'
in clean sans-serif below. Vintage concert poster aesthetic."
```

### Ad de Facebook (1:1)

```
"Create a square 1:1 social media ad image: A premium wireless headphone
case centered on a clean gradient background (deep navy to midnight blue).
Dramatic studio lighting with soft rim light. Leave space in the upper
third for headline text and bottom for CTA button. Product photography,
high-end, minimalist."
```

### LinkedIn profesional (16:9)

```
"Generate a wide 16:9 professional image: A modern bright conference room
with diverse professionals collaborating around a digital whiteboard
displaying data charts. Natural light from floor-to-ceiling windows,
contemporary office design, muted blue and gray corporate palette.
Editorial, authentic feel — not stock-photo generic."
```

### Material educativo

```
"Create a scientifically accurate cross-section diagram of a plant cell,
labeled with organelles (nucleus, chloroplast, cell wall, mitochondria,
vacuole). Clean white background, colorful but professional illustration
style, clear readable labels in sans-serif font. Suitable for a biology
textbook."
```

### Infografia con datos (Gemini 3 Pro + Google Search)

```python
response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents="Visualiza el pronostico del tiempo actual para los proximos "
             "5 dias en Ciudad de Mexico como un grafico limpio y moderno",
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(aspect_ratio="16:9", image_size="2K"),
        tools=[{"google_search": {}}],
    ),
)
```

---

## 8. Prompts para ads (verificados en produccion)

### Variante A: con persona (verificado con 5 formatos)

```python
VARIANTE_A = """
Create a premium curso online premium advertisement image.

SCENE: A confident Hispanic man in his 30s (Jaime Merino, crypto trader/educator)
on one side, with dynamic trading charts, candlestick patterns, and crypto symbols
(Bitcoin, Ethereum logos subtly) in the background. Dark premium atmosphere.

TEXT TO RENDER ON THE IMAGE (must be legible):
- Main headline in GOLD color: "CURSO ONLINE GRATIS"
- Subtext in WHITE: "28 FEB — 1 MAR 2026"
- Secondary text in GOLD: "Plazas Limitadas"
- Small CTA button with gold background and black text: "REGISTRATE AHORA"
- Small logo text "TU MARCA" in bottom corner

STRICT DESIGN RULES:
- Background: dark/black (#0A0B0F) with subtle trading chart graphics
- Primary accent color: gold (#C9A962) for headlines and key elements
- Secondary text: white on dark background
- Style: premium fintech/crypto aesthetic, modern, clean, professional
- Typography: bold sans-serif, high contrast, legible at small sizes
- Max 20% of image area should be text
- Keep key content in the center 80%
"""
```

### Variante B: sin persona (verificado con 5 formatos)

```python
VARIANTE_B = """
Create a premium cryptocurrency trading education advertisement image.

SCENE: Dynamic trading interface with candlestick charts, price tickers,
crypto coin symbols (BTC, ETH, DeFi tokens), technical analysis overlays.
NO person/face — focus entirely on trading visuals.

TEXT TO RENDER:
- Main headline in WHITE: "APRENDE TRADING"
- Second headline in GOLD: "GRATIS"
- Subtext in WHITE: "3 Dias Intensivos — Trading + DeFi + Cripto"
- Date in GOLD: "28 FEB — 1 MAR 2026"
- Small CTA: "INSCRIBETE SIN COSTO"
"""
```

### CTA cards para video (verificado con 9 variantes)

```python
CTA_BASE = """
Create a premium advertising end-card for a curso online premium video ad.

VISUAL STYLE (MUST match the reference images exactly):
- Dark premium background with gradient from deep black (#0A0B0F) to dark navy
- Golden accent color (#C9A962) for highlights, borders, and key text
- Professional financial/trading aesthetic with subtle chart elements

LAYOUT:
- Top: logo de tu marca (golden on dark)
- Center: Large bold text "CURSO ONLINE" in white
- Below: "GRATIS" in a golden badge/pill shape
- Below badge: "28 FEB — 1 MAR" in golden text
- Bottom: Subtle golden line separator

CRITICAL: Text must be PERFECTLY LEGIBLE — large, bold, high contrast.
"GRATIS" must be the most eye-catching element.
"""
```

---

## 9. Anti-patrones

### Keywords estilo Midjourney

```
❌ "crypto, trading, dark, gold, 4k, ultra detailed, cinematic, octane render,
    unreal engine, artstation, trending, masterpiece, best quality"

✅ "Un poster profesional para un evento de trading de criptomonedas.
    Fondo oscuro elegante con destellos dorados. Graficos de velas japonesas
    sutiles en el fondo."
```

### Prompts demasiado cortos

```
❌ "Generate an ad"

✅ "Imagen publicitaria premium para un curso online de diseno.
    Fondo oscuro (#0A0B0F) con formas geometricas sutiles. Titulo 'CURSO
    ONLINE' en dorado, subtitulo 'GRATIS' en blanco grande. Estetica moderna."
```

### Trigger words que activan filtros

Evitar estas palabras que pueden activar `PROHIBITED_CONTENT`:

```
  Palabras a evitar:
  ─────────────────────────────────
  "hack", "exploit", "manipulate", "circumvent", "bypass"
  "attack", "weapon", "drug", "injection", "steal"
  "naked", "nude", "explicit", "violence", "blood"

  Alternativas seguras:
  ─────────────────────────────────
  "cybersecurity" en vez de "hack"
  "strategy" en vez de "exploit"
  "optimize" en vez de "manipulate"
```

### Solicitar demasiado texto

```
❌ "Agrega un parrafo completo de 50 palabras explicando el evento"

✅ "Agrega el titulo 'CURSO ONLINE' y la fecha '28 FEB' solamente"
```

### No especificar formato/layout

```
❌ "Genera un ad para redes sociales"

✅ "Genera un ad en formato cuadrado 1:1 para Instagram Feed. Layout:
    producto centrado, titulo arriba, CTA abajo."
```
