# Batch API and Optimization — Nano Banana Pro Skill

Batch API con 50% descuento, routing hibrido multi-modelo, estimacion de costos, optimizacion.

## Table of Contents

- [1. Batch API overview](#1-batch-api-overview)
- [2. Crear un batch](#2-crear-un-batch)
- [3. Polling y extraccion de resultados](#3-polling-y-extraccion-de-resultados)
- [4. Routing hibrido multi-modelo](#4-routing-hibrido-multi-modelo)
- [5. Tabla de costos detallada](#5-tabla-de-costos-detallada)
- [6. Proyecciones mensuales](#6-proyecciones-mensuales)
- [7. Estrategias de optimizacion](#7-estrategias-de-optimizacion)
- [8. Multi-formato eficiente](#8-multi-formato-eficiente)
- [9. Patron productor real](#9-patron-productor-real)

---

## 1. Batch API overview

- **50% descuento** sobre el precio standard
- Procesamiento **asincrono** — ventana de hasta 24h (tipicamente 2-4h)
- Solo disponible para **Gemini nativo** (3 Pro). NO para Imagen 4.
- Util cuando la latencia no importa (generacion nocturna, pre-produccion)
- Cada request en el batch se procesa independientemente
- Si un request falla (safety filter), los demas continuan

### Cuando usar Batch API

```
  ¿Necesitas las imagenes AHORA?
       │
       ├── SI → Llamadas individuales (standard pricing)
       │
       └── NO → Batch API (50% off)
            │
            ├── Pre-produccion de assets de campana
            ├── Generacion nocturna de variantes
            ├── Thumbnails para catalogo grande
            └── A/B testing de creativos
```

---

## 2. Crear un batch

### Python con SDK

```python
import time
from google import genai
from google.genai import types

client = genai.Client()

# Definir requests
batch_requests = [
    {
        "contents": [
            {"parts": [{"text": f"Thumbnail profesional para YouTube sobre {tema}"}],
             "role": "user"}
        ],
        "config": {"response_modalities": ["TEXT", "IMAGE"]}
    }
    for tema in [
        "inteligencia artificial",
        "cocina mexicana",
        "fitness en casa",
        "marketing digital",
    ]
]

# Crear batch
batch_job = client.batches.create(
    model="gemini-3-pro-image-preview",
    src=batch_requests,
    config={"display_name": "thumbnails-batch"},
)

print(f"Batch creado: {batch_job.name}")
print(f"Estado: {batch_job.state}")
```

### Notas

- `display_name` es opcional pero recomendado para identificar batches
- El batch se inicia inmediatamente
- Cada request es independiente — si uno falla, los demas continuan
- No hay limite documentado de requests por batch, pero recomendado <1000

---

## 3. Polling y extraccion de resultados

### Polling basico

```python
while True:
    batch_job = client.batches.get(name=batch_job.name)
    print(f"Estado: {batch_job.state.name}")

    if batch_job.state.name in ("JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED"):
        break

    time.sleep(30)  # Polling cada 30s
```

### Extraccion de imagenes

```python
if batch_job.state.name == "JOB_STATE_SUCCEEDED":
    for i, resp in enumerate(batch_job.dest.inlined_responses):
        if resp.response:
            for part in resp.response.parts:
                if part.inline_data:
                    part.as_image().save(f"batch_{i}.png")
                    print(f"Guardada: batch_{i}.png")
        else:
            print(f"Request {i} fallo: {resp.error}")
```

### Polling con timeout

```python
import time

MAX_WAIT = 24 * 3600  # 24 horas max
POLL_INTERVAL = 60    # 1 minuto entre checks
start = time.time()

while time.time() - start < MAX_WAIT:
    batch_job = client.batches.get(name=batch_job.name)

    if batch_job.state.name == "JOB_STATE_SUCCEEDED":
        print("Batch completado exitosamente")
        break
    elif batch_job.state.name in ("JOB_STATE_FAILED", "JOB_STATE_CANCELLED"):
        print(f"Batch fallo: {batch_job.state.name}")
        break

    elapsed = time.time() - start
    print(f"Esperando... ({elapsed/60:.0f} min)")
    time.sleep(POLL_INTERVAL)
else:
    print("Timeout: batch no completo en 24h")
```

---

## 4. Routing hibrido multi-modelo

Estrategia para minimizar costos sin sacrificar calidad:

```
  ¿Que tipo de imagen necesito?
       │
       ├── Edicion / multi-turn / texto / 4K / refs
       │   └── Gemini 3 Pro Image ($0.134-$0.24)
       │       └── ¿Puede esperar? → Batch API ($0.067-$0.12)
       │
       ├── Text-to-image puro, volumen masivo (>1000), sin edicion
       │   └── Imagen 4 Fast ($0.02)
       │
       └── Maxima calidad text-to-image, sin edicion
            └── Imagen 4 Ultra ($0.06)
```

### Implementacion

```python
def select_model(needs_editing=False, needs_text=False, needs_refs=False,
                 needs_4k=False, volume_mode=False, max_quality=False):
    """Selecciona el modelo optimo segun requisitos."""
    if needs_editing or needs_text or needs_refs or needs_4k:
        return "gemini-3-pro-image-preview"

    if volume_mode:
        return "imagen-4.0-fast-generate-001"

    if max_quality:
        return "imagen-4.0-ultra-generate-001"

    # Default: Gemini 3 Pro siempre
    return "gemini-3-pro-image-preview"
```

---

## 5. Tabla de costos detallada

### Por modelo y resolucion

| Modelo | 1K | 2K | 4K | Batch 2K | Batch 4K |
|--------|:---:|:---:|:---:|:---:|:---:|
| Gemini 3 Pro | — | $0.134 | $0.24 | $0.067 | $0.12 |
| Imagen 4 Fast | $0.02 | — | — | N/A | N/A |
| Imagen 4 Standard | $0.04 | $0.04 | — | N/A | N/A |
| Imagen 4 Ultra | $0.06 | $0.06 | — | N/A | N/A |

### Calculo para un set tipico de ads

**Campana basica (2 variantes × 4 formatos = 8 imagenes):**

| Modelo | Costo/img | Total 8 imgs | Con Batch |
|--------|:---------:|:------------:|:---------:|
| 3 Pro 2K | $0.134 | $1.07 | $0.54 |
| Imagen 4 Fast | $0.02 | $0.16 | N/A |

**Campana completa (2 variantes × 5 formatos + 9 CTAs = 19 imagenes):**

| Modelo | Costo/img | Total 19 imgs | Con Batch |
|--------|:---------:|:-------------:|:---------:|
| 3 Pro 2K | $0.134 | $2.55 | $1.27 |
| 3 Pro 4K | $0.24 | $4.56 | $2.28 |

---

## 6. Proyecciones mensuales

| Volumen/mes | Imagen 4 Fast | Imagen 4 Ultra | 3 Pro 2K | 3 Pro 2K Batch |
|-------------|:---:|:---:|:---:|:---:|
| 50 imgs | $1 | $3 | $6.70 | $3.35 |
| 100 imgs | $2 | $6 | $13.40 | $6.70 |
| 500 imgs | $10 | $30 | $67 | $33.50 |
| 1,000 imgs | $20 | $60 | $134 | $67 |
| 5,000 imgs | $100 | $300 | $670 | $335 |
| 10,000 imgs | $200 | $600 | $1,340 | $670 |

> **Punto de inflexion:** A partir de ~500 imgs/mes con Gemini 3 Pro,
> considerar Batch API (ahorro de ~$33.50).

---

## 7. Estrategias de optimizacion

### 1. Batch API para volumen (50% descuento)

```python
# En lugar de 10 llamadas individuales...
for prompt in prompts:
    generate_image(prompt)  # 10 × $0.134 = $1.34

# ...usar Batch API
batch = client.batches.create(
    model="gemini-3-pro-image-preview",
    src=[{"contents": p} for p in prompts],
)
# 10 × $0.067 = $0.67 (50% ahorro)
```

### 2. No usar 4K innecesariamente

```
  1K (~1024×1024):  ~$0.134 (2K default en 3 Pro)
  4K (~4096×4096):  ~$0.24

  Diferencia: ~80% mas caro por 4K
  ¿La plataforma destino muestra >2K? Probablemente no.
  Instagram: 1080px, Facebook: 1200px, YouTube: 1920px → 2K suficiente
```

### 3. Reutilizar conversaciones (multi-turn)

```python
# En lugar de generar 3 variantes desde cero...
# 3 × $0.134 = $0.40

# ...editar en multi-turn (1 generacion + 2 ediciones)
chat = client.chats.create(model="gemini-3-pro-image-preview", ...)
chat.send_message("Genera poster version 1")        # $0.134
chat.send_message("Cambia colores a azul")           # $0.134
chat.send_message("Ahora en tonos verdes")           # $0.134
# Total: $0.40 — mismo costo pero con consistencia visual
```

### 4. Cache de prompts similares

```python
import hashlib
import os

CACHE_DIR = "cache/images"

def generate_cached(prompt, aspect_ratio="1:1"):
    """Genera imagen con cache local."""
    cache_key = hashlib.md5(f"{prompt}:{aspect_ratio}".encode()).hexdigest()
    cache_path = os.path.join(CACHE_DIR, f"{cache_key}.png")

    if os.path.exists(cache_path):
        return Image.open(cache_path)

    img = generate_image(prompt, aspect_ratio)
    if img:
        os.makedirs(CACHE_DIR, exist_ok=True)
        img.save(cache_path)
    return img
```

### 5. Routing hibrido en produccion

```python
def generate_smart(prompt, needs_editing=False, needs_text=False, batch_ok=False):
    """Selecciona modelo y metodo optimo."""
    model = select_model(needs_editing=needs_editing, needs_text=needs_text)

    if batch_ok and model.startswith("gemini"):
        return batch_generate(model, prompt)  # 50% off
    else:
        return generate_image(prompt, model=model)
```

---

## 8. Multi-formato eficiente

Generar 1 prompt base → multiples formatos en paralelo o batch:

### Secuencial con pausa

```python
FORMATS = [
    {"name": "landscape", "ratio": "16:9", "w": 1920, "h": 1080},
    {"name": "square",    "ratio": "1:1",  "w": 1080, "h": 1080},
    {"name": "vertical",  "ratio": "9:16", "w": 1080, "h": 1920},
]

base_prompt = "Premium ad for curso online, dark background, gold accents..."

for fmt in FORMATS:
    img = generate_image(
        prompt=base_prompt + f"\nLayout: {fmt['name']} format.",
        aspect_ratio=fmt["ratio"],
    )
    if img:
        img = resize_and_crop(img, fmt["w"], fmt["h"])
        img.save(f"ad-{fmt['name']}.png")
    time.sleep(2)
```

### Con Batch API (50% off)

```python
batch_requests = []
for fmt in FORMATS:
    batch_requests.append({
        "contents": [{
            "parts": [{"text": base_prompt + f"\nLayout: {fmt['name']} format."}],
            "role": "user"
        }],
        "config": {
            "response_modalities": ["TEXT", "IMAGE"],
            "image_config": {"aspect_ratio": fmt["ratio"], "image_size": "2K"}
        }
    })

batch = client.batches.create(
    model="gemini-3-pro-image-preview",
    src=batch_requests,
    config={"display_name": "multi-format-ads"},
)
```

### Async concurrente

```python
import asyncio

async def generate_async(prompt, aspect_ratio, filename):
    response = await client.aio.models.generate_content(
        model="gemini-3-pro-image-preview",
        contents=[prompt],
        config={"response_modalities": ["TEXT", "IMAGE"],
                "image_config": {"aspect_ratio": aspect_ratio}},
    )
    for part in response.parts:
        if part.inline_data:
            part.as_image().save(filename)
            return filename
    return None

async def main():
    tasks = [
        generate_async(base_prompt, "16:9", "landscape.png"),
        generate_async(base_prompt, "1:1", "square.png"),
        generate_async(base_prompt, "9:16", "vertical.png"),
    ]
    results = await asyncio.gather(*tasks)
    print(f"Generados: {results}")

asyncio.run(main())
```

> **Cuidado con rate limits:** Async concurrente puede disparar 429s.
> Usar semaforo: `sem = asyncio.Semaphore(3)` para limitar concurrencia.

---

## 9. Patron productor real

Datos reales del proyecto (feb 2026):

### Produccion ejecutada

| Batch | Imagenes | Modelo | imageSize | Costo estimado |
|-------|---------|--------|-----------|---------------|
| Ad creatives | 10 | gemini-3-pro-image-preview | default (~1K) | ~$1.34 |
| CTA cards | 9 | gemini-3-pro-image-preview | 2K | ~$1.21 |
| **Total** | **19** | | | **~$2.55** |

### Tiempo de ejecucion

- ~10-15 segundos por imagen (incluyendo network)
- ~2 segundos de pausa entre generaciones (rate limiting)
- Total: ~4-5 minutos para 19 imagenes
- Con Batch API: ~2-4 horas (pero 50% mas barato)

### Tasa de exito

- ~90% exito en primer intento
- ~10% requieren retry (safety filter o 503)
- Con 3 retries, ~98% exito total
