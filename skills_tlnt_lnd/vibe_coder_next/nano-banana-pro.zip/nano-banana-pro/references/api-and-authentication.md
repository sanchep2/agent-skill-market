# API and Authentication — Nano Banana Pro Skill

Endpoints, autenticacion, parametros completos de request/response para Gemini Image API e Imagen 4.

## Table of Contents

- [1. Endpoints](#1-endpoints)
- [2. Authentication](#2-authentication)
- [3. generationConfig parameters](#3-generationconfig-parameters)
- [4. imageConfig parameters](#4-imageconfig-parameters)
- [5. safetySettings](#5-safetysettings)
- [6. Tools (Google Search grounding)](#6-tools-google-search-grounding)
- [7. Request JSON — text-to-image](#7-request-json--text-to-image)
- [8. Request JSON — con referencia](#8-request-json--con-referencia)
- [9. Request JSON — multi-turn](#9-request-json--multi-turn)
- [10. Response JSON — Gemini nativo](#10-response-json--gemini-nativo)
- [11. Imagen 4 predict parameters](#11-imagen-4-predict-parameters)
- [12. Imagen 4 response](#12-imagen-4-response)
- [13. Error responses](#13-error-responses)

---

## 1. Endpoints

### Gemini nativo (generateContent)

```
POST https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent
```

Modelos validos:
- `gemini-3-pro-image-preview` (recomendado)

### Imagen 4 (predict / generateImages)

```
POST https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:predict
```

Modelos validos:
- `imagen-4.0-fast-generate-001`
- `imagen-4.0-generate-001`
- `imagen-4.0-ultra-generate-001`

### Vertex AI (alternativa)

```
POST https://{REGION}-aiplatform.googleapis.com/v1/projects/{PROJECT}/locations/{REGION}/publishers/google/models/{MODEL}:generateContent
```

---

## 2. Authentication

### Metodo 1: Variable de entorno (recomendado)

```bash
export GEMINI_API_KEY="tu-api-key-aqui"
```

```python
# Python — lee automaticamente del entorno
client = genai.Client()
```

```typescript
// Node.js — explicita
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
```

### Metodo 2: Query parameter

```bash
curl -X POST \
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image-preview:generateContent?key=$GEMINI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '...'
```

### Metodo 3: Header

```bash
curl -X POST \
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image-preview:generateContent" \
  -H "Content-Type: application/json" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -d '...'
```

### Metodo 4: Vertex AI (project + location)

```python
client = genai.Client(vertexai=True, project="your-project-id", location="us-central1")
```

### Obtener API key

https://aistudio.google.com/apikey

> **IMPORTANTE:** Requiere billing activo. Free tier tiene 0 IPM para modelos de imagen.

---

## 3. generationConfig parameters

Parametros dentro de `generationConfig` para Gemini nativo:

| Parametro | Tipo | Valores | Default | Descripcion |
|-----------|------|---------|---------|-------------|
| `responseModalities` | `string[]` | `["TEXT", "IMAGE"]`, `["IMAGE"]` | — | **OBLIGATORIO** para generar imagenes |
| `temperature` | `float` | 0.0-2.0 | 1.0 | Controla aleatoriedad. Mayor = mas creativo |
| `topP` | `float` | 0.0-1.0 | 0.95 | Nucleus sampling |
| `topK` | `int` | — | — | Top-K sampling |
| `maxOutputTokens` | `int` | — | 8192 | Cada imagen consume 1290 tokens |
| `candidateCount` | `int` | 1 | 1 | **Solo 1 candidato soportado** para imagen |

### Notas criticas

- `responseModalities` es **OBLIGATORIO**. Sin el, no genera imagenes.
- `["TEXT", "IMAGE"]` permite texto + imagen (recomendado). `["IMAGE"]` fuerza solo imagen.
- `candidateCount` debe ser 1. Valores >1 causaran error.
- Cada imagen consume **exactamente 1290 tokens** de salida.

---

## 4. imageConfig parameters

**CRITICO:** `imageConfig` va EN LA RAIZ del config/body, NO dentro de `generationConfig`.

| Parametro | Tipo | Valores | Default | Descripcion |
|-----------|------|---------|---------|-------------|
| `aspectRatio` | `string` | 10 valores (ver abajo) | `"1:1"` | Relacion de aspecto |
| `imageSize` | `string` | `"1K"`, `"2K"`, `"4K"` | `"1K"` | Resolucion. **K MAYUSCULA** |

### Aspect ratios disponibles (Gemini nativo)

```
"1:1"    Cuadrado        → Feed, carrusel, X/Twitter
"2:3"    Retrato          → Pinterest
"3:2"    Paisaje ligero   → —
"3:4"    Retrato          → —
"4:3"    Paisaje          → —
"4:5"    Retrato          → Instagram Feed
"5:4"    Paisaje ligero   → —
"9:16"   Vertical         → Stories, Reels, TikTok
"16:9"   Horizontal       → YouTube, LinkedIn, Facebook post
"21:9"   Ultrawide        → Banner
```

### Resoluciones

| Valor | Resolucion aprox. | Modelos | Costo Gemini 3 Pro |
|-------|-------------------|---------|-------------------|
| `"1K"` | ~1024x1024 | Todos | — |
| `"2K"` | ~2048x2048 | Gemini 3 Pro, Imagen Standard/Ultra | ~$0.134 |
| `"4K"` | ~4096x4096 | Solo Gemini 3 Pro | ~$0.24 |

> **La K debe ser MAYUSCULA.** `"1k"`, `"2k"`, `"4k"` NO funcionan.
> No usar 4K innecesariamente — hasta **12x mas caro** que 1K.

### Ubicacion correcta en JSON REST

```json
{
  "contents": [...],
  "generationConfig": {
    "responseModalities": ["TEXT", "IMAGE"]
  },
  "imageConfig": {
    "aspectRatio": "16:9",
    "imageSize": "2K"
  }
}
```

### Ubicacion correcta en SDK Python

```python
config=types.GenerateContentConfig(
    response_modalities=["TEXT", "IMAGE"],
    image_config=types.ImageConfig(
        aspect_ratio="16:9",
        image_size="2K",
    ),
)
```

### Ubicacion correcta en SDK Node.js

```typescript
config: {
  responseModalities: ["TEXT", "IMAGE"],
  imageConfig: { aspectRatio: "16:9", imageSize: "2K" },
}
```

---

## 5. safetySettings

Configuracion opcional de filtros de seguridad:

```json
{
  "safetySettings": [
    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"}
  ]
}
```

### Valores de threshold

| Valor | Descripcion |
|-------|-------------|
| `OFF` / `BLOCK_NONE` | Desactivado |
| `BLOCK_ONLY_HIGH` | Solo bloquea alta probabilidad |
| `BLOCK_MEDIUM_AND_ABOVE` | Bloquea media+ |
| `BLOCK_LOW_AND_ABOVE` | Bloquea todo sospechoso |

> **Default para Gemini 3 Pro: `OFF`.**
> IMPORTANTE: Ajustar safetySettings NO desactiva el filtro `PROHIBITED_CONTENT`.
> Ese filtro es a nivel de modelo y no se puede configurar.

---

## 6. Tools (Google Search grounding)

Solo disponible en Gemini 3 Pro Image:

```json
{"tools": [{"google_search": {}}]}
```

```python
config=types.GenerateContentConfig(
    response_modalities=["TEXT", "IMAGE"],
    tools=[{"google_search": {}}],
)
```

Permite generar imagenes basadas en datos reales de Google Search. Util para:
- Infografias con datos actuales
- Visualizaciones de weather/stocks/sports
- Imagenes con informacion factual

---

## 7. Request JSON — text-to-image

```json
{
  "contents": [
    {
      "parts": [
        {"text": "Un restaurante elegante con decoracion futurista, iluminacion calida, estilo fotorrealista"}
      ]
    }
  ],
  "generationConfig": {
    "responseModalities": ["TEXT", "IMAGE"]
  },
  "imageConfig": {
    "aspectRatio": "16:9",
    "imageSize": "2K"
  }
}
```

---

## 8. Request JSON — con referencia

Incluir imagenes de referencia como `inlineData` ANTES del texto:

```json
{
  "contents": [
    {
      "parts": [
        {
          "inlineData": {
            "mimeType": "image/jpeg",
            "data": "<BASE64_IMAGE_DATA>"
          }
        },
        {"text": "Cambia el fondo por una playa tropical al atardecer, manten el sujeto principal intacto"}
      ]
    }
  ],
  "generationConfig": {
    "responseModalities": ["TEXT", "IMAGE"]
  }
}
```

### Multiples imagenes de referencia

Gemini 3 Pro soporta hasta 14 imagenes de referencia en un solo request:

```json
{
  "contents": [
    {
      "parts": [
        {"inlineData": {"mimeType": "image/png", "data": "<REF1_BASE64>"}},
        {"inlineData": {"mimeType": "image/png", "data": "<REF2_BASE64>"}},
        {"inlineData": {"mimeType": "image/png", "data": "<REF3_BASE64>"}},
        {"text": "Combina el estilo de las primeras dos imagenes con la composicion de la tercera"}
      ]
    }
  ],
  "generationConfig": {
    "responseModalities": ["TEXT", "IMAGE"]
  },
  "imageConfig": {
    "aspectRatio": "16:9",
    "imageSize": "2K"
  }
}
```

### Formatos de input soportados

| Formato | MIME Type | Max tamaño |
|---------|-----------|-----------|
| JPEG | `image/jpeg` | 20 MB inline |
| PNG | `image/png` | 20 MB inline |
| WebP | `image/webp` | 20 MB inline |
| GIF | `image/gif` | 20 MB inline |
| HEIC | `image/heic` | 20 MB inline |
| HEIF | `image/heif` | 20 MB inline |

> Para archivos >20MB, usar Files API: `client.files.upload()`

---

## 9. Request JSON — multi-turn

```json
{
  "contents": [
    {
      "role": "user",
      "parts": [{"text": "Crea una infografia sobre energias renovables"}]
    },
    {
      "role": "model",
      "parts": [{"inlineData": {"mimeType": "image/png", "data": "<PREVIOUS_IMAGE_BASE64>"}}]
    },
    {
      "role": "user",
      "parts": [{"text": "Cambia los colores a tonos azul marino y dorado. Traduce todo el texto al espanol."}]
    }
  ],
  "generationConfig": {
    "responseModalities": ["TEXT", "IMAGE"]
  },
  "imageConfig": {
    "aspectRatio": "16:9",
    "imageSize": "2K"
  }
}
```

> El modelo preserva el contexto visual del turno anterior.
> Usar SDK con `client.chats.create()` para multi-turn automatico.

---

## 10. Response JSON — Gemini nativo

```json
{
  "candidates": [
    {
      "content": {
        "parts": [
          {"text": "Aqui tienes la imagen del restaurante..."},
          {
            "inlineData": {
              "data": "<BASE64_ENCODED_PNG>",
              "mimeType": "image/png"
            }
          }
        ],
        "role": "model"
      },
      "finishReason": "STOP",
      "safetyRatings": [
        {"category": "HARM_CATEGORY_HARASSMENT", "probability": "NEGLIGIBLE"},
        {"category": "HARM_CATEGORY_HATE_SPEECH", "probability": "NEGLIGIBLE"},
        {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "probability": "NEGLIGIBLE"},
        {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "probability": "NEGLIGIBLE"}
      ]
    }
  ],
  "usageMetadata": {
    "promptTokenCount": 25,
    "candidatesTokenCount": 1315,
    "totalTokenCount": 1340
  }
}
```

### Extraccion de imagen

```python
# Python
for part in response.candidates[0].content.parts:
    if part.inline_data:
        img = part.as_image()  # PIL.Image
        img.save("output.png")
```

```typescript
// Node.js
for (const part of response.candidates[0].content.parts) {
  if (part.inlineData) {
    const buffer = Buffer.from(part.inlineData.data, "base64");
    fs.writeFileSync("output.png", buffer);
  }
}
```

```python
# REST (sin SDK)
import base64
for part in data["candidates"][0]["content"]["parts"]:
    if "inlineData" in part:
        img_bytes = base64.b64decode(part["inlineData"]["data"])
        with open("output.png", "wb") as f:
            f.write(img_bytes)
```

### finishReason values

| Valor | Significado |
|-------|-------------|
| `STOP` | Generacion exitosa |
| `SAFETY` | Bloqueado por filtro de seguridad |
| `IMAGE_SAFETY` | Bloqueado por filtro de imagen especifico |
| `MAX_TOKENS` | Se alcanzo el limite de tokens |
| `RECITATION` | Bloqueado por contenido potencialmente con copyright |

> **Siempre verificar finishReason ANTES de extraer la imagen.**

---

## 11. Imagen 4 predict parameters

### Endpoint

```
POST https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:predict
```

### Request

```json
{
  "instances": [
    {"prompt": "Robot holding a red skateboard in a cyberpunk city"}
  ],
  "parameters": {
    "sampleCount": 4,
    "aspectRatio": "16:9",
    "personGeneration": "allow_adult",
    "imageSize": "2K",
    "safetyFilterLevel": "block_only_high",
    "enhancePrompt": false
  }
}
```

### Parametros

| Parametro | Tipo | Valores | Default | Descripcion |
|-----------|------|---------|---------|-------------|
| `sampleCount` | `int` | 1-4 | 1 | Imagenes por request |
| `aspectRatio` | `string` | `"1:1"`, `"3:4"`, `"4:3"`, `"9:16"`, `"16:9"` | `"1:1"` | 5 opciones (menos que Gemini) |
| `personGeneration` | `string` | `"dont_allow"`, `"allow_adult"`, `"allow_all"` | `"allow_adult"` | `"allow_all"` no en EU/UK |
| `imageSize` | `string` | `"1K"`, `"2K"` | `"1K"` | Solo Standard/Ultra para 2K |
| `safetyFilterLevel` | `string` | `"block_low_and_above"`, `"block_medium_and_above"`, `"block_only_high"` | `"block_medium_and_above"` | Nivel de filtro |
| `enhancePrompt` | `boolean` | `true`/`false` | `true` | Mejora automatica del prompt |

> `enhancePrompt` puede dar resultados indeseados con prompts complejos. Desactivar para control preciso.
> `aspectRatio` en Imagen 4 solo tiene 5 opciones (vs 10 en Gemini nativo).

---

## 12. Imagen 4 response

```json
{
  "predictions": [
    {"bytesBase64Encoded": "<BASE64>", "mimeType": "image/png"},
    {"bytesBase64Encoded": "<BASE64>", "mimeType": "image/png"},
    {"bytesBase64Encoded": "<BASE64>", "mimeType": "image/png"},
    {"bytesBase64Encoded": "<BASE64>", "mimeType": "image/png"}
  ]
}
```

### Extraccion

```python
# Python con SDK
for i, img in enumerate(response.generated_images):
    img.image.save(f"output_{i}.png")

# Python con REST
import base64
for i, pred in enumerate(data["predictions"]):
    img_bytes = base64.b64decode(pred["bytesBase64Encoded"])
    with open(f"output_{i}.png", "wb") as f:
        f.write(img_bytes)
```

---

## 13. Error responses

### Estructura general de error

```json
{
  "error": {
    "code": 429,
    "message": "Resource has been exhausted (e.g. check quota).",
    "status": "RESOURCE_EXHAUSTED"
  }
}
```

### Codigos comunes

| Codigo | Status | Causa | Accion |
|--------|--------|-------|--------|
| 400 | `INVALID_ARGUMENT` | Parametros incorrectos | Verificar request |
| 403 | `PERMISSION_DENIED` | API key invalida o sin permisos | Verificar API key |
| 429 | `RESOURCE_EXHAUSTED` | Rate limit excedido | Retry con backoff |
| 500 | `INTERNAL` | Error interno del servidor | Retry |
| 503 | `UNAVAILABLE` | Modelo sobrecargado | Retry con backoff |

### Errores especificos de imagen

| Situacion | Como detectar | Accion |
|-----------|--------------|--------|
| Safety filter | `finishReason: "SAFETY"` | Reformular prompt |
| Image safety | `finishReason: "IMAGE_SAFETY"` | Reformular prompt |
| No image | Response sin `inlineData` | Verificar `responseModalities`, ser mas explicito |
| PROHIBITED_CONTENT | `finishReason` o error message | Reintentar, reformular, evitar palabras gatillo |
| Model overloaded | 503 `UNAVAILABLE` | Retry con exponential backoff |
