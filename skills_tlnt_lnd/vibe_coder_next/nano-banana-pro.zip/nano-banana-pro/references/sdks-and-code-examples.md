# SDKs and Code Examples — Nano Banana Pro Skill

Codigo completo en Python, Node.js y REST para todos los flujos: text-to-image, edicion,
multi-turn, Imagen 4, async, Batch API, error handling.

## Table of Contents

- [1. Python SDK setup](#1-python-sdk-setup)
- [2. Node.js SDK setup](#2-nodejs-sdk-setup)
- [3. Authentication](#3-authentication)
- [4. Text-to-image Python](#4-text-to-image-python)
- [5. Text-to-image Node.js](#5-text-to-image-nodejs)
- [6. Image editing Python](#6-image-editing-python)
- [7. Image editing Node.js](#7-image-editing-nodejs)
- [8. Multi-turn Python](#8-multi-turn-python)
- [9. Multi-turn Node.js](#9-multi-turn-nodejs)
- [10. Multiple ref images](#10-multiple-ref-images)
- [11. Google Search grounding](#11-google-search-grounding)
- [12. Imagen 4 Python](#12-imagen-4-python)
- [13. Async concurrente](#13-async-concurrente)
- [14. Error handling robusto](#14-error-handling-robusto)
- [15. cURL REST](#15-curl-rest)
- [16. REST sin SDK (Python requests)](#16-rest-sin-sdk-python-requests)
- [17. Batch API Python](#17-batch-api-python)

---

## 1. Python SDK setup

```bash
# Instalar SDK actual (CORRECTO)
pip install google-genai Pillow

# DEPRECATED — NO usar:
# pip install google-generativeai  ← DEPRECADO desde Nov 2025
```

```python
from google import genai
from google.genai import types
```

---

## 2. Node.js SDK setup

```bash
# Instalar SDK actual (CORRECTO)
npm install @google/genai

# DEPRECATED — NO usar:
# npm install @google/generative-ai  ← DEPRECADO desde Ago 2025
```

```typescript
import { GoogleGenAI } from "@google/genai";
import * as fs from "node:fs";
```

---

## 3. Authentication

### Python — variable de entorno (recomendado)

```python
# export GEMINI_API_KEY="tu-api-key"
client = genai.Client()  # Lee automaticamente del entorno
```

### Python — API key explicita

```python
client = genai.Client(api_key="tu-api-key-aqui")
```

### Python — Vertex AI

```python
client = genai.Client(
    vertexai=True,
    project="your-project-id",
    location="us-central1",
)
```

### Node.js

```typescript
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
```

---

## 4. Text-to-image Python

```python
from google import genai
from google.genai import types

client = genai.Client()

response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Un gato astronauta flotando en el espacio con la Tierra de fondo, "
        "estilo fotorrealista cinematografico"
    ],
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(
            aspect_ratio="16:9",
            image_size="2K",
        ),
    ),
)

for part in response.parts:
    if part.text is not None:
        print(part.text)
    elif part.inline_data is not None:
        image = part.as_image()  # Retorna PIL.Image
        image.save("output.png")
        print(f"Imagen guardada: {image.size}")
```

---

## 5. Text-to-image Node.js

```typescript
import { GoogleGenAI } from "@google/genai";
import * as fs from "node:fs";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function generateImage(prompt: string, outputPath = "output.png") {
  const response = await ai.models.generateContent({
    model: "gemini-3-pro-image-preview",
    contents: prompt,
    config: {
      responseModalities: ["TEXT", "IMAGE"],
      imageConfig: { aspectRatio: "16:9", imageSize: "2K" },
    },
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.text) console.log(part.text);
    if (part.inlineData) {
      fs.writeFileSync(outputPath, Buffer.from(part.inlineData.data, "base64"));
      console.log(`Imagen guardada: ${outputPath}`);
    }
  }
}

await generateImage("Un gato astronauta en el espacio");
```

---

## 6. Image editing Python

```python
from PIL import Image

client = genai.Client()
image_ref = Image.open("original.jpg")

response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Cambia el fondo por un atardecer en la playa. "
        "Mantener el sujeto principal exactamente igual.",
        image_ref,
    ],
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
    ),
)

for part in response.parts:
    if part.inline_data is not None:
        part.as_image().save("editado.png")
```

---

## 7. Image editing Node.js

```typescript
async function editImage(imagePath: string, editPrompt: string, outputPath: string) {
  const imageData = fs.readFileSync(imagePath).toString("base64");
  const mimeType = imagePath.endsWith(".png") ? "image/png" : "image/jpeg";

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-image-preview",
    contents: [
      { text: editPrompt },
      { inlineData: { mimeType, data: imageData } },
    ],
    config: { responseModalities: ["TEXT", "IMAGE"] },
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      fs.writeFileSync(outputPath, Buffer.from(part.inlineData.data, "base64"));
      console.log(`Editado guardado: ${outputPath}`);
    }
  }
}

await editImage("foto.jpg", "Cambia el fondo por un jardin japones", "editado.png");
```

---

## 8. Multi-turn Python

```python
client = genai.Client()

chat = client.chats.create(
    model="gemini-3-pro-image-preview",
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(
            aspect_ratio="1:1",
            image_size="2K",
        ),
    ),
)

# Turno 1: Generar
response = chat.send_message(
    "Crea un poster profesional para un festival de musica llamado 'SOLSTICE 2026'"
)
for part in response.parts:
    if part.inline_data:
        part.as_image().save("poster_v1.png")

# Turno 2: Editar colores
response = chat.send_message(
    "Cambia la paleta de colores a tonos sunset (naranja, rosa, purpura). "
    "Mantener el diseno y texto."
)
for part in response.parts:
    if part.inline_data:
        part.as_image().save("poster_v2.png")

# Turno 3: Agregar texto
response = chat.send_message(
    "Agrega '21-23 JUNIO | PARQUE CENTRAL' en la parte inferior en fuente sans-serif blanca"
)
for part in response.parts:
    if part.inline_data:
        part.as_image().save("poster_v3.png")
```

---

## 9. Multi-turn Node.js

```typescript
async function multiTurnEdit() {
  const chat = ai.chats.create({
    model: "gemini-3-pro-image-preview",
    config: {
      responseModalities: ["TEXT", "IMAGE"],
      imageConfig: { aspectRatio: "1:1", imageSize: "2K" },
    },
  });

  let response = await chat.sendMessage({
    message: "Crea un logo minimalista para una cafeteria llamada 'AROMA'",
  });
  saveImage(response, "logo_v1.png");

  response = await chat.sendMessage({
    message: "Hazlo en tonos verde oscuro y crema",
  });
  saveImage(response, "logo_v2.png");

  response = await chat.sendMessage({
    message: "Agrega una taza de cafe estilizada como icono",
  });
  saveImage(response, "logo_v3.png");
}

function saveImage(response: any, filename: string) {
  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      fs.writeFileSync(filename, Buffer.from(part.inlineData.data, "base64"));
      console.log(`Guardado: ${filename}`);
    }
  }
}
```

---

## 10. Multiple ref images

Gemini 3 Pro soporta hasta 14 imagenes de referencia:

```python
from PIL import Image

client = genai.Client()

response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Foto grupal de estas personas en un evento corporativo, "
        "sonriendo, vestimenta formal, fondo de salon elegante",
        Image.open("persona1.png"),
        Image.open("persona2.png"),
        Image.open("persona3.png"),
        Image.open("persona4.png"),
    ],
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(
            aspect_ratio="16:9",
            image_size="2K",
        ),
    ),
)

for part in response.parts:
    if part.inline_data:
        part.as_image().save("foto_grupal.png")
```

---

## 11. Google Search grounding

Solo disponible en Gemini 3 Pro Image:

```python
response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents="Visualiza el pronostico del tiempo actual para los proximos 5 dias "
             "en Ciudad de Mexico como un grafico limpio y moderno",
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(aspect_ratio="16:9", image_size="2K"),
        tools=[{"google_search": {}}],
    ),
)
```

---

## 12. Imagen 4 Python

Para text-to-image puro en volumen (endpoint `generateImages`):

```python
client = genai.Client()

response = client.models.generate_images(
    model="imagen-4.0-fast-generate-001",      # O generate-001, ultra-generate-001
    prompt="Professional product photo of wireless headphones on marble surface, "
           "dramatic studio lighting",
    config=types.GenerateImagesConfig(
        number_of_images=4,                    # 1-4 imagenes
        aspect_ratio="1:1",
        person_generation="allow_adult",
        safety_filter_level="block_only_high",
    ),
)

for i, generated_image in enumerate(response.generated_images):
    generated_image.image.save(f"imagen4_output_{i}.png")
    print(f"Guardada: imagen4_output_{i}.png")
```

> **Imagen 4 NO soporta:** edicion, multi-turn, imagenes de referencia, Batch API.
> Solo text-to-image puro.

---

## 13. Async concurrente

Para generacion paralela con control de concurrencia:

```python
import asyncio
from google import genai

client = genai.Client()

async def generate_image_async(prompt: str, filename: str, semaphore: asyncio.Semaphore):
    """Genera imagen asincronamente con semaforo de concurrencia."""
    async with semaphore:
        response = await client.aio.models.generate_content(
            model="gemini-3-pro-image-preview",
            contents=[prompt],
            config={"response_modalities": ["TEXT", "IMAGE"]},
        )
        for part in response.parts:
            if part.inline_data is not None:
                part.as_image().save(filename)
                return filename
        return None

async def main():
    sem = asyncio.Semaphore(3)  # Max 3 concurrentes (evitar rate limits)

    tasks = [
        generate_image_async("Post de Instagram sobre cafe artesanal", "ig_cafe.png", sem),
        generate_image_async("Banner de LinkedIn sobre IA", "linkedin_ai.png", sem),
        generate_image_async("Thumbnail de YouTube sobre productividad", "yt_prod.png", sem),
        generate_image_async("Story de Instagram sobre fitness", "ig_fitness.png", sem),
        generate_image_async("Post de Facebook sobre viajes", "fb_viajes.png", sem),
    ]

    results = await asyncio.gather(*tasks)
    success = [r for r in results if r]
    print(f"Generados: {len(success)}/{len(tasks)}")

asyncio.run(main())
```

---

## 14. Error handling robusto

```python
import time
import random
from google.genai.errors import APIError

def generate_with_retry(client, prompt, model="gemini-3-pro-image-preview",
                        max_retries=5, aspect_ratio="1:1"):
    """Genera imagen con exponential backoff y manejo de filtros de seguridad."""
    for attempt in range(max_retries):
        try:
            response = client.models.generate_content(
                model=model,
                contents=[prompt],
                config={
                    "response_modalities": ["TEXT", "IMAGE"],
                    "image_config": {"aspect_ratio": aspect_ratio},
                },
            )

            # Sin candidatos = filtro de seguridad
            if not response.candidates:
                return {"error": "content_filtered",
                        "message": "No candidates — filtro de seguridad activado"}

            candidate = response.candidates[0]

            # Verificar finishReason
            if candidate.finish_reason and candidate.finish_reason.name in (
                "SAFETY", "IMAGE_SAFETY"
            ):
                return {"error": "safety_filtered",
                        "message": f"Bloqueado: {candidate.finish_reason.name}"}

            # Extraer imagen
            text_response = None
            for part in response.parts:
                if part.inline_data is not None:
                    return {"success": True, "image": part.as_image(), "text": text_response}
                if part.text is not None:
                    text_response = part.text

            return {"error": "no_image",
                    "message": "Respuesta sin imagen",
                    "text": text_response}

        except APIError as e:
            if e.code == 429:  # Rate limit
                delay = (2 ** attempt) + random.uniform(0, 1)
                print(f"Rate limited, esperando {delay:.1f}s...")
                time.sleep(delay)
            elif e.code >= 500:  # Server error / overloaded
                delay = (2 ** attempt) + random.uniform(0, 0.5)
                print(f"Server error {e.code}, esperando {delay:.1f}s...")
                time.sleep(delay)
            elif e.code == 400:
                return {"error": "bad_request", "message": str(e)}
            else:
                raise

    return {"error": "max_retries", "message": f"Fallo tras {max_retries} intentos"}
```

### Uso

```python
result = generate_with_retry(client, "Un paisaje de montana al amanecer")

if result.get("success"):
    result["image"].save("output.png")
    print("Generada exitosamente")
elif result.get("error") == "safety_filtered":
    print(f"Filtro: {result['message']}")
    # Reformular prompt y reintentar
elif result.get("error") == "no_image":
    print(f"Sin imagen. Texto: {result.get('text')}")
```

---

## 15. cURL REST

### Text-to-image

```bash
curl -X POST \
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image-preview:generateContent?key=$GEMINI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "contents": [{"parts": [{"text": "Un gato astronauta en el espacio, fotorrealista"}]}],
    "generationConfig": {
      "responseModalities": ["TEXT", "IMAGE"],
      "imageConfig": {"aspectRatio": "1:1", "imageSize": "2K"}
    }
  }' | python3 -c "
import sys, json, base64
data = json.load(sys.stdin)
for part in data['candidates'][0]['content']['parts']:
    if 'inlineData' in part:
        with open('output.png', 'wb') as f:
            f.write(base64.b64decode(part['inlineData']['data']))
        print('output.png guardado')
"
```

### Con header de auth

```bash
curl -X POST \
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image-preview:generateContent" \
  -H "Content-Type: application/json" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -d '{"contents": [{"parts": [{"text": "..."}]}], ...}'
```

---

## 16. REST sin SDK (Python requests)

Patron de produccion usado en `scripts/generate-ad-creatives.py`:

```python
import os
import base64
import time
import requests
from PIL import Image
from io import BytesIO

GEMINI_API_KEY = os.environ["GEMINI_API_KEY"]
GEMINI_MODEL = "gemini-3-pro-image-preview"
GEMINI_URL = (
    f"https://generativelanguage.googleapis.com/v1beta/models/"
    f"{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}"
)


def image_to_base64(path):
    """Convierte archivo de imagen a string base64."""
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def generate_image(prompt, aspect_ratio="1:1", reference_images=None, retry=3):
    """Genera imagen con Gemini API (REST directo)."""
    parts = []

    # Imagenes de referencia primero
    if reference_images:
        for ref_path in reference_images:
            if os.path.exists(ref_path):
                mime = "image/png" if ref_path.endswith(".png") else "image/jpeg"
                parts.append({
                    "inlineData": {
                        "mimeType": mime,
                        "data": image_to_base64(ref_path),
                    }
                })

    # Prompt de texto
    parts.append({"text": prompt})

    payload = {
        "contents": [{"parts": parts}],
        "generationConfig": {
            "responseModalities": ["TEXT", "IMAGE"],
            "imageConfig": {"aspectRatio": aspect_ratio},
        },
    }

    for attempt in range(retry):
        try:
            resp = requests.post(
                GEMINI_URL,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=120,
            )

            if resp.status_code == 429:
                wait = 15 * (attempt + 1)
                print(f"Rate limited, esperando {wait}s...")
                time.sleep(wait)
                continue

            if resp.status_code != 200:
                print(f"Error {resp.status_code}: {resp.text[:300]}")
                if attempt < retry - 1:
                    time.sleep(5)
                continue

            data = resp.json()
            for candidate in data.get("candidates", []):
                for part in candidate.get("content", {}).get("parts", []):
                    inline = part.get("inlineData", {})
                    if inline.get("data"):
                        img_bytes = base64.b64decode(inline["data"])
                        return Image.open(BytesIO(img_bytes))

            print("No se encontro imagen en la respuesta")
            if attempt < retry - 1:
                time.sleep(3)

        except Exception as e:
            print(f"Excepcion: {e}")
            if attempt < retry - 1:
                time.sleep(5)

    return None
```

---

## 17. Batch API Python

```python
import time
from google import genai

client = genai.Client()

# Definir requests del batch
batch_requests = [
    {
        "contents": [
            {"parts": [{"text": f"Thumbnail para YouTube sobre {tema}"}],
             "role": "user"}
        ],
        "config": {"response_modalities": ["TEXT", "IMAGE"]}
    }
    for tema in [
        "inteligencia artificial",
        "cocina mexicana",
        "fitness en casa",
        "marketing digital",
    ]
]

# Crear batch (50% descuento)
batch_job = client.batches.create(
    model="gemini-3-pro-image-preview",
    src=batch_requests,
    config={"display_name": "thumbnails-batch"},
)

print(f"Batch creado: {batch_job.name}")

# Polling hasta completar
while True:
    batch_job = client.batches.get(name=batch_job.name)
    if batch_job.state.name in (
        "JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED"
    ):
        break
    print(f"Estado: {batch_job.state.name}")
    time.sleep(30)

# Extraer resultados
if batch_job.state.name == "JOB_STATE_SUCCEEDED":
    for i, resp in enumerate(batch_job.dest.inlined_responses):
        if resp.response:
            for part in resp.response.parts:
                if part.inline_data:
                    part.as_image().save(f"batch_{i}.png")
                    print(f"Guardada: batch_{i}.png")
        else:
            print(f"Request {i} fallo")
```
