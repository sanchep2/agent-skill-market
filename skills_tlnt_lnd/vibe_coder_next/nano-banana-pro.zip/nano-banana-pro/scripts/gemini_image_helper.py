#!/usr/bin/env python3
"""
gemini_image_helper.py — Helper de produccion para generacion de imagenes con Google Gemini.

Soporta 4 modelos:
  - Gemini 3 Pro Image (gemini-3-pro-image-preview) — modelo principal, SOTA text, 4K
  - Imagen 4 Fast (imagen-4.0-fast-generate-001) — volumen masivo, $0.02/img
  - Imagen 4 Standard (imagen-4.0-generate-001) — alta calidad, $0.04/img
  - Imagen 4 Ultra (imagen-4.0-ultra-generate-001) — maxima calidad, $0.06/img

Uso como CLI:
    # Text-to-image
    python gemini_image_helper.py generate "Un gato astronauta" -o output.png --ratio 16:9

    # Edicion con referencia
    python gemini_image_helper.py edit "Cambia el fondo" -r original.jpg -o editado.png

    # Batch generation
    python gemini_image_helper.py batch prompts.txt -o output_dir/ --ratio 1:1

    # Estimar costos
    python gemini_image_helper.py estimate --count 50 --model gemini-3-pro-image-preview --size 2K

    # Listar modelos
    python gemini_image_helper.py models

    # Multi-formato para ads
    python gemini_image_helper.py ad-set "Premium curso online ad" -o assets/

Uso como modulo:
    from gemini_image_helper import GeminiImageHelper
    helper = GeminiImageHelper()
    img = helper.generate("Un paisaje de montana", aspect_ratio="16:9")
    img.save("output.png")

Dependencias:
    pip install google-genai Pillow requests

Variables de entorno:
    GEMINI_API_KEY — API key de Google AI Studio (requerida)
"""

import argparse
import base64
import io
import json
import logging
import os
import random
import sys
import time
from dataclasses import dataclass, field
from enum import Enum
from math import gcd
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

try:
    from PIL import Image
except ImportError:
    Image = None  # type: ignore[assignment,misc]

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logger = logging.getLogger("gemini_image_helper")

# ---------------------------------------------------------------------------
# Constantes — Modelos
# ---------------------------------------------------------------------------

MODELS: Dict[str, Dict[str, Any]] = {
    "gemini-3-pro-image-preview": {
        "name": "Gemini 3 Pro Image",
        "endpoint": "generateContent",
        "price_1k": None,
        "price_2k": 0.134,
        "price_4k": 0.24,
        "batch_discount": 0.5,
        "max_refs": 14,
        "supports_editing": True,
        "supports_multi_turn": True,
        "supports_4k": True,
        "supports_batch": True,
        "max_images_per_request": 1,
    },
    "imagen-4.0-fast-generate-001": {
        "name": "Imagen 4 Fast",
        "endpoint": "generateImages",
        "price_1k": 0.02,
        "price_2k": None,
        "price_4k": None,
        "batch_discount": 0,
        "max_refs": 0,
        "supports_editing": False,
        "supports_multi_turn": False,
        "supports_4k": False,
        "supports_batch": False,
        "max_images_per_request": 4,
    },
    "imagen-4.0-generate-001": {
        "name": "Imagen 4 Standard",
        "endpoint": "generateImages",
        "price_1k": 0.04,
        "price_2k": 0.04,
        "price_4k": None,
        "batch_discount": 0,
        "max_refs": 0,
        "supports_editing": False,
        "supports_multi_turn": False,
        "supports_4k": False,
        "supports_batch": False,
        "max_images_per_request": 4,
    },
    "imagen-4.0-ultra-generate-001": {
        "name": "Imagen 4 Ultra",
        "endpoint": "generateImages",
        "price_1k": 0.06,
        "price_2k": 0.06,
        "price_4k": None,
        "batch_discount": 0,
        "max_refs": 0,
        "supports_editing": False,
        "supports_multi_turn": False,
        "supports_4k": False,
        "supports_batch": False,
        "max_images_per_request": 4,
    },
}

DEFAULT_MODEL = "gemini-3-pro-image-preview"

ASPECT_RATIOS = ["1:1", "2:3", "3:2", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9"]
IMAGEN4_RATIOS = ["1:1", "3:4", "4:3", "9:16", "16:9"]

IMAGE_SIZES = ["1K", "2K", "4K"]

# ---------------------------------------------------------------------------
# Constantes — Presets de formatos publicitarios
# ---------------------------------------------------------------------------

AD_FORMATS: Dict[str, Dict[str, Any]] = {
    "landscape": {"ratio": "16:9", "width": 1920, "height": 1080},
    "square": {"ratio": "1:1", "width": 1080, "height": 1080},
    "vertical": {"ratio": "9:16", "width": 1080, "height": 1920},
    "portrait": {"ratio": "4:5", "width": 1080, "height": 1350},
    "facebook": {"ratio": "16:9", "width": 1200, "height": 628},
    "pinterest": {"ratio": "2:3", "width": 1000, "height": 1500},
}

# ---------------------------------------------------------------------------
# Constantes — API base URL
# ---------------------------------------------------------------------------

GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta"

# ---------------------------------------------------------------------------
# Excepciones
# ---------------------------------------------------------------------------


class GeminiImageError(Exception):
    """Error base para operaciones de generacion de imagen con Gemini."""

    def __init__(self, message: str, code: int = 0,
                 model: str = "", retryable: bool = False) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.model = model
        self.retryable = retryable

    def __str__(self) -> str:
        return f"[{self.model or 'gemini'}] {self.code}: {self.message}"


class SafetyFilterError(GeminiImageError):
    """La peticion fue rechazada por filtros de seguridad."""

    def __init__(self, message: str = "Contenido bloqueado por filtros de seguridad",
                 model: str = "") -> None:
        super().__init__(message, code=400, model=model, retryable=False)


class RateLimitError(GeminiImageError):
    """Se ha excedido el rate limit de la API."""

    def __init__(self, message: str = "Rate limit excedido (429)",
                 model: str = "", retry_after: float = 0.0) -> None:
        super().__init__(message, code=429, model=model, retryable=True)
        self.retry_after = retry_after


# ---------------------------------------------------------------------------
# Dataclass de resultado
# ---------------------------------------------------------------------------


@dataclass
class GenerationResult:
    """Resultado de una operacion de generacion de imagen."""
    image: Any  # PIL.Image.Image o None
    model: str
    cost: float
    aspect_ratio: str
    image_size: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def save(self, path: str, fmt: str = "PNG") -> str:
        """Guarda la imagen en disco. Retorna la ruta absoluta."""
        if self.image is None:
            raise GeminiImageError("No hay imagen para guardar")
        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)
        self.image.save(str(out), format=fmt)
        logger.info("Imagen guardada: %s", out)
        return str(out.resolve())


# ---------------------------------------------------------------------------
# CircuitBreaker
# ---------------------------------------------------------------------------


class CircuitState(Enum):
    """Estados del circuit breaker."""
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Circuit breaker para proteger contra fallos en cascada con la API.

    Tres estados:
      - CLOSED: operacion normal, se cuentan fallos.
      - OPEN: tras alcanzar failure_threshold, se bloquean peticiones
              durante recovery_timeout segundos.
      - HALF_OPEN: tras expirar el timeout, se permite 1 peticion de prueba.
                   Si tiene exito -> CLOSED. Si falla -> OPEN de nuevo.
    """

    def __init__(self, failure_threshold: int = 5,
                 recovery_timeout: float = 60.0) -> None:
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._last_failure_time: float = 0.0
        self._success_count = 0

    @property
    def state(self) -> CircuitState:
        """Estado actual del circuit breaker."""
        if self._state == CircuitState.OPEN:
            elapsed = time.monotonic() - self._last_failure_time
            if elapsed >= self.recovery_timeout:
                self._state = CircuitState.HALF_OPEN
                logger.info("CircuitBreaker -> HALF_OPEN (timeout expirado)")
        return self._state

    def can_execute(self) -> bool:
        """Retorna True si se puede ejecutar una peticion."""
        current = self.state
        if current == CircuitState.CLOSED:
            return True
        if current == CircuitState.HALF_OPEN:
            return True
        return False

    def record_success(self) -> None:
        """Registra una peticion exitosa."""
        self._failure_count = 0
        self._success_count += 1
        if self._state == CircuitState.HALF_OPEN:
            self._state = CircuitState.CLOSED
            logger.info("CircuitBreaker -> CLOSED (peticion exitosa)")

    def record_failure(self) -> None:
        """Registra una peticion fallida."""
        self._failure_count += 1
        self._last_failure_time = time.monotonic()
        self._success_count = 0
        if self._failure_count >= self.failure_threshold:
            self._state = CircuitState.OPEN
            logger.warning(
                "CircuitBreaker -> OPEN (fallos=%d, threshold=%d, recovery=%.0fs)",
                self._failure_count, self.failure_threshold, self.recovery_timeout
            )

    def reset(self) -> None:
        """Reinicia el circuit breaker a su estado inicial."""
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time = 0.0

    def __repr__(self) -> str:
        return (f"CircuitBreaker(state={self.state.value}, "
                f"failures={self._failure_count}/{self.failure_threshold})")


# ---------------------------------------------------------------------------
# Funciones auxiliares (nivel de modulo)
# ---------------------------------------------------------------------------


def image_to_base64(path: str) -> str:
    """Convierte un archivo de imagen a string base64.

    Soporta jpg, jpeg, png, webp y gif.
    """
    img_path = Path(path)
    if not img_path.is_file():
        raise FileNotFoundError(f"Imagen no encontrada: {path}")
    with open(img_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def _mime_for_path(path: str) -> str:
    """Retorna el MIME type adecuado para una ruta de imagen."""
    ext = Path(path).suffix.lower().lstrip(".")
    mapping = {
        "jpg": "image/jpeg", "jpeg": "image/jpeg",
        "png": "image/png", "webp": "image/webp",
        "gif": "image/gif",
    }
    return mapping.get(ext, "image/jpeg")


def resize_and_crop(img: "Image.Image", target_w: int, target_h: int) -> "Image.Image":
    """Redimensiona y recorta al centro una imagen PIL al tamano exacto.

    Algoritmo:
      1. Escalar la imagen para que cubra completamente el area objetivo
         (manteniendo la proporcion original).
      2. Recortar desde el centro al tamano final.
    """
    if Image is None:
        raise ImportError("Pillow es requerido: pip install Pillow")
    orig_w, orig_h = img.size
    scale = max(target_w / orig_w, target_h / orig_h)
    new_w = int(orig_w * scale)
    new_h = int(orig_h * scale)
    resized = img.resize((new_w, new_h), Image.LANCZOS)  # type: ignore[attr-defined]
    left = (new_w - target_w) // 2
    top = (new_h - target_h) // 2
    right = left + target_w
    bottom = top + target_h
    return resized.crop((left, top, right, bottom))


def _extract_image_from_response(data: Dict[str, Any]) -> Optional["Image.Image"]:
    """Extrae una PIL.Image de la respuesta JSON de Gemini generateContent.

    Busca inlineData en candidates[0].content.parts[].
    Retorna None si no se encuentra imagen.
    """
    if Image is None:
        raise ImportError("Pillow es requerido: pip install Pillow")
    candidates = data.get("candidates", [])
    if not candidates:
        return None
    parts = candidates[0].get("content", {}).get("parts", [])
    for part in parts:
        inline = part.get("inlineData")
        if inline and "data" in inline:
            img_bytes = base64.b64decode(inline["data"])
            return Image.open(io.BytesIO(img_bytes))
    return None


def _extract_text_from_response(data: Dict[str, Any]) -> str:
    """Extrae texto de la respuesta JSON de Gemini generateContent."""
    candidates = data.get("candidates", [])
    if not candidates:
        return ""
    parts = candidates[0].get("content", {}).get("parts", [])
    texts = []
    for part in parts:
        if "text" in part:
            texts.append(part["text"])
    return "\n".join(texts)


def _extract_imagen4_images(data: Dict[str, Any]) -> List["Image.Image"]:
    """Extrae PIL.Images de la respuesta JSON de Imagen 4 generateImages."""
    if Image is None:
        raise ImportError("Pillow es requerido: pip install Pillow")
    images = []
    generated = data.get("generatedImages", data.get("predictions", []))
    for entry in generated:
        img_data = entry.get("image", {})
        b64 = img_data.get("imageBytes", img_data.get("bytesBase64Encoded", ""))
        if not b64:
            b64 = entry.get("bytesBase64Encoded", "")
        if b64:
            img_bytes = base64.b64decode(b64)
            images.append(Image.open(io.BytesIO(img_bytes)))
    return images


def _check_safety_block(data: Dict[str, Any]) -> bool:
    """Verifica si la respuesta fue bloqueada por filtros de seguridad."""
    # generateContent: promptFeedback.blockReason
    feedback = data.get("promptFeedback", {})
    if feedback.get("blockReason"):
        return True
    # candidates con finishReason SAFETY
    for cand in data.get("candidates", []):
        if cand.get("finishReason") == "SAFETY":
            return True
    # generateImages: filteredReason
    if data.get("filteredReason"):
        return True
    return False


# ---------------------------------------------------------------------------
# Clase principal
# ---------------------------------------------------------------------------


class GeminiImageHelper:
    """Helper de produccion para generacion de imagenes con Google Gemini.

    Soporta los 4 modelos de generacion de imagen de Google:
      - Gemini 3 Pro Image (text-to-image, edicion, multi-turn, 4K)
      - Imagen 4 Fast, Standard y Ultra (text-to-image puro, alto volumen)

    Caracteristicas:
      - Retry con exponential backoff + jitter
      - Circuit breaker por modelo
      - Soporte para imagenes de referencia (hasta 14 en Gemini 3 Pro)
      - Multi-turn conversation para edicion iterativa
      - Generacion multi-formato para ads (landscape, square, vertical, etc.)
      - Estimacion de costos
      - CLI integrado
    """

    # Constantes de retry
    _MAX_RETRIES: int = 4
    _BASE_DELAY: float = 1.0
    _MAX_DELAY: float = 60.0
    _JITTER_RANGE: float = 0.5

    # Delay entre peticiones batch (rate limiting)
    _BATCH_DELAY: float = 1.5

    def __init__(self, api_key: Optional[str] = None,
                 default_model: str = DEFAULT_MODEL) -> None:
        """Inicializa el helper.

        Args:
            api_key: API key de Google AI Studio. Si es None, lee de GEMINI_API_KEY.
            default_model: Modelo por defecto para generacion.
        """
        self.api_key = api_key or os.getenv("GEMINI_API_KEY", "")
        if not self.api_key:
            logger.warning("GEMINI_API_KEY no configurada — las peticiones fallaran")
        if default_model not in MODELS:
            raise ValueError(f"Modelo no soportado: {default_model}. "
                             f"Opciones: {list(MODELS.keys())}")
        self.default_model = default_model
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json",
            "User-Agent": "GeminiImageHelper/1.0",
        })
        # Circuit breakers por modelo
        self._breakers: Dict[str, CircuitBreaker] = {
            model_id: CircuitBreaker(failure_threshold=5, recovery_timeout=60.0)
            for model_id in MODELS
        }
        # Estadisticas de uso
        self._stats: Dict[str, Any] = {
            "total_requests": 0,
            "total_cost": 0.0,
            "by_model": {},
            "errors": 0,
        }
        self._connect_timeout: float = 15.0
        self._read_timeout: float = 120.0
        logger.info("GeminiImageHelper inicializado — modelo=%s", default_model)

    # ==================================================================
    # METODOS PRIVADOS — Red y retry
    # ==================================================================

    def _build_url(self, model_id: str, endpoint: str) -> str:
        """Construye la URL completa para un modelo y endpoint."""
        return f"{GEMINI_API_BASE}/models/{model_id}:{endpoint}?key={self.api_key}"

    def _delay_with_jitter(self, attempt: int) -> float:
        """Calcula el delay con exponential backoff + jitter."""
        base = self._BASE_DELAY * (2 ** attempt)
        capped = min(base, self._MAX_DELAY)
        jitter = random.uniform(-self._JITTER_RANGE, self._JITTER_RANGE) * capped
        return max(0.1, capped + jitter)

    def _request_with_retry(self, method: str, url: str,
                            body: Optional[Dict[str, Any]],
                            model_id: str) -> Dict[str, Any]:
        """Ejecuta una peticion HTTP con retry, backoff y circuit breaker.

        Maneja:
          - 429 Too Many Requests -> retry con backoff
          - 503 Service Unavailable -> retry con backoff
          - 500 Internal Server Error -> retry con backoff
          - 400 con safety filter -> SafetyFilterError (no retry)
          - Otros errores -> GeminiImageError

        Returns:
            Dict con la respuesta JSON parseada.
        """
        breaker = self._breakers.get(model_id)
        if breaker and not breaker.can_execute():
            raise GeminiImageError(
                f"Circuit breaker ABIERTO para {model_id}. "
                f"Reintentando en {breaker.recovery_timeout}s.",
                code=503, model=model_id, retryable=True
            )

        last_error: Optional[Exception] = None
        self._stats["total_requests"] += 1

        for attempt in range(self._MAX_RETRIES):
            try:
                if method.upper() == "POST":
                    resp = self.session.post(
                        url, json=body,
                        timeout=(self._connect_timeout, self._read_timeout)
                    )
                else:
                    resp = self.session.get(
                        url,
                        timeout=(self._connect_timeout, self._read_timeout)
                    )

                # Exito
                if resp.status_code == 200:
                    data = resp.json()
                    # Verificar bloqueo por seguridad
                    if _check_safety_block(data):
                        if breaker:
                            breaker.record_success()
                        raise SafetyFilterError(model=model_id)
                    if breaker:
                        breaker.record_success()
                    return data

                # Rate limit (429) — siempre reintentar
                if resp.status_code == 429:
                    retry_after = float(resp.headers.get("Retry-After", 0))
                    delay = max(retry_after, self._delay_with_jitter(attempt))
                    logger.warning(
                        "[%s] 429 Rate limit — intento %d/%d, esperando %.1fs",
                        model_id, attempt + 1, self._MAX_RETRIES, delay
                    )
                    time.sleep(delay)
                    last_error = RateLimitError(model=model_id, retry_after=delay)
                    continue

                # Server error (500, 503) — reintentar
                if resp.status_code in (500, 502, 503):
                    delay = self._delay_with_jitter(attempt)
                    logger.warning(
                        "[%s] %d Server error — intento %d/%d, esperando %.1fs",
                        model_id, resp.status_code, attempt + 1,
                        self._MAX_RETRIES, delay
                    )
                    time.sleep(delay)
                    last_error = GeminiImageError(
                        f"Server error: {resp.status_code}",
                        code=resp.status_code, model=model_id, retryable=True
                    )
                    continue

                # Error 400 — verificar si es safety filter
                if resp.status_code == 400:
                    try:
                        err_data = resp.json()
                    except (json.JSONDecodeError, ValueError):
                        err_data = {}
                    err_msg = err_data.get("error", {}).get("message", resp.text[:500])
                    lower_msg = err_msg.lower()
                    if "safety" in lower_msg or "blocked" in lower_msg:
                        if breaker:
                            breaker.record_success()
                        raise SafetyFilterError(
                            message=f"Safety filter: {err_msg}", model=model_id
                        )
                    # Otro error 400 — no reintentar
                    if breaker:
                        breaker.record_failure()
                    raise GeminiImageError(
                        f"Bad request: {err_msg}",
                        code=400, model=model_id, retryable=False
                    )

                # Otros codigos de error
                try:
                    err_data = resp.json()
                    err_msg = err_data.get("error", {}).get("message", resp.text[:500])
                except (json.JSONDecodeError, ValueError):
                    err_msg = resp.text[:500]
                if breaker:
                    breaker.record_failure()
                raise GeminiImageError(
                    f"HTTP {resp.status_code}: {err_msg}",
                    code=resp.status_code, model=model_id, retryable=False
                )

            except requests.exceptions.Timeout:
                delay = self._delay_with_jitter(attempt)
                logger.warning(
                    "[%s] Timeout — intento %d/%d, esperando %.1fs",
                    model_id, attempt + 1, self._MAX_RETRIES, delay
                )
                time.sleep(delay)
                last_error = GeminiImageError(
                    "Request timeout", code=408, model=model_id, retryable=True
                )
                continue

            except requests.exceptions.ConnectionError as exc:
                delay = self._delay_with_jitter(attempt)
                logger.warning(
                    "[%s] Connection error — intento %d/%d: %s",
                    model_id, attempt + 1, self._MAX_RETRIES, str(exc)[:200]
                )
                time.sleep(delay)
                last_error = GeminiImageError(
                    f"Connection error: {exc}", code=0, model=model_id, retryable=True
                )
                continue

        # Agotados todos los reintentos
        self._stats["errors"] += 1
        if breaker:
            breaker.record_failure()
        if last_error:
            raise last_error
        raise GeminiImageError(
            f"Agotados {self._MAX_RETRIES} reintentos", code=0, model=model_id
        )

    # ==================================================================
    # METODOS PRIVADOS — Construccion de payloads
    # ==================================================================

    def _build_reference_parts(
        self, reference_images: Optional[List[str]]
    ) -> List[Dict[str, Any]]:
        """Construye las parts con imagenes de referencia en formato inlineData."""
        parts: List[Dict[str, Any]] = []
        if not reference_images:
            return parts
        for ref_path in reference_images:
            p = Path(ref_path)
            if not p.is_file():
                logger.warning("Imagen de referencia no encontrada: %s", ref_path)
                continue
            b64 = image_to_base64(ref_path)
            mime = _mime_for_path(ref_path)
            parts.append({
                "inlineData": {"mimeType": mime, "data": b64}
            })
        return parts

    def _resolve_model(self, model: Optional[str]) -> str:
        """Resuelve el modelo a usar (default si es None)."""
        if model is None:
            return self.default_model
        if model not in MODELS:
            raise ValueError(f"Modelo no soportado: {model}. "
                             f"Opciones: {list(MODELS.keys())}")
        return model

    def _validate_aspect_ratio(self, ratio: str, model_id: str) -> str:
        """Valida y normaliza el aspect ratio para el modelo dado."""
        # Imagen 4 solo soporta un subconjunto
        if model_id.startswith("imagen-4"):
            if ratio not in IMAGEN4_RATIOS:
                closest = min(IMAGEN4_RATIOS,
                              key=lambda r: abs(_ratio_to_float(r) - _ratio_to_float(ratio)))
                logger.info("Ratio %s no soportado por %s, usando %s",
                            ratio, model_id, closest)
                return closest
            return ratio
        # Gemini 3 Pro soporta todos
        if ratio not in ASPECT_RATIOS:
            logger.warning("Ratio %s no reconocido, usando 1:1", ratio)
            return "1:1"
        return ratio

    def _resolve_image_size(self, image_size: Optional[str],
                            model_id: str) -> Optional[str]:
        """Resuelve el tamano de imagen para Gemini 3 Pro."""
        cfg = MODELS[model_id]
        if not cfg["supports_4k"]:
            return None
        if image_size is None:
            return "2K"
        if image_size not in IMAGE_SIZES:
            logger.warning("Tamano %s no reconocido, usando 2K", image_size)
            return "2K"
        return image_size

    # ==================================================================
    # METODOS PUBLICOS — Generacion
    # ==================================================================

    def generate(
        self,
        prompt: str,
        aspect_ratio: str = "1:1",
        image_size: Optional[str] = None,
        model: Optional[str] = None,
        reference_images: Optional[List[str]] = None,
    ) -> Optional["Image.Image"]:
        """Genera una imagen a partir de un prompt de texto.

        Usa Gemini 3 Pro Image por defecto. Soporta imagenes de referencia
        (hasta 14) y tamanos 1K/2K/4K.

        Args:
            prompt: Descripcion textual de la imagen a generar.
            aspect_ratio: Proporcion de la imagen (ej: "16:9", "1:1").
            image_size: Tamano: "1K", "2K" o "4K". Solo Gemini 3 Pro.
            model: ID del modelo. Si None, usa el modelo por defecto.
            reference_images: Lista de rutas a imagenes de referencia.

        Returns:
            PIL.Image.Image o None si la generacion fallo.
        """
        if Image is None:
            raise ImportError("Pillow es requerido: pip install Pillow")

        model_id = self._resolve_model(model)
        cfg = MODELS[model_id]

        # Si es Imagen 4, delegar al metodo especifico
        if cfg["endpoint"] == "generateImages":
            images = self.generate_imagen4(
                prompt=prompt, model=model_id,
                num_images=1, aspect_ratio=aspect_ratio
            )
            return images[0] if images else None

        # Gemini 3 Pro Image — generateContent
        ratio = self._validate_aspect_ratio(aspect_ratio, model_id)
        size = self._resolve_image_size(image_size, model_id)

        # Construir parts
        parts: List[Dict[str, Any]] = []

        # Imagenes de referencia
        if reference_images:
            max_refs = cfg["max_refs"]
            if len(reference_images) > max_refs:
                logger.warning("Maximo %d refs para %s, truncando",
                               max_refs, model_id)
                reference_images = reference_images[:max_refs]
            parts.extend(self._build_reference_parts(reference_images))

        parts.append({"text": prompt})

        # Body
        body: Dict[str, Any] = {
            "contents": [{"parts": parts}],
            "generationConfig": {
                "responseModalities": ["IMAGE", "TEXT"],
            },
        }

        # imageConfig solo si Gemini 3 Pro
        image_config: Dict[str, Any] = {"aspectRatio": ratio}
        if size:
            image_config["imageSize"] = size
        body["imageConfig"] = image_config

        url = self._build_url(model_id, "generateContent")
        logger.info("Generando con %s — ratio=%s, size=%s, refs=%d",
                     model_id, ratio, size or "default",
                     len(reference_images) if reference_images else 0)

        data = self._request_with_retry("POST", url, body, model_id)

        img = _extract_image_from_response(data)
        if img is None:
            text = _extract_text_from_response(data)
            if text:
                logger.warning("Respuesta solo texto (sin imagen): %s", text[:200])
            return None

        # Registrar costo
        price = self._get_price(model_id, size)
        self._record_cost(model_id, price)

        return img

    def edit(
        self,
        prompt: str,
        reference_image_path: str,
        aspect_ratio: Optional[str] = None,
        image_size: Optional[str] = None,
    ) -> Optional["Image.Image"]:
        """Edita una imagen existente usando Gemini 3 Pro Image.

        Envia la imagen original como referencia junto con instrucciones
        de edicion en el prompt.

        Args:
            prompt: Instruccion de edicion (ej: "Cambia el fondo a azul").
            reference_image_path: Ruta a la imagen a editar.
            aspect_ratio: Ratio del resultado. Si None, mantiene el original.
            image_size: Tamano de salida: "1K", "2K" o "4K".

        Returns:
            PIL.Image.Image editada o None si fallo.
        """
        model_id = "gemini-3-pro-image-preview"
        cfg = MODELS[model_id]

        if not cfg["supports_editing"]:
            raise GeminiImageError(
                "El modelo no soporta edicion", model=model_id
            )

        if not Path(reference_image_path).is_file():
            raise FileNotFoundError(
                f"Imagen de referencia no encontrada: {reference_image_path}"
            )

        # Detectar aspect ratio original si no se especifica
        if aspect_ratio is None:
            if Image is not None:
                with Image.open(reference_image_path) as orig:
                    w, h = orig.size
                aspect_ratio = _dimensions_to_ratio(w, h)
            else:
                aspect_ratio = "1:1"

        ratio = self._validate_aspect_ratio(aspect_ratio, model_id)
        size = self._resolve_image_size(image_size, model_id)

        # Construir parts: imagen + instruccion
        ref_b64 = image_to_base64(reference_image_path)
        mime = _mime_for_path(reference_image_path)

        parts: List[Dict[str, Any]] = [
            {"inlineData": {"mimeType": mime, "data": ref_b64}},
            {"text": prompt},
        ]

        body: Dict[str, Any] = {
            "contents": [{"parts": parts}],
            "generationConfig": {
                "responseModalities": ["IMAGE", "TEXT"],
            },
            "imageConfig": {"aspectRatio": ratio},
        }
        if size:
            body["imageConfig"]["imageSize"] = size

        url = self._build_url(model_id, "generateContent")
        logger.info("Editando con %s — ratio=%s, size=%s", model_id, ratio, size or "default")

        data = self._request_with_retry("POST", url, body, model_id)

        img = _extract_image_from_response(data)
        if img is None:
            text = _extract_text_from_response(data)
            logger.warning("Edicion sin imagen — texto: %s", text[:200] if text else "(vacio)")
            return None

        price = self._get_price(model_id, size)
        self._record_cost(model_id, price)

        return img

    def multi_turn(
        self,
        prompts: List[str],
        aspect_ratio: str = "1:1",
        image_size: Optional[str] = None,
    ) -> List[Optional["Image.Image"]]:
        """Envia multiples prompts en secuencia (multi-turn conversation).

        Cada prompt se envia como un turno nuevo de la conversacion,
        manteniendo el historial completo (texto + imagenes generadas).
        Solo Gemini 3 Pro soporta multi-turn.

        Args:
            prompts: Lista de prompts en orden secuencial.
            aspect_ratio: Ratio comun para todas las imagenes.
            image_size: Tamano de salida.

        Returns:
            Lista de PIL.Image.Image (o None por turno si no hubo imagen).
        """
        model_id = "gemini-3-pro-image-preview"
        cfg = MODELS[model_id]

        if not cfg["supports_multi_turn"]:
            raise GeminiImageError(
                "Multi-turn no soportado por este modelo", model=model_id
            )
        if Image is None:
            raise ImportError("Pillow es requerido: pip install Pillow")

        ratio = self._validate_aspect_ratio(aspect_ratio, model_id)
        size = self._resolve_image_size(image_size, model_id)

        # Historial de contenidos (user + model alternando)
        contents: List[Dict[str, Any]] = []
        results: List[Optional["Image.Image"]] = []

        for i, prompt_text in enumerate(prompts):
            # Agregar turno del usuario
            contents.append({
                "role": "user",
                "parts": [{"text": prompt_text}],
            })

            body: Dict[str, Any] = {
                "contents": contents,
                "generationConfig": {
                    "responseModalities": ["IMAGE", "TEXT"],
                },
                "imageConfig": {"aspectRatio": ratio},
            }
            if size:
                body["imageConfig"]["imageSize"] = size

            url = self._build_url(model_id, "generateContent")
            logger.info("Multi-turn turno %d/%d: '%s...'",
                         i + 1, len(prompts), prompt_text[:60])

            data = self._request_with_retry("POST", url, body, model_id)

            # Extraer respuesta del modelo y agregarla al historial
            candidates = data.get("candidates", [])
            if candidates:
                model_content = candidates[0].get("content", {})
                model_content["role"] = "model"
                contents.append(model_content)

            img = _extract_image_from_response(data)
            results.append(img)

            price = self._get_price(model_id, size)
            self._record_cost(model_id, price)

            # Rate limiting entre turnos
            if i < len(prompts) - 1:
                time.sleep(self._BATCH_DELAY)

        return results

    def generate_imagen4(
        self,
        prompt: str,
        model: str = "imagen-4.0-fast-generate-001",
        num_images: int = 1,
        aspect_ratio: str = "1:1",
    ) -> List["Image.Image"]:
        """Genera imagenes usando Imagen 4 (Fast, Standard o Ultra).

        Usa el endpoint generateImages, diferente al generateContent de Gemini 3 Pro.

        Args:
            prompt: Descripcion textual de la imagen.
            model: ID del modelo Imagen 4.
            num_images: Cantidad de imagenes (1-4).
            aspect_ratio: Proporcion de la imagen.

        Returns:
            Lista de PIL.Image.Image generadas.
        """
        if Image is None:
            raise ImportError("Pillow es requerido: pip install Pillow")

        model_id = self._resolve_model(model)
        cfg = MODELS[model_id]

        if cfg["endpoint"] != "generateImages":
            raise GeminiImageError(
                f"{model_id} no usa generateImages", model=model_id
            )

        ratio = self._validate_aspect_ratio(aspect_ratio, model_id)
        num_images = max(1, min(num_images, cfg["max_images_per_request"]))

        body: Dict[str, Any] = {
            "instances": [{"prompt": prompt}],
            "parameters": {
                "sampleCount": num_images,
                "aspectRatio": ratio,
            },
        }

        url = self._build_url(model_id, "generateImages")
        logger.info("Imagen 4 — model=%s, count=%d, ratio=%s",
                     model_id, num_images, ratio)

        data = self._request_with_retry("POST", url, body, model_id)

        images = _extract_imagen4_images(data)
        if not images:
            logger.warning("Imagen 4: sin imagenes en la respuesta")

        # Costo por imagen
        price_key = "price_1k"
        unit_price = cfg.get(price_key) or 0.0
        total_price = unit_price * len(images)
        self._record_cost(model_id, total_price)

        return images

    def generate_ad_set(
        self,
        prompt: str,
        output_dir: str,
        formats: Optional[List[str]] = None,
        image_size: Optional[str] = None,
        reference_images: Optional[List[str]] = None,
    ) -> Dict[str, str]:
        """Genera un set completo de creatividades publicitarias multi-formato.

        Para cada formato (landscape, square, vertical, etc.) genera una imagen
        con el aspect ratio correspondiente y la guarda en el directorio de salida.

        Args:
            prompt: Prompt base para todas las variantes.
            output_dir: Directorio donde guardar las imagenes.
            formats: Lista de nombres de formato (keys de AD_FORMATS).
                     Si None, genera todos los formatos.
            image_size: Tamano de imagen (solo Gemini 3 Pro).
            reference_images: Imagenes de referencia opcionales.

        Returns:
            Dict con nombre_formato -> ruta_archivo.
        """
        out_path = Path(output_dir)
        out_path.mkdir(parents=True, exist_ok=True)

        if formats is None:
            formats = list(AD_FORMATS.keys())
        else:
            # Validar formatos
            valid = []
            for f in formats:
                if f in AD_FORMATS:
                    valid.append(f)
                else:
                    logger.warning("Formato de ad no reconocido: %s", f)
            formats = valid if valid else list(AD_FORMATS.keys())

        results: Dict[str, str] = {}

        for i, fmt_name in enumerate(formats):
            fmt = AD_FORMATS[fmt_name]
            ratio = fmt["ratio"]
            target_w = fmt["width"]
            target_h = fmt["height"]

            logger.info("Ad set — formato %s (%dx%d, %s) [%d/%d]",
                         fmt_name, target_w, target_h, ratio,
                         i + 1, len(formats))

            img = self.generate(
                prompt=prompt,
                aspect_ratio=ratio,
                image_size=image_size,
                reference_images=reference_images,
            )

            if img is not None:
                # Redimensionar al tamano exacto del formato
                final = resize_and_crop(img, target_w, target_h)
                filename = f"ad_{fmt_name}_{target_w}x{target_h}.png"
                filepath = out_path / filename
                final.save(str(filepath), format="PNG")
                results[fmt_name] = str(filepath.resolve())
                logger.info("Guardado: %s", filepath)
            else:
                logger.warning("No se pudo generar formato %s", fmt_name)

            # Rate limiting entre formatos
            if i < len(formats) - 1:
                time.sleep(self._BATCH_DELAY)

        return results

    def batch_generate(
        self,
        prompts: List[str],
        aspect_ratio: str = "1:1",
        image_size: Optional[str] = None,
    ) -> List[Optional["Image.Image"]]:
        """Genera multiples imagenes secuencialmente con rate limiting.

        Cada prompt se procesa de forma independiente (no es multi-turn).

        Args:
            prompts: Lista de prompts a generar.
            aspect_ratio: Ratio comun para todas las imagenes.
            image_size: Tamano de salida.

        Returns:
            Lista de PIL.Image.Image (o None si algun prompt fallo).
        """
        results: List[Optional["Image.Image"]] = []
        total = len(prompts)

        for i, prompt in enumerate(prompts):
            logger.info("Batch %d/%d: '%s...'", i + 1, total, prompt[:60])
            try:
                img = self.generate(
                    prompt=prompt,
                    aspect_ratio=aspect_ratio,
                    image_size=image_size,
                )
                results.append(img)
            except GeminiImageError as exc:
                logger.error("Batch %d/%d fallo: %s", i + 1, total, exc)
                results.append(None)
            except Exception as exc:
                logger.error("Batch %d/%d error inesperado: %s", i + 1, total, exc)
                results.append(None)

            # Rate limiting entre generaciones
            if i < total - 1:
                time.sleep(self._BATCH_DELAY)

        success = sum(1 for r in results if r is not None)
        logger.info("Batch completo: %d/%d exitosos", success, total)
        return results

    # ==================================================================
    # SELECCION DE MODELO
    # ==================================================================

    def select_model(
        self,
        needs_editing: bool = False,
        needs_text: bool = False,
        needs_refs: bool = False,
        needs_4k: bool = False,
        volume_mode: bool = False,
        max_quality: bool = False,
    ) -> str:
        """Selecciona el modelo optimo segun los requisitos.

        Logica de seleccion:
          - Edicion, multi-turn, refs, 4K, texto -> Gemini 3 Pro (unico que soporta)
          - Volumen masivo, bajo costo -> Imagen 4 Fast
          - Maxima calidad sin edicion -> Imagen 4 Ultra
          - Balance calidad/precio -> Imagen 4 Standard

        Args:
            needs_editing: Requiere edicion de imagen existente.
            needs_text: Requiere renderizado de texto preciso.
            needs_refs: Requiere imagenes de referencia.
            needs_4k: Requiere resolucion 4K.
            volume_mode: Prioriza bajo costo y alto volumen.
            max_quality: Prioriza maxima calidad visual.

        Returns:
            ID del modelo recomendado.
        """
        # Gemini 3 Pro es obligatorio si necesita features avanzadas
        if needs_editing or needs_text or needs_refs or needs_4k:
            return "gemini-3-pro-image-preview"

        # Volumen masivo -> Fast
        if volume_mode:
            return "imagen-4.0-fast-generate-001"

        # Maxima calidad -> Ultra
        if max_quality:
            return "imagen-4.0-ultra-generate-001"

        # Default: Gemini 3 Pro (mejor balance general)
        return "gemini-3-pro-image-preview"

    # ==================================================================
    # ESTIMACION DE COSTOS
    # ==================================================================

    def estimate_cost(
        self,
        count: int,
        model: Optional[str] = None,
        image_size: str = "2K",
        use_batch: bool = False,
    ) -> Dict[str, Any]:
        """Estima el costo de generar N imagenes.

        Args:
            count: Numero de imagenes a generar.
            model: ID del modelo. Si None, usa el default.
            image_size: Tamano de imagen (para calcular precio).
            use_batch: Si True, aplica descuento de Batch API (solo Gemini 3 Pro).

        Returns:
            Dict con desglose de costos: modelo, precio unitario,
            total, descuento batch, etc.
        """
        model_id = self._resolve_model(model)
        cfg = MODELS[model_id]

        unit_price = self._get_price(model_id, image_size)
        total_price = unit_price * count

        batch_discount = 0.0
        batch_total = total_price
        if use_batch and cfg["batch_discount"] > 0:
            batch_discount = cfg["batch_discount"]
            batch_total = total_price * (1.0 - batch_discount)

        return {
            "model": model_id,
            "model_name": cfg["name"],
            "count": count,
            "image_size": image_size,
            "unit_price_usd": round(unit_price, 4),
            "total_price_usd": round(total_price, 4),
            "batch_api": use_batch,
            "batch_discount_pct": round(batch_discount * 100, 1),
            "batch_total_usd": round(batch_total, 4),
            "supports_batch": cfg["supports_batch"],
        }

    # ==================================================================
    # ESTADISTICAS
    # ==================================================================

    def get_stats(self) -> Dict[str, Any]:
        """Retorna las estadisticas de uso acumuladas."""
        return dict(self._stats)

    def reset_stats(self) -> None:
        """Reinicia las estadisticas de uso."""
        self._stats = {
            "total_requests": 0,
            "total_cost": 0.0,
            "by_model": {},
            "errors": 0,
        }

    # ==================================================================
    # METODOS PRIVADOS — Utilidades
    # ==================================================================

    def _get_price(self, model_id: str, image_size: Optional[str] = None) -> float:
        """Obtiene el precio unitario para un modelo y tamano."""
        cfg = MODELS[model_id]
        if image_size == "4K" and cfg["price_4k"] is not None:
            return cfg["price_4k"]
        if image_size == "2K" and cfg["price_2k"] is not None:
            return cfg["price_2k"]
        if cfg["price_1k"] is not None:
            return cfg["price_1k"]
        if cfg["price_2k"] is not None:
            return cfg["price_2k"]
        return 0.0

    def _record_cost(self, model_id: str, cost: float) -> None:
        """Registra un costo en las estadisticas."""
        self._stats["total_cost"] += cost
        if model_id not in self._stats["by_model"]:
            self._stats["by_model"][model_id] = {
                "count": 0, "cost": 0.0
            }
        self._stats["by_model"][model_id]["count"] += 1
        self._stats["by_model"][model_id]["cost"] += cost


# ---------------------------------------------------------------------------
# Funcion auxiliar nivel modulo
# ---------------------------------------------------------------------------


def _ratio_to_float(ratio: str) -> float:
    """Convierte un string ratio 'W:H' a float W/H."""
    try:
        parts = ratio.split(":")
        return float(parts[0]) / float(parts[1])
    except (IndexError, ValueError, ZeroDivisionError):
        return 1.0


def _dimensions_to_ratio(width: int, height: int) -> str:
    """Convierte dimensiones a un aspect ratio soportado.

    Primero intenta una coincidencia exacta via GCD.
    Si no coincide, busca el ratio mas cercano por distancia decimal.
    """
    g = gcd(width, height)
    rw, rh = width // g, height // g
    exact = f"{rw}:{rh}"
    if exact in ASPECT_RATIOS:
        return exact

    r = width / height
    thresholds = [
        (0.56, "9:16"), (0.67, "2:3"), (0.75, "3:4"), (0.80, "4:5"),
        (1.0, "1:1"), (1.25, "5:4"), (1.33, "4:3"), (1.50, "3:2"),
        (1.78, "16:9"), (2.33, "21:9"),
    ]
    best = "1:1"
    best_dist = float("inf")
    for umbral, ar in thresholds:
        dist = abs(r - umbral)
        if dist < best_dist:
            best_dist = dist
            best = ar
    return best


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _setup_logging(verbose: bool = False) -> None:
    """Configura el logging para la sesion CLI."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


def _cmd_generate(args: argparse.Namespace) -> int:
    """Subcomando: generar imagen desde prompt."""
    helper = GeminiImageHelper(default_model=args.model or DEFAULT_MODEL)

    refs = args.reference if hasattr(args, "reference") and args.reference else None

    img = helper.generate(
        prompt=args.prompt,
        aspect_ratio=args.ratio,
        image_size=args.size,
        model=args.model,
        reference_images=refs,
    )

    if img is None:
        print("ERROR: No se pudo generar la imagen.")
        return 1

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    fmt = "PNG" if out.suffix.lower() in (".png", "") else "JPEG"
    img.save(str(out), format=fmt)
    print(f"Imagen guardada: {out.resolve()}")

    stats = helper.get_stats()
    print(f"Costo estimado: ${stats['total_cost']:.4f} USD")
    return 0


def _cmd_edit(args: argparse.Namespace) -> int:
    """Subcomando: editar imagen existente."""
    helper = GeminiImageHelper()

    img = helper.edit(
        prompt=args.prompt,
        reference_image_path=args.reference,
        aspect_ratio=args.ratio,
        image_size=args.size,
    )

    if img is None:
        print("ERROR: No se pudo editar la imagen.")
        return 1

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    fmt = "PNG" if out.suffix.lower() in (".png", "") else "JPEG"
    img.save(str(out), format=fmt)
    print(f"Imagen editada guardada: {out.resolve()}")

    stats = helper.get_stats()
    print(f"Costo estimado: ${stats['total_cost']:.4f} USD")
    return 0


def _cmd_batch(args: argparse.Namespace) -> int:
    """Subcomando: generar multiples imagenes desde archivo de prompts."""
    prompts_file = Path(args.file)
    if not prompts_file.is_file():
        print(f"ERROR: Archivo no encontrado: {args.file}")
        return 1

    with open(prompts_file, "r", encoding="utf-8") as f:
        prompts = [line.strip() for line in f if line.strip()]

    if not prompts:
        print("ERROR: El archivo de prompts esta vacio.")
        return 1

    print(f"Procesando {len(prompts)} prompts...")

    helper = GeminiImageHelper()
    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    results = helper.batch_generate(
        prompts=prompts,
        aspect_ratio=args.ratio,
        image_size=args.size,
    )

    saved = 0
    for i, img in enumerate(results):
        if img is not None:
            filename = f"batch_{i:04d}.png"
            filepath = out_dir / filename
            img.save(str(filepath), format="PNG")
            saved += 1

    stats = helper.get_stats()
    print(f"\nResultados: {saved}/{len(prompts)} imagenes generadas")
    print(f"Directorio: {out_dir.resolve()}")
    print(f"Costo total estimado: ${stats['total_cost']:.4f} USD")
    return 0


def _cmd_ad_set(args: argparse.Namespace) -> int:
    """Subcomando: generar set de ads multi-formato."""
    helper = GeminiImageHelper()

    refs = args.reference if hasattr(args, "reference") and args.reference else None

    print(f"Generando ad set con {len(AD_FORMATS)} formatos...")

    results = helper.generate_ad_set(
        prompt=args.prompt,
        output_dir=args.output,
        image_size=args.size,
        reference_images=refs,
    )

    stats = helper.get_stats()
    print(f"\nFormatos generados: {len(results)}/{len(AD_FORMATS)}")
    for fmt_name, filepath in results.items():
        fmt = AD_FORMATS[fmt_name]
        print(f"  {fmt_name}: {fmt['width']}x{fmt['height']} -> {filepath}")
    print(f"Costo total estimado: ${stats['total_cost']:.4f} USD")
    return 0


def _cmd_estimate(args: argparse.Namespace) -> int:
    """Subcomando: estimar costos."""
    helper = GeminiImageHelper()

    est = helper.estimate_cost(
        count=args.count,
        model=args.model,
        image_size=args.size,
        use_batch=args.batch,
    )

    print("=== Estimacion de costos ===")
    print(f"  Modelo:          {est['model_name']} ({est['model']})")
    print(f"  Imagenes:        {est['count']}")
    print(f"  Tamano:          {est['image_size']}")
    print(f"  Precio unitario: ${est['unit_price_usd']:.4f} USD")
    print(f"  Total:           ${est['total_price_usd']:.4f} USD")
    if est["batch_api"]:
        if est["supports_batch"]:
            print(f"  Descuento Batch: {est['batch_discount_pct']}%")
            print(f"  Total con Batch: ${est['batch_total_usd']:.4f} USD")
        else:
            print(f"  AVISO: {est['model']} no soporta Batch API")
    print()

    # Comparativa con todos los modelos
    print("=== Comparativa de modelos ===")
    for mid, cfg in MODELS.items():
        comp = helper.estimate_cost(
            count=args.count, model=mid, image_size=args.size
        )
        batch_note = ""
        if cfg["supports_batch"]:
            batch_est = helper.estimate_cost(
                count=args.count, model=mid,
                image_size=args.size, use_batch=True
            )
            batch_note = f" (batch: ${batch_est['batch_total_usd']:.2f})"
        marker = " <-- seleccionado" if mid == est["model"] else ""
        print(f"  {cfg['name']:25s} ${comp['total_price_usd']:8.2f} USD{batch_note}{marker}")

    return 0


def _cmd_models(args: argparse.Namespace) -> int:
    """Subcomando: listar modelos disponibles."""
    print("=== Modelos de generacion de imagen ===\n")
    for model_id, cfg in MODELS.items():
        prices = []
        if cfg["price_1k"] is not None:
            prices.append(f"1K: ${cfg['price_1k']:.3f}")
        if cfg["price_2k"] is not None:
            prices.append(f"2K: ${cfg['price_2k']:.3f}")
        if cfg["price_4k"] is not None:
            prices.append(f"4K: ${cfg['price_4k']:.3f}")
        price_str = ", ".join(prices) if prices else "gratuito (quota)"

        features = []
        if cfg["supports_editing"]:
            features.append("edicion")
        if cfg["supports_multi_turn"]:
            features.append("multi-turn")
        if cfg["supports_4k"]:
            features.append("4K")
        if cfg["supports_batch"]:
            features.append("batch API")
        if cfg["max_refs"] > 0:
            features.append(f"refs: {cfg['max_refs']}")
        feat_str = ", ".join(features) if features else "text-to-image"

        default = " (DEFAULT)" if model_id == DEFAULT_MODEL else ""
        print(f"  {cfg['name']}{default}")
        print(f"    ID:       {model_id}")
        print(f"    Endpoint: {cfg['endpoint']}")
        print(f"    Precios:  {price_str}")
        print(f"    Features: {feat_str}")
        print(f"    Max imgs: {cfg['max_images_per_request']}/request")
        print()
    return 0


def main() -> int:
    """Entry point del CLI."""
    parser = argparse.ArgumentParser(
        description="Gemini Image Helper — generacion de imagenes con Google Gemini",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Ejemplos:\n"
            "  python gemini_image_helper.py generate \"Un gato astronauta\" -o gato.png --ratio 16:9\n"
            "  python gemini_image_helper.py edit \"Cambia el fondo\" -r foto.jpg -o editado.png\n"
            "  python gemini_image_helper.py batch prompts.txt -o output/ --ratio 1:1\n"
            "  python gemini_image_helper.py ad-set \"Premium crypto ad\" -o assets/\n"
            "  python gemini_image_helper.py estimate --count 50 --model gemini-3-pro-image-preview\n"
            "  python gemini_image_helper.py models\n"
        ),
    )
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Activar logs de debug")

    subparsers = parser.add_subparsers(dest="command")

    # --- generate ---
    gen_parser = subparsers.add_parser("generate", help="Generar imagen desde prompt")
    gen_parser.add_argument("prompt", help="Prompt de texto")
    gen_parser.add_argument("-o", "--output", default="output.png",
                            help="Archivo de salida (default: output.png)")
    gen_parser.add_argument("--ratio", default="1:1",
                            help="Aspect ratio (default: 1:1)")
    gen_parser.add_argument("--size", default=None,
                            help="Image size: 1K, 2K, 4K")
    gen_parser.add_argument("--model", default=None,
                            help="Model ID (default: gemini-3-pro-image-preview)")
    gen_parser.add_argument("-r", "--reference", nargs="*",
                            help="Rutas a imagenes de referencia")

    # --- edit ---
    edit_parser = subparsers.add_parser("edit", help="Editar imagen existente")
    edit_parser.add_argument("prompt", help="Instruccion de edicion")
    edit_parser.add_argument("-r", "--reference", required=True,
                             help="Imagen a editar")
    edit_parser.add_argument("-o", "--output", default="edited.png",
                             help="Archivo de salida (default: edited.png)")
    edit_parser.add_argument("--ratio", default=None,
                             help="Aspect ratio del resultado")
    edit_parser.add_argument("--size", default=None,
                             help="Image size: 1K, 2K, 4K")

    # --- batch ---
    batch_parser = subparsers.add_parser("batch",
                                          help="Generar multiples imagenes desde archivo")
    batch_parser.add_argument("file",
                               help="Archivo con prompts (1 por linea)")
    batch_parser.add_argument("-o", "--output", default="output",
                               help="Directorio de salida (default: output)")
    batch_parser.add_argument("--ratio", default="1:1",
                               help="Aspect ratio (default: 1:1)")
    batch_parser.add_argument("--size", default=None,
                               help="Image size: 1K, 2K, 4K")

    # --- ad-set ---
    adset_parser = subparsers.add_parser("ad-set",
                                          help="Generar set de ads multi-formato")
    adset_parser.add_argument("prompt",
                               help="Prompt base para el ad")
    adset_parser.add_argument("-o", "--output", default="ads",
                               help="Directorio de salida (default: ads)")
    adset_parser.add_argument("--size", default="2K",
                               help="Image size (default: 2K)")
    adset_parser.add_argument("-r", "--reference", nargs="*",
                               help="Rutas a imagenes de referencia")

    # --- estimate ---
    est_parser = subparsers.add_parser("estimate", help="Estimar costos")
    est_parser.add_argument("--count", type=int, required=True,
                             help="Numero de imagenes")
    est_parser.add_argument("--model", default=DEFAULT_MODEL,
                             help="Modelo (default: gemini-3-pro-image-preview)")
    est_parser.add_argument("--size", default="2K",
                             help="Image size (default: 2K)")
    est_parser.add_argument("--batch", action="store_true",
                             help="Usar Batch API pricing")

    # --- models ---
    subparsers.add_parser("models", help="Listar modelos disponibles")

    args = parser.parse_args()

    _setup_logging(verbose=args.verbose if hasattr(args, "verbose") else False)

    if not args.command:
        parser.print_help()
        return 0

    # Verificar API key antes de comandos que la necesitan
    commands_needing_key = {"generate", "edit", "batch", "ad-set"}
    if args.command in commands_needing_key:
        if not os.getenv("GEMINI_API_KEY"):
            print("ERROR: Variable de entorno GEMINI_API_KEY no configurada.")
            print("Obtener en: https://aistudio.google.com/apikey")
            return 1

    # Verificar Pillow
    if Image is None and args.command in commands_needing_key:
        print("ERROR: Pillow es requerido. Instalar con: pip install Pillow")
        return 1

    dispatch = {
        "generate": _cmd_generate,
        "edit": _cmd_edit,
        "batch": _cmd_batch,
        "ad-set": _cmd_ad_set,
        "estimate": _cmd_estimate,
        "models": _cmd_models,
    }

    handler = dispatch.get(args.command)
    if handler is None:
        parser.print_help()
        return 0

    try:
        return handler(args)
    except GeminiImageError as exc:
        print(f"ERROR [{exc.model}]: {exc.message}")
        return 1
    except KeyboardInterrupt:
        print("\nInterrumpido por el usuario.")
        return 130
    except Exception as exc:
        logger.exception("Error inesperado")
        print(f"ERROR: {exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
