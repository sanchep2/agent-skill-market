# nano-banana-pro — Skill de Claude Code

Skill instalable para **Claude Code**: generación y edición de imágenes con
**Google Gemini 3 Pro Image** e **Imagen 4** (Fast/Standard/Ultra). Cubre
generación text-to-image, edición y multimodal, renderizado de texto dentro de
la imagen (SOTA), prompting avanzado, selección de modelo por caso de uso,
Batch API, optimización de coste, autenticación y manejo de errores. Autocontenida.

## Cómo instalar

1. Descomprime este ZIP. Obtendrás una carpeta `nano-banana-pro/`.
2. Cópiala a tu directorio de skills de Claude Code:
   - **Personal:** `~/.claude/skills/nano-banana-pro/`
   - **Solo un proyecto:** `<tu-proyecto>/.claude/skills/nano-banana-pro/`
3. Reinicia Claude Code. Se activará sola al generar o editar imágenes con Gemini/Imagen.

## Requisitos
- Una API key de Google Gemini en la variable de entorno `GEMINI_API_KEY` (requiere billing activo).
- SDK: `pip install google-genai` (Python) o `npm install @google/genai` (Node.js).

## Contenido
- `SKILL.md` — guía principal (modelos, endpoints, reglas de selección).
- `references/` — models-and-selection, image-generation, image-editing-and-multimodal,
  prompting-and-text-rendering, batch-api-and-optimization, api-and-authentication,
  sdks-and-code-examples, limitations-and-error-handling.
- `scripts/gemini_image_helper.py` — helper de línea de comandos.

Cortesía de **Talent Academy · Vibe Coder**.
