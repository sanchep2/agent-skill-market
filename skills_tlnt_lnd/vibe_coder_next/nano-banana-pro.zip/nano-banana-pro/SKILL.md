---
name: nano-banana-pro
description: "Skill operativo para generación y edición de imágenes con Gemini/Imagen."
---

# Nano Banana Pro — Google Gemini Image & Imagen 4 Skill

Skill completo para generacion de imagenes con Google Gemini Image API e Imagen 4.
Gemini 3 Pro Image es el modelo principal — sin Flash. Todo verificado en produccion (feb 2026).

---

## Quick Orientation

**4 modelos activos (Gemini 3 Pro minimo — sin Flash):**

| Modelo | ID | Tipo | Costo/img |
|--------|-----|------|-----------|
| **Gemini 3 Pro Image** | `gemini-3-pro-image-preview` | Generacion + edicion + 4K + texto SOTA | $0.13-$0.24 |
| Imagen 4 Fast | `imagen-4.0-fast-generate-001` | Text-to-image puro, volumen masivo | $0.02 |
| Imagen 4 Standard | `imagen-4.0-generate-001` | Text-to-image, mayor calidad | $0.04 |
| Imagen 4 Ultra | `imagen-4.0-ultra-generate-001` | Text-to-image, maxima calidad | $0.06 |

**Endpoint principal:** `POST https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent`
**Auth:** API key via `GEMINI_API_KEY` (env var o query param `?key=`)
**SDKs:** `pip install google-genai` (Python) / `npm install @google/genai` (Node.js)
**Rate limits:** Free tier = 0 IPM. Tier 1 = ~10 IPM, 150-300 RPM. Requiere billing activo.
**Output:** Siempre PNG base64 en `inlineData.data`. SynthID watermark invisible en todas las imagenes.

> **REGLA: Gemini 3 Pro Image siempre como modelo por defecto.** Imagen 4 Fast solo para volumen
> masivo sin edicion (>1000 imgs). Imagen 4 Ultra para maxima calidad sin edicion.

---

## Reference Files

| Archivo | Lineas | Leer cuando... |
|---------|--------|----------------|
| [models-and-selection.md](references/models-and-selection.md) | ~500 | Necesitas elegir modelo, ver feature matrix, pricing, o decision tree |
| [api-and-authentication.md](references/api-and-authentication.md) | ~600 | Necesitas endpoints, auth, parametros JSON, request/response completos |
| [image-generation.md](references/image-generation.md) | ~550 | Generas imagenes: text-to-image, aspect ratios, resoluciones, multi-formato |
| [image-editing-and-multimodal.md](references/image-editing-and-multimodal.md) | ~500 | Editas imagenes: ref images, multi-turn, style transfer, composicion |
| [prompting-and-text-rendering.md](references/prompting-and-text-rendering.md) | ~600 | Escribes prompts: framework 6 elementos, texto en imagenes, ejemplos |
| [batch-api-and-optimization.md](references/batch-api-and-optimization.md) | ~450 | Optimizas costos: Batch API 50%, routing hibrido, proyecciones |
| [sdks-and-code-examples.md](references/sdks-and-code-examples.md) | ~650 | Escribes codigo: Python, Node.js, REST, async, error handling |
| [limitations-and-error-handling.md](references/limitations-and-error-handling.md) | ~500 | Debuggeas: filtros, rate limits, retry, workarounds, comparacion alternativas |
| [gemini_image_helper.py](scripts/gemini_image_helper.py) | ~900 | Necesitas script de produccion: multi-modelo, batch, CLI, circuit breaker |

---

## Quick Start

### Python — Text-to-image con Gemini 3 Pro

```python
# pip install google-genai Pillow
# export GEMINI_API_KEY="tu-api-key"
from google import genai
from google.genai import types

client = genai.Client()  # Lee GEMINI_API_KEY del entorno

response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=["Poster profesional para un evento de trading, fondo oscuro, "
              "acentos dorados, texto 'CURSO ONLINE' en sans-serif bold blanca"],
    config=types.GenerateContentConfig(
        response_modalities=["TEXT", "IMAGE"],
        image_config=types.ImageConfig(
            aspect_ratio="16:9",
            image_size="2K",
        ),
    ),
)

for part in response.parts:
    if part.inline_data is not None:
        part.as_image().save("output.png")
        print("Imagen guardada: output.png")
```

### Python — Edicion con imagen de referencia

```python
from PIL import Image

ref = Image.open("foto_original.jpg")
response = client.models.generate_content(
    model="gemini-3-pro-image-preview",
    contents=[
        "Cambia el fondo por un atardecer en la playa. Manten el sujeto principal intacto.",
        ref,
    ],
    config=types.GenerateContentConfig(response_modalities=["TEXT", "IMAGE"]),
)
for part in response.parts:
    if part.inline_data:
        part.as_image().save("editado.png")
```

### Node.js — Text-to-image

```typescript
// npm install @google/genai
import { GoogleGenAI } from "@google/genai";
import * as fs from "node:fs";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const response = await ai.models.generateContent({
  model: "gemini-3-pro-image-preview",
  contents: "Poster profesional para evento de trading, fondo oscuro, acentos dorados",
  config: {
    responseModalities: ["TEXT", "IMAGE"],
    imageConfig: { aspectRatio: "16:9", imageSize: "2K" },
  },
});

for (const part of response.candidates[0].content.parts) {
  if (part.inlineData) {
    fs.writeFileSync("output.png", Buffer.from(part.inlineData.data, "base64"));
  }
}
```

### cURL — REST directo

```bash
curl -X POST \
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-3-pro-image-preview:generateContent?key=$GEMINI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "contents": [{"parts": [{"text": "Un gato astronauta en el espacio, estilo fotorrealista"}]}],
    "generationConfig": {
      "responseModalities": ["TEXT", "IMAGE"],
      "imageConfig": {"aspectRatio": "1:1", "imageSize": "2K"}
    }
  }' | python3 -c "
import sys, json, base64
data = json.load(sys.stdin)
for part in data['candidates'][0]['content']['parts']:
    if 'inlineData' in part:
        with open('output.png', 'wb') as f:
            f.write(base64.b64decode(part['inlineData']['data']))
        print('output.png guardado')
"
```

### Imagen 4 — Volumen masivo (text-to-image puro)

```python
response = client.models.generate_images(
    model="imagen-4.0-fast-generate-001",
    prompt="Product photo of wireless headphones on marble, dramatic studio lighting",
    config=types.GenerateImagesConfig(
        number_of_images=4,
        aspect_ratio="1:1",
        person_generation="allow_adult",
        safety_filter_level="block_only_high",
    ),
)
for i, img in enumerate(response.generated_images):
    img.image.save(f"imagen4_{i}.png")
```

---

## Essential Patterns

### 1. Flujo de generacion de imagen

```
  Prompt + Config
       │
       ▼
  ┌─────────────────────┐
  │ generateContent      │  ← Gemini 3 Pro (default)
  │ (v1beta endpoint)    │  ← Con imageConfig al nivel raiz
  └─────────┬───────────┘
            │
            ▼
  ┌─────────────────────┐
  │ Response             │
  │ candidates[0]        │
  │  .content.parts[N]   │
  │   .inlineData.data   │  ← PNG base64
  └─────────┬───────────┘
            │
            ▼
  base64.b64decode() → PIL Image / Buffer → .save("output.png")
```

### 2. Decision tree: seleccion de modelo

```
  ¿Que necesito?
       │
       ├── Edicion / multi-turn / ref imgs / texto en imagen / 4K
       │   └── Gemini 3 Pro Image (SIEMPRE)
       │
       ├── Text-to-image puro, volumen >1000, sin edicion
       │   └── Imagen 4 Fast ($0.02/img)
       │
       ├── Maxima calidad text-to-image, sin edicion
       │   └── Imagen 4 Ultra ($0.06/img)
       │
       └── Cualquier otra cosa
            └── Gemini 3 Pro Image (default)
```

### 3. Pipeline multi-formato para ads

```
  1 Prompt base
       │
       ├── aspect_ratio="16:9" → Landscape (YouTube, LinkedIn, X)
       ├── aspect_ratio="1:1"  → Square (Instagram, Facebook, X)
       ├── aspect_ratio="4:5"  → Portrait (Instagram Feed, Facebook Feed)
       └── aspect_ratio="9:16" → Vertical (Stories, Reels, TikTok)
       │
       ▼
  4 imagenes → resize_and_crop() → assets listos para plataforma
```

### 4. Batch API flow (50% descuento)

```
  Lista de prompts
       │
       ▼
  client.batches.create(model, requests)
       │
       ▼
  Polling: client.batches.get(name)
       │  (tipico 2-4h, max 24h)
       ▼
  batch_job.dest.inlined_responses
       │
       ▼
  Extraer imagenes de cada response
```

### 5. Multi-turn editing flow

```
  chat = client.chats.create(model="gemini-3-pro-image-preview", config=...)
       │
  Turno 1: chat.send_message("Crea un poster para evento X")
       │   → poster_v1.png
       │
  Turno 2: chat.send_message("Cambia colores a azul y dorado")
       │   → poster_v2.png (contexto visual preservado)
       │
  Turno 3: chat.send_message("Agrega fecha '28 FEB' en la parte inferior")
       │   → poster_v3.png (edicion incremental)
       ▼
  Resultado final con todas las iteraciones
```

---

## Critical Gotchas (15+ verificados en produccion)

1. **SDK deprecado** — `google-generativeai` (Python) y `@google/generative-ai` (Node.js) estan DEPRECADOS. Usar `google-genai` / `@google/genai`.

2. **imageConfig EN LA RAIZ** — `imageConfig` va al nivel raiz del body (o en `config`), NO dentro de `generationConfig`. Error mas comun.

3. **K MAYUSCULA en imageSize** — `"2K"` correcto, `"2k"` NO funciona. Valores: `"1K"`, `"2K"`, `"4K"`.

4. **Free tier = 0 IPM** — Desde dic 2025, el free tier tiene 0 imagenes/minuto para modelos de imagen. Se necesita billing activo.

5. **responseModalities OBLIGATORIO** — Sin `["TEXT", "IMAGE"]` o `["IMAGE"]`, NO genera imagenes.

6. **1 imagen por response** — `generateContent` retorna maximo 1 imagen por llamada. Para multiples, hacer multiples llamadas o usar Batch API.

7. **Filtro PROHIBITED_CONTENT** — ~30% de prompts bloqueados sin razon. NO se desactiva con safetySettings. Workarounds: reintentar, reformular, evitar palabras gatillo.

8. **SynthID watermark** — Invisible, en TODAS las imagenes. No se puede desactivar.

9. **503 model overloaded** — Frecuente en Gemini 3 Pro en horas pico. Retry con exponential backoff.

10. **Sobre-edicion** — El modelo cambia mas de lo pedido. Ser MUY especifico sobre que NO cambiar.

11. **candidateCount = 1** — Solo 1 candidato soportado para generacion de imagen.

12. **Output siempre PNG** — `image/png`, no configurable en Gemini nativo.

13. **1290 tokens por imagen** — Cada imagen consume exactamente 1290 tokens de salida.

14. **finishReason SAFETY** — Verificar `candidate.finish_reason` ANTES de extraer imagen. Si es SAFETY o IMAGE_SAFETY, no hay imagen.

15. **No negative prompts** — Gemini nativo NO tiene parametro de negative prompt. Usar framing afirmativo.

16. **Ambiguedad → solo texto** — Si el prompt es ambiguo, puede devolver solo texto sin imagen. Ser explicito: "Genera una imagen de..."

17. **Input max 20MB** — Imagenes inline maximo 20MB. Para archivos mayores, usar Files API.

18. **Imagen 4 sin edicion** — Los modelos Imagen NO soportan edicion, multi-turn, ni imagenes de referencia.

---

## Cross-Skill Integration

### creative-multimedia
Nano Banana Pro es el **backend principal de imagen** del skill creative-multimedia. El pipeline
`image_generator.py` llama a Gemini 3 Pro Image via la clase `NanoBananaBackend`. Para produccion
de assets publicitarios, usar creative-multimedia como orquestador y este skill como referencia
de la API de imagen.

### remotion-skill
Las CTA cards de los video ads se generan con Nano Banana Pro y se usan como `<Img>` en
composiciones Remotion. Ver `references/nano-banana-cta-generation.md` en remotion-skill para
el flujo completo: generar → public/assets/ → `<Img src={staticFile("assets/cta.png")}/>`.

### convex-skill
Para generar imagenes desde el backend Convex, usar una `action` (no query/mutation) que llame
a la API de Gemini via `fetch()`. Convex actions pueden hacer llamadas HTTP externas.

### google-ads-api
Demand Gen campaigns de Google Ads requieren imagenes en formatos especificos:
landscape 1200x628, square 1200x1200, logo 1200x300. Este skill genera los assets,
google-ads-api los sube a Google Ads.

### meta-ads-api
Feed (1:1 y 4:5), Stories (9:16), Reels covers. Generar con aspect ratios nativos
de este skill, subir via Meta Marketing API.

---

## Production Patterns (verificados en este repo)

### 10 ad creatives generados (scripts/generate-ad-creatives.py)
- 2 variantes × 5 formatos (landscape, square, portrait, meta-feed, stories)
- Variante A: con foto de referencia de Jaime Merino (persona)
- Variante B: sin persona, solo charts de trading
- Modelo: `gemini-3-pro-image-preview` sin imageSize (default 1K)
- Resize con Pillow despues de generacion

### 9 CTA cards generados (scripts/generate-video-cta-cards.py)
- 3 formatos (landscape, vertical, square) × 3 variantes de texto
- Imagenes de referencia: 3 creatives de campana + logo
- Modelo: `gemini-3-pro-image-preview` con `imageSize: "2K"`
- Para uso en composiciones Remotion como end-cards

### Patron de generacion robusto
```python
def generate_image(prompt, aspect_ratio="1:1", reference_images=None, retry=3):
    parts = []
    if reference_images:
        for ref_path in reference_images:
            if os.path.exists(ref_path):
                parts.append({"inlineData": {
                    "mimeType": "image/png",
                    "data": image_to_base64(ref_path)
                }})
    parts.append({"text": prompt})

    payload = {
        "contents": [{"parts": parts}],
        "generationConfig": {
            "responseModalities": ["TEXT", "IMAGE"],
            "imageConfig": {"aspectRatio": aspect_ratio}
        }
    }

    for attempt in range(retry):
        resp = requests.post(GEMINI_URL, json=payload, timeout=120)
        if resp.status_code == 429:
            time.sleep(15 * (attempt + 1))
            continue
        if resp.status_code == 200:
            for part in resp.json()["candidates"][0]["content"]["parts"]:
                if "inlineData" in part:
                    return Image.open(BytesIO(base64.b64decode(part["inlineData"]["data"])))
    return None
```

---

## Next Steps

| Necesitas... | Lee... |
|-------------|--------|
| Elegir modelo, ver precios | [models-and-selection.md](references/models-and-selection.md) |
| Parametros API, JSON request/response | [api-and-authentication.md](references/api-and-authentication.md) |
| Generar imagenes, aspect ratios | [image-generation.md](references/image-generation.md) |
| Editar imagenes, multi-turn | [image-editing-and-multimodal.md](references/image-editing-and-multimodal.md) |
| Escribir prompts efectivos | [prompting-and-text-rendering.md](references/prompting-and-text-rendering.md) |
| Optimizar costos, Batch API | [batch-api-and-optimization.md](references/batch-api-and-optimization.md) |
| Codigo Python/Node.js/REST | [sdks-and-code-examples.md](references/sdks-and-code-examples.md) |
| Debuggear errores, filtros | [limitations-and-error-handling.md](references/limitations-and-error-handling.md) |
| Script helper de produccion | [gemini_image_helper.py](scripts/gemini_image_helper.py) |
